#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
BACKEND_PORT="${BACKEND_PORT:-8000}"
FRONTEND_PORT="${FRONTEND_PORT:-5173}"
PYTHON_ENV_OVERRIDE="${SCHOOL_AI_PYTHON:-${PYTHON_BIN:-}}"

log() {
  printf '\n[school-ai] %s\n' "$1"
}

fail() {
  printf '\n[school-ai] ERROR: %s\n' "$1" >&2
  exit 1
}

cleanup() {
  if [ -n "${BACKEND_PID:-}" ]; then kill "$BACKEND_PID" 2>/dev/null || true; fi
  if [ -n "${FRONTEND_PID:-}" ]; then kill "$FRONTEND_PID" 2>/dev/null || true; fi
}
trap cleanup EXIT INT TERM

python_version() {
  "$1" - <<'PY'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
PY
}

python_is_supported() {
  "$1" - <<'PY'
import sys
raise SystemExit(0 if (sys.version_info.major == 3 and sys.version_info.minor in (11, 12)) else 1)
PY
}

find_supported_python() {
  if [ -n "$PYTHON_ENV_OVERRIDE" ]; then
    if ! command -v "$PYTHON_ENV_OVERRIDE" >/dev/null 2>&1 && [ ! -x "$PYTHON_ENV_OVERRIDE" ]; then
      fail "Configured Python '$PYTHON_ENV_OVERRIDE' was not found. Set SCHOOL_AI_PYTHON to python3.12 or install it with: brew install python@3.12"
    fi
    if python_is_supported "$PYTHON_ENV_OVERRIDE"; then
      printf '%s' "$PYTHON_ENV_OVERRIDE"
      return 0
    fi
    fail "Configured Python '$PYTHON_ENV_OVERRIDE' is version $(python_version "$PYTHON_ENV_OVERRIDE"). This app requires Python 3.11 or 3.12."
  fi

  for candidate in \
    python3.12 \
    /opt/homebrew/bin/python3.12 \
    /usr/local/bin/python3.12 \
    /opt/homebrew/opt/python@3.12/bin/python3.12 \
    /usr/local/opt/python@3.12/bin/python3.12 \
    python3.11 \
    /opt/homebrew/bin/python3.11 \
    /usr/local/bin/python3.11 \
    /opt/homebrew/opt/python@3.11/bin/python3.11 \
    /usr/local/opt/python@3.11/bin/python3.11; do
    if command -v "$candidate" >/dev/null 2>&1 || [ -x "$candidate" ]; then
      if python_is_supported "$candidate"; then
        printf '%s' "$candidate"
        return 0
      fi
    fi
  done

  fail "Python 3.11 or 3.12 was not found. Install Python 3.12 with: brew install python@3.12"
}

ensure_backend_venv() {
  local selected_python="$1"
  local venv_python="$BACKEND_DIR/venv/bin/python"

  if [ -x "$venv_python" ]; then
    if ! python_is_supported "$venv_python"; then
      log "Removing backend/venv because it was created with Python $(python_version "$venv_python")."
      rm -rf "$BACKEND_DIR/venv"
    else
      log "Using existing backend/venv with Python $(python_version "$venv_python")."
      return 0
    fi
  fi

  if [ ! -d "$BACKEND_DIR/venv" ]; then
    log "Creating backend/venv with $selected_python ($(python_version "$selected_python"))."
    "$selected_python" -m venv "$BACKEND_DIR/venv"
  fi
}

log "Preparing backend."
cd "$BACKEND_DIR"
if [ ! -f ".env" ] && [ -f ".env.example" ]; then
  cp .env.example .env
  log "Created backend/.env from .env.example."
fi

PYTHON_CMD="$(find_supported_python)"
ensure_backend_venv "$PYTHON_CMD"

# shellcheck disable=SC1091
source "$BACKEND_DIR/venv/bin/activate"
log "Backend runtime: $(python --version 2>&1)."

python -m pip install --upgrade pip setuptools wheel
python -m pip install --prefer-binary -r requirements-lite.txt
python - <<'PY'
import importlib.metadata as metadata
version = metadata.version("email-validator")
if version != "2.2.0":
    raise SystemExit(f"email-validator must be 2.2.0, found {version}")
print("[school-ai] email-validator==2.2.0 is installed.")
PY
python seed.py

log "Starting backend on http://127.0.0.1:$BACKEND_PORT."
uvicorn app.main:app --reload --port "$BACKEND_PORT" &
BACKEND_PID=$!

log "Preparing frontend."
cd "$FRONTEND_DIR"
if ! command -v npm >/dev/null 2>&1; then
  fail "npm was not found. Install Node.js 20+ before running this script."
fi
if [ ! -d "node_modules" ]; then
  npm install
fi

log "Starting frontend on http://127.0.0.1:$FRONTEND_PORT."
BACKEND_URL="http://127.0.0.1:$BACKEND_PORT" npm run dev -- --host 0.0.0.0 --port "$FRONTEND_PORT" &
FRONTEND_PID=$!

log "Both services are running in this terminal. Open http://127.0.0.1:$FRONTEND_PORT and press Ctrl+C here to stop."
wait "$BACKEND_PID" "$FRONTEND_PID"
