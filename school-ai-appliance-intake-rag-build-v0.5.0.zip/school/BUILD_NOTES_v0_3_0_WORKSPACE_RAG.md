# Build v0.3.0 - Workspace RAG, Chat History, Scope Control, Usage Analytics

This build applies the roadmap direction to the v0.2.1 School AI package and focuses on the immediate application changes requested for a small CPU-only rollout.

## Key additions

### Workspace-first document flow

- Added personal workspaces for every user profile.
- Added automatic default workspace creation during seed/startup.
- Document upload now requires/selects a workspace from the UI.
- Uploaded documents carry workspace metadata into SQLite and ChromaDB.
- Owners retain access to their own uploaded files, even for custom categories.

### Category creation page

- Added a new **Workspaces & Categories** page.
- Added dynamic document categories in the database.
- Default categories are seeded automatically.
- School Admin, Principal, and Super Admin can create/reactivate categories.
- Categories are now used in upload selection and Ask AI scope filtering.

### Ask AI RAG scoping

- Removed example prompt buttons.
- Added an optional pre-question scope dialog.
- Users can ask against:
  - all accessible documents,
  - one workspace,
  - selected categories,
  - selected file types,
  - selected individual documents.
- Backend enforces scope against the user's real accessible document IDs before vector search.

### Chat history

- Added `/api/ai/history`.
- Ask AI now shows saved chat history per profile.
- Users can reopen previous questions and answers.
- Users can clear their own Ask AI history.

### Model/token analytics

- Ollama chat responses now store for Ask AI, Teacher Tools, and Admin Tools:
  - model name,
  - prompt tokens,
  - completion tokens,
  - total tokens,
  - generation duration,
  - RAG scope summary.
- Replaced the sample-style analytics page with real AI/model/document/workspace usage analytics.

### Branding cleanup

- The sidebar and login page now use only the uploaded branding logo image.
- Removed the duplicate visible `AI` brand mark next to the logo.

### Dependency/runtime fix

- `email-validator==2.2.0` is present in both:
  - `backend/requirements.txt`
  - `backend/requirements-lite.txt`

### One-command local run

Added:

```bash
./run_local.sh
```

The script starts the backend and frontend together from one terminal, installs backend lite requirements, runs seed, and starts Vite with the backend proxy.

## Notes

This build does not yet implement the heavier roadmap items such as OCR fallback, Huey/RQ job queue, SSE streaming, hybrid FTS5 retrieval, FlashRank reranking, or the exam-evaluation SIS module. The schema and UI changes in this build prepare the application for those roadmap phases without forcing extra services onto the local Mac test setup.
