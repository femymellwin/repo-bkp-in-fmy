# School AI Appliance - Intake UI + RAG Control Build v0.2.0

Build name: **school-ai-appliance-intake-rag-build-v0.2.0**

## Major changes

- Rebranded the School AI frontend toward the Intake IQ visual style: Intake logo, white enterprise sidebar, gradient hero panel, card polish, and Intake-style account controls.
- Added **RAG Audit** page for document ingestion visibility:
  - vector database name, path, collection, telemetry state, vector count
  - total documents, completed/failed/pending documents, total chunks, average chunk size
  - per-document chunk size, overlap, strategy, embedding provider/model, indexed time, and index errors
  - recent chunk previews so admins can see what the RAG engine is actually searching
- Made chunking configurable by file type:
  - PDF/DOCX default: 800 words with 120-word overlap
  - TXT default: 700 words with 100-word overlap
  - CSV/XLSX default: 600 words with 80-word overlap
  - saved in DB settings and persisted on each document at indexing time
- Added **Model Configuration** page:
  - chat model name
  - embedding provider: Ollama or sentence-transformers
  - embedding model name
  - RAG top-K retrieval count
  - Ollama model list and availability checks
  - explicit note explaining why sentence-transformer embeddings do not appear as an Ollama model
- Default local model settings now match your target stack:
  - `OLLAMA_MODEL=qwen3:4b`
  - `EMBEDDING_PROVIDER=ollama`
  - `OLLAMA_EMBEDDING_MODEL=embeddinggemma`
- Added **Upload Permissions** page:
  - server-side editable roles that can upload
  - read/RAG category matrix for roles
- Added **Users** page similar to Intake:
  - create/edit users
  - role changes
  - active/inactive flag
  - password reset
  - per-user menu exclusions
- Added **Teacher Profile** page:
  - teachers can maintain their own profile
  - subjects, grades, bio, classroom, office hours, extracurricular roles, and RAG notes
  - common timetable remains separately controlled by school admin/principal
- Added **Onboarding** page:
  - extracurricular onboarding tasks
  - owner assignment
  - status tracking
  - teacher-owned update capability for assigned items
- Added backend audit events for RAG config changes, model config changes, upload permission changes, user edits, teacher profile updates, and onboarding changes.
- Added additive SQLite schema-upgrade helper so older local DBs get new columns without manual migration.

## Current RAG internals

- **Vector database:** ChromaDB persistent local store in `backend/data/vector_store`.
- **Collection:** `school_documents`.
- **Vector metric:** cosine distance (`hnsw:space=cosine`).
- **Chunking method:** word-based sliding window.
- **Indexing owner:** backend `ingestion_service` background task triggered after upload.
- **Metadata database:** SQLite (`backend/data/school_ai.db`).
- **Document storage:** encrypted local files under `backend/data/encrypted_documents`.

## Build validation performed here

- Python syntax compile passed with `python3 -m compileall app seed.py`.
- Full backend import/runtime test could not be executed in this sandbox because Python dependencies from `requirements.txt` are not installed here.
- Full frontend Vite build could not be executed in this sandbox because `node_modules` are not installed and `npm install` timed out. Run `npm install && npm run build` on your machine/VM.

## Install commands

```bash
cd backend
python3.12 -m venv venv
source venv/bin/activate
pip install -r requirements-lite.txt
cp .env.example .env
ollama pull qwen3:4b
ollama pull embeddinggemma
python seed.py
uvicorn app.main:app --reload --port 8000
```

```bash
cd frontend
npm install
npm run dev
```
