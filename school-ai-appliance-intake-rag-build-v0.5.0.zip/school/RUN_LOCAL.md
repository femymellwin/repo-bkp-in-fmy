# Run the full local app from one terminal

From the project root:

```bash
./run_local.sh
```

Or on macOS, double-click:

```text
run_school_ai.command
```

The script starts both services in one terminal session:

- Backend: http://127.0.0.1:8000
- Frontend: http://127.0.0.1:5173

## Important Python runtime fix

This build requires **Python 3.11 or Python 3.12** for the backend. Do not use Python 3.13 or 3.14 for the backend venv.

The launcher now automatically searches for Python in this order:

1. `SCHOOL_AI_PYTHON` or `PYTHON_BIN`, if you set one manually
2. `python3.12`
3. Homebrew Python 3.12 locations
4. `python3.11`
5. Homebrew Python 3.11 locations

If an existing `backend/venv` was created with Python 3.13 or 3.14, the script removes it and recreates it with Python 3.12 or 3.11. This prevents the `pydantic-core` / PyO3 build error that happens with Python 3.14.

Install Python 3.12 on macOS with:

```bash
brew install python@3.12
```

Then run:

```bash
./run_local.sh
```

To force a specific Python binary:

```bash
SCHOOL_AI_PYTHON=/opt/homebrew/bin/python3.12 ./run_local.sh
```

## What the script does

1. Creates `backend/.env` from `.env.example` when needed.
2. Finds Python 3.12 or 3.11 only.
3. Recreates `backend/venv` if it was made with an unsupported Python version.
4. Installs `backend/requirements-lite.txt`, including `email-validator==2.2.0`.
5. Verifies that `email-validator==2.2.0` is installed.
6. Runs `python seed.py` so default users, default workspaces, and default categories exist.
7. Starts FastAPI and Vite together.

Before using RAG, keep Ollama running and pull the local models:

```bash
ollama pull qwen3:4b
ollama pull embeddinggemma
```

## Manual reset, only if needed

If you previously created a broken Python 3.14 venv manually, you can also reset it yourself:

```bash
cd backend
rm -rf venv
python3.12 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install --prefer-binary -r requirements-lite.txt
python seed.py
```

Then return to the project root and use:

```bash
./run_local.sh
```

## Optional web search in v0.4.0

The app still uses the local Ollama model for final answers. Web search is optional and permission controlled:

1. Open **Settings** as a system admin.
2. Turn on **Enable web search globally**.
3. Choose DuckDuckGo HTML for no-key testing or Brave Search API with an API key.
4. Open **Users**, edit the user, and enable **Allow web search**.
5. Ask AI will show a per-question **Web search** toggle for that user.

Uploaded documents remain local and encrypted. When web search is enabled, only the question text is sent to the configured search provider to retrieve snippets.
