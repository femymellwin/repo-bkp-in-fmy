# School AI Appliance v0.4.0 - Web Search + Project Chat Build

This build adds a controlled web-search layer and a project-style chat interface while preserving the local-first RAG appliance architecture.

## Major changes

- Added global web-search settings:
  - `web_search_enabled`
  - `web_search_provider`
  - `web_search_max_results`
  - `web_search_timeout_seconds`
  - `web_search_api_key`
- Added per-user web-search permission on the Users page.
- Added backend web-search service with:
  - DuckDuckGo HTML provider without an API key
  - Brave Search API provider when an API key is configured
- Updated Ask School AI so the local model can consume:
  - local ChromaDB RAG snippets
  - optional web-search snippets
  - both together when enabled
- Added project-style chat tables:
  - `chat_projects`
  - `chat_threads`
  - `chat_messages`
- Rebuilt Ask AI UI as a modern chat workspace:
  - project rail
  - chat threads
  - persistent message history
  - document/category/workspace/file-type scope modal
  - web-search toggle
  - local and web source display
  - token/model usage strip
- Added web-search usage fields to `ai_queries` for analytics.
- Updated Analytics to show web-search usage.
- Preserved Python 3.11/3.12 launcher guard and `email-validator==2.2.0`.

## Web-search control model

Web search only runs when both conditions are true:

1. Settings -> Web Search -> global web search is enabled.
2. Users -> selected user -> Allow web search is enabled.

The Ask AI screen also provides a per-question web-search toggle, but it is disabled unless both backend permissions are already true.

## Privacy posture

Uploaded documents remain encrypted and local. When web search is enabled, only the user's question is sent to the configured search provider to retrieve snippets. The local LLM still generates the final answer through Ollama.

## Run

```bash
./run_local.sh
```

Then open:

```text
http://127.0.0.1:5173
```

Pull local models before RAG use:

```bash
ollama pull qwen3:4b
ollama pull embeddinggemma
```
