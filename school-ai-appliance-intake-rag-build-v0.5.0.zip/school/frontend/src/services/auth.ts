import { api, setToken, clearToken } from "./api";
import type { User } from "../types";

interface LoginResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export async function login(email: string, password: string): Promise<User> {
  const data = await api.post<LoginResponse>("/auth/login", { email, password });
  setToken(data.access_token);
  return data.user;
}

export function logout() {
  clearToken();
}

export async function fetchCurrentUser(): Promise<User> {
  return api.get<User>("/auth/me");
}
