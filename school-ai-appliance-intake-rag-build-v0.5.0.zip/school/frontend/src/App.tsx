import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./hooks/useAuth";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import AskAI from "./pages/AskAI";
import Documents from "./pages/Documents";
import Workspaces from "./pages/Workspaces";
import TeacherTools from "./pages/TeacherTools";
import AdminTools from "./pages/AdminTools";
import Timetable from "./pages/Timetable";
import Analytics from "./pages/Analytics";
import AuditLogs from "./pages/AuditLogs";
import Backup from "./pages/Backup";
import SystemHealth from "./pages/SystemHealth";
import Settings from "./pages/Settings";
import RagAudit from "./pages/RagAudit";
import ModelConfig from "./pages/ModelConfig";
import UploadPermissions from "./pages/UploadPermissions";
import UsersPage from "./pages/Users";
import TeacherProfilePage from "./pages/TeacherProfile";
import OnboardingPage from "./pages/Onboarding";
import type { Role } from "./types";

function page(title: string, element: JSX.Element, allowedRoles?: Role[]) {
  return (
    <ProtectedRoute allowedRoles={allowedRoles}>
      <Layout title={title}>{element}</Layout>
    </ProtectedRoute>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={page("Dashboard", <Dashboard />)} />
          <Route path="/ask-ai" element={page("Ask School AI", <AskAI />)} />
          <Route path="/workspaces" element={page("Workspaces & Categories", <Workspaces />)} />
          <Route path="/documents" element={page("Documents", <Documents />)} />
          <Route path="/rag-audit" element={page("RAG Audit", <RagAudit />, ["school_admin", "principal", "super_admin"])} />
          <Route path="/model-config" element={page("Model Configuration", <ModelConfig />, ["school_admin", "principal", "super_admin"])} />
          <Route path="/teacher-tools" element={page("Teacher Tools", <TeacherTools />, ["teacher", "principal", "school_admin"])} />
          <Route path="/teacher-profile" element={page("Teacher Profile", <TeacherProfilePage />, ["teacher", "principal", "school_admin"])} />
          <Route path="/onboarding" element={page("Onboarding", <OnboardingPage />, ["teacher", "principal", "school_admin"])} />
          <Route path="/admin-tools" element={page("Admin Tools", <AdminTools />, ["school_admin", "principal"])} />
          <Route path="/timetable" element={page("Timetable", <Timetable />)} />
          <Route path="/analytics" element={page("Analytics", <Analytics />)} />
          <Route path="/upload-permissions" element={page("Upload Permissions", <UploadPermissions />, ["school_admin", "principal", "super_admin"])} />
          <Route path="/users" element={page("Users", <UsersPage />, ["super_admin", "school_admin"])} />
          <Route path="/audit-logs" element={page("Audit Logs", <AuditLogs />, ["school_admin", "principal", "super_admin"])} />
          <Route path="/backup" element={page("Backup", <Backup />, ["super_admin", "school_admin"])} />
          <Route path="/system-health" element={page("System Health", <SystemHealth />, ["super_admin", "school_admin"])} />
          <Route path="/settings" element={page("Settings", <Settings />, ["super_admin", "school_admin"])} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
