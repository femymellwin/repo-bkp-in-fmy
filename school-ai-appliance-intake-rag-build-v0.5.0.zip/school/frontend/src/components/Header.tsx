import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { api } from "../services/api";

const ROLE_LABELS: Record<string, string> = {
  super_admin: "Super Admin",
  school_admin: "School Admin",
  principal: "Principal",
  teacher: "Teacher",
  accounts_admin: "Accounts / Admin Staff",
};

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export default function Header({ title }: { title: string }) {
  const { user, logout } = useAuth();
  const [ollamaOnline, setOllamaOnline] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;
    api
      .get<{ ollama_status: string }>("/system/health")
      .then((data) => {
        if (!cancelled) setOllamaOnline(data.ollama_status === "online");
      })
      .catch(() => {
        if (!cancelled) setOllamaOnline(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!user) return null;

  return (
    <header className="topbar">
      <div className="topbar-title">{title}</div>
      <div className="topbar-right">
        <span className={`badge ${ollamaOnline ? "badge-green" : ollamaOnline === false ? "badge-red" : "badge-slate"}`}>
          <span className={`status-dot ${ollamaOnline ? "online" : "offline"}`} />
          {ollamaOnline === null ? "Checking system..." : ollamaOnline ? "System Online" : "Ollama Offline"}
        </span>
        <div className="topbar-user">
          <div className="topbar-user-avatar">{initials(user.full_name)}</div>
          <div className="topbar-user-meta">
            <div className="topbar-user-name">{user.full_name}</div>
            <div className="topbar-user-role">{ROLE_LABELS[user.role] || user.role}</div>
          </div>
        </div>
        <button className="logout-btn" onClick={logout}>
          Log out
        </button>
      </div>
    </header>
  );
}
