import type { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import type { Role } from "../types";
import { NAV_ITEMS } from "./Sidebar";

export default function ProtectedRoute({
  children,
  allowedRoles,
}: {
  children: ReactNode;
  allowedRoles?: Role[];
}) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="center-loading">Loading School AI Appliance...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return (
      <div className="page">
        <div className="alert alert-error">You do not have permission to view this page ({user.role} role).</div>
      </div>
    );
  }

  const hidden = new Set((user.menu_exclusions || "").split(",").map((x) => x.trim()).filter(Boolean));
  const current = NAV_ITEMS.find((item) => item.to === location.pathname);
  if (current && hidden.has(current.key)) {
    return (
      <div className="page">
        <div className="alert alert-error">This menu is disabled for your account.</div>
      </div>
    );
  }

  return <>{children}</>;
}
