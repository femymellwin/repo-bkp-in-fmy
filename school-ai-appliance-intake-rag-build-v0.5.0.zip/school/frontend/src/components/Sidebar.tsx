import { NavLink } from "react-router-dom";
import type { Role } from "../types";

interface NavItem {
  key: string;
  to: string;
  label: string;
  icon: string;
  roles?: Role[];
}

export const NAV_ITEMS: NavItem[] = [
  { key: "dashboard", to: "/", label: "Dashboard", icon: "⌂" },
  { key: "ask-ai", to: "/ask-ai", label: "Ask School AI", icon: "✦" },
  { key: "workspaces", to: "/workspaces", label: "Workspaces", icon: "▦" },
  { key: "documents", to: "/documents", label: "Documents", icon: "▣" },
  { key: "rag-audit", to: "/rag-audit", label: "RAG Audit", icon: "◎", roles: ["school_admin", "principal", "super_admin"] },
  { key: "model-config", to: "/model-config", label: "Model Config", icon: "◈", roles: ["school_admin", "principal", "super_admin"] },
  { key: "teacher-tools", to: "/teacher-tools", label: "Teacher Tools", icon: "✎", roles: ["teacher", "principal", "school_admin"] },
  { key: "teacher-profile", to: "/teacher-profile", label: "Teacher Profile", icon: "◉", roles: ["teacher", "principal", "school_admin"] },
  { key: "onboarding", to: "/onboarding", label: "Onboarding", icon: "◇", roles: ["teacher", "principal", "school_admin"] },
  { key: "admin-tools", to: "/admin-tools", label: "Admin Tools", icon: "▤", roles: ["school_admin", "principal"] },
  { key: "timetable", to: "/timetable", label: "Timetable", icon: "□" },
  { key: "analytics", to: "/analytics", label: "Analytics", icon: "▥" },
  { key: "upload-permissions", to: "/upload-permissions", label: "Upload Permissions", icon: "☑", roles: ["super_admin", "school_admin", "principal"] },
  { key: "users", to: "/users", label: "Users", icon: "◌", roles: ["super_admin", "school_admin"] },
  { key: "audit-logs", to: "/audit-logs", label: "Audit Logs", icon: "⌕", roles: ["school_admin", "principal", "super_admin"] },
  { key: "backup", to: "/backup", label: "Backup", icon: "▧", roles: ["super_admin", "school_admin"] },
  { key: "system-health", to: "/system-health", label: "System Health", icon: "⚙", roles: ["super_admin", "school_admin"] },
  { key: "settings", to: "/settings", label: "Settings", icon: "⚒", roles: ["super_admin", "school_admin"] },
];

function excludedSet(menuExclusions?: string) {
  return new Set((menuExclusions || "").split(",").map((x) => x.trim()).filter(Boolean));
}

export default function Sidebar({ role, schoolName, menuExclusions }: { role: Role; schoolName: string; menuExclusions?: string }) {
  const hidden = excludedSet(menuExclusions);
  const visibleItems = NAV_ITEMS.filter((item) => (!item.roles || item.roles.includes(role)) && !hidden.has(item.key));

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <img className="sidebar-brand-logo" src="/logo.png" alt="School AI" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
        <div className="sidebar-brand-text">
          <div className="sidebar-brand-title">{schoolName || "in(Take) IQ School"}</div>
          <div className="sidebar-brand-sub">Local RAG Appliance</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {visibleItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            className={({ isActive }) => `sidebar-link${isActive ? " active" : ""}`}
          >
            <span className="sidebar-icon">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">
        Workspace RAG control plane.
        <br />
        ChromaDB + local Ollama.
      </div>
    </aside>
  );
}
