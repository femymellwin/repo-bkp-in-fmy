import type { ReactNode } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { useAuth } from "../hooks/useAuth";

export default function Layout({ title, children }: { title: string; children: ReactNode }) {
  const { user } = useAuth();
  if (!user) return null;

  return (
    <div className="app-shell">
      <Sidebar role={user.role} schoolName="in(Take) IQ School AI" menuExclusions={user.menu_exclusions} />
      <div className="main-area">
        <Header title={title} />
        <main className="page">{children}</main>
      </div>
    </div>
  );
}
