export type Role =
  | "super_admin"
  | "school_admin"
  | "principal"
  | "teacher"
  | "accounts_admin";

export interface User {
  id: number;
  full_name: string;
  email: string;
  role: Role;
  is_active: boolean;
  menu_exclusions?: string;
  web_search_enabled?: boolean;
  created_at?: string;
  last_login_at?: string | null;
}

export interface Workspace {
  id: number;
  name: string;
  description: string;
  owner_user_id: number;
  owner_name: string;
  is_default: boolean;
  document_count: number;
  created_at: string;
  updated_at: string;
}

export interface DocumentCategory {
  id: number;
  name: string;
  display_name: string;
  description: string;
  is_active: boolean;
  document_count: number;
  created_at: string;
}

export interface DocumentItem {
  id: number;
  filename: string;
  uploaded_by: string;
  upload_date: string;
  document_type: string;
  access_role: string;
  file_size: number;
  workspace_id: number | null;
  workspace_name: string | null;
  doc_kind: string;
  subject: string;
  grade: string;
  academic_year: string;
  ingestion_status: "pending" | "processing" | "completed" | "failed";
  chunk_count: number;
  superadmin_permitted: boolean;
  chunk_size: number;
  chunk_overlap: number;
  chunking_strategy: string;
  extracted_text_chars: number;
  vector_db: string;
  vector_collection: string;
  embedding_provider: string;
  embedding_model: string;
  indexed_at: string | null;
  index_error: string;
  chunk_agent_name: string;
  chunk_agent_reason: string;
  retrieval_test_status: string;
  retrieval_test_score: number;
  retrieval_test_details: string;
}


export interface DocumentIndexTestItem {
  id: number;
  document_id: number;
  test_name: string;
  query: string;
  expected_document_id: number;
  top_document_id: number | null;
  passed: boolean;
  score: number;
  details: string;
  created_at: string;
}

export interface AskAIScope {
  workspace_id?: number | null;
  document_ids?: number[];
  categories?: string[];
  document_types?: string[];
}

export interface TokenUsage {
  model_name: string;
  embedding_model: string;
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  duration_ms: number;
}

export interface WebSource {
  title: string;
  url: string;
  snippet: string;
  provider: string;
}

export interface AskAIResponse {
  answer: string;
  sources: string[];
  web_sources: WebSource[];
  found_answer: boolean;
  ollama_available: boolean;
  scope_summary: string;
  usage: TokenUsage;
  web_search_used: boolean;
  web_search_status: string;
  project_id?: number | null;
  thread_id?: number | null;
}

export interface AIHistoryItem {
  id: number;
  tool: string;
  question: string;
  answer: string;
  sources: string[];
  web_sources?: WebSource[];
  found_answer: boolean;
  model_name: string;
  embedding_model: string;
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  duration_ms: number;
  scope_summary: string;
  used_web_search?: boolean;
  web_search_provider?: string;
  project_id?: number | null;
  thread_id?: number | null;
  created_at: string;
}


export interface ChatProject {
  id: number;
  name: string;
  description: string;
  color: string;
  is_default: boolean;
  thread_count: number;
  created_at: string;
  updated_at: string;
}

export interface ChatThread {
  id: number;
  project_id: number;
  title: string;
  scope_json: Record<string, unknown>;
  web_search_requested: boolean;
  message_count: number;
  created_at: string;
  updated_at: string;
}

export interface ChatMessageItem {
  id: number;
  thread_id: number;
  role: "user" | "assistant" | "system";
  content: string;
  sources: string[];
  web_sources: WebSource[];
  usage: Partial<TokenUsage>;
  scope_summary: string;
  used_web_search: boolean;
  created_at: string;
}

export interface WebSearchStatus {
  global_enabled: boolean;
  user_enabled: boolean;
  allowed: boolean;
  provider_configured?: boolean;
  provider: string;
  max_results: number;
  api_key_set: boolean;
  google_cx_set?: boolean;
  searxng_url_set?: boolean;
}

export interface ChatBootstrap {
  projects: ChatProject[];
  threads: ChatThread[];
  web_search: WebSearchStatus;
}

export interface ToolGenerationResponse {
  output: string;
  tool: string;
  ollama_available: boolean;
}

export interface TimetableEntry {
  id: number;
  class_name: string;
  subject: string;
  teacher_name: string;
  room: string;
  day_of_week: string;
  start_time: string;
  end_time: string;
}

export interface ConflictInfo {
  type: "teacher" | "room";
  message: string;
  entry_ids: number[];
}

export interface TimetableWithConflicts {
  entries: TimetableEntry[];
  conflicts: ConflictInfo[];
}

export interface AnalyticsPoint {
  label: string;
  value: number;
}

export interface ModelUsagePoint {
  label: string;
  query_count: number;
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  avg_duration_ms: number;
}

export interface RecentAIUsage {
  id: number;
  user_email: string;
  question: string;
  model_name: string;
  total_tokens: number;
  duration_ms: number;
  scope_summary: string;
  used_web_search?: boolean;
  web_sources?: WebSource[];
  created_at: string;
}

export interface Analytics {
  totals: Record<string, number>;
  model_usage: ModelUsagePoint[];
  ai_query_count_by_role: AnalyticsPoint[];
  most_used_ai_tools: AnalyticsPoint[];
  document_usage_count: AnalyticsPoint[];
  document_type_usage: AnalyticsPoint[];
  workspace_usage: AnalyticsPoint[];
  scope_usage: AnalyticsPoint[];
  recent_ai_queries: RecentAIUsage[];
}

export interface AuditLogEntry {
  id: number;
  actor_email: string;
  action: string;
  details: string;
  created_at: string;
}

export interface BackupRecord {
  id: number;
  filename: string;
  file_size: number;
  created_by: string;
  created_at: string;
}

export interface SystemHealth {
  cpu_percent: number;
  ram_percent: number;
  ram_used_gb: number;
  ram_total_gb: number;
  disk_percent: number;
  disk_used_gb: number;
  disk_total_gb: number;
  ollama_status: "online" | "offline";
  ollama_model: string;
  embedding_provider: string;
  embedding_model: string;
  embedding_status: "online" | "offline" | "local-process";
  database_status: "online" | "offline";
  vector_db_status: "online" | "offline";
  last_backup_date: string | null;
}

export interface SchoolSettings {
  school_name: string;
  academic_year: string;
  local_model_name: string;
  embedding_model_name: string;
  embedding_provider: string;
  backup_location: string;
  encryption_status: string;
  maintenance_mode: boolean;
  web_search_enabled: boolean;
  web_search_provider: string;
  web_search_max_results: number;
  web_search_timeout_seconds: number;
  web_search_api_key_set: boolean;
  web_search_google_cx: string;
  web_search_google_cx_set: boolean;
  web_search_searxng_url: string;
}

export interface ChunkConfig {
  chunk_size: number;
  chunk_overlap: number;
}

export interface ChunkingConfigResponse {
  strategy: string;
  default_chunk_size: number;
  default_chunk_overlap: number;
  by_file_type: Record<string, ChunkConfig>;
  explanation: string;
}

export interface UploadPolicyResponse {
  allowed_file_types: string[];
  max_file_size_mb: number;
  extractors: Record<string, string>;
}

export interface RagChunkAudit {
  id: number;
  document_id: number;
  filename: string;
  chunk_index: number;
  word_count: number;
  char_count: number;
  vector_id: string;
  preview: string;
}

export interface RagDocumentAudit {
  id: number;
  filename: string;
  document_type: string;
  access_role: string;
  uploaded_by: string;
  upload_date: string;
  ingestion_status: string;
  chunk_count: number;
  chunk_size: number;
  chunk_overlap: number;
  chunking_strategy: string;
  extracted_text_chars: number;
  vector_db: string;
  vector_collection: string;
  embedding_provider: string;
  embedding_model: string;
  indexed_at: string | null;
  index_error: string;
  chunk_agent_name: string;
  chunk_agent_reason: string;
  retrieval_test_status: string;
  retrieval_test_score: number;
}

export interface RagOverview {
  vector_db: Record<string, string | number>;
  chunking: ChunkingConfigResponse;
  upload_policy: UploadPolicyResponse;
  totals: Record<string, number>;
  ingestion_trend: { date: string; uploads: number }[];
  documents: RagDocumentAudit[];
  recent_chunks: RagChunkAudit[];
}

export interface ModelConfigResponse {
  ollama_base_url: string;
  ollama_status: "online" | "offline";
  local_model_name: string;
  local_model_available: boolean;
  embedding_provider: "sentence_transformers" | "ollama";
  embedding_model_name: string;
  embedding_model_available: boolean;
  available_ollama_models: string[];
  rag_top_k: number;
  notes: string[];
}

export interface PermissionMatrixResponse {
  roles: Role[];
  categories: string[];
  read_permissions: Record<Role, string[]>;
  upload_roles: Role[];
  menu_items: string[];
}

export interface TeacherProfile {
  id: number;
  user_id: number;
  full_name: string;
  email: string;
  role: Role;
  preferred_name: string;
  subjects: string;
  grades: string;
  bio: string;
  classroom_location: string;
  office_hours: string;
  extracurricular_roles: string;
  rag_notes: string;
  updated_at: string;
}

export interface OnboardingItem {
  id: number;
  title: string;
  category: string;
  owner_user_id: number | null;
  owner_name: string | null;
  status: string;
  due_date: string | null;
  notes: string;
  created_at: string;
  updated_at: string;
}
