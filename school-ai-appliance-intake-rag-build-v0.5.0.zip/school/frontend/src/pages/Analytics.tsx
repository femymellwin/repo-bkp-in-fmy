import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { Analytics, AnalyticsPoint, ModelUsagePoint } from "../types";

function StatCard({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return (
    <div className="card stat-card">
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value}</span>
      {hint && <span className="stat-hint">{hint}</span>}
    </div>
  );
}

function PointsTable({ title, points }: { title: string; points: AnalyticsPoint[] }) {
  return (
    <div className="card">
      <div className="card-title">{title}</div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Name</th><th>Count</th></tr>
          </thead>
          <tbody>
            {points.map((point) => (
              <tr key={point.label}>
                <td>{point.label}</td>
                <td>{point.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ModelUsageTable({ rows }: { rows: ModelUsagePoint[] }) {
  return (
    <div className="card">
      <div className="card-title">Model Usage & Tokens</div>
      <div className="card-subtitle">
        Tokens are captured from Ollama responses for Ask School AI. This helps you see which local model is being used and how heavy the workload is.
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Model</th>
              <th>Queries</th>
              <th>Prompt tokens</th>
              <th>Completion tokens</th>
              <th>Total tokens</th>
              <th>Avg duration</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.label}>
                <td><b>{row.label}</b></td>
                <td>{row.query_count}</td>
                <td>{row.prompt_tokens}</td>
                <td>{row.completion_tokens}</td>
                <td>{row.total_tokens}</td>
                <td>{row.avg_duration_ms ? `${(row.avg_duration_ms / 1000).toFixed(1)} s` : "0 s"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function AnalyticsPage() {
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get<Analytics>("/analytics")
      .then(setAnalytics)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load analytics."))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="center-loading"><span className="loading-spinner" /> Loading analytics...</div>;
  }

  if (error) {
    return <div className="alert alert-error">{error}</div>;
  }

  if (!analytics) return null;

  return (
    <div>
      <div className="card mb-16">
        <div className="card-title">AI Usage Analytics</div>
        <div className="card-subtitle">
          The old sample attendance analytics have been replaced with real RAG, model, token, workspace,
          and document usage metrics from this local appliance.
        </div>
      </div>

      <div className="grid grid-cols-4 mb-16">
        <StatCard label="AI Queries" value={analytics.totals.ai_queries || 0} hint="Persisted Ask AI requests" />
        <StatCard label="Total Tokens" value={analytics.totals.total_tokens || 0} hint="Prompt + completion" />
        <StatCard label="Documents" value={analytics.totals.documents || 0} hint={`${analytics.totals.completed_documents || 0} indexed`} />
        <StatCard label="Workspaces" value={analytics.totals.workspaces || 0} hint="Workspace-scoped uploads" />
        <StatCard label="Web Searches" value={analytics.totals.web_search_queries || 0} hint="Questions that used web snippets" />
      </div>

      <div className="grid grid-cols-2 mb-16">
        <ModelUsageTable rows={analytics.model_usage} />
        <div className="card">
          <div className="card-title">Recent AI Questions</div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>Question</th><th>User</th><th>Model</th><th>Tokens</th><th>Mode</th><th>Scope</th></tr>
              </thead>
              <tbody>
                {analytics.recent_ai_queries.map((item) => (
                  <tr key={item.id}>
                    <td>{item.question}</td>
                    <td>{item.user_email}</td>
                    <td>{item.model_name}</td>
                    <td>{item.total_tokens}</td>
                    <td>{item.used_web_search ? <span className="badge badge-green">web</span> : <span className="badge badge-slate">local</span>}</td>
                    <td>{item.scope_summary}</td>
                  </tr>
                ))}
                {analytics.recent_ai_queries.length === 0 && (
                  <tr><td colSpan={6} className="empty-state">No AI questions have been asked yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3">
        <PointsTable title="Queries by Role" points={analytics.ai_query_count_by_role} />
        <PointsTable title="Document Categories" points={analytics.document_usage_count} />
        <PointsTable title="Workspace Documents" points={analytics.workspace_usage} />
        <PointsTable title="File Types" points={analytics.document_type_usage} />
        <PointsTable title="AI Tools" points={analytics.most_used_ai_tools} />
        <PointsTable title="RAG Scopes Used" points={analytics.scope_usage} />
      </div>
    </div>
  );
}
