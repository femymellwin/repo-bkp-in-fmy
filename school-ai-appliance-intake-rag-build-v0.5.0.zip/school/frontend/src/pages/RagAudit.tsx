import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { RagOverview, ChunkConfig } from "../types";

const FILE_LABELS: Record<string, string> = { pdf: "PDF", docx: "Word", txt: "Text", csv: "CSV", xlsx: "Excel" };

export default function RagAudit() {
  const [data, setData] = useState<RagOverview | null>(null);
  const [chunks, setChunks] = useState<Record<string, ChunkConfig>>({});
  const [allowed, setAllowed] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    setError("");
    try {
      const res = await api.get<RagOverview>("/rag-audit/overview");
      setData(res);
      setChunks(res.chunking.by_file_type);
      setAllowed(res.upload_policy.allowed_file_types);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load RAG audit data.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function saveChunking() {
    setSaving(true); setError(""); setMessage("");
    try {
      await api.put("/rag-audit/chunking-config", { by_file_type: chunks });
      setMessage("Chunking configuration saved. New values apply to newly indexed documents.");
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to save chunking configuration.");
    } finally { setSaving(false); }
  }

  async function saveUploadPolicy() {
    setSaving(true); setError(""); setMessage("");
    try {
      await api.put("/rag-audit/upload-policy", { allowed_file_types: allowed });
      setMessage("Upload file policy saved.");
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to save upload policy.");
    } finally { setSaving(false); }
  }

  function updateChunk(fileType: string, key: keyof ChunkConfig, value: string) {
    setChunks((prev) => ({
      ...prev,
      [fileType]: { ...prev[fileType], [key]: Number(value) || 0 },
    }));
  }

  function toggleAllowed(fileType: string) {
    setAllowed((prev) => prev.includes(fileType) ? prev.filter((x) => x !== fileType) : [...prev, fileType]);
  }

  if (loading) return <div className="center-loading"><span className="loading-spinner" /> Loading RAG audit...</div>;
  if (error && !data) return <div className="alert alert-error">{error}</div>;
  if (!data) return null;

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      {message && <div className="alert alert-success">{message}</div>}

      <div className="dash-hero mb-16">
        <div className="dash-hero-grid" />
        <div className="dash-hero-body">
          <div className="hero-eyebrow">RAG transparency</div>
          <h1>Document ingestion, chunking, embedding, and vector indexing audit</h1>
          <p>{data.chunking.explanation}</p>
        </div>
      </div>

      <div className="grid grid-cols-4 mb-16">
        <div className="card stat-card"><span className="stat-label">Documents</span><span className="stat-value">{data.totals.documents}</span><span className="stat-hint">Uploaded files</span></div>
        <div className="card stat-card"><span className="stat-label">Chunks</span><span className="stat-value">{data.totals.chunks}</span><span className="stat-hint">Stored in SQLite + ChromaDB</span></div>
        <div className="card stat-card"><span className="stat-label">Avg chunk words</span><span className="stat-value">{data.totals.average_chunk_words || 0}</span><span className="stat-hint">Across indexed chunks</span></div>
        <div className="card stat-card"><span className="stat-label">Vector DB</span><span className="stat-value" style={{ fontSize: 18 }}>{data.vector_db.name}</span><span className="badge badge-indigo" style={{ width: "fit-content" }}>{data.vector_db.collection}</span></div>
      </div>

      <div className="grid grid-cols-2 mb-16">
        <div className="card">
          <div className="card-title">Chunking by file type</div>
          <div className="card-subtitle">These values are used when a document is indexed. Existing documents keep their recorded settings.</div>
          <table className="data-table compact-table">
            <thead><tr><th>File type</th><th>Chunk size</th><th>Overlap</th></tr></thead>
            <tbody>{Object.entries(chunks).map(([ft, cfg]) => (
              <tr key={ft}>
                <td><span className="badge badge-slate">{FILE_LABELS[ft] || ft}</span></td>
                <td><input type="number" min={100} max={4000} value={cfg.chunk_size} onChange={(e) => updateChunk(ft, "chunk_size", e.target.value)} /></td>
                <td><input type="number" min={0} max={cfg.chunk_size - 1} value={cfg.chunk_overlap} onChange={(e) => updateChunk(ft, "chunk_overlap", e.target.value)} /></td>
              </tr>
            ))}</tbody>
          </table>
          <button className="btn btn-primary" onClick={saveChunking} disabled={saving}>Save chunking</button>
        </div>

        <div className="card">
          <div className="card-title">Upload file restrictions</div>
          <div className="card-subtitle">Restrict document types before they reach extraction, encryption, chunking, and indexing.</div>
          <div className="tag-select-grid">
            {Object.keys(chunks).map((ft) => (
              <button key={ft} type="button" className={`tag-select ${allowed.includes(ft) ? "active" : ""}`} onClick={() => toggleAllowed(ft)}>{FILE_LABELS[ft] || ft}</button>
            ))}
          </div>
          <div className="mb-16">
            {Object.entries(data.upload_policy.extractors).map(([ft, extractor]) => <div className="metric-row" key={ft}><span>{FILE_LABELS[ft] || ft}</span><code>{extractor}</code></div>)}
          </div>
          <button className="btn btn-primary" onClick={saveUploadPolicy} disabled={saving || allowed.length === 0}>Save upload policy</button>
        </div>
      </div>

      <div className="card mb-16">
        <div className="card-title">Indexed documents</div>
        <div className="card-subtitle">Shows who indexed what, vector database, model, chunk settings, and errors.</div>
        <table className="data-table">
          <thead><tr><th>Document</th><th>Status</th><th>Chunks</th><th>Chunking agent</th><th>Quality</th><th>Embedding</th><th>Indexed</th><th>Error</th></tr></thead>
          <tbody>{data.documents.map((doc) => (
            <tr key={doc.id}>
              <td><b>{doc.filename}</b><br /><span className="stat-hint">{doc.document_type.toUpperCase()} · {doc.access_role}</span></td>
              <td><span className={`badge ${doc.ingestion_status === "completed" ? "badge-green" : doc.ingestion_status === "failed" ? "badge-red" : "badge-amber"}`}>{doc.ingestion_status}</span></td>
              <td>{doc.chunk_count}</td>
              <td>{doc.chunk_size} / {doc.chunk_overlap}<br /><span className="stat-hint">{doc.chunking_strategy}</span></td>
              <td>{doc.chunk_agent_name || "—"}<br /><span className="stat-hint">{doc.chunk_agent_reason ? doc.chunk_agent_reason.slice(0, 90) : "Configured fallback"}</span></td>
              <td><span className={`badge ${doc.retrieval_test_status === "passed" ? "badge-green" : doc.retrieval_test_status === "warning" ? "badge-amber" : doc.retrieval_test_status === "failed" ? "badge-red" : "badge-slate"}`}>{doc.retrieval_test_status || "not_run"}</span><br /><span className="stat-hint">{Math.round(doc.retrieval_test_score || 0)}%</span></td>
              <td>{doc.embedding_model || "—"}<br /><span className="stat-hint">{doc.embedding_provider}</span></td>
              <td>{doc.indexed_at ? new Date(doc.indexed_at).toLocaleString() : "—"}</td>
              <td>{doc.index_error ? <span className="badge badge-red">{doc.index_error.slice(0, 80)}</span> : "—"}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>

      <div className="card">
        <div className="card-title">Recent chunks</div>
        <div className="card-subtitle">Preview of what the AI actually searches. Use this to spot over-large chunks, tiny chunks, extraction failures, or sensitive text exposure.</div>
        <table className="data-table">
          <thead><tr><th>Source</th><th>Chunk</th><th>Words</th><th>Vector ID</th><th>Preview</th></tr></thead>
          <tbody>{data.recent_chunks.map((chunk) => (
            <tr key={chunk.id}>
              <td>{chunk.filename}</td><td>{chunk.chunk_index}</td><td>{chunk.word_count}</td><td><code>{chunk.vector_id}</code></td><td>{chunk.preview}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}
