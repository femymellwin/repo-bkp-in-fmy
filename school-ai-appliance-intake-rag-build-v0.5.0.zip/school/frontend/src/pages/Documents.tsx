import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { api, ApiError } from "../services/api";
import type { DocumentCategory, DocumentIndexTestItem, DocumentItem, Workspace } from "../types";

const STATUS_BADGE: Record<string, string> = {
  pending: "badge-slate",
  processing: "badge-amber",
  completed: "badge-green",
  failed: "badge-red",
};

const QUALITY_BADGE: Record<string, string> = {
  passed: "badge-green",
  warning: "badge-amber",
  failed: "badge-red",
  not_run: "badge-slate",
};

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function categoryLabel(categories: DocumentCategory[], key: string) {
  return categories.find((c) => c.name === key)?.display_name || key.replace(/_/g, " ");
}

export default function Documents() {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [categories, setCategories] = useState<DocumentCategory[]>([]);
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [docKinds, setDocKinds] = useState<string[]>(["general"]);
  const [allowedFileTypes, setAllowedFileTypes] = useState<string[]>(["pdf", "docx", "txt", "csv", "xlsx"]);
  const [serverCanUpload, setServerCanUpload] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");
  const [qualityTests, setQualityTests] = useState<DocumentIndexTestItem[] | null>(null);
  const [qualityDoc, setQualityDoc] = useState<DocumentItem | null>(null);

  const [file, setFile] = useState<File | null>(null);
  const [workspaceId, setWorkspaceId] = useState<number | "">("");
  const [category, setCategory] = useState("");
  const [docKind, setDocKind] = useState("general");
  const [subject, setSubject] = useState("");
  const [grade, setGrade] = useState("");
  const [academicYear, setAcademicYear] = useState("");
  const [superadminPermitted, setSuperadminPermitted] = useState(false);

  const [workspaceFilter, setWorkspaceFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [search, setSearch] = useState("");

  const canUpload = Boolean(user && serverCanUpload === true);
  const canGrantSuperadmin = user && (user.role === "school_admin" || user.role === "principal");

  async function loadData() {
    setLoading(true);
    setError("");
    try {
      const [docs, cats] = await Promise.all([
        api.get<DocumentItem[]>("/documents"),
        api.get<{
          categories: string[];
          category_items: DocumentCategory[];
          workspaces: Workspace[];
          doc_kinds: string[];
          allowed_file_types: string[];
          can_upload: boolean;
          max_file_size_mb: number;
        }>("/documents/categories"),
      ]);
      setDocuments(docs);
      setCategories(cats.category_items || []);
      setWorkspaces(cats.workspaces || []);
      setDocKinds(cats.doc_kinds || ["general"]);
      setAllowedFileTypes(cats.allowed_file_types || allowedFileTypes);
      setServerCanUpload(cats.can_upload);
      if (!category && cats.categories.length > 0) setCategory(cats.categories[0]);
      if (!workspaceId && cats.workspaces.length > 0) setWorkspaceId(cats.workspaces[0].id);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load documents.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const visibleDocuments = useMemo(() => {
    const q = search.trim().toLowerCase();
    return documents.filter((doc) => {
      const matchesWorkspace = workspaceFilter === "all" || String(doc.workspace_id || "") === workspaceFilter;
      const matchesCategory = categoryFilter === "all" || doc.access_role === categoryFilter;
      const matchesType = typeFilter === "all" || doc.document_type === typeFilter;
      const haystack = [doc.filename, doc.subject, doc.grade, doc.doc_kind, doc.workspace_name || "", doc.access_role].join(" ").toLowerCase();
      const matchesSearch = !q || haystack.includes(q);
      return matchesWorkspace && matchesCategory && matchesType && matchesSearch;
    });
  }, [documents, workspaceFilter, categoryFilter, typeFilter, search]);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !category || !workspaceId) return;
    setUploading(true);
    setError("");
    setMessage("");
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("workspace_id", String(workspaceId));
      formData.append("access_role", category);
      formData.append("doc_kind", docKind);
      formData.append("subject", subject);
      formData.append("grade", grade);
      formData.append("academic_year", academicYear);
      formData.append("superadmin_permitted", String(superadminPermitted));
      const res = await api.upload<{ message: string }>("/documents/upload", formData);
      setMessage(res.message);
      setFile(null);
      const fileInput = document.getElementById("file-input") as HTMLInputElement | null;
      if (fileInput) fileInput.value = "";
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(id: number, filename: string) {
    if (!confirm(`Delete "${filename}"? This cannot be undone.`)) return;
    try {
      await api.delete(`/documents/${id}`);
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Delete failed.");
    }
  }


  async function openQualityTests(doc: DocumentItem) {
    setError("");
    setQualityDoc(doc);
    try {
      const rows = await api.get<DocumentIndexTestItem[]>(`/documents/${doc.id}/quality-tests`);
      setQualityTests(rows);
    } catch (err) {
      setQualityTests([]);
      setError(err instanceof ApiError ? err.message : "Could not load quality tests.");
    }
  }

  async function handleDownload(id: number, filename: string) {
    setError("");
    try {
      await api.download(`/documents/${id}/download`, filename);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Download failed.");
    }
  }

  function canDeleteDoc(doc: DocumentItem) {
    if (!user) return false;
    if (user.role === "school_admin" || user.role === "principal") return true;
    return serverCanUpload === true && doc.uploaded_by === user.email;
  }

  const uniqueTypes = Array.from(new Set(documents.map((doc) => doc.document_type))).filter(Boolean).sort();

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      {message && <div className="alert alert-success">{message}</div>}

      {canUpload && (
        <div className="card mb-16">
          <div className="card-title">Upload from Workspace</div>
          <div className="card-subtitle">
            Pick a workspace first, then classify the document for RAG filtering. Files are encrypted at rest
            and indexed locally. Supported: {allowedFileTypes.map((x) => x.toUpperCase()).join(", ")}.
          </div>
          {workspaces.length === 0 && (
            <div className="alert alert-error">
              No workspace is available for your profile. Create one from <Link to="/workspaces">Workspaces & Categories</Link>.
            </div>
          )}
          <form onSubmit={handleUpload}>
            <div className="form-row">
              <div className="field">
                <label>Workspace</label>
                <select value={workspaceId} onChange={(e) => setWorkspaceId(Number(e.target.value))} required>
                  {workspaces.map((workspace) => (
                    <option key={workspace.id} value={workspace.id}>{workspace.name}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>File</label>
                <input
                  id="file-input"
                  type="file"
                  accept={allowedFileTypes.map((x) => `.${x}`).join(",")}
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  required
                />
              </div>
            </div>
            <div className="form-row">
              <div className="field">
                <label>Category</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)}>
                  {categories.filter((c) => c.is_active).map((c) => (
                    <option key={c.name} value={c.name}>{c.display_name}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Document kind</label>
                <select value={docKind} onChange={(e) => setDocKind(e.target.value)}>
                  {docKinds.map((kind) => <option key={kind} value={kind}>{kind.replace(/_/g, " ")}</option>)}
                </select>
              </div>
            </div>
            <div className="form-row">
              <div className="field">
                <label>Subject</label>
                <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Science, English, Mathematics" />
              </div>
              <div className="field">
                <label>Grade / Class</label>
                <input value={grade} onChange={(e) => setGrade(e.target.value)} placeholder="Grade 5A" />
              </div>
              <div className="field">
                <label>Academic year</label>
                <input value={academicYear} onChange={(e) => setAcademicYear(e.target.value)} placeholder="2025-2026" />
              </div>
            </div>
            {canGrantSuperadmin && (
              <div className="field" style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <input
                  type="checkbox"
                  id="superadmin-permit"
                  style={{ width: "auto" }}
                  checked={superadminPermitted}
                  onChange={(e) => setSuperadminPermitted(e.target.checked)}
                />
                <label htmlFor="superadmin-permit" style={{ margin: 0 }}>
                  Explicitly allow Super Admin to view this document
                </label>
              </div>
            )}
            <button className="btn btn-primary" type="submit" disabled={uploading || !file || !workspaceId}>
              {uploading ? <span className="loading-spinner" /> : "Upload, Encrypt & Index"}
            </button>
          </form>
        </div>
      )}

      <div className="card">
        <div className="card-title">Workspace Documents</div>
        <div className="card-subtitle">
          Use these filters to verify what Ask School AI can target by workspace, document, category, or file type.
        </div>
        <div className="form-row">
          <div className="field">
            <label>Search</label>
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="filename, subject, grade" />
          </div>
          <div className="field">
            <label>Workspace</label>
            <select value={workspaceFilter} onChange={(e) => setWorkspaceFilter(e.target.value)}>
              <option value="all">All accessible workspaces</option>
              {workspaces.map((workspace) => <option key={workspace.id} value={String(workspace.id)}>{workspace.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Category</label>
            <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
              <option value="all">All categories</option>
              {categories.map((c) => <option key={c.name} value={c.name}>{c.display_name}</option>)}
            </select>
          </div>
          <div className="field">
            <label>File type</label>
            <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              <option value="all">All types</option>
              {uniqueTypes.map((type) => <option key={type} value={type}>{type.toUpperCase()}</option>)}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="center-loading"><span className="loading-spinner" /> Loading documents...</div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Document</th>
                  <th>Workspace</th>
                  <th>Category</th>
                  <th>Class/Subject</th>
                  <th>Status</th>
                  <th>Chunks</th>
                  <th>Quality</th>
                  <th>Size</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {visibleDocuments.map((doc) => (
                  <tr key={doc.id}>
                    <td>
                      <b>{doc.filename}</b>
                      <div className="muted-small">
                        {doc.document_type.toUpperCase()} · {doc.doc_kind.replace(/_/g, " ")} · uploaded by {doc.uploaded_by}
                      </div>
                      {doc.index_error && <div className="muted-small" style={{ color: "var(--red-700)" }}>{doc.index_error}</div>}
                    </td>
                    <td>{doc.workspace_name || "Personal workspace"}</td>
                    <td>{categoryLabel(categories, doc.access_role)}</td>
                    <td>{[doc.grade, doc.subject, doc.academic_year].filter(Boolean).join(" · ") || "—"}</td>
                    <td><span className={`badge ${STATUS_BADGE[doc.ingestion_status] || "badge-slate"}`}>{doc.ingestion_status}</span></td>
                    <td>
                      {doc.chunk_count}
                      {doc.chunk_agent_name && <div className="muted-small">{doc.chunk_size}/{doc.chunk_overlap} · agent</div>}
                    </td>
                    <td>
                      <button className="quality-link" type="button" onClick={() => openQualityTests(doc)}>
                        <span className={`badge ${QUALITY_BADGE[doc.retrieval_test_status] || "badge-slate"}`}>{doc.retrieval_test_status || "not_run"}</span>
                        <small>{Math.round(doc.retrieval_test_score || 0)}%</small>
                      </button>
                    </td>
                    <td>{formatSize(doc.file_size)}</td>
                    <td>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <button className="btn btn-secondary" onClick={() => handleDownload(doc.id, doc.filename)}>Download</button>
                        {canDeleteDoc(doc) && <button className="btn btn-danger" onClick={() => handleDelete(doc.id, doc.filename)}>Delete</button>}
                      </div>
                    </td>
                  </tr>
                ))}
                {visibleDocuments.length === 0 && (
                  <tr><td colSpan={9} className="empty-state">No documents match these filters.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {qualityDoc && (
        <div className="modal-backdrop">
          <div className="modal-card quality-modal">
            <div className="card-title">Index quality tests</div>
            <div className="card-subtitle">
              {qualityDoc.filename} · {qualityDoc.chunk_agent_name || "Configured chunking"}
            </div>
            {qualityDoc.chunk_agent_reason && <div className="alert alert-info">Chunk agent decision: {qualityDoc.chunk_agent_reason}</div>}
            <div className="grid grid-cols-3 mb-16">
              <div className="card stat-card"><span className="stat-label">Status</span><span className={`badge ${QUALITY_BADGE[qualityDoc.retrieval_test_status] || "badge-slate"}`}>{qualityDoc.retrieval_test_status}</span></div>
              <div className="card stat-card"><span className="stat-label">Score</span><span className="stat-value">{Math.round(qualityDoc.retrieval_test_score || 0)}%</span></div>
              <div className="card stat-card"><span className="stat-label">Chunks</span><span className="stat-value">{qualityDoc.chunk_count}</span><span className="stat-hint">{qualityDoc.chunk_size}/{qualityDoc.chunk_overlap}</span></div>
            </div>
            <table className="data-table">
              <thead><tr><th>Test</th><th>Query</th><th>Result</th><th>Score</th><th>Details</th></tr></thead>
              <tbody>
                {(qualityTests || []).map((test) => (
                  <tr key={test.id}>
                    <td>{test.test_name.replace(/_/g, " ")}</td>
                    <td>{test.query}</td>
                    <td><span className={`badge ${test.passed ? "badge-green" : "badge-red"}`}>{test.passed ? "passed" : "failed"}</span></td>
                    <td>{Math.round(test.score || 0)}%</td>
                    <td>{test.details}</td>
                  </tr>
                ))}
                {qualityTests && qualityTests.length === 0 && <tr><td colSpan={5} className="empty-state">No quality tests have been recorded yet. Re-upload or re-index this document.</td></tr>}
                {!qualityTests && <tr><td colSpan={5} className="center-loading"><span className="loading-spinner" /> Loading tests...</td></tr>}
              </tbody>
            </table>
            <div className="modal-actions">
              <button className="btn btn-primary" onClick={() => { setQualityDoc(null); setQualityTests(null); }}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
