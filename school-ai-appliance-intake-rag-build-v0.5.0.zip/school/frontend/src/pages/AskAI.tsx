import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { api, ApiError } from "../services/api";
import type {
  AskAIResponse,
  AskAIScope,
  ChatBootstrap,
  ChatMessageItem,
  ChatProject,
  ChatThread,
  DocumentCategory,
  DocumentItem,
  WebSearchStatus,
  WebSource,
  Workspace,
} from "../types";

interface ChatMessage {
  role: "user" | "ai";
  text: string;
  sources?: string[];
  webSources?: WebSource[];
  isError?: boolean;
  usage?: Partial<AskAIResponse["usage"]>;
  scopeSummary?: string;
  usedWebSearch?: boolean;
}

function formatDuration(ms?: number) {
  if (!ms) return "0 ms";
  if (ms < 1000) return `${ms} ms`;
  return `${(ms / 1000).toFixed(1)} s`;
}

function categoryLabel(categories: DocumentCategory[], key: string) {
  return categories.find((c) => c.name === key)?.display_name || key.replace(/_/g, " ");
}

function toggleNumber(values: number[], value: number) {
  return values.includes(value) ? values.filter((x) => x !== value) : [...values, value];
}

function toggleString(values: string[], value: string) {
  return values.includes(value) ? values.filter((x) => x !== value) : [...values, value];
}

function toChatMessages(rows: ChatMessageItem[]): ChatMessage[] {
  return rows
    .filter((row) => row.role === "user" || row.role === "assistant")
    .map((row) => ({
      role: row.role === "assistant" ? "ai" : "user",
      text: row.content,
      sources: row.sources || [],
      webSources: row.web_sources || [],
      usage: row.usage || {},
      scopeSummary: row.scope_summary,
      usedWebSearch: row.used_web_search,
    }));
}

const emptyWebStatus: WebSearchStatus = {
  global_enabled: false,
  user_enabled: false,
  allowed: false,
  provider: "google",
  max_results: 5,
  api_key_set: false,
};

export default function AskAI() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [question, setQuestion] = useState("");
  const [showScopeModal, setShowScopeModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [bootLoading, setBootLoading] = useState(true);
  const [error, setError] = useState("");

  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [categories, setCategories] = useState<DocumentCategory[]>([]);

  const [projects, setProjects] = useState<ChatProject[]>([]);
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<number | null>(null);
  const [activeThreadId, setActiveThreadId] = useState<number | null>(null);
  const [webStatus, setWebStatus] = useState<WebSearchStatus>(emptyWebStatus);
  const [useWebSearch, setUseWebSearch] = useState(false);

  const [scopeWorkspaceId, setScopeWorkspaceId] = useState<number | "">("");
  const [scopeDocuments, setScopeDocuments] = useState<number[]>([]);
  const [scopeCategories, setScopeCategories] = useState<string[]>([]);
  const [scopeTypes, setScopeTypes] = useState<string[]>([]);
  const transcriptRef = useRef<HTMLDivElement | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  async function loadBootstrap() {
    setError("");
    try {
      const [boot, docs, catInfo] = await Promise.all([
        api.get<ChatBootstrap>("/chat/bootstrap"),
        api.get<DocumentItem[]>("/documents"),
        api.get<{ category_items: DocumentCategory[]; workspaces: Workspace[] }>("/documents/categories"),
      ]);
      setProjects(boot.projects || []);
      setThreads(boot.threads || []);
      setDocuments(docs || []);
      setCategories(catInfo.category_items || []);
      setWorkspaces(catInfo.workspaces || []);
      setWebStatus(boot.web_search || emptyWebStatus);
      setUseWebSearch(false);

      const firstProject = boot.projects?.[0];
      if (firstProject && !activeProjectId) setActiveProjectId(firstProject.id);
      const firstThread = boot.threads?.[0];
      if (firstThread && !activeThreadId) await openThread(firstThread.id, true, boot.threads || []);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load Ask AI context.");
    } finally {
      setBootLoading(false);
    }
  }

  async function refreshProjectsAndThreads(projectId?: number | null) {
    const [projectRows, threadRows] = await Promise.all([
      api.get<ChatProject[]>("/chat/projects"),
      api.get<ChatThread[]>(projectId ? `/chat/threads?project_id=${projectId}` : "/chat/threads"),
    ]);
    setProjects(projectRows);
    setThreads(threadRows);
  }

  async function loadThreadsForProject(projectId: number) {
    setActiveProjectId(projectId);
    setActiveThreadId(null);
    setMessages([]);
    try {
      setThreads(await api.get<ChatThread[]>(`/chat/threads?project_id=${projectId}`));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load project chats.");
    }
  }

  async function openThread(threadId: number, updateActive = true, knownThreads?: ChatThread[]) {
    try {
      const rows = await api.get<ChatMessageItem[]>(`/chat/threads/${threadId}/messages`);
      setMessages(toChatMessages(rows));
      if (updateActive) setActiveThreadId(threadId);
      const thread = (knownThreads || threads).find((t) => t.id === threadId);
      if (thread) setActiveProjectId(thread.project_id);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not open chat.");
    }
  }

  useEffect(() => {
    loadBootstrap();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, loading]);

  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0] || null;
  const activeThread = threads.find((t) => t.id === activeThreadId) || null;

  const documentTypes = useMemo(
    () => Array.from(new Set(documents.map((doc) => doc.document_type))).filter(Boolean).sort(),
    [documents]
  );

  const scopedDocumentOptions = useMemo(() => {
    return documents.filter((doc) => {
      const workspaceMatch = !scopeWorkspaceId || doc.workspace_id === Number(scopeWorkspaceId);
      const categoryMatch = scopeCategories.length === 0 || scopeCategories.includes(doc.access_role);
      const typeMatch = scopeTypes.length === 0 || scopeTypes.includes(doc.document_type);
      return workspaceMatch && categoryMatch && typeMatch;
    });
  }, [documents, scopeWorkspaceId, scopeCategories, scopeTypes]);

  const hasCustomScope = Boolean(scopeWorkspaceId || scopeDocuments.length || scopeCategories.length || scopeTypes.length);

  function clearScope() {
    setScopeWorkspaceId("");
    setScopeDocuments([]);
    setScopeCategories([]);
    setScopeTypes([]);
  }

  function buildScope(): AskAIScope | null {
    const scope: AskAIScope = {};
    if (scopeWorkspaceId) scope.workspace_id = Number(scopeWorkspaceId);
    if (scopeDocuments.length > 0) scope.document_ids = scopeDocuments;
    if (scopeCategories.length > 0) scope.categories = scopeCategories;
    if (scopeTypes.length > 0) scope.document_types = scopeTypes;
    return Object.keys(scope).length > 0 ? scope : null;
  }

  function scopeLabel() {
    if (!hasCustomScope) return "All documents";
    const parts: string[] = [];
    if (scopeWorkspaceId) parts.push("workspace");
    if (scopeCategories.length) parts.push(`${scopeCategories.length} categories`);
    if (scopeTypes.length) parts.push(`${scopeTypes.length} types`);
    if (scopeDocuments.length) parts.push(`${scopeDocuments.length} docs`);
    return parts.join(" · ");
  }

  function handleSubmit(e?: FormEvent) {
    e?.preventDefault();
    const trimmed = question.trim();
    if (!trimmed || loading) return;
    sendQuestion(trimmed, buildScope());
  }

  async function createProject() {
    const name = prompt("Project name", "New School AI Project");
    if (!name?.trim()) return;
    try {
      const project = await api.post<ChatProject>("/chat/projects", { name: name.trim(), description: "" });
      await refreshProjectsAndThreads(project.id);
      setActiveProjectId(project.id);
      setActiveThreadId(null);
      setMessages([]);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not create project.");
    }
  }

  async function createThread() {
    try {
      const thread = await api.post<ChatThread>("/chat/threads", {
        project_id: activeProject?.id || null,
        title: "New chat",
        scope_json: buildScope() || {},
        web_search_requested: useWebSearch,
      });
      setActiveThreadId(thread.id);
      setActiveProjectId(thread.project_id);
      setMessages([]);
      await refreshProjectsAndThreads(thread.project_id);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not create chat.");
    }
  }

  async function deleteThread(threadId: number) {
    if (!confirm("Delete this chat from your history?")) return;
    try {
      await api.delete(`/chat/threads/${threadId}`);
      if (activeThreadId === threadId) {
        setActiveThreadId(null);
        setMessages([]);
      }
      await refreshProjectsAndThreads(activeProjectId);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not delete chat.");
    }
  }

  async function sendQuestion(q: string, scope: AskAIScope | null) {
    const trimmed = q.trim();
    if (!trimmed || loading) return;

    setMessages((prev) => [...prev, { role: "user", text: trimmed }]);
    setQuestion("");
    setShowScopeModal(false);
    setLoading(true);
    setError("");

    try {
      const res = await api.post<AskAIResponse>("/ai/ask", {
        question: trimmed,
        scope,
        project_id: activeProject?.id || activeProjectId,
        thread_id: activeThreadId,
        use_web_search: useWebSearch && webStatus.allowed,
      });
      setMessages((prev) => [
        ...prev,
        {
          role: "ai",
          text: res.answer,
          sources: res.sources,
          webSources: res.web_sources,
          isError: !res.ollama_available,
          usage: res.usage,
          scopeSummary: res.scope_summary,
          usedWebSearch: res.web_search_used,
        },
      ]);
      if (res.thread_id) setActiveThreadId(res.thread_id);
      if (res.project_id) setActiveProjectId(res.project_id);
      await refreshProjectsAndThreads(res.project_id || activeProjectId);
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Something went wrong. Please try again.";
      setMessages((prev) => [...prev, { role: "ai", text: message, isError: true }]);
    } finally {
      setLoading(false);
    }
  }

  if (bootLoading) {
    return <div className="center-loading"><span className="loading-spinner" /> Loading chat workspace...</div>;
  }

  return (
    <div className="ask-chatgpt-shell ask-chatgpt-shell-v2">
      {error && <div className="alert alert-error chat-global-alert">{error}</div>}

      <aside className="chat-rail compact-chat-rail">
        <div className="chat-rail-brand compact-brand">
          <img src="/logo.png" alt="School AI" />
          <div>
            <b>School AI</b>
            <span>Projects</span>
          </div>
        </div>

        <button className="btn btn-primary full-width" onClick={createThread}>New chat</button>
        <button className="btn btn-secondary full-width" onClick={createProject}>New project</button>

        <div className="rail-section-title">Projects</div>
        <div className="project-list compact-project-list">
          {projects.map((project) => (
            <button
              key={project.id}
              className={`project-pill ${project.id === activeProjectId ? "active" : ""}`}
              onClick={() => loadThreadsForProject(project.id)}
            >
              <span>{project.name}</span>
              <small>{project.thread_count} chats</small>
            </button>
          ))}
        </div>

        <div className="rail-section-title">Chats</div>
        <div className="thread-list compact-thread-list">
          {threads.map((thread) => (
            <div key={thread.id} className={`thread-row ${thread.id === activeThreadId ? "active" : ""}`}>
              <button onClick={() => openThread(thread.id)} title={thread.title}>
                <span>{thread.title}</span>
                <small>{new Date(thread.updated_at).toLocaleString()}</small>
              </button>
              <button className="thread-delete" onClick={() => deleteThread(thread.id)} title="Delete chat">×</button>
            </div>
          ))}
          {threads.length === 0 && <div className="rail-empty">No chats yet.</div>}
        </div>
      </aside>

      <main className="chat-main chat-main-v2">
        <header className="chat-topbar chat-topbar-v2">
          <div>
            <div className="chat-title">{activeThread?.title || "New chat"}</div>
            <div className="chat-subtitle">
              {activeProject?.name || "Default project"} · local model · {scopeLabel()}{useWebSearch && webStatus.allowed ? ` · search: ${webStatus.provider}` : ""}
            </div>
          </div>
        </header>

        <section className="chat-transcript chat-transcript-v2" ref={transcriptRef}>
          {messages.length === 0 && (
            <div className="chat-empty-hero chat-empty-hero-v2">
              <img src="/logo.png" alt="School AI" />
              <h2>What do you want to know?</h2>
              <p>Ask your local school documents. Turn on Search only when the answer needs current web information.</p>
            </div>
          )}

          {messages.map((m, i) => (
            <article key={i} className={`message-row message-row-v2 ${m.role}`}>
              {m.role === "ai" && <div className="message-avatar message-avatar-v2"><img src="/logo.png" alt="AI" /></div>}
              <div className={`message-card message-card-v2 ${m.isError ? "error" : ""}`}>
                <div className="message-text">{m.text}</div>
                {m.role === "ai" && ((m.sources && m.sources.length > 0) || (m.webSources && m.webSources.length > 0) || m.usage || m.scopeSummary) && (
                  <details className="message-meta-details">
                    <summary>Sources and usage</summary>
                    {m.sources && m.sources.length > 0 && (
                      <div className="source-box compact-source-box"><b>Local sources</b><span>{m.sources.join(", ")}</span></div>
                    )}
                    {m.webSources && m.webSources.length > 0 && (
                      <div className="source-box compact-source-box web-source-box">
                        <b>Web sources</b>
                        {m.webSources.map((source, idx) => (
                          <a key={`${source.url}-${idx}`} href={source.url} target="_blank" rel="noreferrer">
                            {source.title || source.url} <small>({source.provider})</small>
                          </a>
                        ))}
                      </div>
                    )}
                    <div className="usage-strip chat-usage-strip">
                      {m.scopeSummary && <span>{m.scopeSummary}</span>}
                      {m.usedWebSearch && <span>Search used</span>}
                      {m.usage && <span>{m.usage.model_name || "local model"}</span>}
                      {m.usage && <span>{m.usage.total_tokens || 0} tokens</span>}
                      {m.usage && <span>{formatDuration(m.usage.duration_ms)}</span>}
                    </div>
                  </details>
                )}
              </div>
            </article>
          ))}
          {loading && (
            <article className="message-row message-row-v2 ai">
              <div className="message-avatar message-avatar-v2"><img src="/logo.png" alt="AI" /></div>
              <div className="message-card message-card-v2"><span className="loading-spinner" /> Thinking...</div>
            </article>
          )}
          <div ref={bottomRef} />
        </section>

        <form className="chat-composer chat-composer-v2" onSubmit={handleSubmit}>
          <textarea
            placeholder="Message School AI..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            disabled={loading}
            rows={1}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
          />
          <div className="composer-actions-row">
            <button
              type="button"
              className={`composer-chip ${useWebSearch && webStatus.allowed ? "active" : ""}`}
              disabled={!webStatus.allowed || loading}
              title={webStatus.allowed ? `Search using ${webStatus.provider}` : "Enable web search globally and for this user"}
              onClick={() => setUseWebSearch((v) => !v)}
            >
              Search
            </button>
            <button type="button" className={`composer-chip ${hasCustomScope ? "active" : ""}`} onClick={() => setShowScopeModal(true)} disabled={loading}>
              {hasCustomScope ? scopeLabel() : "Scope"}
            </button>
            <button className="composer-send" type="submit" disabled={loading || !question.trim()}>↑</button>
          </div>
        </form>
      </main>

      {showScopeModal && (
        <div className="modal-backdrop">
          <div className="modal-card scope-modal scope-modal-v2">
            <div className="card-title">Retrieval scope</div>
            <div className="card-subtitle">
              Optional. Leave empty for all accessible documents, or narrow this chat to a workspace, category, file type, or selected documents.
            </div>

            <div className="grid grid-cols-2 mb-16">
              <div className="field">
                <label>Workspace</label>
                <select value={scopeWorkspaceId} onChange={(e) => { setScopeWorkspaceId(e.target.value ? Number(e.target.value) : ""); setScopeDocuments([]); }}>
                  <option value="">All accessible workspaces</option>
                  {workspaces.map((workspace) => <option key={workspace.id} value={workspace.id}>{workspace.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Current project</label>
                <input value={activeProject?.name || "Default project"} readOnly />
              </div>
            </div>

            <div className="scope-section">
              <div className="scope-section-title">Categories</div>
              <div className="tag-select-grid compact">
                {categories.map((cat) => (
                  <button
                    key={cat.name}
                    type="button"
                    className={`tag-select ${scopeCategories.includes(cat.name) ? "selected" : ""}`}
                    onClick={() => { setScopeCategories(toggleString(scopeCategories, cat.name)); setScopeDocuments([]); }}
                  >
                    {cat.display_name}
                  </button>
                ))}
              </div>
            </div>

            <div className="scope-section">
              <div className="scope-section-title">File types</div>
              <div className="tag-select-grid compact">
                {documentTypes.map((type) => (
                  <button
                    key={type}
                    type="button"
                    className={`tag-select ${scopeTypes.includes(type) ? "selected" : ""}`}
                    onClick={() => { setScopeTypes(toggleString(scopeTypes, type)); setScopeDocuments([]); }}
                  >
                    {type.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="scope-section">
              <div className="scope-section-title">Specific documents</div>
              <div className="document-pick-list">
                {scopedDocumentOptions.map((doc) => (
                  <label key={doc.id} className="document-pick-item">
                    <input type="checkbox" checked={scopeDocuments.includes(doc.id)} onChange={() => setScopeDocuments(toggleNumber(scopeDocuments, doc.id))} />
                    <span>
                      <b>{doc.filename}</b>
                      <small>{doc.workspace_name || "Workspace"} / {categoryLabel(categories, doc.access_role)} / {doc.document_type.toUpperCase()} / {doc.ingestion_status}</small>
                    </span>
                  </label>
                ))}
                {scopedDocumentOptions.length === 0 && <div className="empty-state">No documents match these scope filters.</div>}
              </div>
            </div>

            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={clearScope}>Reset to all documents</button>
              <button type="button" className="btn btn-primary" onClick={() => setShowScopeModal(false)}>Apply</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
