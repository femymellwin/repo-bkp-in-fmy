import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { SystemHealth } from "../types";

function UsageBar({ percent, color }: { percent: number; color: string }) {
  return (
    <div style={{ background: "var(--slate-200)", borderRadius: 6, height: 8, overflow: "hidden", marginTop: 8 }}>
      <div style={{ width: `${Math.min(percent, 100)}%`, background: color, height: "100%" }} />
    </div>
  );
}

function StatusRow({ label, status, extra }: { label: string; status: "online" | "offline" | "local-process"; extra?: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid var(--slate-100)" }}>
      <div>
        <div style={{ fontWeight: 600, fontSize: 13.5 }}>{label}</div>
        {extra && <div style={{ fontSize: 11.5, color: "var(--slate-500)" }}>{extra}</div>}
      </div>
      <span className={`badge ${status === "online" || status === "local-process" ? "badge-green" : "badge-red"}`}>
        <span className={`status-dot ${status === "offline" ? "offline" : "online"}`} /> {status}
      </span>
    </div>
  );
}

export default function SystemHealthPage() {
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load() {
    try {
      const res = await api.get<SystemHealth>("/system/health");
      setHealth(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load system health.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 15000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="center-loading">
        <span className="loading-spinner" /> Checking system health...
      </div>
    );
  }

  if (error || !health) {
    return <div className="alert alert-error">{error || "No system health data available."}</div>;
  }

  return (
    <div>
      <div className="grid grid-cols-3 mb-16">
        <div className="card">
          <div className="card-title">CPU Usage</div>
          <div className="stat-value">{health.cpu_percent.toFixed(1)}%</div>
          <UsageBar percent={health.cpu_percent} color="#4f46e5" />
        </div>
        <div className="card">
          <div className="card-title">RAM Usage</div>
          <div className="stat-value">{health.ram_percent.toFixed(1)}%</div>
          <UsageBar percent={health.ram_percent} color="#22c55e" />
          <div className="stat-hint" style={{ marginTop: 6 }}>
            {health.ram_used_gb} GB / {health.ram_total_gb} GB
          </div>
        </div>
        <div className="card">
          <div className="card-title">Disk Usage</div>
          <div className="stat-value">{health.disk_percent.toFixed(1)}%</div>
          <UsageBar percent={health.disk_percent} color="#f59e0b" />
          <div className="stat-hint" style={{ marginTop: 6 }}>
            {health.disk_used_gb} GB / {health.disk_total_gb} GB
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Service Status</div>
        <StatusRow label="Ollama (Local AI Model)" status={health.ollama_status} extra={`Model: ${health.ollama_model}`} />
        <StatusRow label="Embedding Model" status={health.embedding_status} extra={`${health.embedding_provider}: ${health.embedding_model}`} />
        <StatusRow label="Database (SQLite)" status={health.database_status} />
        <StatusRow label="Vector Database (ChromaDB)" status={health.vector_db_status} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0" }}>
          <div style={{ fontWeight: 600, fontSize: 13.5 }}>Last Backup</div>
          <span className="badge badge-slate">
            {health.last_backup_date ? new Date(health.last_backup_date).toLocaleString() : "Never"}
          </span>
        </div>
      </div>
    </div>
  );
}
