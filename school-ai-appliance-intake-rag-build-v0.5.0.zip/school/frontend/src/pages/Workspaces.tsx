import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { api, ApiError } from "../services/api";
import type { DocumentCategory, Workspace } from "../types";

const CATEGORY_ADMIN_ROLES = new Set(["super_admin", "school_admin", "principal"]);

export default function Workspaces() {
  const { user } = useAuth();
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [categories, setCategories] = useState<DocumentCategory[]>([]);
  const [workspaceName, setWorkspaceName] = useState("");
  const [workspaceDescription, setWorkspaceDescription] = useState("");
  const [categoryName, setCategoryName] = useState("");
  const [categoryDescription, setCategoryDescription] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const canManageCategories = Boolean(user && CATEGORY_ADMIN_ROLES.has(user.role));

  async function loadData() {
    setLoading(true);
    setError("");
    try {
      const [workspaceRows, categoryRows] = await Promise.all([
        api.get<Workspace[]>("/workspaces"),
        api.get<DocumentCategory[]>("/document-categories"),
      ]);
      setWorkspaces(workspaceRows);
      setCategories(categoryRows);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load workspace settings.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  async function createWorkspace(e: React.FormEvent) {
    e.preventDefault();
    if (!workspaceName.trim()) return;
    setSaving(true);
    setError("");
    setMessage("");
    try {
      await api.post<Workspace>("/workspaces", { name: workspaceName, description: workspaceDescription });
      setWorkspaceName("");
      setWorkspaceDescription("");
      setMessage("Workspace created. You can now upload documents into it.");
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not create workspace.");
    } finally {
      setSaving(false);
    }
  }

  async function createCategory(e: React.FormEvent) {
    e.preventDefault();
    if (!categoryName.trim()) return;
    setSaving(true);
    setError("");
    setMessage("");
    try {
      await api.post<DocumentCategory>("/document-categories", {
        display_name: categoryName,
        description: categoryDescription,
      });
      setCategoryName("");
      setCategoryDescription("");
      setMessage("Document category created and made available for uploads.");
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not create category.");
    } finally {
      setSaving(false);
    }
  }

  async function toggleCategory(category: DocumentCategory) {
    setError("");
    setMessage("");
    try {
      await api.patch<DocumentCategory>(`/document-categories/${category.id}`, { is_active: !category.is_active });
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not update category.");
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      {message && <div className="alert alert-success">{message}</div>}

      <div className="grid grid-cols-2 mb-16">
        <div className="card">
          <div className="card-title">Personal Workspaces</div>
          <div className="card-subtitle">
            Uploads now start from a workspace. Use workspaces to separate class files, exam material,
            onboarding packs, or private teacher resources before asking RAG questions.
          </div>
          <form onSubmit={createWorkspace}>
            <div className="field">
              <label>Workspace name</label>
              <input value={workspaceName} onChange={(e) => setWorkspaceName(e.target.value)} placeholder="Grade 5 Science" />
            </div>
            <div className="field">
              <label>Description</label>
              <textarea value={workspaceDescription} onChange={(e) => setWorkspaceDescription(e.target.value)} placeholder="Optional notes about this workspace" />
            </div>
            <button className="btn btn-primary" disabled={saving || !workspaceName.trim()}>
              Create Workspace
            </button>
          </form>
        </div>

        <div className="card">
          <div className="card-title">Document Categories</div>
          <div className="card-subtitle">
            Categories define the school-level purpose of a file. They can later be used as RAG filters
            from the Ask page.
          </div>
          {canManageCategories ? (
            <form onSubmit={createCategory}>
              <div className="field">
                <label>Category display name</label>
                <input value={categoryName} onChange={(e) => setCategoryName(e.target.value)} placeholder="Exam Rubrics" />
              </div>
              <div className="field">
                <label>Description</label>
                <textarea value={categoryDescription} onChange={(e) => setCategoryDescription(e.target.value)} placeholder="What belongs in this category?" />
              </div>
              <button className="btn btn-primary" disabled={saving || !categoryName.trim()}>
                Create Category
              </button>
            </form>
          ) : (
            <div className="empty-state">Category creation is available to school administrators and principals.</div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2">
        <div className="card">
          <div className="card-title">Your Workspaces</div>
          {loading ? (
            <div className="center-loading"><span className="loading-spinner" /> Loading workspaces...</div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Owner</th>
                    <th>Documents</th>
                    <th>Default</th>
                  </tr>
                </thead>
                <tbody>
                  {workspaces.map((workspace) => (
                    <tr key={workspace.id}>
                      <td>
                        <b>{workspace.name}</b>
                        {workspace.description && <div className="muted-small">{workspace.description}</div>}
                      </td>
                      <td>{workspace.owner_name}</td>
                      <td>{workspace.document_count}</td>
                      <td>{workspace.is_default ? <span className="badge badge-green">Default</span> : <span className="badge badge-slate">Custom</span>}</td>
                    </tr>
                  ))}
                  {workspaces.length === 0 && (
                    <tr><td colSpan={4} className="empty-state">No workspaces yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="card">
          <div className="card-title">Available Categories</div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Key</th>
                  <th>Docs</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {categories.map((category) => (
                  <tr key={category.id}>
                    <td>
                      <b>{category.display_name}</b>
                      {category.description && <div className="muted-small">{category.description}</div>}
                    </td>
                    <td><code>{category.name}</code></td>
                    <td>{category.document_count}</td>
                    <td>
                      {canManageCategories ? (
                        <button className={`btn ${category.is_active ? "btn-secondary" : "btn-primary"}`} onClick={() => toggleCategory(category)}>
                          {category.is_active ? "Active" : "Reactivate"}
                        </button>
                      ) : (
                        <span className={`badge ${category.is_active ? "badge-green" : "badge-slate"}`}>{category.is_active ? "Active" : "Inactive"}</span>
                      )}
                    </td>
                  </tr>
                ))}
                {categories.length === 0 && (
                  <tr><td colSpan={4} className="empty-state">No categories configured.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
