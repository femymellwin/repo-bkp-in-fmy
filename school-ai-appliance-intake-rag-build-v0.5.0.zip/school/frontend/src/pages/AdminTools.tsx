import { useState } from "react";
import { api, ApiError } from "../services/api";
import type { ToolGenerationResponse } from "../types";

const TOOLS = [
  { key: "circular", label: "Circular Generator" },
  { key: "meeting_agenda", label: "Meeting Agenda Generator" },
  { key: "policy_summary", label: "Policy Summary Generator" },
  { key: "staff_announcement", label: "Staff Announcement Generator" },
  { key: "event_plan", label: "Event Plan Generator" },
];

export default function AdminTools() {
  const [tool, setTool] = useState(TOOLS[0].key);
  const [title, setTitle] = useState("");
  const [audience, setAudience] = useState("All Staff");
  const [keyPoints, setKeyPoints] = useState("");
  const [tone, setTone] = useState("formal");
  const [extraInstructions, setExtraInstructions] = useState("");

  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [ollamaWarning, setOllamaWarning] = useState(false);

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setLoading(true);
    setError("");
    setOutput("");
    setOllamaWarning(false);
    try {
      const res = await api.post<ToolGenerationResponse>("/admin-tools/generate", {
        tool,
        title,
        audience,
        key_points: keyPoints,
        tone,
        extra_instructions: extraInstructions,
      });
      setOutput(res.output);
      setOllamaWarning(!res.ollama_available);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Generation failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-2">
      <div className="card">
        <div className="card-title">Admin Tools</div>
        <div className="card-subtitle">Generate official school communications using the local AI model.</div>

        <div className="tag-select-grid">
          {TOOLS.map((t) => (
            <button
              key={t.key}
              type="button"
              className={`tag-select ${tool === t.key ? "active" : ""}`}
              onClick={() => setTool(t.key)}
            >
              {t.label}
            </button>
          ))}
        </div>

        <form onSubmit={handleGenerate}>
          <div className="field">
            <label>Title / Subject</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Term 2 Parent-Teacher Meeting" required />
          </div>
          <div className="form-row">
            <div className="field">
              <label>Audience</label>
              <input value={audience} onChange={(e) => setAudience(e.target.value)} placeholder="e.g. All Staff, Parents, Grade 5 Teachers" />
            </div>
            <div className="field">
              <label>Tone</label>
              <select value={tone} onChange={(e) => setTone(e.target.value)}>
                <option value="formal">Formal</option>
                <option value="friendly">Friendly</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>
          <div className="field">
            <label>Key Points</label>
            <textarea
              value={keyPoints}
              onChange={(e) => setKeyPoints(e.target.value)}
              placeholder="List the key points that must be included..."
            />
          </div>
          <div className="field">
            <label>Extra Instructions (optional)</label>
            <textarea
              value={extraInstructions}
              onChange={(e) => setExtraInstructions(e.target.value)}
              placeholder="Any additional formatting or content requirements..."
            />
          </div>
          <button className="btn btn-primary" type="submit" disabled={loading || !title.trim()}>
            {loading ? <span className="loading-spinner" /> : "Generate"}
          </button>
        </form>
      </div>

      <div className="card">
        <div className="card-title">Generated Output</div>
        {error && <div className="alert alert-error">{error}</div>}
        {ollamaWarning && <div className="alert alert-warning">Ollama was unreachable — see message below.</div>}
        {loading ? (
          <div className="center-loading">
            <span className="loading-spinner" /> Generating with local AI...
          </div>
        ) : output ? (
          <div className="pre-output">{output}</div>
        ) : (
          <div className="empty-state">Fill in the form and click Generate to see output here.</div>
        )}
      </div>
    </div>
  );
}
