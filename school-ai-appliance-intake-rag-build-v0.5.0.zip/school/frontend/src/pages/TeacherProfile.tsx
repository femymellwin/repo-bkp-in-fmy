import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { TeacherProfile } from "../types";

export default function TeacherProfilePage() {
  const [profile, setProfile] = useState<TeacherProfile | null>(null);
  const [form, setForm] = useState({ preferred_name: "", subjects: "", grades: "", bio: "", classroom_location: "", office_hours: "", extracurricular_roles: "", rag_notes: "" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get<TeacherProfile>("/teacher-profiles/me").then((p) => {
      setProfile(p);
      setForm({ preferred_name: p.preferred_name, subjects: p.subjects, grades: p.grades, bio: p.bio, classroom_location: p.classroom_location, office_hours: p.office_hours, extracurricular_roles: p.extracurricular_roles, rag_notes: p.rag_notes });
    }).catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load profile."))
      .finally(() => setLoading(false));
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault(); setSaving(true); setError(""); setMessage("");
    try {
      const updated = await api.put<TeacherProfile>("/teacher-profiles/me", form);
      setProfile(updated); setMessage("Teacher profile saved.");
    } catch (err) { setError(err instanceof ApiError ? err.message : "Failed to save profile."); }
    finally { setSaving(false); }
  }

  if (loading) return <div className="center-loading"><span className="loading-spinner" /> Loading teacher profile...</div>;

  return (
    <div className="grid grid-cols-2">
      <div className="card">
        <div className="card-title">Teacher Profile</div>
        <div className="card-subtitle">Teachers maintain their own profile. Admin-controlled common timetable remains separate and cannot be modified here.</div>
        {error && <div className="alert alert-error">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}
        <form onSubmit={save}>
          <div className="field"><label>Preferred name</label><input value={form.preferred_name} onChange={(e) => setForm({ ...form, preferred_name: e.target.value })} /></div>
          <div className="form-row"><div className="field"><label>Subjects</label><input value={form.subjects} onChange={(e) => setForm({ ...form, subjects: e.target.value })} placeholder="Science, Maths" /></div><div className="field"><label>Grades</label><input value={form.grades} onChange={(e) => setForm({ ...form, grades: e.target.value })} placeholder="Grade 5, Grade 6" /></div></div>
          <div className="field"><label>Bio</label><textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></div>
          <div className="form-row"><div className="field"><label>Classroom / room</label><input value={form.classroom_location} onChange={(e) => setForm({ ...form, classroom_location: e.target.value })} /></div><div className="field"><label>Office hours</label><input value={form.office_hours} onChange={(e) => setForm({ ...form, office_hours: e.target.value })} /></div></div>
          <div className="field"><label>Extracurricular roles</label><textarea value={form.extracurricular_roles} onChange={(e) => setForm({ ...form, extracurricular_roles: e.target.value })} placeholder="Robotics club, football team, debate club" /></div>
          <div className="field"><label>RAG notes / class context</label><textarea value={form.rag_notes} onChange={(e) => setForm({ ...form, rag_notes: e.target.value })} placeholder="Information useful for lesson generation and local school context" /></div>
          <button className="btn btn-primary" disabled={saving}>{saving ? <span className="loading-spinner" /> : "Save profile"}</button>
        </form>
      </div>
      <div className="card">
        <div className="card-title">Profile preview</div>
        {profile && <div className="pre-output">{JSON.stringify({ ...profile, ...form }, null, 2)}</div>}
      </div>
    </div>
  );
}
