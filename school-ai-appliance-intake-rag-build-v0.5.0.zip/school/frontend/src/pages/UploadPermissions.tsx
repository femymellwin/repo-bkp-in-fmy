import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { PermissionMatrixResponse, Role } from "../types";

const ROLE_LABELS: Record<Role, string> = {
  super_admin: "Super Admin",
  school_admin: "School Admin",
  principal: "Principal",
  teacher: "Teacher",
  accounts_admin: "Accounts / Admin Staff",
};

export default function UploadPermissions() {
  const [data, setData] = useState<PermissionMatrixResponse | null>(null);
  const [uploadRoles, setUploadRoles] = useState<Role[]>([]);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const res = await api.get<PermissionMatrixResponse>("/permissions");
      setData(res);
      setUploadRoles(res.upload_roles);
    } catch (err) { setError(err instanceof ApiError ? err.message : "Failed to load permissions."); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, []);

  function toggleRole(role: Role) {
    setUploadRoles((prev) => prev.includes(role) ? prev.filter((r) => r !== role) : [...prev, role]);
  }

  async function save() {
    setError(""); setMessage("");
    try {
      const res = await api.put<PermissionMatrixResponse>("/permissions/upload-roles", { upload_roles: uploadRoles });
      setData(res); setUploadRoles(res.upload_roles); setMessage("Upload permissions saved.");
    } catch (err) { setError(err instanceof ApiError ? err.message : "Failed to save permissions."); }
  }

  if (loading) return <div className="center-loading"><span className="loading-spinner" /> Loading permissions...</div>;
  if (error && !data) return <div className="alert alert-error">{error}</div>;
  if (!data) return null;

  return (
    <div className="grid grid-cols-2">
      <div className="card">
        <div className="card-title">Who can upload documents?</div>
        <div className="card-subtitle">This is enforced server-side before encryption, extraction, chunking, and ChromaDB indexing.</div>
        {error && <div className="alert alert-error">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}
        <div className="tag-select-grid">
          {data.roles.map((role) => (
            <button type="button" key={role} className={`tag-select ${uploadRoles.includes(role) ? "active" : ""}`} onClick={() => toggleRole(role)}>
              {ROLE_LABELS[role] || role}
            </button>
          ))}
        </div>
        <button className="btn btn-primary" onClick={save}>Save upload roles</button>
      </div>

      <div className="card">
        <div className="card-title">Read / RAG category matrix</div>
        <div className="card-subtitle">RAG retrieval is filtered at the vector query layer based on these categories.</div>
        <table className="data-table compact-table">
          <thead><tr><th>Role</th><th>Readable categories</th></tr></thead>
          <tbody>{data.roles.map((role) => (
            <tr key={role}><td><b>{ROLE_LABELS[role] || role}</b></td><td>{(data.read_permissions[role] || []).length ? (data.read_permissions[role] || []).join(", ") : "No default document access"}</td></tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}
