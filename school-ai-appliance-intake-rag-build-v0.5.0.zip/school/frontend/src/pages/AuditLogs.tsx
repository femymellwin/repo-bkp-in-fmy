import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { AuditLogEntry } from "../types";

const ACTION_BADGES: Record<string, string> = {
  login: "badge-green",
  failed_login: "badge-red",
  document_upload: "badge-indigo",
  document_deletion: "badge-amber",
  ai_query: "badge-indigo",
  document_access: "badge-slate",
  user_creation: "badge-green",
  role_change: "badge-amber",
  backup_created: "badge-green",
  settings_updated: "badge-slate",
};

const ACTION_LABELS: Record<string, string> = {
  login: "Login",
  failed_login: "Failed Login",
  document_upload: "Document Upload",
  document_deletion: "Document Deletion",
  ai_query: "AI Query",
  document_access: "Document Access",
  user_creation: "User Creation",
  role_change: "Role Change",
  backup_created: "Backup Created",
  settings_updated: "Settings Updated",
};

export default function AuditLogs() {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    api
      .get<AuditLogEntry[]>("/audit-logs")
      .then(setLogs)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load audit logs."))
      .finally(() => setLoading(false));
  }, []);

  const actions = ["all", ...Array.from(new Set(logs.map((l) => l.action)))];
  const filteredLogs = filter === "all" ? logs : logs.filter((l) => l.action === filter);

  return (
    <div className="card">
      <div className="card-title">Audit Logs</div>
      <div className="card-subtitle">A record of important system actions, visible to School Admin, Principal, and Super Admin.</div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="tag-select-grid">
        {actions.map((a) => (
          <button key={a} className={`tag-select ${filter === a ? "active" : ""}`} onClick={() => setFilter(a)}>
            {a === "all" ? "All" : ACTION_LABELS[a] || a}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="center-loading">
          <span className="loading-spinner" /> Loading audit logs...
        </div>
      ) : filteredLogs.length === 0 ? (
        <div className="empty-state">No audit log entries found.</div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Actor</th>
              <th>Action</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {filteredLogs.map((log) => (
              <tr key={log.id}>
                <td>{new Date(log.created_at).toLocaleString()}</td>
                <td>{log.actor_email}</td>
                <td>
                  <span className={`badge ${ACTION_BADGES[log.action] || "badge-slate"}`}>
                    {ACTION_LABELS[log.action] || log.action}
                  </span>
                </td>
                <td>{log.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
