import { useState } from "react";
import { api, ApiError } from "../services/api";
import type { ToolGenerationResponse } from "../types";

const TOOLS = [
  { key: "lesson_plan", label: "Lesson Plan Generator" },
  { key: "worksheet", label: "Worksheet Generator" },
  { key: "quiz", label: "Quiz Generator" },
  { key: "parent_message", label: "Parent Message Generator" },
  { key: "feedback_comment", label: "Student Feedback Comment" },
];

export default function TeacherTools() {
  const [tool, setTool] = useState(TOOLS[0].key);
  const [grade, setGrade] = useState("Grade 5");
  const [subject, setSubject] = useState("Science");
  const [topic, setTopic] = useState("");
  const [duration, setDuration] = useState("45 minutes");
  const [difficulty, setDifficulty] = useState("medium");
  const [extraInstructions, setExtraInstructions] = useState("");

  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [ollamaWarning, setOllamaWarning] = useState(false);

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    if (!topic.trim()) return;
    setLoading(true);
    setError("");
    setOutput("");
    setOllamaWarning(false);
    try {
      const res = await api.post<ToolGenerationResponse>("/teacher-tools/generate", {
        tool,
        grade,
        subject,
        topic,
        duration,
        difficulty,
        extra_instructions: extraInstructions,
      });
      setOutput(res.output);
      setOllamaWarning(!res.ollama_available);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Generation failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-2">
      <div className="card">
        <div className="card-title">Teacher Tools</div>
        <div className="card-subtitle">Generate classroom-ready materials using the local AI model.</div>

        <div className="tag-select-grid">
          {TOOLS.map((t) => (
            <button
              key={t.key}
              type="button"
              className={`tag-select ${tool === t.key ? "active" : ""}`}
              onClick={() => setTool(t.key)}
            >
              {t.label}
            </button>
          ))}
        </div>

        <form onSubmit={handleGenerate}>
          <div className="form-row">
            <div className="field">
              <label>Grade</label>
              <input value={grade} onChange={(e) => setGrade(e.target.value)} placeholder="e.g. Grade 5" required />
            </div>
            <div className="field">
              <label>Subject</label>
              <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="e.g. Science" required />
            </div>
          </div>
          <div className="field">
            <label>Topic</label>
            <input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="e.g. Photosynthesis" required />
          </div>
          <div className="form-row">
            <div className="field">
              <label>Duration</label>
              <input value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="e.g. 45 minutes" />
            </div>
            <div className="field">
              <label>Difficulty</label>
              <select value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
          </div>
          <div className="field">
            <label>Extra Instructions (optional)</label>
            <textarea
              value={extraInstructions}
              onChange={(e) => setExtraInstructions(e.target.value)}
              placeholder="Any specific requirements, learning style, or focus areas..."
            />
          </div>
          <button className="btn btn-primary" type="submit" disabled={loading || !topic.trim()}>
            {loading ? <span className="loading-spinner" /> : "Generate"}
          </button>
        </form>
      </div>

      <div className="card">
        <div className="card-title">Generated Output</div>
        {error && <div className="alert alert-error">{error}</div>}
        {ollamaWarning && <div className="alert alert-warning">Ollama was unreachable — see message below.</div>}
        {loading ? (
          <div className="center-loading">
            <span className="loading-spinner" /> Generating with local AI...
          </div>
        ) : output ? (
          <div className="pre-output">{output}</div>
        ) : (
          <div className="empty-state">Fill in the form and click Generate to see output here.</div>
        )}
      </div>
    </div>
  );
}
