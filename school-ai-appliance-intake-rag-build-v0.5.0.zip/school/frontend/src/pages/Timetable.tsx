import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { api, ApiError } from "../services/api";
import type { TimetableWithConflicts, TimetableEntry, ConflictInfo } from "../types";

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const MANAGE_ROLES = ["school_admin", "principal"];

export default function Timetable() {
  const { user } = useAuth();
  const [data, setData] = useState<TimetableWithConflicts>({ entries: [], conflicts: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [className, setClassName] = useState("");
  const [subject, setSubject] = useState("");
  const [teacherName, setTeacherName] = useState("");
  const [room, setRoom] = useState("");
  const [day, setDay] = useState(DAYS[0]);
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("09:45");
  const [submitting, setSubmitting] = useState(false);

  const canManage = user && MANAGE_ROLES.includes(user.role);

  async function loadData() {
    setLoading(true);
    setError("");
    try {
      const res = await api.get<TimetableWithConflicts>("/timetable");
      setData(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load timetable.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  function conflictIdsFor(day_of_week: string): Set<number> {
    const ids = new Set<number>();
    data.conflicts.forEach((c) => c.entry_ids.forEach((id) => {
      const entry = data.entries.find((e) => e.id === id);
      if (entry && entry.day_of_week === day_of_week) ids.add(id);
    }));
    return ids;
  }

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await api.post("/timetable", {
        class_name: className,
        subject,
        teacher_name: teacherName,
        room,
        day_of_week: day,
        start_time: startTime,
        end_time: endTime,
      });
      setClassName("");
      setSubject("");
      setTeacherName("");
      setRoom("");
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to add timetable entry.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this timetable entry?")) return;
    try {
      await api.delete(`/timetable/${id}`);
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to delete entry.");
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}

      {data.conflicts.length > 0 && (
        <div className="alert alert-warning">
          <b>{data.conflicts.length} scheduling conflict(s) detected:</b>
          <ul style={{ margin: "6px 0 0", paddingLeft: 18 }}>
            {data.conflicts.map((c: ConflictInfo, i: number) => (
              <li key={i}>{c.message}</li>
            ))}
          </ul>
        </div>
      )}

      {canManage && (
        <div className="card mb-16">
          <div className="card-title">Add Timetable Entry</div>
          <form onSubmit={handleAdd}>
            <div className="form-row">
              <div className="field">
                <label>Class</label>
                <input value={className} onChange={(e) => setClassName(e.target.value)} placeholder="e.g. Grade 5A" required />
              </div>
              <div className="field">
                <label>Subject</label>
                <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="e.g. Mathematics" required />
              </div>
            </div>
            <div className="form-row">
              <div className="field">
                <label>Teacher</label>
                <input value={teacherName} onChange={(e) => setTeacherName(e.target.value)} placeholder="e.g. Ms. Fatima Al Hashimi" required />
              </div>
              <div className="field">
                <label>Room</label>
                <input value={room} onChange={(e) => setRoom(e.target.value)} placeholder="e.g. Room 101" required />
              </div>
            </div>
            <div className="form-row">
              <div className="field">
                <label>Day</label>
                <select value={day} onChange={(e) => setDay(e.target.value)}>
                  {DAYS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Start / End Time</label>
                <div style={{ display: "flex", gap: 8 }}>
                  <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} required />
                  <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} required />
                </div>
              </div>
            </div>
            <button className="btn btn-primary" type="submit" disabled={submitting}>
              {submitting ? <span className="loading-spinner" /> : "Add Entry"}
            </button>
          </form>
        </div>
      )}

      <div className="card">
        <div className="card-title">Weekly Timetable</div>
        {loading ? (
          <div className="center-loading">
            <span className="loading-spinner" /> Loading timetable...
          </div>
        ) : data.entries.length === 0 ? (
          <div className="empty-state">No timetable entries yet.</div>
        ) : (
          <div className="timetable-grid">
            <div className="timetable-header-cell">Day</div>
            {DAYS.map((d) => (
              <div className="timetable-header-cell" key={d}>{d}</div>
            ))}
            <div className="timetable-cell" style={{ background: "var(--slate-50)" }} />
            {DAYS.map((d) => {
              const conflictIds = conflictIdsFor(d);
              const dayEntries = data.entries
                .filter((e) => e.day_of_week === d)
                .sort((a, b) => a.start_time.localeCompare(b.start_time));
              return (
                <div className="timetable-cell" key={d}>
                  {dayEntries.length === 0 && <span style={{ color: "var(--slate-300)" }}>—</span>}
                  {dayEntries.map((entry: TimetableEntry) => (
                    <div
                      key={entry.id}
                      className={`timetable-entry ${conflictIds.has(entry.id) ? "conflict" : ""}`}
                      title={canManage ? "Click to delete" : ""}
                      onClick={() => canManage && handleDelete(entry.id)}
                      style={{ cursor: canManage ? "pointer" : "default" }}
                    >
                      <b>{entry.start_time}-{entry.end_time}</b>
                      <br />
                      {entry.class_name} · {entry.subject}
                      <br />
                      {entry.teacher_name} · {entry.room}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
