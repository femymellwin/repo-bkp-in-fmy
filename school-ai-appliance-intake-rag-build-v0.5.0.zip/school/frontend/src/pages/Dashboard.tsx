import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { api } from "../services/api";
import type { SystemHealth, DocumentItem, SchoolSettings } from "../types";

const ROLE_LABELS: Record<string, string> = {
  super_admin: "Super Admin",
  school_admin: "School Admin",
  principal: "Principal",
  teacher: "Teacher",
  accounts_admin: "Accounts / Admin Staff",
};

const ROLE_WELCOME: Record<string, string> = {
  super_admin: "Manage system-wide settings, users, and infrastructure health.",
  school_admin: "Oversee documents, staff, timetables, and school operations.",
  principal: "Full visibility into school documents, analytics, and audit trail.",
  teacher: "Generate lesson materials and ask the School AI about your curriculum.",
  accounts_admin: "Access finance documents and circulars, and ask School AI questions.",
};

export default function Dashboard() {
  const { user } = useAuth();
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [settings, setSettings] = useState<SchoolSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.allSettled([
      api.get<SystemHealth>("/system/health"),
      api.get<DocumentItem[]>("/documents"),
      api.get<SchoolSettings>("/settings"),
    ]).then(([healthRes, docsRes, settingsRes]) => {
      if (healthRes.status === "fulfilled") setHealth(healthRes.value);
      if (docsRes.status === "fulfilled") setDocuments(docsRes.value);
      if (settingsRes.status === "fulfilled") setSettings(settingsRes.value);
      setLoading(false);
    });
  }, []);

  if (!user) return null;

  return (
    <div>
      <div className="card mb-16">
        <div className="card-title">Welcome back, {user.full_name.split(" ")[0]}</div>
        <div className="card-subtitle">
          {ROLE_LABELS[user.role]} · {settings?.school_name || "Private School"} · {settings?.academic_year || ""}
        </div>
        <p style={{ fontSize: 13.5, color: "var(--slate-600)", margin: 0 }}>
          {ROLE_WELCOME[user.role]}
        </p>
      </div>

      {loading ? (
        <div className="center-loading">
          <span className="loading-spinner" /> Loading dashboard...
        </div>
      ) : (
        <>
          <div className="grid grid-cols-4 mb-16">
            <div className="card stat-card">
              <span className="stat-label">Documents Accessible</span>
              <span className="stat-value">{documents.length}</span>
              <span className="stat-hint">Across all your allowed categories</span>
            </div>
            <div className="card stat-card">
              <span className="stat-label">Local AI Model</span>
              <span className="stat-value" style={{ fontSize: 18 }}>
                {health?.ollama_model || "—"}
              </span>
              <span className={`badge ${health?.ollama_status === "online" ? "badge-green" : "badge-red"}`} style={{ marginTop: 4, width: "fit-content" }}>
                <span className={`status-dot ${health?.ollama_status === "online" ? "online" : "offline"}`} /> {health?.ollama_status || "unknown"}
              </span>
            </div>
            <div className="card stat-card">
              <span className="stat-label">Database</span>
              <span className={`badge ${health?.database_status === "online" ? "badge-green" : "badge-red"}`} style={{ width: "fit-content", marginTop: 4 }}>
                <span className={`status-dot ${health?.database_status === "online" ? "online" : "offline"}`} /> {health?.database_status || "unknown"}
              </span>
              <span className="stat-hint">SQLite local database</span>
            </div>
            <div className="card stat-card">
              <span className="stat-label">Last Backup</span>
              <span className="stat-value" style={{ fontSize: 15 }}>
                {health?.last_backup_date ? new Date(health.last_backup_date).toLocaleDateString() : "Never"}
              </span>
              <span className="stat-hint">Encrypted, local ZIP</span>
            </div>
          </div>

          <div className="grid grid-cols-3">
            <Link to="/ask-ai" className="card" style={{ textDecoration: "none" }}>
              <div className="card-title">✨ Ask School AI</div>
              <div className="card-subtitle">Query your uploaded documents with local RAG.</div>
            </Link>
            <Link to="/documents" className="card" style={{ textDecoration: "none" }}>
              <div className="card-title">📁 Documents</div>
              <div className="card-subtitle">Upload and manage encrypted school documents.</div>
            </Link>
            {(user.role === "teacher" || user.role === "principal" || user.role === "school_admin") && (
              <Link to="/teacher-tools" className="card" style={{ textDecoration: "none" }}>
                <div className="card-title">🎓 Teacher Tools</div>
                <div className="card-subtitle">Generate lesson plans, quizzes, and worksheets.</div>
              </Link>
            )}
          </div>
        </>
      )}
    </div>
  );
}
