import { useEffect, useState, type FormEvent } from "react";
import { api, ApiError } from "../services/api";
import type { SchoolSettings } from "../types";

export default function Settings() {
  const [settings, setSettings] = useState<SchoolSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const [schoolName, setSchoolName] = useState("");
  const [academicYear, setAcademicYear] = useState("");
  const [localModelName, setLocalModelName] = useState("");
  const [embeddingModelName, setEmbeddingModelName] = useState("");
  const [embeddingProvider, setEmbeddingProvider] = useState("ollama");
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [webSearchEnabled, setWebSearchEnabled] = useState(false);
  const [webSearchProvider, setWebSearchProvider] = useState("google");
  const [webSearchMaxResults, setWebSearchMaxResults] = useState(5);
  const [webSearchTimeout, setWebSearchTimeout] = useState(8);
  const [webSearchApiKey, setWebSearchApiKey] = useState("");
  const [webSearchGoogleCx, setWebSearchGoogleCx] = useState("");
  const [webSearchSearxngUrl, setWebSearchSearxngUrl] = useState("");

  useEffect(() => {
    api
      .get<SchoolSettings>("/settings")
      .then((s) => {
        setSettings(s);
        setSchoolName(s.school_name);
        setAcademicYear(s.academic_year);
        setLocalModelName(s.local_model_name);
        setEmbeddingModelName(s.embedding_model_name);
        setEmbeddingProvider(s.embedding_provider || "ollama");
        setMaintenanceMode(s.maintenance_mode);
        setWebSearchEnabled(Boolean(s.web_search_enabled));
        setWebSearchProvider(s.web_search_provider || "google");
        setWebSearchMaxResults(s.web_search_max_results || 5);
        setWebSearchTimeout(s.web_search_timeout_seconds || 8);
        setWebSearchGoogleCx(s.web_search_google_cx || "");
        setWebSearchSearxngUrl(s.web_search_searxng_url || "");
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load settings."))
      .finally(() => setLoading(false));
  }, []);

  async function handleSave(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const payload: Record<string, unknown> = {
        school_name: schoolName,
        academic_year: academicYear,
        local_model_name: localModelName,
        embedding_model_name: embeddingModelName,
        embedding_provider: embeddingProvider,
        maintenance_mode: maintenanceMode,
        web_search_enabled: webSearchEnabled,
        web_search_provider: webSearchProvider,
        web_search_max_results: webSearchMaxResults,
        web_search_timeout_seconds: webSearchTimeout,
        web_search_searxng_url: webSearchSearxngUrl.trim(),
      };
      if (webSearchApiKey.trim()) {
        payload.web_search_api_key = webSearchApiKey.trim();
      }
      if (webSearchGoogleCx.trim()) {
        payload.web_search_google_cx = webSearchGoogleCx.trim();
      }
      const updated = await api.put<SchoolSettings>("/settings", payload);
      setSettings(updated);
      setWebSearchApiKey("");
      setWebSearchGoogleCx(updated.web_search_google_cx || "");
      setWebSearchSearxngUrl(updated.web_search_searxng_url || "");
      setMessage("Settings saved successfully.");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to save settings.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="center-loading">
        <span className="loading-spinner" /> Loading settings...
      </div>
    );
  }

  const providerHelp = {
    google: "Uses Google Programmable Search JSON API. Requires API key and Search Engine ID (cx).",
    searxng: "Uses a SearXNG instance, similar to the web-search layer often used behind OpenWebUI-style deployments.",
    brave: "Uses Brave Search API. Requires a Brave API key.",
    duckduckgo: "Uses DuckDuckGo HTML as a no-key fallback. Good for testing but less stable than API providers.",
  }[webSearchProvider] || "Select a provider.";

  return (
    <div className="grid grid-cols-2">
      <div className="card">
        <div className="card-title">School, Model & Web Settings</div>
        <div className="card-subtitle">
          Control the local Ollama model, embeddings, maintenance mode, and the global web-search master switch.
        </div>
        {error && <div className="alert alert-error">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}
        <form onSubmit={handleSave}>
          <div className="field">
            <label>School Name</label>
            <input value={schoolName} onChange={(e) => setSchoolName(e.target.value)} required />
          </div>
          <div className="field">
            <label>Academic Year</label>
            <input value={academicYear} onChange={(e) => setAcademicYear(e.target.value)} placeholder="e.g. 2025-2026" required />
          </div>
          <div className="field">
            <label>Local Model Name (Ollama)</label>
            <input
              value={localModelName}
              onChange={(e) => setLocalModelName(e.target.value)}
              placeholder="qwen3:4b"
            />
            <p className="help-text">
              Used by Ask AI, Teacher Tools, and Admin Tools. Make sure this model is pulled in Ollama.
            </p>
          </div>
          <div className="form-row">
            <div className="field">
              <label>Embedding Provider</label>
              <select value={embeddingProvider} onChange={(e) => setEmbeddingProvider(e.target.value)}>
                <option value="ollama">Ollama</option>
                <option value="sentence_transformers">Sentence Transformers</option>
              </select>
            </div>
            <div className="field">
              <label>Embedding Model Name</label>
              <input value={embeddingModelName} onChange={(e) => setEmbeddingModelName(e.target.value)} placeholder="embeddinggemma" />
            </div>
          </div>

          <div className="settings-panel">
            <div>
              <div className="card-title small-title">Web Search</div>
              <p className="help-text">
                Web search is controlled in three places: this global switch, the user-level permission in Users, and the Search chip in Ask AI.
                The final answer still comes from the local Ollama model.
              </p>
            </div>
            <label className="switch-row">
              <input type="checkbox" checked={webSearchEnabled} onChange={(e) => setWebSearchEnabled(e.target.checked)} />
              <span>Enable web search globally</span>
            </label>
            <div className="form-row">
              <div className="field">
                <label>Provider</label>
                <select value={webSearchProvider} onChange={(e) => setWebSearchProvider(e.target.value)}>
                  <option value="google">Google Programmable Search</option>
                  <option value="searxng">SearXNG / OpenWebUI-style layer</option>
                  <option value="brave">Brave Search API</option>
                  <option value="duckduckgo">DuckDuckGo HTML fallback</option>
                </select>
                <p className="help-text">{providerHelp}</p>
              </div>
              <div className="field">
                <label>Max results</label>
                <input type="number" min={1} max={10} value={webSearchMaxResults} onChange={(e) => setWebSearchMaxResults(Number(e.target.value))} />
              </div>
            </div>

            {(webSearchProvider === "google" || webSearchProvider === "brave") && (
              <div className="form-row">
                <div className="field">
                  <label>{webSearchProvider === "google" ? "Google API key" : "Brave API key"} {settings?.web_search_api_key_set ? "(configured)" : "(required)"}</label>
                  <input type="password" value={webSearchApiKey} onChange={(e) => setWebSearchApiKey(e.target.value)} placeholder="Leave blank to keep existing key" />
                </div>
                {webSearchProvider === "google" && (
                  <div className="field">
                    <label>Google Search Engine ID / cx {settings?.web_search_google_cx_set ? "(configured)" : "(required)"}</label>
                    <input value={webSearchGoogleCx} onChange={(e) => setWebSearchGoogleCx(e.target.value)} placeholder="e.g. 8ac1ab64606d234f1" />
                  </div>
                )}
              </div>
            )}

            {webSearchProvider === "searxng" && (
              <div className="field">
                <label>SearXNG base URL</label>
                <input value={webSearchSearxngUrl} onChange={(e) => setWebSearchSearxngUrl(e.target.value)} placeholder="http://localhost:8080" />
                <p className="help-text">Your SearXNG instance can be configured to use Google, Bing, Brave, DuckDuckGo, or multiple engines.</p>
              </div>
            )}

            <div className="field">
              <label>Timeout seconds</label>
              <input type="number" min={2} max={30} value={webSearchTimeout} onChange={(e) => setWebSearchTimeout(Number(e.target.value))} />
            </div>
          </div>

          <label className="switch-row mb-16">
            <input type="checkbox" checked={maintenanceMode} onChange={(e) => setMaintenanceMode(e.target.checked)} />
            <span>Maintenance Mode</span>
          </label>

          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? <span className="loading-spinner" /> : "Save Settings"}
          </button>
        </form>
      </div>

      <div className="card">
        <div className="card-title">System Info</div>
        <div className="field">
          <label>Backup Location</label>
          <input value={settings?.backup_location || ""} readOnly />
        </div>
        <div className="field">
          <label>Document Encryption</label>
          <div><span className="badge badge-green">{settings?.encryption_status || "enabled"}</span></div>
        </div>
        <div className="field">
          <label>Web Search Status</label>
          <div className="stack-sm">
            <span className={`badge ${settings?.web_search_enabled ? "badge-green" : "badge-slate"}`}>
              Global {settings?.web_search_enabled ? "enabled" : "disabled"}
            </span>
            <span className="badge badge-indigo">Provider: {settings?.web_search_provider || "google"}</span>
            {(settings?.web_search_provider === "google") && <span className={`badge ${settings.web_search_google_cx_set ? "badge-green" : "badge-amber"}`}>Google cx {settings.web_search_google_cx_set ? "set" : "missing"}</span>}
            {(settings?.web_search_provider === "searxng") && <span className={`badge ${settings.web_search_searxng_url ? "badge-green" : "badge-amber"}`}>SearXNG URL {settings.web_search_searxng_url ? "set" : "missing"}</span>}
          </div>
        </div>
        <p className="help-text">
          Uploaded school documents remain encrypted and local. When web search is enabled, only the question is sent to the chosen provider to fetch snippets for the local model.
        </p>
      </div>
    </div>
  );
}
