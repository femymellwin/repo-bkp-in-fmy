import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { api, ApiError } from "../services/api";
import type { OnboardingItem, User } from "../types";

const STATUSES = ["not_started", "in_progress", "blocked", "completed"];
const CATEGORIES = ["extracurricular", "teacher_onboarding", "policy_acknowledgement", "club_setup", "event_readiness"];

export default function OnboardingPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<OnboardingItem[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [form, setForm] = useState({ title: "", category: "extracurricular", owner_user_id: "", status: "not_started", due_date: "", notes: "" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  const canManage = user?.role === "school_admin" || user?.role === "principal";

  async function load() {
    setError("");
    try {
      const [itemsRes, usersRes] = await Promise.allSettled([
        api.get<OnboardingItem[]>("/onboarding"),
        canManage ? api.get<User[]>("/users") : Promise.resolve([] as User[]),
      ]);
      if (itemsRes.status === "fulfilled") setItems(itemsRes.value);
      if (usersRes.status === "fulfilled") setUsers(usersRes.value);
      if (itemsRes.status === "rejected") throw itemsRes.reason;
    } catch (err) { setError(err instanceof ApiError ? err.message : "Failed to load onboarding."); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault(); setError(""); setMessage("");
    try {
      await api.post<OnboardingItem>("/onboarding", {
        title: form.title,
        category: form.category,
        owner_user_id: form.owner_user_id ? Number(form.owner_user_id) : null,
        status: form.status,
        due_date: form.due_date || null,
        notes: form.notes,
      });
      setMessage("Onboarding item created.");
      setForm({ title: "", category: "extracurricular", owner_user_id: "", status: "not_started", due_date: "", notes: "" });
      await load();
    } catch (err) { setError(err instanceof ApiError ? err.message : "Failed to create item."); }
  }

  async function updateItem(id: number, updates: Partial<OnboardingItem>) {
    setError(""); setMessage("");
    try {
      await api.patch<OnboardingItem>(`/onboarding/${id}`, updates);
      await load();
    } catch (err) { setError(err instanceof ApiError ? err.message : "Failed to update item."); }
  }

  async function deleteItem(id: number) {
    if (!confirm("Delete this onboarding item?")) return;
    setError("");
    try { await api.delete(`/onboarding/${id}`); await load(); }
    catch (err) { setError(err instanceof ApiError ? err.message : "Failed to delete item."); }
  }

  if (loading) return <div className="center-loading"><span className="loading-spinner" /> Loading onboarding...</div>;

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      {message && <div className="alert alert-success">{message}</div>}
      {canManage && (
        <div className="card mb-16">
          <div className="card-title">Create extracurricular / onboarding item</div>
          <div className="card-subtitle">Track activities such as club setup, activity approvals, teacher onboarding, parent forms, and policy acknowledgements.</div>
          <form onSubmit={create}>
            <div className="form-row">
              <div className="field"><label>Title</label><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required /></div>
              <div className="field"><label>Category</label><select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}</select></div>
            </div>
            <div className="form-row">
              <div className="field"><label>Owner</label><select value={form.owner_user_id} onChange={(e) => setForm({ ...form, owner_user_id: e.target.value })}><option value="">Unassigned / common</option>{users.map((u) => <option key={u.id} value={u.id}>{u.full_name} ({u.role})</option>)}</select></div>
              <div className="field"><label>Due date</label><input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} /></div>
            </div>
            <div className="field"><label>Notes</label><textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            <button className="btn btn-primary">Create item</button>
          </form>
        </div>
      )}

      <div className="card">
        <div className="card-title">Onboarding board</div>
        <table className="data-table">
          <thead><tr><th>Item</th><th>Category</th><th>Owner</th><th>Due</th><th>Status</th><th>Notes</th><th></th></tr></thead>
          <tbody>{items.map((item) => (
            <tr key={item.id}>
              <td><b>{item.title}</b></td>
              <td><span className="badge badge-slate">{item.category}</span></td>
              <td>{item.owner_name || "Common"}</td>
              <td>{item.due_date ? new Date(item.due_date).toLocaleDateString() : "—"}</td>
              <td><select value={item.status} onChange={(e) => updateItem(item.id, { status: e.target.value })}>{STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}</select></td>
              <td>{item.notes}</td>
              <td>{canManage && <button className="btn btn-danger btn-sm" onClick={() => deleteItem(item.id)}>Delete</button>}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}
