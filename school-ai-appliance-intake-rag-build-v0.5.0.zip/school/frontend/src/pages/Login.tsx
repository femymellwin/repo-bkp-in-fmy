import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { ApiError } from "../services/api";

const DEMO_USERS = [
  { email: "superadmin@example.com", label: "Super Admin" },
  { email: "admin@example.com", label: "School Admin" },
  { email: "principal@example.com", label: "Principal" },
  { email: "teacher@example.com", label: "Teacher" },
  { email: "accounts@example.com", label: "Accounts Staff" },
];

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password);
      navigate("/");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-brand">
          <img className="login-logo" src="/logo.png" alt="in(Take) IQ" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
          <div className="login-title">in(Take) IQ School AI</div>
          <div className="login-subtitle">Smarter school knowledge. Local RAG. Your data never leaves this machine.</div>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>
          <button className="btn btn-primary" type="submit" style={{ width: "100%", justifyContent: "center" }} disabled={loading}>
            {loading ? <span className="loading-spinner" /> : "Log In"}
          </button>
        </form>

        <div className="demo-users">
          <div className="demo-users-title">Demo Accounts (password: password123)</div>
          {DEMO_USERS.map((u) => (
            <div className="demo-user-row" key={u.email}>
              <span>
                {u.label} — {u.email}
              </span>
              <button
                type="button"
                className="demo-user-use"
                onClick={() => {
                  setEmail(u.email);
                  setPassword("password123");
                }}
              >
                Use
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
