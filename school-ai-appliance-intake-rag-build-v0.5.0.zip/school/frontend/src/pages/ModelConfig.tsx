import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { ModelConfigResponse } from "../types";

export default function ModelConfig() {
  const [config, setConfig] = useState<ModelConfigResponse | null>(null);
  const [localModel, setLocalModel] = useState("qwen3:4b");
  const [embeddingProvider, setEmbeddingProvider] = useState<"sentence_transformers" | "ollama">("ollama");
  const [embeddingModel, setEmbeddingModel] = useState("embeddinggemma");
  const [topK, setTopK] = useState(5);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    try {
      const res = await api.get<ModelConfigResponse>("/model-config");
      setConfig(res);
      setLocalModel(res.local_model_name);
      setEmbeddingProvider(res.embedding_provider);
      setEmbeddingModel(res.embedding_model_name);
      setTopK(res.rag_top_k);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load model configuration.");
    } finally { setLoading(false); }
  }
  useEffect(() => { load(); }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true); setError(""); setMessage("");
    try {
      await api.put<ModelConfigResponse>("/model-config", {
        local_model_name: localModel,
        embedding_provider: embeddingProvider,
        embedding_model_name: embeddingModel,
        rag_top_k: topK,
      });
      setMessage("Model configuration saved.");
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to save model configuration.");
    } finally { setSaving(false); }
  }

  if (loading) return <div className="center-loading"><span className="loading-spinner" /> Loading model configuration...</div>;
  if (error && !config) return <div className="alert alert-error">{error}</div>;

  return (
    <div className="grid grid-cols-2">
      <div className="card">
        <div className="card-title">Model Configuration</div>
        <div className="card-subtitle">Configure the local chat model, embedding provider, embedding model, and RAG retrieval count.</div>
        {error && <div className="alert alert-error">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}
        <form onSubmit={save}>
          <div className="field">
            <label>Chat / reasoning model</label>
            <input value={localModel} onChange={(e) => setLocalModel(e.target.value)} placeholder="qwen3:4b" />
          </div>
          <div className="field">
            <label>Embedding provider</label>
            <select value={embeddingProvider} onChange={(e) => setEmbeddingProvider(e.target.value as "sentence_transformers" | "ollama")}>
              <option value="ollama">Ollama local embedding model</option>
              <option value="sentence_transformers">Sentence Transformers in backend process</option>
            </select>
          </div>
          <div className="field">
            <label>Embedding model</label>
            <input value={embeddingModel} onChange={(e) => setEmbeddingModel(e.target.value)} placeholder="embeddinggemma" />
          </div>
          <div className="field">
            <label>RAG top-K chunks</label>
            <input type="number" min={1} max={20} value={topK} onChange={(e) => setTopK(Number(e.target.value) || 5)} />
          </div>
          <button className="btn btn-primary" type="submit" disabled={saving}>{saving ? <span className="loading-spinner" /> : "Save model configuration"}</button>
        </form>
      </div>

      <div className="card">
        <div className="card-title">Runtime Status</div>
        {config && (
          <>
            <div className="metric-row"><span>Ollama endpoint</span><code>{config.ollama_base_url}</code></div>
            <div className="metric-row"><span>Ollama status</span><span className={`badge ${config.ollama_status === "online" ? "badge-green" : "badge-red"}`}>{config.ollama_status}</span></div>
            <div className="metric-row"><span>Chat model</span><span className={`badge ${config.local_model_available ? "badge-green" : "badge-red"}`}>{config.local_model_name}</span></div>
            <div className="metric-row"><span>Embedding model</span><span className={`badge ${config.embedding_model_available ? "badge-green" : "badge-red"}`}>{config.embedding_model_name}</span></div>
            <div className="metric-row"><span>Available Ollama models</span><span>{config.available_ollama_models.length ? config.available_ollama_models.join(", ") : "No models reported"}</span></div>
            <div className="alert alert-warning" style={{ marginTop: 16 }}>
              {config.notes.map((note) => <div key={note}>• {note}</div>)}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
