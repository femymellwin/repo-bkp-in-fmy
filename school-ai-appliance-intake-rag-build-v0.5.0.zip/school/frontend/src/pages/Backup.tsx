import { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import type { BackupRecord } from "../types";

function formatSize(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function Backup() {
  const [backups, setBackups] = useState<BackupRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function loadBackups() {
    setLoading(true);
    try {
      const res = await api.get<BackupRecord[]>("/backup");
      setBackups(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load backups.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadBackups();
  }, []);

  async function handleCreateBackup() {
    setCreating(true);
    setError("");
    setMessage("");
    try {
      const res = await api.post<BackupRecord>("/backup");
      setMessage(`Backup "${res.filename}" created successfully (${formatSize(res.file_size)}).`);
      await loadBackups();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Backup failed.");
    } finally {
      setCreating(false);
    }
  }

  return (
    <div>
      <div className="card mb-16">
        <div className="card-title">Create Local Backup</div>
        <div className="card-subtitle">
          Bundles the SQLite database, encrypted documents, vector database, and configuration into a
          timestamped ZIP file. Documents remain encrypted inside the backup — nothing is decrypted during
          this process.
        </div>
        {error && <div className="alert alert-error">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}
        <button className="btn btn-primary" onClick={handleCreateBackup} disabled={creating}>
          {creating ? <span className="loading-spinner" /> : "Create Backup Now"}
        </button>
      </div>

      <div className="card">
        <div className="card-title">Previous Backups</div>
        {loading ? (
          <div className="center-loading">
            <span className="loading-spinner" /> Loading backups...
          </div>
        ) : backups.length === 0 ? (
          <div className="empty-state">No backups have been created yet.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Filename</th>
                <th>Size</th>
                <th>Created By</th>
                <th>Created At</th>
              </tr>
            </thead>
            <tbody>
              {backups.map((b) => (
                <tr key={b.id}>
                  <td>{b.filename}</td>
                  <td>{formatSize(b.file_size)}</td>
                  <td>{b.created_by}</td>
                  <td>{new Date(b.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
