import { useEffect, useMemo, useState, type FormEvent } from "react";
import { api, ApiError } from "../services/api";
import type { Role, User } from "../types";
import { NAV_ITEMS } from "../components/Sidebar";

const ROLES: Role[] = ["super_admin", "school_admin", "principal", "teacher", "accounts_admin"];
const ROLE_LABELS: Record<Role, string> = {
  super_admin: "Super Admin",
  school_admin: "School Admin",
  principal: "Principal",
  teacher: "Teacher",
  accounts_admin: "Accounts / Admin Staff",
};

const defaultForm = { full_name: "", email: "", password: "password123", role: "teacher" as Role, is_active: true, menu_exclusions: "", web_search_enabled: false };

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [form, setForm] = useState(defaultForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const menuSet = useMemo(() => new Set((form.menu_exclusions || "").split(",").filter(Boolean)), [form.menu_exclusions]);

  async function load() {
    setError("");
    try { setUsers(await api.get<User[]>("/users")); }
    catch (err) { setError(err instanceof ApiError ? err.message : "Failed to load users."); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, []);

  function edit(user: User) {
    setEditingId(user.id);
    setForm({
      full_name: user.full_name,
      email: user.email,
      password: "",
      role: user.role,
      is_active: user.is_active,
      menu_exclusions: user.menu_exclusions || "",
      web_search_enabled: Boolean(user.web_search_enabled),
    });
  }

  function resetForm() { setEditingId(null); setForm(defaultForm); }

  function toggleMenu(key: string) {
    const next = new Set(menuSet);
    next.has(key) ? next.delete(key) : next.add(key);
    setForm((f) => ({ ...f, menu_exclusions: Array.from(next).join(",") }));
  }

  async function submit(e: FormEvent) {
    e.preventDefault(); setSaving(true); setError(""); setMessage("");
    try {
      const payload = { ...form, password: form.password || undefined };
      if (editingId) {
        await api.patch<User>(`/users/${editingId}`, payload);
        setMessage("User updated.");
      } else {
        await api.post<User>("/users", payload);
        setMessage("User created.");
      }
      resetForm(); await load();
    } catch (err) { setError(err instanceof ApiError ? err.message : "Failed to save user."); }
    finally { setSaving(false); }
  }

  if (loading) return <div className="center-loading"><span className="loading-spinner" /> Loading users...</div>;

  return (
    <div className="grid grid-cols-2">
      <div className="card">
        <div className="card-title">{editingId ? "Edit user" : "Create user"}</div>
        <div className="card-subtitle">Account management with role, active flag, password reset, per-user menu exclusions, and per-user web-search permission.</div>
        {error && <div className="alert alert-error">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}
        <form onSubmit={submit}>
          <div className="field"><label>Full name</label><input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required /></div>
          <div className="field"><label>Email</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></div>
          <div className="form-row">
            <div className="field"><label>Role</label><select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Role })}>{ROLES.map((r) => <option value={r} key={r}>{ROLE_LABELS[r]}</option>)}</select></div>
            <div className="field"><label>Password {editingId ? "(blank = keep)" : ""}</label><input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
          </div>
          <div className="grid grid-cols-2">
            <label className="switch-row">
              <input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} />
              <span>Active user</span>
            </label>
            <label className="switch-row">
              <input type="checkbox" checked={form.web_search_enabled} onChange={(e) => setForm({ ...form, web_search_enabled: e.target.checked })} />
              <span>Allow web search</span>
            </label>
          </div>
          <div className="field">
            <label>Hide menus for this user</label>
            <div className="tag-select-grid">
              {NAV_ITEMS.map((item) => <button type="button" key={item.key} className={`tag-select ${menuSet.has(item.key) ? "active" : ""}`} onClick={() => toggleMenu(item.key)}>{item.label}</button>)}
            </div>
          </div>
          <div className="d-flex gap-2">
            <button className="btn btn-primary" disabled={saving}>{saving ? <span className="loading-spinner" /> : editingId ? "Save changes" : "Create user"}</button>
            {editingId && <button type="button" className="btn btn-secondary" onClick={resetForm}>Cancel</button>}
          </div>
        </form>
      </div>

      <div className="card">
        <div className="card-title">Accounts</div>
        <table className="data-table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Web</th><th>Menus hidden</th><th></th></tr></thead>
          <tbody>{users.map((u) => (
            <tr key={u.id}>
              <td><b>{u.full_name}</b></td>
              <td><code>{u.email}</code></td>
              <td><span className="badge badge-indigo">{ROLE_LABELS[u.role]}</span></td>
              <td><span className={`badge ${u.is_active ? "badge-green" : "badge-red"}`}>{u.is_active ? "active" : "inactive"}</span></td>
              <td><span className={`badge ${u.web_search_enabled ? "badge-green" : "badge-slate"}`}>{u.web_search_enabled ? "allowed" : "off"}</span></td>
              <td>{(u.menu_exclusions || "").split(",").filter(Boolean).length}</td>
              <td><button className="btn btn-secondary btn-sm" onClick={() => edit(u)}>Edit</button></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}
