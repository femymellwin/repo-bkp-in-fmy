# Private School AI Appliance — Frontend

React + Vite + TypeScript. See the top-level README.md for full setup
instructions. Quick reference:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173 — the Vite dev server proxies `/api` requests to
the backend at http://localhost:8000 (see `vite.config.ts`).

## Project layout

```
src/
  components/  # Sidebar, Header, Layout, ProtectedRoute
  pages/       # one file per top-level page/route
  services/    # api.ts (fetch wrapper), auth.ts
  hooks/       # useAuth (auth context)
  types/       # shared TypeScript interfaces
```
