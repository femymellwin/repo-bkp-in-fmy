import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// In local Mac development, the backend runs on localhost:8000.
// Inside Docker Compose, it must be reached via the service name "backend".
// Override with the BACKEND_URL env var if needed.
const backendTarget = process.env.BACKEND_URL || "http://localhost:8000";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
    proxy: {
      "/api": {
        target: backendTarget,
        changeOrigin: true,
      },
    },
  },
});
