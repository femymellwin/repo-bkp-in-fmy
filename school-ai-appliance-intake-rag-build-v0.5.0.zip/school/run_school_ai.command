#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
./run_local.sh
