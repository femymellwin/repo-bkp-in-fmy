# Build v0.5.0 - Google Web Search, Simplified Chat, Adaptive Chunk Agent

## Main changes

### Ask AI chat screen
- Rebuilt the Ask AI screen into a simpler ChatGPT/Claude-style layout.
- Removed the previous Ask AI audit cards from the chat rail.
- Chat history is now project/thread based.
- Sending a message no longer forces the scope popup.
- The scope popup is optional and opens only from the Scope chip.
- The Search chip sits inside the composer and only enables web search for that message.
- Sources and model usage are collapsed under "Sources and usage" so the chat remains clean.
- The chat transcript has a fixed scroll area and automatically scrolls to the latest message.

### Web search layer
- Added provider abstraction similar to OpenWebUI-style web search adapters.
- Supported providers:
  - Google Programmable Search JSON API (`google`)
  - SearXNG / OpenWebUI-style metasearch layer (`searxng`)
  - Brave Search API (`brave`)
  - DuckDuckGo HTML fallback (`duckduckgo`)
- Google search requires:
  - Google API key
  - Google Search Engine ID / `cx`
- Search is enabled only when all three controls allow it:
  - Global Settings switch
  - User-level permission
  - Search chip in Ask AI
- Provider readiness is now enforced. For example, Google search is disabled until both API key and `cx` are configured.

### Adaptive chunk agent
- Added `SchoolAI Adaptive Chunk Agent v1`.
- On upload/indexing, the agent inspects extracted text, file type, document kind, word count, line count, and structure indicators.
- It chooses the final chunk size and overlap per document.
- It records the reason for the decision on the document audit record.

### Retrieval quality tests
- After indexing, the backend runs retrieval smoke tests for the uploaded document.
- Tests are stored in the new `document_index_tests` table.
- Documents now show quality status and score.
- The Documents page includes a quality-test modal.
- RAG Audit shows chunk-agent decision and retrieval quality status.

## New backend objects

- `backend/app/services/chunk_agent_service.py`
- `DocumentIndexTest` SQLAlchemy model
- `GET /api/documents/{document_id}/quality-tests`

## Updated settings

New settings keys:

- `web_search_provider`
- `web_search_api_key`
- `web_search_google_cx`
- `web_search_searxng_url`
- `web_search_max_results`
- `web_search_timeout_seconds`

## Notes

Google Programmable Search JSON API may require an existing Google Programmable Search setup. If you want an OpenWebUI-like self-hosted search layer, run SearXNG locally and configure its base URL in Settings.
