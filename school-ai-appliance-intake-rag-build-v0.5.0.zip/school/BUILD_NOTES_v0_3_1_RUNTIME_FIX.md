# Build notes — v0.3.1 Runtime Fix

Build name: `school-ai-appliance-intake-rag-build-v0.3.1`

## Main fix

The reported install failure was caused by `backend/venv` being created with Python 3.14. The pinned backend dependency chain includes `pydantic==2.9.2`, which installs `pydantic-core==2.23.4`; that native package build rejects Python 3.14 through PyO3. The correct fix is to create the backend virtual environment with Python 3.11 or Python 3.12.

## Changes made

- Rebuilt `run_local.sh` so it searches for Python 3.12 first and Python 3.11 second.
- Added support for `SCHOOL_AI_PYTHON=/path/to/python3.12 ./run_local.sh`.
- Added automatic deletion/recreation of `backend/venv` if it was made with Python 3.13 or 3.14.
- Added `--prefer-binary` to backend dependency install to avoid unnecessary native builds.
- Added a runtime verification that `email-validator==2.2.0` is installed.
- Added `run_school_ai.command` for macOS double-click launch.
- Updated `RUN_LOCAL.md`, root `README.md`, and `backend/README.md` with the correct Python 3.12 setup.
- Updated backend Dockerfile to use `python:3.12-slim` and default to `requirements-lite.txt`.

## Dependency status

Both backend requirement files contain:

```text
email-validator==2.2.0
```

Recommended local install path remains:

```bash
./run_local.sh
```

## Manual recovery for an existing broken folder

```bash
cd backend
rm -rf venv
python3.12 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install --prefer-binary -r requirements-lite.txt
python seed.py
```
