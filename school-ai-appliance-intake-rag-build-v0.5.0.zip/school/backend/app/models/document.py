from datetime import datetime

from sqlalchemy import String, Integer, DateTime, ForeignKey, Boolean, Text, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class Document(Base):
    __tablename__ = "documents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    filename: Mapped[str] = mapped_column(String(255))
    uploaded_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    upload_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    document_type: Mapped[str] = mapped_column(String(20))  # pdf, docx, txt, csv, xlsx
    access_role: Mapped[str] = mapped_column(String(50))  # DocumentCategory value or custom category key
    file_size: Mapped[int] = mapped_column(Integer, default=0)
    workspace_id: Mapped[int | None] = mapped_column(ForeignKey("workspaces.id"), nullable=True, index=True)
    doc_kind: Mapped[str] = mapped_column(String(80), default="general")
    subject: Mapped[str] = mapped_column(String(120), default="")
    grade: Mapped[str] = mapped_column(String(80), default="")
    academic_year: Mapped[str] = mapped_column(String(40), default="")

    encrypted_file_path: Mapped[str] = mapped_column(String(500))
    superadmin_permitted: Mapped[bool] = mapped_column(Boolean, default=False)

    ingestion_status: Mapped[str] = mapped_column(String(20), default="pending")
    chunk_count: Mapped[int] = mapped_column(Integer, default=0)

    # RAG observability metadata, populated by ingestion_service.
    chunk_size: Mapped[int] = mapped_column(Integer, default=800)
    chunk_overlap: Mapped[int] = mapped_column(Integer, default=120)
    chunking_strategy: Mapped[str] = mapped_column(String(80), default="word_sliding_window")
    extracted_text_chars: Mapped[int] = mapped_column(Integer, default=0)
    vector_db: Mapped[str] = mapped_column(String(80), default="ChromaDB")
    vector_collection: Mapped[str] = mapped_column(String(120), default="school_documents")
    embedding_provider: Mapped[str] = mapped_column(String(80), default="sentence_transformers")
    embedding_model: Mapped[str] = mapped_column(String(200), default="")
    indexed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    index_error: Mapped[str] = mapped_column(Text, default="")

    # v0.5 ingestion-agent metadata.
    chunk_agent_name: Mapped[str] = mapped_column(String(120), default="")
    chunk_agent_reason: Mapped[str] = mapped_column(Text, default="")
    retrieval_test_status: Mapped[str] = mapped_column(String(40), default="not_run")
    retrieval_test_score: Mapped[float] = mapped_column(Float, default=0.0)
    retrieval_test_details: Mapped[str] = mapped_column(Text, default="")

    uploaded_by_user = relationship("User", back_populates="documents")
    workspace = relationship("Workspace", back_populates="documents")
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")
    index_tests = relationship("DocumentIndexTest", back_populates="document", cascade="all, delete-orphan")


class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id"))
    chunk_index: Mapped[int] = mapped_column(Integer)
    text: Mapped[str] = mapped_column(Text)
    vector_id: Mapped[str] = mapped_column(String(100))  # id used in the Chroma collection
    word_count: Mapped[int] = mapped_column(Integer, default=0)
    char_count: Mapped[int] = mapped_column(Integer, default=0)
    parent_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    section_title: Mapped[str] = mapped_column(String(240), default="")
    page_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="chunks")


class DocumentIndexTest(Base):
    __tablename__ = "document_index_tests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id"), index=True)
    test_name: Mapped[str] = mapped_column(String(120), default="retrieval_smoke_test")
    query: Mapped[str] = mapped_column(Text, default="")
    expected_document_id: Mapped[int] = mapped_column(Integer, default=0)
    top_document_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    passed: Mapped[bool] = mapped_column(Boolean, default=False)
    score: Mapped[float] = mapped_column(Float, default=0.0)
    details: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="index_tests")
