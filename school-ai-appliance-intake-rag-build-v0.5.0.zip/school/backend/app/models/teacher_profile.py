from datetime import datetime

from sqlalchemy import String, Integer, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class TeacherProfile(Base):
    __tablename__ = "teacher_profiles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True, index=True)
    preferred_name: Mapped[str] = mapped_column(String(150), default="")
    subjects: Mapped[str] = mapped_column(Text, default="")
    grades: Mapped[str] = mapped_column(Text, default="")
    bio: Mapped[str] = mapped_column(Text, default="")
    classroom_location: Mapped[str] = mapped_column(String(120), default="")
    office_hours: Mapped[str] = mapped_column(Text, default="")
    extracurricular_roles: Mapped[str] = mapped_column(Text, default="")
    rag_notes: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="teacher_profile")
