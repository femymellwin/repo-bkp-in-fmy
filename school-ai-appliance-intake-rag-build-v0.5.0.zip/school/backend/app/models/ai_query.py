from datetime import datetime

from sqlalchemy import String, Integer, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class AIQuery(Base):
    __tablename__ = "ai_queries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    role_at_time: Mapped[str] = mapped_column(String(50))
    tool: Mapped[str] = mapped_column(String(50), default="ask_school_ai")
    # ask_school_ai, lesson_plan, worksheet, quiz, parent_message, feedback_comment,
    # circular, meeting_agenda, policy_summary, staff_announcement, event_plan
    question: Mapped[str] = mapped_column(Text)
    answer: Mapped[str] = mapped_column(Text)
    sources: Mapped[list] = mapped_column(JSON, default=list)  # list of filenames
    found_answer: Mapped[bool] = mapped_column(Integer, default=1)
    model_name: Mapped[str] = mapped_column(String(150), default="")
    embedding_model: Mapped[str] = mapped_column(String(200), default="")
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    scope_summary: Mapped[str] = mapped_column(Text, default="All accessible documents")
    workspace_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    project_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    thread_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    used_web_search: Mapped[int] = mapped_column(Integer, default=0)
    web_search_provider: Mapped[str] = mapped_column(String(80), default="")
    web_sources: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="ai_queries")
