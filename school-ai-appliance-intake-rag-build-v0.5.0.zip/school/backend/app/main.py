from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.db.database import init_db, SessionLocal
from app.services.settings_service import ensure_defaults
from app.api import (
    auth, users, documents, ai, teacher_tools, admin_tools,
    timetable, analytics, audit, backup, system, settings as settings_api,
    rag_audit, model_config, permissions, teacher_profiles, onboarding, workspaces, chat,
)

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    db = SessionLocal()
    try:
        ensure_defaults(db)
    finally:
        db.close()
    yield


app = FastAPI(
    title=settings.APP_NAME,
    description="Local-first, on-premise AI appliance prototype for private schools. "
                 "All AI runs via local Ollama; all documents stay encrypted on this machine.",
    version="0.4.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health_check():
    return {"status": "ok", "app": settings.APP_NAME}


app.include_router(auth.router)
app.include_router(users.router)
app.include_router(documents.router)
app.include_router(ai.router)
app.include_router(teacher_tools.router)
app.include_router(admin_tools.router)
app.include_router(timetable.router)
app.include_router(analytics.router)
app.include_router(audit.router)
app.include_router(backup.router)
app.include_router(system.router)
app.include_router(settings_api.router)
app.include_router(rag_audit.router)
app.include_router(model_config.router)
app.include_router(permissions.router)
app.include_router(teacher_profiles.router)
app.include_router(onboarding.router)
app.include_router(workspaces.router)
app.include_router(chat.router)
