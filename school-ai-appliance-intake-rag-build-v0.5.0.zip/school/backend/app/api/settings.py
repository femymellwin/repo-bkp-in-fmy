from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.settings import SettingsResponse, SettingsUpdateRequest
from app.services import settings_service, audit_service
from app.api.deps import get_current_user, require_roles
from app.core.permissions import SYSTEM_ADMIN_ROLES
from app.core.config import get_settings as get_env_settings
from app.models.user import User

router = APIRouter(prefix="/api/settings", tags=["settings"])
env_settings = get_env_settings()


def _build_response(db: Session) -> SettingsResponse:
    values = settings_service.get_all_settings(db)
    web_cfg = settings_service.get_web_search_config(db)
    return SettingsResponse(
        school_name=values["school_name"],
        academic_year=values["academic_year"],
        local_model_name=values["local_model_name"],
        embedding_model_name=values["embedding_model_name"],
        embedding_provider=values.get("embedding_provider", env_settings.EMBEDDING_PROVIDER),
        backup_location=str(env_settings.backup_path),
        encryption_status="enabled",
        maintenance_mode=bool(values["maintenance_mode"]),
        web_search_enabled=bool(web_cfg["enabled"]),
        web_search_provider=str(web_cfg["provider"]),
        web_search_max_results=int(web_cfg["max_results"]),
        web_search_timeout_seconds=int(web_cfg["timeout_seconds"]),
        web_search_api_key_set=bool(str(web_cfg.get("api_key") or "")),
        web_search_google_cx=str(web_cfg.get("google_cx") or ""),
        web_search_google_cx_set=bool(str(web_cfg.get("google_cx") or "")),
        web_search_searxng_url=str(web_cfg.get("searxng_url") or ""),
    )


@router.get("", response_model=SettingsResponse)
def get_settings_route(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return _build_response(db)


@router.put("", response_model=SettingsResponse)
def update_settings(
    payload: SettingsUpdateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*SYSTEM_ADMIN_ROLES)),
):
    updates = payload.model_dump(exclude_none=True)
    if "embedding_provider" in updates:
        updates["embedding_provider"] = str(updates["embedding_provider"]).lower()
    if "web_search_provider" in updates:
        provider = str(updates["web_search_provider"]).lower()
        if provider not in {"google", "searxng", "brave", "duckduckgo"}:
            provider = "google"
        updates["web_search_provider"] = provider
    if "web_search_max_results" in updates:
        updates["web_search_max_results"] = str(max(1, min(int(updates["web_search_max_results"]), 10)))
    if "web_search_timeout_seconds" in updates:
        updates["web_search_timeout_seconds"] = str(max(2, min(int(updates["web_search_timeout_seconds"]), 30)))
    # Empty secret/config fields mean keep the existing value; use the Settings table directly if you need to clear them.
    if updates.get("web_search_api_key") == "":
        updates.pop("web_search_api_key", None)
    if updates.get("web_search_google_cx") == "":
        updates.pop("web_search_google_cx", None)
    if "web_search_searxng_url" in updates:
        updates["web_search_searxng_url"] = str(updates.get("web_search_searxng_url") or "").strip().rstrip("/")
    for key, value in updates.items():
        settings_service.set_setting(db, key, str(value))

    if updates:
        audit_service.log_action(
            db,
            action="settings_updated",
            actor_email=current_user.email,
            user_id=current_user.id,
            details=f"Updated settings: {list(updates.keys())}",
        )
    return _build_response(db)
