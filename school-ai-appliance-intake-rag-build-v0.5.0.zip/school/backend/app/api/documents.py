from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, BackgroundTasks, Request, Response
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.document import DocumentResponse, DocumentUploadResponse, DocumentIndexTestResponse
from app.services import document_service, ingestion_service, audit_service, settings_service, workspace_service
from app.api.deps import get_current_user
from app.core.permissions import RoleName
from app.models.user import User
from app.models.document import Document, DocumentIndexTest
from app.utils.file_utils import get_extension

router = APIRouter(prefix="/api/documents", tags=["documents"])

MAX_FILE_SIZE_MB = 25


def _to_response(document: Document) -> DocumentResponse:
    return DocumentResponse(
        id=document.id,
        filename=document.filename,
        uploaded_by=document.uploaded_by_user.email if document.uploaded_by_user else "unknown",
        upload_date=document.upload_date,
        document_type=document.document_type,
        access_role=document.access_role,
        file_size=document.file_size,
        workspace_id=document.workspace_id,
        workspace_name=document.workspace.name if document.workspace else None,
        doc_kind=document.doc_kind or "general",
        subject=document.subject or "",
        grade=document.grade or "",
        academic_year=document.academic_year or "",
        ingestion_status=document.ingestion_status,
        chunk_count=document.chunk_count,
        superadmin_permitted=document.superadmin_permitted,
        chunk_size=document.chunk_size,
        chunk_overlap=document.chunk_overlap,
        chunking_strategy=document.chunking_strategy,
        extracted_text_chars=document.extracted_text_chars,
        vector_db=document.vector_db,
        vector_collection=document.vector_collection,
        embedding_provider=document.embedding_provider,
        embedding_model=document.embedding_model,
        indexed_at=document.indexed_at,
        index_error=document.index_error,
        chunk_agent_name=document.chunk_agent_name or "",
        chunk_agent_reason=document.chunk_agent_reason or "",
        retrieval_test_status=document.retrieval_test_status or "not_run",
        retrieval_test_score=float(document.retrieval_test_score or 0.0),
        retrieval_test_details=document.retrieval_test_details or "",
    )


def _run_ingestion_job(document_id: int):
    from app.db.database import SessionLocal
    db = SessionLocal()
    try:
        document = db.query(Document).filter(Document.id == document_id).first()
        if document:
            ingestion_service.ingest_document(db, document)
    finally:
        db.close()


@router.get("/categories")
def list_categories(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    workspace_service.ensure_default_workspace(db, current_user)
    category_rows = workspace_service.list_categories(db, active_only=True)
    return {
        "categories": [row["name"] for row in category_rows],
        "category_items": category_rows,
        "workspaces": workspace_service.list_workspaces_for_user(db, current_user),
        "allowed_file_types": settings_service.get_allowed_file_types(db),
        "can_upload": settings_service.role_can_upload(db, current_user.role),
        "max_file_size_mb": MAX_FILE_SIZE_MB,
        "doc_kinds": [
            "general", "textbook", "syllabus", "lesson_notes", "worksheet", "question_paper",
            "answer_key", "answer_paper", "policy", "circular", "timetable", "marksheet",
        ],
    }


@router.get("", response_model=list[DocumentResponse])
def list_documents(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    documents = document_service.list_documents_for_user(db, current_user)
    return [_to_response(d) for d in documents]


@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_document(
    background_tasks: BackgroundTasks,
    request: Request,
    file: UploadFile = File(...),
    access_role: str = Form(...),
    workspace_id: int | None = Form(None),
    doc_kind: str = Form("general"),
    subject: str = Form(""),
    grade: str = Form(""),
    academic_year: str = Form(""),
    superadmin_permitted: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    allowed_extensions = settings_service.get_allowed_file_types(db)
    if not settings_service.role_can_upload(db, current_user.role):
        raise HTTPException(status_code=403, detail="Your role is not permitted to upload documents.")
    if get_extension(file.filename or "") not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type. Allowed types: {', '.join(sorted(allowed_extensions))}",
        )
    if not workspace_service.category_exists(db, access_role):
        raise HTTPException(status_code=400, detail="Invalid or inactive category. Create/activate it from Workspaces & Categories first.")

    try:
        workspace = workspace_service.get_workspace_for_upload(db, current_user, workspace_id)
    except workspace_service.WorkspaceAccessError as exc:
        raise HTTPException(status_code=403, detail=str(exc))

    file_bytes = await file.read()
    if len(file_bytes) > MAX_FILE_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=400, detail=f"File too large. Max size is {MAX_FILE_SIZE_MB} MB.")

    # Only School Admin / Principal may grant Super Admin an explicit exception.
    if superadmin_permitted and current_user.role not in (RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value):
        superadmin_permitted = False

    document = document_service.save_new_document(
        db,
        current_user,
        file.filename,
        file_bytes,
        access_role,
        superadmin_permitted,
        workspace_id=workspace.id,
        doc_kind=doc_kind,
        subject=subject,
        grade=grade,
        academic_year=academic_year,
    )

    audit_service.log_action(
        db, action="document_upload", actor_email=current_user.email, user_id=current_user.id,
        details=f"Uploaded '{document.filename}' to workspace '{workspace.name}' and category '{access_role}'.",
        ip_address=request.client.host if request.client else "",
    )

    background_tasks.add_task(_run_ingestion_job, document.id)

    return DocumentUploadResponse(
        document=_to_response(document),
        message="Document uploaded to the selected workspace, encrypted, and queued for local RAG indexing.",
    )


@router.get("/{document_id}/quality-tests", response_model=list[DocumentIndexTestResponse])
def document_quality_tests(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        document = document_service.get_document_or_403(db, current_user, document_id)
    except document_service.AccessDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    rows = (
        db.query(DocumentIndexTest)
        .filter(DocumentIndexTest.document_id == document.id)
        .order_by(DocumentIndexTest.created_at.desc(), DocumentIndexTest.id.desc())
        .all()
    )
    return rows


@router.get("/{document_id}/download")
def download_document(
    document_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Streams the original file back to an authorized user. The file is
    decrypted in memory only - the encrypted copy on disk is never touched,
    and raw storage paths are never revealed. Every download is written to
    the audit log as a `document_access` event.
    """
    try:
        document = document_service.get_document_or_403(db, current_user, document_id)
    except document_service.AccessDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc))

    try:
        file_bytes = document_service.decrypt_document_text_bytes(document)
    except Exception:
        raise HTTPException(status_code=500, detail="Could not decrypt this document. Check the encryption key.")

    audit_service.log_action(
        db, action="document_access", actor_email=current_user.email, user_id=current_user.id,
        details=f"Downloaded '{document.filename}'.",
        ip_address=request.client.host if request.client else "",
    )

    media_types = {
        "pdf": "application/pdf",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "txt": "text/plain",
        "csv": "text/csv",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }
    safe_name = quote(document.filename)
    return Response(
        content=file_bytes,
        media_type=media_types.get(document.document_type, "application/octet-stream"),
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{safe_name}"},
    )


@router.delete("/{document_id}")
def delete_document(
    document_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        document = document_service.get_document_or_403(db, current_user, document_id)
    except document_service.AccessDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc))

    # School Admin / Principal may delete any document they can access;
    # other staff may delete documents they uploaded into their workspaces.
    is_admin = current_user.role in (RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)
    is_owner = document.uploaded_by_id == current_user.id
    if not (is_admin or (settings_service.role_can_upload(db, current_user.role) and is_owner)):
        raise HTTPException(status_code=403, detail="You may only delete documents you uploaded yourself.")

    filename = document.filename
    document_service.delete_document(db, document)

    audit_service.log_action(
        db, action="document_deletion", actor_email=current_user.email, user_id=current_user.id,
        details=f"Deleted '{filename}'.", ip_address=request.client.host if request.client else "",
    )
    return {"message": f"Document '{filename}' deleted."}
