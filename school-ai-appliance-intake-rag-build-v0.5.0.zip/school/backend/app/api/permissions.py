from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import require_roles
from app.core.permissions import RoleName, ROLE_PERMISSIONS, ALL_CATEGORIES
from app.models.user import User
from app.services import settings_service, audit_service, workspace_service
from app.schemas.permissions import PermissionMatrixResponse, UploadRolesUpdate

router = APIRouter(prefix="/api/permissions", tags=["permissions"])
VIEW_ROLES = (RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)
CONFIG_ROLES = (RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value)


def _response(db: Session) -> PermissionMatrixResponse:
    category_rows = workspace_service.list_categories(db, active_only=True)
    return PermissionMatrixResponse(
        roles=list(ROLE_PERMISSIONS.keys()),
        categories=[row["name"] for row in category_rows],
        read_permissions=ROLE_PERMISSIONS,
        upload_roles=settings_service.get_upload_roles(db),
        menu_items=settings_service.DEFAULT_MENU_ITEMS,
    )


@router.get("", response_model=PermissionMatrixResponse)
def get_permissions(db: Session = Depends(get_db), current_user: User = Depends(require_roles(*VIEW_ROLES))):
    return _response(db)


@router.put("/upload-roles", response_model=PermissionMatrixResponse)
def update_upload_roles(
    payload: UploadRolesUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*CONFIG_ROLES)),
):
    roles = settings_service.set_upload_roles(db, payload.upload_roles)
    audit_service.log_action(
        db, action="upload_permissions_updated", actor_email=current_user.email, user_id=current_user.id,
        details=f"Upload roles set to {roles}.",
    )
    return _response(db)
