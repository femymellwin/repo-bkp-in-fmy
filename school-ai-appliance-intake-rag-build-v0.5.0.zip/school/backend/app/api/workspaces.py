from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles
from app.core.permissions import RoleName
from app.db.database import get_db
from app.models.user import User
from app.schemas.workspace import (
    WorkspaceResponse,
    WorkspaceCreate,
    WorkspaceUpdate,
    DocumentCategoryResponse,
    DocumentCategoryCreate,
    DocumentCategoryUpdate,
)
from app.services import workspace_service, audit_service

router = APIRouter(tags=["workspaces"])
CATEGORY_CONFIG_ROLES = (RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)


def _workspace_response(item: dict) -> WorkspaceResponse:
    return WorkspaceResponse(**item)


def _category_response(item: dict | object) -> DocumentCategoryResponse:
    if isinstance(item, dict):
        return DocumentCategoryResponse(**item)
    return DocumentCategoryResponse(
        id=item.id,
        name=item.name,
        display_name=item.display_name,
        description=item.description or "",
        is_active=bool(item.is_active),
        document_count=0,
        created_at=item.created_at,
    )


@router.get("/api/workspaces", response_model=list[WorkspaceResponse])
def list_my_workspaces(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    workspace_service.ensure_default_workspace(db, current_user)
    return [_workspace_response(w) for w in workspace_service.list_workspaces_for_user(db, current_user)]


@router.post("/api/workspaces", response_model=WorkspaceResponse)
def create_workspace(
    payload: WorkspaceCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    workspace = workspace_service.create_workspace(db, current_user, payload.name, payload.description)
    audit_service.log_action(
        db, action="workspace_created", actor_email=current_user.email, user_id=current_user.id,
        details=f"Created workspace '{workspace.name}'.",
        ip_address=request.client.host if request.client else "",
    )
    return _workspace_response(workspace_service.list_workspaces_for_user(db, current_user)[0] if False else {
        "id": workspace.id,
        "name": workspace.name,
        "description": workspace.description or "",
        "owner_user_id": workspace.owner_user_id,
        "owner_name": current_user.full_name,
        "is_default": bool(workspace.is_default),
        "document_count": 0,
        "created_at": workspace.created_at,
        "updated_at": workspace.updated_at,
    })


@router.patch("/api/workspaces/{workspace_id}", response_model=WorkspaceResponse)
def update_workspace(
    workspace_id: int,
    payload: WorkspaceUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        workspace = workspace_service.update_workspace(db, current_user, workspace_id, payload.name, payload.description)
    except workspace_service.WorkspaceAccessError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    audit_service.log_action(
        db, action="workspace_updated", actor_email=current_user.email, user_id=current_user.id,
        details=f"Updated workspace '{workspace.name}'.",
        ip_address=request.client.host if request.client else "",
    )
    return WorkspaceResponse(
        id=workspace.id,
        name=workspace.name,
        description=workspace.description or "",
        owner_user_id=workspace.owner_user_id,
        owner_name=workspace.owner.full_name if workspace.owner else current_user.full_name,
        is_default=bool(workspace.is_default),
        document_count=len(workspace.documents or []),
        created_at=workspace.created_at,
        updated_at=workspace.updated_at,
    )


@router.delete("/api/workspaces/{workspace_id}")
def delete_workspace(
    workspace_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        workspace_service.delete_workspace(db, current_user, workspace_id)
    except workspace_service.WorkspaceAccessError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    audit_service.log_action(
        db, action="workspace_deleted", actor_email=current_user.email, user_id=current_user.id,
        details=f"Deleted workspace {workspace_id}.",
        ip_address=request.client.host if request.client else "",
    )
    return {"message": "Workspace deleted."}


@router.get("/api/document-categories", response_model=list[DocumentCategoryResponse])
def list_document_categories(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return [_category_response(c) for c in workspace_service.list_categories(db, active_only=False)]


@router.post("/api/document-categories", response_model=DocumentCategoryResponse)
def create_document_category(
    payload: DocumentCategoryCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*CATEGORY_CONFIG_ROLES)),
):
    row = workspace_service.create_category(db, current_user, payload.display_name, payload.description)
    audit_service.log_action(
        db, action="document_category_created", actor_email=current_user.email, user_id=current_user.id,
        details=f"Created/activated document category '{row.name}'.",
        ip_address=request.client.host if request.client else "",
    )
    return _category_response(row)


@router.patch("/api/document-categories/{category_id}", response_model=DocumentCategoryResponse)
def update_document_category(
    category_id: int,
    payload: DocumentCategoryUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*CATEGORY_CONFIG_ROLES)),
):
    try:
        row = workspace_service.update_category(
            db,
            category_id,
            display_name=payload.display_name,
            description=payload.description,
            is_active=payload.is_active,
        )
    except workspace_service.WorkspaceAccessError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    audit_service.log_action(
        db, action="document_category_updated", actor_email=current_user.email, user_id=current_user.id,
        details=f"Updated document category '{row.name}'.",
        ip_address=request.client.host if request.client else "",
    )
    return _category_response(row)
