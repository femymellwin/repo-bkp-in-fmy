from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.audit import AuditLogResponse
from app.api.deps import require_roles
from app.core.permissions import AUDIT_LOG_ROLES
from app.models.user import User
from app.models.audit_log import AuditLog

router = APIRouter(prefix="/api/audit-logs", tags=["audit-logs"])


@router.get("", response_model=list[AuditLogResponse])
def list_audit_logs(
    limit: int = 200,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*AUDIT_LOG_ROLES)),
):
    return (
        db.query(AuditLog)
        .order_by(AuditLog.created_at.desc())
        .limit(min(limit, 1000))
        .all()
    )
