from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, require_roles
from app.core.permissions import RoleName
from app.models.user import User
from app.models.teacher_profile import TeacherProfile
from app.schemas.teacher_profile import TeacherProfileResponse, TeacherProfileUpdate
from app.services import audit_service

router = APIRouter(prefix="/api/teacher-profiles", tags=["teacher-profiles"])
VIEW_ROLES = (RoleName.TEACHER.value, RoleName.PRINCIPAL.value, RoleName.SCHOOL_ADMIN.value)


def _response(profile: TeacherProfile) -> TeacherProfileResponse:
    user = profile.user
    return TeacherProfileResponse(
        id=profile.id,
        user_id=profile.user_id,
        full_name=user.full_name if user else "Unknown",
        email=user.email if user else "",
        role=user.role if user else "",
        preferred_name=profile.preferred_name or "",
        subjects=profile.subjects or "",
        grades=profile.grades or "",
        bio=profile.bio or "",
        classroom_location=profile.classroom_location or "",
        office_hours=profile.office_hours or "",
        extracurricular_roles=profile.extracurricular_roles or "",
        rag_notes=profile.rag_notes or "",
        updated_at=profile.updated_at,
    )


def _ensure_profile(db: Session, user: User) -> TeacherProfile:
    profile = db.query(TeacherProfile).filter(TeacherProfile.user_id == user.id).first()
    if profile:
        return profile
    profile = TeacherProfile(user_id=user.id, preferred_name=user.full_name)
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile


@router.get("", response_model=list[TeacherProfileResponse])
def list_profiles(db: Session = Depends(get_db), current_user: User = Depends(require_roles(*VIEW_ROLES))):
    rows = db.query(TeacherProfile).join(User).order_by(User.full_name).all()
    return [_response(row) for row in rows]


@router.get("/me", response_model=TeacherProfileResponse)
def get_my_profile(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role not in VIEW_ROLES:
        raise HTTPException(status_code=403, detail="Only teachers and school leadership can use teacher profiles.")
    return _response(_ensure_profile(db, current_user))


@router.put("/me", response_model=TeacherProfileResponse)
def update_my_profile(
    payload: TeacherProfileUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role not in VIEW_ROLES:
        raise HTTPException(status_code=403, detail="Only teachers and school leadership can use teacher profiles.")
    profile = _ensure_profile(db, current_user)
    for key, value in payload.model_dump().items():
        setattr(profile, key, value)
    profile.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(profile)
    audit_service.log_action(
        db, action="teacher_profile_updated", actor_email=current_user.email, user_id=current_user.id,
        details="Updated teacher profile.",
    )
    return _response(profile)
