from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, require_roles
from app.core.permissions import RoleName
from app.models.user import User
from app.models.onboarding import OnboardingItem
from app.schemas.onboarding import OnboardingItemCreate, OnboardingItemUpdate, OnboardingItemResponse
from app.services import audit_service

router = APIRouter(prefix="/api/onboarding", tags=["onboarding"])
VIEW_ROLES = (RoleName.TEACHER.value, RoleName.PRINCIPAL.value, RoleName.SCHOOL_ADMIN.value)
MANAGE_ROLES = (RoleName.PRINCIPAL.value, RoleName.SCHOOL_ADMIN.value)


def _response(item: OnboardingItem) -> OnboardingItemResponse:
    return OnboardingItemResponse(
        id=item.id,
        title=item.title,
        category=item.category,
        owner_user_id=item.owner_user_id,
        owner_name=item.owner.full_name if item.owner else None,
        status=item.status,
        due_date=item.due_date,
        notes=item.notes or "",
        created_at=item.created_at,
        updated_at=item.updated_at,
    )


@router.get("", response_model=list[OnboardingItemResponse])
def list_items(db: Session = Depends(get_db), current_user: User = Depends(require_roles(*VIEW_ROLES))):
    query = db.query(OnboardingItem)
    if current_user.role == RoleName.TEACHER.value:
        query = query.filter((OnboardingItem.owner_user_id == current_user.id) | (OnboardingItem.owner_user_id.is_(None)))
    return [_response(item) for item in query.order_by(OnboardingItem.due_date.is_(None), OnboardingItem.due_date, OnboardingItem.created_at.desc()).all()]


@router.post("", response_model=OnboardingItemResponse)
def create_item(
    payload: OnboardingItemCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    item = OnboardingItem(**payload.model_dump(), created_by_id=current_user.id)
    db.add(item)
    db.commit()
    db.refresh(item)
    audit_service.log_action(
        db, action="onboarding_item_created", actor_email=current_user.email, user_id=current_user.id,
        details=f"Created onboarding item '{item.title}'.",
    )
    return _response(item)


@router.patch("/{item_id}", response_model=OnboardingItemResponse)
def update_item(
    item_id: int,
    payload: OnboardingItemUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    item = db.query(OnboardingItem).filter(OnboardingItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Onboarding item not found.")
    is_manager = current_user.role in MANAGE_ROLES
    is_owner = item.owner_user_id == current_user.id
    if not (is_manager or is_owner):
        raise HTTPException(status_code=403, detail="You can only update your own onboarding items.")

    updates = payload.model_dump(exclude_unset=True)
    if not is_manager:
        updates = {k: v for k, v in updates.items() if k in {"status", "notes"}}
    for key, value in updates.items():
        setattr(item, key, value)
    item.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(item)
    audit_service.log_action(
        db, action="onboarding_item_updated", actor_email=current_user.email, user_id=current_user.id,
        details=f"Updated onboarding item '{item.title}'.",
    )
    return _response(item)


@router.delete("/{item_id}")
def delete_item(
    item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    item = db.query(OnboardingItem).filter(OnboardingItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Onboarding item not found.")
    title = item.title
    db.delete(item)
    db.commit()
    audit_service.log_action(
        db, action="onboarding_item_deleted", actor_email=current_user.email, user_id=current_user.id,
        details=f"Deleted onboarding item '{title}'.",
    )
    return {"message": f"Deleted '{title}'."}
