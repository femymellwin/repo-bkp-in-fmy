from fastapi import APIRouter, Depends, HTTPException, Request, Query
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.database import get_db
from app.models.user import User
from app.schemas.chat import (
    ChatBootstrapResponse,
    ChatMessageResponse,
    ChatProjectCreate,
    ChatProjectResponse,
    ChatProjectUpdate,
    ChatThreadCreate,
    ChatThreadResponse,
    ChatThreadUpdate,
)
from app.services import audit_service, chat_service, web_search_service

router = APIRouter(prefix="/api/chat", tags=["chat"])


def _project_response(item: dict) -> ChatProjectResponse:
    return ChatProjectResponse(**item)


def _thread_response(item: dict) -> ChatThreadResponse:
    return ChatThreadResponse(**item)


@router.get("/bootstrap", response_model=ChatBootstrapResponse)
def bootstrap_chat(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    default_project = chat_service.ensure_default_project(db, current_user)
    projects = chat_service.list_projects(db, current_user)
    threads = chat_service.list_threads(db, current_user, project_id=default_project.id, limit=80)
    return ChatBootstrapResponse(
        projects=[_project_response(item) for item in projects],
        threads=[_thread_response(item) for item in threads],
        web_search=web_search_service.web_search_status(db, current_user),
    )


@router.get("/projects", response_model=list[ChatProjectResponse])
def list_projects(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return [_project_response(item) for item in chat_service.list_projects(db, current_user)]


@router.post("/projects", response_model=ChatProjectResponse)
def create_project(
    payload: ChatProjectCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = chat_service.create_project(db, current_user, payload.name, payload.description, payload.color)
    audit_service.log_action(
        db, action="chat_project_created", actor_email=current_user.email, user_id=current_user.id,
        details=f"Created chat project '{project.name}'.",
        ip_address=request.client.host if request.client else "",
    )
    db.commit()
    return ChatProjectResponse(
        id=project.id,
        name=project.name,
        description=project.description or "",
        color=project.color or "indigo",
        is_default=bool(project.is_default),
        thread_count=0,
        created_at=project.created_at,
        updated_at=project.updated_at,
    )


@router.patch("/projects/{project_id}", response_model=ChatProjectResponse)
def update_project(
    project_id: int,
    payload: ChatProjectUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        project = chat_service.update_project(db, current_user, project_id, payload.name, payload.description, payload.color)
    except chat_service.ChatAccessError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    audit_service.log_action(
        db, action="chat_project_updated", actor_email=current_user.email, user_id=current_user.id,
        details=f"Updated chat project '{project.name}'.",
        ip_address=request.client.host if request.client else "",
    )
    db.commit()
    return ChatProjectResponse(
        id=project.id, name=project.name, description=project.description or "", color=project.color or "indigo",
        is_default=bool(project.is_default), thread_count=len([t for t in project.threads if not t.archived]),
        created_at=project.created_at, updated_at=project.updated_at,
    )


@router.delete("/projects/{project_id}")
def delete_project(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        chat_service.archive_project(db, current_user, project_id)
    except chat_service.ChatAccessError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    audit_service.log_action(
        db, action="chat_project_archived", actor_email=current_user.email, user_id=current_user.id,
        details=f"Archived chat project id={project_id}.", ip_address=request.client.host if request.client else "",
    )
    db.commit()
    return {"message": "Project archived."}


@router.get("/threads", response_model=list[ChatThreadResponse])
def list_threads(
    project_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if project_id is not None:
        try:
            chat_service.get_project_or_403(db, current_user, project_id)
        except chat_service.ChatAccessError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
    return [_thread_response(item) for item in chat_service.list_threads(db, current_user, project_id=project_id)]


@router.post("/threads", response_model=ChatThreadResponse)
def create_thread(
    payload: ChatThreadCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        thread = chat_service.create_thread(db, current_user, payload.project_id, payload.title, payload.scope_json, payload.web_search_requested)
    except chat_service.ChatAccessError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    audit_service.log_action(
        db, action="chat_thread_created", actor_email=current_user.email, user_id=current_user.id,
        details=f"Created chat '{thread.title}'.", ip_address=request.client.host if request.client else "",
    )
    db.commit()
    return ChatThreadResponse(
        id=thread.id, project_id=thread.project_id, title=thread.title, scope_json=thread.scope_json or {},
        web_search_requested=bool(thread.web_search_requested), message_count=0,
        created_at=thread.created_at, updated_at=thread.updated_at,
    )


@router.patch("/threads/{thread_id}", response_model=ChatThreadResponse)
def update_thread(
    thread_id: int,
    payload: ChatThreadUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        thread = chat_service.rename_thread(db, current_user, thread_id, payload.title or "New chat")
    except chat_service.ChatAccessError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return ChatThreadResponse(
        id=thread.id, project_id=thread.project_id, title=thread.title, scope_json=thread.scope_json or {},
        web_search_requested=bool(thread.web_search_requested), message_count=len(thread.messages),
        created_at=thread.created_at, updated_at=thread.updated_at,
    )


@router.delete("/threads/{thread_id}")
def delete_thread(
    thread_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        chat_service.archive_thread(db, current_user, thread_id)
    except chat_service.ChatAccessError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"message": "Chat archived."}


@router.get("/threads/{thread_id}/messages", response_model=list[ChatMessageResponse])
def list_messages(thread_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    try:
        return [ChatMessageResponse(**item) for item in chat_service.list_messages(db, current_user, thread_id)]
    except chat_service.ChatAccessError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
