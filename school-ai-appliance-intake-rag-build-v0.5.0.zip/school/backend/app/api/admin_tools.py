from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.admin_tools import AdminToolRequest
from app.schemas.teacher_tools import ToolGenerationResponse
from app.services import admin_tools_service, settings_service
from app.api.deps import require_roles
from app.core.permissions import RoleName
from app.models.user import User
from app.models.ai_query import AIQuery

router = APIRouter(prefix="/api/admin-tools", tags=["admin-tools"])

VALID_TOOLS = {"circular", "meeting_agenda", "policy_summary", "staff_announcement", "event_plan"}


@router.post("/generate", response_model=ToolGenerationResponse)
def generate(
    payload: AdminToolRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)),
):
    if payload.tool not in VALID_TOOLS:
        raise HTTPException(status_code=400, detail=f"Invalid tool. Must be one of: {sorted(VALID_TOOLS)}")

    model_cfg = settings_service.get_model_runtime_config(db)
    result = admin_tools_service.generate_admin_tool(
        payload.tool, payload.title, payload.audience, payload.key_points,
        payload.tone, payload.extra_instructions,
        model_name=str(model_cfg["local_model_name"]),
    )
    usage = result.get("usage", {}) or {}

    db.add(AIQuery(
        user_id=current_user.id,
        role_at_time=current_user.role,
        tool=payload.tool,
        question=payload.title,
        answer=result["output"],
        sources=[],
        found_answer=1,
        model_name=str(usage.get("model_name") or model_cfg["local_model_name"]),
        embedding_model=str(model_cfg["embedding_model_name"]),
        prompt_tokens=int(usage.get("prompt_tokens") or 0),
        completion_tokens=int(usage.get("completion_tokens") or 0),
        total_tokens=int(usage.get("total_tokens") or 0),
        duration_ms=int(usage.get("duration_ms") or 0),
        scope_summary="Admin tool generation",
    ))
    db.commit()

    return ToolGenerationResponse(output=result["output"], tool=payload.tool, ollama_available=result["ollama_available"])
