from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.timetable import TimetableEntryCreate, TimetableEntryResponse, TimetableWithConflicts
from app.services import timetable_service
from app.api.deps import get_current_user, require_roles
from app.core.permissions import RoleName
from app.models.user import User

router = APIRouter(prefix="/api/timetable", tags=["timetable"])

MANAGE_ROLES = (RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)


@router.get("", response_model=TimetableWithConflicts)
def get_timetable(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    entries = timetable_service.list_entries(db)
    conflicts = timetable_service.detect_conflicts(entries)
    return TimetableWithConflicts(entries=entries, conflicts=conflicts)


@router.post("", response_model=TimetableEntryResponse)
def create_entry(
    payload: TimetableEntryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    if payload.start_time >= payload.end_time:
        raise HTTPException(status_code=400, detail="Start time must be before end time.")
    return timetable_service.create_entry(db, payload.model_dump())


@router.delete("/{entry_id}")
def delete_entry(
    entry_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    if not timetable_service.delete_entry(db, entry_id):
        raise HTTPException(status_code=404, detail="Timetable entry not found.")
    return {"message": "Timetable entry deleted."}
