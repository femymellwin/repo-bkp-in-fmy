from collections import Counter

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import require_roles
from app.core.permissions import RoleName
from app.models.user import User
from app.models.document import Document, DocumentChunk
from app.services import settings_service, vector_service, audit_service
from app.schemas.rag_audit import (
    ChunkConfig,
    ChunkingConfigResponse,
    ChunkingConfigUpdate,
    UploadPolicyResponse,
    UploadPolicyUpdate,
    RagDocumentAudit,
    RagChunkAudit,
    RagOverviewResponse,
)

router = APIRouter(prefix="/api/rag-audit", tags=["rag-audit"])
AUDIT_ROLES = (RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)

EXTRACTORS = {
    "pdf": "pypdf text extraction",
    "docx": "python-docx paragraphs and tables",
    "txt": "UTF-8/Latin-1/plain text decode",
    "csv": "pandas CSV table-to-text",
    "xlsx": "pandas Excel sheet-to-text",
}


def _chunking_response(db: Session) -> ChunkingConfigResponse:
    cfg = settings_service.get_chunking_by_file_type(db)
    return ChunkingConfigResponse(
        strategy=settings_service.get_setting(db, "chunking_strategy") or "word_sliding_window",
        default_chunk_size=int(settings_service.get_setting(db, "default_chunk_size") or 800),
        default_chunk_overlap=int(settings_service.get_setting(db, "default_chunk_overlap") or 120),
        by_file_type={k: ChunkConfig(**v) for k, v in cfg.items()},
        explanation=(
            "Chunks are word-based sliding windows. The chunk size decides how many words go into each "
            "embedding; overlap repeats words from the previous chunk so answers crossing a boundary are "
            "still retrievable. File-type defaults are now reviewed by the local Adaptive Chunk Agent, "
            "which records the final chunk plan and then runs retrieval quality tests after indexing."
        ),
    )


def _upload_policy_response(db: Session) -> UploadPolicyResponse:
    return UploadPolicyResponse(
        allowed_file_types=settings_service.get_allowed_file_types(db),
        max_file_size_mb=25,
        extractors={k: v for k, v in EXTRACTORS.items() if k in settings_service.get_allowed_file_types(db)},
    )


def _document_audit(document: Document) -> RagDocumentAudit:
    return RagDocumentAudit(
        id=document.id,
        filename=document.filename,
        document_type=document.document_type,
        access_role=document.access_role,
        uploaded_by=document.uploaded_by_user.email if document.uploaded_by_user else "unknown",
        upload_date=document.upload_date,
        ingestion_status=document.ingestion_status,
        chunk_count=document.chunk_count,
        chunk_size=document.chunk_size,
        chunk_overlap=document.chunk_overlap,
        chunking_strategy=document.chunking_strategy,
        extracted_text_chars=document.extracted_text_chars,
        vector_db=document.vector_db,
        vector_collection=document.vector_collection,
        embedding_provider=document.embedding_provider,
        embedding_model=document.embedding_model,
        indexed_at=document.indexed_at,
        index_error=document.index_error or "",
        chunk_agent_name=document.chunk_agent_name or "",
        chunk_agent_reason=document.chunk_agent_reason or "",
        retrieval_test_status=document.retrieval_test_status or "not_run",
        retrieval_test_score=float(document.retrieval_test_score or 0.0),
    )


def _chunk_audit(chunk: DocumentChunk) -> RagChunkAudit:
    text = chunk.text or ""
    return RagChunkAudit(
        id=chunk.id,
        document_id=chunk.document_id,
        filename=chunk.document.filename if chunk.document else "unknown",
        chunk_index=chunk.chunk_index,
        word_count=chunk.word_count or len(text.split()),
        char_count=chunk.char_count or len(text),
        vector_id=chunk.vector_id,
        preview=(text[:280] + "…") if len(text) > 280 else text,
    )


@router.get("/overview", response_model=RagOverviewResponse)
def overview(db: Session = Depends(get_db), current_user: User = Depends(require_roles(*AUDIT_ROLES))):
    docs = db.query(Document).order_by(Document.upload_date.desc()).all()
    chunks = db.query(DocumentChunk).join(Document).order_by(DocumentChunk.id.desc()).limit(20).all()
    status_counts = Counter(d.ingestion_status for d in docs)
    by_day = Counter(d.upload_date.date().isoformat() for d in docs)
    total_chunks = sum(d.chunk_count for d in docs)
    completed_docs = [d for d in docs if d.ingestion_status == "completed"]
    avg_chunks = round(total_chunks / len(completed_docs), 2) if completed_docs else 0
    avg_chunk_words = 0
    chunk_rows = db.query(DocumentChunk).all()
    if chunk_rows:
        avg_chunk_words = round(sum(c.word_count or len((c.text or '').split()) for c in chunk_rows) / len(chunk_rows), 2)

    return RagOverviewResponse(
        vector_db=vector_service.vector_metadata(),
        chunking=_chunking_response(db),
        upload_policy=_upload_policy_response(db),
        totals={
            "documents": len(docs),
            "completed": status_counts.get("completed", 0),
            "processing": status_counts.get("processing", 0),
            "failed": status_counts.get("failed", 0),
            "pending": status_counts.get("pending", 0),
            "chunks": total_chunks,
            "average_chunks_per_completed_document": avg_chunks,
            "average_chunk_words": avg_chunk_words,
        },
        ingestion_trend=[{"date": day, "uploads": count} for day, count in sorted(by_day.items())],
        documents=[_document_audit(d) for d in docs],
        recent_chunks=[_chunk_audit(c) for c in chunks],
    )


@router.get("/chunking-config", response_model=ChunkingConfigResponse)
def get_chunking_config(db: Session = Depends(get_db), current_user: User = Depends(require_roles(*AUDIT_ROLES))):
    return _chunking_response(db)


@router.put("/chunking-config", response_model=ChunkingConfigResponse)
def update_chunking_config(
    payload: ChunkingConfigUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value)),
):
    settings_service.set_chunking_by_file_type(db, {k: v.model_dump() for k, v in payload.by_file_type.items()})
    audit_service.log_action(
        db, action="rag_chunking_config_updated", actor_email=current_user.email, user_id=current_user.id,
        details="Updated file-type chunking configuration.",
    )
    return _chunking_response(db)


@router.get("/upload-policy", response_model=UploadPolicyResponse)
def get_upload_policy(db: Session = Depends(get_db), current_user: User = Depends(require_roles(*AUDIT_ROLES))):
    return _upload_policy_response(db)


@router.put("/upload-policy", response_model=UploadPolicyResponse)
def update_upload_policy(
    payload: UploadPolicyUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value)),
):
    settings_service.set_allowed_file_types(db, payload.allowed_file_types)
    audit_service.log_action(
        db, action="upload_policy_updated", actor_email=current_user.email, user_id=current_user.id,
        details=f"Allowed file types set to {payload.allowed_file_types}.",
    )
    return _upload_policy_response(db)


@router.get("/documents/{document_id}/chunks", response_model=list[RagChunkAudit])
def document_chunks(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*AUDIT_ROLES)),
):
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found.")
    chunks = db.query(DocumentChunk).filter(DocumentChunk.document_id == document_id).order_by(DocumentChunk.chunk_index).all()
    return [_chunk_audit(c) for c in chunks]
