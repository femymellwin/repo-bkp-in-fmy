from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.teacher_tools import TeacherToolRequest, ToolGenerationResponse
from app.services import teacher_tools_service, settings_service
from app.api.deps import require_roles
from app.core.permissions import RoleName
from app.models.user import User
from app.models.ai_query import AIQuery

router = APIRouter(prefix="/api/teacher-tools", tags=["teacher-tools"])

VALID_TOOLS = {"lesson_plan", "worksheet", "quiz", "parent_message", "feedback_comment"}


@router.post("/generate", response_model=ToolGenerationResponse)
def generate(
    payload: TeacherToolRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(RoleName.TEACHER.value, RoleName.PRINCIPAL.value, RoleName.SCHOOL_ADMIN.value)),
):
    if payload.tool not in VALID_TOOLS:
        raise HTTPException(status_code=400, detail=f"Invalid tool. Must be one of: {sorted(VALID_TOOLS)}")

    model_cfg = settings_service.get_model_runtime_config(db)
    result = teacher_tools_service.generate_teacher_tool(
        payload.tool, payload.grade, payload.subject, payload.topic,
        payload.duration, payload.difficulty, payload.extra_instructions,
        model_name=str(model_cfg["local_model_name"]),
    )
    usage = result.get("usage", {}) or {}

    db.add(AIQuery(
        user_id=current_user.id,
        role_at_time=current_user.role,
        tool=payload.tool,
        question=f"{payload.subject} / {payload.topic} (Grade {payload.grade})",
        answer=result["output"],
        sources=[],
        found_answer=1,
        model_name=str(usage.get("model_name") or model_cfg["local_model_name"]),
        embedding_model=str(model_cfg["embedding_model_name"]),
        prompt_tokens=int(usage.get("prompt_tokens") or 0),
        completion_tokens=int(usage.get("completion_tokens") or 0),
        total_tokens=int(usage.get("total_tokens") or 0),
        duration_ms=int(usage.get("duration_ms") or 0),
        scope_summary="Teacher tool generation",
    ))
    db.commit()

    return ToolGenerationResponse(output=result["output"], tool=payload.tool, ollama_available=result["ollama_available"])
