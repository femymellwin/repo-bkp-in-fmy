from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.system import SystemHealthResponse
from app.services import system_health_service
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("/health", response_model=SystemHealthResponse)
def get_health(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return system_health_service.get_system_health(db)
