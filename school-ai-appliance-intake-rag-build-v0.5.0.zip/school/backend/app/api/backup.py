from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.backup import BackupRecordResponse
from app.services import backup_service, audit_service
from app.api.deps import require_roles
from app.core.permissions import SYSTEM_ADMIN_ROLES
from app.models.user import User

router = APIRouter(prefix="/api/backup", tags=["backup"])


@router.get("", response_model=list[BackupRecordResponse])
def list_backups(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*SYSTEM_ADMIN_ROLES)),
):
    return backup_service.list_backups(db)


@router.post("", response_model=BackupRecordResponse)
def create_backup(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*SYSTEM_ADMIN_ROLES)),
):
    record = backup_service.create_backup(db, created_by=current_user.email)
    audit_service.log_action(
        db, action="backup_created", actor_email=current_user.email, user_id=current_user.id,
        details=f"Created backup '{record.filename}' ({record.file_size} bytes).",
    )
    return record
