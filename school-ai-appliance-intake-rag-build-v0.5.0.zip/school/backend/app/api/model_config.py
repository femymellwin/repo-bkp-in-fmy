from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import require_roles
from app.core.permissions import RoleName
from app.models.user import User
from app.services import settings_service, audit_service
from app.services.ollama_service import is_ollama_available, list_local_models, model_is_available
from app.schemas.model_config import ModelConfigResponse, ModelConfigUpdate

router = APIRouter(prefix="/api/model-config", tags=["model-config"])
CONFIG_ROLES = (RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value)
VIEW_ROLES = (RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)


def _build_response(db: Session) -> ModelConfigResponse:
    cfg = settings_service.get_model_runtime_config(db)
    available = list_local_models()
    provider = str(cfg["embedding_provider"])
    embedding_model = str(cfg["embedding_model_name"])
    notes: list[str] = []
    if provider == "sentence_transformers":
        notes.append("The embedding model runs inside the backend Python process, so it will not appear as a running Ollama model.")
        embedding_available = True
    else:
        embedding_available = model_is_available(embedding_model)
        notes.append("Ollama embedding models are visible in Ollama only after you pull them, for example: ollama pull embeddinggemma.")
    notes.append("If you change the embedding model after documents were indexed, rebuild the vector store or re-upload/re-index documents so vector dimensions and semantics match.")
    notes.append("The chat model setting is used by Ask AI, Teacher Tools, and Admin Tools without requiring code changes.")

    return ModelConfigResponse(
        ollama_base_url=str(cfg["ollama_base_url"]),
        ollama_status="online" if is_ollama_available() else "offline",
        local_model_name=str(cfg["local_model_name"]),
        local_model_available=model_is_available(str(cfg["local_model_name"])),
        embedding_provider=provider,
        embedding_model_name=embedding_model,
        embedding_model_available=embedding_available,
        available_ollama_models=available,
        rag_top_k=int(cfg["rag_top_k"]),
        notes=notes,
    )


@router.get("", response_model=ModelConfigResponse)
def get_config(db: Session = Depends(get_db), current_user: User = Depends(require_roles(*VIEW_ROLES))):
    return _build_response(db)


@router.put("", response_model=ModelConfigResponse)
def update_config(
    payload: ModelConfigUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*CONFIG_ROLES)),
):
    updates = payload.model_dump(exclude_none=True)
    if "embedding_provider" in updates:
        provider = str(updates["embedding_provider"]).lower()
        if provider not in ("sentence_transformers", "ollama"):
            raise HTTPException(status_code=400, detail="embedding_provider must be sentence_transformers or ollama.")
        updates["embedding_provider"] = provider
    if "rag_top_k" in updates:
        updates["rag_top_k"] = str(max(1, min(int(updates["rag_top_k"]), 20)))
    for key, value in updates.items():
        settings_service.set_setting(db, key, str(value))
    if updates:
        audit_service.log_action(
            db, action="model_config_updated", actor_email=current_user.email, user_id=current_user.id,
            details=f"Updated model configuration: {list(updates.keys())}.",
        )
    return _build_response(db)
