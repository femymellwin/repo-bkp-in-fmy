from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.user import UserCreate, UserResponse, UserUpdateRole, UserUpdate
from app.services import auth_service, audit_service
from app.api.deps import require_roles
from app.core.permissions import SYSTEM_ADMIN_ROLES, RoleName
from app.models.user import User
from app.core.security import hash_password

router = APIRouter(prefix="/api/users", tags=["users"])

VALID_ROLES = {r.value for r in RoleName}


def _normalize_menu_exclusions(value: str | None) -> str:
    if not value:
        return ""
    parts = [p.strip() for p in value.split(",") if p.strip()]
    return ",".join(dict.fromkeys(parts))


@router.get("", response_model=list[UserResponse])
def list_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*SYSTEM_ADMIN_ROLES)),
):
    return db.query(User).order_by(User.created_at.desc()).all()


@router.post("", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*SYSTEM_ADMIN_ROLES)),
):
    if payload.role not in VALID_ROLES:
        raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {sorted(VALID_ROLES)}")
    if auth_service.get_user_by_email(db, payload.email):
        raise HTTPException(status_code=400, detail="A user with this email already exists.")

    user = auth_service.create_user(db, payload.full_name, payload.email, payload.password, payload.role)
    user.is_active = payload.is_active
    user.menu_exclusions = _normalize_menu_exclusions(payload.menu_exclusions)
    user.web_search_enabled = bool(payload.web_search_enabled)
    db.commit()
    db.refresh(user)
    audit_service.log_action(
        db, action="user_creation", actor_email=current_user.email, user_id=current_user.id,
        details=f"Created user {user.email} with role {user.role}.",
    )
    return user


@router.patch("/{user_id}", response_model=UserResponse)
def update_user(
    user_id: int,
    payload: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*SYSTEM_ADMIN_ROLES)),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    changes: list[str] = []
    if payload.full_name is not None:
        user.full_name = payload.full_name
        changes.append("full_name")
    if payload.email is not None:
        email = payload.email.lower()
        existing = db.query(User).filter(User.email == email, User.id != user_id).first()
        if existing:
            raise HTTPException(status_code=400, detail="A user with this email already exists.")
        user.email = email
        changes.append("email")
    if payload.role is not None:
        if payload.role not in VALID_ROLES:
            raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {sorted(VALID_ROLES)}")
        user.role = payload.role
        changes.append("role")
    if payload.is_active is not None:
        if user.id == current_user.id and payload.is_active is False:
            raise HTTPException(status_code=400, detail="You cannot deactivate your own account.")
        user.is_active = payload.is_active
        changes.append("is_active")
    if payload.menu_exclusions is not None:
        user.menu_exclusions = _normalize_menu_exclusions(payload.menu_exclusions)
        changes.append("menu_exclusions")
    if payload.web_search_enabled is not None:
        user.web_search_enabled = bool(payload.web_search_enabled)
        changes.append("web_search_enabled")
    if payload.password:
        user.hashed_password = hash_password(payload.password)
        changes.append("password")

    db.commit()
    db.refresh(user)
    if changes:
        audit_service.log_action(
            db, action="user_updated", actor_email=current_user.email, user_id=current_user.id,
            details=f"Updated user {user.email}: {changes}.",
        )
    return user


@router.patch("/{user_id}/role", response_model=UserResponse)
def change_role(
    user_id: int,
    payload: UserUpdateRole,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*SYSTEM_ADMIN_ROLES)),
):
    if payload.role not in VALID_ROLES:
        raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {sorted(VALID_ROLES)}")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    old_role = user.role
    user.role = payload.role
    db.commit()
    db.refresh(user)

    audit_service.log_action(
        db, action="role_change", actor_email=current_user.email, user_id=current_user.id,
        details=f"Changed role of {user.email} from {old_role} to {user.role}.",
    )
    return user
