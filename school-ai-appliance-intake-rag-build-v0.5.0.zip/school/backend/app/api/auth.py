from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.auth import LoginRequest, TokenResponse, UserOut
from app.services import auth_service, audit_service
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    client_ip = request.client.host if request.client else ""
    user = auth_service.authenticate_user(db, payload.email, payload.password)

    if not user:
        audit_service.log_action(
            db, action="failed_login", actor_email=payload.email,
            details="Invalid email or password.", ip_address=client_ip,
        )
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password.")

    auth_service.mark_login(db, user)
    token = auth_service.issue_token_for_user(user)
    audit_service.log_action(
        db, action="login", actor_email=user.email, user_id=user.id, ip_address=client_ip,
    )
    return TokenResponse(access_token=token, user=UserOut.model_validate(user))


@router.get("/me", response_model=UserOut)
def get_me(current_user: User = Depends(get_current_user)):
    return UserOut.model_validate(current_user)
