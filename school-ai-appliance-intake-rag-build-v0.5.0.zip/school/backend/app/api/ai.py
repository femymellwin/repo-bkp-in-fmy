from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.database import get_db
from app.models.ai_query import AIQuery
from app.models.user import User
from app.schemas.ai import AIHistoryItem, AskAIRequest, AskAIResponse
from app.services import ai_service, audit_service, chat_service

router = APIRouter(prefix="/api/ai", tags=["ai"])


def _history_item(row: AIQuery) -> AIHistoryItem:
    return AIHistoryItem(
        id=row.id,
        tool=row.tool,
        question=row.question,
        answer=row.answer,
        sources=row.sources or [],
        web_sources=row.web_sources or [],
        found_answer=bool(row.found_answer),
        model_name=row.model_name or "",
        embedding_model=row.embedding_model or "",
        prompt_tokens=row.prompt_tokens or 0,
        completion_tokens=row.completion_tokens or 0,
        total_tokens=row.total_tokens or 0,
        duration_ms=row.duration_ms or 0,
        scope_summary=row.scope_summary or "All accessible documents",
        used_web_search=bool(row.used_web_search),
        web_search_provider=row.web_search_provider or "",
        project_id=row.project_id,
        thread_id=row.thread_id,
        created_at=row.created_at,
    )


@router.post("/ask", response_model=AskAIResponse)
def ask_school_ai(
    payload: AskAIRequest,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    scope_dict = payload.scope.model_dump() if payload.scope else {}
    thread = chat_service.get_or_create_thread_for_question(
        db,
        current_user,
        payload.question,
        thread_id=payload.thread_id,
        project_id=payload.project_id,
        scope_json=scope_dict,
        web_search_requested=bool(payload.use_web_search),
    )
    chat_service.add_message(db, thread, "user", payload.question, scope_summary="Pending question")

    result = ai_service.ask_school_ai(
        db,
        current_user,
        payload.question,
        payload.scope,
        use_web_search=payload.use_web_search,
    )
    usage = result.get("usage", {}) or {}
    workspace_id = payload.scope.workspace_id if payload.scope else None

    chat_service.add_message(
        db,
        thread,
        "assistant",
        result["answer"],
        sources=result.get("sources", []),
        web_sources=result.get("web_sources", []),
        usage=usage,
        scope_summary=str(result.get("scope_summary") or "All accessible documents"),
        used_web_search=bool(result.get("web_search_used")),
    )

    db.add(AIQuery(
        user_id=current_user.id,
        role_at_time=current_user.role,
        tool="ask_school_ai",
        question=payload.question,
        answer=result["answer"],
        sources=result.get("sources", []),
        found_answer=1 if result["found_answer"] else 0,
        model_name=str(usage.get("model_name") or ""),
        embedding_model=str(usage.get("embedding_model") or ""),
        prompt_tokens=int(usage.get("prompt_tokens") or 0),
        completion_tokens=int(usage.get("completion_tokens") or 0),
        total_tokens=int(usage.get("total_tokens") or 0),
        duration_ms=int(usage.get("duration_ms") or 0),
        scope_summary=str(result.get("scope_summary") or "All accessible documents"),
        workspace_id=workspace_id,
        project_id=thread.project_id,
        thread_id=thread.id,
        used_web_search=1 if result.get("web_search_used") else 0,
        web_search_provider=str((result.get("web_sources") or [{}])[0].get("provider", "") if result.get("web_sources") else ""),
        web_sources=result.get("web_sources", []),
    ))
    audit_service.log_action(
        db, action="ai_query", actor_email=current_user.email, user_id=current_user.id,
        details=(
            f"Asked School AI: '{payload.question[:120]}' | scope: {result.get('scope_summary', '')[:180]} | "
            f"web: {result.get('web_search_status', 'disabled')}"
        ),
        ip_address=request.client.host if request.client else "",
    )
    db.commit()

    return AskAIResponse(**{**result, "project_id": thread.project_id, "thread_id": thread.id})


@router.get("/history", response_model=list[AIHistoryItem])
def get_my_ai_history(
    limit: int = Query(default=40, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    rows = (
        db.query(AIQuery)
        .filter(AIQuery.user_id == current_user.id, AIQuery.tool == "ask_school_ai")
        .order_by(AIQuery.created_at.desc())
        .limit(limit)
        .all()
    )
    return [_history_item(row) for row in rows]


@router.delete("/history")
def clear_my_ai_history(
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    deleted = db.query(AIQuery).filter(AIQuery.user_id == current_user.id, AIQuery.tool == "ask_school_ai").delete()
    audit_service.log_action(
        db, action="ai_history_cleared", actor_email=current_user.email, user_id=current_user.id,
        details=f"Cleared {deleted} Ask AI history rows.",
        ip_address=request.client.host if request.client else "",
    )
    db.commit()
    return {"message": f"Cleared {deleted} chat history items."}
