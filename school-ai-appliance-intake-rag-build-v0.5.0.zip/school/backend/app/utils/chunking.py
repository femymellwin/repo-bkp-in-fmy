def chunk_text(text: str, chunk_size: int = 800, overlap: int = 120) -> list[str]:
    """
    Splits text into overlapping word-based chunks suitable for embedding.
    Simple, dependency-free sliding window chunker - good enough for a
    local prototype; swap for a smarter splitter later if needed.
    """
    words = text.split()
    if not words:
        return []

    chunks: list[str] = []
    start = 0
    while start < len(words):
        end = min(start + chunk_size, len(words))
        chunk = " ".join(words[start:end])
        if chunk.strip():
            chunks.append(chunk.strip())
        if end == len(words):
            break
        start = end - overlap if end - overlap > start else end
    return chunks
