"""
Extracts plain text from uploaded document bytes.

Everything runs in-memory using local libraries only (pypdf, python-docx,
openpyxl/pandas) - no external services are called.
"""
import io

import pandas as pd
from pypdf import PdfReader
from docx import Document as DocxDocument


def extract_text(file_bytes: bytes, document_type: str) -> str:
    document_type = document_type.lower().lstrip(".")

    if document_type == "pdf":
        return _extract_pdf(file_bytes)
    if document_type == "docx":
        return _extract_docx(file_bytes)
    if document_type == "txt":
        return _extract_txt(file_bytes)
    if document_type == "csv":
        return _extract_csv(file_bytes)
    if document_type == "xlsx":
        return _extract_xlsx(file_bytes)

    raise ValueError(f"Unsupported document type for text extraction: {document_type}")


def _extract_pdf(file_bytes: bytes) -> str:
    reader = PdfReader(io.BytesIO(file_bytes))
    pages = []
    for page in reader.pages:
        text = page.extract_text() or ""
        pages.append(text)
    return "\n\n".join(pages).strip()


def _extract_docx(file_bytes: bytes) -> str:
    doc = DocxDocument(io.BytesIO(file_bytes))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells)
            if row_text.strip(" |"):
                parts.append(row_text)
    return "\n".join(parts).strip()


def _extract_txt(file_bytes: bytes) -> str:
    for encoding in ("utf-8", "latin-1"):
        try:
            return file_bytes.decode(encoding).strip()
        except UnicodeDecodeError:
            continue
    return file_bytes.decode("utf-8", errors="ignore").strip()


def _extract_csv(file_bytes: bytes) -> str:
    df = pd.read_csv(io.BytesIO(file_bytes))
    return df.to_string(index=False)


def _extract_xlsx(file_bytes: bytes) -> str:
    sheets = pd.read_excel(io.BytesIO(file_bytes), sheet_name=None)
    parts = []
    for sheet_name, df in sheets.items():
        parts.append(f"--- Sheet: {sheet_name} ---")
        parts.append(df.to_string(index=False))
    return "\n\n".join(parts)
