import uuid
from pathlib import Path
from collections.abc import Iterable


DEFAULT_ALLOWED_EXTENSIONS = {"pdf", "docx", "txt", "csv", "xlsx"}
# Backwards-compatible alias for older imports. Upload enforcement now uses the
# database-backed policy in settings_service via the documents API.
ALLOWED_EXTENSIONS = DEFAULT_ALLOWED_EXTENSIONS


def new_encrypted_filename(original_filename: str) -> str:
    ext = Path(original_filename).suffix.lower().lstrip(".") or "bin"
    return f"{uuid.uuid4().hex}.{ext}.enc"


def get_extension(filename: str) -> str:
    return Path(filename).suffix.lower().lstrip(".")


def is_allowed_extension(filename: str, allowed_extensions: Iterable[str] | None = None) -> bool:
    allowed = {item.lower().lstrip(".") for item in (allowed_extensions or DEFAULT_ALLOWED_EXTENSIONS)}
    return get_extension(filename) in allowed


def human_readable_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ["B", "KB", "MB", "GB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"
