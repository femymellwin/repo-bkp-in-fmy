from datetime import datetime

from sqlalchemy.orm import Session

from app.models.user import User
from app.core.security import verify_password, hash_password, create_access_token


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email.lower()).first()


def authenticate_user(db: Session, email: str, password: str) -> User | None:
    user = get_user_by_email(db, email)
    if not user or not user.is_active:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user


def create_user(db: Session, full_name: str, email: str, password: str, role: str) -> User:
    user = User(
        full_name=full_name,
        email=email.lower(),
        hashed_password=hash_password(password),
        role=role,
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def issue_token_for_user(user: User) -> str:
    return create_access_token(subject=str(user.id), extra_claims={"role": user.role, "email": user.email})


def mark_login(db: Session, user: User) -> None:
    user.last_login_at = datetime.utcnow()
    db.commit()
