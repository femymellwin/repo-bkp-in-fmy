from app.services.ollama_service import chat_completion_with_usage, is_ollama_available, OllamaUnavailableError

SYSTEM_PROMPT = (
    "You are an administrative writing assistant for a private school. Produce polished, "
    "professionally formatted documents ready to send, using clear structure and headings "
    "where appropriate. Match the requested tone."
)

PROMPT_TEMPLATES = {
    "circular": (
        "Draft a school circular.\nTitle: {title}\nAudience: {audience}\nTone: {tone}\n"
        "Key points to include: {key_points}\nExtra instructions: {extra_instructions}\n\n"
        "Format as: Title, Date placeholder, Salutation, Body, Closing, Signature block placeholder."
    ),
    "meeting_agenda": (
        "Draft a meeting agenda.\nMeeting title: {title}\nAudience/Attendees: {audience}\n"
        "Key points/topics: {key_points}\nExtra instructions: {extra_instructions}\n\n"
        "Format as: Meeting title, Date/Time/Location placeholders, numbered agenda items with "
        "estimated time allocations, and an 'Any Other Business' item."
    ),
    "policy_summary": (
        "Summarize a school policy for a general audience.\nPolicy title: {title}\n"
        "Audience: {audience}\nKey points: {key_points}\nExtra instructions: {extra_instructions}\n\n"
        "Produce a plain-language summary with bullet points covering scope, key rules, and "
        "who to contact for questions."
    ),
    "staff_announcement": (
        "Draft a staff announcement.\nTitle: {title}\nAudience: {audience}\nTone: {tone}\n"
        "Key points: {key_points}\nExtra instructions: {extra_instructions}\n\n"
        "Keep it clear and concise, with the most important information first."
    ),
    "event_plan": (
        "Draft an event plan.\nEvent title: {title}\nAudience: {audience}\n"
        "Key points/requirements: {key_points}\nExtra instructions: {extra_instructions}\n\n"
        "Structure as: Event Overview, Objectives, Date/Time/Venue placeholders, Logistics "
        "Checklist, Roles & Responsibilities, and Budget Considerations (high level)."
    ),
}


def generate_admin_tool(
    tool: str, title: str, audience: str, key_points: str, tone: str, extra_instructions: str, model_name: str | None = None
) -> dict:
    if tool not in PROMPT_TEMPLATES:
        raise ValueError(f"Unknown admin tool: {tool}")

    if not is_ollama_available():
        return {
            "output": "The local AI model (Ollama) is not reachable. Start it with 'ollama serve' and try again.",
            "ollama_available": False,
            "usage": {"model_name": model_name or "", "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "duration_ms": 0},
        }

    prompt = PROMPT_TEMPLATES[tool].format(
        title=title, audience=audience or "All Staff", key_points=key_points or "None provided",
        tone=tone or "formal", extra_instructions=extra_instructions or "None",
    )
    try:
        completion = chat_completion_with_usage(SYSTEM_PROMPT, prompt, model=model_name, temperature=0.5)
        output = str(completion.get("answer") or "")
    except OllamaUnavailableError as exc:
        return {"output": str(exc), "ollama_available": False, "usage": {"model_name": model_name or "", "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "duration_ms": 0}}

    usage = {
        "model_name": str(completion.get("model_name") or model_name or ""),
        "prompt_tokens": int(completion.get("prompt_tokens") or 0),
        "completion_tokens": int(completion.get("completion_tokens") or 0),
        "total_tokens": int(completion.get("total_tokens") or 0),
        "duration_ms": int(completion.get("duration_ms") or 0),
    }
    return {"output": output, "ollama_available": True, "usage": usage}
