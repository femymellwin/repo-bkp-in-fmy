from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.document import Document
from app.models.ai_query import AIQuery
from app.models.workspace import Workspace


def _point_rows(rows) -> list[dict]:
    return [{"label": str(label or "Unknown"), "value": float(value or 0)} for label, value in rows]


def get_analytics(db: Session) -> dict:
    query_count = int(db.query(func.count(AIQuery.id)).scalar() or 0)
    total_tokens = int(db.query(func.coalesce(func.sum(AIQuery.total_tokens), 0)).scalar() or 0)
    prompt_tokens = int(db.query(func.coalesce(func.sum(AIQuery.prompt_tokens), 0)).scalar() or 0)
    completion_tokens = int(db.query(func.coalesce(func.sum(AIQuery.completion_tokens), 0)).scalar() or 0)
    avg_duration_ms = float(db.query(func.coalesce(func.avg(AIQuery.duration_ms), 0)).scalar() or 0)
    document_count = int(db.query(func.count(Document.id)).scalar() or 0)
    workspace_count = int(db.query(func.count(Workspace.id)).scalar() or 0)
    completed_documents = int(db.query(func.count(Document.id)).filter(Document.ingestion_status == "completed").scalar() or 0)
    web_search_queries = int(db.query(func.count(AIQuery.id)).filter(AIQuery.used_web_search == 1).scalar() or 0)

    model_rows = (
        db.query(
            AIQuery.model_name,
            func.count(AIQuery.id),
            func.coalesce(func.sum(AIQuery.prompt_tokens), 0),
            func.coalesce(func.sum(AIQuery.completion_tokens), 0),
            func.coalesce(func.sum(AIQuery.total_tokens), 0),
            func.coalesce(func.avg(AIQuery.duration_ms), 0),
        )
        .group_by(AIQuery.model_name)
        .order_by(func.count(AIQuery.id).desc())
        .all()
    )
    model_usage = [
        {
            "label": model or "Unknown model",
            "query_count": int(count or 0),
            "prompt_tokens": int(p_tokens or 0),
            "completion_tokens": int(c_tokens or 0),
            "total_tokens": int(t_tokens or 0),
            "avg_duration_ms": float(avg_ms or 0),
        }
        for model, count, p_tokens, c_tokens, t_tokens, avg_ms in model_rows
    ] or [{"label": "No AI usage yet", "query_count": 0, "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "avg_duration_ms": 0.0}]

    query_role_rows = (
        db.query(AIQuery.role_at_time, func.count(AIQuery.id))
        .group_by(AIQuery.role_at_time)
        .order_by(func.count(AIQuery.id).desc())
        .all()
    )
    tool_rows = (
        db.query(AIQuery.tool, func.count(AIQuery.id))
        .group_by(AIQuery.tool)
        .order_by(func.count(AIQuery.id).desc())
        .all()
    )
    doc_rows = (
        db.query(Document.access_role, func.count(Document.id))
        .group_by(Document.access_role)
        .order_by(func.count(Document.id).desc())
        .all()
    )
    doc_type_rows = (
        db.query(Document.document_type, func.count(Document.id))
        .group_by(Document.document_type)
        .order_by(func.count(Document.id).desc())
        .all()
    )
    workspace_rows = (
        db.query(Workspace.name, func.count(Document.id))
        .outerjoin(Document, Document.workspace_id == Workspace.id)
        .group_by(Workspace.id, Workspace.name)
        .order_by(func.count(Document.id).desc())
        .all()
    )
    scope_rows = (
        db.query(AIQuery.scope_summary, func.count(AIQuery.id))
        .group_by(AIQuery.scope_summary)
        .order_by(func.count(AIQuery.id).desc())
        .limit(10)
        .all()
    )

    recent_rows = (
        db.query(AIQuery)
        .order_by(AIQuery.created_at.desc())
        .limit(10)
        .all()
    )
    recent = [
        {
            "id": row.id,
            "user_email": row.user.email if row.user else "unknown",
            "question": row.question[:180],
            "model_name": row.model_name or "Unknown model",
            "total_tokens": int(row.total_tokens or 0),
            "duration_ms": int(row.duration_ms or 0),
            "scope_summary": row.scope_summary or "All accessible documents",
            "used_web_search": bool(row.used_web_search),
            "web_sources": row.web_sources or [],
            "created_at": row.created_at,
        }
        for row in recent_rows
    ]

    return {
        "totals": {
            "ai_queries": query_count,
            "total_tokens": total_tokens,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "avg_duration_ms": round(avg_duration_ms, 1),
            "documents": document_count,
            "completed_documents": completed_documents,
            "workspaces": workspace_count,
            "web_search_queries": web_search_queries,
        },
        "model_usage": model_usage,
        "ai_query_count_by_role": _point_rows(query_role_rows) or [{"label": "No AI usage yet", "value": 0}],
        "most_used_ai_tools": _point_rows(tool_rows) or [{"label": "No AI tools used yet", "value": 0}],
        "document_usage_count": _point_rows(doc_rows) or [{"label": "No documents yet", "value": 0}],
        "document_type_usage": _point_rows(doc_type_rows) or [{"label": "No documents yet", "value": 0}],
        "workspace_usage": _point_rows(workspace_rows) or [{"label": "No workspaces yet", "value": 0}],
        "scope_usage": _point_rows(scope_rows) or [{"label": "No scoped questions yet", "value": 0}],
        "recent_ai_queries": recent,
    }
