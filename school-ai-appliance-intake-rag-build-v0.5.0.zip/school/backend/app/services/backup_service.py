import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from sqlalchemy.orm import Session

from app.core.config import get_settings, BASE_DIR
from app.models.backup import BackupRecord

settings = get_settings()


def _snapshot_sqlite(db_path: Path, dest_path: Path) -> None:
    """
    Takes a consistent snapshot of the live SQLite database using SQLite's
    online backup API, so the backup is valid even while the app is
    actively writing (zipping the raw file mid-transaction could otherwise
    capture a corrupt copy).
    """
    src = sqlite3.connect(str(db_path))
    dst = sqlite3.connect(str(dest_path))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def create_backup(db: Session, created_by: str) -> BackupRecord:
    """
    Creates a timestamped ZIP containing:
      - a consistent snapshot of the SQLite database
      - the encrypted documents folder (still encrypted - never decrypted for backup)
      - the vector database folder
      - the .env configuration file (contains the encryption key - keep the
        resulting ZIP itself secured/off-machine for real disaster recovery)
    """
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"backup_{timestamp}.zip"
    zip_path = settings.backup_path / zip_filename

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        db_path = settings.database_path
        if db_path.exists():
            with tempfile.TemporaryDirectory() as tmp_dir:
                snapshot_path = Path(tmp_dir) / db_path.name
                _snapshot_sqlite(db_path, snapshot_path)
                zf.write(snapshot_path, arcname=f"database/{db_path.name}")

        docs_dir = settings.documents_path
        for file_path in docs_dir.rglob("*"):
            if file_path.is_file():
                zf.write(file_path, arcname=f"encrypted_documents/{file_path.relative_to(docs_dir)}")

        vector_dir = settings.vector_db_path
        for file_path in vector_dir.rglob("*"):
            if file_path.is_file():
                zf.write(file_path, arcname=f"vector_store/{file_path.relative_to(vector_dir)}")

        env_path = BASE_DIR / ".env"
        if env_path.exists():
            zf.write(env_path, arcname="config/.env")

    file_size = zip_path.stat().st_size
    record = BackupRecord(filename=zip_filename, file_size=file_size, created_by=created_by)
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def list_backups(db: Session) -> list[BackupRecord]:
    return db.query(BackupRecord).order_by(BackupRecord.created_at.desc()).all()


def get_last_backup_date(db: Session) -> str | None:
    latest = db.query(BackupRecord).order_by(BackupRecord.created_at.desc()).first()
    return latest.created_at.isoformat() if latest else None
