from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

import requests
from sqlalchemy.orm import Session

from app.models.user import User
from app.services import settings_service


@dataclass
class WebSearchResult:
    title: str
    url: str
    snippet: str
    provider: str

    def as_dict(self) -> dict[str, str]:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "provider": self.provider,
        }


def _provider_configured(cfg: dict[str, Any]) -> bool:
    provider = str(cfg.get("provider") or "google").lower()
    api_key_set = bool(str(cfg.get("api_key") or ""))
    google_cx_set = bool(str(cfg.get("google_cx") or ""))
    searxng_url_set = bool(str(cfg.get("searxng_url") or ""))
    if provider == "google":
        return api_key_set and google_cx_set
    if provider == "brave":
        return api_key_set
    if provider == "searxng":
        return searxng_url_set
    return True


def can_user_use_web_search(db: Session, user: User) -> bool:
    cfg = settings_service.get_web_search_config(db)
    return bool(cfg["enabled"]) and bool(getattr(user, "web_search_enabled", False)) and _provider_configured(cfg)


def web_search_status(db: Session, user: User) -> dict[str, Any]:
    cfg = settings_service.get_web_search_config(db)
    user_enabled = bool(getattr(user, "web_search_enabled", False))
    provider = str(cfg["provider"])
    configured = _provider_configured(cfg)
    return {
        "global_enabled": bool(cfg["enabled"]),
        "user_enabled": user_enabled,
        "provider_configured": configured,
        "allowed": bool(cfg["enabled"]) and user_enabled and configured,
        "provider": provider,
        "max_results": int(cfg["max_results"]),
        "api_key_set": bool(str(cfg.get("api_key") or "")),
        "google_cx_set": bool(str(cfg.get("google_cx") or "")),
        "searxng_url_set": bool(str(cfg.get("searxng_url") or "")),
    }


def _strip_tags(value: str) -> str:
    value = re.sub(r"<script.*?</script>", " ", value, flags=re.I | re.S)
    value = re.sub(r"<style.*?</style>", " ", value, flags=re.I | re.S)
    value = re.sub(r"<[^>]+>", " ", value)
    value = html.unescape(value)
    return re.sub(r"\s+", " ", value).strip()


def _normalize_result(title: str, url: str, snippet: str, provider: str) -> WebSearchResult | None:
    title = _strip_tags(title or "")[:220]
    url = (url or "").strip()[:1000]
    snippet = _strip_tags(snippet or "")[:800]
    if not title or not url:
        return None
    return WebSearchResult(title=title, url=url, snippet=snippet, provider=provider)


def _clean_duckduckgo_url(url: str) -> str:
    url = html.unescape(url)
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    if "uddg" in qs and qs["uddg"]:
        return unquote(qs["uddg"][0])
    return url


def _duckduckgo_search(query: str, max_results: int, timeout_seconds: int) -> list[WebSearchResult]:
    url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
    headers = {
        "User-Agent": "Mozilla/5.0 SchoolAI/0.5 local web search",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    response = requests.get(url, headers=headers, timeout=timeout_seconds)
    response.raise_for_status()
    text = response.text

    results: list[WebSearchResult] = []
    seen: set[str] = set()
    for href, title_html in re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', text, flags=re.I | re.S):
        title = _strip_tags(title_html)
        clean_url = _clean_duckduckgo_url(href)
        # Find a nearby snippet if possible.
        snippet = ""
        pos = text.find(href)
        if pos >= 0:
            local = text[pos:pos + 2500]
            snippet_match = re.search(r'class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</a>|class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</div>', local, flags=re.I | re.S)
            if snippet_match:
                snippet = _strip_tags(next((g for g in snippet_match.groups() if g), ""))
        item = _normalize_result(title, clean_url, snippet, "duckduckgo")
        if item and item.url not in seen:
            seen.add(item.url)
            results.append(item)
        if len(results) >= max_results:
            break
    return results


def _brave_search(query: str, max_results: int, timeout_seconds: int, api_key: str) -> list[WebSearchResult]:
    if not api_key:
        raise RuntimeError("Brave Search is selected but no API key is configured.")
    response = requests.get(
        "https://api.search.brave.com/res/v1/web/search",
        params={"q": query, "count": max_results},
        headers={"X-Subscription-Token": api_key, "Accept": "application/json"},
        timeout=timeout_seconds,
    )
    response.raise_for_status()
    payload = response.json()
    rows = (((payload or {}).get("web") or {}).get("results") or [])[:max_results]
    results: list[WebSearchResult] = []
    for row in rows:
        item = _normalize_result(str(row.get("title") or "Untitled"), str(row.get("url") or ""), str(row.get("description") or ""), "brave")
        if item:
            results.append(item)
    return results


def _google_search(query: str, max_results: int, timeout_seconds: int, api_key: str, cx: str) -> list[WebSearchResult]:
    if not api_key or not cx:
        raise RuntimeError("Google search is selected but the Google API key or Search Engine ID (cx) is missing.")
    response = requests.get(
        "https://www.googleapis.com/customsearch/v1",
        params={"q": query, "key": api_key, "cx": cx, "num": max(1, min(max_results, 10))},
        timeout=timeout_seconds,
    )
    response.raise_for_status()
    payload = response.json()
    rows = (payload or {}).get("items") or []
    results: list[WebSearchResult] = []
    for row in rows[:max_results]:
        item = _normalize_result(
            str(row.get("title") or "Untitled"),
            str(row.get("link") or ""),
            str(row.get("snippet") or ""),
            "google",
        )
        if item:
            results.append(item)
    return results


def _searxng_search(query: str, max_results: int, timeout_seconds: int, base_url: str) -> list[WebSearchResult]:
    if not base_url:
        raise RuntimeError("SearXNG is selected but no SearXNG base URL is configured.")
    response = requests.get(
        f"{base_url.rstrip('/')}/search",
        params={"q": query, "format": "json", "categories": "general", "language": "auto"},
        headers={"Accept": "application/json", "User-Agent": "SchoolAI/0.5"},
        timeout=timeout_seconds,
    )
    response.raise_for_status()
    payload = response.json()
    rows = (payload or {}).get("results") or []
    results: list[WebSearchResult] = []
    for row in rows[:max_results]:
        provider = str(row.get("engine") or "searxng")
        item = _normalize_result(
            str(row.get("title") or "Untitled"),
            str(row.get("url") or ""),
            str(row.get("content") or row.get("snippet") or ""),
            f"searxng:{provider}",
        )
        if item:
            results.append(item)
    return results


def _rewrite_query_for_search(query: str) -> str:
    cleaned = re.sub(r"\s+", " ", query or "").strip()
    lower = cleaned.lower()
    # Help real-time finance/search pages return relevant snippets.
    if "nifty" in lower and any(word in lower for word in ["live", "closing", "close", "point", "price"]):
        return f"NIFTY 50 live close price today NSE {cleaned}"
    if any(word in lower for word in ["today", "current", "latest", "live", "now"]):
        return cleaned
    return cleaned


def search_web(db: Session, query: str) -> tuple[list[dict[str, str]], str]:
    cfg = settings_service.get_web_search_config(db)
    provider = str(cfg["provider"] or "google").lower()
    max_results = int(cfg["max_results"] or 5)
    timeout_seconds = int(cfg["timeout_seconds"] or 8)
    search_query = _rewrite_query_for_search(query)
    try:
        if provider == "google":
            results = _google_search(search_query, max_results, timeout_seconds, str(cfg.get("api_key") or ""), str(cfg.get("google_cx") or ""))
        elif provider == "searxng":
            results = _searxng_search(search_query, max_results, timeout_seconds, str(cfg.get("searxng_url") or ""))
        elif provider == "brave":
            results = _brave_search(search_query, max_results, timeout_seconds, str(cfg.get("api_key") or ""))
        else:
            results = _duckduckgo_search(search_query, max_results, timeout_seconds)
        return [r.as_dict() for r in results[:max_results]], f"ok:{provider}"
    except Exception as exc:
        return [], f"web search unavailable ({provider}): {exc}"
