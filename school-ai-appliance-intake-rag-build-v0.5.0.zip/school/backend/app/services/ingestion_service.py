from datetime import datetime
from pathlib import Path

from sqlalchemy.orm import Session

from app.models.document import Document, DocumentChunk
from app.core.encryption import decrypt_file_from_path
from app.utils.text_extraction import extract_text
from app.utils.chunking import chunk_text
from app.services import vector_service, settings_service, chunk_agent_service


def ingest_document(db: Session, document: Document) -> None:
    """
    Extracts text from the encrypted document, asks the local adaptive chunk
    agent to choose chunk size/overlap, embeds locally, stores vectors in
    ChromaDB, then runs retrieval quality tests. The ingestion decisions and
    quality results are persisted for RAG audit visibility.
    """
    document.ingestion_status = "processing"
    document.index_error = ""
    document.retrieval_test_status = "not_run"
    document.retrieval_test_score = 0.0
    db.commit()

    try:
        raw_bytes = decrypt_file_from_path(Path(document.encrypted_file_path))
        text = extract_text(raw_bytes, document.document_type)
        document.extracted_text_chars = len(text or "")

        if not text.strip():
            document.ingestion_status = "failed"
            document.chunk_count = 0
            document.index_error = "No extractable text was found in this file."
            document.retrieval_test_status = "failed"
            document.retrieval_test_details = "No extractable text; retrieval quality test skipped."
            db.commit()
            return

        chunk_cfg = settings_service.get_chunk_config_for_type(db, document.document_type)
        model_cfg = settings_service.get_model_runtime_config(db)
        base_chunk_size = int(chunk_cfg["chunk_size"])
        base_chunk_overlap = int(chunk_cfg["chunk_overlap"])

        plan = chunk_agent_service.decide_chunk_plan(
            document_type=document.document_type,
            filename=document.filename,
            doc_kind=document.doc_kind or "general",
            text=text,
            default_chunk_size=base_chunk_size,
            default_chunk_overlap=base_chunk_overlap,
        )
        chunk_size = int(plan.chunk_size)
        chunk_overlap = int(plan.chunk_overlap)
        chunking_strategy = str(plan.strategy)

        chunks = chunk_text(text, chunk_size=chunk_size, overlap=chunk_overlap)

        db.query(DocumentChunk).filter(DocumentChunk.document_id == document.id).delete()
        vector_service.delete_document_vectors(document.id)

        vector_ids = [f"doc{document.id}-chunk{i}" for i in range(len(chunks))]
        metadatas = [
            {
                "document_id": document.id,
                "category": document.access_role,
                "filename": document.filename,
                "chunk_index": i,
                "chunk_size": chunk_size,
                "chunk_overlap": chunk_overlap,
                "chunking_strategy": chunking_strategy,
                "chunk_agent": plan.agent_name,
                "document_type": document.document_type,
                "workspace_id": document.workspace_id or 0,
                "doc_kind": document.doc_kind or "general",
                "subject": document.subject or "",
                "grade": document.grade or "",
                "academic_year": document.academic_year or "",
                "uploaded_by_id": document.uploaded_by_id,
                "embedding_provider": model_cfg["embedding_provider"],
                "embedding_model": model_cfg["embedding_model_name"],
            }
            for i in range(len(chunks))
        ]
        vector_service.add_chunks(
            vector_ids,
            chunks,
            metadatas,
            embedding_provider=str(model_cfg["embedding_provider"]),
            embedding_model=str(model_cfg["embedding_model_name"]),
        )

        for i, (chunk, vector_id) in enumerate(zip(chunks, vector_ids)):
            db.add(DocumentChunk(
                document_id=document.id,
                chunk_index=i,
                text=chunk,
                vector_id=vector_id,
                word_count=len(chunk.split()),
                char_count=len(chunk),
            ))

        document.ingestion_status = "completed"
        document.chunk_count = len(chunks)
        document.chunk_size = chunk_size
        document.chunk_overlap = chunk_overlap
        document.chunking_strategy = chunking_strategy
        document.chunk_agent_name = plan.agent_name
        document.chunk_agent_reason = plan.reason
        document.vector_db = vector_service.VECTOR_DB_NAME
        document.vector_collection = vector_service.COLLECTION_NAME
        document.embedding_provider = str(model_cfg["embedding_provider"])
        document.embedding_model = str(model_cfg["embedding_model_name"])
        document.indexed_at = datetime.utcnow()
        document.index_error = ""
        db.commit()

        chunk_agent_service.run_retrieval_quality_tests(db, document, text, chunks, model_cfg)

    except Exception as exc:  # noqa: BLE001 - surface failure state, don't crash the request
        document.ingestion_status = "failed"
        document.index_error = str(exc)[:2000]
        if not document.retrieval_test_status or document.retrieval_test_status == "not_run":
            document.retrieval_test_status = "failed"
            document.retrieval_test_details = f"Indexing failed before quality tests: {exc}"[:4000]
        db.commit()
        raise exc
