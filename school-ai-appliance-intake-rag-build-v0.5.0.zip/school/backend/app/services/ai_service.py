from datetime import date
from typing import Any

from sqlalchemy.orm import Session

from app.models.user import User
from app.services import document_service, settings_service, vector_service, web_search_service
from app.services.ollama_service import OllamaUnavailableError, chat_completion_with_usage, is_ollama_available

NOT_FOUND_MESSAGE = "I could not find this in the uploaded school documents or enabled web search results."
LEGACY_NOT_FOUND_MESSAGE = "I could not find this in the uploaded school documents."

SYSTEM_PROMPT = """You are "School AI", an assistant for a private school.
You answer using only the context supplied by the application. The context can contain:
1. LOCAL DOCUMENT excerpts from encrypted school workspaces.
2. WEB SEARCH excerpts, only when web search is enabled for this user.

Rules:
- Never invent policies, dates, names, numbers, URLs, or school facts.
- Prefer LOCAL DOCUMENT context for school-specific questions.
- Use WEB SEARCH context only for public/current/background information or when the local documents do not contain the answer.
- Clearly distinguish school-document facts from web-search facts when both are used.
- If neither the local context nor the web context contains the answer, respond with exactly:
  "I could not find this in the uploaded school documents or enabled web search results."
- Keep answers concise, clear, and professional.
- When useful, structure answers with short bullet points.
"""


def _scope_to_dict(scope: Any) -> dict[str, Any]:
    if scope is None:
        return {}
    if isinstance(scope, dict):
        return scope
    if hasattr(scope, "model_dump"):
        return scope.model_dump()
    return {
        "workspace_id": getattr(scope, "workspace_id", None),
        "document_ids": getattr(scope, "document_ids", []) or [],
        "categories": getattr(scope, "categories", []) or [],
        "document_types": getattr(scope, "document_types", []) or [],
    }


def _empty_usage(model_cfg: dict[str, str | int]) -> dict[str, str | int]:
    return {
        "model_name": str(model_cfg.get("local_model_name", "")),
        "embedding_model": str(model_cfg.get("embedding_model_name", "")),
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
        "duration_ms": 0,
    }


def _not_found_response(model_cfg: dict[str, str | int], scope_summary: str, web_status: str = "disabled", web_used: bool = False) -> dict:
    return {
        "answer": NOT_FOUND_MESSAGE,
        "sources": [],
        "web_sources": [],
        "found_answer": False,
        "ollama_available": True,
        "scope_summary": scope_summary,
        "usage": _empty_usage(model_cfg),
        "web_search_used": web_used,
        "web_search_status": web_status,
    }


def ask_school_ai(
    db: Session,
    user: User,
    question: str,
    scope: Any = None,
    n_results: int | None = None,
    use_web_search: bool | None = None,
) -> dict:
    model_cfg = settings_service.get_model_runtime_config(db)
    top_k = int(n_results or model_cfg["rag_top_k"])
    scope_dict = _scope_to_dict(scope)
    workspace_id = scope_dict.get("workspace_id")
    document_ids = [int(x) for x in (scope_dict.get("document_ids") or []) if str(x).isdigit()]
    categories = [str(x) for x in (scope_dict.get("categories") or []) if str(x).strip()]
    document_types = [str(x).lower().lstrip(".") for x in (scope_dict.get("document_types") or []) if str(x).strip()]

    scope_summary = document_service.describe_scope(
        db,
        user,
        workspace_id=workspace_id,
        document_ids=document_ids,
        categories=categories,
        document_types=document_types,
    )

    web_allowed = web_search_service.can_user_use_web_search(db, user)
    web_requested = web_allowed if use_web_search is None else bool(use_web_search and web_allowed)
    web_status = "disabled"
    if use_web_search and not web_allowed:
        web_status = "blocked: enable global web search and this user's web permission"
    elif web_requested:
        web_status = "enabled"

    if not is_ollama_available():
        return {
            "answer": (
                "The local AI model (Ollama) is not reachable right now. "
                "Start it with 'ollama serve' and make sure the configured model "
                "has been pulled, then try again."
            ),
            "sources": [],
            "web_sources": [],
            "found_answer": False,
            "ollama_available": False,
            "scope_summary": scope_summary,
            "usage": _empty_usage(model_cfg),
            "web_search_used": False,
            "web_search_status": web_status,
        }

    allowed_document_ids = document_service.get_accessible_document_ids(
        db,
        user,
        workspace_id=workspace_id,
        document_ids=document_ids,
        categories=categories,
        document_types=document_types,
        completed_only=True,
    )

    documents_matched: list[str] = []
    metadatas_matched: list[dict] = []
    if allowed_document_ids:
        results = vector_service.query_similar(
            question,
            allowed_categories=[],
            n_results=top_k,
            allowed_document_ids=allowed_document_ids,
            embedding_provider=str(model_cfg["embedding_provider"]),
            embedding_model=str(model_cfg["embedding_model_name"]),
        )
        documents_matched = results.get("documents", [[]])[0] or []
        metadatas_matched = results.get("metadatas", [[]])[0] or []

    web_sources: list[dict[str, str]] = []
    if web_requested:
        web_sources, web_status = web_search_service.search_web(db, question)
        if web_sources:
            web_status = f"enabled: {len(web_sources)} result(s)"

    if not documents_matched and not web_sources:
        return _not_found_response(model_cfg, scope_summary, web_status=web_status, web_used=web_requested)

    context_blocks: list[str] = []
    sources: list[str] = []
    for text, meta in zip(documents_matched, metadatas_matched):
        filename = meta.get("filename", "Unknown document")
        chunk_index = meta.get("chunk_index", "?")
        category = meta.get("category", "")
        workspace = meta.get("workspace_id", "")
        page = meta.get("page_number") or meta.get("page") or ""
        page_part = f"; page {page}" if page else ""
        context_blocks.append(
            f"[LOCAL DOCUMENT: {filename}; chunk {chunk_index}{page_part}; category {category}; workspace {workspace}]\n{text}"
        )
        if filename not in sources:
            sources.append(filename)

    for idx, item in enumerate(web_sources, start=1):
        title = item.get("title") or "Untitled web result"
        url = item.get("url") or ""
        snippet = item.get("snippet") or ""
        provider = item.get("provider") or "web"
        context_blocks.append(f"[WEB SEARCH {idx}: {title}; provider {provider}; url {url}]\n{snippet}")

    context = "\n\n---\n\n".join(context_blocks)
    user_prompt = (
        f"CURRENT DATE: {date.today().isoformat()}\n\n"
        f"CONTEXT:\n{context}\n\n"
        f"QUESTION: {question}\n\n"
        "Answer using only the context above. For current or public facts, use WEB SEARCH snippets when present. "
        "Mention whether the answer came from local school documents, web search, or both. "
        "If web snippets contain sources but not enough detail for a precise answer, say that the web search ran but the snippets were insufficient."
    )

    try:
        completion = chat_completion_with_usage(SYSTEM_PROMPT, user_prompt, model=str(model_cfg["local_model_name"]))
        answer = str(completion.get("answer") or "")
    except OllamaUnavailableError as exc:
        return {
            "answer": str(exc),
            "sources": [],
            "web_sources": [],
            "found_answer": False,
            "ollama_available": False,
            "scope_summary": scope_summary,
            "usage": _empty_usage(model_cfg),
            "web_search_used": web_requested,
            "web_search_status": web_status,
        }

    if not answer:
        answer = NOT_FOUND_MESSAGE

    lower_answer = answer.lower()
    found = NOT_FOUND_MESSAGE.lower() not in lower_answer and LEGACY_NOT_FOUND_MESSAGE.lower() not in lower_answer
    usage = {
        "model_name": str(completion.get("model_name") or model_cfg["local_model_name"]),
        "embedding_model": str(model_cfg["embedding_model_name"]),
        "prompt_tokens": int(completion.get("prompt_tokens") or 0),
        "completion_tokens": int(completion.get("completion_tokens") or 0),
        "total_tokens": int(completion.get("total_tokens") or 0),
        "duration_ms": int(completion.get("duration_ms") or 0),
    }
    return {
        "answer": answer,
        "sources": sources if found else [],
        "web_sources": web_sources if web_sources else [],
        "found_answer": found,
        "ollama_available": True,
        "scope_summary": scope_summary,
        "usage": usage,
        "web_search_used": bool(web_requested and web_sources),
        "web_search_status": web_status,
    }
