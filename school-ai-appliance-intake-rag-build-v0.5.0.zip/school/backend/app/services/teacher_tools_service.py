from app.services.ollama_service import chat_completion_with_usage, is_ollama_available, OllamaUnavailableError

SYSTEM_PROMPT = (
    "You are an expert curriculum assistant for school teachers. Produce clear, "
    "well-structured, classroom-ready output using headings and bullet points where "
    "appropriate. Be practical and age-appropriate for the given grade."
)

PROMPT_TEMPLATES = {
    "lesson_plan": (
        "Create a detailed lesson plan.\nGrade: {grade}\nSubject: {subject}\nTopic: {topic}\n"
        "Duration: {duration}\nDifficulty: {difficulty}\nExtra instructions: {extra_instructions}\n\n"
        "Structure the plan with: Learning Objectives, Materials Needed, Introduction/Hook, "
        "Main Activities (step by step with timing), Assessment, and Homework/Follow-up."
    ),
    "worksheet": (
        "Create a student worksheet.\nGrade: {grade}\nSubject: {subject}\nTopic: {topic}\n"
        "Difficulty: {difficulty}\nExtra instructions: {extra_instructions}\n\n"
        "Include a short instructions line, then 8-12 varied practice questions "
        "(mix of short answer, fill-in-the-blank, and application questions), "
        "followed by an answer key at the end."
    ),
    "quiz": (
        "Create a quiz.\nGrade: {grade}\nSubject: {subject}\nTopic: {topic}\n"
        "Difficulty: {difficulty}\nExtra instructions: {extra_instructions}\n\n"
        "Include 10 multiple-choice questions (4 options each, mark the correct answer) "
        "covering the topic, ordered from easier to harder."
    ),
    "parent_message": (
        "Write a message to parents.\nGrade: {grade}\nSubject: {subject}\nTopic/Context: {topic}\n"
        "Extra instructions: {extra_instructions}\n\n"
        "Keep it warm, professional, concise (under 150 words), and clear about any action needed."
    ),
    "feedback_comment": (
        "Write a student feedback / report-card comment.\nGrade: {grade}\nSubject: {subject}\n"
        "Topic/Context: {topic}\nDifficulty/Performance level: {difficulty}\n"
        "Extra instructions: {extra_instructions}\n\n"
        "Keep it constructive, specific, encouraging, and 2-4 sentences long."
    ),
}


def generate_teacher_tool(
    tool: str, grade: str, subject: str, topic: str, duration: str, difficulty: str, extra_instructions: str, model_name: str | None = None
) -> dict:
    if tool not in PROMPT_TEMPLATES:
        raise ValueError(f"Unknown teacher tool: {tool}")

    if not is_ollama_available():
        return {
            "output": "The local AI model (Ollama) is not reachable. Start it with 'ollama serve' and try again.",
            "ollama_available": False,
            "usage": {"model_name": model_name or "", "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "duration_ms": 0},
        }

    prompt = PROMPT_TEMPLATES[tool].format(
        grade=grade, subject=subject, topic=topic, duration=duration or "Not specified",
        difficulty=difficulty, extra_instructions=extra_instructions or "None",
    )
    try:
        completion = chat_completion_with_usage(SYSTEM_PROMPT, prompt, model=model_name, temperature=0.5)
        output = str(completion.get("answer") or "")
    except OllamaUnavailableError as exc:
        return {"output": str(exc), "ollama_available": False, "usage": {"model_name": model_name or "", "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "duration_ms": 0}}

    usage = {
        "model_name": str(completion.get("model_name") or model_name or ""),
        "prompt_tokens": int(completion.get("prompt_tokens") or 0),
        "completion_tokens": int(completion.get("completion_tokens") or 0),
        "total_tokens": int(completion.get("total_tokens") or 0),
        "duration_ms": int(completion.get("duration_ms") or 0),
    }
    return {"output": output, "ollama_available": True, "usage": usage}
