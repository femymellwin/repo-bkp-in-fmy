import json
from typing import Any

from sqlalchemy.orm import Session

from app.models.setting import Setting
from app.core.config import get_settings as get_env_settings
from app.core.permissions import ROLE_PERMISSIONS, UPLOAD_ROLES

app_settings = get_env_settings()

DEFAULT_ALLOWED_FILE_TYPES = ["pdf", "docx", "txt", "csv", "xlsx"]
DEFAULT_CHUNKING_BY_TYPE = {
    "pdf": {"chunk_size": 800, "chunk_overlap": 120},
    "docx": {"chunk_size": 800, "chunk_overlap": 120},
    "txt": {"chunk_size": 700, "chunk_overlap": 100},
    "csv": {"chunk_size": 600, "chunk_overlap": 80},
    "xlsx": {"chunk_size": 600, "chunk_overlap": 80},
}
DEFAULT_MENU_ITEMS = [
    "dashboard", "ask-ai", "workspaces", "documents", "teacher-tools", "admin-tools", "timetable",
    "analytics", "rag-audit", "model-config", "upload-permissions", "users",
    "teacher-profile", "onboarding", "audit-logs", "backup", "system-health", "settings",
]

DEFAULTS = {
    "school_name": app_settings.SCHOOL_NAME,
    "academic_year": app_settings.ACADEMIC_YEAR,
    "local_model_name": app_settings.OLLAMA_MODEL,
    "embedding_provider": app_settings.EMBEDDING_PROVIDER,
    "embedding_model_name": app_settings.OLLAMA_EMBEDDING_MODEL
        if app_settings.EMBEDDING_PROVIDER.lower() == "ollama"
        else app_settings.SENTENCE_TRANSFORMER_MODEL,
    "sentence_transformer_model": app_settings.SENTENCE_TRANSFORMER_MODEL,
    "ollama_embedding_model": app_settings.OLLAMA_EMBEDDING_MODEL,
    "ollama_base_url": app_settings.OLLAMA_BASE_URL,
    "rag_top_k": "5",
    "chunking_strategy": "structure_aware_word_window",
    "default_chunk_size": "800",
    "default_chunk_overlap": "120",
    "chunking_by_file_type": json.dumps(DEFAULT_CHUNKING_BY_TYPE),
    "allowed_file_types": ",".join(DEFAULT_ALLOWED_FILE_TYPES),
    "upload_roles": ",".join(sorted(UPLOAD_ROLES)),
    "maintenance_mode": "false",
    "web_search_enabled": "false",
    "web_search_provider": "google",
    "web_search_max_results": "5",
    "web_search_timeout_seconds": "8",
    "web_search_api_key": "",
    "web_search_google_cx": "",
    "web_search_searxng_url": "",
}


def _csv_to_list(value: str | None) -> list[str]:
    if not value:
        return []
    return [part.strip().lower().lstrip(".") for part in value.split(",") if part.strip()]


def _list_to_csv(values: list[str]) -> str:
    return ",".join(dict.fromkeys(v.strip().lower().lstrip(".") for v in values if v.strip()))


def get_setting(db: Session, key: str) -> str:
    row = db.query(Setting).filter(Setting.key == key).first()
    if row:
        return row.value
    return DEFAULTS.get(key, "")


def set_setting(db: Session, key: str, value: str) -> None:
    row = db.query(Setting).filter(Setting.key == key).first()
    if row:
        row.value = value
    else:
        row = Setting(key=key, value=value)
        db.add(row)
    db.commit()


def get_all_settings(db: Session) -> dict[str, Any]:
    result: dict[str, Any] = dict(DEFAULTS)
    for row in db.query(Setting).all():
        result[row.key] = row.value
    result["maintenance_mode"] = str(result.get("maintenance_mode", "false")).lower() == "true"
    return result


def ensure_defaults(db: Session) -> None:
    from app.services.workspace_service import ensure_category_defaults, ensure_default_workspaces_for_all_users
    from app.services.chat_service import ensure_default_projects_for_all_users
    existing_keys = {row.key for row in db.query(Setting).all()}
    for key, value in DEFAULTS.items():
        if key not in existing_keys:
            db.add(Setting(key=key, value=str(value)))
    db.commit()
    ensure_category_defaults(db)
    ensure_default_workspaces_for_all_users(db)
    ensure_default_projects_for_all_users(db)


def get_allowed_file_types(db: Session) -> list[str]:
    configured = _csv_to_list(get_setting(db, "allowed_file_types"))
    return configured or list(DEFAULT_ALLOWED_FILE_TYPES)


def set_allowed_file_types(db: Session, values: list[str]) -> list[str]:
    clean = [v for v in _csv_to_list(",".join(values)) if v in DEFAULT_ALLOWED_FILE_TYPES]
    if not clean:
        clean = list(DEFAULT_ALLOWED_FILE_TYPES)
    set_setting(db, "allowed_file_types", _list_to_csv(clean))
    return clean


def get_upload_roles(db: Session) -> list[str]:
    roles = _csv_to_list(get_setting(db, "upload_roles"))
    return roles or sorted(UPLOAD_ROLES)


def set_upload_roles(db: Session, values: list[str]) -> list[str]:
    valid_roles = set(ROLE_PERMISSIONS.keys())
    clean = [v for v in _csv_to_list(",".join(values)) if v in valid_roles]
    set_setting(db, "upload_roles", _list_to_csv(clean))
    return clean


def role_can_upload(db: Session, role: str) -> bool:
    return role in get_upload_roles(db)


def get_chunking_by_file_type(db: Session) -> dict[str, dict[str, int]]:
    raw = get_setting(db, "chunking_by_file_type")
    try:
        parsed = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        parsed = {}

    result: dict[str, dict[str, int]] = {}
    default_size = int(get_setting(db, "default_chunk_size") or 800)
    default_overlap = int(get_setting(db, "default_chunk_overlap") or 120)
    for file_type in DEFAULT_ALLOWED_FILE_TYPES:
        configured = parsed.get(file_type, {}) if isinstance(parsed, dict) else {}
        try:
            size = int(configured.get("chunk_size", DEFAULT_CHUNKING_BY_TYPE[file_type]["chunk_size"]))
        except (TypeError, ValueError):
            size = default_size
        try:
            overlap = int(configured.get("chunk_overlap", DEFAULT_CHUNKING_BY_TYPE[file_type]["chunk_overlap"]))
        except (TypeError, ValueError):
            overlap = default_overlap
        # Keep the local prototype sane: overlap must be smaller than chunk size.
        size = max(100, min(size, 4000))
        overlap = max(0, min(overlap, size - 1))
        result[file_type] = {"chunk_size": size, "chunk_overlap": overlap}
    return result


def set_chunking_by_file_type(db: Session, value: dict[str, dict[str, int]]) -> dict[str, dict[str, int]]:
    clean: dict[str, dict[str, int]] = {}
    for file_type in DEFAULT_ALLOWED_FILE_TYPES:
        cfg = value.get(file_type, {})
        try:
            size = int(cfg.get("chunk_size", DEFAULT_CHUNKING_BY_TYPE[file_type]["chunk_size"]))
        except (TypeError, ValueError):
            size = DEFAULT_CHUNKING_BY_TYPE[file_type]["chunk_size"]
        try:
            overlap = int(cfg.get("chunk_overlap", DEFAULT_CHUNKING_BY_TYPE[file_type]["chunk_overlap"]))
        except (TypeError, ValueError):
            overlap = DEFAULT_CHUNKING_BY_TYPE[file_type]["chunk_overlap"]
        size = max(100, min(size, 4000))
        overlap = max(0, min(overlap, size - 1))
        clean[file_type] = {"chunk_size": size, "chunk_overlap": overlap}
    set_setting(db, "chunking_by_file_type", json.dumps(clean, sort_keys=True))
    return clean


def get_chunk_config_for_type(db: Session, document_type: str) -> dict[str, int | str]:
    file_type = (document_type or "").lower().lstrip(".")
    by_type = get_chunking_by_file_type(db)
    cfg = by_type.get(file_type) or {"chunk_size": int(get_setting(db, "default_chunk_size") or 800), "chunk_overlap": int(get_setting(db, "default_chunk_overlap") or 120)}
    return {
        "chunk_size": int(cfg["chunk_size"]),
        "chunk_overlap": int(cfg["chunk_overlap"]),
        "chunking_strategy": get_setting(db, "chunking_strategy") or "word_sliding_window",
    }


def get_model_runtime_config(db: Session) -> dict[str, str | int]:
    provider = (get_setting(db, "embedding_provider") or app_settings.EMBEDDING_PROVIDER).lower()
    embedding_model = get_setting(db, "embedding_model_name") or (
        app_settings.OLLAMA_EMBEDDING_MODEL if provider == "ollama" else app_settings.SENTENCE_TRANSFORMER_MODEL
    )
    return {
        "ollama_base_url": get_setting(db, "ollama_base_url") or app_settings.OLLAMA_BASE_URL,
        "local_model_name": get_setting(db, "local_model_name") or app_settings.OLLAMA_MODEL,
        "embedding_provider": provider,
        "embedding_model_name": embedding_model,
        "rag_top_k": int(get_setting(db, "rag_top_k") or 5),
    }


def get_bool_setting(db: Session, key: str, default: bool = False) -> bool:
    value = get_setting(db, key)
    if value == "":
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def get_int_setting(db: Session, key: str, default: int, minimum: int | None = None, maximum: int | None = None) -> int:
    try:
        value = int(get_setting(db, key) or default)
    except (TypeError, ValueError):
        value = default
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def get_web_search_config(db: Session) -> dict[str, str | int | bool]:
    return {
        "enabled": get_bool_setting(db, "web_search_enabled", False),
        "provider": (get_setting(db, "web_search_provider") or "google").lower(),
        "max_results": get_int_setting(db, "web_search_max_results", 5, minimum=1, maximum=10),
        "timeout_seconds": get_int_setting(db, "web_search_timeout_seconds", 8, minimum=2, maximum=30),
        "api_key": get_setting(db, "web_search_api_key") or "",
        "google_cx": get_setting(db, "web_search_google_cx") or "",
        "searxng_url": get_setting(db, "web_search_searxng_url") or "",
    }
