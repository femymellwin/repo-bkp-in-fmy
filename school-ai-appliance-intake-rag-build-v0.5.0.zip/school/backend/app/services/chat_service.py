from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.chat import ChatMessage, ChatProject, ChatThread
from app.models.user import User


class ChatAccessError(Exception):
    pass


def _clean_title(value: str | None, fallback: str = "New chat") -> str:
    text = (value or "").strip()
    if not text:
        return fallback
    return text[:220]


def _question_title(question: str) -> str:
    text = " ".join((question or "").strip().split())
    if not text:
        return "New chat"
    return text[:72] + ("..." if len(text) > 72 else "")


def ensure_default_project(db: Session, user: User) -> ChatProject:
    project = (
        db.query(ChatProject)
        .filter(ChatProject.owner_user_id == user.id, ChatProject.is_default.is_(True), ChatProject.archived.is_(False))
        .order_by(ChatProject.id.asc())
        .first()
    )
    if project:
        return project
    project = ChatProject(
        owner_user_id=user.id,
        name="My School AI Workspace",
        description="Default project for personal school AI chats and document-scoped questions.",
        color="indigo",
        is_default=True,
    )
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


def ensure_default_projects_for_all_users(db: Session) -> None:
    users = db.query(User).all()
    for user in users:
        ensure_default_project(db, user)


def list_projects(db: Session, user: User) -> list[dict[str, Any]]:
    rows = (
        db.query(ChatProject)
        .filter(ChatProject.owner_user_id == user.id, ChatProject.archived.is_(False))
        .order_by(ChatProject.is_default.desc(), ChatProject.updated_at.desc(), ChatProject.id.desc())
        .all()
    )
    if not rows:
        rows = [ensure_default_project(db, user)]
    thread_counts = dict(
        db.query(ChatThread.project_id, func.count(ChatThread.id))
        .filter(ChatThread.user_id == user.id, ChatThread.archived.is_(False))
        .group_by(ChatThread.project_id)
        .all()
    )
    return [
        {
            "id": project.id,
            "name": project.name,
            "description": project.description or "",
            "color": project.color or "indigo",
            "is_default": bool(project.is_default),
            "thread_count": int(thread_counts.get(project.id, 0) or 0),
            "created_at": project.created_at,
            "updated_at": project.updated_at,
        }
        for project in rows
    ]


def get_project_or_403(db: Session, user: User, project_id: int) -> ChatProject:
    project = (
        db.query(ChatProject)
        .filter(ChatProject.id == project_id, ChatProject.owner_user_id == user.id, ChatProject.archived.is_(False))
        .first()
    )
    if not project:
        raise ChatAccessError("Project not found or not accessible.")
    return project


def create_project(db: Session, user: User, name: str, description: str = "", color: str = "indigo") -> ChatProject:
    project = ChatProject(
        owner_user_id=user.id,
        name=_clean_title(name, "New project"),
        description=(description or "")[:1000],
        color=(color or "indigo")[:32],
        is_default=False,
    )
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


def update_project(db: Session, user: User, project_id: int, name: str | None = None, description: str | None = None, color: str | None = None) -> ChatProject:
    project = get_project_or_403(db, user, project_id)
    if name is not None:
        project.name = _clean_title(name, project.name)
    if description is not None:
        project.description = description[:1000]
    if color is not None:
        project.color = color[:32]
    project.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(project)
    return project


def archive_project(db: Session, user: User, project_id: int) -> None:
    project = get_project_or_403(db, user, project_id)
    if project.is_default:
        raise ChatAccessError("The default project cannot be deleted.")
    project.archived = True
    for thread in project.threads:
        thread.archived = True
    project.updated_at = datetime.utcnow()
    db.commit()


def list_threads(db: Session, user: User, project_id: int | None = None, limit: int = 80) -> list[dict[str, Any]]:
    query = db.query(ChatThread).filter(ChatThread.user_id == user.id, ChatThread.archived.is_(False))
    if project_id is not None:
        query = query.filter(ChatThread.project_id == project_id)
    rows = query.order_by(ChatThread.updated_at.desc(), ChatThread.id.desc()).limit(limit).all()
    message_counts = dict(
        db.query(ChatMessage.thread_id, func.count(ChatMessage.id))
        .filter(ChatMessage.thread_id.in_([row.id for row in rows] or [-1]))
        .group_by(ChatMessage.thread_id)
        .all()
    )
    return [
        {
            "id": thread.id,
            "project_id": thread.project_id,
            "title": thread.title,
            "scope_json": thread.scope_json or {},
            "web_search_requested": bool(thread.web_search_requested),
            "message_count": int(message_counts.get(thread.id, 0) or 0),
            "created_at": thread.created_at,
            "updated_at": thread.updated_at,
        }
        for thread in rows
    ]


def get_thread_or_403(db: Session, user: User, thread_id: int) -> ChatThread:
    thread = (
        db.query(ChatThread)
        .filter(ChatThread.id == thread_id, ChatThread.user_id == user.id, ChatThread.archived.is_(False))
        .first()
    )
    if not thread:
        raise ChatAccessError("Chat not found or not accessible.")
    return thread


def create_thread(
    db: Session,
    user: User,
    project_id: int | None = None,
    title: str | None = None,
    scope_json: dict | None = None,
    web_search_requested: bool = False,
) -> ChatThread:
    project = get_project_or_403(db, user, project_id) if project_id else ensure_default_project(db, user)
    thread = ChatThread(
        project_id=project.id,
        user_id=user.id,
        title=_clean_title(title, "New chat"),
        scope_json=scope_json or {},
        web_search_requested=bool(web_search_requested),
    )
    project.updated_at = datetime.utcnow()
    db.add(thread)
    db.commit()
    db.refresh(thread)
    return thread


def get_or_create_thread_for_question(
    db: Session,
    user: User,
    question: str,
    thread_id: int | None = None,
    project_id: int | None = None,
    scope_json: dict | None = None,
    web_search_requested: bool = False,
) -> ChatThread:
    if thread_id:
        thread = get_thread_or_403(db, user, thread_id)
        thread.scope_json = scope_json or thread.scope_json or {}
        thread.web_search_requested = bool(web_search_requested)
        thread.updated_at = datetime.utcnow()
        if thread.project:
            thread.project.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(thread)
        return thread
    return create_thread(
        db,
        user,
        project_id=project_id,
        title=_question_title(question),
        scope_json=scope_json or {},
        web_search_requested=web_search_requested,
    )


def rename_thread(db: Session, user: User, thread_id: int, title: str) -> ChatThread:
    thread = get_thread_or_403(db, user, thread_id)
    thread.title = _clean_title(title, thread.title)
    thread.updated_at = datetime.utcnow()
    if thread.project:
        thread.project.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(thread)
    return thread


def archive_thread(db: Session, user: User, thread_id: int) -> None:
    thread = get_thread_or_403(db, user, thread_id)
    thread.archived = True
    thread.updated_at = datetime.utcnow()
    if thread.project:
        thread.project.updated_at = datetime.utcnow()
    db.commit()


def add_message(
    db: Session,
    thread: ChatThread,
    role: str,
    content: str,
    sources: list | None = None,
    web_sources: list | None = None,
    usage: dict | None = None,
    scope_summary: str = "All accessible documents",
    used_web_search: bool = False,
) -> ChatMessage:
    msg = ChatMessage(
        thread_id=thread.id,
        role=role,
        content=content,
        sources=sources or [],
        web_sources=web_sources or [],
        usage_json=usage or {},
        scope_summary=scope_summary or "All accessible documents",
        used_web_search=bool(used_web_search),
    )
    thread.updated_at = datetime.utcnow()
    if thread.project:
        thread.project.updated_at = datetime.utcnow()
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return msg


def list_messages(db: Session, user: User, thread_id: int) -> list[dict[str, Any]]:
    thread = get_thread_or_403(db, user, thread_id)
    return [
        {
            "id": msg.id,
            "thread_id": msg.thread_id,
            "role": msg.role,
            "content": msg.content,
            "sources": msg.sources or [],
            "web_sources": msg.web_sources or [],
            "usage": msg.usage_json or {},
            "scope_summary": msg.scope_summary or "All accessible documents",
            "used_web_search": bool(msg.used_web_search),
            "created_at": msg.created_at,
        }
        for msg in db.query(ChatMessage).filter(ChatMessage.thread_id == thread.id).order_by(ChatMessage.created_at.asc(), ChatMessage.id.asc()).all()
    ]
