"""
Thin client for a locally running Ollama instance.

No API keys, no cloud calls - just HTTP requests to
`OLLAMA_BASE_URL` (default http://localhost:11434), which must be running
on the same Mac. If Ollama is not reachable, every function here raises
`OllamaUnavailableError`, which API routes translate into a friendly
error message rather than a crash.
"""
import re

import requests

from app.core.config import get_settings

settings = get_settings()

# Reasoning models (e.g. qwen3, deepseek-r1) emit their chain of thought in
# <think>...</think> blocks before the actual answer. Strip these so users
# only see the final answer.
_THINK_BLOCK = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


def _clean_response(text: str) -> str:
    text = _THINK_BLOCK.sub("", text)
    # Handle an unterminated <think> block (model hit the token limit mid-thought).
    if "<think>" in text.lower():
        text = re.split(r"<think>", text, flags=re.IGNORECASE)[0]
    return text.strip()


class OllamaUnavailableError(Exception):
    pass


def is_ollama_available() -> bool:
    try:
        resp = requests.get(f"{settings.OLLAMA_BASE_URL}/api/tags", timeout=2)
        return resp.status_code == 200
    except requests.RequestException:
        return False


def chat_completion_with_usage(system_prompt: str, user_prompt: str, model: str | None = None, temperature: float = 0.3) -> dict:
    model_name = model or settings.OLLAMA_MODEL
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "stream": False,
        "options": {"temperature": temperature},
    }
    try:
        resp = requests.post(f"{settings.OLLAMA_BASE_URL}/api/chat", json=payload, timeout=180)
    except requests.RequestException as exc:
        raise OllamaUnavailableError(
            "Could not reach Ollama. Make sure Ollama is installed and running "
            f"locally (ollama serve) and that the model '{model_name}' has been "
            f"pulled (ollama pull {model_name})."
        ) from exc

    if resp.status_code != 200:
        raise OllamaUnavailableError(f"Ollama returned an error (HTTP {resp.status_code}): {resp.text[:300]}")

    data = resp.json()
    message = data.get("message", {})
    prompt_tokens = int(data.get("prompt_eval_count") or 0)
    completion_tokens = int(data.get("eval_count") or 0)
    total_duration_ns = int(data.get("total_duration") or 0)
    return {
        "answer": _clean_response(message.get("content") or ""),
        "model_name": data.get("model") or model_name,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
        "duration_ms": round(total_duration_ns / 1_000_000) if total_duration_ns else 0,
    }


def chat_completion(system_prompt: str, user_prompt: str, model: str | None = None, temperature: float = 0.3) -> str:
    return str(chat_completion_with_usage(system_prompt, user_prompt, model=model, temperature=temperature)["answer"])


def list_local_models() -> list[str]:
    try:
        resp = requests.get(f"{settings.OLLAMA_BASE_URL}/api/tags", timeout=3)
    except requests.RequestException:
        return []
    if resp.status_code != 200:
        return []
    data = resp.json()
    models = []
    for item in data.get("models", []):
        name = item.get("name")
        if name:
            models.append(name)
    return sorted(models)


def model_is_available(model_name: str) -> bool:
    if not model_name:
        return False
    models = list_local_models()
    return model_name in models or any(m.split(":", 1)[0] == model_name for m in models)


def embed_texts_via_ollama(texts: list[str], model: str | None = None) -> list[list[float]]:
    """
    Embeds a batch of texts using a local Ollama embedding model
    (e.g. `nomic-embed-text`). Tries the modern batch endpoint
    (/api/embed) first and falls back to the legacy single-prompt
    endpoint (/api/embeddings) for older Ollama versions.
    """
    model_name = model or settings.OLLAMA_EMBEDDING_MODEL

    # Modern batch endpoint (Ollama >= 0.2.6).
    try:
        resp = requests.post(
            f"{settings.OLLAMA_BASE_URL}/api/embed",
            json={"model": model_name, "input": texts},
            timeout=300,
        )
        if resp.status_code == 200:
            embeddings = resp.json().get("embeddings")
            if embeddings and len(embeddings) == len(texts):
                return embeddings
    except requests.RequestException as exc:
        raise OllamaUnavailableError(
            "Could not reach Ollama for embeddings. Make sure Ollama is running "
            f"and the embedding model '{model_name}' has been pulled "
            f"(ollama pull {model_name})."
        ) from exc

    # Legacy fallback: one request per text.
    embeddings: list[list[float]] = []
    for text in texts:
        try:
            resp = requests.post(
                f"{settings.OLLAMA_BASE_URL}/api/embeddings",
                json={"model": model_name, "prompt": text},
                timeout=120,
            )
        except requests.RequestException as exc:
            raise OllamaUnavailableError(
                f"Ollama embedding request failed for model '{model_name}'."
            ) from exc
        if resp.status_code != 200:
            raise OllamaUnavailableError(
                f"Ollama embeddings returned HTTP {resp.status_code}: {resp.text[:300]}"
            )
        embeddings.append(resp.json().get("embedding", []))
    return embeddings
