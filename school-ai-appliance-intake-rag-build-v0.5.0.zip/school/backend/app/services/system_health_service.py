import psutil
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.config import get_settings, BASE_DIR
from app.db.database import engine
from app.services.ollama_service import is_ollama_available, model_is_available
from app.services.vector_service import vector_db_healthy
from app.services.backup_service import get_last_backup_date
from app.services import settings_service

settings = get_settings()


def _database_healthy() -> bool:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:
        return False


def get_system_health(db: Session) -> dict:
    cpu_percent = psutil.cpu_percent(interval=0.3)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage(str(BASE_DIR))
    model_cfg = settings_service.get_model_runtime_config(db)
    embedding_provider = str(model_cfg["embedding_provider"])
    embedding_model = str(model_cfg["embedding_model_name"])
    if embedding_provider == "ollama":
        embedding_status = "online" if model_is_available(embedding_model) else "offline"
    else:
        embedding_status = "local-process"

    return {
        "cpu_percent": cpu_percent,
        "ram_percent": mem.percent,
        "ram_used_gb": round(mem.used / (1024 ** 3), 2),
        "ram_total_gb": round(mem.total / (1024 ** 3), 2),
        "disk_percent": disk.percent,
        "disk_used_gb": round(disk.used / (1024 ** 3), 2),
        "disk_total_gb": round(disk.total / (1024 ** 3), 2),
        "ollama_status": "online" if is_ollama_available() else "offline",
        "ollama_model": str(model_cfg["local_model_name"]),
        "embedding_provider": embedding_provider,
        "embedding_model": embedding_model,
        "embedding_status": embedding_status,
        "database_status": "online" if _database_healthy() else "offline",
        "vector_db_status": "online" if vector_db_healthy() else "offline",
        "last_backup_date": get_last_backup_date(db),
    }
