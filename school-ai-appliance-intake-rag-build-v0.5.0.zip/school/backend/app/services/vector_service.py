"""
Local vector search over document chunks.

Uses a persistent ChromaDB collection stored entirely on disk (VECTOR_DB_DIR).
Embeddings are produced either by a local sentence-transformers model or a local
Ollama embedding model. ChromaDB telemetry is disabled.
"""
from functools import lru_cache
from typing import Any

import chromadb
from chromadb.config import Settings as ChromaSettings

from app.core.config import get_settings

settings = get_settings()

COLLECTION_NAME = "school_documents"
VECTOR_DB_NAME = "ChromaDB"


@lru_cache
def get_embedding_model(model_name: str):
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(model_name)


@lru_cache
def get_chroma_client():
    return chromadb.PersistentClient(
        path=str(settings.vector_db_path),
        settings=ChromaSettings(anonymized_telemetry=False, allow_reset=False),
    )


def get_collection(collection_name: str = COLLECTION_NAME):
    client = get_chroma_client()
    return client.get_or_create_collection(name=collection_name, metadata={"hnsw:space": "cosine"})


def embed_texts(texts: list[str], provider: str | None = None, model_name: str | None = None) -> list[list[float]]:
    chosen_provider = (provider or settings.EMBEDDING_PROVIDER).lower()
    if chosen_provider == "ollama":
        from app.services.ollama_service import embed_texts_via_ollama
        return embed_texts_via_ollama(texts, model=model_name or settings.OLLAMA_EMBEDDING_MODEL)
    model = get_embedding_model(model_name or settings.SENTENCE_TRANSFORMER_MODEL)
    embeddings = model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
    return embeddings.tolist()


def add_chunks(
    vector_ids: list[str],
    texts: list[str],
    metadatas: list[dict],
    embedding_provider: str | None = None,
    embedding_model: str | None = None,
) -> None:
    if not texts:
        return
    embeddings = embed_texts(texts, provider=embedding_provider, model_name=embedding_model)
    collection = get_collection()
    collection.add(ids=vector_ids, embeddings=embeddings, documents=texts, metadatas=metadatas)


def delete_document_vectors(document_id: int) -> None:
    collection = get_collection()
    collection.delete(where={"document_id": document_id})


def query_similar(
    query_text: str,
    allowed_categories: list[str],
    n_results: int = 5,
    allowed_document_ids: list[int] | None = None,
    embedding_provider: str | None = None,
    embedding_model: str | None = None,
):
    collection = get_collection()
    if collection.count() == 0:
        return {"documents": [[]], "metadatas": [[]], "distances": [[]]}

    where_filter: dict[str, Any] | None = None
    if allowed_document_ids is not None:
        if not allowed_document_ids:
            return {"documents": [[]], "metadatas": [[]], "distances": [[]]}
        where_filter = {"document_id": {"$in": allowed_document_ids}}
    elif allowed_categories:
        where_filter = {"category": {"$in": allowed_categories}}
    else:
        return {"documents": [[]], "metadatas": [[]], "distances": [[]]}

    query_embedding = embed_texts([query_text], provider=embedding_provider, model_name=embedding_model)[0]
    return collection.query(
        query_embeddings=[query_embedding],
        n_results=n_results,
        where=where_filter,
    )


def vector_db_healthy() -> bool:
    try:
        get_chroma_client().heartbeat()
        return True
    except Exception:
        return False


def vector_count() -> int:
    try:
        return get_collection().count()
    except Exception:
        return 0


def vector_metadata() -> dict[str, Any]:
    return {
        "name": VECTOR_DB_NAME,
        "collection": COLLECTION_NAME,
        "path": str(settings.vector_db_path),
        "telemetry": "disabled",
        "status": "online" if vector_db_healthy() else "offline",
        "vector_count": vector_count(),
        "distance_metric": "cosine",
    }
