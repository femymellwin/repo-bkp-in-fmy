from pathlib import Path

from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.encryption import encrypt_file_to_path, decrypt_file_from_path
from app.core.permissions import accessible_categories, RoleName
from app.models.document import Document
from app.models.user import User
from app.utils.file_utils import new_encrypted_filename, get_extension
from app.services import vector_service

settings = get_settings()


class AccessDeniedError(Exception):
    pass


def save_new_document(
    db: Session,
    uploader: User,
    original_filename: str,
    file_bytes: bytes,
    access_role: str,
    superadmin_permitted: bool = False,
    workspace_id: int | None = None,
    doc_kind: str = "general",
    subject: str = "",
    grade: str = "",
    academic_year: str = "",
) -> Document:
    encrypted_name = new_encrypted_filename(original_filename)
    dest_path = settings.documents_path / encrypted_name
    size = encrypt_file_to_path(file_bytes, dest_path)

    document = Document(
        filename=original_filename,
        uploaded_by_id=uploader.id,
        document_type=get_extension(original_filename),
        access_role=access_role,
        file_size=size,
        workspace_id=workspace_id,
        doc_kind=(doc_kind or "general")[:80],
        subject=(subject or "")[:120],
        grade=(grade or "")[:80],
        academic_year=(academic_year or "")[:40],
        encrypted_file_path=str(dest_path),
        superadmin_permitted=superadmin_permitted,
        ingestion_status="pending",
    )
    db.add(document)
    db.commit()
    db.refresh(document)
    return document


def user_can_access_document(user: User, document: Document) -> bool:
    # Owners always retain access to the documents they uploaded, even when
    # the category is custom/private.
    if document.uploaded_by_id == user.id:
        return True
    if user.role in (RoleName.PRINCIPAL.value, RoleName.SCHOOL_ADMIN.value):
        return True
    if user.role == RoleName.SUPER_ADMIN.value:
        return bool(document.superadmin_permitted)
    return document.access_role in accessible_categories(user.role)


def _base_access_query(db: Session, user: User):
    query = db.query(Document)
    if user.role in (RoleName.PRINCIPAL.value, RoleName.SCHOOL_ADMIN.value):
        return query
    if user.role == RoleName.SUPER_ADMIN.value:
        return query.filter(or_(Document.uploaded_by_id == user.id, Document.superadmin_permitted.is_(True)))
    cats = accessible_categories(user.role)
    return query.filter(or_(Document.uploaded_by_id == user.id, Document.access_role.in_(cats)))


def list_documents_for_user(db: Session, user: User) -> list[Document]:
    return _base_access_query(db, user).order_by(Document.upload_date.desc()).all()


def get_accessible_document_ids(
    db: Session,
    user: User,
    workspace_id: int | None = None,
    document_ids: list[int] | None = None,
    categories: list[str] | None = None,
    document_types: list[str] | None = None,
    completed_only: bool = True,
) -> list[int]:
    query = _base_access_query(db, user)
    if completed_only:
        query = query.filter(Document.ingestion_status == "completed")
    if workspace_id is not None:
        query = query.filter(Document.workspace_id == workspace_id)
    if document_ids:
        query = query.filter(Document.id.in_(document_ids))
    if categories:
        query = query.filter(Document.access_role.in_(categories))
    if document_types:
        clean_types = [x.lower().lstrip(".") for x in document_types if x]
        if clean_types:
            query = query.filter(Document.document_type.in_(clean_types))
    return [row[0] for row in query.with_entities(Document.id).all()]


def describe_scope(
    db: Session,
    user: User,
    workspace_id: int | None = None,
    document_ids: list[int] | None = None,
    categories: list[str] | None = None,
    document_types: list[str] | None = None,
) -> str:
    parts: list[str] = []
    if workspace_id is not None:
        from app.models.workspace import Workspace
        ws = db.query(Workspace).filter(Workspace.id == workspace_id).first()
        parts.append(f"workspace={ws.name if ws else workspace_id}")
    if document_ids:
        rows = (
            _base_access_query(db, user)
            .filter(Document.id.in_(document_ids))
            .with_entities(Document.filename)
            .limit(5)
            .all()
        )
        names = [r[0] for r in rows]
        suffix = "" if len(names) == len(document_ids) else f" +{len(document_ids) - len(names)} more"
        parts.append("documents=" + ", ".join(names) + suffix)
    if categories:
        parts.append("categories=" + ", ".join(categories))
    if document_types:
        parts.append("file_types=" + ", ".join(document_types))
    return "; ".join(parts) if parts else "All accessible documents"


def get_document_or_403(db: Session, user: User, document_id: int) -> Document:
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise AccessDeniedError("Document not found.")
    if not user_can_access_document(user, document):
        raise AccessDeniedError("You do not have permission to access this document.")
    return document


def decrypt_document_text_bytes(document: Document) -> bytes:
    """Decrypts a document's raw bytes into memory only (never written back to disk unencrypted)."""
    return decrypt_file_from_path(Path(document.encrypted_file_path))


def delete_document(db: Session, document: Document) -> None:
    try:
        Path(document.encrypted_file_path).unlink(missing_ok=True)
    except OSError:
        pass
    vector_service.delete_document_vectors(document.id)
    db.delete(document)
    db.commit()
