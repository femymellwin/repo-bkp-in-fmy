from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from sqlalchemy.orm import Session

from app.models.document import Document, DocumentIndexTest
from app.services import vector_service


@dataclass
class ChunkAgentPlan:
    chunk_size: int
    chunk_overlap: int
    strategy: str
    agent_name: str
    reason: str


def _clamp(value: int, lower: int, upper: int) -> int:
    return max(lower, min(value, upper))


def decide_chunk_plan(
    *,
    document_type: str,
    filename: str,
    doc_kind: str,
    text: str,
    default_chunk_size: int,
    default_chunk_overlap: int,
) -> ChunkAgentPlan:
    """Choose a chunking plan from the actual extracted document profile.

    This is intentionally local and deterministic. It behaves like a small
    ingestion agent: it inspects the extracted text, file type, estimated
    structure, and document purpose, then records why it changed or kept the
    base chunking settings. No school content is sent outside the appliance.
    """
    words = text.split()
    word_count = len(words)
    line_count = max(1, text.count("\n") + 1)
    avg_line_words = word_count / line_count
    file_type = (document_type or "").lower().lstrip(".")
    kind = (doc_kind or "general").lower()
    name = (filename or "").lower()

    size = int(default_chunk_size or 800)
    overlap = int(default_chunk_overlap or 120)
    reasons: list[str] = [
        f"profile: {word_count} words, {line_count} lines, {avg_line_words:.1f} words/line, type={file_type or 'unknown'}"
    ]

    if file_type in {"csv", "xlsx"}:
        size = 500 if word_count > 2500 else 350
        overlap = 50
        strategy = "agent_adaptive_tabular_window"
        reasons.append("tabular document: smaller row-aware chunks reduce unrelated rows being embedded together")
    elif word_count < 900:
        size = _clamp(max(220, word_count + 80), 220, 420)
        overlap = min(45, max(20, size // 8))
        strategy = "agent_adaptive_short_document_window"
        reasons.append("short document: compact chunks preserve precision and avoid over-fragmentation")
    elif "question" in kind or "answer" in kind or "worksheet" in kind or "exam" in name:
        size = 520
        overlap = 80
        strategy = "agent_adaptive_assessment_window"
        reasons.append("assessment-style document: medium chunks preserve question/answer boundaries")
    elif "policy" in kind or "circular" in kind or "handbook" in name:
        size = 700
        overlap = 110
        strategy = "agent_adaptive_policy_window"
        reasons.append("policy/circular document: section-sized chunks improve citation and retrieval quality")
    elif word_count > 18000:
        size = 950
        overlap = 150
        strategy = "agent_adaptive_long_document_window"
        reasons.append("long document: larger chunks reduce index bloat while overlap protects boundary answers")
    else:
        strategy = "agent_adaptive_word_window"
        reasons.append("standard document profile: kept the configured file-type chunking range")

    # Keep overlap in a useful range and always below size.
    overlap = _clamp(overlap, 0, max(0, min(size - 1, size // 3)))
    size = _clamp(size, 120, 1800)
    return ChunkAgentPlan(
        chunk_size=size,
        chunk_overlap=overlap,
        strategy=strategy,
        agent_name="SchoolAI Adaptive Chunk Agent v1",
        reason="; ".join(reasons),
    )


def _clean_query(value: str, max_words: int = 22) -> str:
    value = re.sub(r"\s+", " ", value or "").strip()
    words = value.split()
    return " ".join(words[:max_words])


def _quality_queries(document: Document, text: str, chunks: list[str]) -> list[tuple[str, str]]:
    queries: list[tuple[str, str]] = []
    title_bits = [document.filename, document.subject, document.grade, document.academic_year, document.doc_kind]
    title_query = _clean_query(" ".join(x for x in title_bits if x), 18)
    if title_query:
        queries.append(("metadata_lookup", title_query))
    if chunks:
        first_chunk_query = _clean_query(chunks[0], 24)
        if first_chunk_query:
            queries.append(("first_chunk_retrieval", first_chunk_query))
    # Use a mid-document query when available to detect if only the first chunk was indexed.
    if len(chunks) > 2:
        mid = chunks[len(chunks) // 2]
        mid_query = _clean_query(mid, 24)
        if mid_query:
            queries.append(("middle_chunk_retrieval", mid_query))
    # Last fallback: a normalized filename query.
    if not queries:
        queries.append(("filename_lookup", _clean_query(document.filename, 10)))
    return queries[:3]


def run_retrieval_quality_tests(
    db: Session,
    document: Document,
    text: str,
    chunks: list[str],
    model_cfg: dict[str, Any],
) -> dict[str, Any]:
    """Run automated indexing tests immediately after upload indexing.

    The tests verify that representative queries retrieve the newly indexed
    document from ChromaDB. The score is a retrieval smoke-test score, not a
    full human accuracy grade.
    """
    db.query(DocumentIndexTest).filter(DocumentIndexTest.document_id == document.id).delete()
    db.commit()

    tests = []
    passed = 0
    for test_name, query in _quality_queries(document, text, chunks):
        top_document_id: int | None = None
        score = 0.0
        detail = "No vector result returned."
        try:
            result = vector_service.query_similar(
                query,
                allowed_categories=[document.access_role],
                n_results=3,
                embedding_provider=str(model_cfg["embedding_provider"]),
                embedding_model=str(model_cfg["embedding_model_name"]),
            )
            metadatas = result.get("metadatas", [[]])[0] or []
            distances = result.get("distances", [[]])[0] or []
            if metadatas:
                top_document_id = int(metadatas[0].get("document_id") or 0) or None
                matched = any(int(meta.get("document_id") or 0) == document.id for meta in metadatas)
                passed += 1 if matched else 0
                # Chroma cosine distance: lower is better. Convert to a simple 0-100 score.
                distance = float(distances[0]) if distances else 1.0
                score = round(max(0.0, min(100.0, (1.0 - distance) * 100.0)), 2)
                detail = "Expected document found in top 3 results." if matched else "Expected document was not in the top 3 results."
        except Exception as exc:  # noqa: BLE001 - record diagnostic, do not fail ingestion
            detail = f"Quality test error: {exc}"

        passed_bool = top_document_id == document.id or "top 3" in detail and "found" in detail
        tests.append({
            "test_name": test_name,
            "query": query,
            "expected_document_id": document.id,
            "top_document_id": top_document_id,
            "passed": bool(passed_bool),
            "score": score,
            "details": detail,
        })
        db.add(DocumentIndexTest(
            document_id=document.id,
            test_name=test_name,
            query=query,
            expected_document_id=document.id,
            top_document_id=top_document_id,
            passed=bool(passed_bool),
            score=score,
            details=detail,
        ))

    total = len(tests) or 1
    pass_count = sum(1 for item in tests if item["passed"])
    pass_ratio = pass_count / total
    avg_score = round(sum(float(item["score"] or 0.0) for item in tests) / total, 2)
    if pass_ratio >= 0.67:
        status = "passed"
    elif pass_ratio > 0:
        status = "warning"
    else:
        status = "failed"

    document.retrieval_test_status = status
    document.retrieval_test_score = avg_score
    document.retrieval_test_details = json.dumps({"tests": tests, "pass_count": pass_count, "total": total}, ensure_ascii=False)[:4000]
    db.commit()
    return {"status": status, "score": avg_score, "tests": tests}
