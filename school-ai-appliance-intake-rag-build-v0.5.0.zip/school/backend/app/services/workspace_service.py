import re
from datetime import datetime

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.permissions import ALL_CATEGORIES, RoleName
from app.models.document import Document
from app.models.user import User
from app.models.workspace import Workspace, DocumentCategoryRecord

CATEGORY_DISPLAY_NAMES = {
    "policies": "Policies",
    "timetable": "Timetable",
    "curriculum": "Curriculum",
    "student_records": "Student Records",
    "staff_records": "Staff Records",
    "finance": "Finance",
    "circulars": "Circulars",
    "lesson_materials": "Lesson Materials",
}

DEFAULT_CATEGORY_DESCRIPTIONS = {
    "policies": "School policies, procedures, rules, and compliance notes.",
    "timetable": "Common timetable, period allocations, room schedules, and class schedule files.",
    "curriculum": "Syllabi, curriculum maps, textbooks, and academic standards.",
    "student_records": "Student-linked records, progress notes, and assessment documents.",
    "staff_records": "Teacher and staff-facing reference documents.",
    "finance": "Fee circulars, finance procedures, and payment information.",
    "circulars": "Announcements, notices, newsletters, and parent communications.",
    "lesson_materials": "Teacher-uploaded notes, worksheets, lesson resources, and class materials.",
}


class WorkspaceAccessError(Exception):
    pass


def slugify_category(value: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip().lower()).strip("_")
    return clean[:80] or "general"


def ensure_category_defaults(db: Session) -> None:
    existing = {row.name for row in db.query(DocumentCategoryRecord).all()}
    for name in ALL_CATEGORIES:
        if name in existing:
            continue
        db.add(DocumentCategoryRecord(
            name=name,
            display_name=CATEGORY_DISPLAY_NAMES.get(name, name.replace("_", " ").title()),
            description=DEFAULT_CATEGORY_DESCRIPTIONS.get(name, ""),
            is_active=True,
        ))
    db.commit()


def ensure_default_workspace(db: Session, user: User) -> Workspace:
    workspace = (
        db.query(Workspace)
        .filter(Workspace.owner_user_id == user.id, Workspace.is_default.is_(True))
        .first()
    )
    if workspace:
        return workspace
    workspace = Workspace(
        owner_user_id=user.id,
        name=f"{user.full_name}'s Workspace",
        description="Default personal workspace for uploads and RAG scope control.",
        is_default=True,
    )
    db.add(workspace)
    db.commit()
    db.refresh(workspace)
    return workspace


def ensure_default_workspaces_for_all_users(db: Session) -> None:
    for user in db.query(User).all():
        ensure_default_workspace(db, user)


def list_workspaces_for_user(db: Session, user: User) -> list[dict]:
    # Every user works primarily from their own workspace. School Admin and
    # Principal also get visibility of other workspaces for audit/support.
    query = db.query(Workspace)
    if user.role not in (RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value):
        query = query.filter(Workspace.owner_user_id == user.id)
    rows = query.order_by(Workspace.is_default.desc(), Workspace.name.asc()).all()
    counts = dict(
        db.query(Document.workspace_id, func.count(Document.id))
        .group_by(Document.workspace_id)
        .all()
    )
    return [
        {
            "id": w.id,
            "name": w.name,
            "description": w.description or "",
            "owner_user_id": w.owner_user_id,
            "owner_name": w.owner.full_name if w.owner else "Unknown",
            "is_default": bool(w.is_default),
            "document_count": int(counts.get(w.id, 0) or 0),
            "created_at": w.created_at,
            "updated_at": w.updated_at,
        }
        for w in rows
    ]


def create_workspace(db: Session, user: User, name: str, description: str = "") -> Workspace:
    workspace = Workspace(
        owner_user_id=user.id,
        name=name.strip()[:150] or "Untitled Workspace",
        description=(description or "").strip(),
        is_default=False,
    )
    db.add(workspace)
    db.commit()
    db.refresh(workspace)
    return workspace


def get_workspace_for_upload(db: Session, user: User, workspace_id: int | None) -> Workspace:
    if workspace_id is None:
        return ensure_default_workspace(db, user)
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace:
        raise WorkspaceAccessError("Workspace not found.")
    if workspace.owner_user_id == user.id:
        return workspace
    if user.role in (RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value):
        return workspace
    raise WorkspaceAccessError("You can upload only into your own workspace.")


def user_can_manage_workspace(user: User, workspace: Workspace) -> bool:
    return workspace.owner_user_id == user.id or user.role in (RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value)


def update_workspace(db: Session, user: User, workspace_id: int, name: str | None = None, description: str | None = None) -> Workspace:
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace or not user_can_manage_workspace(user, workspace):
        raise WorkspaceAccessError("Workspace not found or not editable by your profile.")
    if name is not None:
        workspace.name = name.strip()[:150] or workspace.name
    if description is not None:
        workspace.description = description.strip()
    workspace.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(workspace)
    return workspace


def delete_workspace(db: Session, user: User, workspace_id: int) -> None:
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace or not user_can_manage_workspace(user, workspace):
        raise WorkspaceAccessError("Workspace not found or not removable by your profile.")
    if workspace.is_default:
        raise WorkspaceAccessError("Default workspaces cannot be deleted.")
    if db.query(Document).filter(Document.workspace_id == workspace.id).count() > 0:
        raise WorkspaceAccessError("Move or delete the workspace documents before deleting this workspace.")
    db.delete(workspace)
    db.commit()


def list_categories(db: Session, active_only: bool = True) -> list[dict]:
    ensure_category_defaults(db)
    query = db.query(DocumentCategoryRecord)
    if active_only:
        query = query.filter(DocumentCategoryRecord.is_active.is_(True))
    counts = dict(db.query(Document.access_role, func.count(Document.id)).group_by(Document.access_role).all())
    rows = query.order_by(DocumentCategoryRecord.display_name.asc()).all()
    return [
        {
            "id": row.id,
            "name": row.name,
            "display_name": row.display_name,
            "description": row.description or "",
            "is_active": bool(row.is_active),
            "document_count": int(counts.get(row.name, 0) or 0),
            "created_at": row.created_at,
        }
        for row in rows
    ]


def category_exists(db: Session, name: str) -> bool:
    ensure_category_defaults(db)
    clean = slugify_category(name)
    row = db.query(DocumentCategoryRecord).filter(DocumentCategoryRecord.name == clean, DocumentCategoryRecord.is_active.is_(True)).first()
    return bool(row)


def create_category(db: Session, user: User, display_name: str, description: str = "") -> DocumentCategoryRecord:
    clean = slugify_category(display_name)
    existing = db.query(DocumentCategoryRecord).filter(DocumentCategoryRecord.name == clean).first()
    if existing:
        existing.display_name = display_name.strip()[:120] or existing.display_name
        existing.description = description.strip()
        existing.is_active = True
        db.commit()
        db.refresh(existing)
        return existing
    row = DocumentCategoryRecord(
        name=clean,
        display_name=display_name.strip()[:120] or clean.replace("_", " ").title(),
        description=description.strip(),
        is_active=True,
        created_by_id=user.id,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


def update_category(db: Session, category_id: int, display_name: str | None = None, description: str | None = None, is_active: bool | None = None) -> DocumentCategoryRecord:
    row = db.query(DocumentCategoryRecord).filter(DocumentCategoryRecord.id == category_id).first()
    if not row:
        raise WorkspaceAccessError("Category not found.")
    if display_name is not None:
        row.display_name = display_name.strip()[:120] or row.display_name
    if description is not None:
        row.description = description.strip()
    if is_active is not None:
        row.is_active = bool(is_active)
    db.commit()
    db.refresh(row)
    return row
