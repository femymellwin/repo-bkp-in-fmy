from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog


def log_action(
    db: Session,
    action: str,
    actor_email: str = "unknown",
    user_id: int | None = None,
    details: str = "",
    ip_address: str = "",
) -> AuditLog:
    entry = AuditLog(
        user_id=user_id,
        actor_email=actor_email,
        action=action,
        details=details,
        ip_address=ip_address,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
