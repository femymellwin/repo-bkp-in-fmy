from sqlalchemy.orm import Session

from app.models.timetable import TimetableEntry


def _times_overlap(start_a: str, end_a: str, start_b: str, end_b: str) -> bool:
    return start_a < end_b and start_b < end_a


def list_entries(db: Session) -> list[TimetableEntry]:
    return db.query(TimetableEntry).order_by(TimetableEntry.day_of_week, TimetableEntry.start_time).all()


def create_entry(db: Session, data: dict) -> TimetableEntry:
    entry = TimetableEntry(**data)
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def delete_entry(db: Session, entry_id: int) -> bool:
    entry = db.query(TimetableEntry).filter(TimetableEntry.id == entry_id).first()
    if not entry:
        return False
    db.delete(entry)
    db.commit()
    return True


def detect_conflicts(entries: list[TimetableEntry]) -> list[dict]:
    """
    Flags:
      - Same teacher assigned to two classes at the same day/time.
      - Same room assigned to two classes at the same day/time.
    """
    conflicts: list[dict] = []

    by_day: dict[str, list[TimetableEntry]] = {}
    for entry in entries:
        by_day.setdefault(entry.day_of_week, []).append(entry)

    for day, day_entries in by_day.items():
        for i in range(len(day_entries)):
            for j in range(i + 1, len(day_entries)):
                a, b = day_entries[i], day_entries[j]
                if not _times_overlap(a.start_time, a.end_time, b.start_time, b.end_time):
                    continue
                if a.teacher_name.strip().lower() == b.teacher_name.strip().lower():
                    conflicts.append({
                        "type": "teacher",
                        "message": (
                            f"{a.teacher_name} is double-booked on {day} "
                            f"({a.start_time}-{a.end_time} vs {b.start_time}-{b.end_time})."
                        ),
                        "entry_ids": [a.id, b.id],
                    })
                if a.room.strip().lower() == b.room.strip().lower():
                    conflicts.append({
                        "type": "room",
                        "message": (
                            f"Room {a.room} is double-booked on {day} "
                            f"({a.start_time}-{a.end_time} vs {b.start_time}-{b.end_time})."
                        ),
                        "entry_ids": [a.id, b.id],
                    })
    return conflicts
