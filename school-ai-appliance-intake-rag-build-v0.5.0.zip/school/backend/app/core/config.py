"""
Central application configuration.

All configuration is read from environment variables / a local .env file.
Nothing here ever talks to a paid cloud service - every default points at
localhost (Ollama) or to purely local files (SQLite, ChromaDB, local
sentence-transformers model).
"""
from pathlib import Path
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

# Backend root directory (…/backend)
BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    APP_NAME: str = "Private School AI Appliance"
    DEBUG: bool = True

    # Auth
    SECRET_KEY: str = "CHANGE_ME_TO_A_LONG_RANDOM_SECRET"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480

    # Database
    DATABASE_URL: str = "sqlite:///./data/school_ai.db"

    # Encryption
    ENCRYPTION_KEY: str = ""

    # Storage
    DOCUMENTS_DIR: str = "./data/encrypted_documents"
    VECTOR_DB_DIR: str = "./data/vector_store"
    BACKUP_DIR: str = "./data/backups"

    # Ollama
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen3:4b"

    # Embeddings
    # "sentence_transformers" (default) runs a local HF model on CPU.
    # "ollama" uses a local Ollama embedding model instead (e.g. nomic-embed-text),
    # which avoids loading sentence-transformers into the backend process.
    EMBEDDING_PROVIDER: str = "ollama"
    SENTENCE_TRANSFORMER_MODEL: str = "all-MiniLM-L6-v2"
    OLLAMA_EMBEDDING_MODEL: str = "embeddinggemma"

    # School
    SCHOOL_NAME: str = "Sunrise International School"
    ACADEMIC_YEAR: str = "2025-2026"

    # CORS
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def documents_path(self) -> Path:
        p = (BASE_DIR / self.DOCUMENTS_DIR).resolve()
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def vector_db_path(self) -> Path:
        p = (BASE_DIR / self.VECTOR_DB_DIR).resolve()
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def backup_path(self) -> Path:
        p = (BASE_DIR / self.BACKUP_DIR).resolve()
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def database_path(self) -> Path:
        """Absolute path to the sqlite file (for backups / health checks)."""
        db_url = self.DATABASE_URL
        if db_url.startswith("sqlite:///"):
            rel = db_url.replace("sqlite:///", "", 1)
            return (BASE_DIR / rel).resolve()
        return BASE_DIR / "data" / "school_ai.db"


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    # Make sure local data directories always exist.
    settings.documents_path
    settings.vector_db_path
    settings.backup_path
    (BASE_DIR / "data").mkdir(parents=True, exist_ok=True)
    return settings
