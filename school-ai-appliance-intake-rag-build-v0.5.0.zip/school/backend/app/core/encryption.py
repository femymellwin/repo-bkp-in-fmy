"""
Local, symmetric encryption for documents at rest.

Uses `cryptography.fernet` (AES-128-CBC + HMAC under the hood) with a key
kept only in the local .env file. Nothing is ever sent off the machine.

If no ENCRYPTION_KEY is present in .env on first run, one is generated
and written back automatically so the appliance "just works" out of the
box, while still keeping the key out of source control (.env is
git-ignored).
"""
from pathlib import Path

from cryptography.fernet import Fernet

from app.core.config import get_settings, BASE_DIR

settings = get_settings()

_fernet: Fernet | None = None


def _ensure_key_in_env_file(key: str) -> None:
    env_path = BASE_DIR / ".env"
    lines: list[str] = []
    found = False
    if env_path.exists():
        lines = env_path.read_text().splitlines()
        for i, line in enumerate(lines):
            if line.startswith("ENCRYPTION_KEY="):
                lines[i] = f"ENCRYPTION_KEY={key}"
                found = True
                break
    if not found:
        lines.append(f"ENCRYPTION_KEY={key}")
    env_path.write_text("\n".join(lines) + "\n")


def get_fernet() -> Fernet:
    global _fernet
    if _fernet is not None:
        return _fernet

    key = settings.ENCRYPTION_KEY
    if not key:
        key = Fernet.generate_key().decode()
        try:
            _ensure_key_in_env_file(key)
        except OSError:
            # If we can't write .env (e.g. read-only fs), still proceed
            # in-memory for this process run; warn via print.
            print("[encryption] WARNING: could not persist generated "
                  "ENCRYPTION_KEY to .env - documents encrypted this "
                  "session will not be decryptable after restart unless "
                  "you set ENCRYPTION_KEY manually.")
        settings.ENCRYPTION_KEY = key

    _fernet = Fernet(key.encode() if isinstance(key, str) else key)
    return _fernet


def encrypt_bytes(data: bytes) -> bytes:
    return get_fernet().encrypt(data)


def decrypt_bytes(token: bytes) -> bytes:
    return get_fernet().decrypt(token)


def encrypt_file_to_path(source_bytes: bytes, dest_path: Path) -> int:
    """Encrypts source_bytes and writes them to dest_path. Returns file size."""
    encrypted = encrypt_bytes(source_bytes)
    dest_path.write_bytes(encrypted)
    return len(encrypted)


def decrypt_file_from_path(path: Path) -> bytes:
    """Reads an encrypted file from disk and returns decrypted bytes (in memory only)."""
    encrypted = path.read_bytes()
    return decrypt_bytes(encrypted)
