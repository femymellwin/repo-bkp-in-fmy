"""
Role-based access control definitions.

This is intentionally a plain Python module (not just DB rows) so the
backend always has a safe, well-known permission matrix even before the
database has been seeded. The `Role` DB table mirrors this for
visibility/extensibility in the Settings UI, but authorization checks in
the API layer always go through `has_category_access()` /
`ROLE_PERMISSIONS` below.
"""
from enum import Enum


class RoleName(str, Enum):
    SUPER_ADMIN = "super_admin"
    SCHOOL_ADMIN = "school_admin"
    PRINCIPAL = "principal"
    TEACHER = "teacher"
    ACCOUNTS_ADMIN = "accounts_admin"


class DocumentCategory(str, Enum):
    POLICIES = "policies"
    TIMETABLE = "timetable"
    CURRICULUM = "curriculum"
    STUDENT_RECORDS = "student_records"
    STAFF_RECORDS = "staff_records"
    FINANCE = "finance"
    CIRCULARS = "circulars"
    LESSON_MATERIALS = "lesson_materials"


ALL_CATEGORIES = [c.value for c in DocumentCategory]

# Which categories each role may read/query by default.
# Super Admin is deliberately NOT given blanket access - see
# `has_category_access` below for the explicit-permission exception.
ROLE_PERMISSIONS: dict[str, list[str]] = {
    RoleName.TEACHER.value: [
        DocumentCategory.CURRICULUM.value,
        DocumentCategory.LESSON_MATERIALS.value,
        DocumentCategory.CIRCULARS.value,
        DocumentCategory.POLICIES.value,
    ],
    RoleName.ACCOUNTS_ADMIN.value: [
        DocumentCategory.FINANCE.value,
        DocumentCategory.CIRCULARS.value,
        DocumentCategory.POLICIES.value,
    ],
    RoleName.PRINCIPAL.value: ALL_CATEGORIES,
    RoleName.SCHOOL_ADMIN.value: ALL_CATEGORIES,
    RoleName.SUPER_ADMIN.value: [],  # no default document access
}

# Roles allowed to upload/manage documents (as opposed to just reading them).
# Every profile can upload into its own workspace. Actual document access is
# still governed by owner/category/superadmin rules.
UPLOAD_ROLES = set(ROLE_PERMISSIONS.keys())

# Roles allowed to see audit logs.
AUDIT_LOG_ROLES = {RoleName.SCHOOL_ADMIN.value, RoleName.PRINCIPAL.value, RoleName.SUPER_ADMIN.value}

# Roles allowed to manage users / system settings / backups.
SYSTEM_ADMIN_ROLES = {RoleName.SUPER_ADMIN.value, RoleName.SCHOOL_ADMIN.value}


def has_category_access(role: str, category: str, superadmin_permitted: bool = False) -> bool:
    """
    Returns True if a user with `role` may access a document in `category`.

    Super Admin is special-cased: they only get access to a specific
    document if that document was explicitly flagged
    `superadmin_permitted=True` at upload time - they do not get casual
    blanket access to private school documents just by virtue of being
    Super Admin.
    """
    if role == RoleName.SUPER_ADMIN.value:
        return bool(superadmin_permitted)
    return category in ROLE_PERMISSIONS.get(role, [])


def accessible_categories(role: str) -> list[str]:
    return ROLE_PERMISSIONS.get(role, [])
