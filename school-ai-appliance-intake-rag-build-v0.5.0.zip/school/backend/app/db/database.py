"""
SQLAlchemy engine, session factory, and declarative base.

SQLite is used for the local prototype. `check_same_thread=False` is
required because FastAPI may service requests on different threads than
the one that created the connection; SQLAlchemy's session-per-request
pattern (see get_db below) keeps this safe.
"""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase

from app.core.config import get_settings

settings = get_settings()

settings.database_path.parent.mkdir(parents=True, exist_ok=True)

if settings.DATABASE_URL.startswith("sqlite"):
    engine_url = f"sqlite:///{settings.database_path}"
    connect_args = {"check_same_thread": False}
else:
    engine_url = settings.DATABASE_URL
    connect_args = {}

engine = create_engine(engine_url, connect_args=connect_args, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine, future=True)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _table_columns(conn, table: str) -> set[str]:
    return {row[1] for row in conn.execute(text(f"PRAGMA table_info({table})")).fetchall()}


def _add_column_if_missing(conn, table: str, column: str, ddl_type: str, default_sql: str | None = None) -> None:
    cols = _table_columns(conn, table)
    if column in cols:
        return
    default_clause = f" DEFAULT {default_sql}" if default_sql is not None else ""
    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {ddl_type}{default_clause}"))


def _ensure_sqlite_schema_upgrades() -> None:
    """Tiny prototype migration layer for users who already ran an older build."""
    if not settings.DATABASE_URL.startswith("sqlite"):
        return
    with engine.begin() as conn:
        existing_tables = {row[0] for row in conn.execute(text("SELECT name FROM sqlite_master WHERE type='table'"))}
        if "users" in existing_tables:
            _add_column_if_missing(conn, "users", "menu_exclusions", "TEXT", "''")
            _add_column_if_missing(conn, "users", "web_search_enabled", "BOOLEAN", "0")
        if "documents" in existing_tables:
            _add_column_if_missing(conn, "documents", "workspace_id", "INTEGER")
            _add_column_if_missing(conn, "documents", "doc_kind", "VARCHAR(80)", "'general'")
            _add_column_if_missing(conn, "documents", "subject", "VARCHAR(120)", "''")
            _add_column_if_missing(conn, "documents", "grade", "VARCHAR(80)", "''")
            _add_column_if_missing(conn, "documents", "academic_year", "VARCHAR(40)", "''")
            _add_column_if_missing(conn, "documents", "chunk_size", "INTEGER", "800")
            _add_column_if_missing(conn, "documents", "chunk_overlap", "INTEGER", "120")
            _add_column_if_missing(conn, "documents", "chunking_strategy", "VARCHAR(80)", "'word_sliding_window'")
            _add_column_if_missing(conn, "documents", "extracted_text_chars", "INTEGER", "0")
            _add_column_if_missing(conn, "documents", "vector_db", "VARCHAR(80)", "'ChromaDB'")
            _add_column_if_missing(conn, "documents", "vector_collection", "VARCHAR(120)", "'school_documents'")
            _add_column_if_missing(conn, "documents", "embedding_provider", "VARCHAR(80)", "'sentence_transformers'")
            _add_column_if_missing(conn, "documents", "embedding_model", "VARCHAR(200)", "''")
            _add_column_if_missing(conn, "documents", "indexed_at", "DATETIME")
            _add_column_if_missing(conn, "documents", "index_error", "TEXT", "''")
            _add_column_if_missing(conn, "documents", "chunk_agent_name", "VARCHAR(120)", "''")
            _add_column_if_missing(conn, "documents", "chunk_agent_reason", "TEXT", "''")
            _add_column_if_missing(conn, "documents", "retrieval_test_status", "VARCHAR(40)", "'not_run'")
            _add_column_if_missing(conn, "documents", "retrieval_test_score", "FLOAT", "0.0")
            _add_column_if_missing(conn, "documents", "retrieval_test_details", "TEXT", "''")
        if "document_chunks" in existing_tables:
            _add_column_if_missing(conn, "document_chunks", "word_count", "INTEGER", "0")
            _add_column_if_missing(conn, "document_chunks", "char_count", "INTEGER", "0")
            _add_column_if_missing(conn, "document_chunks", "parent_id", "INTEGER")
            _add_column_if_missing(conn, "document_chunks", "section_title", "VARCHAR(240)", "''")
            _add_column_if_missing(conn, "document_chunks", "page_number", "INTEGER")
            _add_column_if_missing(conn, "document_chunks", "created_at", "DATETIME")
        if "ai_queries" in existing_tables:
            _add_column_if_missing(conn, "ai_queries", "model_name", "VARCHAR(150)", "''")
            _add_column_if_missing(conn, "ai_queries", "embedding_model", "VARCHAR(200)", "''")
            _add_column_if_missing(conn, "ai_queries", "prompt_tokens", "INTEGER", "0")
            _add_column_if_missing(conn, "ai_queries", "completion_tokens", "INTEGER", "0")
            _add_column_if_missing(conn, "ai_queries", "total_tokens", "INTEGER", "0")
            _add_column_if_missing(conn, "ai_queries", "duration_ms", "INTEGER", "0")
            _add_column_if_missing(conn, "ai_queries", "scope_summary", "TEXT", "'All accessible documents'")
            _add_column_if_missing(conn, "ai_queries", "workspace_id", "INTEGER")
            _add_column_if_missing(conn, "ai_queries", "project_id", "INTEGER")
            _add_column_if_missing(conn, "ai_queries", "thread_id", "INTEGER")
            _add_column_if_missing(conn, "ai_queries", "used_web_search", "INTEGER", "0")
            _add_column_if_missing(conn, "ai_queries", "web_search_provider", "VARCHAR(80)", "''")
            _add_column_if_missing(conn, "ai_queries", "web_sources", "JSON")


def init_db() -> None:
    """Create all tables and apply small additive upgrades for prototype releases."""
    from app import models  # noqa: F401  (ensures models are registered on Base)
    Base.metadata.create_all(bind=engine)
    _ensure_sqlite_schema_upgrades()
