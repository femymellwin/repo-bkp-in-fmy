from datetime import datetime
from pydantic import BaseModel


class ChunkConfig(BaseModel):
    chunk_size: int
    chunk_overlap: int


class ChunkingConfigResponse(BaseModel):
    strategy: str
    default_chunk_size: int
    default_chunk_overlap: int
    by_file_type: dict[str, ChunkConfig]
    explanation: str


class ChunkingConfigUpdate(BaseModel):
    by_file_type: dict[str, ChunkConfig]


class UploadPolicyResponse(BaseModel):
    allowed_file_types: list[str]
    max_file_size_mb: int
    extractors: dict[str, str]


class UploadPolicyUpdate(BaseModel):
    allowed_file_types: list[str]


class RagDocumentAudit(BaseModel):
    id: int
    filename: str
    document_type: str
    access_role: str
    uploaded_by: str
    upload_date: datetime
    ingestion_status: str
    chunk_count: int
    chunk_size: int
    chunk_overlap: int
    chunking_strategy: str
    extracted_text_chars: int
    vector_db: str
    vector_collection: str
    embedding_provider: str
    embedding_model: str
    indexed_at: datetime | None = None
    index_error: str = ""
    chunk_agent_name: str = ""
    chunk_agent_reason: str = ""
    retrieval_test_status: str = "not_run"
    retrieval_test_score: float = 0.0


class RagChunkAudit(BaseModel):
    id: int
    document_id: int
    filename: str
    chunk_index: int
    word_count: int
    char_count: int
    vector_id: str
    preview: str


class RagOverviewResponse(BaseModel):
    vector_db: dict
    chunking: ChunkingConfigResponse
    upload_policy: UploadPolicyResponse
    totals: dict
    ingestion_trend: list[dict]
    documents: list[RagDocumentAudit]
    recent_chunks: list[RagChunkAudit]
