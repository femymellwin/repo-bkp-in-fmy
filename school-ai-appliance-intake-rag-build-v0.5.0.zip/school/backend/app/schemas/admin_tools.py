from pydantic import BaseModel


class AdminToolRequest(BaseModel):
    tool: str  # circular | meeting_agenda | policy_summary | staff_announcement | event_plan
    title: str
    audience: str = "All Staff"
    key_points: str = ""
    tone: str = "formal"
    extra_instructions: str = ""
