from pydantic import BaseModel


class TimetableEntryCreate(BaseModel):
    class_name: str
    subject: str
    teacher_name: str
    room: str
    day_of_week: str
    start_time: str
    end_time: str


class TimetableEntryResponse(TimetableEntryCreate):
    id: int

    class Config:
        from_attributes = True


class ConflictInfo(BaseModel):
    type: str  # "teacher" | "room"
    message: str
    entry_ids: list[int]


class TimetableWithConflicts(BaseModel):
    entries: list[TimetableEntryResponse]
    conflicts: list[ConflictInfo]
