from datetime import datetime
from pydantic import BaseModel


class AnalyticsPoint(BaseModel):
    label: str
    value: float


class ModelUsagePoint(BaseModel):
    label: str
    query_count: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    avg_duration_ms: float


class RecentAIUsage(BaseModel):
    id: int
    user_email: str
    question: str
    model_name: str
    total_tokens: int
    duration_ms: int
    scope_summary: str
    created_at: datetime


class AnalyticsResponse(BaseModel):
    totals: dict[str, float | int]
    model_usage: list[ModelUsagePoint]
    ai_query_count_by_role: list[AnalyticsPoint]
    most_used_ai_tools: list[AnalyticsPoint]
    document_usage_count: list[AnalyticsPoint]
    document_type_usage: list[AnalyticsPoint]
    workspace_usage: list[AnalyticsPoint]
    scope_usage: list[AnalyticsPoint]
    recent_ai_queries: list[RecentAIUsage]
