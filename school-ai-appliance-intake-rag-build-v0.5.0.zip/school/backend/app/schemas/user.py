from datetime import datetime

from pydantic import BaseModel, EmailStr


class UserCreate(BaseModel):
    full_name: str
    email: EmailStr
    password: str
    role: str
    is_active: bool = True
    menu_exclusions: str = ""
    web_search_enabled: bool = False


class UserUpdateRole(BaseModel):
    role: str


class UserUpdate(BaseModel):
    full_name: str | None = None
    email: EmailStr | None = None
    password: str | None = None
    role: str | None = None
    is_active: bool | None = None
    menu_exclusions: str | None = None
    web_search_enabled: bool | None = None


class UserResponse(BaseModel):
    id: int
    full_name: str
    email: str
    role: str
    is_active: bool
    menu_exclusions: str = ""
    web_search_enabled: bool = False
    created_at: datetime
    last_login_at: datetime | None = None

    class Config:
        from_attributes = True
