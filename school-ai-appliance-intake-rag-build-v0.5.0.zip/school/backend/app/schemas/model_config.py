from pydantic import BaseModel


class ModelConfigResponse(BaseModel):
    ollama_base_url: str
    ollama_status: str
    local_model_name: str
    local_model_available: bool
    embedding_provider: str
    embedding_model_name: str
    embedding_model_available: bool
    available_ollama_models: list[str]
    rag_top_k: int
    notes: list[str]


class ModelConfigUpdate(BaseModel):
    local_model_name: str | None = None
    embedding_provider: str | None = None
    embedding_model_name: str | None = None
    rag_top_k: int | None = None
