from datetime import datetime

from pydantic import BaseModel


class DocumentIndexTestResponse(BaseModel):
    id: int
    document_id: int
    test_name: str
    query: str
    expected_document_id: int
    top_document_id: int | None = None
    passed: bool
    score: float
    details: str
    created_at: datetime

    class Config:
        from_attributes = True


class DocumentResponse(BaseModel):
    id: int
    filename: str
    uploaded_by: str
    upload_date: datetime
    document_type: str
    access_role: str
    file_size: int
    workspace_id: int | None = None
    workspace_name: str | None = None
    doc_kind: str = "general"
    subject: str = ""
    grade: str = ""
    academic_year: str = ""
    ingestion_status: str
    chunk_count: int
    superadmin_permitted: bool
    chunk_size: int = 800
    chunk_overlap: int = 120
    chunking_strategy: str = "word_sliding_window"
    extracted_text_chars: int = 0
    vector_db: str = "ChromaDB"
    vector_collection: str = "school_documents"
    embedding_provider: str = ""
    embedding_model: str = ""
    indexed_at: datetime | None = None
    index_error: str = ""
    chunk_agent_name: str = ""
    chunk_agent_reason: str = ""
    retrieval_test_status: str = "not_run"
    retrieval_test_score: float = 0.0
    retrieval_test_details: str = ""

    class Config:
        from_attributes = True


class DocumentUploadResponse(BaseModel):
    document: DocumentResponse
    message: str
