from datetime import datetime

from pydantic import BaseModel


class AuditLogResponse(BaseModel):
    id: int
    actor_email: str
    action: str
    details: str
    created_at: datetime

    class Config:
        from_attributes = True
