from datetime import datetime
from pydantic import BaseModel


class TeacherProfileBase(BaseModel):
    preferred_name: str = ""
    subjects: str = ""
    grades: str = ""
    bio: str = ""
    classroom_location: str = ""
    office_hours: str = ""
    extracurricular_roles: str = ""
    rag_notes: str = ""


class TeacherProfileUpdate(TeacherProfileBase):
    pass


class TeacherProfileResponse(TeacherProfileBase):
    id: int
    user_id: int
    full_name: str
    email: str
    role: str
    updated_at: datetime

    class Config:
        from_attributes = True
