from datetime import datetime

from pydantic import BaseModel, Field


class AskAIScope(BaseModel):
    workspace_id: int | None = None
    document_ids: list[int] = Field(default_factory=list)
    categories: list[str] = Field(default_factory=list)
    document_types: list[str] = Field(default_factory=list)


class AskAIRequest(BaseModel):
    question: str
    scope: AskAIScope | None = None
    project_id: int | None = None
    thread_id: int | None = None
    use_web_search: bool | None = None


class TokenUsage(BaseModel):
    model_name: str = ""
    embedding_model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    duration_ms: int = 0


class AskAIResponse(BaseModel):
    answer: str
    sources: list[str]
    web_sources: list[dict[str, str]] = Field(default_factory=list)
    found_answer: bool
    ollama_available: bool = True
    scope_summary: str = "All accessible documents"
    usage: TokenUsage = Field(default_factory=TokenUsage)
    web_search_used: bool = False
    web_search_status: str = "disabled"
    project_id: int | None = None
    thread_id: int | None = None


class AIHistoryItem(BaseModel):
    id: int
    tool: str
    question: str
    answer: str
    sources: list[str]
    found_answer: bool
    model_name: str = ""
    embedding_model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    duration_ms: int = 0
    scope_summary: str = "All accessible documents"
    used_web_search: bool = False
    web_search_provider: str = ""
    web_sources: list[dict[str, str]] = Field(default_factory=list)
    project_id: int | None = None
    thread_id: int | None = None
    created_at: datetime
