from pydantic import BaseModel


class PermissionMatrixResponse(BaseModel):
    roles: list[str]
    categories: list[str]
    read_permissions: dict[str, list[str]]
    upload_roles: list[str]
    menu_items: list[str]


class UploadRolesUpdate(BaseModel):
    upload_roles: list[str]
