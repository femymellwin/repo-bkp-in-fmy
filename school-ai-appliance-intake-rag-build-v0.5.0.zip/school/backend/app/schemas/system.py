from pydantic import BaseModel


class SystemHealthResponse(BaseModel):
    cpu_percent: float
    ram_percent: float
    ram_used_gb: float
    ram_total_gb: float
    disk_percent: float
    disk_used_gb: float
    disk_total_gb: float
    ollama_status: str  # "online" | "offline"
    ollama_model: str
    embedding_provider: str
    embedding_model: str
    embedding_status: str  # "online" | "offline" | "local-process"
    database_status: str  # "online" | "offline"
    vector_db_status: str  # "online" | "offline"
    last_backup_date: str | None = None
