from pydantic import BaseModel


class SettingsResponse(BaseModel):
    school_name: str
    academic_year: str
    local_model_name: str
    embedding_model_name: str
    embedding_provider: str
    backup_location: str
    encryption_status: str
    maintenance_mode: bool
    web_search_enabled: bool = False
    web_search_provider: str = "google"
    web_search_max_results: int = 5
    web_search_timeout_seconds: int = 8
    web_search_api_key_set: bool = False
    web_search_google_cx: str = ""
    web_search_google_cx_set: bool = False
    web_search_searxng_url: str = ""


class SettingsUpdateRequest(BaseModel):
    school_name: str | None = None
    academic_year: str | None = None
    local_model_name: str | None = None
    embedding_model_name: str | None = None
    embedding_provider: str | None = None
    maintenance_mode: bool | None = None
    web_search_enabled: bool | None = None
    web_search_provider: str | None = None
    web_search_max_results: int | None = None
    web_search_timeout_seconds: int | None = None
    web_search_api_key: str | None = None
    web_search_google_cx: str | None = None
    web_search_searxng_url: str | None = None
