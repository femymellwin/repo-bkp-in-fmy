from datetime import date, datetime
from pydantic import BaseModel


class OnboardingItemCreate(BaseModel):
    title: str
    category: str = "extracurricular"
    owner_user_id: int | None = None
    status: str = "not_started"
    due_date: date | None = None
    notes: str = ""


class OnboardingItemUpdate(BaseModel):
    title: str | None = None
    category: str | None = None
    owner_user_id: int | None = None
    status: str | None = None
    due_date: date | None = None
    notes: str | None = None


class OnboardingItemResponse(BaseModel):
    id: int
    title: str
    category: str
    owner_user_id: int | None = None
    owner_name: str | None = None
    status: str
    due_date: date | None = None
    notes: str
    created_at: datetime
    updated_at: datetime
