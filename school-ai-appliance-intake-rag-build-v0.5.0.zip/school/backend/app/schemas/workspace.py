from datetime import datetime

from pydantic import BaseModel, Field


class WorkspaceResponse(BaseModel):
    id: int
    name: str
    description: str = ""
    owner_user_id: int
    owner_name: str
    is_default: bool
    document_count: int = 0
    created_at: datetime
    updated_at: datetime


class WorkspaceCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=150)
    description: str = ""


class WorkspaceUpdate(BaseModel):
    name: str | None = Field(default=None, max_length=150)
    description: str | None = None


class DocumentCategoryResponse(BaseModel):
    id: int
    name: str
    display_name: str
    description: str = ""
    is_active: bool
    document_count: int = 0
    created_at: datetime


class DocumentCategoryCreate(BaseModel):
    display_name: str = Field(..., min_length=1, max_length=120)
    description: str = ""


class DocumentCategoryUpdate(BaseModel):
    display_name: str | None = Field(default=None, max_length=120)
    description: str | None = None
    is_active: bool | None = None
