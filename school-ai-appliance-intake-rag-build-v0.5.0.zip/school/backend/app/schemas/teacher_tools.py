from pydantic import BaseModel


class TeacherToolRequest(BaseModel):
    tool: str  # lesson_plan | worksheet | quiz | parent_message | feedback_comment
    grade: str
    subject: str
    topic: str
    duration: str = ""
    difficulty: str = "medium"
    extra_instructions: str = ""


class ToolGenerationResponse(BaseModel):
    output: str
    tool: str
    ollama_available: bool = True
