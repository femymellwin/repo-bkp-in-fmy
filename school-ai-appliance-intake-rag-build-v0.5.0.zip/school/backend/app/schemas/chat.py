from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class ChatProjectCreate(BaseModel):
    name: str
    description: str = ""
    color: str = "indigo"


class ChatProjectUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    color: str | None = None


class ChatProjectResponse(BaseModel):
    id: int
    name: str
    description: str = ""
    color: str = "indigo"
    is_default: bool
    thread_count: int = 0
    created_at: datetime
    updated_at: datetime


class ChatThreadCreate(BaseModel):
    project_id: int | None = None
    title: str = "New chat"
    scope_json: dict[str, Any] = Field(default_factory=dict)
    web_search_requested: bool = False


class ChatThreadUpdate(BaseModel):
    title: str | None = None


class ChatThreadResponse(BaseModel):
    id: int
    project_id: int
    title: str
    scope_json: dict[str, Any] = Field(default_factory=dict)
    web_search_requested: bool = False
    message_count: int = 0
    created_at: datetime
    updated_at: datetime


class ChatMessageResponse(BaseModel):
    id: int
    thread_id: int
    role: str
    content: str
    sources: list[str] = Field(default_factory=list)
    web_sources: list[dict[str, str]] = Field(default_factory=list)
    usage: dict[str, Any] = Field(default_factory=dict)
    scope_summary: str = "All accessible documents"
    used_web_search: bool = False
    created_at: datetime


class ChatBootstrapResponse(BaseModel):
    projects: list[ChatProjectResponse]
    threads: list[ChatThreadResponse]
    web_search: dict[str, Any]
