from datetime import datetime

from pydantic import BaseModel


class BackupRecordResponse(BaseModel):
    id: int
    filename: str
    file_size: int
    created_by: str
    created_at: datetime

    class Config:
        from_attributes = True
