"""
Seeds the local SQLite database with:
  - the 5 default test users (one per role)
  - the Role reference table (mirrors app.core.permissions matrix)
  - a small sample timetable (including one deliberate conflict, so the
    conflict-detection feature has something to show on first run)
  - default application settings

Run with:  python seed.py   (from inside backend/, with the venv active)
Safe to re-run - it skips anything that already exists.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.db.database import init_db, SessionLocal
from app.core.security import hash_password
from app.core.permissions import ROLE_PERMISSIONS, RoleName
from app.models.user import User
from app.models.role import Role
from app.models.timetable import TimetableEntry
from app.models.teacher_profile import TeacherProfile
from app.models.onboarding import OnboardingItem
from app.services.settings_service import ensure_defaults

DEFAULT_USERS = [
    ("Super Admin", "superadmin@example.com", "password123", RoleName.SUPER_ADMIN.value),
    ("School Admin", "admin@example.com", "password123", RoleName.SCHOOL_ADMIN.value),
    ("Principal", "principal@example.com", "password123", RoleName.PRINCIPAL.value),
    ("Teacher", "teacher@example.com", "password123", RoleName.TEACHER.value),
    ("Accounts Staff", "accounts@example.com", "password123", RoleName.ACCOUNTS_ADMIN.value),
]

ROLE_DISPLAY_NAMES = {
    RoleName.SUPER_ADMIN.value: "Super Admin",
    RoleName.SCHOOL_ADMIN.value: "School Admin",
    RoleName.PRINCIPAL.value: "Principal",
    RoleName.TEACHER.value: "Teacher",
    RoleName.ACCOUNTS_ADMIN.value: "Accounts / Admin Staff",
}

SAMPLE_TIMETABLE = [
    {"class_name": "Grade 5A", "subject": "Science", "teacher_name": "Ms. Fatima Al Hashimi", "room": "Room 101", "day_of_week": "Monday", "start_time": "09:00", "end_time": "09:45"},
    {"class_name": "Grade 5B", "subject": "Mathematics", "teacher_name": "Mr. Rahul Nair", "room": "Room 102", "day_of_week": "Monday", "start_time": "09:00", "end_time": "09:45"},
    {"class_name": "Grade 6A", "subject": "English", "teacher_name": "Ms. Sara Idris", "room": "Room 103", "day_of_week": "Monday", "start_time": "10:00", "end_time": "10:45"},
    # Deliberate conflict: same teacher, overlapping time, different classes.
    {"class_name": "Grade 6B", "subject": "Science", "teacher_name": "Ms. Fatima Al Hashimi", "room": "Room 104", "day_of_week": "Monday", "start_time": "09:30", "end_time": "10:15"},
    {"class_name": "Grade 7A", "subject": "History", "teacher_name": "Mr. Omar Khalid", "room": "Room 101", "day_of_week": "Tuesday", "start_time": "11:00", "end_time": "11:45"},
]


def seed():
    init_db()
    db = SessionLocal()
    try:
        # --- Users ---
        for full_name, email, password, role in DEFAULT_USERS:
            existing = db.query(User).filter(User.email == email).first()
            if existing:
                print(f"[seed] User already exists, skipping: {email}")
                continue
            user = User(
                full_name=full_name,
                email=email,
                hashed_password=hash_password(password),
                role=role,
                is_active=True,
            )
            db.add(user)
            print(f"[seed] Created user: {email} ({role})")
        db.commit()

        # --- Roles reference table ---
        for role_value, categories in ROLE_PERMISSIONS.items():
            existing_role = db.query(Role).filter(Role.name == role_value).first()
            if existing_role:
                continue
            db.add(Role(
                name=role_value,
                display_name=ROLE_DISPLAY_NAMES.get(role_value, role_value),
                description=f"Auto-generated from permission matrix for {role_value}.",
                allowed_categories=categories,
            ))
        db.commit()

        # --- Sample timetable ---
        if db.query(TimetableEntry).count() == 0:
            for entry in SAMPLE_TIMETABLE:
                db.add(TimetableEntry(**entry))
            db.commit()
            print(f"[seed] Created {len(SAMPLE_TIMETABLE)} sample timetable entries "
                  f"(includes one deliberate teacher conflict for demo purposes).")
        else:
            print("[seed] Timetable already has data, skipping.")

        # --- Teacher profile sample ---
        teacher = db.query(User).filter(User.email == "teacher@example.com").first()
        if teacher and not db.query(TeacherProfile).filter(TeacherProfile.user_id == teacher.id).first():
            db.add(TeacherProfile(
                user_id=teacher.id, preferred_name="Demo Teacher", subjects="Science, Mathematics",
                grades="Grade 5, Grade 6", extracurricular_roles="Robotics club coordinator",
                rag_notes="Prefers concise lesson plans with hands-on activity ideas.",
            ))
            db.commit()
            print("[seed] Created sample teacher profile.")

        # --- Onboarding sample ---
        if db.query(OnboardingItem).count() == 0:
            db.add(OnboardingItem(
                title="Set up Robotics Club onboarding pack", category="extracurricular",
                owner_user_id=teacher.id if teacher else None, status="not_started",
                notes="Collect consent form, club rules, equipment list, and first-session plan.",
            ))
            db.commit()
            print("[seed] Created sample extracurricular onboarding item.")

        # --- Default settings ---
        ensure_defaults(db)
        print("[seed] Default settings ensured.")

        print("\n[seed] Done. You can now log in with any of these accounts (password: password123):")
        for full_name, email, _, role in DEFAULT_USERS:
            print(f"        {email}  -  {ROLE_DISPLAY_NAMES.get(role, role)}")

    finally:
        db.close()


if __name__ == "__main__":
    seed()
