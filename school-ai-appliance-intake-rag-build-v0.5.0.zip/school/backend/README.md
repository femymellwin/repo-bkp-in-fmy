# Private School AI Appliance — Backend

FastAPI + SQLite + ChromaDB + local Ollama. See the top-level `README.md` and `RUN_LOCAL.md` for the preferred setup.

## Recommended local run

Run the full app from the project root:

```bash
./run_local.sh
```

The root launcher starts both backend and frontend. It also protects you from the Python 3.14 `pydantic-core` build failure by only using Python 3.11 or Python 3.12 for `backend/venv`.

## Backend-only manual setup

Use Python 3.12 or 3.11 only:

```bash
cd backend
rm -rf venv
python3.12 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install --prefer-binary -r requirements-lite.txt
cp .env.example .env
python seed.py
uvicorn app.main:app --reload --port 8000
```

For the local Ollama embedding setup, `requirements-lite.txt` is recommended because it avoids the large `sentence-transformers` and Torch dependency. It includes `email-validator==2.2.0`.

API docs once running: http://localhost:8000/docs

## Project layout

```text
app/
  core/       # config, security, encryption, permissions
  db/         # SQLAlchemy engine/session
  models/     # SQLAlchemy ORM models
  schemas/    # Pydantic request/response schemas
  services/   # business logic (auth, documents, ingestion, AI, etc.)
  api/        # FastAPI routers (thin, delegate to services)
  utils/      # text extraction, chunking, file helpers
seed.py       # creates default users + sample data
```

## v0.4.0 optional web search

The backend now supports optional web search as an additional retrieval source for Ask School AI.

Control flow:

1. `Settings.web_search_enabled` must be true.
2. `User.web_search_enabled` must be true for the current user.
3. The Ask request may pass `use_web_search=true`.

When enabled, `ai_service.ask_school_ai` retrieves local RAG snippets and web snippets, then sends both to the local Ollama model. Uploaded documents remain local and encrypted.

Supported providers:

- `duckduckgo` - no key required, uses DuckDuckGo HTML search.
- `brave` - uses Brave Search API with `web_search_api_key` stored in settings.

Chat projects and persistent chat threads are stored in `chat_projects`, `chat_threads`, and `chat_messages`.
