#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

PRODUCT_NAME="ForgeBridge"
PRODUCT_VERSION="0.1.2"
BUILD_NUMBER="FB-0.1.2-004"
IMAGE_NAME="forgebridge/app:0.1.2-004"
GEI_VERSION="1.30.3"
DEFAULT_PORT="3002"
POLICY_MODE="github-supported-only"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

COMPOSE_FILE="$SCRIPT_DIR/docker-compose.yml"
ENV_FILE="${FORGEBRIDGE_ENV_FILE:-$SCRIPT_DIR/.env.production}"
PROJECT_NAME="${FORGEBRIDGE_PROJECT_NAME:-forgebridge}"
BACKUP_DIR="$SCRIPT_DIR/backups"
RELEASE_MANIFEST="$SCRIPT_DIR/RELEASE-SHA256SUMS"
BUILD_INFO_FILE="$SCRIPT_DIR/BUILD-INFO.env"
INSTALL_RECEIPT="$SCRIPT_DIR/INSTALLATION-RECEIPT.txt"
NEW_ENV=0
IMPORTED_ENV=0
IMPORT_ENV_PATH=""
REPLACE_ENV=0

say() { printf '[ForgeBridge] %s\n' "$*"; }
warn() { printf '[ForgeBridge] WARNING: %s\n' "$*" >&2; }
fail() { printf '[ForgeBridge] ERROR: %s\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

compose() {
  docker compose --project-name "$PROJECT_NAME" --env-file "$ENV_FILE" --file "$COMPOSE_FILE" "$@"
}

env_value() {
  local key="$1" value
  value="$(grep -E "^${key}=" "$ENV_FILE" 2>/dev/null | tail -n 1 | cut -d= -f2- || true)"
  value="${value#\'}"; value="${value%\'}"
  value="${value#\"}"; value="${value%\"}"
  printf '%s' "$value"
}

set_env_value() {
  local key="$1" value="$2" temporary
  temporary="$(mktemp "${ENV_FILE}.tmp.XXXXXX")"
  awk -v key="$key" -v value="$value" '
    BEGIN { found = 0 }
    index($0, key "=") == 1 { print key "=" value; found = 1; next }
    { print }
    END { if (!found) print key "=" value }
  ' "$ENV_FILE" > "$temporary"
  chmod 600 "$temporary"
  mv "$temporary" "$ENV_FILE"
}

ensure_env_value() {
  local key="$1" value="$2"
  if ! grep -qE "^${key}=" "$ENV_FILE"; then
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
  fi
}

hash_file() {
  local path="$1"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$path" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$path" | awk '{print $1}'
  else
    fail "sha256sum or shasum is required for release integrity verification."
  fi
}

verify_release_manifest() {
  [[ -f "$RELEASE_MANIFEST" ]] || fail "Missing release integrity manifest: RELEASE-SHA256SUMS"
  local output status
  output="$(mktemp "${TMPDIR:-/tmp}/forgebridge-integrity.XXXXXX.log")"
  set +e
  if command -v sha256sum >/dev/null 2>&1; then
    (cd "$SCRIPT_DIR" && sha256sum -c "$(basename "$RELEASE_MANIFEST")") >"$output" 2>&1
    status=$?
  elif command -v shasum >/dev/null 2>&1; then
    (cd "$SCRIPT_DIR" && shasum -a 256 -c "$(basename "$RELEASE_MANIFEST")") >"$output" 2>&1
    status=$?
  else
    rm -f "$output"
    fail "sha256sum or shasum is required for release integrity verification."
  fi
  set -e
  if [[ $status -ne 0 ]]; then
    cat "$output" >&2
    rm -f "$output"
    fail "Release integrity verification failed. Re-extract the official Build 004 package into a new directory."
  fi
  rm -f "$output"
}

verify_build_identity() {
  [[ -f "$BUILD_INFO_FILE" ]] || fail "Missing BUILD-INFO.env"
  grep -qx "FORGEBRIDGE_VERSION=${PRODUCT_VERSION}" "$BUILD_INFO_FILE" || fail "Build version metadata does not match ${PRODUCT_VERSION}."
  grep -qx "FORGEBRIDGE_BUILD=${BUILD_NUMBER}" "$BUILD_INFO_FILE" || fail "Build metadata does not match ${BUILD_NUMBER}."
  grep -qx "FORGEBRIDGE_PORT=${DEFAULT_PORT}" "$BUILD_INFO_FILE" || fail "Build metadata does not require port ${DEFAULT_PORT}."
  grep -qx "MIGRATION_POLICY_MODE=${POLICY_MODE}" "$BUILD_INFO_FILE" || fail "Build metadata does not enforce the GitHub-supported-only policy."
  grep -qx "GEI_VERSION=${GEI_VERSION}" "$BUILD_INFO_FILE" || fail "Build metadata does not pin GEI ${GEI_VERSION}."
}

verify_source_contract() {
  [[ -f "$COMPOSE_FILE" ]] || fail "Missing docker-compose.yml"
  [[ -f "$SCRIPT_DIR/Dockerfile" ]] || fail "Missing Dockerfile"
  [[ -f "$SCRIPT_DIR/vendor/gei/GEI.lock" ]] || fail "Missing pinned GEI release manifest"

  grep -q 'FROM debian:trixie-slim' "$SCRIPT_DIR/Dockerfile" || fail "Dockerfile is not the Build 004 PyPI-free runtime."
  grep -q 'EXPOSE 3002' "$SCRIPT_DIR/Dockerfile" || fail "Dockerfile does not expose port 3002."
  grep -q 'ARG GEI_VERSION=1.30.3' "$SCRIPT_DIR/Dockerfile" || fail "Dockerfile does not pin GEI v1.30.3."
  grep -q 'image: forgebridge/app:0.1.2-004' "$COMPOSE_FILE" || fail "Compose image tag does not match Build 004."
  grep -q 'GEI_BINARY: gei' "$COMPOSE_FILE" || fail "Compose is not configured for GitHub's official standalone GEI executable."
  grep -q 'MIGRATION_POLICY_MODE: ${MIGRATION_POLICY_MODE}' "$COMPOSE_FILE" || fail "Compose does not enforce the supported-method policy setting."

  if grep -Eqi 'python[0-9.]*[[:space:]]+-m[[:space:]]+pip|pip[[:space:]]+install|https?://pypi\.org|COPY[[:space:]]+requirements\.txt' "$SCRIPT_DIR/Dockerfile"; then
    fail "Dockerfile unexpectedly contains a pip or PyPI production dependency."
  fi
  if [[ -f "$SCRIPT_DIR/requirements.txt" ]]; then
    fail "Build 004 must not contain a production requirements.txt file."
  fi
  if grep -RIEq 'git[[:space:]]+push[[:space:]]+--mirror|ghe-migrator' "$SCRIPT_DIR/app" "$SCRIPT_DIR/Dockerfile" "$SCRIPT_DIR/docker-compose.yml"; then
    fail "An unsupported migration implementation was detected."
  fi
  if grep -RIEq 'gh[[:space:]]+extension[[:space:]]+install|gh[[:space:]]+gei' "$SCRIPT_DIR/app" "$SCRIPT_DIR/Dockerfile" "$SCRIPT_DIR/docker-compose.yml"; then
    fail "Floating GitHub CLI extension execution is disabled in this sealed runtime."
  fi

  local shell_count
  shell_count="$(find "$SCRIPT_DIR" -type f -name '*.sh' ! -path "$SCRIPT_DIR/backups/*" | wc -l | tr -d ' ')"
  [[ "$shell_count" == "1" ]] || fail "Build 004 must expose exactly one shell entrypoint: forgebridge.sh"
}

parse_options() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --import-env)
        [[ $# -ge 2 ]] || fail "--import-env requires a path."
        IMPORT_ENV_PATH="$2"
        shift 2
        ;;
      --replace-env)
        [[ $# -ge 2 ]] || fail "--replace-env requires a path."
        IMPORT_ENV_PATH="$2"
        REPLACE_ENV=1
        shift 2
        ;;
      *)
        fail "Unknown option: $1"
        ;;
    esac
  done
}

import_environment_if_requested() {
  if [[ -z "$IMPORT_ENV_PATH" ]]; then
    return 0
  fi
  local source_path timestamp
  source_path="$(cd "$(dirname "$IMPORT_ENV_PATH")" 2>/dev/null && pwd)/$(basename "$IMPORT_ENV_PATH")" || fail "Cannot resolve environment file: $IMPORT_ENV_PATH"
  [[ -f "$source_path" ]] || fail "Environment file not found: $source_path"
  if [[ "$source_path" == "$ENV_FILE" ]]; then
    IMPORT_ENV_PATH=""
    return
  fi

  if [[ -f "$ENV_FILE" && "$REPLACE_ENV" -ne 1 ]]; then
    fail "$ENV_FILE already exists. Use --replace-env only when you intentionally want to replace it."
  fi
  if [[ -f "$ENV_FILE" ]]; then
    timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
    cp -p "$ENV_FILE" "${ENV_FILE}.before-import-${timestamp}"
    chmod 600 "${ENV_FILE}.before-import-${timestamp}"
    say "Backed up the previous environment file."
  fi
  cp -p "$source_path" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  IMPORTED_ENV=1
  IMPORT_ENV_PATH=""
  say "Imported protected production configuration from: $source_path"
}

create_environment() {
  if [[ -f "$ENV_FILE" ]]; then
    chmod 600 "$ENV_FILE" 2>/dev/null || true
    return
  fi

  need openssl
  umask 077
  local secret_key encryption_key postgres_password admin_password
  secret_key="$(openssl rand -hex 48)"
  encryption_key="$(openssl rand -base64 32 | tr '+/' '-_' | tr -d '\n')"
  postgres_password="$(openssl rand -hex 24)"
  admin_password="$(openssl rand -base64 24 | tr '+/' '-_' | tr -d '\n')"

  cat > "$ENV_FILE" <<ENV
APP_NAME=ForgeBridge
APP_TAGLINE='Controlled, auditable GHES-to-GHEC migrations.'
APP_VERSION=${PRODUCT_VERSION}
APP_BUILD_NUMBER=${BUILD_NUMBER}
COMPANY_NAME='Inception UAE'
EDITION_LABEL=Enterprise
ENVIRONMENT=production
LOG_LEVEL=INFO

FORGEBRIDGE_BIND_ADDRESS=127.0.0.1
FORGEBRIDGE_PORT=${DEFAULT_PORT}
WEB_WORKERS=2
CELERY_CONCURRENCY=4
FORWARDED_ALLOW_IPS=*
SESSION_COOKIE_NAME=forgebridge_session
SESSION_COOKIE_SECURE=false

SECRET_KEY=$secret_key
TOKEN_ENCRYPTION_KEY=$encryption_key
POSTGRES_DB=forgebridge
POSTGRES_USER=forgebridge
POSTGRES_PASSWORD=$postgres_password
DEFAULT_ADMIN_USERNAME=admin
DEFAULT_ADMIN_EMAIL=admin@example.com
DEFAULT_ADMIN_PASSWORD=$admin_password

MIGRATION_POLICY_MODE=${POLICY_MODE}
ENABLE_REAL_MIGRATIONS=false
ENABLE_ELM=false
ENABLE_DESTRUCTIVE_PURGE=false
ENABLE_SOURCE_FREEZE=false
COMMAND_TIMEOUT_SECONDS=21600
GITHUB_API_VERSION=2022-11-28

ENABLE_LARGE_FILE_SCAN=false
LARGE_FILE_WARNING_BYTES=52428800
LARGE_FILE_BLOCKER_BYTES=104857600
LARGE_FILE_SCAN_TIMEOUT_SECONDS=3600
LARGE_FILE_SCAN_TOP_N=100

ELM_SSH_HOST=
ELM_SSH_USER=admin
ELM_SSH_PORT=122
ELM_SSH_IDENTITY_FILE=
ELM_POLL_INTERVAL_SECONDS=30
ELM_READY_TIMEOUT_SECONDS=21600
ELM_COMPLETION_TIMEOUT_SECONDS=3600

AI_REQUEST_TIMEOUT_SECONDS=60
AI_MAX_LOG_CHARS=120000
ENV
  chmod 600 "$ENV_FILE"
  NEW_ENV=1
  say "Created protected production configuration: $ENV_FILE"
}

upgrade_environment_defaults() {
  if [[ ! -f "$ENV_FILE" ]]; then
    return 0
  fi
  local version build policy port
  version="$(env_value APP_VERSION)"
  build="$(env_value APP_BUILD_NUMBER)"
  policy="$(env_value MIGRATION_POLICY_MODE)"
  port="$(env_value FORGEBRIDGE_PORT)"

  case "$version" in
    0.1.0|0.1.1|"") set_env_value APP_VERSION "$PRODUCT_VERSION" ;;
  esac
  case "$build" in
    FB-0.1.2-001|FB-0.1.2-002|FB-0.1.2-003|"")
      set_env_value APP_BUILD_NUMBER "$BUILD_NUMBER"
      say "Updated the packaged build identity to ${BUILD_NUMBER}; custom build numbers were preserved."
      ;;
  esac
  if [[ -n "$policy" && "$policy" != "$POLICY_MODE" ]]; then
    fail "MIGRATION_POLICY_MODE must be ${POLICY_MODE}."
  fi
  if [[ -n "$port" && "$port" != "$DEFAULT_PORT" ]]; then
    fail "This build is fixed to port ${DEFAULT_PORT}; FORGEBRIDGE_PORT is currently ${port}."
  fi

  ensure_env_value MIGRATION_POLICY_MODE "$POLICY_MODE"
  ensure_env_value ENABLE_ELM false
  ensure_env_value FORGEBRIDGE_PORT "$DEFAULT_PORT"
  chmod 600 "$ENV_FILE"
}

validate_environment() {
  local key
  for key in APP_NAME APP_VERSION APP_BUILD_NUMBER SECRET_KEY TOKEN_ENCRYPTION_KEY POSTGRES_DB POSTGRES_USER POSTGRES_PASSWORD DEFAULT_ADMIN_USERNAME DEFAULT_ADMIN_PASSWORD MIGRATION_POLICY_MODE FORGEBRIDGE_PORT; do
    [[ -n "$(env_value "$key")" ]] || fail "Required configuration value is missing: $key"
  done
  [[ "$(env_value MIGRATION_POLICY_MODE)" == "$POLICY_MODE" ]] || fail "Only the ${POLICY_MODE} migration policy is allowed."
  [[ "$(env_value FORGEBRIDGE_PORT)" == "$DEFAULT_PORT" ]] || fail "ForgeBridge must run on port ${DEFAULT_PORT}."
}

check_disk_space() {
  local available_kb
  available_kb="$(df -Pk "$SCRIPT_DIR" | awk 'NR==2 {print $4}')"
  if [[ "$available_kb" =~ ^[0-9]+$ ]]; then
    if [[ "$available_kb" -lt 4194304 ]]; then
      fail "Less than 4 GiB of free disk space is available. Free space before installation."
    elif [[ "$available_kb" -lt 10485760 ]]; then
      warn "Less than 10 GiB of free disk space is available; large image builds and migration evidence may need more."
    fi
  fi
}

prepare_environment() {
  import_environment_if_requested
  create_environment
  upgrade_environment_defaults
  validate_environment
}

preflight() {
  need docker
  need curl
  need openssl
  docker info >/dev/null 2>&1 || fail "Docker Desktop or the Docker daemon is not running."
  docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 is required."
  verify_release_manifest
  verify_build_identity
  verify_source_contract
  prepare_environment
  check_disk_space
  compose config --quiet
}

build_images() {
  local no_cache="${1:-0}" build_log status
  local -a arguments
  arguments=(build --pull)
  if [[ "$no_cache" == "1" ]]; then
    arguments+=(--no-cache)
  fi
  arguments+=(web)

  build_log="$(mktemp "${TMPDIR:-/tmp}/forgebridge-build.XXXXXX.log")"
  set +e
  compose "${arguments[@]}" 2>&1 | tee "$build_log"
  status=${PIPESTATUS[0]}
  set -e
  if [[ $status -ne 0 ]]; then
    if grep -Eqi 'pypi\.org|/simple/fastapi|python[^ ]*[[:space:]]+-m[[:space:]]+pip|pip[[:space:]]+install' "$build_log"; then
      cat >&2 <<'HELP'

[ForgeBridge] Build 004 never uses pip or PyPI. This output can only come from
an older ForgeBridge directory or Dockerfile. Do not reuse the old directory.
Run the installer from the uniquely named forgebridge-0.1.2-build-004 folder:

  ./forgebridge.sh install

The installer verifies the complete release hash manifest before Docker starts.
HELP
    fi
    rm -f "$build_log"
    return "$status"
  fi
  rm -f "$build_log"
}

verify_runtime_image() {
  local revision
  revision="$(docker image inspect "$IMAGE_NAME" --format '{{ index .Config.Labels "org.opencontainers.image.revision" }}' 2>/dev/null || true)"
  [[ "$revision" == "$BUILD_NUMBER" ]] || fail "Built image revision is '$revision', expected '$BUILD_NUMBER'."
  compose run --rm --no-deps web sh -lc '
    set -eu
    python3 -c "import alembic, celery, fastapi, psycopg, pydantic_settings, redis, sqlalchemy, uvicorn; print(\"Python runtime: ready\")"
    gei --version
    gei migrate-repo --help >/dev/null
    printf "GitHub Enterprise Importer: ready\n"
  '
}

run_database_migrations() {
  say "Starting PostgreSQL and Redis..."
  compose up -d postgres redis
  say "Applying Alembic database migrations..."
  compose run --rm migrate
  say "Applying idempotent application seed data..."
  compose run --rm seed
}

wait_for_health() {
  local port bind health_url attempt
  port="$(env_value FORGEBRIDGE_PORT)"; port="${port:-$DEFAULT_PORT}"
  bind="$(env_value FORGEBRIDGE_BIND_ADDRESS)"; bind="${bind:-127.0.0.1}"
  [[ "$bind" == "0.0.0.0" || "$bind" == "::" ]] && bind="127.0.0.1"
  health_url="http://${bind}:${port}/health"
  for attempt in $(seq 1 75); do
    if curl -fsS "$health_url" >/dev/null 2>&1; then
      say "Health check passed: $health_url"
      return 0
    fi
    sleep 2
  done
  compose ps || true
  compose logs --tail 160 web worker || true
  fail "Web service did not become healthy at $health_url"
}

write_installation_receipt() {
  local image_id installed_at
  image_id="$(docker image inspect "$IMAGE_NAME" --format '{{.Id}}' 2>/dev/null || true)"
  installed_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  cat > "$INSTALL_RECEIPT" <<RECEIPT
product=${PRODUCT_NAME}
version=${PRODUCT_VERSION}
build=${BUILD_NUMBER}
installed_at_utc=${installed_at}
image=${IMAGE_NAME}
image_id=${image_id}
port=${DEFAULT_PORT}
migration_policy=${POLICY_MODE}
gei_version=${GEI_VERSION}
configuration=${ENV_FILE}
RECEIPT
  chmod 600 "$INSTALL_RECEIPT"
}

show_access() {
  local port bind username password secure
  port="$(env_value FORGEBRIDGE_PORT)"; port="${port:-$DEFAULT_PORT}"
  bind="$(env_value FORGEBRIDGE_BIND_ADDRESS)"; bind="${bind:-127.0.0.1}"
  [[ "$bind" == "0.0.0.0" || "$bind" == "::" ]] && bind="127.0.0.1"
  username="$(env_value DEFAULT_ADMIN_USERNAME)"
  password="$(env_value DEFAULT_ADMIN_PASSWORD)"
  secure="$(env_value SESSION_COOKIE_SECURE)"

  printf '\nForgeBridge is available at: http://%s:%s\n' "$bind" "$port"
  if [[ "$NEW_ENV" -eq 1 ]]; then
    printf 'Initial administrator: %s\nInitial password:      %s\n' "$username" "$password"
    printf 'Credentials are stored in %s with restricted permissions. Change the password after first sign-in.\n' "$ENV_FILE"
  elif [[ "$IMPORTED_ENV" -eq 1 ]]; then
    printf 'Existing production configuration was imported from the previous installation.\n'
  fi
  printf 'Version/build: %s / %s\n' "$PRODUCT_VERSION" "$BUILD_NUMBER"
  printf 'Migration policy: GitHub-supported methods only.\n'
  if [[ "$secure" != "true" ]]; then
    printf 'TLS note: local HTTP is enabled. Before network exposure, terminate HTTPS and set SESSION_COOKIE_SECURE=true.\n'
  fi
  printf '\n'
}

install_stack() {
  preflight
  say "Installing ${PRODUCT_NAME} ${PRODUCT_VERSION} build ${BUILD_NUMBER}..."
  say "Pulling PostgreSQL and Redis images..."
  compose pull postgres redis
  say "Building the verified application image without Docker cache..."
  build_images 1 || fail "Container image build failed. Review the output above."
  verify_runtime_image
  run_database_migrations
  say "Starting the web service and background workers..."
  compose up -d --force-recreate --remove-orphans web worker
  wait_for_health
  write_installation_receipt
  compose ps
  show_access
}

build_stack() {
  preflight
  say "Building ${PRODUCT_NAME} ${PRODUCT_VERSION} build ${BUILD_NUMBER}..."
  build_images 0 || fail "Container image build failed. Review the output above."
  verify_runtime_image
  say "Application image build completed. Build 004 does not invoke pip or contact PyPI."
}

clean_build_stack() {
  preflight
  say "Removing the Build 004 application image and rebuilding without Docker cache..."
  docker image rm "$IMAGE_NAME" >/dev/null 2>&1 || true
  build_images 1 || fail "Clean container image build failed."
  verify_runtime_image
  say "Clean image build completed."
}

start_stack() {
  preflight
  if ! docker image inspect "$IMAGE_NAME" >/dev/null 2>&1; then
    warn "Build 004 image is not installed; running the full installer."
    install_stack
    return
  fi
  run_database_migrations
  say "Starting ForgeBridge..."
  compose up -d --remove-orphans web worker
  wait_for_health
  write_installation_receipt
  compose ps
  show_access
}

stop_stack() {
  preflight
  say "Stopping ForgeBridge while preserving PostgreSQL, Redis, reports, logs, branding, and configuration..."
  compose down --remove-orphans
}

restart_stack() {
  preflight
  compose restart web worker
  wait_for_health
  compose ps
}

status_stack() {
  preflight
  compose ps
}

logs_stack() {
  preflight
  local service="${1:-}"
  if [[ -n "$service" ]]; then
    case "$service" in
      web|worker|postgres|redis) compose logs --follow --tail 250 "$service" ;;
      *) fail "Unknown service: $service. Use web, worker, postgres, or redis." ;;
    esac
  else
    compose logs --follow --tail 250 web worker
  fi
}

health_stack() {
  preflight
  wait_for_health
  compose ps
}

tooling_stack() {
  preflight
  if ! docker image inspect "$IMAGE_NAME" >/dev/null 2>&1; then
    build_images 1 || fail "Container image build failed."
  fi
  verify_runtime_image
}

backup_stack() {
  preflight
  need gzip
  mkdir -p "$BACKUP_DIR"
  local stamp db_user db_name database_file data_file
  stamp="$(date -u +%Y%m%dT%H%M%SZ)"
  db_user="$(env_value POSTGRES_USER)"
  db_name="$(env_value POSTGRES_DB)"
  database_file="$BACKUP_DIR/forgebridge-${stamp}-database.sql.gz"
  data_file="$BACKUP_DIR/forgebridge-${stamp}-data.tar.gz"

  compose ps --status running postgres | grep -q postgres || fail "PostgreSQL is not running."
  say "Creating PostgreSQL backup..."
  compose exec -T postgres pg_dump --clean --if-exists --no-owner --username "$db_user" "$db_name" | gzip -9 > "$database_file"

  if compose ps --status running web | grep -q web; then
    say "Creating reports, logs, and branding backup..."
    compose exec -T web tar -C /app/data -czf - . > "$data_file"
  else
    warn "Web service is not running; the application-data volume archive was skipped."
  fi
  chmod 600 "$database_file" "$data_file" 2>/dev/null || true
  say "Backup complete: $database_file"
  [[ -f "$data_file" ]] && say "Backup complete: $data_file"
}

upgrade_stack() {
  preflight
  if compose ps --status running postgres | grep -q postgres; then
    backup_stack
  else
    warn "PostgreSQL is not running; no automatic pre-upgrade database backup was created."
  fi
  say "Rebuilding ${PRODUCT_NAME} ${PRODUCT_VERSION} build ${BUILD_NUMBER} without Docker cache..."
  build_images 1 || fail "Container image build failed. Review the output above."
  verify_runtime_image
  run_database_migrations
  compose up -d --force-recreate --remove-orphans web worker
  wait_for_health
  write_installation_receipt
  compose ps
}

uninstall_runtime() {
  preflight
  say "Removing ForgeBridge containers and the Build 004 application image. Named data volumes and .env.production will be preserved."
  compose down --remove-orphans
  docker image rm "$IMAGE_NAME" >/dev/null 2>&1 || true
  say "Runtime removed. Reinstall with: ./forgebridge.sh install"
}

doctor() {
  need docker
  need curl
  verify_release_manifest
  verify_build_identity
  verify_source_contract
  docker info >/dev/null 2>&1 || fail "Docker Desktop or the Docker daemon is not running."
  docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 is required."
  prepare_environment
  validate_environment
  compose config --quiet
  say "Release integrity: verified"
  say "Docker: $(docker --version)"
  say "Compose: $(docker compose version --short)"
  say "Configuration: $ENV_FILE"
  say "Bind: $(env_value FORGEBRIDGE_BIND_ADDRESS):$(env_value FORGEBRIDGE_PORT)"
  say "Version: $(env_value APP_VERSION)"
  say "Build: $(env_value APP_BUILD_NUMBER)"
  say "Application image: $IMAGE_NAME"
  say "Python packaging: Debian signed packages; pip/PyPI disabled in the Dockerfile"
  say "GEI packaging: official standalone v${GEI_VERSION}, SHA-256 verified"
  say "Migration policy: $(env_value MIGRATION_POLICY_MODE)"
  say "ELM enabled: $(env_value ENABLE_ELM)"
  say "Real migrations enabled: $(env_value ENABLE_REAL_MIGRATIONS)"
  say "Target purge enabled: $(env_value ENABLE_DESTRUCTIVE_PURGE)"
  say "Source read-only enabled: $(env_value ENABLE_SOURCE_FREEZE)"
  say "Compose configuration: valid"
}

init_only() {
  verify_release_manifest
  verify_build_identity
  verify_source_contract
  prepare_environment
  show_access
  say "Configuration initialized. Run ./forgebridge.sh install to install and start the stack."
}

version_info() {
  cat <<INFO
Product: ${PRODUCT_NAME}
Version: ${PRODUCT_VERSION}
Build: ${BUILD_NUMBER}
Port: ${DEFAULT_PORT}
Migration policy: GitHub-supported methods only
GitHub Enterprise Importer: standalone v${GEI_VERSION}
INFO
}

usage() {
  cat <<'USAGE'
ForgeBridge 0.1.2 production installer and manager - build FB-0.1.2-004

Fresh installation - the only script you run:
  chmod +x forgebridge.sh
  ./forgebridge.sh install

Upgrade while importing an earlier protected configuration:
  ./forgebridge.sh install --import-env ../forgebridge-0.1.2/.env.production

Replace an existing Build 004 environment deliberately:
  ./forgebridge.sh install --replace-env /absolute/path/to/.env.production

Management commands:
  ./forgebridge.sh init                         Create/import protected configuration only
  ./forgebridge.sh install [options]            Verify, clean-build, migrate, seed, and start
  ./forgebridge.sh build                        Build and verify the application image
  ./forgebridge.sh clean-build                  Force a no-cache image rebuild
  ./forgebridge.sh start                        Start; installs automatically if image is absent
  ./forgebridge.sh stop                         Stop while preserving all data volumes
  ./forgebridge.sh restart                      Restart web and worker services
  ./forgebridge.sh status                       Show container and health status
  ./forgebridge.sh health                       Verify the port 3002 health endpoint
  ./forgebridge.sh tooling                      Verify Python and official standalone GEI
  ./forgebridge.sh logs [service]               Follow logs: web, worker, postgres, or redis
  ./forgebridge.sh backup                       Back up PostgreSQL and persistent app data
  ./forgebridge.sh upgrade [options]            Back up, clean-build, migrate, seed, and restart
  ./forgebridge.sh uninstall                    Remove runtime; preserve data and configuration
  ./forgebridge.sh doctor                       Verify release, Docker, Compose, and settings
  ./forgebridge.sh version                      Show version, build, port, and method policy
  ./forgebridge.sh help                         Show this help

Build 004 does not invoke pip or contact PyPI. A customer-supplied CA certificate
is not part of normal installation. Standard HTTPS validation remains enabled.

Migration execution is limited to GitHub-supported methods:
  - GitHub Enterprise Importer for normal GHES-to-GHEC repository migrations.
  - Enterprise Live Migrations only when explicitly enabled for an eligible
    GHE.com data-residency destination; it remains a GitHub public preview.

No custom mirror-push migration, custom delta migration, or ghe-migrator path is
implemented. GEI does not support delta synchronization; production GEI requires
an approved maintenance/source-lock strategy.
USAGE
}

command_name="${1:-help}"
shift || true
case "$command_name" in
  init)
    parse_options "$@"
    init_only
    ;;
  install)
    parse_options "$@"
    install_stack
    ;;
  build)
    [[ $# -eq 0 ]] || fail "build does not accept options."
    build_stack
    ;;
  clean-build)
    [[ $# -eq 0 ]] || fail "clean-build does not accept options."
    clean_build_stack
    ;;
  start)
    [[ $# -eq 0 ]] || fail "start does not accept options."
    start_stack
    ;;
  stop)
    [[ $# -eq 0 ]] || fail "stop does not accept options."
    stop_stack
    ;;
  restart)
    [[ $# -eq 0 ]] || fail "restart does not accept options."
    restart_stack
    ;;
  status|ps)
    [[ $# -eq 0 ]] || fail "status does not accept options."
    status_stack
    ;;
  health)
    [[ $# -eq 0 ]] || fail "health does not accept options."
    health_stack
    ;;
  tooling)
    [[ $# -eq 0 ]] || fail "tooling does not accept options."
    tooling_stack
    ;;
  logs)
    logs_stack "${1:-}"
    ;;
  backup)
    [[ $# -eq 0 ]] || fail "backup does not accept options."
    backup_stack
    ;;
  upgrade)
    parse_options "$@"
    upgrade_stack
    ;;
  uninstall)
    [[ $# -eq 0 ]] || fail "uninstall does not accept options."
    uninstall_runtime
    ;;
  doctor)
    [[ $# -eq 0 ]] || fail "doctor does not accept options."
    doctor
    ;;
  version)
    [[ $# -eq 0 ]] || fail "version does not accept options."
    version_info
    ;;
  help|-h|--help)
    usage
    ;;
  *)
    usage
    fail "Unknown command: $command_name"
    ;;
esac
