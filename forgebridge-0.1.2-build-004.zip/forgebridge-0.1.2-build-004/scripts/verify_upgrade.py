#!/usr/bin/env python3
"""Seed or verify a minimal ForgeBridge 0.1.0 database during 0.1.2 upgrade checks."""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse


def database_path() -> Path:
    url = os.environ.get("DATABASE_URL", "")
    parsed = urlparse(url)
    if parsed.scheme != "sqlite":
        raise SystemExit("verify_upgrade.py requires a temporary SQLite DATABASE_URL")
    return Path(parsed.path)


def seed(path: Path) -> None:
    now = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(path) as conn:
        conn.execute(
            "INSERT INTO branding (id, product_name, tagline, version, logo_url, support_email, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (1, "Legacy ForgeBridge", "Legacy migration control plane", "0.1.0", None, "legacy@example.com", now),
        )
        conn.execute(
            "INSERT INTO users (id, username, email, password_hash, role, active, created_at, last_login_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("usr_legacy", "legacy-admin", "legacy-admin@example.com", "legacy-hash", "admin", 1, now, None),
        )
        conn.execute(
            "INSERT INTO workspaces (id, name, slug, description, owner_id, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("wsp_legacy", "Legacy wave", "legacy-wave", "Preserve this row", "usr_legacy", now, now),
        )
        conn.execute(
            "INSERT INTO connectors "
            "(id, workspace_id, name, kind, target_flavor, base_url, api_url, encrypted_token, token_last4, "
            "verify_ssl, status, status_message, metadata_json, created_at, updated_at, last_tested_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "con_legacy",
                "wsp_legacy",
                "Legacy GHES",
                "ghes",
                "not_applicable",
                "https://ghes.example.com",
                "https://ghes.example.com/api/v3",
                None,
                None,
                1,
                "connected",
                "Preserve this connector",
                json.dumps({"installed_version": "3.21.2"}),
                now,
                now,
                now,
            ),
        )
        conn.commit()


def verify(path: Path) -> None:
    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        user = conn.execute("SELECT username, email, role, active FROM users WHERE id = 'usr_legacy'").fetchone()
        workspace = conn.execute("SELECT name, description FROM workspaces WHERE id = 'wsp_legacy'").fetchone()
        connector = conn.execute("SELECT name, api_url, status FROM connectors WHERE id = 'con_legacy'").fetchone()
        assert user and dict(user) == {
            "username": "legacy-admin",
            "email": "legacy-admin@example.com",
            "role": "admin",
            "active": 1,
        }
        assert workspace and workspace["name"] == "Legacy wave" and workspace["description"] == "Preserve this row"
        assert connector and connector["api_url"] == "https://ghes.example.com/api/v3"

        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'").fetchall()
        }
        for required in ("menu_settings", "ai_configuration", "saved_repository_scopes", "source_freeze_runs"):
            assert required in tables, f"missing enhanced table: {required}"

        workspace_columns = {
            row[1] for row in conn.execute("PRAGMA table_info(workspaces)").fetchall()
        }
        assert {"migration_profile_json", "default_source_connector_id", "default_target_connector_id"} <= workspace_columns
        repository_columns = {
            row[1] for row in conn.execute("PRAGMA table_info(repository_inventory)").fetchall()
        }
        assert {"readiness_grade", "target_state_json", "pipeline_lane"} <= repository_columns
        branding_columns = {
            row[1] for row in conn.execute("PRAGMA table_info(branding)").fetchall()
        }
        assert {"build_number", "company_name", "edition_label", "theme_json"} <= branding_columns
        brand = conn.execute(
            "SELECT product_name, version, build_number, company_name, edition_label, theme_json "
            "FROM branding WHERE id = 1"
        ).fetchone()
        assert brand and brand["product_name"] == "Legacy ForgeBridge"
        assert brand["build_number"] == "FB-0.1.2-004"
        assert brand["company_name"] == "Inception UAE"
        assert brand["edition_label"] == "Enterprise"
        assert json.loads(brand["theme_json"])["accent"] == "#3B82F6"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("seed", "verify"))
    args = parser.parse_args()
    path = database_path()
    if args.mode == "seed":
        seed(path)
    else:
        verify(path)
    print(f"Legacy schema {args.mode} check passed: {path}")


if __name__ == "__main__":
    main()
