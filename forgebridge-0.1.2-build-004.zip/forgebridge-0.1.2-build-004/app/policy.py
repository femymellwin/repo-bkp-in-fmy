from __future__ import annotations

from typing import Final

POLICY_REFERENCE_DATE: Final[str] = "2026-07-14"
# ForgeBridge's conservative local worker ceiling for GEI. GitHub's current
# public GEI documentation does not state that five is a service-side maximum;
# operators should tune this only after pilot evidence and GitHub Support review.
GEI_MAX_CONCURRENT_REPOSITORIES: Final[int] = 5
ELM_MAX_CONCURRENT_REPOSITORIES_PER_GHES: Final[int] = 10
# GitHub public documentation checked on POLICY_REFERENCE_DATE.
ELM_MINIMUM_PATCH_RELEASES: Final[dict[int, int]] = {
    17: 17,
    18: 11,
    19: 8,
    20: 4,
    21: 2,
}
ELM_RELEASE_ASSET_LIMIT_BYTES: Final[int] = 2 * 1024**3
GEI_RELEASE_DATA_LIMIT_BYTES: Final[int] = 10 * 1024**3

METHOD_POLICY: Final[dict[str, object]] = {
    "reference_date": POLICY_REFERENCE_DATE,
    "gei": {
        "name": "GitHub Enterprise Importer",
        "default_for": "GHES to GitHub Enterprise Cloud repository migrations",
        "delta_supported": False,
        "forgebridge_default_parallelism_ceiling": GEI_MAX_CONCURRENT_REPOSITORIES,
        "github_documented_service_maximum": None,
        "source_behavior": "Trial runs remain unlocked. Production runs in ForgeBridge require the official --lock-source-repo option because GEI has no delta synchronization.",
        "lfs_objects_migrated": False,
        "compressed_archive_limits_by_ghes_version": {
            "before_3.8": "2 GiB Git source and 2 GiB metadata",
            "3.8_to_3.11": "10 GiB Git source and 10 GiB metadata",
            "3.12": "20 GiB Git source and 20 GiB metadata",
            "3.13_and_later": "40 GiB Git source and 40 GiB metadata (public preview)",
        },
        "release_data_limit": "Repositories with more than 10 GB of releases data require --skip-releases; discovered asset totals are an approximation and are not equivalent to the compressed metadata archive size.",
        "organization_objects_migrated": False,
    },
    "elm": {
        "name": "Enterprise Live Migrations",
        "availability": "GitHub public preview",
        "eligible_destination": "GitHub Enterprise Cloud with data residency on GHE.com",
        "delta_supported_during_live_window": True,
        "maximum_concurrent_repositories_per_source": ELM_MAX_CONCURRENT_REPOSITORIES_PER_GHES,
        "minimum_patch_releases": [
            f"3.{minor}.{patch}" for minor, patch in ELM_MINIMUM_PATCH_RELEASES.items()
        ],
        "source_behavior": "The official cutover archives the source repository and completes final synchronization.",
        "public_repositories_supported": False,
        "maximum_release_asset_bytes": ELM_RELEASE_ASSET_LIMIT_BYTES,
    },
    "source_safety": {
        "discovery_is_read_only": True,
        "purge_calls_source": False,
        "source_deletion_implemented": False,
        "source_mutation_requires_explicit_cutover_or_lock": True,
    },
    "known_non_migrated_or_separate_workstreams": [
        "Organization creation and organization-wide settings",
        "Teams and repository access assignments",
        "GitHub Actions secrets and variables",
        "GitHub Actions environments, runners, artifacts, and run history",
        "GitHub Apps, app installations, webhooks, and deploy keys",
        "GitHub Packages",
        "Projects and rulesets",
        "Audit logs and existing code-scanning or Dependabot results",
        "Git LFS objects when using GEI",
        "Identity reclamation for mannequins",
    ],
    "pipeline_policy": {
        "workflow_files_are_not_removed_or_rewritten_by_migration": True,
        "secret_values_retrievable_from_github": False,
        "onepassword_output": "Inventory, owner handoff, and proposed op:// references only; workflow changes require an approved post-migration pull request.",
    },
}
