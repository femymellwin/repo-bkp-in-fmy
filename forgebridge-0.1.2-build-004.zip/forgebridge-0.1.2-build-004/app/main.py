from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from cryptography.fernet import Fernet
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from app.config import get_settings
from app.database import Base, SessionLocal, engine
from app.routers.web import router
from app.seed import seed_database

settings = get_settings()
logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger("forgebridge")

PACKAGE_DIR = Path(__file__).resolve().parent


def validate_runtime_configuration() -> None:
    if settings.is_production:
        failures: list[str] = []
        unsafe_secret_keys = {
            "change-this-development-secret",
            "replace-with-at-least-32-random-characters",
            "forgebridge-demo-secret-key-change-before-use",
        }
        if settings.secret_key in unsafe_secret_keys or len(settings.secret_key) < 32:
            failures.append("SECRET_KEY must be a unique random value of at least 32 characters")
        unsafe_encryption_keys = {
            None,
            "replace-with-a-fernet-key",
            "Kp4TAd9EVXngsUcp1fRbVr8OzK76HTAvrfW0gHUcDpA=",
        }
        if settings.token_encryption_key in unsafe_encryption_keys:
            failures.append("TOKEN_ENCRYPTION_KEY must be a unique generated Fernet key")
        elif settings.token_encryption_key:
            try:
                Fernet(settings.token_encryption_key.encode("utf-8"))
            except Exception:
                failures.append("TOKEN_ENCRYPTION_KEY is not a valid Fernet key")
        if settings.default_admin_password == "ChangeMe123!" and not settings.allow_default_admin_in_production:
            failures.append("DEFAULT_ADMIN_PASSWORD must be changed")
        if settings.demo_mode:
            failures.append("DEMO_MODE must be false")
        if settings.database_url.startswith("sqlite"):
            failures.append("Use PostgreSQL rather than SQLite")
        if settings.auto_create_tables:
            failures.append("AUTO_CREATE_TABLES must be false; apply Alembic migrations before startup")
        if settings.task_mode.lower() != "celery":
            failures.append("TASK_MODE must be celery for durable background execution")
        if failures:
            raise RuntimeError("Unsafe production configuration: " + "; ".join(failures))


validate_runtime_configuration()

@asynccontextmanager
async def lifespan(_: FastAPI):
    if settings.auto_create_tables:
        Base.metadata.create_all(bind=engine)
    if settings.seed_on_startup:
        db = SessionLocal()
        try:
            seed_database(db)
        finally:
            db.close()
    logger.info("ForgeBridge %s started in %s mode", settings.app_version, settings.environment)
    yield


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    docs_url="/api/docs",
    redoc_url=None,
    lifespan=lifespan,
)
app.add_middleware(
    SessionMiddleware,
    secret_key=settings.secret_key,
    session_cookie=settings.session_cookie_name,
    same_site="lax",
    https_only=(settings.is_production if settings.session_cookie_secure is None else settings.session_cookie_secure),
    max_age=8 * 60 * 60,
)
app.mount("/static", StaticFiles(directory=str(PACKAGE_DIR / "static")), name="static")
app.include_router(router)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; img-src 'self' data: https:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'",
    )
    if settings.is_production:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    accept = request.headers.get("accept", "")
    if exc.status_code == 401 and "text/html" in accept:
        return RedirectResponse("/login", status_code=303)
    if "text/html" in accept:
        from app.routers.web import html

        db = SessionLocal()
        try:
            user = None
            user_id = request.session.get("user_id")
            if user_id:
                from app.models import User

                user = db.get(User, user_id)
            return html(
                request,
                db,
                "error.html",
                user,
                status_code=exc.status_code,
                error_status=exc.status_code,
                error_detail=exc.detail,
            )
        finally:
            db.close()
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
