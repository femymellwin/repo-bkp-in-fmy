from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from app.config import get_settings
from app.tasks import execute_job

_executor = ThreadPoolExecutor(max_workers=8, thread_name_prefix="forgebridge-job")


def enqueue_job(job_id: str) -> None:
    settings = get_settings()
    if settings.task_mode.lower() == "celery":
        from app.celery_app import celery

        celery.send_task("forgebridge.execute_job", args=[job_id])
    else:
        _executor.submit(execute_job, job_id)
