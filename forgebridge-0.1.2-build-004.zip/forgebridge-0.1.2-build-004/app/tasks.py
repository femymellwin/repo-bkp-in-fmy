from __future__ import annotations

import traceback

from sqlalchemy import update

from app.database import SessionLocal
from app.models import (
    AIConfiguration,
    Connector,
    DiscoveryRun,
    Job,
    JobStatus,
    MigrationRun,
    MigrationStatus,
    PurgeRun,
    SourceFreezeRun,
    ValidationRun,
    utcnow,
)
from app.services.ai import run_ai_interpret_job, run_ai_test_job
from app.services.connectors import run_connector_test
from app.services.discovery import run_discovery
from app.services.job_utils import append_job_log, update_job
from app.services.migration import run_cutover_job, run_migration_job
from app.services.purge import run_purge_job
from app.services.source_freeze import run_source_freeze_job
from app.services.validation import run_validation_job


HANDLERS = {
    "connector_test": run_connector_test,
    "discovery": run_discovery,
    "migration": run_migration_job,
    "cutover": run_cutover_job,
    "validation": run_validation_job,
    "purge": run_purge_job,
    "source_freeze": run_source_freeze_job,
    "ai_test": run_ai_test_job,
    "ai_interpret": run_ai_interpret_job,
}


def _mark_domain_failure(db, job: Job, error: str) -> None:
    """Keep the operational record consistent when a handler exits early.

    Handlers normally persist their own terminal state. This guard covers
    failures during preflight, configuration loading, or other code paths that
    raise before the handler reaches its normal finalization block.
    """

    payload = job.payload_json or {}
    now = utcnow()
    if job.kind == "discovery" and payload.get("discovery_run_id"):
        record = db.get(DiscoveryRun, payload["discovery_run_id"])
        if record:
            record.status = JobStatus.failed
            record.finished_at = now
            record.summary_json = {**(record.summary_json or {}), "error": error}
            db.add(record)

    elif job.kind in {"migration", "cutover"} and payload.get("migration_run_id"):
        record = db.get(MigrationRun, payload["migration_run_id"])
        if record and record.status not in {MigrationStatus.completed, MigrationStatus.purged}:
            record.status = MigrationStatus.failed
            record.finished_at = now
            record.preflight_json = {
                **(record.preflight_json or {}),
                "job_failure": error,
                "external_state_reconciliation_required": job.kind == "cutover",
            }
            db.add(record)

    elif job.kind == "validation" and payload.get("validation_run_id"):
        record = db.get(ValidationRun, payload["validation_run_id"])
        if record:
            record.status = JobStatus.failed
            record.finished_at = now
            record.report_json = {**(record.report_json or {}), "error": error}
            db.add(record)

    elif job.kind == "purge" and payload.get("purge_run_id"):
        record = db.get(PurgeRun, payload["purge_run_id"])
        if record:
            record.status = JobStatus.failed
            record.finished_at = now
            record.result_json = {**(record.result_json or {}), "error": error, "source_touched": False}
            db.add(record)

    elif job.kind == "source_freeze" and payload.get("freeze_run_id"):
        record = db.get(SourceFreezeRun, payload["freeze_run_id"])
        if record:
            record.status = JobStatus.failed
            record.finished_at = now
            record.result_json = {**(record.result_json or {}), "error": error}
            db.add(record)

    elif job.kind == "connector_test" and payload.get("connector_id"):
        record = db.get(Connector, payload["connector_id"])
        if record:
            record.status = "failed"
            record.status_message = error
            record.last_tested_at = now
            db.add(record)

    elif job.kind == "ai_test":
        record = db.get(AIConfiguration, 1)
        if record:
            record.status = "failed"
            record.status_message = error
            record.last_tested_at = now
            db.add(record)

    db.commit()


def execute_job(job_id: str) -> dict:
    db = SessionLocal()
    try:
        # Compare-and-set prevents redelivery or repeated enqueue attempts from
        # executing the same persisted job more than once.
        claim = db.execute(
            update(Job)
            .where(Job.id == job_id, Job.status == JobStatus.queued)
            .values(status=JobStatus.running, started_at=utcnow(), current_step="Worker claimed job")
        )
        db.commit()
        job = db.get(Job, job_id)
        if not job:
            raise RuntimeError(f"Job not found: {job_id}")
        if claim.rowcount != 1:
            return {
                "job_id": job_id,
                "status": job.status.value,
                "ignored": True,
                "reason": "Job was already claimed or completed",
            }
        handler = HANDLERS.get(job.kind)
        if not handler:
            raise RuntimeError(f"Unsupported job kind: {job.kind}")
        return handler(db, job)
    except Exception as exc:
        db.rollback()
        job = db.get(Job, job_id)
        if job:
            _mark_domain_failure(db, job, str(exc))
            append_job_log(job, "Job failed", {"error": str(exc), "traceback": traceback.format_exc()})
            update_job(db, job, status=JobStatus.failed, progress=100, step="Job failed", error=str(exc))
        return {"job_id": job_id, "status": "failed", "error": str(exc)}
    finally:
        db.close()
