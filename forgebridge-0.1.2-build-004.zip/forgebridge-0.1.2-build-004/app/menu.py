from __future__ import annotations

from sqlalchemy.orm import Session

from app.models import MenuSetting


MENU_GROUPS: list[dict] = [
    {
        "label": "GitHub",
        "items": [
            ("github.discovery", "Repository discovery", False),
            ("github.with_pipelines", "Repository with pipelines", False),
            ("github.pipeline_handoff", "Pipeline owner handoff", False),
            ("github.without_pipelines", "Repository without pipelines", False),
            ("github.migrations", "Migration runs", False),
            ("github.validation", "Repository validation", False),
            ("github.target_purge", "Target purge", False),
            ("github.source_read_only", "Source read-only", False),
        ],
    },
    {
        "label": "Operations",
        "items": [
            ("operations.jobs", "Jobs", False),
            ("operations.reports", "Reports", False),
        ],
    },
    {
        "label": "Configure",
        "items": [
            ("configure.connectors", "Connectors", False),
            ("configure.workspaces", "Workspaces", False),
            ("configure.branding", "Branding", True),
            ("configure.users", "Users", True),
            ("configure.menu", "Menu enablement", True),
            ("configure.audit", "Audit log activity", True),
            ("configure.ai", "AI configuration", True),
        ],
    },
    {
        "label": "Help",
        "items": [
            ("help.index", "Help index", False),
            ("help.github_guide", "GitHub Enterprise migration guide", False),
        ],
    },
]


def menu_definitions() -> list[dict]:
    rows: list[dict] = []
    order = 0
    for group in MENU_GROUPS:
        for key, label, admin_only in group["items"]:
            order += 10
            rows.append(
                {
                    "key": key,
                    "group_name": group["label"],
                    "label": label,
                    "admin_only": admin_only,
                    "sort_order": order,
                }
            )
    return rows


def ensure_menu_settings(db: Session) -> list[MenuSetting]:
    existing = {row.key: row for row in db.query(MenuSetting).all()}
    changed = False
    for definition in menu_definitions():
        row = existing.get(definition["key"])
        if row is None:
            row = MenuSetting(enabled=True, **definition)
            db.add(row)
            existing[row.key] = row
            changed = True
        else:
            for key in ("group_name", "label", "admin_only", "sort_order"):
                value = definition[key]
                if getattr(row, key) != value:
                    setattr(row, key, value)
                    changed = True
    if changed:
        db.commit()
    return sorted(existing.values(), key=lambda item: (item.sort_order, item.key))


def menu_settings(db: Session) -> dict[str, bool]:
    return {row.key: row.enabled for row in ensure_menu_settings(db)}


def enabled(db: Session, key: str) -> bool:
    return bool(menu_settings(db).get(key, True))


def normalize_menu(values: list[str] | set[str] | tuple[str, ...]) -> dict[str, bool]:
    selected = set(values)
    return {item["key"]: item["key"] in selected for item in menu_definitions()}
