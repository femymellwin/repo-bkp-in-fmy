from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.menu import ensure_menu_settings
from app.models import (
    AIConfiguration,
    Branding,
    Connector,
    ConnectorKind,
    TargetFlavor,
    User,
    UserRole,
    Workspace,
)
from app.security import hash_password


def seed_database(db: Session) -> None:
    settings = get_settings()
    branding = db.get(Branding, 1)
    if not branding:
        branding = Branding(
            id=1,
            product_name=settings.app_name,
            tagline=settings.app_tagline,
            version=settings.app_version,
            build_number=settings.app_build_number,
            company_name=settings.company_name,
            edition_label=settings.edition_label,
        )
        db.add(branding)
    elif branding.version in {"0.1.0", "0.1.1"}:
        branding.version = settings.app_version
        if not branding.build_number or branding.build_number in {"FB-0.1.2-001", "FB-0.1.2-002", "FB-0.1.2-003"}:
            branding.build_number = settings.app_build_number
        if not branding.company_name:
            branding.company_name = settings.company_name
        if not branding.edition_label:
            branding.edition_label = settings.edition_label
        db.add(branding)
    elif branding.version == "0.1.2" and branding.build_number in {"FB-0.1.2-001", "FB-0.1.2-002", "FB-0.1.2-003"}:
        # Build 004 keeps the PyPI-free signed Debian runtime and adds a single
        # verified installer/manager script. Preserve administrator-defined
        # custom build identities.
        branding.build_number = settings.app_build_number
        db.add(branding)

    ensure_menu_settings(db)
    if not db.get(AIConfiguration, 1):
        db.add(AIConfiguration(id=1))

    admin = db.scalar(select(User).where(User.username == settings.default_admin_username))
    if not admin:
        admin = User(
            username=settings.default_admin_username,
            email=settings.default_admin_email,
            password_hash=hash_password(settings.default_admin_password),
            role=UserRole.admin,
            active=True,
        )
        db.add(admin)
        db.flush()

    if settings.demo_mode:
        workspace = db.scalar(select(Workspace).where(Workspace.slug == "demo-migration"))
        if not workspace:
            workspace = Workspace(
                name="Demo Migration",
                slug="demo-migration",
                description="Safe simulated GHES to GHEC migration workspace.",
                owner_id=admin.id,
                source_org="legacy-engineering",
                target_org="cloud-engineering",
            )
            db.add(workspace)
            db.flush()
        source = db.scalar(
            select(Connector).where(
                Connector.workspace_id == workspace.id,
                Connector.kind == ConnectorKind.simulated_ghes,
            )
        )
        target = db.scalar(
            select(Connector).where(
                Connector.workspace_id == workspace.id,
                Connector.kind == ConnectorKind.simulated_ghec,
            )
        )
        if not source:
            source = Connector(
                workspace_id=workspace.id,
                name="Demo GHES",
                kind=ConnectorKind.simulated_ghes,
                target_flavor=TargetFlavor.not_applicable,
                base_url="https://ghes.demo.invalid",
                api_url="https://ghes.demo.invalid/api/v3",
                status="connected",
                status_message="Simulation connector",
                metadata_json={
                    "identity": "demo-migrator",
                    "installed_version": "3.21.2",
                    "simulation": True,
                    "scopes": ["repo", "admin:org"],
                },
            )
            db.add(source)
            db.flush()
        if not target:
            target = Connector(
                workspace_id=workspace.id,
                name="Demo GHEC",
                kind=ConnectorKind.simulated_ghec,
                target_flavor=TargetFlavor.ghe_com,
                base_url="https://demo.ghe.com",
                api_url="https://api.demo.ghe.com",
                status="connected",
                status_message="Simulation connector",
                metadata_json={
                    "identity": "demo-migrator",
                    "simulation": True,
                    "scopes": ["repo", "admin:org", "workflow"],
                },
            )
            db.add(target)
            db.flush()
        workspace.default_source_connector_id = source.id
        workspace.default_target_connector_id = target.id
        workspace.source_org = workspace.source_org or "legacy-engineering"
        workspace.target_org = workspace.target_org or "cloud-engineering"
        workspace.migration_profile_json = {
            **(workspace.migration_profile_json or {}),
            "source_connector_id": source.id,
            "target_connector_id": target.id,
            "source_org": workspace.source_org,
            "target_org": workspace.target_org,
            "default_method": "gei",
            "default_concurrency": 3,
        }
        db.add(workspace)
    db.commit()
