(() => {
  "use strict";
  const storageKey = "forgebridge.theme";
  let initial = "light";
  try {
    const saved = window.localStorage.getItem(storageKey);
    if (saved === "light" || saved === "dark") initial = saved;
    else if (window.matchMedia?.("(prefers-color-scheme: dark)").matches) initial = "dark";
  } catch (_) {
    // Local storage can be unavailable in hardened browser modes.
  }
  document.documentElement.dataset.theme = initial;
})();
