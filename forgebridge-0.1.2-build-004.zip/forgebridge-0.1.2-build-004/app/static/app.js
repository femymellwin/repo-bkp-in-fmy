(() => {
  "use strict";

  const terminalStatuses = new Set(["succeeded", "completed", "failed", "cancelled", "blocked", "purged"]);

  const escapeHtml = (value) => String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  const statusClass = (value) => {
    const status = String(value || "").toLowerCase();
    if (["succeeded", "completed", "connected", "success", "passed", "ready", "active"].includes(status)) return "success";
    if (["failed", "error", "blocked", "purged", "rejected"].includes(status)) return "danger";
    if (["warning", "queued", "pending", "running", "validating", "migrating", "cutover", "ready_for_cutover"].includes(status)) return "warning";
    return "neutral";
  };

  const closeDropdowns = (except = null) => {
    document.querySelectorAll("[data-dropdown-toggle][aria-expanded=\"true\"]").forEach((button) => {
      if (button === except) return;
      button.setAttribute("aria-expanded", "false");
      button.closest(".dropdown")?.classList.remove("open");
    });
  };

  document.querySelectorAll("[data-dropdown-toggle]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = button.getAttribute("aria-expanded") === "true";
      closeDropdowns(button);
      button.setAttribute("aria-expanded", open ? "false" : "true");
      button.closest(".dropdown")?.classList.toggle("open", !open);
    });
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".dropdown")) closeDropdowns();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeDropdowns();
  });

  const navToggle = document.querySelector("[data-nav-toggle]");
  const navCollapse = document.querySelector("[data-nav-collapse]");
  navToggle?.addEventListener("click", () => {
    const open = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", open ? "false" : "true");
    navCollapse?.classList.toggle("show", !open);
    if (open) closeDropdowns();
  });

  document.querySelector("[data-workspace-switcher] select")?.addEventListener("change", (event) => {
    event.currentTarget.form?.requestSubmit();
  });

  const themeButton = document.getElementById("themeToggle");
  const syncThemeButton = () => {
    const dark = document.documentElement.dataset.theme === "dark";
    themeButton?.classList.toggle("is-dark", dark);
    themeButton?.setAttribute("aria-label", dark ? "Switch to light theme" : "Switch to dark theme");
  };
  syncThemeButton();
  themeButton?.addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { window.localStorage.setItem("forgebridge.theme", next); } catch (_) { /* no-op */ }
    syncThemeButton();
  });

  const brandingForm = document.querySelector("[data-branding-form]");
  if (brandingForm) {
    const previewImage = document.querySelector("[data-brand-preview-logo]");
    const currentImage = document.querySelector("[data-current-logo]");
    const fileInput = brandingForm.querySelector('input[name="logo_file"]');
    fileInput?.addEventListener("change", () => {
      const file = fileInput.files?.[0];
      if (!file) return;
      if (file.size > 2 * 1024 * 1024) {
        window.alert("Logo exceeds the 2 MB limit.");
        fileInput.value = "";
        return;
      }
      const url = URL.createObjectURL(file);
      if (previewImage) previewImage.src = url;
      if (currentImage) currentImage.src = url;
    });

    const bindPreview = (name, target, fallback = "") => {
      const input = brandingForm.querySelector(`[name="${name}"]`);
      const node = document.querySelector(target);
      input?.addEventListener("input", () => { if (node) node.textContent = input.value || fallback; });
    };
    bindPreview("product_name", "[data-brand-preview-name]", "ForgeBridge");
    bindPreview("tagline", "[data-brand-preview-tagline]");
    bindPreview("version", "[data-brand-preview-version]");
    bindPreview("build_number", "[data-brand-preview-build]");
    bindPreview("edition_label", "[data-brand-preview-edition]");

    brandingForm.querySelectorAll('input[type="color"]').forEach((input) => {
      input.addEventListener("input", () => {
        const key = input.dataset.themeVariable;
        if (key) document.documentElement.style.setProperty(key, input.value);
        if (key === "--ado2-accent") document.documentElement.style.setProperty("--primary", input.value);
        const code = input.closest(".color-control")?.querySelector("code");
        if (code) code.textContent = input.value.toUpperCase();
      });
    });
  }

  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      const text = form.dataset.confirm || "Continue with this action?";
      if (!window.confirm(text)) event.preventDefault();
    });
  });

  const updateSelectionCount = (root) => {
    const count = [...root.querySelectorAll('input[name="repository_ids"]')].filter((item) => item.checked).length;
    root.querySelectorAll("[data-selected-count]").forEach((node) => { node.textContent = `${count} selected`; });
  };

  document.querySelectorAll("[data-filter-root]").forEach((root) => {
    const rows = [...root.querySelectorAll("[data-filter-row]")];
    const search = root.querySelector("[data-filter-search]");
    const filters = [...root.querySelectorAll("[data-filter]")];

    const applyFilters = () => {
      const query = String(search?.value || "").trim().toLowerCase();
      let visible = 0;
      rows.forEach((row) => {
        const text = String(row.dataset.search || row.textContent || "").toLowerCase();
        let match = !query || text.includes(query);
        filters.forEach((control) => {
          const wanted = String(control.value || "").trim().toLowerCase();
          if (!wanted || !match) return;
          const key = control.dataset.filter;
          const actual = String(row.dataset[key] || "").trim().toLowerCase();
          match = key === "dependency" ? actual.includes(wanted) : actual === wanted;
        });
        row.hidden = !match;
        if (match) visible += 1;
      });
      root.querySelectorAll("[data-visible-count]").forEach((node) => { node.textContent = `${visible} shown`; });
      updateSelectionCount(root);
    };

    search?.addEventListener("input", applyFilters);
    filters.forEach((control) => control.addEventListener("change", applyFilters));
    root.querySelectorAll("[data-clear-filters]").forEach((button) => button.addEventListener("click", () => {
      if (search) search.value = "";
      filters.forEach((control) => { control.value = ""; });
      applyFilters();
    }));

    const selectableCheckboxes = (predicate = () => true) => rows
      .filter((row) => !row.hidden && row.dataset.selectable !== "false" && predicate(row))
      .map((row) => row.querySelector('input[name="repository_ids"]'))
      .filter((item) => item && !item.disabled);

    root.querySelectorAll("[data-select-visible]").forEach((button) => button.addEventListener("click", () => {
      selectableCheckboxes().forEach((item) => { item.checked = true; });
      updateSelectionCount(root);
    }));
    root.querySelectorAll("[data-select-ready]").forEach((button) => button.addEventListener("click", () => {
      selectableCheckboxes((row) => row.dataset.status === "ready").forEach((item) => { item.checked = true; });
      updateSelectionCount(root);
    }));
    root.querySelectorAll("[data-select-batch]").forEach((button) => button.addEventListener("click", () => {
      const limit = Math.max(1, Number(button.dataset.selectBatch || 1));
      selectableCheckboxes().filter((item) => !item.checked).slice(0, limit).forEach((item) => { item.checked = true; });
      updateSelectionCount(root);
    }));
    root.querySelectorAll("[data-clear-selection]").forEach((button) => button.addEventListener("click", () => {
      root.querySelectorAll('input[name="repository_ids"]').forEach((item) => { item.checked = false; });
      updateSelectionCount(root);
    }));
    root.querySelectorAll('input[name="repository_ids"]').forEach((item) => item.addEventListener("change", () => updateSelectionCount(root)));
    applyFilters();
  });

  const migrationForm = document.querySelector("[data-migration-form]");
  if (migrationForm && !migrationForm.closest("[data-filter-root]")) {
    const sourceOrg = migrationForm.querySelector("[data-source-org-input]");
    const rows = [...migrationForm.querySelectorAll(".repo-selector-row")];
    const pipelineFilter = migrationForm.querySelector("[data-pipeline-filter]");
    const filterRows = () => {
      const value = (sourceOrg?.value || "").trim().toLowerCase();
      const pipelineValue = pipelineFilter?.value || "all";
      rows.forEach((row) => {
        const wrongOrg = Boolean(value) && String(row.dataset.sourceOrg || "").toLowerCase() !== value;
        const hasActions = row.dataset.hasActions === "true";
        const wrongPipelineGroup = (pipelineValue === "with" && !hasActions) || (pipelineValue === "without" && hasActions);
        row.hidden = wrongOrg || wrongPipelineGroup;
        if (row.hidden) {
          const checkbox = row.querySelector('input[type="checkbox"]');
          if (checkbox) checkbox.checked = false;
        }
      });
    };
    sourceOrg?.addEventListener("input", filterRows);
    sourceOrg?.addEventListener("change", filterRows);
    pipelineFilter?.addEventListener("change", filterRows);
    migrationForm.querySelector("[data-select-all]")?.addEventListener("click", () => {
      rows.filter((row) => !row.hidden).forEach((row) => {
        const checkbox = row.querySelector('input[type="checkbox"]');
        if (checkbox && !checkbox.disabled) checkbox.checked = true;
      });
    });
    filterRows();
  }

  const pollable = [...document.querySelectorAll("[data-job-id]")];
  if (!pollable.length) return;

  const updateJob = (jobId, payload) => {
    document.querySelectorAll(`[data-job-id="${CSS.escape(jobId)}"]`).forEach((container) => {
      const progress = container.querySelector("progress");
      const text = container.querySelector("[data-progress-text]");
      const value = Math.max(0, Math.min(100, Number(payload.progress || 0)));
      if (progress) progress.value = value;
      if (text) text.textContent = `${value}%`;

      const row = container.closest("[data-job-row]");
      if (row) {
        const statusCell = row.querySelector("[data-job-status]");
        const stepCell = row.querySelector("[data-job-step]");
        if (statusCell) {
          const status = String(payload.status || "unknown");
          statusCell.innerHTML = `<span class="badge badge-${statusClass(status)}">${escapeHtml(status.replaceAll("_", " "))}</span>`;
        }
        if (stepCell) {
          const message = payload.error_message || payload.error;
          const error = message ? `<small class="error-text">${escapeHtml(message)}</small>` : "";
          stepCell.innerHTML = `${escapeHtml(payload.current_step || "-")}${error}`;
        }
      }
    });
  };

  const activeIds = new Set(pollable.map((node) => node.dataset.jobId).filter(Boolean));
  const poll = async () => {
    await Promise.all([...activeIds].map(async (jobId) => {
      try {
        const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`, { headers: { "Accept": "application/json" }, credentials: "same-origin" });
        if (!response.ok) return;
        const payload = await response.json();
        updateJob(jobId, payload);
        if (terminalStatuses.has(String(payload.status || "").toLowerCase())) activeIds.delete(jobId);
      } catch (_) {
        // Persisted job state remains authoritative when polling is unavailable.
      }
    }));
    if (activeIds.size) window.setTimeout(poll, 2200);
  };
  poll();
})();
