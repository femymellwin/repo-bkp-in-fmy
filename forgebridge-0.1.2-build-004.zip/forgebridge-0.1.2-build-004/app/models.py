from __future__ import annotations

import enum
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class UserRole(str, enum.Enum):
    admin = "admin"
    user = "user"


class ConnectorKind(str, enum.Enum):
    ghes = "ghes"
    ghec = "ghec"
    onepassword = "onepassword"
    simulated_ghes = "simulated_ghes"
    simulated_ghec = "simulated_ghec"


class TargetFlavor(str, enum.Enum):
    github_com = "github.com"
    ghe_com = "ghe.com"
    not_applicable = "n/a"


class JobStatus(str, enum.Enum):
    queued = "queued"
    running = "running"
    succeeded = "succeeded"
    failed = "failed"
    cancelled = "cancelled"


class MigrationMethod(str, enum.Enum):
    gei = "gei"
    elm = "elm"
    simulation = "simulation"


class MigrationMode(str, enum.Enum):
    trial = "trial"
    production = "production"


class MigrationLane(str, enum.Enum):
    all = "all"
    with_pipelines = "with_pipelines"
    without_pipelines = "without_pipelines"


class PipelinePolicy(str, enum.Enum):
    preserve_disable_actions = "preserve_disable_actions"
    preserve_current_settings = "preserve_current_settings"
    inventory_only = "inventory_only"


class MigrationStatus(str, enum.Enum):
    planned = "planned"
    queued = "queued"
    running = "running"
    ready_for_cutover = "ready_for_cutover"
    completed = "completed"
    completed_with_warnings = "completed_with_warnings"
    failed = "failed"
    cancelled = "cancelled"
    purged = "purged"


class RepoMigrationStatus(str, enum.Enum):
    pending = "pending"
    running = "running"
    ready_for_cutover = "ready_for_cutover"
    completed = "completed"
    warning = "warning"
    failed = "failed"
    cancelled = "cancelled"
    purged = "purged"


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("usr"))
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(512))
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, native_enum=False, validate_strings=True), default=UserRole.user
    )
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    workspaces: Mapped[list["Workspace"]] = relationship(back_populates="owner")


class Branding(Base):
    __tablename__ = "branding"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    product_name: Mapped[str] = mapped_column(String(120), default="ForgeBridge")
    tagline: Mapped[str] = mapped_column(
        String(255), default="Controlled, auditable GitHub enterprise migrations."
    )
    version: Mapped[str] = mapped_column(String(40), default="0.1.2")
    build_number: Mapped[str] = mapped_column(String(80), default="FB-0.1.2-004")
    company_name: Mapped[str] = mapped_column(String(120), default="Inception UAE")
    edition_label: Mapped[str | None] = mapped_column(String(80), default="Enterprise", nullable=True)
    logo_url: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    support_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    theme_json: Mapped[dict[str, Any]] = mapped_column(
        JSON,
        default=lambda: {
            "primary": "#243144",
            "accent": "#3B82F6",
            "gradient_from": "#F8FAFC",
            "gradient_to": "#EEF4FF",
            "border": "#D7DEE8",
            "button_bg": "#FFFFFF",
            "button_border": "#CBD5E1",
            "button_text": "#243144",
        },
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )


class MenuSetting(Base):
    __tablename__ = "menu_settings"

    key: Mapped[str] = mapped_column(String(120), primary_key=True)
    group_name: Mapped[str] = mapped_column(String(80), index=True)
    label: Mapped[str] = mapped_column(String(160))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    admin_only: Mapped[bool] = mapped_column(Boolean, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )


class AIConfiguration(Base):
    __tablename__ = "ai_configuration"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    provider: Mapped[str] = mapped_column(String(80), default="azure_openai")
    endpoint: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    deployment: Mapped[str | None] = mapped_column(String(255), nullable=True)
    model: Mapped[str | None] = mapped_column(String(255), nullable=True)
    api_style: Mapped[str] = mapped_column(String(40), default="v1")
    api_version: Mapped[str] = mapped_column(String(80), default="2024-10-21")
    auth_mode: Mapped[str] = mapped_column(String(40), default="managed_identity")
    encrypted_api_key: Mapped[str | None] = mapped_column(Text, nullable=True)
    api_key_last4: Mapped[str | None] = mapped_column(String(8), nullable=True)
    temperature: Mapped[float] = mapped_column(Float, default=0.1)
    max_output_tokens: Mapped[int] = mapped_column(Integer, default=1200)
    max_input_chars: Mapped[int] = mapped_column(Integer, default=60000)
    system_prompt: Mapped[str] = mapped_column(
        Text,
        default=(
            "You are a read-only GitHub migration analysis assistant. Use only supplied evidence, "
            "never invent repository state, and never request or execute mutating GitHub operations."
        ),
    )
    allowed_use_cases_json: Mapped[list[str]] = mapped_column(
        JSON,
        default=lambda: [
            "job_interpretation",
            "owner_remediation_draft",
            "validation_summary",
        ],
    )
    status: Mapped[str] = mapped_column(String(40), default="not_tested")
    status_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    last_tested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )


class Workspace(Base):
    __tablename__ = "workspaces"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("wsp"))
    name: Mapped[str] = mapped_column(String(120))
    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    default_source_connector_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    default_target_connector_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    source_org: Mapped[str | None] = mapped_column(String(255), nullable=True)
    target_org: Mapped[str | None] = mapped_column(String(255), nullable=True)
    settings_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    migration_profile_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    owner: Mapped[User] = relationship(back_populates="workspaces")
    connectors: Mapped[list["Connector"]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )
    repositories: Mapped[list["RepositoryInventory"]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )
    jobs: Mapped[list["Job"]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )
    migration_runs: Mapped[list["MigrationRun"]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )
    discovery_runs: Mapped[list["DiscoveryRun"]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )
    saved_scopes: Mapped[list["SavedRepositoryScope"]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )


class Connector(Base):
    __tablename__ = "connectors"
    __table_args__ = (
        UniqueConstraint("workspace_id", "name", name="uq_connector_workspace_name"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("con"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    name: Mapped[str] = mapped_column(String(120))
    kind: Mapped[ConnectorKind] = mapped_column(
        Enum(ConnectorKind, native_enum=False, validate_strings=True)
    )
    target_flavor: Mapped[TargetFlavor] = mapped_column(
        Enum(TargetFlavor, native_enum=False, validate_strings=True),
        default=TargetFlavor.not_applicable,
    )
    base_url: Mapped[str] = mapped_column(String(1024))
    api_url: Mapped[str] = mapped_column(String(1024))
    encrypted_token: Mapped[str | None] = mapped_column(Text, nullable=True)
    token_last4: Mapped[str | None] = mapped_column(String(8), nullable=True)
    verify_ssl: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(40), default="not_tested")
    status_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )
    last_tested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    workspace: Mapped[Workspace] = relationship(back_populates="connectors")


class RepositoryInventory(Base):
    __tablename__ = "repository_inventory"
    __table_args__ = (
        UniqueConstraint("workspace_id", "source_org", "name", name="uq_inventory_repo"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("rep"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    connector_id: Mapped[str] = mapped_column(
        ForeignKey("connectors.id", ondelete="CASCADE"), index=True
    )
    source_org: Mapped[str] = mapped_column(String(255), index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    full_name: Mapped[str] = mapped_column(String(512))
    target_name: Mapped[str] = mapped_column(String(255))
    owner_login: Mapped[str | None] = mapped_column(String(255), nullable=True)
    owner_type: Mapped[str | None] = mapped_column(String(80), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    homepage: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    primary_language: Mapped[str | None] = mapped_column(String(120), nullable=True)
    license_spdx: Mapped[str | None] = mapped_column(String(120), nullable=True)
    topics_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    github_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    node_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    visibility: Mapped[str] = mapped_column(String(40), default="private")
    default_branch: Mapped[str | None] = mapped_column(String(255), nullable=True)
    archived: Mapped[bool] = mapped_column(Boolean, default=False)
    disabled: Mapped[bool] = mapped_column(Boolean, default=False)
    is_fork: Mapped[bool] = mapped_column(Boolean, default=False)
    empty_repository: Mapped[bool] = mapped_column(Boolean, default=False)
    size_kb: Mapped[int] = mapped_column(Integer, default=0)
    created_at_source: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at_source: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    pushed_at_source: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_commit_sha: Mapped[str | None] = mapped_column(String(128), nullable=True)
    last_commit_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_author_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_author_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_author_login: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_committer_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_committer_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_committer_login: Mapped[str | None] = mapped_column(String(255), nullable=True)
    inactive_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    branches_count: Mapped[int] = mapped_column(Integer, default=0)
    tags_count: Mapped[int] = mapped_column(Integer, default=0)
    open_issues_count: Mapped[int] = mapped_column(Integer, default=0)
    pull_requests_count: Mapped[int] = mapped_column(Integer, default=0)
    open_pull_requests_count: Mapped[int] = mapped_column(Integer, default=0)
    releases_count: Mapped[int] = mapped_column(Integer, default=0)
    release_assets_bytes: Mapped[int] = mapped_column(BigInteger, default=0)
    largest_release_asset_bytes: Mapped[int] = mapped_column(BigInteger, default=0)
    oversized_release_assets_count: Mapped[int] = mapped_column(Integer, default=0)
    workflows_count: Mapped[int] = mapped_column(Integer, default=0)
    environments_count: Mapped[int] = mapped_column(Integer, default=0)
    secrets_count: Mapped[int] = mapped_column(Integer, default=0)
    variables_count: Mapped[int] = mapped_column(Integer, default=0)
    webhooks_count: Mapped[int] = mapped_column(Integer, default=0)
    deploy_keys_count: Mapped[int] = mapped_column(Integer, default=0)
    collaborators_count: Mapped[int] = mapped_column(Integer, default=0)
    contributors_count: Mapped[int] = mapped_column(Integer, default=0)
    protected_branches_count: Mapped[int] = mapped_column(Integer, default=0)
    forks_count: Mapped[int] = mapped_column(Integer, default=0)
    stargazers_count: Mapped[int] = mapped_column(Integer, default=0)
    watchers_count: Mapped[int] = mapped_column(Integer, default=0)
    has_lfs: Mapped[bool] = mapped_column(Boolean, default=False)
    has_actions: Mapped[bool] = mapped_column(Boolean, default=False)
    pipeline_lane: Mapped[str] = mapped_column(String(40), default="without_pipelines", index=True)
    external_pipeline_count: Mapped[int] = mapped_column(Integer, default=0)
    self_hosted_runner_count: Mapped[int] = mapped_column(Integer, default=0)
    pipeline_risk_score: Mapped[float] = mapped_column(Float, default=0.0)
    pipeline_report_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    large_file_blocker_count: Mapped[int] = mapped_column(Integer, default=0)
    large_file_warning_count: Mapped[int] = mapped_column(Integer, default=0)
    largest_blob_bytes: Mapped[int] = mapped_column(BigInteger, default=0)
    target_org_checked: Mapped[str | None] = mapped_column(String(255), nullable=True)
    target_exists: Mapped[bool] = mapped_column(Boolean, default=False)
    target_repository_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    target_visibility: Mapped[str | None] = mapped_column(String(40), nullable=True)
    target_default_branch: Mapped[str | None] = mapped_column(String(255), nullable=True)
    target_last_commit_sha: Mapped[str | None] = mapped_column(String(128), nullable=True)
    target_state_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    readiness_score: Mapped[int] = mapped_column(Integer, default=0, index=True)
    readiness_grade: Mapped[str] = mapped_column(String(4), default="N/A", index=True)
    readiness_status: Mapped[str] = mapped_column(String(40), default="not_assessed", index=True)
    blocker_count: Mapped[int] = mapped_column(Integer, default=0)
    warning_count: Mapped[int] = mapped_column(Integer, default=0)
    blockers_json: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    warnings_json: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    readiness_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    raw_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    detail_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    selected: Mapped[bool] = mapped_column(Boolean, default=True)
    discovered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    workspace: Mapped[Workspace] = relationship(back_populates="repositories")
    connector: Mapped[Connector] = relationship()


class SavedRepositoryScope(Base):
    __tablename__ = "saved_repository_scopes"
    __table_args__ = (
        UniqueConstraint("workspace_id", "name", name="uq_scope_workspace_name"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("scp"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    lane: Mapped[str] = mapped_column(String(40), default="all")
    filters_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    repository_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    workspace: Mapped[Workspace] = relationship(back_populates="saved_scopes")
    created_by: Mapped[User] = relationship()


class DiscoveryRun(Base):
    __tablename__ = "discovery_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("dsc"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    connector_id: Mapped[str] = mapped_column(
        ForeignKey("connectors.id", ondelete="CASCADE"), index=True
    )
    target_connector_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    job_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    source_org: Mapped[str] = mapped_column(String(255), index=True)
    target_org: Mapped[str | None] = mapped_column(String(255), nullable=True)
    deep_scan: Mapped[bool] = mapped_column(Boolean, default=True)
    assess_target: Mapped[bool] = mapped_column(Boolean, default=True)
    options_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    status: Mapped[JobStatus] = mapped_column(
        Enum(JobStatus, native_enum=False, validate_strings=True),
        default=JobStatus.queued,
        index=True,
    )
    repository_count: Mapped[int] = mapped_column(Integer, default=0)
    organization_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    summary_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    workspace: Mapped[Workspace] = relationship(back_populates="discovery_runs")
    connector: Mapped[Connector] = relationship(foreign_keys=[connector_id])
    created_by: Mapped[User] = relationship()
    snapshots: Mapped[list["RepositorySnapshot"]] = relationship(
        back_populates="discovery_run", cascade="all, delete-orphan"
    )


class RepositorySnapshot(Base):
    __tablename__ = "repository_snapshots"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("snp"))
    discovery_run_id: Mapped[str] = mapped_column(
        ForeignKey("discovery_runs.id", ondelete="CASCADE"), index=True
    )
    repository_inventory_id: Mapped[str] = mapped_column(
        ForeignKey("repository_inventory.id", ondelete="CASCADE"), index=True
    )
    data_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    discovery_run: Mapped[DiscoveryRun] = relationship(back_populates="snapshots")
    repository: Mapped[RepositoryInventory] = relationship()


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("job"))
    workspace_id: Mapped[str | None] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), nullable=True, index=True
    )
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    kind: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[JobStatus] = mapped_column(
        Enum(JobStatus, native_enum=False, validate_strings=True),
        default=JobStatus.queued,
        index=True,
    )
    progress: Mapped[int] = mapped_column(Integer, default=0)
    current_step: Mapped[str | None] = mapped_column(String(255), nullable=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    result_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    log_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    workspace: Mapped[Workspace | None] = relationship(back_populates="jobs")
    created_by: Mapped[User] = relationship()


class MigrationRun(Base):
    __tablename__ = "migration_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("mig"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    source_connector_id: Mapped[str] = mapped_column(ForeignKey("connectors.id"))
    target_connector_id: Mapped[str] = mapped_column(ForeignKey("connectors.id"))
    source_org: Mapped[str] = mapped_column(String(255))
    target_org: Mapped[str] = mapped_column(String(255))
    method: Mapped[MigrationMethod] = mapped_column(
        Enum(MigrationMethod, native_enum=False, validate_strings=True), default=MigrationMethod.gei
    )
    mode: Mapped[MigrationMode] = mapped_column(
        Enum(MigrationMode, native_enum=False, validate_strings=True), default=MigrationMode.trial
    )
    pipeline_policy: Mapped[PipelinePolicy] = mapped_column(
        Enum(PipelinePolicy, native_enum=False, validate_strings=True),
        default=PipelinePolicy.preserve_disable_actions,
    )
    status: Mapped[MigrationStatus] = mapped_column(
        Enum(MigrationStatus, native_enum=False, validate_strings=True),
        default=MigrationStatus.planned,
        index=True,
    )
    cleanup_token: Mapped[str] = mapped_column(
        String(96), unique=True, default=lambda: new_id("purge")
    )
    lock_source_at_cutover: Mapped[bool] = mapped_column(Boolean, default=False)
    acknowledged_manual_actions: Mapped[bool] = mapped_column(Boolean, default=False)
    storage_mode: Mapped[str] = mapped_column(String(40), default="github_owned")
    skip_releases: Mapped[bool] = mapped_column(Boolean, default=False)
    concurrency: Mapped[int] = mapped_column(Integer, default=3)
    lane: Mapped[MigrationLane] = mapped_column(
        Enum(MigrationLane, native_enum=False, validate_strings=True),
        default=MigrationLane.all,
        index=True,
    )
    selection_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    preflight_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    workspace: Mapped[Workspace] = relationship(back_populates="migration_runs")
    created_by: Mapped[User] = relationship()
    source_connector: Mapped[Connector] = relationship(foreign_keys=[source_connector_id])
    target_connector: Mapped[Connector] = relationship(foreign_keys=[target_connector_id])
    repositories: Mapped[list["RepoMigration"]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )


class RepoMigration(Base):
    __tablename__ = "repo_migrations"
    __table_args__ = (
        UniqueConstraint("migration_run_id", "repository_inventory_id", name="uq_run_repo"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("rmg"))
    migration_run_id: Mapped[str] = mapped_column(
        ForeignKey("migration_runs.id", ondelete="CASCADE"), index=True
    )
    repository_inventory_id: Mapped[str] = mapped_column(
        ForeignKey("repository_inventory.id"), index=True
    )
    source_repo: Mapped[str] = mapped_column(String(255))
    target_repo: Mapped[str] = mapped_column(String(255))
    status: Mapped[RepoMigrationStatus] = mapped_column(
        Enum(RepoMigrationStatus, native_enum=False, validate_strings=True),
        default=RepoMigrationStatus.pending,
        index=True,
    )
    external_migration_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    source_sha_at_start: Mapped[str | None] = mapped_column(String(128), nullable=True)
    target_sha_after: Mapped[str | None] = mapped_column(String(128), nullable=True)
    warning_count: Mapped[int] = mapped_column(Integer, default=0)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    command_preview: Mapped[str | None] = mapped_column(Text, nullable=True)
    log_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    result_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    run: Mapped[MigrationRun] = relationship(back_populates="repositories")
    repository: Mapped[RepositoryInventory] = relationship()


class ValidationRun(Base):
    __tablename__ = "validation_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("val"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    migration_run_id: Mapped[str | None] = mapped_column(
        ForeignKey("migration_runs.id", ondelete="CASCADE"), nullable=True, index=True
    )
    source_connector_id: Mapped[str | None] = mapped_column(ForeignKey("connectors.id"), nullable=True)
    target_connector_id: Mapped[str | None] = mapped_column(ForeignKey("connectors.id"), nullable=True)
    source_org: Mapped[str | None] = mapped_column(String(255), nullable=True)
    target_org: Mapped[str | None] = mapped_column(String(255), nullable=True)
    lane: Mapped[MigrationLane] = mapped_column(
        Enum(MigrationLane, native_enum=False, validate_strings=True), default=MigrationLane.all
    )
    scope_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    status: Mapped[JobStatus] = mapped_column(
        Enum(JobStatus, native_enum=False, validate_strings=True), default=JobStatus.queued
    )
    passed_count: Mapped[int] = mapped_column(Integer, default=0)
    warning_count: Mapped[int] = mapped_column(Integer, default=0)
    failed_count: Mapped[int] = mapped_column(Integer, default=0)
    score: Mapped[int] = mapped_column(Integer, default=0)
    grade: Mapped[str] = mapped_column(String(4), default="N/A")
    report_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class PurgeRun(Base):
    __tablename__ = "purge_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("prg"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    migration_run_id: Mapped[str] = mapped_column(
        ForeignKey("migration_runs.id", ondelete="CASCADE"), index=True
    )
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    status: Mapped[JobStatus] = mapped_column(
        Enum(JobStatus, native_enum=False, validate_strings=True), default=JobStatus.queued
    )
    cleanup_token_used: Mapped[str] = mapped_column(String(96))
    dry_run: Mapped[bool] = mapped_column(Boolean, default=True)
    scope_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    deleted_count: Mapped[int] = mapped_column(Integer, default=0)
    skipped_count: Mapped[int] = mapped_column(Integer, default=0)
    failed_count: Mapped[int] = mapped_column(Integer, default=0)
    result_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class SourceFreezeRun(Base):
    __tablename__ = "source_freeze_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("frz"))
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), index=True
    )
    source_connector_id: Mapped[str] = mapped_column(ForeignKey("connectors.id"), index=True)
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    source_org: Mapped[str] = mapped_column(String(255), index=True)
    status: Mapped[JobStatus] = mapped_column(
        Enum(JobStatus, native_enum=False, validate_strings=True), default=JobStatus.queued
    )
    dry_run: Mapped[bool] = mapped_column(Boolean, default=True)
    scope_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    archived_count: Mapped[int] = mapped_column(Integer, default=0)
    skipped_count: Mapped[int] = mapped_column(Integer, default=0)
    failed_count: Mapped[int] = mapped_column(Integer, default=0)
    result_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("aud"))
    user_id: Mapped[str | None] = mapped_column(
        ForeignKey("users.id"), nullable=True, index=True
    )
    workspace_id: Mapped[str | None] = mapped_column(
        ForeignKey("workspaces.id", ondelete="SET NULL"), nullable=True, index=True
    )
    action: Mapped[str] = mapped_column(String(120), index=True)
    resource_type: Mapped[str] = mapped_column(String(80))
    resource_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    detail_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    ip_address: Mapped[str | None] = mapped_column(String(80), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, index=True
    )
