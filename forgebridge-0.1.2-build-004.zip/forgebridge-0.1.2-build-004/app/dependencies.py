from __future__ import annotations

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Branding, User, UserRole, Workspace


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    user_id = request.session.get("user_id")
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    user = db.get(User, user_id)
    if not user or not user.active:
        request.session.clear()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    return user


def admin_user(user: User = Depends(current_user)) -> User:
    if user.role != UserRole.admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Administrator access required")
    return user


def accessible_workspace(workspace_id: str, user: User, db: Session) -> Workspace:
    workspace = db.get(Workspace, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    if user.role != UserRole.admin and workspace.owner_id != user.id:
        raise HTTPException(status_code=403, detail="Workspace access denied")
    return workspace


def branding(db: Session) -> Branding:
    row = db.get(Branding, 1)
    if not row:
        row = Branding(id=1)
        db.add(row)
        db.commit()
        db.refresh(row)
    return row
