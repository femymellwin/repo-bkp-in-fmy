from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import re
from typing import Any

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from cryptography.fernet import Fernet, InvalidToken
from fastapi import HTTPException, Request, status

from app.config import get_settings


_password_hasher = PasswordHasher()


_EMBEDDED_SECRET_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"(?i)\b(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{8,}\b"),
    re.compile(r"(?i)\bops_[A-Za-z0-9_-]{16,}\b"),
    re.compile(r"(?i)(authorization\s*[:=]\s*(?:bearer|token)\s+)[^\s,;]+"),
    re.compile(
        r"(?i)((?:access[_-]?token|refresh[_-]?token|api[_-]?key|client[_-]?secret|password|passwd|pat)"
        r"\s*[:=]\s*[\"']?)[^\"'\s,;}]+"
    ),
    re.compile(r"(?i)([?&](?:access_token|token|api_key|key)=)[^&#\s]+"),
)

_SENSITIVE_LOG_KEYS = {
    "authorization",
    "credential",
    "credentials",
    "encrypted_token",
    "connection_string",
    "password",
    "passwd",
    "secret",
    "token",
    "pat",
    "api_key",
    "private_key",
    "client_secret",
    "access_token",
    "refresh_token",
}


def redact_text(value: str) -> str:
    """Remove credential-shaped values from free-form text before persistence."""

    redacted = value
    for pattern in _EMBEDDED_SECRET_PATTERNS:
        if pattern.groups:
            redacted = pattern.sub(lambda match: (match.group(1) if match.lastindex else "") + "***REDACTED***", redacted)
        else:
            redacted = pattern.sub("***REDACTED***", redacted)
    return redacted


def _sensitive_log_key(key: str) -> bool:
    normalized = key.strip().lower().replace("-", "_")
    if normalized in _SENSITIVE_LOG_KEYS:
        return True
    return normalized.endswith(
        (
            "_password",
            "_passwd",
            "_secret",
            "_token",
            "_pat",
            "_api_key",
            "_private_key",
            "_client_secret",
            "_credential",
            "_credentials",
            "_connection_string",
        )
    )


def redact_for_persistence(data: Any) -> Any:
    """Redact actual credential values while preserving safe metadata names.

    Fields such as ``secret_names`` and ``token_scopes`` are inventory metadata,
    not secret values, and remain available to migration operators.
    """

    if isinstance(data, dict):
        result: dict[str, Any] = {}
        for key, value in data.items():
            key_text = str(key)
            result[key_text] = "***REDACTED***" if _sensitive_log_key(key_text) else redact_for_persistence(value)
        return result
    if isinstance(data, (list, tuple, set)):
        return [redact_for_persistence(item) for item in data]
    if isinstance(data, str):
        return redact_text(data)
    return data


def hash_password(password: str) -> str:
    return _password_hasher.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _password_hasher.verify(password_hash, password)
    except VerifyMismatchError:
        return False
    except Exception:
        return False


def _fernet() -> Fernet:
    settings = get_settings()
    if settings.token_encryption_key:
        key = settings.token_encryption_key.encode("utf-8")
    else:
        digest = hashlib.sha256(settings.secret_key.encode("utf-8")).digest()
        key = base64.urlsafe_b64encode(digest)
    return Fernet(key)


def encrypt_secret(value: str) -> str:
    return _fernet().encrypt(value.encode("utf-8")).decode("utf-8")


def decrypt_secret(value: str | None) -> str | None:
    if not value:
        return None
    try:
        return _fernet().decrypt(value.encode("utf-8")).decode("utf-8")
    except InvalidToken as exc:
        raise RuntimeError("Unable to decrypt connector credential. Check TOKEN_ENCRYPTION_KEY.") from exc


def issue_csrf_token(request: Request) -> str:
    token = request.session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf_token"] = token
    return token


def validate_csrf(request: Request, submitted: str | None) -> None:
    expected = request.session.get("csrf_token")
    if not expected or not submitted or not hmac.compare_digest(expected, submitted):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid CSRF token")


def redact_sensitive(data: Any) -> Any:
    if isinstance(data, dict):
        result: dict[str, Any] = {}
        for key, value in data.items():
            lowered = key.lower()
            if any(term in lowered for term in ("token", "secret", "password", "authorization", "key")):
                result[key] = "***REDACTED***"
            else:
                result[key] = redact_sensitive(value)
        return result
    if isinstance(data, list):
        return [redact_sensitive(item) for item in data]
    if isinstance(data, tuple):
        return [redact_sensitive(item) for item in data]
    if isinstance(data, str):
        return redact_text(data)
    return data
