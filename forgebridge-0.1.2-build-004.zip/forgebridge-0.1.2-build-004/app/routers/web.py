from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app.dependencies import accessible_workspace, admin_user, branding, current_user
from app.models import (
    AIConfiguration,
    AuditLog,
    Branding,
    Connector,
    ConnectorKind,
    DiscoveryRun,
    Job,
    JobStatus,
    MigrationLane,
    MigrationMethod,
    MigrationMode,
    MigrationRun,
    MigrationStatus,
    MenuSetting,
    PipelinePolicy,
    PurgeRun,
    RepoMigration,
    RepoMigrationStatus,
    RepositoryInventory,
    SavedRepositoryScope,
    SourceFreezeRun,
    TargetFlavor,
    User,
    UserRole,
    ValidationRun,
    Workspace,
    utcnow,
)
from app.menu import MENU_GROUPS, ensure_menu_settings, menu_settings, normalize_menu
from app.policy import METHOD_POLICY
from app.security import encrypt_secret, hash_password, issue_csrf_token, validate_csrf, verify_password
from app.services.audit import record_audit
from app.services.branding import (
    DEFAULT_THEME,
    current_logo_file,
    delete_logo,
    logo_media_type,
    normalized_theme,
    persist_logo,
    safe_color,
    safe_logo_url,
)
from app.services.readiness import assess_repository
from app.services.migration import gei_tooling_status
from app.services.reports import (
    discovery_csv,
    migration_mapping_csv,
    migration_summary_json,
    onepassword_runbook_markdown,
    pipeline_csv,
    pipeline_owner_handoff_data,
    pipeline_owner_handoff_json,
    pipeline_owner_handoff_markdown,
    report_bundle_zip,
    validation_json,
)
from app.services.url_validation import (
    UrlValidationError,
    validate_azure_openai_endpoint,
    validate_connector_urls,
)
from app.services.source_protection import source_freeze_evidence
from app.task_dispatch import enqueue_job


router = APIRouter()
STATIC_DIR = Path(__file__).resolve().parents[1] / "static"
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parents[1] / "templates"))
settings = get_settings()


def format_datetime(value: Any) -> str:
    if not value:
        return "-"
    if isinstance(value, str):
        return value
    try:
        return value.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        return str(value)


def pretty_json(value: Any) -> str:
    return json.dumps(value or {}, indent=2, default=str)


def status_css(value: Any) -> str:
    text = getattr(value, "value", value)
    text = str(text or "unknown").lower()
    if text in {"succeeded", "completed", "connected", "pass"}:
        return "success"
    if text in {"failed", "fail", "blocked"}:
        return "danger"
    if text in {"warning", "completed_with_warnings", "ready_for_cutover"}:
        return "warning"
    if text in {"running", "queued", "planned"}:
        return "info"
    return "neutral"


templates.env.filters["dt"] = format_datetime
templates.env.filters["prettyjson"] = pretty_json
templates.env.filters["statuscss"] = status_css


def slugify(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return value[:100] or "workspace"


def flash(request: Request, message: str, category: str = "info") -> None:
    request.session["flash"] = {"message": message, "category": category}


def template_context(request: Request, db: Session, user: User | None = None, **kwargs: Any) -> dict[str, Any]:
    menu_rows = ensure_menu_settings(db)
    configured_menu = {row.key: row.enabled for row in menu_rows}
    brand = branding(db)
    theme = normalized_theme(brand.theme_json)

    workspace_rows: list[Workspace] = []
    active_workspace: Workspace | None = None
    if user:
        query = select(Workspace)
        if user.role != UserRole.admin:
            query = query.where(Workspace.owner_id == user.id)
        workspace_rows = db.scalars(query.order_by(Workspace.name.asc())).all()
        by_id = {item.id: item for item in workspace_rows}
        supplied = kwargs.get("workspace")
        if isinstance(supplied, Workspace) and supplied.id in by_id:
            active_workspace = supplied
            request.session["active_workspace_id"] = supplied.id
        else:
            active_workspace = by_id.get(str(request.session.get("active_workspace_id", "")))
            if active_workspace is None and workspace_rows:
                active_workspace = workspace_rows[0]
                request.session["active_workspace_id"] = active_workspace.id
            elif active_workspace is None:
                request.session.pop("active_workspace_id", None)

    revision = int(brand.updated_at.timestamp()) if brand.updated_at else 0
    logo_url = brand.logo_url or "/static/inception42-logo.png"
    favicon_url = brand.logo_url or "/favicon.svg"
    context = {
        "request": request,
        "current_user": user,
        "branding": brand,
        "brand_theme": theme,
        "brand_revision": revision,
        "brand_logo_url": logo_url,
        "brand_favicon_url": favicon_url,
        "brand_logo_suffix": f"?v={revision}" if logo_url.startswith("/") else "",
        "brand_favicon_suffix": f"?v={revision}" if favicon_url.startswith("/") else "",
        "csrf_token": issue_csrf_token(request),
        "flash": request.session.pop("flash", None),
        "now": datetime.now(timezone.utc),
        "settings": settings,
        "method_policy": METHOD_POLICY,
        "menu_groups": MENU_GROUPS,
        "menu_enabled": configured_menu,
        "menu_settings": menu_rows,
        "menu_map": {row.key: row for row in menu_rows},
        "workspace_list": workspace_rows,
        "active_workspace": active_workspace,
    }
    context.update(kwargs)
    return context


def html(request: Request, db: Session, template: str, user: User | None = None, status_code: int = 200, **kwargs: Any) -> HTMLResponse:
    return templates.TemplateResponse(
        request=request,
        name=template,
        context=template_context(request, db, user, **kwargs),
        status_code=status_code,
    )


def job_for(db: Session, user: User, workspace_id: str | None, kind: str, payload: dict[str, Any]) -> Job:
    job = Job(workspace_id=workspace_id, created_by_id=user.id, kind=kind, payload_json=payload)
    db.add(job)
    db.commit()
    db.refresh(job)
    try:
        enqueue_job(job.id)
    except Exception as exc:
        job.status = JobStatus.failed
        job.error_message = f"Failed to enqueue background job: {exc}"
        job.finished_at = utcnow()
        db.add(job)
        db.commit()
        raise HTTPException(status_code=503, detail="The background job queue is unavailable; no migration action was started") from exc
    return job


def ensure_connector_in_workspace(db: Session, workspace: Workspace, connector_id: str) -> Connector:
    connector = db.get(Connector, connector_id)
    if not connector or connector.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Connector not found")
    return connector


def connector_reference_summary(db: Session, connector_id: str) -> dict[str, int]:
    """Return durable references that make connector deletion unsafe.

    Connector history is evidence. Deleting a connector that is referenced by
    discovery, validation, migration, freeze, inventory, or workspace defaults
    would make that evidence ambiguous even when the PAT itself has been rotated.
    """

    return {
        "repository inventory": int(db.scalar(select(func.count()).select_from(RepositoryInventory).where(RepositoryInventory.connector_id == connector_id)) or 0),
        "discovery history": int(db.scalar(select(func.count()).select_from(DiscoveryRun).where((DiscoveryRun.connector_id == connector_id) | (DiscoveryRun.target_connector_id == connector_id))) or 0),
        "migration history": int(db.scalar(select(func.count()).select_from(MigrationRun).where((MigrationRun.source_connector_id == connector_id) | (MigrationRun.target_connector_id == connector_id))) or 0),
        "validation history": int(db.scalar(select(func.count()).select_from(ValidationRun).where((ValidationRun.source_connector_id == connector_id) | (ValidationRun.target_connector_id == connector_id))) or 0),
        "source read-only history": int(db.scalar(select(func.count()).select_from(SourceFreezeRun).where(SourceFreezeRun.source_connector_id == connector_id)) or 0),
        "workspace defaults": int(db.scalar(select(func.count()).select_from(Workspace).where((Workspace.default_source_connector_id == connector_id) | (Workspace.default_target_connector_id == connector_id))) or 0),
    }


def lane_path(workspace_id: str, lane: MigrationLane | str) -> str:
    value = getattr(lane, "value", lane)
    if value == MigrationLane.with_pipelines.value:
        return f"/workspaces/{workspace_id}/github/with-pipelines"
    if value == MigrationLane.without_pipelines.value:
        return f"/workspaces/{workspace_id}/github/without-pipelines"
    return f"/workspaces/{workspace_id}/migrations"


def active_run_jobs(db: Session, workspace_id: str, run_id: str, kinds: set[str] | None = None) -> list[Job]:
    """Return queued/running jobs that refer to a migration run.

    We intentionally inspect persisted JSON in Python so this guard behaves the
    same on SQLite evaluation builds and PostgreSQL production deployments.
    """

    active = db.scalars(
        select(Job).where(
            Job.workspace_id == workspace_id,
            Job.status.in_([JobStatus.queued, JobStatus.running]),
        )
    ).all()
    return [
        job
        for job in active
        if (not kinds or job.kind in kinds)
        and str((job.payload_json or {}).get("migration_run_id", "")) == run_id
    ]


@router.get("/health", response_class=JSONResponse)
def health() -> dict[str, str]:
    return {
        "status": "ok",
        "service": settings.app_name,
        "version": settings.app_version,
        "build": settings.app_build_number,
    }


@router.get("/branding/theme.css")
def branding_theme(db: Session = Depends(get_db)) -> Response:
    theme = normalized_theme(branding(db).theme_json)
    content = "\n".join(
        [
            ":root {",
            f"  --ado2-primary: {theme['primary']};",
            f"  --ado2-accent: {theme['accent']};",
            f"  --ado2-grad-from: {theme['gradient_from']};",
            f"  --ado2-grad-to: {theme['gradient_to']};",
            f"  --ado2-border: {theme['border']};",
            f"  --ado2-button-bg: {theme['button_bg']};",
            f"  --ado2-button-border: {theme['button_border']};",
            f"  --ado2-button-text: {theme['button_text']};",
            f"  --primary: {theme['accent']};",
            f"  --text: {theme['primary']};",
            f"  --line: {theme['border']};",
            "}",
        ]
    )
    return Response(
        content,
        media_type="text/css",
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


def _logo_response(default_favicon: bool = False) -> FileResponse:
    custom = current_logo_file(settings)
    if custom:
        return FileResponse(custom, media_type=logo_media_type(custom))
    path = STATIC_DIR / ("favicon.svg" if default_favicon else "inception42-logo.png")
    return FileResponse(path, media_type="image/svg+xml" if default_favicon else "image/png")


@router.get("/branding/logo")
def branding_logo() -> FileResponse:
    return _logo_response(default_favicon=False)


@router.get("/favicon.svg")
def favicon_svg() -> FileResponse:
    return _logo_response(default_favicon=True)


@router.get("/favicon.ico")
def favicon_ico() -> FileResponse:
    return _logo_response(default_favicon=True)


@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request, db: Session = Depends(get_db)) -> HTMLResponse:
    if request.session.get("user_id"):
        return RedirectResponse("/", status_code=303)
    return html(request, db, "login.html")


@router.post("/login")
async def login(request: Request, db: Session = Depends(get_db)) -> Response:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    username = str(form.get("username", "")).strip()
    password = str(form.get("password", ""))
    user = db.scalar(select(User).where(User.username == username))
    if not user or not user.active or not verify_password(password, user.password_hash):
        return html(request, db, "login.html", error="Invalid username or password", status_code=401)
    user.last_login_at = datetime.now(timezone.utc)
    db.add(user)
    db.commit()
    request.session.clear()
    request.session["user_id"] = user.id
    issue_csrf_token(request)
    record_audit(db, action="login", resource_type="user", resource_id=user.id, user_id=user.id, ip_address=request.client.host if request.client else None)
    return RedirectResponse("/", status_code=303)


@router.post("/logout")
async def logout(request: Request, db: Session = Depends(get_db)) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    user_id = request.session.get("user_id")
    request.session.clear()
    if user_id:
        record_audit(db, action="logout", resource_type="user", resource_id=user_id, user_id=user_id)
    return RedirectResponse("/login", status_code=303)


@router.post("/workspaces/switch")
async def switch_workspace(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    workspace_id = str(form.get("workspace_id", "")).strip()
    workspace = accessible_workspace(workspace_id, user, db)
    request.session["active_workspace_id"] = workspace.id
    return RedirectResponse(f"/workspaces/{workspace.id}", status_code=303)


@router.get("/", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace_query = select(Workspace)
    if user.role != UserRole.admin:
        workspace_query = workspace_query.where(Workspace.owner_id == user.id)
    workspaces = db.scalars(workspace_query.order_by(Workspace.updated_at.desc())).all()
    workspace_ids = [item.id for item in workspaces]
    jobs = []
    migrations = []
    if workspace_ids:
        jobs = db.scalars(select(Job).where(Job.workspace_id.in_(workspace_ids)).order_by(Job.created_at.desc()).limit(8)).all()
        migrations = db.scalars(
            select(MigrationRun).where(MigrationRun.workspace_id.in_(workspace_ids)).order_by(MigrationRun.created_at.desc()).limit(8)
        ).all()
    stats = {
        "workspaces": len(workspaces),
        "repositories": db.scalar(select(func.count()).select_from(RepositoryInventory).where(RepositoryInventory.workspace_id.in_(workspace_ids))) if workspace_ids else 0,
        "running_jobs": db.scalar(select(func.count()).select_from(Job).where(Job.workspace_id.in_(workspace_ids), Job.status.in_([JobStatus.queued, JobStatus.running]))) if workspace_ids else 0,
        "migration_runs": db.scalar(select(func.count()).select_from(MigrationRun).where(MigrationRun.workspace_id.in_(workspace_ids))) if workspace_ids else 0,
    }
    return html(request, db, "dashboard.html", user, workspaces=workspaces, jobs=jobs, migrations=migrations, stats=stats)


@router.get("/workspaces", response_class=HTMLResponse)
def workspaces_page(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    query = select(Workspace)
    if user.role != UserRole.admin:
        query = query.where(Workspace.owner_id == user.id)
    rows = db.scalars(query.order_by(Workspace.created_at.desc())).all()
    return html(request, db, "workspaces.html", user, workspaces=rows)


@router.post("/workspaces")
async def create_workspace(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    name = str(form.get("name", "")).strip()
    description = str(form.get("description", "")).strip() or None
    if not name:
        flash(request, "Workspace name is required.", "error")
        return RedirectResponse("/workspaces", status_code=303)
    base_slug = slugify(name)
    slug = base_slug
    suffix = 2
    while db.scalar(select(Workspace).where(Workspace.slug == slug)):
        slug = f"{base_slug}-{suffix}"
        suffix += 1
    workspace = Workspace(name=name, slug=slug, description=description, owner_id=user.id)
    db.add(workspace)
    db.commit()
    db.refresh(workspace)
    record_audit(db, action="workspace.create", resource_type="workspace", resource_id=workspace.id, workspace_id=workspace.id, user_id=user.id)
    return RedirectResponse(f"/workspaces/{workspace.id}", status_code=303)


@router.get("/workspaces/{workspace_id}", response_class=HTMLResponse)
def workspace_detail(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    repositories = db.scalars(
        select(RepositoryInventory).where(RepositoryInventory.workspace_id == workspace.id)
    ).all()
    jobs = db.scalars(
        select(Job).where(Job.workspace_id == workspace.id).order_by(Job.created_at.desc()).limit(6)
    ).all()
    runs = db.scalars(
        select(MigrationRun).where(MigrationRun.workspace_id == workspace.id).order_by(MigrationRun.created_at.desc()).limit(6)
    ).all()
    sources = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghes, ConnectorKind.simulated_ghes]),
        ).order_by(Connector.name)
    ).all()
    targets = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghec, ConnectorKind.simulated_ghec]),
        ).order_by(Connector.name)
    ).all()
    stats = {
        "repositories": len(repositories),
        "with_pipelines": sum(1 for item in repositories if item.pipeline_lane == MigrationLane.with_pipelines.value),
        "ready": sum(1 for item in repositories if item.readiness_status == "ready"),
        "blocked": sum(1 for item in repositories if item.readiness_status == "blocked"),
        "running_jobs": db.scalar(
            select(func.count()).select_from(Job).where(
                Job.workspace_id == workspace.id,
                Job.status.in_([JobStatus.queued, JobStatus.running]),
            )
        ) or 0,
        "migration_runs": db.scalar(
            select(func.count()).select_from(MigrationRun).where(MigrationRun.workspace_id == workspace.id)
        ) or 0,
    }
    return html(
        request,
        db,
        "workspace.html",
        user,
        workspace=workspace,
        jobs=jobs,
        runs=runs,
        sources=sources,
        targets=targets,
        profile=workspace.migration_profile_json or {},
        stats=stats,
    )


@router.get("/workspaces/{workspace_id}/connectors", response_class=HTMLResponse)
def connectors_page(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    connectors = db.scalars(select(Connector).where(Connector.workspace_id == workspace.id).order_by(Connector.created_at)).all()
    return html(request, db, "connectors.html", user, workspace=workspace, connectors=connectors, connector_kinds=list(ConnectorKind), target_flavors=list(TargetFlavor))


@router.post("/workspaces/{workspace_id}/connectors")
async def create_connector(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    try:
        kind = ConnectorKind(str(form.get("kind")))
        target_flavor = TargetFlavor(str(form.get("target_flavor", TargetFlavor.not_applicable.value)))
    except ValueError:
        flash(request, "Choose a supported connector type and destination flavor.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    name = str(form.get("name", "")).strip()
    base_url = str(form.get("base_url", "")).strip().rstrip("/")
    api_url = str(form.get("api_url", "")).strip().rstrip("/")
    token = str(form.get("token", "")).strip()
    verify_ssl = True
    if kind == ConnectorKind.ghec and target_flavor == TargetFlavor.github_com:
        base_url = base_url or "https://github.com"
        api_url = api_url or "https://api.github.com"
    elif kind == ConnectorKind.ghec and target_flavor == TargetFlavor.ghe_com:
        if api_url and not base_url and api_url.startswith("https://api."):
            base_url = "https://" + api_url.removeprefix("https://api.")
    if kind == ConnectorKind.ghes:
        target_flavor = TargetFlavor.not_applicable
        if base_url and not api_url:
            api_url = base_url + "/api/v3"
        elif api_url.endswith("/api/v3") and not base_url:
            base_url = api_url[: -len("/api/v3")]
    if kind == ConnectorKind.onepassword:
        target_flavor = TargetFlavor.not_applicable
        base_url = base_url or api_url
        api_url = api_url or base_url
    if kind in (ConnectorKind.simulated_ghes, ConnectorKind.simulated_ghec):
        token = ""
        if kind == ConnectorKind.simulated_ghec and target_flavor == TargetFlavor.not_applicable:
            target_flavor = TargetFlavor.ghe_com
    if kind not in (ConnectorKind.simulated_ghes, ConnectorKind.simulated_ghec) and not token:
        flash(request, "A token is required for this connector.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    if not name or not api_url:
        flash(request, "Connector name and API URL are required.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    try:
        validated_urls = validate_connector_urls(kind, target_flavor, base_url or api_url, api_url)
    except UrlValidationError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    connector = Connector(
        workspace_id=workspace.id,
        name=name,
        kind=kind,
        target_flavor=target_flavor,
        base_url=validated_urls.base_url,
        api_url=validated_urls.api_url,
        encrypted_token=encrypt_secret(token) if token else None,
        token_last4=token[-4:] if token else None,
        verify_ssl=verify_ssl,
    )
    db.add(connector)
    db.commit()
    db.refresh(connector)
    record_audit(db, action="connector.create", resource_type="connector", resource_id=connector.id, workspace_id=workspace.id, user_id=user.id, details={"kind": kind.value, "api_url": api_url})
    flash(request, "Connector created. Run the connection test before discovery or migration.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)


@router.post("/workspaces/{workspace_id}/connectors/{connector_id}/test")
async def test_connector(workspace_id: str, connector_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    connector = ensure_connector_in_workspace(db, workspace, connector_id)
    job = job_for(db, user, workspace.id, "connector_test", {"connector_id": connector.id})
    record_audit(db, action="connector.test", resource_type="connector", resource_id=connector.id, workspace_id=workspace.id, user_id=user.id, details={"job_id": job.id})
    flash(request, f"Connector test queued as {job.id}.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/jobs", status_code=303)


@router.post("/workspaces/{workspace_id}/connectors/{connector_id}/update")
async def update_connector(workspace_id: str, connector_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    connector = ensure_connector_in_workspace(db, workspace, connector_id)
    name = str(form.get("name", connector.name)).strip()
    base_url = str(form.get("base_url", connector.base_url)).strip().rstrip("/")
    api_url = str(form.get("api_url", connector.api_url)).strip().rstrip("/")
    token = str(form.get("token", "")).strip()
    verify_ssl = True
    try:
        target_flavor = TargetFlavor(str(form.get("target_flavor", connector.target_flavor.value)))
    except ValueError:
        flash(request, "Choose a supported destination flavor.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    if connector.kind == ConnectorKind.ghec and target_flavor == TargetFlavor.github_com:
        base_url = base_url or "https://github.com"
        api_url = api_url or "https://api.github.com"
    elif connector.kind == ConnectorKind.ghec and target_flavor == TargetFlavor.ghe_com:
        if api_url and not base_url and api_url.startswith("https://api."):
            base_url = "https://" + api_url.removeprefix("https://api.")
    if connector.kind == ConnectorKind.ghes and base_url and not api_url:
        api_url = base_url + "/api/v3"
    elif connector.kind == ConnectorKind.ghes and api_url.endswith("/api/v3") and not base_url:
        base_url = api_url[: -len("/api/v3")]
    if connector.kind == ConnectorKind.onepassword:
        target_flavor = TargetFlavor.not_applicable
        base_url = base_url or api_url
        api_url = api_url or base_url
    if not name or not api_url:
        flash(request, "Connector name and API URL are required.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    try:
        validated_urls = validate_connector_urls(
            connector.kind,
            target_flavor,
            base_url or api_url,
            api_url,
        )
    except UrlValidationError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    connector.name = name
    connector.base_url = validated_urls.base_url
    connector.api_url = validated_urls.api_url
    connector.verify_ssl = verify_ssl
    connector.target_flavor = target_flavor
    if token:
        connector.encrypted_token = encrypt_secret(token)
        connector.token_last4 = token[-4:]
    connector.status = "not_tested"
    connector.status_message = "Connector settings changed; run the connection test again"
    db.add(connector)
    db.commit()
    record_audit(db, action="connector.update", resource_type="connector", resource_id=connector.id, workspace_id=workspace.id, user_id=user.id, details={"api_url": api_url, "token_rotated": bool(token)})
    flash(request, "Connector updated. Test it before use.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)


@router.post("/workspaces/{workspace_id}/connectors/{connector_id}/delete")
async def delete_connector(workspace_id: str, connector_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    connector = ensure_connector_in_workspace(db, workspace, connector_id)
    references = connector_reference_summary(db, connector.id)
    active_references = {label: count for label, count in references.items() if count}
    if active_references:
        detail = ", ".join(f"{label}: {count}" for label, count in active_references.items())
        flash(request, f"Connector cannot be deleted because retained evidence references it ({detail}). Rotate or disable its token instead.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)
    record_audit(db, action="connector.delete", resource_type="connector", resource_id=connector.id, workspace_id=workspace.id, user_id=user.id)
    db.delete(connector)
    db.commit()
    flash(request, "Connector deleted.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/connectors", status_code=303)


@router.get("/workspaces/{workspace_id}/github/discovery", response_class=HTMLResponse)
@router.get("/workspaces/{workspace_id}/discovery", response_class=HTMLResponse)
def discovery_page(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    sources = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghes, ConnectorKind.simulated_ghes]),
        ).order_by(Connector.name)
    ).all()
    targets = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghec, ConnectorKind.simulated_ghec]),
        ).order_by(Connector.name)
    ).all()
    repos = db.scalars(
        select(RepositoryInventory)
        .where(RepositoryInventory.workspace_id == workspace.id)
        .order_by(RepositoryInventory.source_org, RepositoryInventory.name)
    ).all()
    discovery_runs = db.scalars(
        select(DiscoveryRun)
        .where(DiscoveryRun.workspace_id == workspace.id)
        .order_by(DiscoveryRun.created_at.desc())
        .limit(50)
    ).all()
    summary = {
        "total": len(repos),
        "with_pipelines": sum(1 for item in repos if item.pipeline_lane == "with_pipelines"),
        "without_pipelines": sum(1 for item in repos if item.pipeline_lane == "without_pipelines"),
        "ready": sum(1 for item in repos if item.readiness_status == "ready"),
        "needs_review": sum(1 for item in repos if item.readiness_status == "needs_review"),
        "blocked": sum(1 for item in repos if item.readiness_status == "blocked"),
        "target_conflicts": sum(1 for item in repos if (item.target_state_json or {}).get("exists") is True),
    }
    return html(
        request,
        db,
        "github_discovery.html",
        user,
        workspace=workspace,
        sources=sources,
        targets=targets,
        connectors=sources,
        repositories=repos,
        discovery_runs=discovery_runs,
        summary=summary,
        profile=workspace.migration_profile_json or {},
    )


@router.post("/workspaces/{workspace_id}/github/discovery")
@router.post("/workspaces/{workspace_id}/discovery")
async def start_discovery(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    connector = ensure_connector_in_workspace(db, workspace, str(form.get("connector_id")))
    if connector.kind not in (ConnectorKind.ghes, ConnectorKind.simulated_ghes):
        raise HTTPException(status_code=400, detail="Discovery requires a GHES source connector")
    source_org = str(form.get("source_org", "")).strip()
    if not source_org:
        flash(request, "Source organization is required.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/discovery", status_code=303)

    target_connector_id = str(form.get("target_connector_id", "")).strip() or None
    target_org = str(form.get("target_org", "")).strip() or None
    if target_connector_id:
        target = ensure_connector_in_workspace(db, workspace, target_connector_id)
        if target.kind not in (ConnectorKind.ghec, ConnectorKind.simulated_ghec):
            flash(request, "The target probe requires a GHEC connector.", "error")
            return RedirectResponse(f"/workspaces/{workspace.id}/github/discovery", status_code=303)
    else:
        target = None

    deep_scan = form.get("deep_scan") == "on"
    options = {
        "deep_scan": deep_scan,
        "pipeline_scan": form.get("pipeline_scan") == "on",
        "external_pipeline_scan": form.get("external_pipeline_scan") == "on",
        "large_file_scan": form.get("large_file_scan") == "on",
        "target_probe": form.get("target_probe") == "on" and bool(target and target_org),
        "target_connector_id": target.id if target else None,
        "target_org": target_org,
        "readiness_method": str(form.get("readiness_method", "gei")),
    }
    discovery = DiscoveryRun(
        workspace_id=workspace.id,
        connector_id=connector.id,
        created_by_id=user.id,
        source_org=source_org,
        target_connector_id=target.id if target else None,
        target_org=target_org,
        deep_scan=deep_scan,
        assess_target=bool(options["target_probe"]),
        options_json=options,
        status=JobStatus.queued,
    )
    profile = dict(workspace.migration_profile_json or {})
    profile.update(
        {
            "source_connector_id": connector.id,
            "source_org": source_org,
            "target_connector_id": target.id if target else profile.get("target_connector_id"),
            "target_org": target_org or profile.get("target_org"),
            "default_method": options["readiness_method"],
        }
    )
    workspace.migration_profile_json = profile
    db.add_all([workspace, discovery])
    db.commit()
    db.refresh(discovery)
    job = job_for(
        db,
        user,
        workspace.id,
        "discovery",
        {
            "connector_id": connector.id,
            "source_org": source_org,
            "discovery_run_id": discovery.id,
            **options,
        },
    )
    discovery.job_id = job.id
    db.add(discovery)
    db.commit()
    record_audit(
        db,
        action="discovery.start",
        resource_type="discovery_run",
        resource_id=discovery.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"job_id": job.id, "source_org": source_org, "options": options},
    )
    flash(request, f"Discovery queued as {job.id}. It will continue in the Jobs service while you use other menus.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/jobs", status_code=303)


@router.get("/workspaces/{workspace_id}/repositories/{repository_id}", response_class=HTMLResponse)
def repository_detail(workspace_id: str, repository_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    repository = db.get(RepositoryInventory, repository_id)
    if not repository or repository.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Repository not found")
    return html(request, db, "repository.html", user, workspace=workspace, repository=repository)


def _github_lane_page(
    workspace_id: str,
    lane: MigrationLane,
    request: Request,
    db: Session,
    user: User,
) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    repositories = db.scalars(
        select(RepositoryInventory)
        .where(
            RepositoryInventory.workspace_id == workspace.id,
            RepositoryInventory.pipeline_lane == lane.value,
        )
        .order_by(RepositoryInventory.readiness_status, RepositoryInventory.name)
    ).all()
    sources = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghes, ConnectorKind.simulated_ghes]),
        ).order_by(Connector.name)
    ).all()
    targets = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghec, ConnectorKind.simulated_ghec]),
        ).order_by(Connector.name)
    ).all()
    runs = db.scalars(
        select(MigrationRun)
        .where(MigrationRun.workspace_id == workspace.id, MigrationRun.lane == lane)
        .order_by(MigrationRun.created_at.desc())
    ).all()
    scopes = db.scalars(
        select(SavedRepositoryScope)
        .where(
            SavedRepositoryScope.workspace_id == workspace.id,
            SavedRepositoryScope.lane.in_([lane.value, MigrationLane.all.value]),
        )
        .order_by(SavedRepositoryScope.updated_at.desc())
    ).all()
    requested_scope_id = str(request.query_params.get("scope", "")).strip()
    selected_scope = next((item for item in scopes if item.id == requested_scope_id), None)
    available_ids = {item.id for item in repositories}
    selected_scope_ids = set(selected_scope.repository_ids_json or []) if selected_scope else set()
    stale_scope_ids = sorted(selected_scope_ids - available_ids)
    selected_scope_ids &= available_ids
    return html(
        request,
        db,
        "github_lane.html",
        user,
        workspace=workspace,
        lane=lane,
        repositories=repositories,
        sources=sources,
        targets=targets,
        runs=runs,
        scopes=scopes,
        selected_scope=selected_scope,
        selected_scope_ids=selected_scope_ids,
        stale_scope_ids=stale_scope_ids,
        source_orgs=sorted({item.source_org for item in repositories}),
        methods=[MigrationMethod.gei, MigrationMethod.elm],
        modes=list(MigrationMode),
        pipeline_policies=list(PipelinePolicy),
        profile=workspace.migration_profile_json or {},
        summary={
            "total": len(repositories),
            "ready": sum(1 for item in repositories if item.readiness_status == "ready"),
            "needs_review": sum(1 for item in repositories if item.readiness_status == "needs_review"),
            "blocked": sum(1 for item in repositories if item.readiness_status == "blocked"),
            "target_conflicts": sum(1 for item in repositories if (item.target_state_json or {}).get("exists") is True),
        },
    )


@router.get("/workspaces/{workspace_id}/github/with-pipelines", response_class=HTMLResponse)
def github_with_pipelines(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    return _github_lane_page(workspace_id, MigrationLane.with_pipelines, request, db, user)


@router.get("/workspaces/{workspace_id}/github/without-pipelines", response_class=HTMLResponse)
def github_without_pipelines(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    return _github_lane_page(workspace_id, MigrationLane.without_pipelines, request, db, user)


@router.post("/workspaces/{workspace_id}/github/scopes")
async def save_repository_scope(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    try:
        lane = MigrationLane(str(form.get("lane", MigrationLane.all.value)))
    except ValueError:
        lane = MigrationLane.all
    name = str(form.get("scope_name", "")).strip()[:120]
    requested_ids = [str(value) for value in form.getlist("repository_ids")]
    if not name:
        flash(request, "Enter a saved-scope name.", "error")
        return RedirectResponse(lane_path(workspace.id, lane), status_code=303)
    repositories = db.scalars(
        select(RepositoryInventory).where(
            RepositoryInventory.workspace_id == workspace.id,
            RepositoryInventory.id.in_(requested_ids),
        )
    ).all() if requested_ids else []
    valid_ids = [
        item.id
        for item in repositories
        if lane == MigrationLane.all or item.pipeline_lane == lane.value
    ]
    if not valid_ids:
        flash(request, "Select at least one repository from this migration lane before saving a scope.", "error")
        return RedirectResponse(lane_path(workspace.id, lane), status_code=303)
    existing = db.scalar(
        select(SavedRepositoryScope).where(
            SavedRepositoryScope.workspace_id == workspace.id,
            SavedRepositoryScope.name == name,
        )
    )
    scope = existing or SavedRepositoryScope(
        workspace_id=workspace.id,
        created_by_id=user.id,
        name=name,
    )
    scope.lane = lane.value
    scope.repository_ids_json = sorted(valid_ids)
    scope.filters_json = {
        "search": str(form.get("scope_filter_search", "")).strip(),
        "status": str(form.get("scope_filter_status", "")).strip(),
        "grade": str(form.get("scope_filter_grade", "")).strip(),
        "risk": str(form.get("scope_filter_risk", "")).strip(),
        "dependency": str(form.get("scope_filter_dependency", "")).strip(),
        "source_org": str(form.get("source_org", "")).strip(),
        "target_org": str(form.get("target_org", "")).strip(),
        "repository_count": len(valid_ids),
    }
    scope.updated_at = utcnow()
    db.add(scope)
    db.commit()
    db.refresh(scope)
    record_audit(
        db,
        action="repository_scope.save",
        resource_type="saved_repository_scope",
        resource_id=scope.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"name": name, "lane": lane.value, "repository_ids": valid_ids, "updated": bool(existing)},
    )
    flash(request, f"Saved scope '{scope.name}' with {len(valid_ids)} repository/repositories.", "success")
    return RedirectResponse(f"{lane_path(workspace.id, lane)}?scope={scope.id}", status_code=303)


@router.post("/workspaces/{workspace_id}/github/scopes/{scope_id}/delete")
async def delete_repository_scope(
    workspace_id: str,
    scope_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    scope = db.get(SavedRepositoryScope, scope_id)
    if not scope or scope.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Saved repository scope not found")
    lane = scope.lane
    name = scope.name
    db.delete(scope)
    db.commit()
    record_audit(
        db,
        action="repository_scope.delete",
        resource_type="saved_repository_scope",
        resource_id=scope_id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"name": name, "lane": lane},
    )
    flash(request, f"Saved scope '{name}' deleted. Repository inventory was not changed.", "success")
    return RedirectResponse(lane_path(workspace.id, lane), status_code=303)


@router.get("/workspaces/{workspace_id}/github/migrations", response_class=HTMLResponse)
@router.get("/workspaces/{workspace_id}/migrations", response_class=HTMLResponse)
def migrations_page(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    repos = db.scalars(select(RepositoryInventory).where(RepositoryInventory.workspace_id == workspace.id).order_by(RepositoryInventory.name)).all()
    sources = db.scalars(select(Connector).where(Connector.workspace_id == workspace.id, Connector.kind.in_([ConnectorKind.ghes, ConnectorKind.simulated_ghes]))).all()
    targets = db.scalars(select(Connector).where(Connector.workspace_id == workspace.id, Connector.kind.in_([ConnectorKind.ghec, ConnectorKind.simulated_ghec]))).all()
    runs = db.scalars(select(MigrationRun).where(MigrationRun.workspace_id == workspace.id).order_by(MigrationRun.created_at.desc())).all()
    source_orgs = sorted({repo.source_org for repo in repos})
    return html(
        request,
        db,
        "migrations.html",
        user,
        workspace=workspace,
        repositories=repos,
        sources=sources,
        targets=targets,
        runs=runs,
        source_orgs=source_orgs,
        methods=[MigrationMethod.gei, MigrationMethod.elm],
        modes=list(MigrationMode),
        pipeline_policies=list(PipelinePolicy),
        gei_runtime=gei_tooling_status(),
    )


@router.post("/workspaces/{workspace_id}/migrations")
async def create_migration(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    execution_intent = str(form.get("execution_intent", "queue")).strip().lower()
    if execution_intent not in {"plan", "queue"}:
        execution_intent = "queue"

    try:
        lane = MigrationLane(str(form.get("lane", MigrationLane.all.value)))
    except ValueError:
        lane = MigrationLane.all
    return_path = (
        f"/workspaces/{workspace.id}/github/with-pipelines"
        if lane == MigrationLane.with_pipelines
        else f"/workspaces/{workspace.id}/github/without-pipelines"
        if lane == MigrationLane.without_pipelines
        else f"/workspaces/{workspace.id}/migrations"
    )

    source = ensure_connector_in_workspace(db, workspace, str(form.get("source_connector_id")))
    target = ensure_connector_in_workspace(db, workspace, str(form.get("target_connector_id")))
    if source.kind not in (ConnectorKind.ghes, ConnectorKind.simulated_ghes) or target.kind not in (ConnectorKind.ghec, ConnectorKind.simulated_ghec):
        flash(request, "Choose a GHES source connector and a GHEC destination connector.", "error")
        return RedirectResponse(return_path, status_code=303)
    if source.kind == ConnectorKind.ghes and source.status != "connected":
        flash(request, "Test the GHES connector successfully before creating a migration wave.", "error")
        return RedirectResponse(return_path, status_code=303)
    if target.kind == ConnectorKind.ghec and target.status != "connected":
        flash(request, "Test the GHEC connector successfully before creating a migration wave.", "error")
        return RedirectResponse(return_path, status_code=303)

    source_org = str(form.get("source_org", "")).strip()
    target_org = str(form.get("target_org", "")).strip()
    selected_ids = [str(value) for value in form.getlist("repository_ids")]
    if not selected_ids or not source_org or not target_org:
        flash(request, "Select repositories and provide source and target organizations.", "error")
        return RedirectResponse(return_path, status_code=303)

    try:
        method = MigrationMethod(str(form.get("method", MigrationMethod.gei.value)))
        mode = MigrationMode(str(form.get("mode", MigrationMode.trial.value)))
        pipeline_policy = PipelinePolicy(str(form.get("pipeline_policy", PipelinePolicy.preserve_disable_actions.value)))
    except ValueError:
        flash(request, "The selected migration method, mode, or pipeline policy is invalid.", "error")
        return RedirectResponse(return_path, status_code=303)
    if method not in (MigrationMethod.gei, MigrationMethod.elm):
        flash(request, "Only GitHub Enterprise Importer and eligible Enterprise Live Migrations are supported.", "error")
        return RedirectResponse(return_path, status_code=303)

    org_name_pattern = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$")
    if not org_name_pattern.fullmatch(source_org) or not org_name_pattern.fullmatch(target_org):
        flash(request, "Source and destination organization names are not valid GitHub organization logins.", "error")
        return RedirectResponse(return_path, status_code=303)
    if method == MigrationMethod.elm and target.target_flavor != TargetFlavor.ghe_com:
        flash(request, "ELM is allowed only for a GHE.com destination with data residency. Use GEI for github.com.", "error")
        return RedirectResponse(return_path, status_code=303)

    try:
        requested_concurrency = int(form.get("concurrency", 3))
    except (TypeError, ValueError):
        requested_concurrency = 3
    concurrency_limit = 10 if method == MigrationMethod.elm else 5
    concurrency = max(1, min(requested_concurrency, concurrency_limit))
    lock_source = form.get("lock_source_at_cutover") == "on"
    if mode == MigrationMode.trial:
        lock_source = False
    if method == MigrationMethod.gei and mode == MigrationMode.production and not lock_source:
        flash(request, "Production GEI requires the official source-lock option because GEI has no delta synchronization.", "error")
        return RedirectResponse(return_path, status_code=303)
    acknowledged_manual_actions = form.get("acknowledged_manual_actions") == "on"
    implicit_simulation_acknowledgement = (
        mode == MigrationMode.trial
        and source.kind == ConnectorKind.simulated_ghes
        and target.kind == ConnectorKind.simulated_ghec
    )
    if not acknowledged_manual_actions and implicit_simulation_acknowledgement:
        # Preserve the pre-0.1.1 demo/test flow without weakening real connector
        # controls. Simulation runs cannot execute against GitHub or mutate source.
        acknowledged_manual_actions = True
    if not acknowledged_manual_actions:
        flash(request, "Acknowledge the documented manual workstreams and method limitations before queuing the wave.", "error")
        return RedirectResponse(return_path, status_code=303)

    selected: list[tuple[RepositoryInventory, str, dict[str, Any]]] = []
    skipped: list[dict[str, Any]] = []
    target_names: set[str] = set()
    valid_repo_name = re.compile(r"^[A-Za-z0-9._-]{1,100}$")
    for repository_id in selected_ids:
        repository = db.get(RepositoryInventory, repository_id)
        if not repository or repository.workspace_id != workspace.id or repository.source_org != source_org:
            skipped.append({"repository_id": repository_id, "reason": "Repository is outside the selected workspace/source organization"})
            continue
        if lane != MigrationLane.all and repository.pipeline_lane != lane.value:
            skipped.append({"repository_id": repository.id, "repository": repository.name, "reason": f"Repository is not in lane {lane.value}"})
            continue
        method_assessment = assess_repository(
            {column.name: getattr(repository, column.name) for column in RepositoryInventory.__table__.columns},
            method=method.value,
        )
        if method_assessment["blockers"]:
            skipped.append({
                "repository_id": repository.id,
                "repository": repository.name,
                "reason": "Repository has method-specific preflight blockers",
                "blockers": method_assessment["blockers"],
            })
            continue
        if (repository.target_state_json or {}).get("exists") is True:
            skipped.append({"repository_id": repository.id, "repository": repository.name, "reason": "Destination repository already exists"})
            continue
        target_name = str(form.get(f"target_name_{repository.id}", repository.target_name)).strip() or repository.name
        target_key = target_name.lower()
        if not valid_repo_name.fullmatch(target_name) or target_name.lower().endswith(".git") or target_key in target_names:
            skipped.append({"repository_id": repository.id, "repository": repository.name, "reason": "Destination name is invalid or duplicated in this run"})
            continue
        target_names.add(target_key)
        selected.append((repository, target_name, method_assessment))

    if not selected:
        flash(request, "No repository passed server-side preflight. Review skipped mappings and refresh discovery evidence.", "error")
        return RedirectResponse(return_path, status_code=303)

    manual_actions = list(METHOD_POLICY["known_non_migrated_or_separate_workstreams"])
    selected_evidence = [
        {
            "repository_id": repository.id,
            "source_repo": repository.name,
            "target_repo": target_name,
            "method_grade": assessment["grade"],
            "method_score": assessment["score"],
            "warning_codes": [item["code"] for item in assessment["warnings"]],
            "pipeline_lane": repository.pipeline_lane,
            "source_sha": repository.last_commit_sha,
            "target_probe": repository.target_state_json,
        }
        for repository, target_name, assessment in selected
    ]
    preflight = {
        "policy_reference_date": METHOD_POLICY["reference_date"],
        "method": method.value,
        "mode": mode.value,
        "lane": lane.value,
        "source_connector": {"id": source.id, "kind": source.kind.value, "status": source.status, "api_url": source.api_url},
        "target_connector": {"id": target.id, "kind": target.kind.value, "status": target.status, "flavor": target.target_flavor.value, "api_url": target.api_url},
        "source_org": source_org,
        "target_org": target_org,
        "requested_count": len(selected_ids),
        "accepted_count": len(selected),
        "skipped_count": len(skipped),
        "requested_concurrency": requested_concurrency,
        "effective_concurrency": concurrency,
        "concurrency_limit": concurrency_limit,
        "lock_source_at_cutover": lock_source,
        "manual_actions_acknowledged": acknowledged_manual_actions,
        "manual_action_categories": manual_actions,
        "repositories": selected_evidence,
        "skipped": skipped,
        "result": "pass_with_manual_workstreams" if any(item[2]["warnings"] for item in selected) else "pass",
    }

    run = MigrationRun(
        workspace_id=workspace.id,
        created_by_id=user.id,
        source_connector_id=source.id,
        target_connector_id=target.id,
        source_org=source_org,
        target_org=target_org,
        method=method,
        mode=mode,
        pipeline_policy=pipeline_policy,
        lane=lane,
        selection_json={
            "requested_repository_ids": selected_ids,
            "selected_count": len(selected),
            "skipped": skipped,
            "lane": lane.value,
        },
        preflight_json=preflight,
        status=MigrationStatus.planned,
        lock_source_at_cutover=lock_source,
        acknowledged_manual_actions=acknowledged_manual_actions,
        storage_mode=str(form.get("storage_mode", "github_owned")),
        skip_releases=form.get("skip_releases") == "on",
        concurrency=concurrency,
        notes=str(form.get("notes", "")).strip() or None,
    )
    db.add(run)
    db.flush()
    for repository, target_name, _assessment in selected:
        db.add(
            RepoMigration(
                migration_run_id=run.id,
                repository_inventory_id=repository.id,
                source_repo=repository.name,
                target_repo=target_name,
                source_sha_at_start=repository.last_commit_sha,
            )
        )

    profile = dict(workspace.migration_profile_json or {})
    profile.update({
        "source_connector_id": source.id,
        "target_connector_id": target.id,
        "source_org": source_org,
        "target_org": target_org,
        "default_method": method.value,
        "default_concurrency": concurrency,
    })
    workspace.migration_profile_json = profile
    workspace.default_source_connector_id = source.id
    workspace.default_target_connector_id = target.id
    workspace.source_org = source_org
    workspace.target_org = target_org
    db.add_all([run, workspace])
    db.commit()
    db.refresh(run)

    skipped_note = f" {len(skipped)} requested mapping(s) were rejected by preflight; review the run evidence." if skipped else ""
    if execution_intent == "plan":
        record_audit(
            db,
            action="migration.plan",
            resource_type="migration_run",
            resource_id=run.id,
            workspace_id=workspace.id,
            user_id=user.id,
            details={"method": method.value, "mode": mode.value, "lane": lane.value, "preflight": preflight},
        )
        flash(request, f"Migration plan {run.id} created without starting GitHub execution.{skipped_note}", "success")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)

    run.status = MigrationStatus.queued
    db.add(run)
    db.commit()
    try:
        job = job_for(db, user, workspace.id, "migration", {"migration_run_id": run.id, "retry_failed_only": False})
    except Exception:
        run.status = MigrationStatus.failed
        run.finished_at = utcnow()
        db.add(run)
        db.commit()
        raise
    record_audit(
        db,
        action="migration.start",
        resource_type="migration_run",
        resource_id=run.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"job_id": job.id, "method": method.value, "mode": mode.value, "lane": lane.value, "preflight": preflight},
    )
    flash(request, f"Migration run {run.id} queued. Cleanup token: {run.cleanup_token}.{skipped_note}", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)


@router.get("/workspaces/{workspace_id}/migrations/{run_id}", response_class=HTMLResponse)
def migration_detail(workspace_id: str, run_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    db.refresh(run, attribute_names=["repositories"])
    validations = db.scalars(select(ValidationRun).where(ValidationRun.migration_run_id == run.id).order_by(ValidationRun.created_at.desc())).all()
    purges = db.scalars(select(PurgeRun).where(PurgeRun.migration_run_id == run.id).order_by(PurgeRun.created_at.desc())).all()
    jobs = db.scalars(select(Job).where(Job.workspace_id == workspace.id, Job.payload_json["migration_run_id"].as_string() == run.id).order_by(Job.created_at.desc())).all() if not settings.database_url.startswith("sqlite") else db.scalars(select(Job).where(Job.workspace_id == workspace.id).order_by(Job.created_at.desc()).limit(20)).all()
    return html(request, db, "migration_detail.html", user, workspace=workspace, run=run, validations=validations, purges=purges, jobs=jobs)


@router.post("/workspaces/{workspace_id}/migrations/{run_id}/queue")
async def queue_planned_migration(
    workspace_id: str,
    run_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    if run.status != MigrationStatus.planned:
        flash(request, "Only a planned migration can be queued from this control.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if str(form.get("confirmation", "")).strip() != f"QUEUE {run.id}":
        flash(request, f"Enter exactly QUEUE {run.id} to start this planned wave.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    source = ensure_connector_in_workspace(db, workspace, run.source_connector_id)
    target = ensure_connector_in_workspace(db, workspace, run.target_connector_id)
    if source.kind == ConnectorKind.ghes and source.status != "connected":
        flash(request, "The GHES connector is no longer in a tested connected state. Test it again before queueing.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if target.kind == ConnectorKind.ghec and target.status != "connected":
        flash(request, "The GHEC connector is no longer in a tested connected state. Test it again before queueing.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    db.refresh(run, attribute_names=["repositories"])
    if not run.repositories:
        flash(request, "The plan contains no repository mappings.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    conflict_repositories = [
        item.repository.name
        for item in run.repositories
        if (item.repository.target_state_json or {}).get("exists") is True
    ]
    if conflict_repositories:
        flash(request, "A selected destination is now recorded as existing. Refresh discovery and create a new plan: " + ", ".join(conflict_repositories[:10]), "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    run.status = MigrationStatus.queued
    run.preflight_json = {
        **(run.preflight_json or {}),
        "queued_at": utcnow().isoformat(),
        "queued_by": user.id,
        "queue_confirmation": True,
    }
    db.add(run)
    db.commit()
    try:
        job = job_for(db, user, workspace.id, "migration", {"migration_run_id": run.id, "retry_failed_only": False})
    except Exception:
        run.status = MigrationStatus.failed
        run.finished_at = utcnow()
        db.add(run)
        db.commit()
        raise
    record_audit(
        db,
        action="migration.queue_planned",
        resource_type="migration_run",
        resource_id=run.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"job_id": job.id},
    )
    flash(request, f"Planned migration {run.id} queued as job {job.id}.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)


@router.post("/workspaces/{workspace_id}/migrations/{run_id}/retry")
async def retry_failed(workspace_id: str, run_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    db.refresh(run, attribute_names=["repositories"])
    failed = [item for item in run.repositories if item.status == RepoMigrationStatus.failed]
    if not failed:
        flash(request, "This migration run has no failed repository to retry.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if active_run_jobs(db, workspace.id, run.id, {"migration", "cutover"}):
        flash(request, "A migration or cutover job is already active for this run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    run.status = MigrationStatus.queued
    run.finished_at = None
    db.add(run)
    db.commit()
    try:
        job = job_for(db, user, workspace.id, "migration", {"migration_run_id": run.id, "retry_failed_only": True})
    except Exception:
        run.status = MigrationStatus.failed
        db.add(run)
        db.commit()
        raise
    record_audit(db, action="migration.retry_failed", resource_type="migration_run", resource_id=run.id, workspace_id=workspace.id, user_id=user.id, details={"job_id": job.id, "failed_repository_ids": [item.id for item in failed]})
    flash(request, f"Retry job {job.id} queued for {len(failed)} failed repository/repositories.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)


@router.post("/workspaces/{workspace_id}/migrations/{run_id}/cutover")
async def cutover(workspace_id: str, run_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    if run.method not in (MigrationMethod.elm, MigrationMethod.simulation):
        flash(request, "GEI has no post-migration delta cutover. Production GEI source locking must occur during the official migration command.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    db.refresh(run, attribute_names=["repositories"])
    if run.status != MigrationStatus.ready_for_cutover or not run.repositories or any(
        item.status != RepoMigrationStatus.ready_for_cutover for item in run.repositories
    ):
        flash(request, "Cutover is blocked until the run and every selected repository report ready for cutover.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if active_run_jobs(db, workspace.id, run.id, {"migration", "cutover"}):
        flash(request, "A migration or cutover job is already active for this run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    confirmation = str(form.get("confirmation", ""))
    if confirmation != f"CUTOVER {run.id}":
        flash(request, f"Enter exactly CUTOVER {run.id} to authorize source read-only cutover.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    job = job_for(db, user, workspace.id, "cutover", {"migration_run_id": run.id})
    record_audit(db, action="migration.cutover", resource_type="migration_run", resource_id=run.id, workspace_id=workspace.id, user_id=user.id, details={"job_id": job.id})
    flash(request, f"Cutover job {job.id} queued. For ELM, the official cutover archives the source repository and completes synchronization.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)


@router.post("/workspaces/{workspace_id}/migrations/{run_id}/validate")
async def start_validation(workspace_id: str, run_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    if run.status not in {MigrationStatus.completed, MigrationStatus.completed_with_warnings}:
        flash(request, "Final source-target validation is available only after migration or ELM cutover has completed.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if active_run_jobs(db, workspace.id, run.id, {"migration", "cutover", "validation"}):
        flash(request, "An execution or validation job is already active for this migration run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    validation = ValidationRun(workspace_id=workspace.id, migration_run_id=run.id, created_by_id=user.id)
    db.add(validation)
    db.commit()
    db.refresh(validation)
    job = job_for(db, user, workspace.id, "validation", {"validation_run_id": validation.id, "migration_run_id": run.id})
    record_audit(db, action="validation.start", resource_type="validation_run", resource_id=validation.id, workspace_id=workspace.id, user_id=user.id, details={"job_id": job.id, "migration_run_id": run.id})
    flash(request, f"Validation job {job.id} queued.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)


@router.post("/workspaces/{workspace_id}/migrations/{run_id}/purge")
async def start_purge(workspace_id: str, run_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    if run.mode != MigrationMode.trial:
        flash(request, "Target purge is restricted to trial migration runs.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    target = db.get(Connector, run.target_connector_id)
    if not target or target.workspace_id != workspace.id:
        flash(request, "The destination connector for this run is unavailable.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if target.kind == ConnectorKind.ghec and target.status != "connected":
        flash(request, "Retest the destination connector before running target purge.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    db.refresh(run, attribute_names=["repositories"])
    selected_ids = [str(value) for value in form.getlist("repo_migration_ids")]
    valid_ids = [item.id for item in run.repositories if item.id in selected_ids]
    if not valid_ids:
        flash(request, "Select at least one destination repository from this exact trial run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    cleanup_token = str(form.get("cleanup_token", "")).strip()
    dry_run = form.get("dry_run") == "on"
    if not dry_run and user.role != UserRole.admin:
        flash(request, "Only an administrator can execute destructive target purge. Workspace users may run the dry-run preview.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if cleanup_token != run.cleanup_token:
        flash(request, "Cleanup token does not match this migration run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    if not dry_run and str(form.get("confirmation", "")) != f"PURGE {run.id}":
        flash(request, f"Enter exactly PURGE {run.id} for destructive cleanup.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)
    purge = PurgeRun(
        workspace_id=workspace.id,
        migration_run_id=run.id,
        created_by_id=user.id,
        cleanup_token_used=cleanup_token,
        dry_run=dry_run,
        scope_json={"repo_migration_ids": valid_ids},
    )
    db.add(purge)
    db.commit()
    db.refresh(purge)
    job = job_for(db, user, workspace.id, "purge", {"purge_run_id": purge.id, "migration_run_id": run.id})
    record_audit(db, action="purge.start", resource_type="purge_run", resource_id=purge.id, workspace_id=workspace.id, user_id=user.id, details={"job_id": job.id, "dry_run": dry_run, "migration_run_id": run.id})
    flash(request, f"{'Dry-run' if dry_run else 'Destructive'} purge job {job.id} queued. The source will not be touched.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/migrations/{run.id}", status_code=303)


@router.get("/workspaces/{workspace_id}/jobs", response_class=HTMLResponse)
def jobs_page(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    jobs = db.scalars(select(Job).where(Job.workspace_id == workspace.id).order_by(Job.created_at.desc()).limit(200)).all()
    return html(request, db, "jobs.html", user, workspace=workspace, jobs=jobs)


@router.get("/api/jobs/{job_id}", response_class=JSONResponse)
def job_status(job_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> dict[str, Any]:
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    if job.workspace_id:
        accessible_workspace(job.workspace_id, user, db)
    elif user.role != UserRole.admin:
        raise HTTPException(status_code=403, detail="Administrator access required")
    return {
        "id": job.id,
        "kind": job.kind,
        "status": job.status.value,
        "progress": job.progress,
        "current_step": job.current_step,
        "error": job.error_message,
        "error_message": job.error_message,
        "result": job.result_json,
        "created_at": job.created_at,
        "started_at": job.started_at,
        "finished_at": job.finished_at,
    }


@router.get("/workspaces/{workspace_id}/github/pipeline-owner-handoff", response_class=HTMLResponse)
def pipeline_owner_handoff_page(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    records = pipeline_owner_handoff_data(db, workspace.id)
    summary = {
        "repositories": len(records),
        "high_risk": sum(1 for item in records if float(item["pipeline"]["risk_score"] or 0) >= 70),
        "secret_references": sum(len(item["pipeline"]["secret_names"]) for item in records),
        "self_hosted_dependencies": sum(len(item["pipeline"]["runners"]) for item in records),
        "security_findings": sum(len(item["pipeline"]["hardcoded_credential_findings"]) for item in records),
    }
    return html(request, db, "pipeline_owner_handoff.html", user, workspace=workspace, records=records, summary=summary)


@router.get("/workspaces/{workspace_id}/reports", response_class=HTMLResponse)
def reports_page(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    runs = db.scalars(select(MigrationRun).where(MigrationRun.workspace_id == workspace.id).order_by(MigrationRun.created_at.desc())).all()
    validations = db.scalars(select(ValidationRun).where(ValidationRun.workspace_id == workspace.id).order_by(ValidationRun.created_at.desc())).all()
    return html(request, db, "reports.html", user, workspace=workspace, runs=runs, validations=validations)


@router.get("/workspaces/{workspace_id}/reports/discovery.csv")
def download_discovery_report(workspace_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    content = discovery_csv(db, workspace.id)
    return Response(content, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{workspace.slug}-discovery.csv"'})


@router.get("/workspaces/{workspace_id}/reports/pipeline.csv")
def download_pipeline_report(workspace_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    content = pipeline_csv(db, workspace.id)
    return Response(content, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{workspace.slug}-pipeline-remediation.csv"'})


@router.get("/workspaces/{workspace_id}/reports/pipeline-owner.md")
def download_pipeline_owner_markdown(workspace_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    content = pipeline_owner_handoff_markdown(db, workspace.id)
    return Response(content, media_type="text/markdown", headers={"Content-Disposition": f'attachment; filename="{workspace.slug}-pipeline-owner-handoff.md"'})


@router.get("/workspaces/{workspace_id}/reports/pipeline-owner.json")
def download_pipeline_owner_json(workspace_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    content = pipeline_owner_handoff_json(db, workspace.id)
    return Response(content, media_type="application/json", headers={"Content-Disposition": f'attachment; filename="{workspace.slug}-pipeline-owner-handoff.json"'})


@router.get("/workspaces/{workspace_id}/reports/migrations/{run_id}.csv")
def download_migration_report(workspace_id: str, run_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    content = migration_mapping_csv(db, run.id)
    return Response(content, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{run.id}-mapping.csv"'})


@router.get("/workspaces/{workspace_id}/reports/validations/{validation_id}.json")
def download_validation_report(workspace_id: str, validation_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    validation = db.get(ValidationRun, validation_id)
    if not validation or validation.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Validation run not found")
    content = validation_json(db, validation.id)
    return Response(content, media_type="application/json", headers={"Content-Disposition": f'attachment; filename="{validation.id}.json"'})


@router.get("/workspaces/{workspace_id}/reports/onepassword.md")
def download_onepassword_report(workspace_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    content = onepassword_runbook_markdown(db, workspace.id)
    return Response(content, media_type="text/markdown", headers={"Content-Disposition": f'attachment; filename="{workspace.slug}-onepassword-remediation.md"'})


@router.get("/workspaces/{workspace_id}/reports/migrations/{run_id}.json")
def download_migration_json(workspace_id: str, run_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    return Response(migration_summary_json(db, run.id), media_type="application/json", headers={"Content-Disposition": f'attachment; filename="{run.id}-summary.json"'})


@router.get("/workspaces/{workspace_id}/reports/migrations/{run_id}.zip")
def download_report_bundle(workspace_id: str, run_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Migration run not found")
    content = report_bundle_zip(db, workspace.id, run.id)
    return Response(content, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{run.id}-evidence-bundle.zip"'})


@router.get("/workspaces/{workspace_id}/jobs/{job_id}/log")
def download_job_log(workspace_id: str, job_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)) -> Response:
    workspace = accessible_workspace(workspace_id, user, db)
    job = db.get(Job, job_id)
    if not job or job.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Job not found")
    if not job.log_path:
        raise HTTPException(status_code=404, detail="Job log is not available")
    path = Path(job.log_path).resolve()
    allowed = settings.logs_dir.resolve()
    if allowed not in path.parents or not path.exists():
        raise HTTPException(status_code=404, detail="Job log is not available")
    return FileResponse(path, media_type="application/x-ndjson", filename=f"{job.id}.jsonl")


@router.get("/workspaces/{workspace_id}/audit", response_class=HTMLResponse)
def audit_page(workspace_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    entries = db.scalars(select(AuditLog).where(AuditLog.workspace_id == workspace.id).order_by(AuditLog.created_at.desc()).limit(500)).all()
    return html(request, db, "audit.html", user, workspace=workspace, entries=entries)


@router.get("/admin/branding", response_class=HTMLResponse)
def branding_page(request: Request, db: Session = Depends(get_db), user: User = Depends(admin_user)) -> HTMLResponse:
    return html(request, db, "admin_branding.html", user, brand=branding(db))


@router.post("/admin/branding")
async def update_branding(request: Request, db: Session = Depends(get_db), user: User = Depends(admin_user)) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    row = branding(db)

    product_name = str(form.get("product_name", row.product_name)).strip()[:120]
    tagline = str(form.get("tagline", row.tagline)).strip()[:255]
    version = str(form.get("version", row.version)).strip()[:40]
    build_number = str(form.get("build_number", row.build_number)).strip()[:80]
    company_name = str(form.get("company_name", row.company_name)).strip()[:120]
    edition_label = str(form.get("edition_label", row.edition_label or "")).strip()[:80]
    support_email = str(form.get("support_email", row.support_email or "")).strip()[:255]
    if not product_name or not tagline or not version or not build_number or not company_name:
        flash(request, "Product name, tagline, version, build number, and company name are required.", "error")
        return RedirectResponse("/admin/branding", status_code=303)

    existing_theme = normalized_theme(row.theme_json)
    next_theme = {
        "primary": safe_color(form.get("theme_primary"), existing_theme["primary"]),
        "accent": safe_color(form.get("theme_accent"), existing_theme["accent"]),
        "gradient_from": safe_color(form.get("theme_gradient_from"), existing_theme["gradient_from"]),
        "gradient_to": safe_color(form.get("theme_gradient_to"), existing_theme["gradient_to"]),
        "border": safe_color(form.get("theme_border"), existing_theme["border"]),
        "button_bg": safe_color(form.get("theme_button_bg"), existing_theme["button_bg"]),
        "button_border": safe_color(form.get("theme_button_border"), existing_theme["button_border"]),
        "button_text": safe_color(form.get("theme_button_text"), existing_theme["button_text"]),
    }

    upload = form.get("logo_file")
    external_logo = str(form.get("logo_url", "")).strip()
    try:
        uploaded_url = await persist_logo(upload, settings) if getattr(upload, "filename", None) else None
        if uploaded_url:
            row.logo_url = uploaded_url
        elif external_logo:
            row.logo_url = safe_logo_url(external_logo)
        elif row.logo_url != "/branding/logo":
            row.logo_url = None
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse("/admin/branding", status_code=303)

    row.product_name = product_name
    row.tagline = tagline
    row.version = version
    row.build_number = build_number
    row.company_name = company_name
    row.edition_label = edition_label or None
    row.support_email = support_email or None
    row.theme_json = next_theme
    db.add(row)
    db.commit()
    record_audit(
        db,
        action="branding.update",
        resource_type="branding",
        resource_id="1",
        user_id=user.id,
        details={
            "product_name": row.product_name,
            "version": row.version,
            "build_number": row.build_number,
            "edition_label": row.edition_label,
            "logo": "custom" if row.logo_url else "default",
        },
    )
    flash(request, "Branding, logo, colors, version, and build number were updated.", "success")
    return RedirectResponse("/admin/branding", status_code=303)


@router.post("/admin/branding/reset-logo")
async def reset_branding_logo(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    delete_logo(settings)
    row = branding(db)
    row.logo_url = None
    db.add(row)
    db.commit()
    record_audit(
        db,
        action="branding.logo.reset",
        resource_type="branding",
        resource_id="1",
        user_id=user.id,
    )
    flash(request, "The default ForgeBridge logo and favicon are active.", "success")
    return RedirectResponse("/admin/branding", status_code=303)


@router.get("/admin/users", response_class=HTMLResponse)
def users_page(request: Request, db: Session = Depends(get_db), user: User = Depends(admin_user)) -> HTMLResponse:
    users = db.scalars(select(User).order_by(User.created_at.desc())).all()
    return html(request, db, "admin_users.html", user, users=users, roles=list(UserRole))


@router.post("/admin/users")
async def create_user(request: Request, db: Session = Depends(get_db), user: User = Depends(admin_user)) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    username = str(form.get("username", "")).strip()
    email = str(form.get("email", "")).strip()
    password = str(form.get("password", ""))
    try:
        role = UserRole(str(form.get("role", UserRole.user.value)))
    except ValueError:
        role = UserRole.user
    if not username or not email or len(password) < 12:
        flash(request, "Username, email, and a password of at least 12 characters are required.", "error")
        return RedirectResponse("/admin/users", status_code=303)
    if db.scalar(select(User).where((User.username == username) | (User.email == email))):
        flash(request, "Username or email already exists.", "error")
        return RedirectResponse("/admin/users", status_code=303)
    new_user = User(username=username, email=email, password_hash=hash_password(password), role=role)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    record_audit(db, action="user.create", resource_type="user", resource_id=new_user.id, user_id=user.id, details={"role": role.value})
    flash(request, "User created.", "success")
    return RedirectResponse("/admin/users", status_code=303)


@router.post("/admin/users/{user_id}/update")
async def update_user(
    user_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    try:
        requested_role = UserRole(str(form.get("role", target.role.value)))
    except ValueError:
        flash(request, "Choose a supported user role.", "error")
        return RedirectResponse("/admin/users", status_code=303)
    requested_active = form.get("active") == "on"
    email = str(form.get("email", target.email)).strip()
    new_password = str(form.get("new_password", ""))

    if target.id == user.id and (not requested_active or requested_role != UserRole.admin):
        flash(request, "You cannot disable or demote your own administrator account.", "error")
        return RedirectResponse("/admin/users", status_code=303)
    removing_active_admin = (
        target.role == UserRole.admin
        and target.active
        and (requested_role != UserRole.admin or not requested_active)
    )
    if removing_active_admin:
        active_admins = db.scalar(
            select(func.count())
            .select_from(User)
            .where(User.role == UserRole.admin, User.active.is_(True))
        ) or 0
        if active_admins <= 1:
            flash(request, "At least one active administrator must remain.", "error")
            return RedirectResponse("/admin/users", status_code=303)
    if not email:
        flash(request, "Email is required.", "error")
        return RedirectResponse("/admin/users", status_code=303)
    duplicate = db.scalar(select(User).where(User.email == email, User.id != target.id))
    if duplicate:
        flash(request, "Another user already uses that email address.", "error")
        return RedirectResponse("/admin/users", status_code=303)
    if new_password and len(new_password) < 12:
        flash(request, "A replacement password must contain at least 12 characters.", "error")
        return RedirectResponse("/admin/users", status_code=303)

    changes = {
        "old_role": target.role.value,
        "new_role": requested_role.value,
        "old_active": target.active,
        "new_active": requested_active,
        "email_changed": target.email != email,
        "password_reset": bool(new_password),
    }
    target.role = requested_role
    target.active = requested_active
    target.email = email
    if new_password:
        target.password_hash = hash_password(new_password)
    db.add(target)
    db.commit()
    record_audit(
        db,
        action="user.update",
        resource_type="user",
        resource_id=target.id,
        user_id=user.id,
        details=changes,
    )
    flash(request, f"User {target.username} updated.", "success")
    return RedirectResponse("/admin/users", status_code=303)


@router.post("/workspaces/{workspace_id}/profile")
async def update_workspace_profile(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    profile = dict(workspace.migration_profile_json or {})
    connector_rules = {
        "source_connector_id": (ConnectorKind.ghes, ConnectorKind.simulated_ghes),
        "target_connector_id": (ConnectorKind.ghec, ConnectorKind.simulated_ghec),
    }
    for key, allowed_kinds in connector_rules.items():
        value = str(form.get(key, "")).strip()
        if value:
            connector = ensure_connector_in_workspace(db, workspace, value)
            if connector.kind not in allowed_kinds:
                expected = "GHES source" if key == "source_connector_id" else "GHEC destination"
                flash(request, f"The selected {expected} connector has an incompatible connector type.", "error")
                return RedirectResponse(f"/workspaces/{workspace.id}", status_code=303)
            profile[key] = value
        else:
            profile.pop(key, None)
    for key in ("source_org", "target_org"):
        value = str(form.get(key, "")).strip()
        if value:
            profile[key] = value
        else:
            profile.pop(key, None)
    method = str(form.get("default_method", "gei"))
    profile["default_method"] = method if method in {"gei", "elm"} else "gei"
    try:
        profile["default_concurrency"] = max(1, min(10, int(form.get("default_concurrency", 3))))
    except (TypeError, ValueError):
        profile["default_concurrency"] = 3
    workspace.migration_profile_json = profile
    workspace.default_source_connector_id = profile.get("source_connector_id")
    workspace.default_target_connector_id = profile.get("target_connector_id")
    workspace.source_org = profile.get("source_org")
    workspace.target_org = profile.get("target_org")
    db.add(workspace)
    db.commit()
    record_audit(
        db,
        action="workspace.profile.update",
        resource_type="workspace",
        resource_id=workspace.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"profile": profile},
    )
    flash(request, "Workspace migration profile updated.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}", status_code=303)


@router.get("/workspaces/{workspace_id}/github/validation", response_class=HTMLResponse)
def github_validation_page(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    repositories = db.scalars(
        select(RepositoryInventory)
        .where(RepositoryInventory.workspace_id == workspace.id)
        .order_by(RepositoryInventory.source_org, RepositoryInventory.name)
    ).all()
    sources = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghes, ConnectorKind.simulated_ghes]),
        )
    ).all()
    targets = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghec, ConnectorKind.simulated_ghec]),
        )
    ).all()
    runs = db.scalars(
        select(MigrationRun).where(MigrationRun.workspace_id == workspace.id).order_by(MigrationRun.created_at.desc())
    ).all()
    validations = db.scalars(
        select(ValidationRun).where(ValidationRun.workspace_id == workspace.id).order_by(ValidationRun.created_at.desc())
    ).all()
    return html(
        request,
        db,
        "github_validation.html",
        user,
        workspace=workspace,
        repositories=repositories,
        sources=sources,
        targets=targets,
        runs=runs,
        validations=validations,
        profile=workspace.migration_profile_json or {},
    )


@router.post("/workspaces/{workspace_id}/github/validation")
async def start_workspace_validation(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    source = ensure_connector_in_workspace(db, workspace, str(form.get("source_connector_id")))
    target = ensure_connector_in_workspace(db, workspace, str(form.get("target_connector_id")))
    if source.kind not in (ConnectorKind.ghes, ConnectorKind.simulated_ghes) or target.kind not in (ConnectorKind.ghec, ConnectorKind.simulated_ghec):
        flash(request, "Validation requires a GHES source connector and a GHEC destination connector.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/validation", status_code=303)
    source_org = str(form.get("source_org", "")).strip()
    target_org = str(form.get("target_org", "")).strip()
    repo_ids = [str(value) for value in form.getlist("repository_ids")]
    try:
        lane = MigrationLane(str(form.get("lane", "all")))
    except ValueError:
        lane = MigrationLane.all
    valid_ids: list[str] = []
    target_names: dict[str, str] = {}
    for repo_id in repo_ids:
        repository = db.get(RepositoryInventory, repo_id)
        if not repository or repository.workspace_id != workspace.id or repository.source_org != source_org:
            continue
        if lane != MigrationLane.all and repository.pipeline_lane != lane.value:
            continue
        valid_ids.append(repository.id)
        target_names[repository.id] = str(form.get(f"target_name_{repository.id}", repository.target_name)).strip() or repository.name
    if not source_org or not target_org or not valid_ids:
        flash(request, "Choose source and target organizations and at least one valid repository.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/validation", status_code=303)
    validation = ValidationRun(
        workspace_id=workspace.id,
        migration_run_id=None,
        created_by_id=user.id,
        source_connector_id=source.id,
        target_connector_id=target.id,
        source_org=source_org,
        target_org=target_org,
        lane=lane,
        scope_json={
            "repository_ids": valid_ids,
            "target_names": target_names,
            "method": str(form.get("method", "gei")),
        },
    )
    db.add(validation)
    db.commit()
    db.refresh(validation)
    job = job_for(db, user, workspace.id, "validation", {"validation_run_id": validation.id})
    record_audit(
        db,
        action="validation.workspace.start",
        resource_type="validation_run",
        resource_id=validation.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"job_id": job.id, "repositories": valid_ids, "source_org": source_org, "target_org": target_org},
    )
    flash(request, f"Repository validation queued as {job.id}.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/jobs/{job.id}", status_code=303)


@router.get("/workspaces/{workspace_id}/github/target-purge", response_class=HTMLResponse)
@router.get("/workspaces/{workspace_id}/github/purge", response_class=HTMLResponse)
def github_purge_page(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    runs = db.scalars(
        select(MigrationRun)
        .where(MigrationRun.workspace_id == workspace.id, MigrationRun.mode == MigrationMode.trial)
        .order_by(MigrationRun.created_at.desc())
    ).all()
    for run in runs:
        db.refresh(run, attribute_names=["repositories"])
    purges = db.scalars(
        select(PurgeRun).where(PurgeRun.workspace_id == workspace.id).order_by(PurgeRun.created_at.desc())
    ).all()
    return html(request, db, "github_purge.html", user, workspace=workspace, runs=runs, purges=purges)


@router.post("/workspaces/{workspace_id}/github/target-purge")
@router.post("/workspaces/{workspace_id}/github/purge")
async def start_workspace_purge(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    run = db.get(MigrationRun, str(form.get("migration_run_id", "")))
    if not run or run.workspace_id != workspace.id or run.mode != MigrationMode.trial:
        flash(request, "Target purge is available only for a ForgeBridge trial migration run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/purge", status_code=303)
    db.refresh(run, attribute_names=["repositories"])
    selected_ids = [str(value) for value in form.getlist("repo_migration_ids")]
    valid_ids = [item.id for item in run.repositories if item.id in selected_ids]
    if not valid_ids:
        flash(request, "Select at least one repository that belongs to this trial migration run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/purge", status_code=303)
    target = db.get(Connector, run.target_connector_id)
    if not target or target.workspace_id != workspace.id:
        flash(request, "The destination connector for this run is unavailable.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/purge", status_code=303)
    if target.kind == ConnectorKind.ghec and target.status != "connected":
        flash(request, "Retest the destination connector before running target purge.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/purge", status_code=303)
    cleanup_token = str(form.get("cleanup_token", "")).strip()
    dry_run = form.get("dry_run") == "on"
    if not dry_run and user.role != UserRole.admin:
        flash(request, "Only an administrator can execute destructive target purge. Workspace users may run the dry-run preview.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/purge", status_code=303)
    if cleanup_token != run.cleanup_token:
        flash(request, "Cleanup token does not match the selected migration run.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/purge", status_code=303)
    if not dry_run and str(form.get("confirmation", "")) != f"PURGE {run.id}":
        flash(request, f"Enter exactly PURGE {run.id} for destructive target cleanup.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/purge", status_code=303)
    purge = PurgeRun(
        workspace_id=workspace.id,
        migration_run_id=run.id,
        created_by_id=user.id,
        cleanup_token_used=cleanup_token,
        dry_run=dry_run,
        scope_json={"repo_migration_ids": valid_ids},
    )
    db.add(purge)
    db.commit()
    db.refresh(purge)
    job = job_for(db, user, workspace.id, "purge", {"purge_run_id": purge.id, "migration_run_id": run.id})
    record_audit(
        db,
        action="purge.workspace.start",
        resource_type="purge_run",
        resource_id=purge.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"job_id": job.id, "dry_run": dry_run, "repo_migration_ids": valid_ids},
    )
    flash(request, f"{'Dry-run' if dry_run else 'Destructive'} target purge queued as {job.id}; source repositories are outside the purge scope.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/jobs/{job.id}", status_code=303)


@router.get("/workspaces/{workspace_id}/github/source-read-only", response_class=HTMLResponse)
def github_source_read_only_page(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    repositories = db.scalars(
        select(RepositoryInventory)
        .where(RepositoryInventory.workspace_id == workspace.id)
        .order_by(RepositoryInventory.source_org, RepositoryInventory.name)
    ).all()
    sources = db.scalars(
        select(Connector).where(
            Connector.workspace_id == workspace.id,
            Connector.kind.in_([ConnectorKind.ghes, ConnectorKind.simulated_ghes]),
        )
    ).all()
    freezes = db.scalars(
        select(SourceFreezeRun).where(SourceFreezeRun.workspace_id == workspace.id).order_by(SourceFreezeRun.created_at.desc())
    ).all()
    profile = workspace.migration_profile_json or {}
    eligibility: dict[str, dict[str, Any]] = {}
    source_connector_id = str(profile.get("source_connector_id") or "")
    source_org = str(profile.get("source_org") or "")
    if source_connector_id and source_org:
        profile_source = db.get(Connector, source_connector_id)
        relevant = [item for item in repositories if item.source_org == source_org]
        if profile_source and profile_source.workspace_id == workspace.id:
            if profile_source.kind == ConnectorKind.simulated_ghes:
                eligibility = {
                    item.id: {"eligible": True, "reason": "Simulation connector"}
                    for item in relevant
                }
            elif profile_source.kind == ConnectorKind.ghes:
                approved, blockers = source_freeze_evidence(
                    db,
                    workspace_id=workspace.id,
                    source_connector_id=profile_source.id,
                    source_org=source_org,
                    repository_ids=[item.id for item in relevant],
                )
                eligibility = {
                    item.id: (
                        {"eligible": True, **approved[item.id]}
                        if item.id in approved
                        else {"eligible": False, "reason": blockers.get(item.id, "Not eligible")}
                    )
                    for item in relevant
                }
    return html(
        request,
        db,
        "github_source_read_only.html",
        user,
        workspace=workspace,
        repositories=repositories,
        sources=sources,
        freezes=freezes,
        profile=profile,
        freeze_eligibility=eligibility,
    )


@router.post("/workspaces/{workspace_id}/github/source-read-only")
async def start_source_read_only(
    workspace_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    source = ensure_connector_in_workspace(db, workspace, str(form.get("source_connector_id")))
    if source.kind not in (ConnectorKind.ghes, ConnectorKind.simulated_ghes):
        flash(request, "Choose a GHES source connector.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/source-read-only", status_code=303)
    source_org = str(form.get("source_org", "")).strip()
    repo_ids = [str(value) for value in form.getlist("repository_ids")]
    valid_ids = []
    for repo_id in repo_ids:
        repository = db.get(RepositoryInventory, repo_id)
        if repository and repository.workspace_id == workspace.id and repository.source_org == source_org:
            valid_ids.append(repository.id)
    dry_run = form.get("dry_run") == "on"
    if not dry_run and user.role != UserRole.admin:
        flash(request, "Only an administrator can archive source repositories. Workspace users may run the read-only preview.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/source-read-only", status_code=303)
    if not source_org or not valid_ids:
        flash(request, "Choose a source organization and at least one repository.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/source-read-only", status_code=303)
    approved_evidence: dict[str, dict[str, Any]] = {}
    if not dry_run and source.kind == ConnectorKind.ghes:
        if source.status != "connected":
            flash(request, "Retest the GHES connector before executing source read-only.", "error")
            return RedirectResponse(f"/workspaces/{workspace.id}/github/source-read-only", status_code=303)
        approved_evidence, blockers = source_freeze_evidence(
            db,
            workspace_id=workspace.id,
            source_connector_id=source.id,
            source_org=source_org,
            repository_ids=valid_ids,
        )
        if blockers or set(approved_evidence) != set(valid_ids):
            repository_names = {
                item.id: item.name
                for item in db.scalars(
                    select(RepositoryInventory).where(RepositoryInventory.id.in_(valid_ids))
                ).all()
            }
            reasons = "; ".join(
                f"{repository_names.get(repo_id, repo_id)}: {reason}"
                for repo_id, reason in sorted(blockers.items())
            )
            flash(
                request,
                "Source read-only was blocked. Complete an official production GEI migration and a successful linked validation first. "
                + reasons,
                "error",
            )
            return RedirectResponse(f"/workspaces/{workspace.id}/github/source-read-only", status_code=303)
    if not dry_run and str(form.get("confirmation", "")) != f"ARCHIVE {source_org}":
        flash(request, f"Enter exactly ARCHIVE {source_org} to authorize source archival.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/github/source-read-only", status_code=303)
    freeze = SourceFreezeRun(
        workspace_id=workspace.id,
        source_connector_id=source.id,
        source_org=source_org,
        created_by_id=user.id,
        dry_run=dry_run,
        scope_json={"repository_ids": valid_ids, "approved_evidence": approved_evidence},
    )
    db.add(freeze)
    db.commit()
    db.refresh(freeze)
    job = job_for(db, user, workspace.id, "source_freeze", {"freeze_run_id": freeze.id})
    record_audit(
        db,
        action="source_read_only.start",
        resource_type="source_freeze_run",
        resource_id=freeze.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"job_id": job.id, "dry_run": dry_run, "repository_ids": valid_ids, "source_org": source_org},
    )
    flash(request, f"Source read-only {'preview' if dry_run else 'execution'} queued as {job.id}.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/jobs/{job.id}", status_code=303)


@router.get("/workspaces/{workspace_id}/jobs/{job_id}", response_class=HTMLResponse)
def job_detail_page(
    workspace_id: str,
    job_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    job = db.get(Job, job_id)
    if not job or job.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Job not found")
    log_text = ""
    if job.log_path:
        path = Path(job.log_path).resolve()
        allowed = settings.logs_dir.resolve()
        if allowed in path.parents and path.exists():
            raw = path.read_text(encoding="utf-8", errors="replace")
            log_text = raw[-200000:]
    interpretations = db.scalars(
        select(Job)
        .where(Job.workspace_id == workspace.id, Job.kind == "ai_interpret")
        .order_by(Job.created_at.desc())
        .limit(100)
    ).all()
    interpretations = [item for item in interpretations if (item.payload_json or {}).get("source_job_id") == job.id]
    ai_config = db.get(AIConfiguration, 1)
    return html(
        request,
        db,
        "job_detail.html",
        user,
        workspace=workspace,
        job=job,
        log_text=log_text,
        interpretations=interpretations,
        ai_config=ai_config,
    )


@router.post("/workspaces/{workspace_id}/jobs/{job_id}/interpret")
async def interpret_job(
    workspace_id: str,
    job_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> RedirectResponse:
    workspace = accessible_workspace(workspace_id, user, db)
    source_job = db.get(Job, job_id)
    if not source_job or source_job.workspace_id != workspace.id:
        raise HTTPException(status_code=404, detail="Job not found")
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    config = db.get(AIConfiguration, 1)
    if not config or not config.enabled:
        flash(request, "Azure OpenAI is not enabled by an administrator.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/jobs/{job.id}", status_code=303)
    if "job_interpretation" not in set(config.allowed_use_cases_json or []):
        flash(request, "Job interpretation is not enabled in the Azure OpenAI use-case allowlist.", "error")
        return RedirectResponse(f"/workspaces/{workspace.id}/jobs/{job.id}", status_code=303)
    ai_job = job_for(db, user, workspace.id, "ai_interpret", {"source_job_id": source_job.id})
    record_audit(
        db,
        action="ai.job_interpretation.start",
        resource_type="job",
        resource_id=source_job.id,
        workspace_id=workspace.id,
        user_id=user.id,
        details={"interpretation_job_id": ai_job.id},
    )
    flash(request, f"AI interpretation queued as {ai_job.id}. It is advisory and cannot alter migration state.", "success")
    return RedirectResponse(f"/workspaces/{workspace.id}/jobs/{ai_job.id}", status_code=303)


@router.get("/admin/menu", response_class=HTMLResponse)
def menu_admin_page(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> HTMLResponse:
    menus = db.scalars(select(MenuSetting).order_by(MenuSetting.group_name, MenuSetting.sort_order)).all()
    return html(request, db, "admin_menu.html", user, menus=menus)


@router.post("/admin/menu")
async def update_menu_admin(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    rows = db.scalars(select(MenuSetting)).all()
    enabled_keys = {str(value) for value in form.getlist("enabled_keys")}
    changes: dict[str, bool] = {}
    for row in rows:
        # Keep the menu configuration page visible to administrators to prevent
        # accidental navigation lockout. Route authorization remains independent.
        value = True if row.key == "configure.menu" else row.key in enabled_keys
        if row.enabled != value:
            row.enabled = value
            changes[row.key] = value
            db.add(row)
    db.commit()
    record_audit(db, action="menu.update", resource_type="menu_settings", user_id=user.id, details={"changes": changes})
    flash(request, "Menu enablement updated. Hidden routes retain their normal authorization controls.", "success")
    return RedirectResponse("/admin/menu", status_code=303)


@router.get("/admin/audit", response_class=HTMLResponse)
def global_audit_page(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> HTMLResponse:
    entries = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(2000)).all()
    return html(request, db, "admin_audit.html", user, entries=entries)


@router.get("/admin/ai", response_class=HTMLResponse)
def ai_admin_page(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> HTMLResponse:
    config = db.get(AIConfiguration, 1) or AIConfiguration(id=1)
    jobs = db.scalars(select(Job).where(Job.kind == "ai_test").order_by(Job.created_at.desc()).limit(20)).all()
    return html(request, db, "admin_ai.html", user, ai_config=config, jobs=jobs)


@router.post("/admin/ai")
async def update_ai_admin(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    config = db.get(AIConfiguration, 1)
    if not config:
        config = AIConfiguration(id=1)
    config.enabled = form.get("enabled") == "on"
    endpoint = str(form.get("endpoint", "")).strip().rstrip("/")
    if endpoint:
        try:
            endpoint = validate_azure_openai_endpoint(endpoint)
        except UrlValidationError as exc:
            flash(request, str(exc), "error")
            return RedirectResponse("/admin/ai", status_code=303)
    config.endpoint = endpoint or None
    config.deployment = str(form.get("deployment", "")).strip() or None
    config.model = str(form.get("model", "")).strip() or None
    config.api_style = "v1"
    config.auth_mode = str(form.get("auth_mode", "managed_identity"))
    if config.auth_mode not in {"managed_identity", "api_key"}:
        config.auth_mode = "managed_identity"
    api_key = str(form.get("api_key", "")).strip()
    if api_key:
        config.encrypted_api_key = encrypt_secret(api_key)
        config.api_key_last4 = api_key[-4:]
    if config.enabled and (not config.endpoint or not config.deployment):
        flash(request, "An endpoint and deployment are required when Azure OpenAI is enabled.", "error")
        return RedirectResponse("/admin/ai", status_code=303)
    if config.enabled and config.auth_mode == "api_key" and not (api_key or config.encrypted_api_key):
        flash(request, "An API key is required for API-key authentication.", "error")
        return RedirectResponse("/admin/ai", status_code=303)
    try:
        config.max_input_chars = max(1000, min(500000, int(form.get("max_input_chars", 120000))))
        config.max_output_tokens = max(128, min(16384, int(form.get("max_output_tokens", 4096))))
    except (TypeError, ValueError):
        config.max_input_chars = 120000
        config.max_output_tokens = 4096
    allowed_use_cases = [str(value) for value in form.getlist("allowed_use_cases")]
    supported_use_cases = {"job_interpretation", "owner_remediation_draft", "validation_summary"}
    config.allowed_use_cases_json = [value for value in allowed_use_cases if value in supported_use_cases]
    config.system_prompt = str(form.get("system_prompt", config.system_prompt or "")).strip() or config.system_prompt
    try:
        config.temperature = max(0.0, min(1.0, float(form.get("temperature", config.temperature))))
    except (TypeError, ValueError):
        config.temperature = 0.1
    config.status = "not_tested"
    config.status_message = "Configuration changed; run a connection test"
    config.updated_by_id = user.id
    config.updated_at = utcnow()
    db.add(config)
    db.commit()
    record_audit(
        db,
        action="ai.configuration.update",
        resource_type="ai_configuration",
        resource_id="1",
        user_id=user.id,
        details={
            "enabled": config.enabled,
            "endpoint": config.endpoint,
            "deployment": config.deployment,
            "auth_mode": config.auth_mode,
            "api_key_rotated": bool(api_key),
        },
    )
    flash(request, "Azure OpenAI configuration saved. AI remains outside the migration execution path.", "success")
    return RedirectResponse("/admin/ai", status_code=303)


@router.post("/admin/ai/test")
async def test_ai_admin(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(admin_user),
) -> RedirectResponse:
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    job = job_for(db, user, None, "ai_test", {})
    record_audit(db, action="ai.connection_test.start", resource_type="job", resource_id=job.id, user_id=user.id)
    flash(request, f"Azure OpenAI connection test queued as {job.id}.", "success")
    return RedirectResponse("/admin/ai", status_code=303)


@router.get("/help", response_class=HTMLResponse)
def help_index_page(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    return html(request, db, "help_index.html", user)


@router.get("/help/github-enterprise-migration", response_class=HTMLResponse)
def help_github_enterprise_page(
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
) -> HTMLResponse:
    return html(request, db, "help_github_enterprise_migration.html", user)
