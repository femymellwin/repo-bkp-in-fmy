from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    app_name: str = "ForgeBridge"
    app_tagline: str = "Controlled, auditable GHES-to-GHEC migrations."
    app_version: str = "0.1.2"
    app_build_number: str = "FB-0.1.2-004"
    company_name: str = "Inception UAE"
    edition_label: str = "Enterprise"
    environment: str = "development"
    secret_key: str = Field(default="change-this-development-secret")
    token_encryption_key: str | None = None
    database_url: str = "sqlite:///./forgebridge.db"
    redis_url: str = "redis://localhost:6379/0"
    task_mode: str = "local"  # local or celery
    session_cookie_name: str = "forgebridge_session"
    session_cookie_secure: bool | None = None
    seed_on_startup: bool = True
    demo_mode: bool = True
    auto_create_tables: bool = True
    allow_default_admin_in_production: bool = False
    log_level: str = "INFO"
    github_api_version: str = "2022-11-28"
    default_admin_username: str = "admin"
    default_admin_email: str = "admin@example.com"
    default_admin_password: str = "ChangeMe123!"

    # Official GitHub migration execution.
    command_timeout_seconds: int = 21600
    gei_binary: str = "gei"
    gei_download_logs: bool = True
    migration_policy_mode: str = "github-supported-only"
    enable_real_migrations: bool = False
    enable_elm: bool = False
    enable_destructive_purge: bool = False
    enable_source_freeze: bool = False

    # Optional read-only Git mirror scan. This is discovery evidence only and is
    # never used as a migration method.
    git_binary: str = "git"
    enable_large_file_scan: bool = False
    large_file_warning_bytes: int = 50 * 1024 * 1024
    large_file_blocker_bytes: int = 100 * 1024 * 1024
    large_file_scan_timeout_seconds: int = 3600
    large_file_scan_top_n: int = 100

    # Enterprise Live Migrations official CLI invocation.
    elm_ssh_host: str | None = None
    elm_ssh_user: str = "admin"
    elm_ssh_port: int = 122
    elm_ssh_identity_file: str | None = None
    elm_poll_interval_seconds: int = 30
    elm_ready_timeout_seconds: int = 21600
    elm_completion_timeout_seconds: int = 3600

    # Azure OpenAI is advisory only. Migration, validation, freeze and purge
    # must continue safely when AI is unavailable.
    ai_request_timeout_seconds: int = 60
    ai_max_log_chars: int = 120000

    reports_dir: Path = Path("./data/reports")
    logs_dir: Path = Path("./data/logs")
    branding_dir: Path = Path("./data/branding")

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.reports_dir.mkdir(parents=True, exist_ok=True)
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    settings.branding_dir.mkdir(parents=True, exist_ok=True)
    return settings
