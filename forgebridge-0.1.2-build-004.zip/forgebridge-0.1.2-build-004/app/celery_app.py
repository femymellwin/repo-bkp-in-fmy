from __future__ import annotations

from celery import Celery

from app.config import get_settings
from app.tasks import execute_job

settings = get_settings()
celery = Celery("forgebridge", broker=settings.redis_url, backend=settings.redis_url)
celery.conf.update(
    task_track_started=True,
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    worker_prefetch_multiplier=1,
    task_acks_late=True,
)


@celery.task(name="forgebridge.execute_job")
def execute_job_task(job_id: str) -> dict:
    return execute_job(job_id)
