from __future__ import annotations

from typing import Any

import httpx
from sqlalchemy.orm import Session

from app.models import Connector, ConnectorKind, Job, JobStatus, TargetFlavor, utcnow
from app.security import decrypt_secret
from app.services.github_client import GitHubApiError, GitHubClient
from app.services.job_utils import append_job_log, update_job


def _scope_observations(connector: Connector, scopes: list[str]) -> list[str]:
    """Return advisory scope findings without pretending scopes alone prove access."""
    findings: list[str] = []
    scope_set = set(scopes)
    if connector.kind == ConnectorKind.ghes:
        for required in ("repo", "admin:org"):
            if scopes and required not in scope_set:
                findings.append(f"Classic PAT scope '{required}' was not reported by the API")
    elif connector.kind == ConnectorKind.ghec:
        for required in ("repo", "workflow"):
            if scopes and required not in scope_set:
                findings.append(f"Classic PAT scope '{required}' was not reported by the API")
        if scopes and not ({"admin:org", "read:org"} & scope_set):
            findings.append("Neither 'admin:org' nor 'read:org' was reported")
    return findings


def run_connector_test(db: Session, job: Job) -> dict[str, Any]:
    connector = db.get(Connector, job.payload_json["connector_id"])
    if not connector:
        raise RuntimeError("Connector not found")
    update_job(db, job, status=JobStatus.running, progress=10, step="Testing connector")
    append_job_log(job, "Connector test started", {"connector": connector.name, "kind": connector.kind.value})

    if not connector.verify_ssl and connector.kind not in (ConnectorKind.simulated_ghes, ConnectorKind.simulated_ghec):
        raise RuntimeError("TLS certificate verification is mandatory in the GitHub-supported-only build")

    if connector.kind in (ConnectorKind.simulated_ghes, ConnectorKind.simulated_ghec):
        metadata = {
            "identity": "demo-migrator",
            "scopes": ["repo", "admin:org", "workflow", "delete_repo"],
            "installed_version": "3.21.2" if connector.kind == ConnectorKind.simulated_ghes else None,
            "organizations": ["demo-source"] if connector.kind == ConnectorKind.simulated_ghes else ["demo-target"],
            "target_flavor": connector.target_flavor.value,
            "simulation": True,
            "scope_observations": [],
        }
    elif connector.kind in (ConnectorKind.ghes, ConnectorKind.ghec):
        token = decrypt_secret(connector.encrypted_token)
        if not token:
            raise RuntimeError("Connector token is missing")
        with GitHubClient(connector.api_url, token, connector.verify_ssl) as client:
            identity = client.identity()
            meta = client.meta()
            try:
                organizations = client.list_user_organizations()
            except GitHubApiError as exc:
                if exc.status_code in (403, 404):
                    organizations = []
                else:
                    raise
            installed_version = meta.get("installed_version") if connector.kind == ConnectorKind.ghes else None
            metadata = {
                "identity": identity.login,
                "name": identity.name,
                "email": identity.email,
                "scopes": identity.scopes,
                "installed_version": installed_version,
                "organizations": sorted({str(item.get("login")) for item in organizations if item.get("login")}),
                "target_flavor": connector.target_flavor.value,
                "scope_observations": _scope_observations(connector, identity.scopes),
                "meta": meta,
            }
    elif connector.kind == ConnectorKind.onepassword:
        token = decrypt_secret(connector.encrypted_token)
        if not token:
            raise RuntimeError("1Password connector token is missing")
        url = connector.api_url.rstrip("/") + "/v1/vaults"
        response = httpx.get(
            url,
            headers={"Authorization": f"Bearer {token}"},
            verify=connector.verify_ssl,
            timeout=30,
            follow_redirects=False,
        )
        if 300 <= response.status_code < 400:
            raise RuntimeError("1Password Connect redirect was refused to protect the bearer token")
        response.raise_for_status()
        vaults = response.json()
        metadata = {
            "vault_count": len(vaults),
            "vaults": [{"id": item.get("id"), "name": item.get("name")} for item in vaults[:200]],
            "connection_type": "1Password Connect",
            "note": "ForgeBridge verifies access and produces references; it never copies GitHub secret values because GitHub does not expose them.",
        }
    else:
        raise RuntimeError(f"Unsupported connector type: {connector.kind.value}")

    connector.status = "connected"
    connector.status_message = "Connection successful"
    connector.metadata_json = metadata
    connector.last_tested_at = utcnow()
    db.add(connector)
    db.commit()
    result = {"connector": connector.name, "status": "connected", "metadata": metadata}
    update_job(db, job, status=JobStatus.succeeded, progress=100, step="Connector verified", result=result)
    append_job_log(job, "Connector test completed", result)
    return result
