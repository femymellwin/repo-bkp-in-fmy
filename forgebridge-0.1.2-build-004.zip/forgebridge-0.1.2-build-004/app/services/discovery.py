from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Callable

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import (
    Connector,
    ConnectorKind,
    DiscoveryRun,
    Job,
    JobStatus,
    MigrationMethod,
    RepositoryInventory,
    RepositorySnapshot,
    utcnow,
)
from app.security import decrypt_secret
from app.services.git_scan import GitScanError, scan_large_git_objects
from app.services.github_client import GitHubApiError, GitHubClient
from app.services.job_utils import append_job_log, update_job
from app.services.pipeline_scan import EXTERNAL_PIPELINE_PATHS, merge_pipeline_reports, scan_pipeline_file
from app.services.readiness import apply_assessment

settings = get_settings()


EXPECTED_GITHUB_ERRORS = (403, 404, 409, 422)


def parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None


def safe_count(client: GitHubClient, path: str, params: dict[str, Any] | None = None) -> int:
    try:
        return client.count_endpoint(path, params)
    except GitHubApiError as exc:
        if exc.status_code in EXPECTED_GITHUB_ERRORS:
            return 0
        raise


def safe_list(call: Callable[[], list[dict[str, Any]]]) -> list[dict[str, Any]]:
    try:
        return call()
    except GitHubApiError as exc:
        if exc.status_code in EXPECTED_GITHUB_ERRORS:
            return []
        raise


def safe_dict(call: Callable[[], dict[str, Any]]) -> dict[str, Any]:
    try:
        return call() or {}
    except GitHubApiError as exc:
        if exc.status_code in EXPECTED_GITHUB_ERRORS:
            return {}
        raise


def demo_repositories(org: str) -> list[dict[str, Any]]:
    now = utcnow()
    return [
        {
            "id": 101,
            "node_id": "DEMO_node_payments",
            "name": "payments-api",
            "full_name": f"{org}/payments-api",
            "owner": {"login": org, "type": "Organization"},
            "description": "Payment service and settlement APIs",
            "homepage": "https://payments.example.internal",
            "language": "Python",
            "license": {"spdx_id": "NOASSERTION"},
            "topics": ["payments", "api"],
            "visibility": "private",
            "default_branch": "main",
            "archived": False,
            "disabled": False,
            "fork": False,
            "size": 742000,
            "forks_count": 3,
            "stargazers_count": 8,
            "watchers_count": 8,
            "created_at": "2020-01-12T09:00:00Z",
            "updated_at": now.isoformat(),
            "pushed_at": now.isoformat(),
            "open_issues_count": 14,
            "demo": {
                "branches": 19,
                "protected": 2,
                "tags": 48,
                "prs": 312,
                "open_prs": 3,
                "releases": 36,
                "workflows": 4,
                "secrets": 12,
                "variables": 9,
                "envs": 3,
                "risk": 62,
                "contributors": 27,
                "self_hosted": True,
            },
        },
        {
            "id": 102,
            "node_id": "DEMO_node_mobile",
            "name": "mobile-app",
            "full_name": f"{org}/mobile-app",
            "owner": {"login": org, "type": "Organization"},
            "description": "Customer mobile application",
            "homepage": None,
            "language": "Kotlin",
            "license": None,
            "topics": ["mobile", "android"],
            "visibility": "internal",
            "default_branch": "main",
            "archived": False,
            "disabled": False,
            "fork": False,
            "size": 1850000,
            "forks_count": 8,
            "stargazers_count": 16,
            "watchers_count": 16,
            "created_at": "2018-06-08T11:22:00Z",
            "updated_at": now.isoformat(),
            "pushed_at": now.isoformat(),
            "open_issues_count": 33,
            "demo": {
                "branches": 44,
                "protected": 3,
                "tags": 77,
                "prs": 847,
                "open_prs": 11,
                "releases": 68,
                "workflows": 7,
                "external": 1,
                "secrets": 21,
                "variables": 15,
                "envs": 4,
                "risk": 78,
                "contributors": 64,
                "hardcoded": True,
            },
        },
        {
            "id": 103,
            "node_id": "DEMO_node_legacy",
            "name": "legacy-billing",
            "full_name": f"{org}/legacy-billing",
            "owner": {"login": org, "type": "Organization"},
            "description": "Legacy billing service",
            "homepage": None,
            "language": "Java",
            "license": None,
            "topics": ["legacy"],
            "visibility": "private",
            "default_branch": "master",
            "archived": False,
            "disabled": False,
            "fork": False,
            "size": 410000,
            "forks_count": 1,
            "stargazers_count": 1,
            "watchers_count": 1,
            "created_at": "2016-03-01T07:00:00Z",
            "updated_at": "2024-01-02T12:00:00Z",
            "pushed_at": "2024-01-02T12:00:00Z",
            "open_issues_count": 3,
            "demo": {
                "branches": 5,
                "protected": 1,
                "tags": 10,
                "prs": 98,
                "open_prs": 0,
                "releases": 8,
                "workflows": 0,
                "secrets": 0,
                "variables": 0,
                "envs": 0,
                "risk": 5,
                "contributors": 9,
            },
        },
        {
            "id": 104,
            "node_id": "DEMO_node_data",
            "name": "data-platform-monorepo",
            "full_name": f"{org}/data-platform-monorepo",
            "owner": {"login": org, "type": "Organization"},
            "description": "Large data platform monorepository",
            "homepage": "https://data.example.internal",
            "language": "Scala",
            "license": None,
            "topics": ["data", "monorepo", "platform"],
            "visibility": "internal",
            "default_branch": "main",
            "archived": False,
            "disabled": False,
            "fork": False,
            "size": 12900000,
            "forks_count": 20,
            "stargazers_count": 45,
            "watchers_count": 45,
            "created_at": "2019-09-15T13:30:00Z",
            "updated_at": now.isoformat(),
            "pushed_at": now.isoformat(),
            "open_issues_count": 81,
            "demo": {
                "branches": 122,
                "protected": 6,
                "tags": 160,
                "prs": 2100,
                "open_prs": 24,
                "releases": 18,
                "workflows": 12,
                "external": 2,
                "secrets": 34,
                "variables": 27,
                "envs": 8,
                "risk": 85,
                "lfs": True,
                "contributors": 133,
                "large_warning": 4,
                "largest_blob": 180 * 1024 * 1024,
            },
        },
        {
            "id": 105,
            "node_id": "DEMO_node_fork",
            "name": "vendor-fork",
            "full_name": f"{org}/vendor-fork",
            "owner": {"login": org, "type": "Organization"},
            "description": "Archived vendor fork",
            "homepage": None,
            "language": "Go",
            "license": {"spdx_id": "Apache-2.0"},
            "topics": ["vendor", "fork"],
            "visibility": "private",
            "default_branch": "main",
            "archived": True,
            "disabled": False,
            "fork": True,
            "size": 98000,
            "forks_count": 0,
            "stargazers_count": 0,
            "watchers_count": 0,
            "created_at": "2021-02-01T10:00:00Z",
            "updated_at": "2025-02-02T10:00:00Z",
            "pushed_at": "2025-02-02T10:00:00Z",
            "open_issues_count": 0,
            "demo": {
                "branches": 2,
                "protected": 0,
                "tags": 2,
                "prs": 1,
                "open_prs": 0,
                "releases": 0,
                "workflows": 1,
                "secrets": 1,
                "variables": 0,
                "envs": 0,
                "risk": 25,
                "contributors": 2,
            },
        },
    ]


def _upsert_inventory(
    db: Session,
    workspace_id: str,
    connector_id: str,
    org: str,
    data: dict[str, Any],
) -> RepositoryInventory:
    row = db.scalar(
        select(RepositoryInventory).where(
            RepositoryInventory.workspace_id == workspace_id,
            RepositoryInventory.source_org == org,
            RepositoryInventory.name == data["name"],
        )
    )
    if not row:
        row = RepositoryInventory(
            workspace_id=workspace_id,
            connector_id=connector_id,
            source_org=org,
            name=data["name"],
            full_name=data.get("full_name", f"{org}/{data['name']}"),
            target_name=data.get("target_name") or data["name"],
        )
    row.connector_id = connector_id
    for key, value in data.items():
        if hasattr(row, key):
            setattr(row, key, value)
    row.discovered_at = utcnow()
    db.add(row)
    db.flush()
    return row


def _snapshot_data(row: RepositoryInventory) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for column in row.__table__.columns:
        value = getattr(row, column.name)
        if isinstance(value, datetime):
            value = value.isoformat()
        result[column.name] = value
    return result


def _save_snapshot(db: Session, discovery: DiscoveryRun | None, row: RepositoryInventory) -> None:
    if discovery:
        db.add(
            RepositorySnapshot(
                discovery_run_id=discovery.id,
                repository_inventory_id=row.id,
                data_json=_snapshot_data(row),
            )
        )


def _summarize_org(client: GitHubClient, org: str, deep_scan: bool) -> dict[str, Any]:
    org_data = client.org(org)
    if not deep_scan:
        return {"organization": org_data, "deep_scan": False}
    teams = safe_list(lambda: client.list_org_teams(org))
    members = safe_list(lambda: client.list_org_members(org))
    outside = safe_list(lambda: client.list_outside_collaborators(org))
    hooks = safe_list(lambda: client.list_org_hooks(org))
    rulesets = safe_list(lambda: client.list_org_rulesets(org))
    secrets = safe_list(lambda: client.list_org_secret_names(org))
    variables = safe_list(lambda: client.list_org_variables(org))
    return {
        "organization": org_data,
        "deep_scan": True,
        "teams": [
            {
                "id": item.get("id"),
                "slug": item.get("slug"),
                "name": item.get("name"),
                "privacy": item.get("privacy"),
                "permission": item.get("permission"),
            }
            for item in teams
        ],
        "members": [
            {"id": item.get("id"), "login": item.get("login"), "type": item.get("type")}
            for item in members
        ],
        "outside_collaborators": [
            {"id": item.get("id"), "login": item.get("login"), "type": item.get("type")}
            for item in outside
        ],
        "organization_webhooks": [
            {
                "id": item.get("id"),
                "name": item.get("name"),
                "active": item.get("active"),
                "events": item.get("events"),
                "url": (item.get("config") or {}).get("url"),
            }
            for item in hooks
        ],
        "organization_rulesets": [
            {
                "id": item.get("id"),
                "name": item.get("name"),
                "target": item.get("target"),
                "enforcement": item.get("enforcement"),
            }
            for item in rulesets
        ],
        "actions_secret_names": sorted(item.get("name") for item in secrets if item.get("name")),
        "actions_variable_names": sorted(item.get("name") for item in variables if item.get("name")),
        "counts": {
            "teams": len(teams),
            "members": len(members),
            "outside_collaborators": len(outside),
            "organization_webhooks": len(hooks),
            "organization_rulesets": len(rulesets),
            "actions_secret_names": len(secrets),
            "actions_variable_names": len(variables),
        },
        "important_note": (
            "Secret values are never returned by GitHub APIs. Organization settings, teams, "
            "access and integrations require separately tracked destination workstreams."
        ),
    }


def _target_state(client: GitHubClient | None, target_org: str | None, name: str) -> dict[str, Any]:
    if not client or not target_org:
        return {"probed": False, "exists": False}
    try:
        repository = client.get_repository(target_org, name)
        latest = client.get_latest_commit(target_org, name, repository.get("default_branch"))
        return {
            "probed": True,
            "exists": True,
            "id": repository.get("id"),
            "node_id": repository.get("node_id"),
            "full_name": repository.get("full_name"),
            "visibility": repository.get("visibility")
            or ("private" if repository.get("private") else "public"),
            "archived": repository.get("archived"),
            "default_branch": repository.get("default_branch"),
            "default_branch_sha": (latest or {}).get("sha"),
            "html_url": repository.get("html_url"),
        }
    except GitHubApiError as exc:
        if exc.status_code == 404:
            return {"probed": True, "exists": False}
        return {"probed": True, "exists": None, "error": str(exc)}


def _large_file_scan(
    client: GitHubClient,
    connector: Connector,
    token: str,
    org: str,
    repo: str,
    treeish: str | None,
    requested: bool,
) -> dict[str, Any]:
    if not requested or not treeish:
        return {"requested": requested, "status": "not_run", "warning_count": 0, "blocker_count": 0}
    try:
        evidence = client.list_large_files(
            org,
            repo,
            treeish,
            warning_bytes=settings.large_file_warning_bytes,
            top_n=settings.large_file_scan_top_n,
        )
        files = evidence.get("files") or []
        result = {
            "requested": True,
            "status": "completed_api_tree",
            "scope": "default branch recursive tree; not complete Git history",
            "warning_threshold_bytes": settings.large_file_warning_bytes,
            "blocker_threshold_bytes": settings.large_file_blocker_bytes,
            "warning_count": len(files),
            "blocker_count": sum(
                1 for item in files if int(item.get("size_bytes") or 0) >= settings.large_file_blocker_bytes
            ),
            "largest_blob_bytes": int(evidence.get("largest_bytes") or 0),
            "largest_objects": files,
            "tree_truncated": bool(evidence.get("truncated")),
            "tree_unavailable": bool(evidence.get("tree_unavailable")),
        }
        if settings.enable_large_file_scan:
            try:
                historical = scan_large_git_objects(connector.base_url, org, repo, token)
                result["full_history_scan"] = historical
                if historical.get("status") == "completed":
                    result["status"] = "completed_full_history"
                    result["warning_count"] = max(
                        int(result["warning_count"]), int(historical.get("warning_count") or 0)
                    )
                    result["blocker_count"] = max(
                        int(result["blocker_count"]), int(historical.get("blocker_count") or 0)
                    )
                    result["largest_blob_bytes"] = max(
                        int(result["largest_blob_bytes"]), int(historical.get("largest_blob_bytes") or 0)
                    )
            except GitScanError as exc:
                result["full_history_scan"] = {"status": "failed", "error": str(exc)}
        return result
    except GitHubApiError as exc:
        return {
            "requested": True,
            "status": "failed",
            "warning_count": 0,
            "blocker_count": 0,
            "error": str(exc),
        }


def _simulation_pipeline(repo_name: str, demo: dict[str, Any]) -> dict[str, Any]:
    reports: list[dict[str, Any]] = []
    workflow_count = int(demo.get("workflows") or 0)
    if workflow_count:
        content = """name: CI
on: [push]
permissions:
  contents: read
  id-token: write
jobs:
  build:
    runs-on: self-hosted
    environment: production
    steps:
      - uses: actions/checkout@v4
      - run: curl https://api.example.internal/deploy
        env:
          DEPLOY_TOKEN: ${{ secrets.DEPLOY_TOKEN }}
          SERVICE_URL: ${{ vars.SERVICE_URL }}
"""
        if not demo.get("self_hosted"):
            content = content.replace("runs-on: self-hosted", "runs-on: ubuntu-latest")
        if demo.get("hardcoded"):
            content += "      - run: deploy\n        env:\n          API_PASSWORD: example-not-a-real-secret\n"
        reports.append(scan_pipeline_file(".github/workflows/ci.yml", content))
    if int(demo.get("external") or 0):
        reports.append(
            scan_pipeline_file(
                "azure-pipelines.yml",
                "pool: private-linux\nsteps:\n- script: curl https://ado.example.internal\n  env:\n    TOKEN: $(DEPLOY_TOKEN)\n",
            )
        )
    secret_names = [f"SECRET_{index}" for index in range(1, int(demo.get("secrets") or 0) + 1)]
    variable_names = [f"VAR_{index}" for index in range(1, int(demo.get("variables") or 0) + 1)]
    merged = merge_pipeline_reports(reports, secret_names, variable_names)
    merged["risk_score"] = float(demo.get("risk") or merged.get("risk_score") or 0)
    merged["owner_contacts"] = [
        {
            "login": f"{repo_name}-owner",
            "name": "Demo Repository Owner",
            "email": "owner@example.com",
            "source": "simulation",
        }
    ]
    return merged


def _simulation_inventory(repo: dict[str, Any], org: str, options: dict[str, Any]) -> dict[str, Any]:
    demo = repo.get("demo") or {}
    pipeline_report = _simulation_pipeline(repo["name"], demo) if options.get("pipeline_scan") else merge_pipeline_reports([], [], [])
    pushed_at = parse_datetime(repo.get("pushed_at"))
    inactive_days = (datetime.now(timezone.utc) - pushed_at).days if pushed_at else None
    large_warning_count = int(demo.get("large_warning") or 0) if options.get("large_file_scan") else 0
    largest_blob = int(demo.get("largest_blob") or 0) if options.get("large_file_scan") else 0
    large_scan = {
        "requested": bool(options.get("large_file_scan")),
        "status": "completed_simulation" if options.get("large_file_scan") else "not_run",
        "warning_count": large_warning_count,
        "blocker_count": 1 if largest_blob >= settings.large_file_blocker_bytes else 0,
        "largest_blob_bytes": largest_blob,
        "scope": "simulation",
    }
    target_state = {"probed": bool(options.get("target_probe")), "exists": False, "simulation": True}
    latest_sha = (f"demo{repo['id']:x}" * 10)[:40]
    workflow_count = int(demo.get("workflows") or 0)
    external_count = len(pipeline_report.get("external_pipeline_files") or [])
    detail = {
        "branches": [
            {"name": repo.get("default_branch"), "protected": bool(demo.get("protected")), "sha": latest_sha}
        ],
        "open_pull_requests": [
            {
                "number": index,
                "title": f"Demo pull request {index}",
                "state": "open",
                "user": "demo-developer",
            }
            for index in range(1, int(demo.get("open_prs") or 0) + 1)
        ],
        "collaborators": [
            {"login": f"{repo['name']}-owner", "role_name": "maintain", "permissions": {"admin": True}}
        ],
        "contributors": [
            {"login": "demo-developer", "contributions": 42, "email": "developer@example.com"}
        ],
        "webhooks": [{"id": 1, "active": True, "url": "https://ci.example.internal/hook"}]
        if workflow_count or external_count
        else [],
        "deploy_keys": [{"id": 1, "title": "Deployment key", "read_only": True}]
        if workflow_count
        else [],
        "actions_permissions": {"enabled": True, "allowed_actions": "all"},
        "repository_rulesets": [
            {"id": 1, "name": "Protect main", "target": "branch", "enforcement": "active"}
        ]
        if demo.get("protected")
        else [],
        "environment_names": [f"environment-{i}" for i in range(1, int(demo.get("envs") or 0) + 1)],
        "secret_names": pipeline_report.get("secret_names") or [],
        "variable_names": pipeline_report.get("variable_names") or [],
        "large_file_scan": large_scan,
        "deep_scan_complete": bool(options.get("deep_scan")),
        "simulation": True,
        "data_availability_note": (
            "GitHub does not reliably expose an original repository creator or private user email addresses. "
            "Commit identity is retained when the API exposes it."
        ),
    }
    return {
        "name": repo["name"],
        "full_name": repo.get("full_name", f"{org}/{repo['name']}"),
        "owner_login": (repo.get("owner") or {}).get("login"),
        "owner_type": (repo.get("owner") or {}).get("type"),
        "description": repo.get("description"),
        "homepage": repo.get("homepage"),
        "primary_language": repo.get("language"),
        "license_spdx": (repo.get("license") or {}).get("spdx_id"),
        "topics_json": repo.get("topics") or [],
        "github_id": repo.get("id"),
        "node_id": repo.get("node_id"),
        "visibility": repo.get("visibility") or "private",
        "default_branch": repo.get("default_branch"),
        "archived": bool(repo.get("archived")),
        "disabled": bool(repo.get("disabled")),
        "is_fork": bool(repo.get("fork")),
        "empty_repository": False,
        "size_kb": int(repo.get("size") or 0),
        "forks_count": int(repo.get("forks_count") or 0),
        "stargazers_count": int(repo.get("stargazers_count") or 0),
        "watchers_count": int(repo.get("watchers_count") or 0),
        "created_at_source": parse_datetime(repo.get("created_at")),
        "updated_at_source": parse_datetime(repo.get("updated_at")),
        "pushed_at_source": pushed_at,
        "last_commit_sha": latest_sha,
        "last_commit_at": pushed_at,
        "last_author_name": "Demo Developer",
        "last_author_email": "developer@example.com",
        "last_author_login": "demo-developer",
        "last_committer_name": "Demo Developer",
        "last_committer_email": "developer@example.com",
        "last_committer_login": "demo-developer",
        "inactive_days": inactive_days,
        "branches_count": int(demo.get("branches") or 0),
        "protected_branches_count": int(demo.get("protected") or 0),
        "tags_count": int(demo.get("tags") or 0),
        "open_issues_count": int(repo.get("open_issues_count") or 0),
        "pull_requests_count": int(demo.get("prs") or 0),
        "open_pull_requests_count": int(demo.get("open_prs") or 0),
        "releases_count": int(demo.get("releases") or 0),
        "release_assets_bytes": int(demo.get("release_assets_bytes") or 0),
        "largest_release_asset_bytes": int(demo.get("largest_release_asset_bytes") or 0),
        "oversized_release_assets_count": int(demo.get("oversized_release_assets_count") or 0),
        "workflows_count": workflow_count,
        "environments_count": int(demo.get("envs") or 0),
        "secrets_count": int(demo.get("secrets") or 0),
        "variables_count": int(demo.get("variables") or 0),
        "webhooks_count": len(detail["webhooks"]),
        "deploy_keys_count": len(detail["deploy_keys"]),
        "collaborators_count": int(demo.get("contributors") or 0),
        "contributors_count": int(demo.get("contributors") or 0),
        "has_lfs": bool(demo.get("lfs")),
        "has_actions": workflow_count > 0,
        "pipeline_lane": "with_pipelines" if pipeline_report.get("has_pipeline") else "without_pipelines",
        "external_pipeline_count": external_count,
        "self_hosted_runner_count": len(pipeline_report.get("self_hosted_runners") or []),
        "pipeline_risk_score": float(pipeline_report.get("risk_score") or 0),
        "pipeline_report_json": pipeline_report,
        "large_file_blocker_count": int(large_scan.get("blocker_count") or 0),
        "large_file_warning_count": int(large_scan.get("warning_count") or 0),
        "largest_blob_bytes": int(large_scan.get("largest_blob_bytes") or 0),
        "target_org_checked": options.get("target_org"),
        "target_exists": False,
        "target_state_json": target_state,
        "raw_json": repo,
        "detail_json": detail,
    }


def _scan_real_repository(
    client: GitHubClient,
    connector: Connector,
    token: str,
    repo: dict[str, Any],
    org: str,
    options: dict[str, Any],
    target_client: GitHubClient | None,
) -> dict[str, Any]:
    name = str(repo["name"])
    deep_scan = bool(options.get("deep_scan"))
    pipeline_scan = deep_scan and bool(options.get("pipeline_scan"))
    default_branch = repo.get("default_branch")
    latest: dict[str, Any] | None = None
    try:
        latest = client.get_latest_commit(org, name, default_branch)
    except GitHubApiError as exc:
        if exc.status_code not in EXPECTED_GITHUB_ERRORS:
            raise
    commit_info = (latest or {}).get("commit") or {}
    author = commit_info.get("author") or {}
    committer = commit_info.get("committer") or {}
    api_author = (latest or {}).get("author") or {}
    api_committer = (latest or {}).get("committer") or {}
    last_commit_at = parse_datetime(committer.get("date") or author.get("date"))
    inactive_days = (datetime.now(timezone.utc) - last_commit_at).days if last_commit_at else None

    branches = safe_list(lambda: client.list_branches(org, name)) if deep_scan else []
    branches_count = len(branches) if deep_scan else safe_count(client, f"/repos/{org}/{name}/branches")
    protected_count = sum(1 for item in branches if item.get("protected"))
    tags_count = safe_count(client, f"/repos/{org}/{name}/tags")
    pulls_all = safe_count(client, f"/repos/{org}/{name}/pulls", {"state": "all"})
    open_pulls = safe_list(lambda: client.list_open_pull_requests(org, name)) if deep_scan else []
    pulls_open = len(open_pulls) if deep_scan else safe_count(
        client, f"/repos/{org}/{name}/pulls", {"state": "open"}
    )
    releases = safe_list(lambda: client.list_releases(org, name)) if deep_scan else []
    releases_count = len(releases) if deep_scan else safe_count(client, f"/repos/{org}/{name}/releases")
    release_assets = [asset for release in releases for asset in (release.get("assets") or [])]
    release_assets_bytes = sum(int(item.get("size") or 0) for item in release_assets)
    largest_release_asset = max((int(item.get("size") or 0) for item in release_assets), default=0)
    oversized_release_assets = sum(1 for item in release_assets if int(item.get("size") or 0) > 2 * 1024**3)

    workflows = safe_list(lambda: client.list_workflows(org, name)) if pipeline_scan else []
    secrets = safe_list(lambda: client.list_secret_names(org, name)) if pipeline_scan else []
    variables = safe_list(lambda: client.list_variables(org, name)) if pipeline_scan else []
    environments = safe_list(lambda: client.list_environments(org, name)) if pipeline_scan else []
    pipeline_reports: list[dict[str, Any]] = []
    if pipeline_scan:
        for workflow in workflows:
            path = workflow.get("path")
            if not path:
                continue
            text = client.get_content_text(org, name, str(path), default_branch)
            if text is not None:
                pipeline_reports.append(scan_pipeline_file(str(path), text))
        if options.get("external_pipeline_scan"):
            for path in EXTERNAL_PIPELINE_PATHS:
                text = client.get_content_text(org, name, path, default_branch)
                if text is not None:
                    pipeline_reports.append(scan_pipeline_file(path, text))
    pipeline_report = merge_pipeline_reports(
        pipeline_reports,
        [str(item.get("name")) for item in secrets if item.get("name")],
        [str(item.get("name")) for item in variables if item.get("name")],
    )

    collaborators = safe_list(lambda: client.list_collaborators(org, name)) if deep_scan else []
    contributors = safe_list(lambda: client.list_contributors(org, name)) if deep_scan else []
    hooks = safe_list(lambda: client.list_webhooks(org, name)) if deep_scan else []
    deploy_keys = safe_list(lambda: client.list_deploy_keys(org, name)) if deep_scan else []
    actions_permissions = safe_dict(lambda: client.get_actions_permissions(org, name)) if deep_scan else {}
    repository_rulesets = safe_list(lambda: client.list_repository_rulesets(org, name)) if deep_scan else []

    has_lfs = False
    if deep_scan and default_branch:
        has_lfs = client.get_content_text(org, name, ".gitattributes", default_branch) is not None
    large_scan = _large_file_scan(
        client,
        connector,
        token,
        org,
        name,
        default_branch,
        bool(options.get("large_file_scan")),
    )
    target_state = _target_state(target_client, options.get("target_org"), name)
    secret_names = [str(item.get("name")) for item in secrets if item.get("name")]
    variable_names = [str(item.get("name")) for item in variables if item.get("name")]

    detail = {
        "branches": [
            {
                "name": item.get("name"),
                "protected": item.get("protected"),
                "sha": (item.get("commit") or {}).get("sha"),
            }
            for item in branches
        ],
        "open_pull_requests": [
            {
                "number": item.get("number"),
                "title": item.get("title"),
                "state": item.get("state"),
                "draft": item.get("draft"),
                "user": (item.get("user") or {}).get("login"),
                "updated_at": item.get("updated_at"),
                "head": (item.get("head") or {}).get("ref"),
                "base": (item.get("base") or {}).get("ref"),
            }
            for item in open_pulls
        ],
        "collaborators": [
            {
                "id": item.get("id"),
                "login": item.get("login"),
                "type": item.get("type"),
                "role_name": item.get("role_name"),
                "permissions": item.get("permissions"),
                "email": item.get("email"),
                "name": item.get("name"),
            }
            for item in collaborators
        ],
        "contributors": [
            {
                "id": item.get("id"),
                "login": item.get("login") or item.get("name"),
                "type": item.get("type"),
                "contributions": item.get("contributions"),
                "email": item.get("email"),
                "name": item.get("name"),
            }
            for item in contributors
        ],
        "webhooks": [
            {
                "id": item.get("id"),
                "name": item.get("name"),
                "active": item.get("active"),
                "events": item.get("events"),
                "url": (item.get("config") or {}).get("url"),
            }
            for item in hooks
        ],
        "deploy_keys": [
            {
                "id": item.get("id"),
                "title": item.get("title"),
                "read_only": item.get("read_only"),
                "verified": item.get("verified"),
            }
            for item in deploy_keys
        ],
        "actions_permissions": actions_permissions,
        "repository_rulesets": [
            {
                "id": item.get("id"),
                "name": item.get("name"),
                "target": item.get("target"),
                "enforcement": item.get("enforcement"),
            }
            for item in repository_rulesets
        ],
        "environment_names": [str(item.get("name")) for item in environments if item.get("name")],
        "secret_names": secret_names,
        "variable_names": variable_names,
        "release_assets": [
            {
                "release_id": release.get("id"),
                "release_tag": release.get("tag_name"),
                "asset_id": asset.get("id"),
                "asset_name": asset.get("name"),
                "size_bytes": int(asset.get("size") or 0),
                "download_count": int(asset.get("download_count") or 0),
            }
            for release in releases
            for asset in (release.get("assets") or [])
        ],
        "large_file_scan": large_scan,
        "deep_scan_complete": deep_scan,
        "data_availability_note": (
            "The repository API does not generally expose the original creator or private user email "
            "addresses. ForgeBridge records commit and account identity only when GitHub returns it."
        ),
    }
    github_open_issues = int(repo.get("open_issues_count") or 0)
    open_issue_only = max(0, github_open_issues - pulls_open)
    return {
        "name": name,
        "full_name": repo.get("full_name", f"{org}/{name}"),
        "owner_login": (repo.get("owner") or {}).get("login"),
        "owner_type": (repo.get("owner") or {}).get("type"),
        "description": repo.get("description"),
        "homepage": repo.get("homepage"),
        "primary_language": repo.get("language"),
        "license_spdx": (repo.get("license") or {}).get("spdx_id"),
        "topics_json": repo.get("topics") or [],
        "github_id": repo.get("id"),
        "node_id": repo.get("node_id"),
        "visibility": repo.get("visibility") or ("private" if repo.get("private") else "public"),
        "default_branch": default_branch,
        "archived": bool(repo.get("archived")),
        "disabled": bool(repo.get("disabled")),
        "is_fork": bool(repo.get("fork")),
        "empty_repository": latest is None,
        "size_kb": int(repo.get("size") or 0),
        "forks_count": int(repo.get("forks_count") or 0),
        "stargazers_count": int(repo.get("stargazers_count") or 0),
        "watchers_count": int(repo.get("watchers_count") or 0),
        "created_at_source": parse_datetime(repo.get("created_at")),
        "updated_at_source": parse_datetime(repo.get("updated_at")),
        "pushed_at_source": parse_datetime(repo.get("pushed_at")),
        "last_commit_sha": (latest or {}).get("sha"),
        "last_commit_at": last_commit_at,
        "last_author_name": author.get("name"),
        "last_author_email": author.get("email"),
        "last_author_login": api_author.get("login"),
        "last_committer_name": committer.get("name"),
        "last_committer_email": committer.get("email"),
        "last_committer_login": api_committer.get("login"),
        "inactive_days": inactive_days,
        "branches_count": branches_count,
        "protected_branches_count": protected_count,
        "tags_count": tags_count,
        "open_issues_count": open_issue_only,
        "pull_requests_count": pulls_all,
        "open_pull_requests_count": pulls_open,
        "releases_count": releases_count,
        "release_assets_bytes": release_assets_bytes,
        "largest_release_asset_bytes": largest_release_asset,
        "oversized_release_assets_count": oversized_release_assets,
        "workflows_count": len(workflows),
        "environments_count": len(environments),
        "secrets_count": len(secrets),
        "variables_count": len(variables),
        "webhooks_count": len(hooks) if deep_scan else safe_count(client, f"/repos/{org}/{name}/hooks"),
        "deploy_keys_count": len(deploy_keys) if deep_scan else safe_count(client, f"/repos/{org}/{name}/keys"),
        "collaborators_count": len(collaborators)
        if deep_scan
        else safe_count(client, f"/repos/{org}/{name}/collaborators", {"affiliation": "all"}),
        "contributors_count": len(contributors),
        "has_lfs": has_lfs,
        "has_actions": bool(workflows),
        "pipeline_lane": "with_pipelines" if pipeline_report.get("has_pipeline") else "without_pipelines",
        "external_pipeline_count": len(pipeline_report.get("external_pipeline_files") or []),
        "self_hosted_runner_count": len(pipeline_report.get("self_hosted_runners") or []),
        "pipeline_risk_score": float(pipeline_report.get("risk_score") or 0),
        "pipeline_report_json": pipeline_report,
        "large_file_blocker_count": int(large_scan.get("blocker_count") or 0),
        "large_file_warning_count": int(large_scan.get("warning_count") or 0),
        "largest_blob_bytes": int(large_scan.get("largest_blob_bytes") or 0),
        "target_org_checked": options.get("target_org"),
        "target_exists": target_state.get("exists") is True,
        "target_repository_id": target_state.get("id"),
        "target_visibility": target_state.get("visibility"),
        "target_default_branch": target_state.get("default_branch"),
        "target_last_commit_sha": target_state.get("default_branch_sha"),
        "target_state_json": target_state,
        "raw_json": repo,
        "detail_json": detail,
    }


def _summary(
    rows: list[RepositoryInventory],
    *,
    discovery_id: str | None,
    org: str,
    mode: str,
    options: dict[str, Any],
    errors: list[dict[str, str]],
) -> dict[str, Any]:
    grades: dict[str, int] = {}
    statuses: dict[str, int] = {}
    for row in rows:
        grades[row.readiness_grade] = grades.get(row.readiness_grade, 0) + 1
        statuses[row.readiness_status] = statuses.get(row.readiness_status, 0) + 1
    return {
        "discovery_run_id": discovery_id,
        "organization": org,
        "repositories": len(rows),
        "mode": mode,
        "options": options,
        "with_pipelines": sum(1 for row in rows if row.pipeline_lane == "with_pipelines"),
        "without_pipelines": sum(1 for row in rows if row.pipeline_lane == "without_pipelines"),
        "blocked": sum(1 for row in rows if row.readiness_status == "blocked"),
        "needs_review": sum(1 for row in rows if row.readiness_status == "needs_review"),
        "ready": sum(1 for row in rows if row.readiness_status == "ready"),
        "target_conflicts": sum(1 for row in rows if row.target_exists),
        "lfs_repositories": sum(1 for row in rows if row.has_lfs),
        "empty_repositories": sum(1 for row in rows if row.empty_repository),
        "large_file_findings": sum(
            row.large_file_warning_count + row.large_file_blocker_count for row in rows
        ),
        "readiness_grades": grades,
        "readiness_statuses": statuses,
        "repository_errors": errors,
    }


def run_discovery(db: Session, job: Job) -> dict[str, Any]:
    payload = job.payload_json or {}
    connector = db.get(Connector, payload.get("connector_id"))
    if not connector:
        raise RuntimeError("Source connector not found")
    if connector.kind not in (ConnectorKind.ghes, ConnectorKind.simulated_ghes):
        raise RuntimeError("Discovery requires a GHES source connector")
    org = str(payload.get("source_org") or "").strip()
    if not org:
        raise RuntimeError("Source organization is required")
    discovery = db.get(DiscoveryRun, payload.get("discovery_run_id")) if payload.get("discovery_run_id") else None
    options = {
        "deep_scan": bool(payload.get("deep_scan", True)),
        "pipeline_scan": bool(payload.get("pipeline_scan", True)),
        "external_pipeline_scan": bool(payload.get("external_pipeline_scan", True)),
        "large_file_scan": bool(payload.get("large_file_scan", False)),
        "target_probe": bool(payload.get("target_probe", False)),
        "target_connector_id": payload.get("target_connector_id"),
        "target_org": str(payload.get("target_org") or "").strip() or None,
        "readiness_method": str(payload.get("readiness_method") or "gei").lower(),
    }
    if options["readiness_method"] not in {"gei", "elm"}:
        raise RuntimeError("Readiness method must be gei or elm")
    target_connector = db.get(Connector, options["target_connector_id"]) if options["target_connector_id"] else None
    if target_connector and target_connector.workspace_id != job.workspace_id:
        raise RuntimeError("Target connector is outside this workspace")

    update_job(db, job, status=JobStatus.running, progress=1, step="Starting discovery")
    append_job_log(job, "Discovery started", {"source_org": org, "options": options})
    if discovery:
        discovery.status = JobStatus.running
        discovery.started_at = utcnow()
        discovery.deep_scan = options["deep_scan"]
        discovery.target_connector_id = target_connector.id if target_connector else None
        discovery.target_org = options["target_org"]
        discovery.assess_target = bool(options["target_probe"])
        discovery.options_json = options
        db.add(discovery)
        db.commit()

    target_client: GitHubClient | None = None
    rows: list[RepositoryInventory] = []
    errors: list[dict[str, str]] = []
    org_summary: dict[str, Any]
    try:
        if connector.kind == ConnectorKind.simulated_ghes:
            org_summary = {
                "organization": {"login": org, "name": "Simulated GHES organization"},
                "deep_scan": options["deep_scan"],
                "counts": {"teams": 8, "members": 180, "outside_collaborators": 6},
                "simulation": True,
            }
            repositories = demo_repositories(org)
            for index, repo in enumerate(repositories, start=1):
                update_job(
                    db,
                    job,
                    progress=max(2, int(index / max(len(repositories), 1) * 92)),
                    step=f"Inspecting {repo['name']}",
                )
                data = _simulation_inventory(repo, org, options)
                row = _upsert_inventory(db, job.workspace_id or "", connector.id, org, data)
                apply_assessment(
                    row,
                    method=MigrationMethod(options["readiness_method"]),
                    target_flavor=target_connector.target_flavor if target_connector else None,
                    source_metadata=connector.metadata_json or {},
                )
                _save_snapshot(db, discovery, row)
                db.commit()
                db.refresh(row)
                rows.append(row)
        else:
            token = decrypt_secret(connector.encrypted_token)
            if not token:
                raise RuntimeError("Source connector has no token")
            if target_connector and options["target_probe"]:
                if target_connector.kind == ConnectorKind.simulated_ghec:
                    target_client = None
                elif target_connector.kind == ConnectorKind.ghec:
                    target_token = decrypt_secret(target_connector.encrypted_token)
                    if not target_token:
                        raise RuntimeError("Target connector has no token")
                    target_client = GitHubClient(
                        target_connector.api_url,
                        target_token,
                        target_connector.verify_ssl,
                    )
            with GitHubClient(connector.api_url, token, connector.verify_ssl) as client:
                org_summary = _summarize_org(client, org, options["deep_scan"])
                repositories = client.list_org_repositories(org)
                for index, repo in enumerate(repositories, start=1):
                    name = str(repo.get("name") or f"repository-{index}")
                    update_job(
                        db,
                        job,
                        progress=max(2, int(index / max(len(repositories), 1) * 92)),
                        step=f"Inspecting {name}",
                    )
                    append_job_log(
                        job,
                        "Inspecting repository",
                        {"repository": name, "index": index, "total": len(repositories)},
                    )
                    try:
                        data = _scan_real_repository(
                            client,
                            connector,
                            token,
                            repo,
                            org,
                            options,
                            target_client,
                        )
                    except Exception as exc:
                        errors.append({"repository": name, "error": str(exc)})
                        append_job_log(job, "Repository discovery failed", {"repository": name, "error": str(exc)})
                        data = {
                            "name": name,
                            "full_name": repo.get("full_name", f"{org}/{name}"),
                            "target_name": name,
                            "owner_login": (repo.get("owner") or {}).get("login"),
                            "owner_type": (repo.get("owner") or {}).get("type"),
                            "description": repo.get("description"),
                            "visibility": repo.get("visibility") or "private",
                            "default_branch": repo.get("default_branch"),
                            "disabled": bool(repo.get("disabled")),
                            "archived": bool(repo.get("archived")),
                            "is_fork": bool(repo.get("fork")),
                            "size_kb": int(repo.get("size") or 0),
                            "pipeline_lane": "without_pipelines",
                            "target_state_json": {"probed": False, "exists": False},
                            "raw_json": repo,
                            "detail_json": {
                                "deep_scan_complete": False,
                                "discovery_error": str(exc),
                            },
                        }
                    row = _upsert_inventory(db, job.workspace_id or "", connector.id, org, data)
                    apply_assessment(
                        row,
                        method=MigrationMethod(options["readiness_method"]),
                        target_flavor=target_connector.target_flavor if target_connector else None,
                        source_metadata=connector.metadata_json or {},
                    )
                    _save_snapshot(db, discovery, row)
                    db.commit()
                    db.refresh(row)
                    rows.append(row)
    finally:
        if target_client:
            target_client.close()

    result = _summary(
        rows,
        discovery_id=discovery.id if discovery else None,
        org=org,
        mode="simulation" if connector.kind == ConnectorKind.simulated_ghes else "live",
        options=options,
        errors=errors,
    )
    if discovery:
        discovery.status = JobStatus.succeeded
        discovery.repository_count = len(rows)
        discovery.organization_json = org_summary
        discovery.summary_json = result
        discovery.finished_at = utcnow()
        db.add(discovery)
        db.commit()
    update_job(
        db,
        job,
        status=JobStatus.succeeded,
        progress=100,
        step="Discovery complete",
        result=result,
    )
    append_job_log(job, "Discovery completed", result)
    return result
