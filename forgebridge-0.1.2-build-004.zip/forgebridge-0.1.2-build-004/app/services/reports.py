from __future__ import annotations

import csv
import io
import json
import zipfile
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import (
    DiscoveryRun,
    Job,
    MigrationRun,
    PurgeRun,
    RepositoryInventory,
    SourceFreezeRun,
    ValidationRun,
)
from app.policy import METHOD_POLICY


def _csv_cell(value: Any) -> Any:
    """Prevent spreadsheet formula execution when reports are opened interactively."""
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple, set)):
        value = json.dumps(value, sort_keys=True, default=str)
    if isinstance(value, str) and value[:1] in {"=", "+", "-", "@"}:
        return "'" + value
    return value


def csv_text(headers: list[str], rows: list[list[Any]]) -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(headers)
    writer.writerows([[_csv_cell(value) for value in row] for row in rows])
    return output.getvalue()


def discovery_csv(db: Session, workspace_id: str) -> str:
    repos = db.scalars(
        select(RepositoryInventory)
        .where(RepositoryInventory.workspace_id == workspace_id)
        .order_by(RepositoryInventory.source_org, RepositoryInventory.name)
    ).all()
    headers = [
        "inventory_id", "source_connector_id", "source_org", "repository", "target_name",
        "github_id", "node_id", "owner_login", "owner_type", "description", "homepage",
        "visibility", "archived", "disabled", "fork", "empty_repository", "size_kb",
        "language", "license", "topics", "default_branch", "created_at_source",
        "updated_at_source", "pushed_at_source", "last_commit_sha", "last_commit_at",
        "last_author_login", "last_author_name", "last_author_email", "last_committer_login",
        "last_committer_name", "last_committer_email", "inactive_days", "branches",
        "protected_branches", "tags", "open_issues", "pull_requests", "open_pull_requests",
        "releases", "release_assets_bytes", "largest_release_asset_bytes",
        "oversized_release_assets_count", "workflows", "external_pipeline_files",
        "pipeline_systems", "environments", "secret_names_count", "variables_count",
        "self_hosted_runners", "webhooks", "deploy_keys", "collaborators", "contributors",
        "has_lfs", "pipeline_lane", "pipeline_risk_score", "readiness_score", "readiness_grade",
        "readiness_status", "blocker_count", "warning_count", "blockers", "warnings",
        "largest_blob_bytes", "large_file_warning_count", "large_file_blocker_count",
        "target_probe_completed", "target_exists", "target_org", "target_repository_id",
        "target_probe_message", "deep_scan_complete", "discovered_at",
    ]
    rows: list[list[Any]] = []
    for repo in repos:
        pipeline = repo.pipeline_report_json or {}
        target = repo.target_state_json or {}
        detail = repo.detail_json or {}
        rows.append([
            repo.id, repo.connector_id, repo.source_org, repo.name, repo.target_name,
            repo.github_id, repo.node_id, repo.owner_login, repo.owner_type, repo.description,
            repo.homepage, repo.visibility, repo.archived, repo.disabled, repo.is_fork,
            repo.empty_repository, repo.size_kb, repo.primary_language, repo.license_spdx,
            ";".join(repo.topics_json or []), repo.default_branch, repo.created_at_source,
            repo.updated_at_source, repo.pushed_at_source, repo.last_commit_sha,
            repo.last_commit_at, repo.last_author_login, repo.last_author_name,
            repo.last_author_email, repo.last_committer_login, repo.last_committer_name,
            repo.last_committer_email, repo.inactive_days, repo.branches_count,
            repo.protected_branches_count, repo.tags_count, repo.open_issues_count,
            repo.pull_requests_count, repo.open_pull_requests_count, repo.releases_count,
            repo.release_assets_bytes, repo.largest_release_asset_bytes,
            repo.oversized_release_assets_count, repo.workflows_count,
            repo.external_pipeline_count, ";".join(pipeline.get("pipeline_systems", [])),
            repo.environments_count, repo.secrets_count, repo.variables_count,
            repo.self_hosted_runner_count, repo.webhooks_count, repo.deploy_keys_count,
            repo.collaborators_count, repo.contributors_count, repo.has_lfs, repo.pipeline_lane,
            repo.pipeline_risk_score, repo.readiness_score, repo.readiness_grade,
            repo.readiness_status, repo.blocker_count, repo.warning_count,
            repo.blockers_json or [], repo.warnings_json or [], repo.largest_blob_bytes,
            repo.large_file_warning_count, repo.large_file_blocker_count,
            bool(target.get("probed")), target.get("exists"), target.get("organization"),
            target.get("id"), target.get("message"), bool(detail.get("deep_scan_complete")),
            repo.discovered_at,
        ])
    return csv_text(headers, rows)


def _pipeline_row(repo: RepositoryInventory, category: str, name: Any, details: str, location: str = "", recommended: str = "") -> list[Any]:
    report = repo.pipeline_report_json or {}
    return [
        repo.source_org, repo.name, repo.owner_login, repo.pipeline_lane,
        ";".join(report.get("pipeline_systems", [])), repo.pipeline_risk_score,
        category, name, location, recommended, details,
    ]


def pipeline_csv(db: Session, workspace_id: str) -> str:
    repos = db.scalars(
        select(RepositoryInventory)
        .where(RepositoryInventory.workspace_id == workspace_id)
        .order_by(RepositoryInventory.source_org, RepositoryInventory.name)
    ).all()
    headers = [
        "source_org", "repository", "owner", "pipeline_lane", "pipeline_systems",
        "risk_score", "category", "name", "location", "recommended_1password_reference",
        "owner_action_or_details",
    ]
    rows: list[list[Any]] = []
    for repo in repos:
        report = repo.pipeline_report_json or {}
        mappings = {item.get("github_secret_name"): item for item in report.get("onepassword_mapping", [])}
        for secret in report.get("secret_names", []):
            mapping = mappings.get(secret, {})
            rows.append(_pipeline_row(
                repo, "secret_reference", secret,
                "Value is intentionally unavailable; populate and validate in the approved 1Password vault.",
                recommended=mapping.get("recommended_reference", f"op://<vault>/{repo.name}/{secret}"),
            ))
        for usage in report.get("secret_usage", []):
            rows.append(_pipeline_row(
                repo, "secret_usage", usage.get("name"), "Review and replace through a normal pull request.",
                location=f"{usage.get('file','')}:{usage.get('line','')}",
                recommended=f"op://<vault>/{repo.name}/{usage.get('name','<secret>')}",
            ))
        for variable in report.get("variable_names", []):
            rows.append(_pipeline_row(repo, "variable", variable, "Recreate or review on GHEC; value is omitted from this report."))
        for usage in report.get("variable_usage", []):
            rows.append(_pipeline_row(repo, "variable_usage", usage.get("name"), usage.get("excerpt", ""), location=f"{usage.get('file','')}:{usage.get('line','')}"))
        for environment in report.get("environments", []):
            rows.append(_pipeline_row(repo, "environment", environment, "Recreate environment, reviewers, wait timers, and deployment protection configuration."))
        for url in report.get("external_urls", []):
            rows.append(_pipeline_row(repo, "external_url", url, "Confirm GHEC-side DNS, firewall, proxy, and endpoint reachability."))
        for runner in report.get("runners", []):
            rows.append(_pipeline_row(repo, "runner", runner, "Re-register or reassign self-hosted runner infrastructure and labels."))
        for action in report.get("actions_used", []):
            rows.append(_pipeline_row(repo, "action_dependency", action, "Review allow-list availability and pinning policy on GHEC."))
        for reference in report.get("oidc_references", []):
            rows.append(_pipeline_row(repo, "oidc", reference, "Recreate cloud trust against the GHEC organization/repository subject and audience."))
        for reference in report.get("artifact_references", []):
            rows.append(_pipeline_row(repo, "artifact", reference, "Workflow artifacts and run history require explicit acceptance; validate retention expectations."))
        for reference in report.get("cache_references", []):
            rows.append(_pipeline_row(repo, "cache", reference, "Caches are ephemeral; validate first-run behavior and target permissions."))
        for pipeline_file in report.get("pipeline_files", []):
            rows.append(_pipeline_row(
                repo, "pipeline_file", pipeline_file.get("path"),
                f"System={pipeline_file.get('pipeline_system')}; risk={pipeline_file.get('risk_score',0)}; parse_error={pipeline_file.get('parse_error') or 'none'}",
                location=pipeline_file.get("path", ""),
            ))
        for finding in report.get("hardcoded_credential_findings", []):
            rows.append(_pipeline_row(
                repo, "security_finding", finding.get("key"),
                f"{finding.get('severity','critical')}: {finding.get('reason','Potential hard-coded credential')}. Value is redacted.",
                location=f"{finding.get('file','')}:{finding.get('line','')}",
            ))
        for parse_error in report.get("parse_errors", []):
            rows.append(_pipeline_row(repo, "parse_error", parse_error.get("path"), parse_error.get("error", ""), location=parse_error.get("path", "")))
        if not report.get("has_pipeline"):
            rows.append(_pipeline_row(repo, "classification", "No pipeline dependency discovered", "No known Actions or external pipeline file was detected by the bounded discovery scan."))
    return csv_text(headers, rows)


def pipeline_owner_handoff_data(db: Session, workspace_id: str) -> list[dict[str, Any]]:
    """Build owner-ready pipeline remediation records without secret values."""

    repos = db.scalars(
        select(RepositoryInventory)
        .where(
            RepositoryInventory.workspace_id == workspace_id,
            RepositoryInventory.pipeline_lane == "with_pipelines",
        )
        .order_by(RepositoryInventory.source_org, RepositoryInventory.name)
    ).all()
    records: list[dict[str, Any]] = []
    for repo in repos:
        report = repo.pipeline_report_json or {}
        target = repo.target_state_json or {}
        owner_actions: list[str] = []
        if report.get("secret_names"):
            owner_actions.append("Create or confirm each named value in the approved 1Password vault; GitHub secret values are not exported.")
        if report.get("variable_names"):
            owner_actions.append("Recreate or intentionally replace Actions variables on GHEC.")
        if report.get("environments"):
            owner_actions.append("Recreate environments, reviewers, wait timers, protection rules, variables, and secrets.")
        if report.get("runners"):
            owner_actions.append("Register or reassign self-hosted runners and validate every required label.")
        if report.get("external_urls"):
            owner_actions.append("Validate target-side DNS, firewall, proxy, allow-list, and endpoint reachability.")
        if report.get("oidc_references"):
            owner_actions.append("Recreate cloud OIDC trust for the GHEC organization/repository subject and audience.")
        if report.get("hardcoded_credential_findings"):
            owner_actions.append("Resolve potential hard-coded credentials before cutover and rotate affected credentials.")
        if report.get("actions_used"):
            owner_actions.append("Confirm action allow-list policy and immutable pinning on GHEC.")
        owner_actions.extend([
            "Confirm workflow permissions and branch/ruleset requirements after migration.",
            "Run an owner-approved smoke workflow after secrets, runners, environments, and external integrations are restored.",
            "Record acceptance in the migration evidence bundle; ForgeBridge does not rewrite workflow files.",
        ])
        records.append({
            "inventory_id": repo.id,
            "source": f"{repo.source_org}/{repo.name}",
            "target_repository": repo.target_name,
            "target_organization": target.get("organization") or repo.target_org_checked,
            "target_exists_at_discovery": target.get("exists"),
            "repository_owner_login": repo.owner_login,
            "commit_identity_notice": "Names and emails are derived from available commit/API metadata and are not verified repository ownership.",
            "last_author": {
                "login": repo.last_author_login,
                "name": repo.last_author_name,
                "email": repo.last_author_email,
            },
            "last_committer": {
                "login": repo.last_committer_login,
                "name": repo.last_committer_name,
                "email": repo.last_committer_email,
            },
            "last_commit_sha": repo.last_commit_sha,
            "last_commit_at": repo.last_commit_at,
            "inactive_days": repo.inactive_days,
            "readiness": {
                "score": repo.readiness_score,
                "grade": repo.readiness_grade,
                "status": repo.readiness_status,
                "blockers": repo.blockers_json or [],
                "warnings": repo.warnings_json or [],
            },
            "pipeline": {
                "risk_score": repo.pipeline_risk_score,
                "systems": report.get("pipeline_systems", []),
                "files": report.get("pipeline_files", []),
                "github_actions_workflows": report.get("workflow_files", []),
                "secret_names": report.get("secret_names", []),
                "secret_usage": report.get("secret_usage", []),
                "onepassword_mapping": report.get("onepassword_mapping", []),
                "variable_names": report.get("variable_names", []),
                "variable_usage": report.get("variable_usage", []),
                "environments": report.get("environments", []),
                "runners": report.get("runners", []),
                "external_urls": report.get("external_urls", []),
                "actions_used": report.get("actions_used", []),
                "oidc_references": report.get("oidc_references", []),
                "artifact_references": report.get("artifact_references", []),
                "cache_references": report.get("cache_references", []),
                "permissions": report.get("permissions", []),
                "hardcoded_credential_findings": report.get("hardcoded_credential_findings", []),
            },
            "owner_actions": owner_actions,
        })
    return records


def pipeline_owner_handoff_json(db: Session, workspace_id: str) -> str:
    records = pipeline_owner_handoff_data(db, workspace_id)
    return json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "workspace_id": workspace_id,
        "secret_values_included": False,
        "repository_count": len(records),
        "repositories": records,
    }, indent=2, default=str)


def pipeline_owner_handoff_markdown(db: Session, workspace_id: str) -> str:
    records = pipeline_owner_handoff_data(db, workspace_id)
    lines = [
        "# Pipeline owner handoff report",
        "",
        f"Generated: `{datetime.now(timezone.utc).isoformat()}`",
        "",
        "> No GitHub secret values are present. Secret names and redacted usage locations are discovery evidence only.",
        "",
    ]
    if not records:
        lines.append("No repository with a recognized pipeline was found in this workspace.")
        return "\n".join(lines)
    for item in records:
        pipeline = item["pipeline"]
        readiness = item["readiness"]
        lines.extend([
            f"## {item['source']} → {item.get('target_organization') or '<target-org>'}/{item['target_repository']}",
            "",
            f"- Repository owner login: `{item.get('repository_owner_login') or 'unassigned'}`",
            f"- Last commit: `{item.get('last_commit_sha') or 'unknown'}` at `{item.get('last_commit_at') or 'unknown'}`",
            f"- Readiness: `{readiness['grade']}` / `{readiness['score']}` / `{readiness['status']}`",
            f"- Pipeline risk: `{pipeline['risk_score']}`",
            f"- Systems: `{', '.join(pipeline['systems']) or 'not classified'}`",
            f"- Secret names: `{', '.join(pipeline['secret_names']) or 'none discovered'}`",
            f"- Variables: `{', '.join(pipeline['variable_names']) or 'none discovered'}`",
            f"- Environments: `{', '.join(pipeline['environments']) or 'none discovered'}`",
            f"- Runners: `{', '.join(map(str, pipeline['runners'])) or 'none discovered'}`",
            "",
            "### Required owner actions",
            "",
            *[f"- {action}" for action in item["owner_actions"]],
            "",
        ])
        if pipeline["onepassword_mapping"]:
            lines.extend([
                "### Proposed 1Password mappings",
                "",
                "| GitHub reference | Proposed 1Password reference |",
                "|---|---|",
            ])
            for mapping in pipeline["onepassword_mapping"]:
                name = mapping.get("github_secret_name") or mapping.get("name") or "<secret>"
                ref = mapping.get("recommended_reference") or f"op://<vault>/{item['target_repository']}/{name}"
                lines.append(f"| `{name}` | `{ref}` |")
            lines.append("")
        if pipeline["external_urls"]:
            lines.extend(["### External endpoints", "", *[f"- `{value}`" for value in pipeline["external_urls"]], ""])
        if pipeline["hardcoded_credential_findings"]:
            lines.extend(["### Security findings (redacted)", ""])
            for finding in pipeline["hardcoded_credential_findings"]:
                lines.append(f"- `{finding.get('file')}:{finding.get('line')}` — `{finding.get('key') or 'potential credential'}`")
            lines.append("")
    return "\n".join(lines)


def migration_mapping_csv(db: Session, run_id: str) -> str:
    run = db.get(MigrationRun, run_id)
    if not run:
        raise ValueError("Migration run not found")
    db.refresh(run, attribute_names=["repositories"])
    headers = [
        "migration_run_id", "cleanup_token", "lane", "source_org", "source_repo", "source_inventory_id",
        "target_org", "target_repo", "method", "mode", "pipeline_policy", "status", "attempts",
        "external_migration_id", "source_sha", "target_sha", "target_repository_id", "warnings",
        "error", "started_at", "finished_at", "command_preview",
    ]
    rows = [[
        run.id, run.cleanup_token, run.lane.value, run.source_org, item.source_repo,
        item.repository_inventory_id, run.target_org, item.target_repo, run.method.value,
        run.mode.value, run.pipeline_policy.value, item.status.value, item.attempt_count,
        item.external_migration_id, item.source_sha_at_start, item.target_sha_after,
        (item.result_json or {}).get("target_repository_id"), item.warning_count,
        item.error_message, item.started_at, item.finished_at, item.command_preview,
    ] for item in run.repositories]
    return csv_text(headers, rows)


def validation_json(db: Session, validation_id: str) -> str:
    validation = db.get(ValidationRun, validation_id)
    if not validation:
        raise ValueError("Validation run not found")
    return json.dumps({
        "validation_run_id": validation.id,
        "workspace_id": validation.workspace_id,
        "migration_run_id": validation.migration_run_id,
        "source_connector_id": validation.source_connector_id,
        "target_connector_id": validation.target_connector_id,
        "source_org": validation.source_org,
        "target_org": validation.target_org,
        "lane": validation.lane.value,
        "scope": validation.scope_json,
        "status": validation.status.value,
        "score": validation.score,
        "grade": validation.grade,
        "passed": validation.passed_count,
        "warnings": validation.warning_count,
        "failed": validation.failed_count,
        "created_at": validation.created_at,
        "finished_at": validation.finished_at,
        "report": validation.report_json,
    }, indent=2, default=str)


def onepassword_runbook_markdown(db: Session, workspace_id: str) -> str:
    repos = db.scalars(
        select(RepositoryInventory)
        .where(RepositoryInventory.workspace_id == workspace_id, RepositoryInventory.pipeline_lane == "with_pipelines")
        .order_by(RepositoryInventory.source_org, RepositoryInventory.name)
    ).all()
    lines = [
        "# 1Password pipeline remediation plan",
        "",
        "ForgeBridge never retrieves or copies GitHub secret values. This report contains names and references only. Repository owners must create or confirm each value in an approved 1Password vault and update workflows through the normal code-review process.",
        "",
        "Use an approved 1Password service account, Connect server, or official action pattern. Pin external actions to an immutable commit SHA under the organization's software-supply-chain policy.",
        "",
    ]
    for repo in repos:
        report = repo.pipeline_report_json or {}
        lines.extend([f"## {repo.source_org}/{repo.name}", "", f"Owner: `{repo.owner_login or 'unassigned'}`  ", f"Pipeline systems: `{', '.join(report.get('pipeline_systems', [])) or 'unknown'}`  ", f"Pipeline risk: `{repo.pipeline_risk_score:.1f}/100`", ""])
        secret_names = report.get("secret_names", [])
        if secret_names:
            lines.extend(["| Current reference | Proposed 1Password reference | Owner action |", "|---|---|---|"])
            for name in secret_names:
                lines.append(f"| `secrets.{name}` / pipeline variable | `op://<vault>/{repo.name}/{name}` | Populate, authorize, rotate if needed, and validate in a reviewed workflow run |")
            lines.append("")
        else:
            lines.extend(["No secret-name reference was discovered. Confirm manually with the pipeline owner.", ""])
        if report.get("external_urls"):
            lines.extend(["External endpoints to validate:", *[f"- `{url}`" for url in report["external_urls"]], ""])
        if report.get("runners"):
            lines.extend(["Runner dependencies to re-register:", *[f"- `{runner}`" for runner in report["runners"]], ""])
        if report.get("hardcoded_credential_findings"):
            lines.extend(["**Security blocker:** possible hard-coded credentials were found at these redacted locations:", *[f"- `{item.get('file')}:{item.get('line')}` — `{item.get('key')}`" for item in report["hardcoded_credential_findings"]], ""])
        lines.extend([
            "Illustrative pattern only (ForgeBridge does not edit the repository):", "", "```yaml",
            "- name: Load approved secrets from 1Password",
            "  uses: 1password/load-secrets-action@<reviewed-immutable-sha>",
            "  with:", "    export-env: true", "  env:",
            "    OP_SERVICE_ACCOUNT_TOKEN: ${{ secrets.OP_SERVICE_ACCOUNT_TOKEN }}",
        ])
        for name in secret_names[:20]:
            lines.append(f"    {name}: op://<vault>/{repo.name}/{name}")
        if len(secret_names) > 20:
            lines.append(f"    # ... {len(secret_names) - 20} additional mappings in pipeline-remediation.csv")
        lines.extend(["```", ""])
    return "\n".join(lines)


def migration_summary_json(db: Session, run_id: str) -> str:
    run = db.get(MigrationRun, run_id)
    if not run:
        raise ValueError("Migration run not found")
    db.refresh(run, attribute_names=["repositories"])
    return json.dumps({
        "id": run.id,
        "status": run.status.value,
        "lane": run.lane.value,
        "source": {"organization": run.source_org, "connector_id": run.source_connector_id},
        "destination": {"organization": run.target_org, "connector_id": run.target_connector_id},
        "method": run.method.value,
        "mode": run.mode.value,
        "pipeline_policy": run.pipeline_policy.value,
        "selection": run.selection_json,
        "preflight": run.preflight_json,
        "cleanup_token": run.cleanup_token,
        "lock_source_at_cutover": run.lock_source_at_cutover,
        "skip_releases": run.skip_releases,
        "concurrency": run.concurrency,
        "created_at": run.created_at,
        "started_at": run.started_at,
        "finished_at": run.finished_at,
        "repositories": [{
            "inventory_id": item.repository_inventory_id,
            "source": item.source_repo,
            "target": item.target_repo,
            "status": item.status.value,
            "attempts": item.attempt_count,
            "external_migration_id": item.external_migration_id,
            "source_sha": item.source_sha_at_start,
            "target_sha": item.target_sha_after,
            "warnings": item.warning_count,
            "error": item.error_message,
            "command_preview": item.command_preview,
            "result": item.result_json,
        } for item in run.repositories],
    }, indent=2, default=str)


def report_bundle_zip(db: Session, workspace_id: str, run_id: str) -> bytes:
    settings = get_settings()
    run = db.get(MigrationRun, run_id)
    if not run or run.workspace_id != workspace_id:
        raise ValueError("Migration run not found")
    validations = db.scalars(select(ValidationRun).where(ValidationRun.migration_run_id == run.id).order_by(ValidationRun.created_at)).all()
    discoveries = db.scalars(select(DiscoveryRun).where(DiscoveryRun.workspace_id == workspace_id).order_by(DiscoveryRun.created_at)).all()
    purges = db.scalars(select(PurgeRun).where(PurgeRun.migration_run_id == run.id).order_by(PurgeRun.created_at)).all()
    freezes = db.scalars(select(SourceFreezeRun).where(SourceFreezeRun.workspace_id == workspace_id).order_by(SourceFreezeRun.created_at)).all()
    jobs = db.scalars(select(Job).where(Job.workspace_id == workspace_id).order_by(Job.created_at)).all()
    relevant_jobs = [job for job in jobs if (job.payload_json or {}).get("migration_run_id") == run.id or (job.payload_json or {}).get("validation_run_id") in {item.id for item in validations} or (job.payload_json or {}).get("purge_run_id") in {item.id for item in purges}]

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps({
            "product": settings.app_name,
            "version": settings.app_version,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "workspace_id": workspace_id,
            "migration_run_id": run_id,
            "source_is_never_deleted_by_purge": True,
            "approved_migration_methods_only": True,
            "discovery_runs": [item.id for item in discoveries],
            "validation_runs": [item.id for item in validations],
            "purge_runs": [item.id for item in purges],
            "source_freeze_runs": [item.id for item in freezes],
            "jobs": [item.id for item in relevant_jobs],
        }, indent=2))
        archive.writestr("method-policy.json", json.dumps(METHOD_POLICY, indent=2, default=str))
        archive.writestr("known-limitations.md", "# Known migration boundaries\n\nForgeBridge invokes GitHub-supported migration methods and records remediation work. It does not assert lossless parity for objects that GitHub documents as unsupported or separate.\n\n" + "\n".join(f"- {item}" for item in METHOD_POLICY["known_non_migrated_or_separate_workstreams"]))
        archive.writestr("discovery.csv", discovery_csv(db, workspace_id))
        archive.writestr("pipeline-remediation.csv", pipeline_csv(db, workspace_id))
        archive.writestr("pipeline-owner-handoff.md", pipeline_owner_handoff_markdown(db, workspace_id))
        archive.writestr("pipeline-owner-handoff.json", pipeline_owner_handoff_json(db, workspace_id))
        archive.writestr("onepassword-remediation.md", onepassword_runbook_markdown(db, workspace_id))
        archive.writestr("migration-mapping.csv", migration_mapping_csv(db, run_id))
        archive.writestr("migration-summary.json", migration_summary_json(db, run_id))
        archive.writestr("jobs.json", json.dumps([{
            "id": item.id, "kind": item.kind, "status": item.status.value,
            "progress": item.progress, "current_step": item.current_step,
            "payload": item.payload_json, "result": item.result_json,
            "error": item.error_message, "created_at": item.created_at,
            "started_at": item.started_at, "finished_at": item.finished_at,
        } for item in relevant_jobs], indent=2, default=str))
        archive.writestr("target-purge-history.json", json.dumps([{
            "id": item.id, "dry_run": item.dry_run, "status": item.status.value,
            "scope": item.scope_json, "result": item.result_json,
        } for item in purges], indent=2, default=str))
        archive.writestr("source-read-only-history.json", json.dumps([{
            "id": item.id, "source_org": item.source_org, "dry_run": item.dry_run,
            "status": item.status.value, "scope": item.scope_json, "result": item.result_json,
        } for item in freezes], indent=2, default=str))
        for validation in validations:
            archive.writestr(f"validations/{validation.id}.json", validation_json(db, validation.id))
        for discovery in discoveries:
            archive.writestr(f"discoveries/{discovery.id}.json", json.dumps({
                "id": discovery.id, "source_org": discovery.source_org,
                "deep_scan": discovery.deep_scan, "options": discovery.options_json,
                "status": discovery.status.value, "repository_count": discovery.repository_count,
                "organization": discovery.organization_json, "summary": discovery.summary_json,
                "created_at": discovery.created_at, "started_at": discovery.started_at,
                "finished_at": discovery.finished_at,
            }, indent=2, default=str))
    return buffer.getvalue()
