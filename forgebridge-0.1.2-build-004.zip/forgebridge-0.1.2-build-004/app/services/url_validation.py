from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit

from app.models import ConnectorKind, TargetFlavor


class UrlValidationError(ValueError):
    """Raised when an administrator-provided service URL is unsafe or inconsistent."""


@dataclass(frozen=True)
class ValidatedConnectorUrls:
    base_url: str
    api_url: str


def _parse_https_url(value: str, label: str) -> tuple[str, str, int | None, str]:
    raw = (value or "").strip().rstrip("/")
    if not raw:
        raise UrlValidationError(f"{label} is required")
    try:
        parsed = urlsplit(raw)
    except ValueError as exc:
        raise UrlValidationError(f"{label} is not a valid URL") from exc
    if parsed.scheme.lower() != "https":
        raise UrlValidationError(f"{label} must use HTTPS")
    if not parsed.hostname:
        raise UrlValidationError(f"{label} must include a hostname")
    if parsed.username or parsed.password:
        raise UrlValidationError(f"{label} must not contain embedded credentials")
    if parsed.query or parsed.fragment:
        raise UrlValidationError(f"{label} must not contain a query string or fragment")
    try:
        port = parsed.port or 443
    except ValueError as exc:
        raise UrlValidationError(f"{label} contains an invalid port") from exc
    path = parsed.path.rstrip("/")
    normalized = urlunsplit(("https", parsed.netloc, path, "", ""))
    return normalized, parsed.hostname.lower(), port, path


def validate_connector_urls(
    kind: ConnectorKind,
    target_flavor: TargetFlavor,
    base_url: str,
    api_url: str,
) -> ValidatedConnectorUrls:
    """Validate URLs before any credential is stored or sent.

    Private GHES and 1Password Connect hostnames are allowed because enterprise
    deployments commonly use private DNS. The protection is transport and URL
    shape validation, plus GitHub product-specific host/path constraints.
    """

    base, base_host, base_port, base_path = _parse_https_url(base_url or api_url, "Base URL")
    api, api_host, api_port, api_path = _parse_https_url(api_url, "API URL")

    if kind == ConnectorKind.ghes:
        if not api_path.endswith("/api/v3"):
            raise UrlValidationError("A GHES API URL must end with /api/v3")
        if (base_host, base_port) != (api_host, api_port):
            raise UrlValidationError("GHES base and API URLs must use the same origin")
        expected_base_path = api_path[: -len("/api/v3")]
        if base_path != expected_base_path:
            raise UrlValidationError("GHES base URL must correspond to the API URL before /api/v3")

    elif kind == ConnectorKind.ghec:
        if target_flavor == TargetFlavor.github_com:
            if base != "https://github.com" or api != "https://api.github.com":
                raise UrlValidationError(
                    "A github.com destination must use https://github.com and https://api.github.com"
                )
        elif target_flavor == TargetFlavor.ghe_com:
            if not api_host.startswith("api.") or not api_host.endswith(".ghe.com"):
                raise UrlValidationError("A GHE.com API hostname must match api.<enterprise>.ghe.com")
            if api_path:
                raise UrlValidationError("A GHE.com API URL must not include an additional path")
            if not base_host.endswith(".ghe.com") or base_host.startswith("api."):
                raise UrlValidationError("A GHE.com base hostname must match <enterprise>.ghe.com")
            if base_path:
                raise UrlValidationError("A GHE.com base URL must not include an additional path")
            if api_host.removeprefix("api.") != base_host or base_port != api_port:
                raise UrlValidationError("GHE.com base and API URLs must identify the same enterprise origin")
        else:
            raise UrlValidationError("Choose github.com or GHE.com for a GHEC destination")

    elif kind == ConnectorKind.onepassword:
        # 1Password Connect can be privately hosted. Do not impose a public host
        # allowlist, but require an HTTPS origin and no credential-bearing URL.
        if (base_host, base_port) != (api_host, api_port):
            raise UrlValidationError("1Password base and API URLs must use the same origin")
        if base_path or api_path:
            raise UrlValidationError("A 1Password Connect URL must be the HTTPS service origin without /v1")

    elif kind == ConnectorKind.simulated_ghes:
        if not api_path.endswith("/api/v3"):
            raise UrlValidationError("A simulated GHES API URL must end with /api/v3")
        if (base_host, base_port) != (api_host, api_port):
            raise UrlValidationError("Simulated GHES base and API URLs must use the same origin")
        if base_path != api_path[: -len("/api/v3")]:
            raise UrlValidationError("Simulated GHES base URL must correspond to the API URL before /api/v3")

    elif kind == ConnectorKind.simulated_ghec:
        # Simulation URLs still use HTTPS to exercise the same rendering and
        # persistence paths without permitting insecure examples.
        pass

    else:  # pragma: no cover - enum exhaustiveness guard
        raise UrlValidationError(f"Unsupported connector kind: {kind.value}")

    return ValidatedConnectorUrls(base_url=base, api_url=api)


def validate_azure_openai_endpoint(value: str) -> str:
    endpoint, hostname, _, path = _parse_https_url(value, "Azure OpenAI endpoint")
    allowed_suffixes = (".openai.azure.com", ".services.ai.azure.com")
    if not hostname.endswith(allowed_suffixes):
        raise UrlValidationError(
            "Azure OpenAI endpoint must use an *.openai.azure.com or *.services.ai.azure.com hostname"
        )
    if path not in ("", "/openai/v1"):
        raise UrlValidationError("Azure OpenAI endpoint path must be empty or /openai/v1")
    return endpoint
