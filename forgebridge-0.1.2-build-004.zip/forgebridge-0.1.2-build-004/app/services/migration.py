from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from sqlalchemy import update
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import SessionLocal
from app.policy import (
    ELM_MAX_CONCURRENT_REPOSITORIES_PER_GHES,
    ELM_MINIMUM_PATCH_RELEASES,
    ELM_RELEASE_ASSET_LIMIT_BYTES,
    GEI_MAX_CONCURRENT_REPOSITORIES,
    GEI_RELEASE_DATA_LIMIT_BYTES,
)
from app.models import (
    Connector,
    ConnectorKind,
    Job,
    JobStatus,
    MigrationLane,
    MigrationMethod,
    MigrationMode,
    MigrationRun,
    MigrationStatus,
    PipelinePolicy,
    RepoMigration,
    RepoMigrationStatus,
    RepositoryInventory,
    TargetFlavor,
    utcnow,
)
from app.security import decrypt_secret
from app.services.github_client import GitHubApiError, GitHubClient
from app.services.job_utils import append_job_log, update_job
from app.services.remediation import remediation_for_error


UUID_RE = re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}\b")
MIGRATION_ID_RE = re.compile(r"(?:migration(?:Id| ID| id)?|id)\s*[:=]\s*[\"']?([A-Za-z0-9_-]{8,})", re.IGNORECASE)

CLI_TOKEN_RE = re.compile(
    r"(?i)(github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9_]+|authorization:\s*bearer\s+\S+)"
)
SENSITIVE_ENV_KEY_RE = re.compile(r"(?i)(token|pat|secret|password|passwd|api[_-]?key|private[_-]?key)")


def _cli_redaction_values(env: dict[str, str]) -> list[str]:
    values = {
        str(value)
        for key, value in env.items()
        if value and len(str(value)) >= 8 and SENSITIVE_ENV_KEY_RE.search(str(key))
    }
    return sorted(values, key=len, reverse=True)


def redact_cli_output(value: str, secret_values: list[str]) -> str:
    redacted = value
    for secret in secret_values:
        redacted = redacted.replace(secret, "***REDACTED***")
    return CLI_TOKEN_RE.sub("***REDACTED***", redacted)


def command_for_display(command: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in command)


def run_process(command: list[str], env: dict[str, str], log_path: Path, timeout: int) -> tuple[int, str]:
    """Run a CLI command, persist all output, and retain only a bounded tail in memory."""
    from collections import deque
    from queue import Empty, Queue
    from threading import Thread

    log_path.parent.mkdir(parents=True, exist_ok=True)
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
        bufsize=1,
    )
    if process.stdout is None:
        process.kill()
        raise RuntimeError("Unable to capture command output")

    queue: Queue[str | None] = Queue()
    def reader() -> None:
        try:
            for line in iter(process.stdout.readline, ""):
                queue.put(line)
        finally:
            queue.put(None)

    thread = Thread(target=reader, daemon=True)
    thread.start()
    deadline = time.monotonic() + timeout
    tail: deque[str] = deque()
    tail_chars = 0
    max_tail_chars = 500_000
    timed_out = False
    secret_values = _cli_redaction_values(env)

    with log_path.open("w", encoding="utf-8") as handle:
        stream_finished = False
        while not stream_finished:
            if time.monotonic() >= deadline:
                timed_out = True
                process.kill()
            try:
                line = queue.get(timeout=0.2)
            except Empty:
                if process.poll() is not None and not thread.is_alive():
                    break
                continue
            if line is None:
                stream_finished = True
                continue
            safe_line = redact_cli_output(line, secret_values)
            handle.write(safe_line)
            handle.flush()
            tail.append(safe_line)
            tail_chars += len(safe_line)
            while tail and tail_chars > max_tail_chars:
                tail_chars -= len(tail.popleft())
        process.wait(timeout=30)

    output_tail = "".join(tail)
    if timed_out:
        raise RuntimeError(f"Command timed out after {timeout} seconds; review {log_path}")
    return int(process.returncode or 0), output_tail


def parse_external_id(output: str) -> str | None:
    uuid_match = UUID_RE.search(output)
    if uuid_match:
        return uuid_match.group(0)
    match = MIGRATION_ID_RE.search(output)
    return match.group(1) if match else None


def parse_json_output(output: str) -> dict[str, Any] | None:
    """Parse JSON even when the CLI prints informational lines around it."""
    stripped = output.strip()
    if not stripped:
        return None
    try:
        payload = json.loads(stripped)
        return payload if isinstance(payload, dict) else None
    except json.JSONDecodeError:
        pass
    starts = [index for index, char in enumerate(stripped) if char == "{"]
    for start in reversed(starts):
        try:
            payload = json.loads(stripped[start:])
            if isinstance(payload, dict):
                return payload
        except json.JSONDecodeError:
            continue
    return None


def _target_repo_visibility(repo: RepositoryInventory) -> str:
    return repo.visibility if repo.visibility in ("private", "internal", "public") else "private"


def gei_command_prefix() -> list[str]:
    """Return the packaged official standalone GEI invocation prefix.

    Build 004 deliberately does not install or invoke a floating GitHub CLI
    extension. The worker must use the checksum-pinned standalone ``gei``
    executable published by GitHub.
    """

    binary = get_settings().gei_binary
    if Path(binary).name == "gh":
        raise RuntimeError("ForgeBridge requires the packaged standalone gei binary; gh extension mode is disabled")
    return [binary]

def build_gei_command(run: MigrationRun, repo: RepoMigration, source: Connector, target: Connector) -> list[str]:
    settings = get_settings()
    command = [
        *gei_command_prefix(),
        "migrate-repo",
        "--github-source-org",
        run.source_org,
        "--source-repo",
        repo.source_repo,
        "--github-target-org",
        run.target_org,
        "--target-repo",
        repo.target_repo,
        "--ghes-api-url",
        source.api_url,
        "--target-repo-visibility",
        _target_repo_visibility(repo.repository),
    ]
    if run.storage_mode == "github_owned":
        command.append("--use-github-storage")
    if target.target_flavor == TargetFlavor.ghe_com:
        command.extend(["--target-api-url", target.api_url])
    if run.skip_releases:
        command.append("--skip-releases")
    # GEI has no delta synchronization. For a production GEI run, source
    # locking must happen as part of the supported migration command.
    if run.mode == MigrationMode.production and run.lock_source_at_cutover:
        command.append("--lock-source-repo")
    return command


def build_gei_download_logs_command(run: MigrationRun, repo: RepoMigration, target: Connector, output_path: Path) -> list[str]:
    settings = get_settings()
    command = [
        *gei_command_prefix(),
        "download-logs",
        "--github-target-org",
        run.target_org,
        "--target-repo",
        repo.target_repo,
        "--migration-log-file",
        str(output_path),
    ]
    if target.target_flavor == TargetFlavor.ghe_com:
        command.extend(["--target-api-url", target.api_url])
    return command


def _ssh_base_command() -> list[str]:
    settings = get_settings()
    if not settings.elm_ssh_host:
        raise RuntimeError("ELM_SSH_HOST is not configured")
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "StrictHostKeyChecking=yes",
        "-p",
        str(settings.elm_ssh_port),
    ]
    if settings.elm_ssh_identity_file:
        command.extend(["-i", settings.elm_ssh_identity_file])
    command.append(f"{settings.elm_ssh_user}@{settings.elm_ssh_host}")
    return command


def elm_remote_prefix() -> str:
    # Values are read on GHES; they are not sent through the web process or
    # stored in a command preview.
    return (
        "export API_URL='http://localhost:1738'; "
        "export MIGRATION_MANAGER_HMAC_KEY=\"$(ghe-config secrets.elm-exporter.elm-exporter-hmac-keys)\"; "
        "export MIGRATION_TARGET_URL=\"$(ghe-config secrets.elm-exporter.migration-target-url)\"; "
        "export MIGRATION_TARGET_TOKEN=\"$(ghe-config secrets.elm-exporter.migration-target-token)\"; "
    )


def build_elm_create_command(run: MigrationRun, repo: RepoMigration, target: Connector) -> list[str]:
    visibility = "private" if repo.repository.visibility == "private" else "internal"
    remote = (
        elm_remote_prefix()
        + "elm migration create "
        + f"--source-org {shlex.quote(run.source_org)} "
        + f"--source-repo {shlex.quote(repo.source_repo)} "
        + f"--target-org {shlex.quote(run.target_org)} "
        + f"--target-repo {shlex.quote(repo.target_repo)} "
        + f"--target-api {shlex.quote(target.api_url)} "
        + f"--target-visibility {shlex.quote(visibility)} "
        + "--pat-name system-pat --start"
    )
    return _ssh_base_command() + [remote]


def build_elm_status_command(migration_id: str) -> list[str]:
    remote = elm_remote_prefix() + f"elm migration status --migration-id {shlex.quote(migration_id)}"
    return _ssh_base_command() + [remote]


def build_elm_cutover_command(migration_id: str) -> list[str]:
    remote = elm_remote_prefix() + f"elm migration cutover-to-destination --migration-id {shlex.quote(migration_id)}"
    return _ssh_base_command() + [remote]


def elm_status_details(output: str) -> dict[str, Any]:
    payload = parse_json_output(output) or {}
    combined = payload.get("combinedState") or payload.get("combined_state") or {}
    top_status = str(payload.get("status") or payload.get("migrationStatus") or "")
    combined_status = str(combined.get("status") or "")
    display = str(combined.get("displayMessage") or payload.get("displayMessage") or "")
    ready = bool(combined.get("readyForCutover")) or combined_status == "COMBINED_STATUS_READY_FOR_CUTOVER"
    completed = top_status == "MIGRATION_STATUS_COMPLETED" or combined_status in {
        "COMBINED_STATUS_COMPLETED",
        "MIGRATION_STATUS_COMPLETED",
    }
    failed_statuses = {
        "MIGRATION_STATUS_FAILED",
        "MIGRATION_STATUS_TERMINATED",
        "COMBINED_STATUS_FAILED",
        "COMBINED_STATUS_TERMINATED",
    }
    failed = top_status.upper() in failed_statuses or combined_status.upper() in failed_statuses
    blockers = combined.get("cutoverBlockers") or []
    resource_failures = combined.get("failedResources") or payload.get("failedResources") or []
    return {
        "payload": payload,
        "top_status": top_status,
        "combined_status": combined_status,
        "display_message": display,
        "ready_for_cutover": ready,
        "completed": completed,
        "failed": failed,
        "cutover_blockers": blockers,
        "resource_failures": resource_failures,
    }


def poll_elm(
    migration_id: str,
    *,
    wait_for: str,
    log_path: Path,
    timeout_seconds: int,
) -> dict[str, Any]:
    settings = get_settings()
    deadline = time.monotonic() + timeout_seconds
    snapshots: list[dict[str, Any]] = []
    while True:
        code, output = run_process(build_elm_status_command(migration_id), dict(os.environ), log_path, 600)
        if code != 0:
            raise RuntimeError(f"ELM status check failed; review {log_path}")
        details = elm_status_details(output)
        snapshots.append({
            "time": utcnow().isoformat(),
            "top_status": details["top_status"],
            "combined_status": details["combined_status"],
            "display_message": details["display_message"],
            "ready_for_cutover": details["ready_for_cutover"],
            "completed": details["completed"],
            "cutover_blockers": details["cutover_blockers"],
            "resource_failures": details["resource_failures"],
        })
        snapshots = snapshots[-50:]
        if details["failed"]:
            raise RuntimeError(f"ELM reported a failed or terminated migration; review {log_path}")
        if wait_for == "ready" and details["ready_for_cutover"]:
            return {"latest": details, "snapshots": snapshots}
        if wait_for == "completed" and details["completed"]:
            return {"latest": details, "snapshots": snapshots}
        if time.monotonic() >= deadline:
            raise RuntimeError(
                f"ELM did not reach {wait_for} within {timeout_seconds} seconds. "
                f"The migration remains active; review {log_path} and the Jobs page."
            )
        time.sleep(max(5, settings.elm_poll_interval_seconds))


def _parse_semver(value: str) -> tuple[int, int, int] | None:
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", value or "")
    if not match:
        return None
    return tuple(int(part) for part in match.groups())


def _elm_version_supported(version: str) -> bool:
    parsed = _parse_semver(version)
    if not parsed:
        return False
    major, minor, patch = parsed
    minimum_patch = ELM_MINIMUM_PATCH_RELEASES
    if major != 3:
        return False
    if minor not in minimum_patch:
        return False
    return patch >= minimum_patch[minor]


def _tool_output(command: list[str], *, env: dict[str, str] | None = None, timeout: int = 30) -> tuple[int, str]:
    result = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
        timeout=timeout,
        check=False,
    )
    return result.returncode, (result.stdout or "")[-20_000:]


def gei_tooling_status(*, target_token: str | None = None) -> dict[str, Any]:
    """Verify GitHub's packaged standalone GEI executable without mutations."""

    settings = get_settings()
    binary_path = shutil.which(settings.gei_binary)
    status: dict[str, Any] = {
        "binary": settings.gei_binary,
        "binary_path": binary_path,
        "mode": "standalone",
        "packaged_version": os.getenv("GEI_PACKAGED_VERSION"),
        "ready": False,
        "error": None,
    }
    if Path(settings.gei_binary).name == "gh":
        status["error"] = "GitHub CLI extension mode is disabled; use the packaged standalone gei executable"
        return status
    if not binary_path:
        status["error"] = f"GEI standalone binary '{settings.gei_binary}' is not installed"
        return status

    env = dict(os.environ)
    env["GH_NO_UPDATE_NOTIFIER"] = "1"
    env["GH_NO_EXTENSION_UPDATE_NOTIFIER"] = "1"
    env["GH_PROMPT_DISABLED"] = "1"
    env["GEI_SKIP_VERSION_CHECK"] = "true"
    if target_token:
        env["GH_TOKEN"] = target_token
        env["GITHUB_TOKEN"] = target_token

    try:
        version_code, version_output = _tool_output([settings.gei_binary, "--version"], env=env)
        status["version"] = version_output.splitlines()[0] if version_output else None
        if version_code != 0:
            status["error"] = "The packaged GEI standalone executable did not run successfully"
            return status

        verify_command = [settings.gei_binary, "migrate-repo", "--help"]
        verify_code, verify_output = _tool_output(verify_command, env=env)
        if verify_code != 0:
            status["error"] = "The packaged official standalone GEI binary failed its migrate-repo readiness check"
            status["verification_output"] = verify_output[-4000:]
            return status
        status["ready"] = True
        status["verification"] = command_for_display(verify_command)
        return status
    except Exception as exc:
        status["error"] = f"Unable to verify GitHub Enterprise Importer tooling: {exc}"
        return status

def _tooling_error(run: MigrationRun, target: Connector | None = None) -> str | None:
    settings = get_settings()
    if run.method == MigrationMethod.gei:
        target_token = decrypt_secret(target.encrypted_token) if target else None
        status = gei_tooling_status(target_token=target_token)
        if not status["ready"]:
            return str(status.get("error") or "GitHub Enterprise Importer tooling is not ready")
    elif run.method == MigrationMethod.elm:
        if not shutil.which("ssh"):
            return "OpenSSH client is required to invoke the official ELM CLI on the GHES administrative shell"
    return None


def preflight_run(db: Session, run: MigrationRun) -> list[str]:
    settings = get_settings()
    errors: list[str] = []
    source = db.get(Connector, run.source_connector_id)
    target = db.get(Connector, run.target_connector_id)
    if not source or not target:
        return ["Source or target connector is missing"]
    if settings.migration_policy_mode != "github-supported-only":
        errors.append("Unsupported migration policy mode; ForgeBridge permits only GitHub-supported migration methods")
    simulated = source.kind == ConnectorKind.simulated_ghes or target.kind == ConnectorKind.simulated_ghec or run.method == MigrationMethod.simulation
    if not simulated and not settings.enable_real_migrations:
        errors.append("Real migrations are disabled. Set ENABLE_REAL_MIGRATIONS=true after completing simulation and security review")
    if not simulated:
        tooling_error = _tooling_error(run, target)
        if tooling_error:
            errors.append(tooling_error)
    if source.status != "connected":
        errors.append("Source connector has not passed a connection test")
    if target.status != "connected":
        errors.append("Target connector has not passed a connection test")
    if not source.verify_ssl or not target.verify_ssl:
        errors.append("TLS certificate verification must remain enabled for source and destination GitHub connectors")
    if source.kind not in (ConnectorKind.ghes, ConnectorKind.simulated_ghes):
        errors.append("Source connector must be GHES")
    if target.kind not in (ConnectorKind.ghec, ConnectorKind.simulated_ghec):
        errors.append("Target connector must be GHEC")
    if run.method == MigrationMethod.elm:
        if not settings.enable_elm:
            errors.append("Enterprise Live Migrations is disabled; enable it only for an eligible GHE.com enterprise after GitHub approval")
        if target.target_flavor != TargetFlavor.ghe_com:
            errors.append("Enterprise Live Migrations is supported only for a GHE.com destination with data residency")
        if not source.base_url.lower().startswith("https://"):
            errors.append("ELM requires the GHES instance to use an HTTPS URL")
        version = str(source.metadata_json.get("installed_version") or "")
        if not version:
            errors.append("GHES version could not be detected; ELM eligibility cannot be verified")
        elif not _elm_version_supported(version):
            required = ", ".join(
                f"3.{minor}.{patch}" for minor, patch in sorted(ELM_MINIMUM_PATCH_RELEASES.items())
            )
            errors.append(
                f"Detected GHES version {version}; it does not meet the embedded ELM minimum patch releases "
                f"({required})"
            )
        if run.concurrency > ELM_MAX_CONCURRENT_REPOSITORIES_PER_GHES:
            errors.append("ELM concurrency cannot exceed 10 repositories from one GHES instance")
        if not simulated and not settings.elm_ssh_host:
            errors.append("ELM_SSH_HOST is required because the official elm CLI runs from the GHES administrative shell")
    if run.method == MigrationMethod.gei:
        if run.concurrency > GEI_MAX_CONCURRENT_REPOSITORIES:
            errors.append("This ForgeBridge deployment limits GEI execution to 5 concurrent repository tasks; this is an application safety throttle, not a claimed GitHub service maximum")
        if run.mode == MigrationMode.trial and run.lock_source_at_cutover:
            errors.append("Source locking is not permitted for trial migrations")
        if run.mode == MigrationMode.production and not run.lock_source_at_cutover:
            errors.append(
                "Production GEI requires 'lock source during migration'. GEI does not support delta migrations, so an unlocked production run can lose later changes"
            )
    if not run.repositories:
        errors.append("No repositories are selected")
    for item in run.repositories:
        repository = item.repository
        if repository.readiness_status == "blocked":
            errors.append(f"{item.source_repo}: repository readiness is blocked; resolve discovery blockers and re-run discovery")
        if run.lane != MigrationLane.all and repository.pipeline_lane != run.lane.value:
            errors.append(f"{item.source_repo}: repository no longer belongs to the selected {run.lane.value} lane")
        if (repository.target_state_json or {}).get("exists") is True:
            errors.append(f"{item.source_repo}: discovery recorded an existing destination repository; choose a new target name or purge an eligible trial target")
        if item.target_repo.lower().endswith(".git"):
            errors.append(f"{item.source_repo}: target repository name must not end in .git")
        if run.mode == MigrationMode.production and not (repository.detail_json or {}).get("deep_scan_complete"):
            errors.append(f"{item.source_repo}: production migration requires a completed deep discovery scan")
        if (
            run.method == MigrationMethod.gei
            and repository.release_assets_bytes > GEI_RELEASE_DATA_LIMIT_BYTES
            and not run.skip_releases
        ):
            warning = (
                "More than 10 GiB of release assets were discovered. GitHub documents that releases above this "
                "limit cannot be migrated with GEI; use --skip-releases after repository-owner approval. "
                "The discovered total remains an API-based approximation."
            )
            existing_warnings = list((item.result_json or {}).get("preflight_warnings") or [])
            if warning not in existing_warnings:
                existing_warnings.append(warning)
            item.result_json = {**(item.result_json or {}), "preflight_warnings": existing_warnings}
        if run.method == MigrationMethod.elm and repository.largest_release_asset_bytes > ELM_RELEASE_ASSET_LIMIT_BYTES:
            errors.append(
                f"{item.source_repo}: at least one release asset exceeds the ELM 2 GiB per-asset limit"
            )
        if run.method == MigrationMethod.gei and item.repository.has_lfs:
            item.result_json = {
                **(item.result_json or {}),
                "preflight_warning": "GEI does not migrate Git LFS objects; transfer and validate them separately or use eligible ELM.",
            }
        if run.method == MigrationMethod.elm and item.repository.visibility == "public":
            errors.append(f"{item.source_repo}: public repositories are not supported on GHE.com ELM")
    db.commit()
    return errors


def _simulate_repo_migration(db: Session, run: MigrationRun, item: RepoMigration) -> dict[str, Any]:
    item.external_migration_id = f"sim-{item.id}"
    item.source_sha_at_start = item.repository.last_commit_sha
    item.target_sha_after = item.repository.last_commit_sha
    if run.method == MigrationMethod.elm:
        item.status = RepoMigrationStatus.ready_for_cutover
        message = "Simulated ELM backfill and live-update capture is ready for cutover"
    else:
        item.status = RepoMigrationStatus.completed
        message = "Simulated GEI migration completed"
    item.finished_at = utcnow()
    item.result_json = {
        **(item.result_json or {}),
        "simulation": True,
        "message": message,
        "pipeline_policy": run.pipeline_policy.value,
        "target_repository_id": f"sim-target-{item.id}",
        "expected_differences": ["GitHub-generated migration log issue for GEI"] if run.method == MigrationMethod.gei else [],
    }
    db.commit()
    return {"repo": item.source_repo, "status": item.status.value, "message": message}


def _capture_target_state(
    db: Session,
    run: MigrationRun,
    item: RepoMigration,
    target: Connector,
    target_token: str,
) -> dict[str, Any]:
    with GitHubClient(target.api_url, target_token, target.verify_ssl) as client:
        target_data = client.get_repository(run.target_org, item.target_repo)
        latest = client.get_latest_commit(run.target_org, item.target_repo, target_data.get("default_branch"))
    item.target_sha_after = (latest or {}).get("sha")
    state = {
        "target_repository_id": target_data.get("id"),
        "target_repository_node_id": target_data.get("node_id"),
        "target_default_branch": target_data.get("default_branch"),
        "target_html_url": target_data.get("html_url"),
    }
    item.result_json = {**(item.result_json or {}), **state}
    db.add(item)
    db.commit()
    return state


def migrate_repository(repo_migration_id: str) -> dict[str, Any]:
    settings = get_settings()
    db = SessionLocal()
    try:
        claim = db.execute(
            update(RepoMigration)
            .where(
                RepoMigration.id == repo_migration_id,
                RepoMigration.status.in_([RepoMigrationStatus.pending, RepoMigrationStatus.failed]),
            )
            .values(
                status=RepoMigrationStatus.running,
                attempt_count=RepoMigration.attempt_count + 1,
                started_at=utcnow(),
                finished_at=None,
                error_message=None,
            )
        )
        db.commit()
        item = db.get(RepoMigration, repo_migration_id)
        if not item:
            raise RuntimeError("Repository migration record not found")
        if claim.rowcount != 1:
            return {
                "repo_migration_id": repo_migration_id,
                "status": item.status.value,
                "ignored": True,
                "reason": "Repository migration was already claimed or is not retryable",
            }
        run = db.get(MigrationRun, item.migration_run_id)
        if not run:
            raise RuntimeError("Migration run not found")
        source = db.get(Connector, run.source_connector_id)
        target = db.get(Connector, run.target_connector_id)
        if not source or not target:
            raise RuntimeError("Migration connectors not found")
        db.refresh(item, attribute_names=["repository"])

        if source.kind == ConnectorKind.simulated_ghes or target.kind == ConnectorKind.simulated_ghec or run.method == MigrationMethod.simulation:
            return _simulate_repo_migration(db, run, item)

        source_token = decrypt_secret(source.encrypted_token)
        target_token = decrypt_secret(target.encrypted_token)
        if not source_token or not target_token:
            raise RuntimeError("Source and destination tokens are required")

        # Both GEI and ELM create a new destination repository. Never overwrite
        # or silently merge into a pre-existing repository.
        with GitHubClient(target.api_url, target_token, target.verify_ssl) as target_client:
            if target_client.repository_exists(run.target_org, item.target_repo):
                raise RuntimeError(
                    f"Destination repository {run.target_org}/{item.target_repo} already exists. "
                    "Use a new target name or run a guarded ForgeBridge purge for a prior test run."
                )
        with GitHubClient(source.api_url, source_token, source.verify_ssl) as source_client:
            source_repo_data = source_client.get_repository(run.source_org, item.source_repo)
            latest = source_client.get_latest_commit(run.source_org, item.source_repo, source_repo_data.get("default_branch"))
            item.source_sha_at_start = (latest or {}).get("sha")

        db.commit()
        log_path = settings.logs_dir / f"{item.id}-attempt-{item.attempt_count}.log"
        item.log_path = str(log_path)

        if run.method == MigrationMethod.gei:
            command = build_gei_command(run, item, source, target)
            env = dict(os.environ)
            env["GH_PAT"] = target_token
            env["GH_TARGET_PAT"] = target_token
            env["GH_SOURCE_PAT"] = source_token
            env["GITHUB_TOKEN"] = target_token
            if target.target_flavor == TargetFlavor.github_com:
                env["GH_HOST"] = "github.com"
            item.command_preview = command_for_display(command)
            db.commit()
            return_code, output = run_process(command, env, log_path, settings.command_timeout_seconds)
            item.external_migration_id = parse_external_id(output)
            if return_code != 0:
                raise RuntimeError(f"GEI command failed with exit code {return_code}. Review {log_path}")
            item.status = RepoMigrationStatus.completed
            item.finished_at = utcnow()
            item.result_json = {
                **(item.result_json or {}),
                "method": "gei",
                "external_migration_id": item.external_migration_id,
                "source_locked_by_gei": bool(run.mode == MigrationMode.production and run.lock_source_at_cutover),
                "expected_differences": ["GitHub Enterprise Importer may create a Migration Log issue when Issues are enabled."],
            }
            db.commit()
            target_state = _capture_target_state(db, run, item, target, target_token)

            if settings.gei_download_logs:
                migration_log = settings.reports_dir / f"{run.id}-{item.target_repo}-migration-log.csv"
                log_command = build_gei_download_logs_command(run, item, target, migration_log)
                log_cli_output = settings.logs_dir / f"{item.id}-download-logs.log"
                log_code, _ = run_process(log_command, env, log_cli_output, 900)
                item.result_json = {
                    **(item.result_json or {}),
                    "migration_log_path": str(migration_log) if log_code == 0 and migration_log.exists() else None,
                    "migration_log_download_status": "downloaded" if log_code == 0 else "failed",
                }
                if log_code != 0:
                    item.warning_count += 1
                    item.status = RepoMigrationStatus.warning
                db.commit()

            # This changes repository settings only. It never edits workflow files.
            if run.pipeline_policy == PipelinePolicy.preserve_disable_actions:
                with GitHubClient(target.api_url, target_token, target.verify_ssl) as target_client:
                    target_client.set_actions_enabled(run.target_org, item.target_repo, False)
                item.result_json = {**item.result_json, "actions_enabled": False}
                db.commit()
            return {
                "repo": item.source_repo,
                "status": item.status.value,
                "external_id": item.external_migration_id,
                **target_state,
            }

        if run.method == MigrationMethod.elm:
            command = build_elm_create_command(run, item, target)
            item.command_preview = command_for_display(command[:-1] + ["<remote official ELM command>"])
            db.commit()
            return_code, output = run_process(command, dict(os.environ), log_path, settings.command_timeout_seconds)
            if return_code != 0:
                raise RuntimeError(f"ELM create/start failed with exit code {return_code}. Review {log_path}")
            payload = parse_json_output(output) or {}
            migration_id = str(payload.get("migrationId") or parse_external_id(output) or "")
            if not migration_id:
                raise RuntimeError("ELM did not return a migration ID")
            item.external_migration_id = migration_id
            item.result_json = {
                **(item.result_json or {}),
                "method": "elm",
                "external_migration_id": migration_id,
                "cutover_required": True,
            }
            db.commit()
            status_log = settings.logs_dir / f"{item.id}-elm-status.log"
            monitor = poll_elm(
                migration_id,
                wait_for="ready",
                log_path=status_log,
                timeout_seconds=settings.elm_ready_timeout_seconds,
            )
            item.status = RepoMigrationStatus.ready_for_cutover
            if monitor["latest"].get("resource_failures") or monitor["latest"].get("cutover_blockers"):
                item.warning_count += 1
            item.finished_at = utcnow()
            item.result_json = {
                **(item.result_json or {}),
                "elm_status": monitor["latest"],
                "elm_status_history": monitor["snapshots"],
            }
            db.commit()
            return {"repo": item.source_repo, "status": item.status.value, "external_id": migration_id}

        raise RuntimeError(f"Unsupported migration method: {run.method.value}")
    except Exception as exc:
        db.rollback()
        item = db.get(RepoMigration, repo_migration_id)
        remediation = remediation_for_error(str(exc))
        if item:
            item.status = RepoMigrationStatus.failed
            item.error_message = str(exc)
            item.result_json = {**(item.result_json or {}), "remediation": remediation}
            item.finished_at = utcnow()
            db.commit()
        return {"repo_migration_id": repo_migration_id, "status": "failed", "error": str(exc), "remediation": remediation}
    finally:
        db.close()


def run_migration_job(db: Session, job: Job) -> dict[str, Any]:
    run_id = job.payload_json["migration_run_id"]
    retry_failed_only = bool(job.payload_json.get("retry_failed_only", False))
    run = db.get(MigrationRun, run_id)
    if not run:
        raise RuntimeError("Migration run not found")
    db.refresh(run, attribute_names=["repositories"])
    errors = preflight_run(db, run)
    if errors:
        raise RuntimeError("Migration preflight failed: " + "; ".join(errors))

    candidates = [
        item
        for item in run.repositories
        if (item.status == RepoMigrationStatus.failed if retry_failed_only else item.status in (RepoMigrationStatus.pending, RepoMigrationStatus.failed))
    ]
    if not candidates:
        raise RuntimeError("No repositories are eligible for this migration job")

    run.status = MigrationStatus.running
    run.started_at = run.started_at or utcnow()
    db.commit()
    update_job(db, job, status=JobStatus.running, progress=1, step="Migration preflight passed")
    append_job_log(job, "Migration run started", {"run_id": run.id, "repositories": len(candidates), "method": run.method.value})

    max_workers = max(1, min(
        run.concurrency,
        ELM_MAX_CONCURRENT_REPOSITORIES_PER_GHES if run.method == MigrationMethod.elm else GEI_MAX_CONCURRENT_REPOSITORIES,
        len(candidates),
    ))
    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="forgebridge-migrate") as executor:
        futures = {executor.submit(migrate_repository, item.id): item.id for item in candidates}
        completed = 0
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            completed += 1
            update_job(
                db,
                job,
                progress=max(2, int(completed / len(candidates) * 96)),
                step=f"Processed {completed} of {len(candidates)} repositories",
            )
            append_job_log(job, "Repository migration finished", result)

    db.expire_all()
    run = db.get(MigrationRun, run_id)
    assert run is not None
    db.refresh(run, attribute_names=["repositories"])
    failed = [item for item in run.repositories if item.status == RepoMigrationStatus.failed]
    ready = [item for item in run.repositories if item.status == RepoMigrationStatus.ready_for_cutover]
    completed_items = [item for item in run.repositories if item.status in (RepoMigrationStatus.completed, RepoMigrationStatus.warning)]

    if failed:
        run.status = MigrationStatus.failed if not completed_items and not ready else MigrationStatus.completed_with_warnings
    elif ready:
        run.status = MigrationStatus.ready_for_cutover
    elif any(item.status == RepoMigrationStatus.warning for item in run.repositories):
        run.status = MigrationStatus.completed_with_warnings
        run.finished_at = utcnow()
    else:
        run.status = MigrationStatus.completed
        run.finished_at = utcnow()
    db.commit()
    result = {
        "run_id": run.id,
        "status": run.status.value,
        "processed": len(results),
        "completed": len(completed_items),
        "ready_for_cutover": len(ready),
        "failed": len(failed),
        "cleanup_token": run.cleanup_token,
        "results": results,
    }
    final_status = JobStatus.failed if failed and not completed_items and not ready else JobStatus.succeeded
    update_job(
        db,
        job,
        status=final_status,
        progress=100,
        step="Migration job finished",
        result=result,
        error="One or more repositories failed" if final_status == JobStatus.failed else None,
    )
    append_job_log(job, "Migration run finished", result)
    return result


def cutover_repository(db: Session, item: RepoMigration) -> dict[str, Any]:
    settings = get_settings()
    run = db.get(MigrationRun, item.migration_run_id)
    if not run:
        raise RuntimeError("Migration run not found")
    source = db.get(Connector, run.source_connector_id)
    target = db.get(Connector, run.target_connector_id)
    if not source or not target:
        raise RuntimeError("Connectors are missing")

    if source.kind == ConnectorKind.simulated_ghes or target.kind == ConnectorKind.simulated_ghec:
        item.status = RepoMigrationStatus.completed
        item.result_json = {**(item.result_json or {}), "cutover": "simulated", "source_archived": True}
        item.finished_at = utcnow()
        db.commit()
        return {"repo": item.source_repo, "status": "completed", "source_archived": True}

    if run.method != MigrationMethod.elm:
        if run.method == MigrationMethod.gei and run.mode == MigrationMode.production and run.lock_source_at_cutover:
            return {
                "repo": item.source_repo,
                "status": item.status.value,
                "source_archived": True,
                "message": "Source locking was performed by the official GEI --lock-source-repo option during migration.",
            }
        raise RuntimeError(
            "Post-migration delta cutover is not supported for GEI. Use a production GEI run with source locking, "
            "or use eligible ELM for GHE.com."
        )

    if item.status != RepoMigrationStatus.ready_for_cutover or not item.external_migration_id:
        raise RuntimeError("Repository is not ready for ELM cutover")
    command = build_elm_cutover_command(item.external_migration_id)
    log_path = settings.logs_dir / f"{item.id}-elm-cutover.log"
    return_code, output = run_process(command, dict(os.environ), log_path, 1800)
    if return_code != 0:
        raise RuntimeError(f"ELM cutover failed. Review {log_path}")
    completion_log = settings.logs_dir / f"{item.id}-elm-completion-status.log"
    monitor = poll_elm(
        item.external_migration_id,
        wait_for="completed",
        log_path=completion_log,
        timeout_seconds=settings.elm_completion_timeout_seconds,
    )
    target_token = decrypt_secret(target.encrypted_token)
    if not target_token:
        raise RuntimeError("Target token is missing")
    target_state = _capture_target_state(db, run, item, target, target_token)
    if run.pipeline_policy == PipelinePolicy.preserve_disable_actions:
        with GitHubClient(target.api_url, target_token, target.verify_ssl) as target_client:
            target_client.set_actions_enabled(run.target_org, item.target_repo, False)
    item.status = RepoMigrationStatus.completed
    item.result_json = {
        **(item.result_json or {}),
        "cutover_output": output[-10000:],
        "elm_completion": monitor["latest"],
        "elm_completion_history": monitor["snapshots"],
        "source_archived": True,
        "actions_enabled": run.pipeline_policy != PipelinePolicy.preserve_disable_actions,
    }
    item.finished_at = utcnow()
    db.commit()
    return {"repo": item.source_repo, "status": "completed", "source_archived": True, **target_state}


def run_cutover_job(db: Session, job: Job) -> dict[str, Any]:
    run = db.get(MigrationRun, job.payload_json["migration_run_id"])
    if not run:
        raise RuntimeError("Migration run not found")
    db.refresh(run, attribute_names=["repositories"])
    selected_ids = set(job.payload_json.get("repo_migration_ids") or [])
    items = [item for item in run.repositories if not selected_ids or item.id in selected_ids]
    if not items:
        raise RuntimeError("No repositories selected for cutover")
    update_job(db, job, status=JobStatus.running, progress=1, step="Starting cutover")
    results: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        try:
            result = cutover_repository(db, item)
            results.append(result)
        except Exception as exc:
            item.error_message = str(exc)
            db.add(item)
            db.commit()
            failure = {"repo": item.source_repo, "status": "failed", "error": str(exc)}
            results.append(failure)
            failures.append(failure)
        update_job(db, job, progress=int(index / len(items) * 95), step=f"Cut over {item.source_repo}")
    db.expire_all()
    run = db.get(MigrationRun, run.id)
    assert run is not None
    db.refresh(run, attribute_names=["repositories"])
    if all(item.status in (RepoMigrationStatus.completed, RepoMigrationStatus.warning) for item in run.repositories):
        run.status = MigrationStatus.completed_with_warnings if any(item.status == RepoMigrationStatus.warning for item in run.repositories) else MigrationStatus.completed
        run.finished_at = utcnow()
    elif failures:
        run.status = MigrationStatus.completed_with_warnings
    db.commit()
    result = {"run_id": run.id, "status": run.status.value, "results": results, "failed": len(failures)}
    update_job(
        db,
        job,
        status=JobStatus.failed if failures else JobStatus.succeeded,
        progress=100,
        step="Cutover finished",
        result=result,
        error="One or more cutovers failed" if failures else None,
    )
    return result
