from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

import httpx
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import AIConfiguration, Job, JobStatus, utcnow
from app.security import decrypt_secret
from app.services.job_utils import append_job_log, update_job
from app.services.url_validation import validate_azure_openai_endpoint


SECRET_TEXT = re.compile(
    r"(?i)(authorization\s*[:=]\s*bearer\s+\S+|gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+|api[-_ ]?key\s*[:=]\s*\S+|token\s*[:=]\s*\S+|password\s*[:=]\s*\S+)"
)
SENSITIVE_FIELD = re.compile(
    r"(?i)(authorization|password|passwd|secret|token|api[_-]?key|private[_-]?key|client[_-]?secret|connection[_-]?string|encrypted_.+)"
)


def sanitize_text(value: str, limit: int) -> str:
    value = SECRET_TEXT.sub("***REDACTED***", value)
    return value[:limit]


def sanitize_evidence(value: Any, *, string_limit: int = 20_000) -> Any:
    """Recursively redact credential-bearing fields before AI submission.

    This is defense in depth: ForgeBridge should not persist credentials in job
    results or logs, but AI input must not rely on that assumption.
    """

    if isinstance(value, dict):
        sanitized: dict[str, Any] = {}
        for key, item in value.items():
            key_text = str(key)
            sanitized[key_text] = (
                "***REDACTED***"
                if SENSITIVE_FIELD.search(key_text)
                else sanitize_evidence(item, string_limit=string_limit)
            )
        return sanitized
    if isinstance(value, list):
        return [sanitize_evidence(item, string_limit=string_limit) for item in value]
    if isinstance(value, tuple):
        return [sanitize_evidence(item, string_limit=string_limit) for item in value]
    if isinstance(value, str):
        return sanitize_text(value, string_limit)
    return value


def _managed_identity_token_request(
    url: str,
    *,
    headers: dict[str, str],
    params: dict[str, str],
) -> str:
    """Request an Azure managed-identity token without an SDK dependency.

    Only process-controlled Azure identity endpoints are used. No endpoint value
    is accepted from the ForgeBridge web UI or from model output.
    """

    with httpx.Client(timeout=10.0, follow_redirects=False) as client:
        response = client.get(url, headers=headers, params=params)
    if 300 <= response.status_code < 400:
        raise RuntimeError("Azure managed-identity redirect was refused")
    if response.status_code >= 400:
        raise RuntimeError(
            f"Azure managed identity returned {response.status_code}: {response.text[:1000]}"
        )
    try:
        payload = response.json()
    except Exception as exc:
        raise RuntimeError("Azure managed identity returned a non-JSON response") from exc
    token = payload.get("access_token")
    if not isinstance(token, str) or not token:
        raise RuntimeError("Azure managed identity response did not contain an access token")
    return token


def _access_token() -> str:
    # Explicit deployment injection is useful for controlled test environments;
    # it is never displayed or persisted by ForgeBridge.
    injected = os.getenv("AZURE_ACCESS_TOKEN", "").strip()
    if injected:
        return injected

    resource = "https://cognitiveservices.azure.com/"
    client_id = os.getenv("AZURE_CLIENT_ID", "").strip()

    identity_endpoint = os.getenv("IDENTITY_ENDPOINT", "").strip()
    identity_header = os.getenv("IDENTITY_HEADER", "").strip()
    if identity_endpoint and identity_header:
        params = {"api-version": "2019-08-01", "resource": resource}
        if client_id:
            params["client_id"] = client_id
        return _managed_identity_token_request(
            identity_endpoint,
            headers={"X-IDENTITY-HEADER": identity_header},
            params=params,
        )

    msi_endpoint = os.getenv("MSI_ENDPOINT", "").strip()
    msi_secret = os.getenv("MSI_SECRET", "").strip()
    if msi_endpoint and msi_secret:
        params = {"api-version": "2017-09-01", "resource": resource}
        if client_id:
            params["clientid"] = client_id
        return _managed_identity_token_request(
            msi_endpoint,
            headers={"Secret": msi_secret},
            params=params,
        )

    params = {"api-version": "2018-02-01", "resource": resource}
    if client_id:
        params["client_id"] = client_id
    return _managed_identity_token_request(
        "http://169.254.169.254/metadata/identity/oauth2/token",
        headers={"Metadata": "true"},
        params=params,
    )


def _output_text(payload: dict[str, Any]) -> str:
    if isinstance(payload.get("output_text"), str):
        return payload["output_text"]
    parts: list[str] = []
    for output in payload.get("output") or []:
        for content in output.get("content") or []:
            text = content.get("text")
            if isinstance(text, str):
                parts.append(text)
    return "\n".join(parts).strip()


def call_azure_openai(config: AIConfiguration, instructions: str, input_text: str) -> dict[str, Any]:
    settings = get_settings()
    if not config.enabled:
        raise RuntimeError("Azure OpenAI integration is disabled")
    if not config.endpoint or not config.deployment:
        raise RuntimeError("Azure OpenAI endpoint and deployment are required")
    endpoint = validate_azure_openai_endpoint(config.endpoint)
    if endpoint.endswith("/openai/v1"):
        url = endpoint + "/responses"
    else:
        url = endpoint + "/openai/v1/responses"

    headers = {"Content-Type": "application/json"}
    if config.auth_mode == "api_key":
        key = decrypt_secret(config.encrypted_api_key)
        if not key:
            raise RuntimeError("Azure OpenAI API key is not configured")
        headers["api-key"] = key
    else:
        headers["Authorization"] = f"Bearer {_access_token()}"

    body = {
        "model": config.deployment,
        "instructions": instructions,
        "input": sanitize_text(input_text, min(config.max_input_chars, settings.ai_max_log_chars)),
        "max_output_tokens": config.max_output_tokens,
        "store": False,
    }
    with httpx.Client(timeout=settings.ai_request_timeout_seconds, follow_redirects=False) as client:
        response = client.post(url, headers=headers, json=body)
    if 300 <= response.status_code < 400:
        raise RuntimeError("Azure OpenAI redirect was refused to protect credentials")
    if response.status_code >= 400:
        message = response.text[:2000]
        try:
            message = response.json().get("error", {}).get("message", message)
        except Exception:
            pass
        raise RuntimeError(f"Azure OpenAI returned {response.status_code}: {message}")
    payload = response.json()
    return {
        "text": _output_text(payload),
        "response_id": payload.get("id"),
        "model": payload.get("model") or config.deployment,
        "usage": payload.get("usage") or {},
    }


def run_ai_test_job(db: Session, job: Job) -> dict[str, Any]:
    config = db.get(AIConfiguration, 1)
    if not config:
        raise RuntimeError("AI configuration not found")
    update_job(db, job, status=JobStatus.running, progress=15, step="Testing Azure OpenAI configuration")
    result = call_azure_openai(
        config,
        "You are a connectivity test. Return exactly the words ForgeBridge AI connected.",
        "Confirm connectivity without using tools or adding explanation.",
    )
    config.status = "connected"
    config.status_message = result.get("text") or "Connected"
    config.last_tested_at = utcnow()
    config.metadata_json = {"model": result.get("model"), "response_id": result.get("response_id")}
    db.add(config)
    db.commit()
    append_job_log(job, "Azure OpenAI connection test completed", {"model": result.get("model")})
    update_job(db, job, status=JobStatus.succeeded, progress=100, step="AI connection test complete", result=result)
    return result


def run_ai_interpret_job(db: Session, job: Job) -> dict[str, Any]:
    config = db.get(AIConfiguration, 1)
    if not config:
        raise RuntimeError("AI configuration not found")
    allowed_use_cases = set(config.allowed_use_cases_json or [])
    if "job_interpretation" not in allowed_use_cases:
        raise RuntimeError("AI job interpretation is not enabled in the administrator allowlist")
    source_job = db.get(Job, job.payload_json.get("source_job_id"))
    if not source_job:
        raise RuntimeError("Source job not found")
    update_job(db, job, status=JobStatus.running, progress=10, step="Preparing sanitized job evidence")
    evidence: dict[str, Any] = {
        "job_id": source_job.id,
        "kind": source_job.kind,
        "status": source_job.status.value,
        "current_step": source_job.current_step,
        "error_message": source_job.error_message,
        "result": source_job.result_json,
    }
    if source_job.log_path and Path(source_job.log_path).exists():
        evidence["log_tail"] = Path(source_job.log_path).read_text(encoding="utf-8", errors="replace")[-config.max_input_chars :]
    evidence = sanitize_evidence(evidence, string_limit=min(config.max_input_chars, get_settings().ai_max_log_chars))
    administrator_guardrail = (config.system_prompt or "").strip()
    instructions = (
        (administrator_guardrail + "\n\n") if administrator_guardrail else ""
    ) + (
        "You are the ForgeBridge migration operations assistant. Interpret only the supplied sanitized evidence. "
        "Do not claim that data migrated unless the evidence proves it. Produce sections: Summary, Likely cause, "
        "Evidence, Safe remediation, Retry decision, and Escalation. Never suggest deleting source repositories, "
        "bypassing GitHub-supported migration methods, or exposing credentials. State uncertainty explicitly. "
        "Your response is advisory and cannot authorize or execute a migration, source freeze, cutover, or purge."
    )
    result = call_azure_openai(config, instructions, json.dumps(evidence, default=str))
    result["source_job_id"] = source_job.id
    append_job_log(job, "AI interpretation completed", {"source_job_id": source_job.id, "model": result.get("model")})
    update_job(db, job, status=JobStatus.succeeded, progress=100, step="AI interpretation complete", result=result)
    return result
