from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Job, JobStatus, utcnow
from app.security import redact_for_persistence, redact_text


def update_job(
    db: Session,
    job: Job,
    *,
    status: JobStatus | None = None,
    progress: int | None = None,
    step: str | None = None,
    result: dict[str, Any] | None = None,
    error: str | None = None,
) -> None:
    if status is not None:
        job.status = status
        if status == JobStatus.running and job.started_at is None:
            job.started_at = utcnow()
        if status in (JobStatus.succeeded, JobStatus.failed, JobStatus.cancelled):
            job.finished_at = utcnow()
    if progress is not None:
        job.progress = max(0, min(100, progress))
    if step is not None:
        job.current_step = step
    if result is not None:
        job.result_json = redact_for_persistence(result)
    if error is not None:
        job.error_message = redact_text(error)
    db.add(job)
    db.commit()


def append_job_log(job: Job, message: str, data: dict[str, Any] | None = None) -> None:
    settings = get_settings()
    if not job.log_path:
        job.log_path = str(settings.logs_dir / f"{job.id}.jsonl")
    path = Path(job.log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "time": utcnow().isoformat(),
        "message": redact_text(message),
        "data": redact_for_persistence(data or {}),
    }
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, default=str) + "\n")
