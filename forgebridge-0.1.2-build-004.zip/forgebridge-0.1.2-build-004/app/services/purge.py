from __future__ import annotations

from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import (
    Connector,
    ConnectorKind,
    Job,
    JobStatus,
    MigrationMode,
    MigrationRun,
    MigrationStatus,
    PurgeRun,
    RepoMigrationStatus,
    utcnow,
)
from app.security import decrypt_secret
from app.services.github_client import GitHubApiError, GitHubClient
from app.services.job_utils import append_job_log, update_job


def run_purge_job(db: Session, job: Job) -> dict:
    settings = get_settings()
    purge = db.get(PurgeRun, job.payload_json["purge_run_id"])
    if not purge:
        raise RuntimeError("Purge run not found")
    run = db.get(MigrationRun, purge.migration_run_id)
    if not run:
        raise RuntimeError("Migration run not found")
    if purge.cleanup_token_used != run.cleanup_token:
        raise RuntimeError("Cleanup token does not match this migration run")
    target = db.get(Connector, run.target_connector_id)
    if not target:
        raise RuntimeError("Target connector not found")
    db.refresh(run, attribute_names=["repositories"])
    selected_ids = {str(value) for value in (purge.scope_json or {}).get("repo_migration_ids", [])}
    if not selected_ids:
        raise RuntimeError("An explicit destination repository selection is required for purge")
    items = [item for item in run.repositories if item.id in selected_ids]
    if not items:
        raise RuntimeError("No eligible migration repositories were selected for purge")

    simulated = target.kind == ConnectorKind.simulated_ghec
    if not purge.dry_run and not simulated:
        if run.mode != MigrationMode.trial:
            raise RuntimeError("Destructive target cleanup is restricted to trial migration runs")
        if not settings.enable_destructive_purge:
            raise RuntimeError("Destructive purge is disabled. Set ENABLE_DESTRUCTIVE_PURGE=true only for an approved test window")

    purge.status = JobStatus.running
    db.commit()
    update_job(db, job, status=JobStatus.running, progress=1, step="Purge safety checks passed")
    results: list[dict] = []

    if simulated:
        for index, item in enumerate(items, start=1):
            expected_id = (item.result_json or {}).get("target_repository_id")
            if not expected_id:
                results.append({"repo": item.target_repo, "action": "blocked", "status": "missing_target_identity"})
            elif purge.dry_run:
                results.append({"repo": item.target_repo, "action": "would_delete", "status": "safe", "expected_id": expected_id})
            else:
                item.status = RepoMigrationStatus.purged
                db.add(item)
                results.append({"repo": item.target_repo, "action": "deleted", "status": "simulated", "expected_id": expected_id})
            update_job(db, job, progress=int(index / max(len(items), 1) * 95), step=f"Checked {item.target_repo}")
        db.commit()
    else:
        token = decrypt_secret(target.encrypted_token)
        if not token:
            raise RuntimeError("Target token is missing")
        with GitHubClient(target.api_url, token, target.verify_ssl) as client:
            for index, item in enumerate(items, start=1):
                expected_id = (item.result_json or {}).get("target_repository_id")
                try:
                    if not expected_id:
                        results.append({"repo": item.target_repo, "action": "blocked", "status": "missing_target_identity"})
                    elif not client.repository_exists(run.target_org, item.target_repo):
                        results.append({"repo": item.target_repo, "action": "skip", "status": "not_found"})
                    else:
                        target_data = client.get_repository(run.target_org, item.target_repo)
                        actual_id = target_data.get("id")
                        if str(expected_id) != str(actual_id):
                            results.append(
                                {
                                    "repo": item.target_repo,
                                    "action": "blocked",
                                    "status": "repository_identity_changed",
                                    "expected_id": expected_id,
                                    "actual_id": actual_id,
                                }
                            )
                        elif purge.dry_run:
                            results.append(
                                {
                                    "repo": item.target_repo,
                                    "action": "would_delete",
                                    "status": "safe",
                                    "expected_id": expected_id,
                                    "actual_id": actual_id,
                                }
                            )
                        else:
                            client.delete_repository(run.target_org, item.target_repo)
                            item.status = RepoMigrationStatus.purged
                            db.add(item)
                            results.append({"repo": item.target_repo, "action": "deleted", "status": "success", "actual_id": actual_id})
                except GitHubApiError as exc:
                    results.append({"repo": item.target_repo, "action": "failed", "status": str(exc)})
                db.commit()
                update_job(db, job, progress=int(index / max(len(items), 1) * 95), step=f"Processed {item.target_repo}")
                append_job_log(job, "Purge repository result", results[-1])

    purge.deleted_count = sum(1 for item in results if item["action"] == "deleted")
    purge.skipped_count = sum(1 for item in results if item["action"] in ("skip", "would_delete"))
    purge.failed_count = sum(1 for item in results if item["action"] in ("failed", "blocked"))
    purge.result_json = {
        "repositories": results,
        "source_touched": False,
        "safety_model": "cleanup token + run ownership + captured destination repository ID + explicit confirmation",
    }
    purge.status = JobStatus.failed if purge.failed_count else JobStatus.succeeded
    purge.finished_at = utcnow()
    if not purge.dry_run and purge.failed_count == 0:
        if all(item.status == RepoMigrationStatus.purged for item in run.repositories):
            run.status = MigrationStatus.purged
            db.add(run)
    db.commit()
    result = {
        "purge_run_id": purge.id,
        "dry_run": purge.dry_run,
        "deleted": purge.deleted_count,
        "skipped": purge.skipped_count,
        "failed": purge.failed_count,
        "source_touched": False,
        "repositories": results,
    }
    update_job(
        db,
        job,
        status=purge.status,
        progress=100,
        step="Purge complete",
        result=result,
        error="One or more repositories were not purged" if purge.failed_count else None,
    )
    return result
