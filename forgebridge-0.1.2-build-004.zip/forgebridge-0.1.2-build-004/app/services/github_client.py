from __future__ import annotations

import base64
import re
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, urlparse

import httpx

from app.config import get_settings


class GitHubApiError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None, response_text: str | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_text = response_text


@dataclass
class GitHubIdentity:
    login: str
    name: str | None
    email: str | None
    scopes: list[str]


class GitHubClient:
    def __init__(self, api_url: str, token: str, verify_ssl: bool = True, timeout: float = 60.0):
        self.api_url = api_url.rstrip("/")
        self.token = token
        self.verify_ssl = verify_ssl
        self.settings = get_settings()
        self.client = httpx.Client(
            base_url=self.api_url,
            verify=verify_ssl,
            timeout=httpx.Timeout(timeout, connect=20.0),
            follow_redirects=False,
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {token}",
                "X-GitHub-Api-Version": self.settings.github_api_version,
                "User-Agent": f"{self.settings.app_name}/{self.settings.app_version}",
            },
        )

    def close(self) -> None:
        self.client.close()

    def __enter__(self) -> "GitHubClient":
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()

    def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        max_attempts = 4
        last_error: Exception | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                response = self.client.request(method, path, **kwargs)
            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout, httpx.RemoteProtocolError) as exc:
                last_error = exc
                if attempt == max_attempts:
                    raise GitHubApiError(f"GitHub API request failed after {attempt} attempts: {exc}") from exc
                time.sleep(min(8.0, 0.5 * (2 ** (attempt - 1))))
                continue
            except httpx.HTTPError as exc:
                raise GitHubApiError(f"GitHub API request failed: {exc}") from exc

            retryable = response.status_code in (429, 502, 503, 504)
            rate_limited = response.status_code == 403 and response.headers.get("x-ratelimit-remaining") == "0"
            if (retryable or rate_limited) and attempt < max_attempts:
                retry_after = response.headers.get("retry-after")
                wait_seconds: float
                if retry_after and retry_after.isdigit():
                    wait_seconds = min(60.0, float(retry_after))
                elif rate_limited and response.headers.get("x-ratelimit-reset", "").isdigit():
                    wait_seconds = min(60.0, max(1.0, float(response.headers["x-ratelimit-reset"]) - time.time()))
                else:
                    wait_seconds = min(8.0, 0.5 * (2 ** (attempt - 1)))
                time.sleep(wait_seconds)
                continue

            if 300 <= response.status_code < 400:
                location = response.headers.get("location", "")
                raise GitHubApiError(
                    f"GitHub API redirect was refused to protect the bearer token: {location or response.status_code}",
                    status_code=response.status_code,
                )

            if response.status_code >= 400:
                message = response.text[:2000]
                try:
                    payload = response.json()
                    message = payload.get("message", message)
                except Exception:
                    pass
                raise GitHubApiError(
                    f"GitHub API returned {response.status_code}: {message}",
                    status_code=response.status_code,
                    response_text=response.text[:4000],
                )
            return response
        raise GitHubApiError(f"GitHub API request failed: {last_error or 'unknown error'}")

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        response = self._request("GET", path, params=params)
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    def patch(self, path: str, json: dict[str, Any]) -> Any:
        response = self._request("PATCH", path, json=json)
        return response.json() if response.content else None

    def put(self, path: str, json: dict[str, Any] | None = None) -> Any:
        response = self._request("PUT", path, json=json or {})
        return response.json() if response.content else None

    def delete(self, path: str) -> None:
        self._request("DELETE", path)

    def paginate(self, path: str, params: dict[str, Any] | None = None, max_items: int | None = None) -> list[Any]:
        items: list[Any] = []
        page = 1
        base_params = dict(params or {})
        base_params.setdefault("per_page", 100)
        while True:
            base_params["page"] = page
            response = self._request("GET", path, params=base_params)
            payload = response.json()
            if isinstance(payload, dict):
                for key in ("repositories", "workflows", "secrets", "variables", "environments"):
                    if key in payload and isinstance(payload[key], list):
                        batch = payload[key]
                        break
                else:
                    batch = []
            else:
                batch = payload
            items.extend(batch)
            if max_items is not None and len(items) >= max_items:
                return items[:max_items]
            if len(batch) < int(base_params["per_page"]):
                break
            page += 1
        return items

    def count_endpoint(self, path: str, params: dict[str, Any] | None = None) -> int:
        params = dict(params or {})
        params["per_page"] = 1
        params["page"] = 1
        response = self._request("GET", path, params=params)
        payload = response.json()
        if isinstance(payload, dict):
            for key in ("total_count", "totalCount"):
                if key in payload:
                    return int(payload[key])
            for key in ("repositories", "workflows", "secrets", "variables", "environments"):
                if key in payload and isinstance(payload[key], list):
                    batch = payload[key]
                    break
            else:
                batch = []
        else:
            batch = payload
        link = response.headers.get("link", "")
        match = re.search(r"[?&]page=(\d+)[^>]*>; rel=\"last\"", link)
        if match:
            return int(match.group(1))
        return len(batch)

    def identity(self) -> GitHubIdentity:
        response = self._request("GET", "/user")
        payload = response.json()
        scopes_header = response.headers.get("x-oauth-scopes", "")
        scopes = [scope.strip() for scope in scopes_header.split(",") if scope.strip()]
        return GitHubIdentity(
            login=payload.get("login", "unknown"),
            name=payload.get("name"),
            email=payload.get("email"),
            scopes=scopes,
        )

    def meta(self) -> dict[str, Any]:
        try:
            return self.get("/meta") or {}
        except GitHubApiError:
            return {}

    def org(self, org: str) -> dict[str, Any]:
        return self.get(f"/orgs/{org}")

    def list_user_organizations(self) -> list[dict[str, Any]]:
        return self.paginate("/user/orgs", {"sort": "full_name", "direction": "asc"})

    def list_org_repositories(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/repos", {"type": "all", "sort": "full_name", "direction": "asc"})

    def list_org_teams(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/teams")

    def list_org_members(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/members", {"filter": "all"})

    def list_outside_collaborators(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/outside_collaborators", {"filter": "all"})

    def list_org_hooks(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/hooks")

    def list_org_rulesets(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/rulesets")

    def list_org_secret_names(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/actions/secrets")

    def list_org_variables(self, org: str) -> list[dict[str, Any]]:
        return self.paginate(f"/orgs/{org}/actions/variables")

    def get_repository(self, org: str, repo: str) -> dict[str, Any]:
        return self.get(f"/repos/{org}/{repo}")

    def get_latest_commit(self, org: str, repo: str, branch: str | None = None) -> dict[str, Any] | None:
        params = {"sha": branch} if branch else None
        commits = self.paginate(f"/repos/{org}/{repo}/commits", params, max_items=1)
        return commits[0] if commits else None

    def get_content_text(self, org: str, repo: str, path: str, ref: str | None = None) -> str | None:
        params = {"ref": ref} if ref else None
        try:
            payload = self.get(f"/repos/{org}/{repo}/contents/{path}", params=params)
        except GitHubApiError as exc:
            if exc.status_code == 404:
                return None
            raise
        if not isinstance(payload, dict) or payload.get("type") != "file":
            return None
        content = payload.get("content", "")
        encoding = payload.get("encoding")
        if encoding == "base64":
            return base64.b64decode(content).decode("utf-8", errors="replace")
        return str(content)

    def list_branches(self, org: str, repo: str) -> list[dict[str, Any]]:
        return self.paginate(f"/repos/{org}/{repo}/branches")

    def list_collaborators(self, org: str, repo: str, max_items: int = 500) -> list[dict[str, Any]]:
        return self.paginate(f"/repos/{org}/{repo}/collaborators", {"affiliation": "all"}, max_items=max_items)

    def list_contributors(self, org: str, repo: str, max_items: int = 500) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/contributors", {"anon": "true"}, max_items=max_items)
        except GitHubApiError as exc:
            if exc.status_code in (202, 204, 403, 404, 409):
                return []
            raise

    def list_webhooks(self, org: str, repo: str) -> list[dict[str, Any]]:
        return self.paginate(f"/repos/{org}/{repo}/hooks")

    def list_deploy_keys(self, org: str, repo: str) -> list[dict[str, Any]]:
        return self.paginate(f"/repos/{org}/{repo}/keys")

    def get_actions_permissions(self, org: str, repo: str) -> dict[str, Any]:
        try:
            return self.get(f"/repos/{org}/{repo}/actions/permissions") or {}
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return {}
            raise

    def list_releases(self, org: str, repo: str) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/releases")
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return []
            raise

    def list_workflows(self, org: str, repo: str) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/actions/workflows")
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return []
            raise

    def list_secret_names(self, org: str, repo: str) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/actions/secrets")
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return []
            raise

    def list_variables(self, org: str, repo: str) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/actions/variables")
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return []
            raise

    def list_environments(self, org: str, repo: str) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/environments")
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return []
            raise

    def list_refs(self, org: str, repo: str, namespace: str) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/git/matching-refs/{namespace}")
        except GitHubApiError as exc:
            if exc.status_code == 409:
                return []
            raise

    def list_open_pull_requests(self, org: str, repo: str, max_items: int = 500) -> list[dict[str, Any]]:
        try:
            return self.paginate(
                f"/repos/{org}/{repo}/pulls",
                {"state": "open", "sort": "updated", "direction": "desc"},
                max_items=max_items,
            )
        except GitHubApiError as exc:
            if exc.status_code in (403, 404, 409):
                return []
            raise

    def list_repository_rulesets(self, org: str, repo: str) -> list[dict[str, Any]]:
        try:
            return self.paginate(f"/repos/{org}/{repo}/rulesets")
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return []
            raise

    def get_branch_protection(self, org: str, repo: str, branch: str) -> dict[str, Any]:
        try:
            return self.get(f"/repos/{org}/{repo}/branches/{branch}/protection") or {}
        except GitHubApiError as exc:
            if exc.status_code in (403, 404):
                return {}
            raise

    def get_git_tree(self, org: str, repo: str, tree_sha: str, recursive: bool = True) -> dict[str, Any]:
        params = {"recursive": "1"} if recursive else None
        return self.get(f"/repos/{org}/{repo}/git/trees/{tree_sha}", params=params) or {}

    def get_recursive_tree(self, org: str, repo: str, treeish: str) -> dict[str, Any]:
        """Return a recursive Git tree without downloading blob contents."""
        try:
            payload = self.get(f"/repos/{org}/{repo}/git/trees/{treeish}", params={"recursive": "1"})
            return payload if isinstance(payload, dict) else {"tree": [], "truncated": False}
        except GitHubApiError as exc:
            if exc.status_code in (404, 409, 422):
                return {"tree": [], "truncated": False, "unavailable": True}
            raise

    def list_large_files(
        self,
        org: str,
        repo: str,
        treeish: str,
        *,
        warning_bytes: int,
        top_n: int = 100,
    ) -> dict[str, Any]:
        tree = self.get_recursive_tree(org, repo, treeish)
        files = [
            {"path": item.get("path"), "size_bytes": int(item.get("size") or 0), "sha": item.get("sha")}
            for item in (tree.get("tree") or [])
            if item.get("type") == "blob" and int(item.get("size") or 0) >= warning_bytes
        ]
        files.sort(key=lambda item: item["size_bytes"], reverse=True)
        return {
            "files": files[:top_n],
            "count": len(files),
            "largest_bytes": files[0]["size_bytes"] if files else 0,
            "truncated": bool(tree.get("truncated")),
            "tree_unavailable": bool(tree.get("unavailable")),
        }

    def archive_repository(self, org: str, repo: str) -> dict[str, Any]:
        return self.patch(f"/repos/{org}/{repo}", {"archived": True})

    def set_actions_enabled(self, org: str, repo: str, enabled: bool) -> None:
        if enabled:
            self.put(f"/repos/{org}/{repo}/actions/permissions", {"enabled": True, "allowed_actions": "all"})
        else:
            self.put(f"/repos/{org}/{repo}/actions/permissions", {"enabled": False})

    def delete_repository(self, org: str, repo: str) -> None:
        self.delete(f"/repos/{org}/{repo}")

    def repository_exists(self, org: str, repo: str) -> bool:
        try:
            self.get_repository(org, repo)
            return True
        except GitHubApiError as exc:
            if exc.status_code == 404:
                return False
            raise

    def graphql(self, query: str, variables: dict[str, Any]) -> dict[str, Any]:
        response = self._request("POST", "/graphql", json={"query": query, "variables": variables})
        payload = response.json()
        if payload.get("errors"):
            raise GitHubApiError(f"GraphQL error: {payload['errors']}")
        return payload.get("data", {})
