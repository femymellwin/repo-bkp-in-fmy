from __future__ import annotations

from typing import Any


_RULES: list[tuple[tuple[str, ...], dict[str, Any]]] = [
    (("already exists", "destination repository"), {
        "code": "TARGET_REPOSITORY_EXISTS",
        "likely_cause": "The destination name is occupied, often by an earlier trial migration.",
        "recommended_actions": [
            "Confirm the existing repository is from the intended ForgeBridge trial run.",
            "Use the guarded dry-run purge and verify the captured destination repository ID.",
            "Otherwise choose a new destination repository name; never overwrite an unrelated repository.",
        ],
    }),
    (("rate limit", "secondary rate", "429"), {
        "code": "GITHUB_RATE_LIMIT",
        "likely_cause": "GitHub API primary or secondary rate limiting was reached.",
        "recommended_actions": [
            "Review the response headers and job log for reset or retry-after details.",
            "Reduce repository concurrency and avoid overlapping deep discoveries.",
            "Use a dedicated migration identity and retry the failed repositories after the limit resets.",
        ],
    }),
    (("401", "bad credentials", "token"), {
        "code": "AUTHENTICATION_OR_TOKEN",
        "likely_cause": "A PAT is invalid, expired, not SSO-authorized, or encrypted with a different application key.",
        "recommended_actions": [
            "Rotate the connector token and run the connector test again.",
            "Authorize the PAT for the destination organization SAML SSO policy where applicable.",
            "Confirm TOKEN_ENCRYPTION_KEY has not changed since the credential was stored.",
        ],
    }),
    (("403", "forbidden", "resource not accessible"), {
        "code": "INSUFFICIENT_PERMISSION",
        "likely_cause": "The migration identity lacks a required organization role, PAT scope, IP allow-list access, or repository permission.",
        "recommended_actions": [
            "Confirm source organization-owner access and destination organization-owner or migrator-role access.",
            "Verify the classic PAT scopes required by the selected GitHub migration method.",
            "Check SSO authorization and organization or enterprise IP allow lists.",
        ],
    }),
    (("migration log", "download-logs"), {
        "code": "MIGRATION_LOG_DOWNLOAD",
        "likely_cause": "The migration completed but the GEI migration log could not be downloaded.",
        "recommended_actions": [
            "Download the log promptly with the official gh-gei command.",
            "Check the destination token and organization access.",
            "Review the GitHub-generated Migration Log issue in the destination repository when present.",
        ],
    }),
    (("lfs",), {
        "code": "GIT_LFS_REMEDIATION",
        "likely_cause": "Git LFS content requires a separate supported transfer or validation path for GEI.",
        "recommended_actions": [
            "Inventory all LFS pointers and object counts before cutover.",
            "Transfer LFS objects through the approved Git LFS process and verify object retrieval from GHEC.",
            "Do not approve final validation until every referenced LFS object can be downloaded.",
        ],
    }),
    (("timeout", "timed out"), {
        "code": "OPERATION_TIMEOUT",
        "likely_cause": "A large archive, slow network path, overloaded appliance, or long-running GitHub operation exceeded the configured worker timeout.",
        "recommended_actions": [
            "Inspect the complete CLI log before retrying.",
            "Confirm the migration may still be active in GitHub and avoid starting a duplicate run.",
            "Increase the approved timeout only after checking storage, appliance load, archive size, and GitHub status.",
        ],
    }),
    (("no delta", "delta", "post-migration"), {
        "code": "UNSUPPORTED_GEI_DELTA",
        "likely_cause": "A delta or post-migration cutover was requested for standard GEI.",
        "recommended_actions": [
            "For github.com, schedule a maintenance window and run production GEI with source locking.",
            "For an eligible GHE.com data-residency destination, evaluate Enterprise Live Migrations.",
            "Do not build an unofficial Git push or metadata merge as a substitute for GEI delta migration.",
        ],
    }),
    (("elm", "ready for cutover", "cutover blocker"), {
        "code": "ELM_STATE_OR_BLOCKER",
        "likely_cause": "The ELM migration is not in the required state, has blockers, or the official CLI could not complete the transition.",
        "recommended_actions": [
            "Review the latest official ELM status payload and failed resources.",
            "Resolve all cutover blockers and confirm source/destination connectivity.",
            "Retry only through the documented ELM CLI workflow; do not manually mutate migration state.",
        ],
    }),
    (("ssl", "certificate"), {
        "code": "TLS_CERTIFICATE",
        "likely_cause": "The GHES certificate chain is not trusted by the worker host.",
        "recommended_actions": [
            "Use a publicly trusted certificate on the endpoint and keep TLS verification enabled.",
            "Correct the endpoint certificate chain or approved network trust path; this build does not disable TLS verification.",
            "Re-run the connector test after correcting trust configuration.",
        ],
    }),
    (("position", "repository identity changed"), {
        "code": "PURGE_IDENTITY_MISMATCH",
        "likely_cause": "The destination repository no longer has the database ID captured by this migration run.",
        "recommended_actions": [
            "Stop cleanup and investigate who deleted or recreated the repository.",
            "Never bypass the repository-ID guard.",
            "Use a new migration run after the destination namespace is safely prepared.",
        ],
    }),
]


def remediation_for_error(message: str | None) -> dict[str, Any]:
    text = (message or "").lower()
    for terms, payload in _RULES:
        if any(term in text for term in terms):
            return payload
    return {
        "code": "UNCLASSIFIED_MIGRATION_ERROR",
        "likely_cause": "The available error text is not specific enough for an automatic diagnosis.",
        "recommended_actions": [
            "Review the complete job and official-tool logs, not only the UI summary.",
            "Confirm connector health, tool version, source/target state, storage capacity, and GitHub service status.",
            "Preserve the failed run evidence and retry only after the cause is understood.",
        ],
    }
