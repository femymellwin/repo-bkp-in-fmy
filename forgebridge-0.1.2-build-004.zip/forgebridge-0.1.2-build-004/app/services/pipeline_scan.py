from __future__ import annotations

import re
from collections import defaultdict
from pathlib import PurePosixPath
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import yaml


SECRET_REF = re.compile(r"(?:secrets|github\.event\.inputs)\.([A-Za-z_][A-Za-z0-9_]*)")
VAR_REF = re.compile(r"vars\.([A-Za-z_][A-Za-z0-9_]*)")
ENV_REF = re.compile(r"env\.([A-Za-z_][A-Za-z0-9_]*)")
AZURE_VAR_REF = re.compile(r"\$\(([A-Za-z_][A-Za-z0-9_.-]*)\)")
GITLAB_VAR_REF = re.compile(r"\$\{?([A-Z][A-Z0-9_]{2,})\}?")
URL_REF = re.compile(r"https?://[^\s\"'<>)}]+", re.IGNORECASE)
ACTION_REF = re.compile(r"^\s*(?:-\s*)?uses:\s*([^\s#]+)", re.MULTILINE)
SENSITIVE_KEY = re.compile(r"(?i)(password|passwd|secret|token|api[_-]?key|private[_-]?key|client[_-]?secret|connection[_-]?string)")
ASSIGNMENT = re.compile(r"^\s*(?:-\s*)?([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s*(.+?)\s*$")
ARTIFACT_HINT = re.compile(r"(?i)(upload-artifact|download-artifact|publishpipelineartifact|publishbuildartifacts|artifacts\s*:)")
CACHE_HINT = re.compile(r"(?i)(actions/cache|cache\s*:|cache@|restorekeys)")
OIDC_HINT = re.compile(r"(?i)(id-token\s*:\s*write|workload.identity|oidc|federated.credentials)")
SELF_HOSTED_HINT = re.compile(r"(?i)(self-hosted|private[-_ ]runner|agentpool|pool\s*:)")

# Paths inspected during deep discovery. This is deliberately bounded and
# deterministic; repository trees can contain millions of entries.
EXTERNAL_PIPELINE_PATHS: dict[str, str] = {
    "azure-pipelines.yml": "Azure Pipelines",
    "azure-pipelines.yaml": "Azure Pipelines",
    ".azure-pipelines/pipeline.yml": "Azure Pipelines",
    "Jenkinsfile": "Jenkins",
    ".gitlab-ci.yml": "GitLab CI",
    ".circleci/config.yml": "CircleCI",
    ".buildkite/pipeline.yml": "Buildkite",
    "bitbucket-pipelines.yml": "Bitbucket Pipelines",
    "cloudbuild.yaml": "Google Cloud Build",
    "cloudbuild.yml": "Google Cloud Build",
    "buildspec.yml": "AWS CodeBuild",
    "buildspec.yaml": "AWS CodeBuild",
    "appveyor.yml": "AppVeyor",
    ".travis.yml": "Travis CI",
}


def sanitize_url(raw: str) -> str:
    try:
        parts = urlsplit(raw.rstrip(".,;"))
        hostname = parts.hostname or ""
        port = f":{parts.port}" if parts.port else ""
        return urlunsplit((parts.scheme, hostname + port, parts.path, "", ""))
    except Exception:
        return raw.split("?", 1)[0]


def _walk(node: Any, path: tuple[str, ...] = ()) -> list[tuple[tuple[str, ...], Any]]:
    found: list[tuple[tuple[str, ...], Any]] = []
    if isinstance(node, dict):
        for key, value in node.items():
            found.extend(_walk(value, path + (str(key),)))
    elif isinstance(node, list):
        for index, value in enumerate(node):
            found.extend(_walk(value, path + (str(index),)))
    else:
        found.append((path, node))
    return found


def _hardcoded_findings(path: str, text: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        match = ASSIGNMENT.match(line)
        if not match:
            continue
        key, value = match.groups()
        if not SENSITIVE_KEY.search(key):
            continue
        stripped = value.strip().strip("\"'")
        key_lower = key.lower()
        value_lower = stripped.lower()
        safe_scalar = value_lower in {"null", "none", "false", "true"}
        github_permission_literal = (
            key_lower == "id-token" and value_lower in {"read", "write", "none"}
        )
        reusable_secret_inheritance = (
            key_lower in {"secret", "secrets"} and value_lower == "inherit"
        )
        if (
            not stripped
            or "${{" in stripped
            or stripped.startswith("$(")
            or stripped.startswith("$")
            or safe_scalar
            or github_permission_literal
            or reusable_secret_inheritance
            or stripped.startswith("op://")
        ):
            continue
        findings.append(
            {
                "file": path,
                "line": line_number,
                "key": key,
                "severity": "critical",
                "value": "***REDACTED***",
                "reason": "Potential hard-coded credential in pipeline configuration",
            }
        )
    return findings


def _usage_locations(pattern: re.Pattern[str], path: str, text: str, reference_kind: str) -> list[dict[str, Any]]:
    usage: list[dict[str, Any]] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        for match in pattern.finditer(line):
            usage.append(
                {
                    "name": match.group(1),
                    "file": path,
                    "line": line_number,
                    "kind": reference_kind,
                    "excerpt": line.strip()[:300],
                }
            )
    return usage


def scan_workflow(path: str, text: str) -> dict[str, Any]:
    secret_refs = sorted(set(SECRET_REF.findall(text)))
    variable_refs = sorted(set(VAR_REF.findall(text)))
    env_refs = sorted(set(ENV_REF.findall(text)))
    secret_usage = _usage_locations(SECRET_REF, path, text, "secret")
    variable_usage = _usage_locations(VAR_REF, path, text, "variable")
    environment_usage = _usage_locations(ENV_REF, path, text, "environment")
    urls = sorted(set(sanitize_url(item) for item in URL_REF.findall(text)))
    actions = sorted(set(ACTION_REF.findall(text)))
    hardcoded_findings = _hardcoded_findings(path, text)
    parse_error: str | None = None
    parsed: Any = None
    try:
        parsed = yaml.safe_load(text) or {}
    except Exception as exc:
        parse_error = str(exc)

    environments: set[str] = set()
    runners: set[str] = set()
    permissions: dict[str, set[str]] = defaultdict(set)
    if parsed is not None:
        for node_path, value in _walk(parsed):
            if node_path and node_path[-1] == "environment" and isinstance(value, str):
                environments.add(value)
            if "runs-on" in node_path:
                if isinstance(value, str):
                    runners.add(value)
            if "permissions" in node_path and isinstance(value, str):
                permission_index = node_path.index("permissions")
                if len(node_path) > permission_index + 1:
                    permissions[node_path[permission_index + 1]].add(value)

    # YAML traversal flattens list-valued runs-on fields into scalar leaves, but
    # malformed YAML should still expose obvious runner labels through text.
    if SELF_HOSTED_HINT.search(text):
        runners.add("self-hosted")

    artifact_references = sorted(set(match.group(0).strip() for match in ARTIFACT_HINT.finditer(text)))
    cache_references = sorted(set(match.group(0).strip() for match in CACHE_HINT.finditer(text)))
    oidc_references = sorted(set(match.group(0).strip() for match in OIDC_HINT.finditer(text)))

    risk = 0
    risk += min(40, len(hardcoded_findings) * 20)
    risk += min(20, len(secret_refs) * 2)
    if any("self-hosted" in runner.lower() for runner in runners):
        risk += 15
    if oidc_references or any("id-token" in key and "write" in values for key, values in permissions.items()):
        risk += 10
    if urls:
        risk += min(15, len(urls))
    if parse_error:
        risk += 10

    return {
        "path": path,
        "pipeline_system": "GitHub Actions",
        "secret_references": secret_refs,
        "variable_references": variable_refs,
        "environment_references": env_refs,
        "secret_usage": secret_usage,
        "variable_usage": variable_usage,
        "environment_usage": environment_usage,
        "deployment_environments": sorted(environments),
        "external_urls": urls,
        "actions_used": actions,
        "runners": sorted(runners),
        "permissions": {key: sorted(values) for key, values in permissions.items()},
        "artifact_references": artifact_references,
        "cache_references": cache_references,
        "oidc_references": oidc_references,
        "hardcoded_credential_findings": hardcoded_findings,
        "parse_error": parse_error,
        "risk_score": min(100, risk),
    }


def scan_external_pipeline(path: str, text: str, system: str | None = None) -> dict[str, Any]:
    normalized = str(PurePosixPath(path))
    system = system or EXTERNAL_PIPELINE_PATHS.get(normalized, "External CI/CD")
    variables = sorted(set(AZURE_VAR_REF.findall(text)) | set(GITLAB_VAR_REF.findall(text)))
    sensitive_variables = sorted(name for name in variables if SENSITIVE_KEY.search(name))
    variable_usage: list[dict[str, Any]] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        for name in sorted(set(AZURE_VAR_REF.findall(line)) | set(GITLAB_VAR_REF.findall(line))):
            variable_usage.append({"name": name, "file": path, "line": line_number, "kind": "pipeline_variable", "excerpt": line.strip()[:300]})
    secret_usage = [item for item in variable_usage if SENSITIVE_KEY.search(item["name"])]
    urls = sorted(set(sanitize_url(item) for item in URL_REF.findall(text)))
    hardcoded = _hardcoded_findings(path, text)
    runners: set[str] = set()
    if SELF_HOSTED_HINT.search(text):
        runners.add("self-hosted-or-private")
    artifact_references = sorted(set(match.group(0).strip() for match in ARTIFACT_HINT.finditer(text)))
    cache_references = sorted(set(match.group(0).strip() for match in CACHE_HINT.finditer(text)))
    oidc_references = sorted(set(match.group(0).strip() for match in OIDC_HINT.finditer(text)))
    risk = min(
        100,
        len(sensitive_variables) * 3
        + len(urls)
        + len(hardcoded) * 25
        + (15 if runners else 0)
        + (10 if oidc_references else 0),
    )
    return {
        "path": path,
        "pipeline_system": system,
        "secret_references": sensitive_variables,
        "variable_references": variables,
        "environment_references": [],
        "secret_usage": secret_usage,
        "variable_usage": variable_usage,
        "environment_usage": [],
        "deployment_environments": [],
        "external_urls": urls,
        "actions_used": [],
        "runners": sorted(runners),
        "permissions": {},
        "artifact_references": artifact_references,
        "cache_references": cache_references,
        "oidc_references": oidc_references,
        "hardcoded_credential_findings": hardcoded,
        "parse_error": None,
        "risk_score": risk,
    }


def scan_pipeline_file(path: str, text: str) -> dict[str, Any]:
    normalized = str(PurePosixPath(path))
    if normalized.startswith(".github/workflows/"):
        return scan_workflow(path, text)
    return scan_external_pipeline(path, text, EXTERNAL_PIPELINE_PATHS.get(normalized))


def merge_pipeline_reports(
    reports: list[dict[str, Any]],
    api_secret_names: list[str],
    api_variable_names: list[str],
) -> dict[str, Any]:
    secrets = set(api_secret_names)
    variables = set(api_variable_names)
    environments: set[str] = set()
    urls: set[str] = set()
    actions: set[str] = set()
    runners: set[str] = set()
    artifacts: set[str] = set()
    caches: set[str] = set()
    oidc: set[str] = set()
    systems: set[str] = set()
    hardcoded: list[dict[str, Any]] = []
    secret_usage: list[dict[str, Any]] = []
    variable_usage: list[dict[str, Any]] = []
    environment_usage: list[dict[str, Any]] = []
    parse_errors: list[dict[str, str]] = []
    file_scores: list[int] = []

    for report in reports:
        secrets.update(report.get("secret_references", []))
        variables.update(report.get("variable_references", []))
        environments.update(report.get("deployment_environments", []))
        urls.update(report.get("external_urls", []))
        actions.update(report.get("actions_used", []))
        runners.update(report.get("runners", []))
        artifacts.update(report.get("artifact_references", []))
        caches.update(report.get("cache_references", []))
        oidc.update(report.get("oidc_references", []))
        if report.get("pipeline_system"):
            systems.add(str(report["pipeline_system"]))
        hardcoded.extend(report.get("hardcoded_credential_findings", []))
        secret_usage.extend(report.get("secret_usage", []))
        variable_usage.extend(report.get("variable_usage", []))
        environment_usage.extend(report.get("environment_usage", []))
        if report.get("parse_error"):
            parse_errors.append({"path": report["path"], "error": report["parse_error"]})
        file_scores.append(int(report.get("risk_score", 0)))

    onepassword_mapping = [
        {
            "github_secret_name": name,
            "recommended_reference": f"op://<vault>/<repository>/{name}",
            "value_available_from_github": False,
            "owner_action": "Populate or confirm this secret in 1Password; GitHub APIs expose the name, not the value.",
        }
        for name in sorted(secrets)
    ]

    average = round(sum(file_scores) / len(file_scores), 1) if file_scores else 0.0
    risk = min(100.0, average + min(30, len(hardcoded) * 15))
    github_workflows = [item for item in reports if item.get("pipeline_system") == "GitHub Actions"]
    external_files = [item for item in reports if item.get("pipeline_system") != "GitHub Actions"]
    return {
        "pipeline_files": reports,
        "workflow_files": github_workflows,
        "external_pipeline_files": external_files,
        "pipeline_systems": sorted(systems),
        "secret_names": sorted(secrets),
        "variable_names": sorted(variables),
        "environments": sorted(environments),
        "external_urls": sorted(urls),
        "actions_used": sorted(actions),
        "runners": sorted(runners),
        "self_hosted_runners": sorted(item for item in runners if "self-hosted" in item.lower() or "private" in item.lower()),
        "artifact_references": sorted(artifacts),
        "cache_references": sorted(caches),
        "oidc_references": sorted(oidc),
        "hardcoded_credential_findings": hardcoded,
        "secret_usage": secret_usage,
        "variable_usage": variable_usage,
        "environment_usage": environment_usage,
        "parse_errors": parse_errors,
        "onepassword_mapping": onepassword_mapping,
        "risk_score": risk,
        "has_pipeline": bool(reports or api_secret_names or api_variable_names),
        "important_note": "Secret values cannot be read from GitHub. This report intentionally contains names and references only.",
    }
