from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import (
    JobStatus,
    MigrationMethod,
    MigrationMode,
    MigrationRun,
    MigrationStatus,
    RepoMigration,
    RepoMigrationStatus,
    RepositoryInventory,
    ValidationRun,
)


def source_freeze_evidence(
    db: Session,
    *,
    workspace_id: str,
    source_connector_id: str,
    source_org: str,
    repository_ids: list[str],
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    """Return immutable evidence references required for manual source archival.

    Manual source archival is a fallback control. It is only eligible after an
    official production GEI migration completed and a linked validation passed.
    ELM repositories must use the official ELM cutover path instead.
    """

    approved: dict[str, dict[str, Any]] = {}
    blockers: dict[str, str] = {}
    for repository_id in repository_ids:
        repository = db.get(RepositoryInventory, repository_id)
        if not repository or repository.workspace_id != workspace_id or repository.source_org != source_org:
            blockers[repository_id] = "Repository is outside the selected workspace or source organization"
            continue

        mappings = db.scalars(
            select(RepoMigration)
            .join(MigrationRun, RepoMigration.migration_run_id == MigrationRun.id)
            .where(
                RepoMigration.repository_inventory_id == repository.id,
                MigrationRun.workspace_id == workspace_id,
                MigrationRun.source_connector_id == source_connector_id,
                MigrationRun.source_org == source_org,
                MigrationRun.mode == MigrationMode.production,
                MigrationRun.status.in_([
                    MigrationStatus.completed,
                    MigrationStatus.completed_with_warnings,
                ]),
                RepoMigration.status.in_([
                    RepoMigrationStatus.completed,
                    RepoMigrationStatus.warning,
                ]),
            )
            .order_by(MigrationRun.created_at.desc())
        ).all()
        if not mappings:
            blockers[repository.id] = "No completed production migration evidence exists"
            continue

        # The latest completed production migration is authoritative. Do not
        # fall back to an older GEI run when a newer ELM run exists, because
        # ELM source archival must happen through its official final cutover.
        selected_mapping = mappings[0]
        selected_run = db.get(MigrationRun, selected_mapping.migration_run_id)
        if not selected_run:
            blockers[repository.id] = "Latest completed migration evidence is unavailable"
            continue
        if selected_run.method == MigrationMethod.elm:
            blockers[repository.id] = "Use the official ELM cutover; do not run a separate manual archive"
            continue
        if selected_run.method != MigrationMethod.gei:
            blockers[repository.id] = "No eligible production GEI migration evidence exists"
            continue

        validation = db.scalar(
            select(ValidationRun)
            .where(
                ValidationRun.workspace_id == workspace_id,
                ValidationRun.migration_run_id == selected_run.id,
                ValidationRun.status == JobStatus.succeeded,
                ValidationRun.failed_count == 0,
            )
            .order_by(ValidationRun.created_at.desc())
        )
        if not validation:
            blockers[repository.id] = "A successful linked validation with zero failures is required"
            continue

        repository_report = next(
            (
                item
                for item in ((validation.report_json or {}).get("repositories") or [])
                if item.get("repo") == selected_mapping.source_repo
                and item.get("target_repo") == selected_mapping.target_repo
            ),
            None,
        )
        if not repository_report:
            blockers[repository.id] = "The linked validation does not contain repository-level evidence"
            continue
        validated_source_sha = repository_report.get("source_sha")
        validated_target_sha = repository_report.get("target_sha")
        if not validated_source_sha or not validated_target_sha or validated_source_sha != validated_target_sha:
            blockers[repository.id] = "The linked validation does not prove an identical source and target head SHA"
            continue
        critical_warning_names = {
            "release_count",
            "git_lfs_objects",
            "workflow_file_paths",
            "all_branch_refs",
            "all_tag_refs",
            "default_branch_head_sha",
        }
        unresolved = [
            item.get("name")
            for item in (repository_report.get("checks") or [])
            if item.get("status") == "warning"
            and (item.get("name") in critical_warning_names or str(item.get("name") or "").startswith("workflow_hash:"))
        ]
        if unresolved:
            blockers[repository.id] = (
                "Critical validation warnings must be resolved before source archival: "
                + ", ".join(str(item) for item in unresolved)
            )
            continue

        approved[repository.id] = {
            "repository_id": repository.id,
            "repository": repository.name,
            "migration_run_id": selected_run.id,
            "repo_migration_id": selected_mapping.id,
            "validation_run_id": validation.id,
            "validation_grade": validation.grade,
            "validated_source_sha": validated_source_sha,
            "validated_target_sha": validated_target_sha,
            "validated_at": validation.finished_at.isoformat() if validation.finished_at else None,
            "source_sha_at_start": selected_mapping.source_sha_at_start,
            "target_sha_after": selected_mapping.target_sha_after,
            "target_connector_id": selected_run.target_connector_id,
            "target_org": selected_run.target_org,
            "target_repo": selected_mapping.target_repo,
            "target_repository_id": (selected_mapping.result_json or {}).get("target_repository_id"),
            "method": selected_run.method.value,
            "lock_source_at_cutover": selected_run.lock_source_at_cutover,
        }
        blockers.pop(repository.id, None)
    return approved, blockers


def validate_source_freeze_evidence(
    db: Session,
    *,
    workspace_id: str,
    source_connector_id: str,
    source_org: str,
    evidence: dict[str, dict[str, Any]],
) -> None:
    repository_ids = sorted(evidence)
    current, blockers = source_freeze_evidence(
        db,
        workspace_id=workspace_id,
        source_connector_id=source_connector_id,
        source_org=source_org,
        repository_ids=repository_ids,
    )
    if blockers or set(current) != set(repository_ids):
        detail = "; ".join(f"{repo_id}: {reason}" for repo_id, reason in sorted(blockers.items()))
        raise RuntimeError(f"Source read-only evidence is no longer valid: {detail or 'scope changed'}")
    for repository_id, stored in evidence.items():
        observed = current[repository_id]
        for key in (
            "migration_run_id",
            "repo_migration_id",
            "validation_run_id",
            "validated_source_sha",
            "validated_target_sha",
            "target_connector_id",
            "target_org",
            "target_repo",
            "target_repository_id",
        ):
            if str(stored.get(key)) != str(observed.get(key)):
                raise RuntimeError(
                    f"Source read-only evidence changed for {observed.get('repository') or repository_id}; rerun the preview"
                )
