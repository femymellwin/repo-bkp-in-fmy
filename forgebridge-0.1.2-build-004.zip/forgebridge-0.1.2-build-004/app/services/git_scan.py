from __future__ import annotations

import os
import shutil
import stat
import subprocess
import tempfile
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from app.config import get_settings


class GitScanError(RuntimeError):
    pass


def repository_clone_url(base_url: str, org: str, repo: str) -> str:
    parts = urlsplit(base_url.rstrip("/"))
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        raise GitScanError("Large-file scan requires an HTTPS GHES base URL")
    return urlunsplit((parts.scheme, parts.netloc, f"/{org}/{repo}.git", "", ""))


def scan_large_git_objects(base_url: str, org: str, repo: str, token: str) -> dict[str, Any]:
    """Create a temporary read-only mirror solely to inspect object sizes.

    Credentials are delivered through a temporary GIT_ASKPASS program and are
    never placed in the process argument list. The mirror is removed on exit.
    This function is not a migration path.
    """

    settings = get_settings()
    if not settings.enable_large_file_scan:
        return {"enabled": False, "status": "skipped", "reason": "ENABLE_LARGE_FILE_SCAN is false"}
    git = shutil.which(settings.git_binary)
    if not git:
        raise GitScanError(f"Git binary '{settings.git_binary}' is not installed")
    if not token:
        raise GitScanError("A source token is required for the read-only mirror scan")

    clone_url = repository_clone_url(base_url, org, repo)
    with tempfile.TemporaryDirectory(prefix="forgebridge-git-scan-") as tmp:
        root = Path(tmp)
        mirror = root / "repository.git"
        askpass = root / "askpass.sh"
        askpass.write_text(
            "#!/bin/sh\n"
            "case \"$1\" in\n"
            "  *Username*) printf '%s\\n' \"${FORGEBRIDGE_GIT_USER:-x-access-token}\" ;;\n"
            "  *) printf '%s\\n' \"$FORGEBRIDGE_GIT_TOKEN\" ;;\n"
            "esac\n",
            encoding="utf-8",
        )
        askpass.chmod(askpass.stat().st_mode | stat.S_IXUSR)
        env = os.environ.copy()
        env.update(
            {
                "GIT_ASKPASS": str(askpass),
                "GIT_TERMINAL_PROMPT": "0",
                "FORGEBRIDGE_GIT_TOKEN": token,
                "FORGEBRIDGE_GIT_USER": "x-access-token",
            }
        )
        try:
            clone = subprocess.run(
                [git, "clone", "--mirror", "--quiet", clone_url, str(mirror)],
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=settings.large_file_scan_timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise GitScanError("Large-file mirror clone exceeded the configured timeout") from exc
        if clone.returncode != 0:
            message = (clone.stderr or clone.stdout or "Git mirror clone failed").replace(token, "***")
            raise GitScanError(message[-3000:])

        rev = subprocess.run(
            [git, "-C", str(mirror), "rev-list", "--objects", "--all"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=settings.large_file_scan_timeout_seconds,
            check=False,
        )
        if rev.returncode != 0:
            raise GitScanError((rev.stderr or "git rev-list failed")[-3000:])

        object_lines = [line for line in rev.stdout.splitlines() if line.strip()]
        if not object_lines:
            return {
                "enabled": True,
                "status": "completed",
                "objects_examined": 0,
                "largest_blob_bytes": 0,
                "warning_count": 0,
                "blocker_count": 0,
                "largest_objects": [],
            }

        batch = subprocess.run(
            [
                git,
                "-C",
                str(mirror),
                "cat-file",
                "--batch-check=%(objectname) %(objecttype) %(objectsize) %(rest)",
            ],
            input="\n".join(object_lines) + "\n",
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=settings.large_file_scan_timeout_seconds,
            check=False,
        )
        if batch.returncode != 0:
            raise GitScanError((batch.stderr or "git cat-file failed")[-3000:])

        blobs: list[dict[str, Any]] = []
        for line in batch.stdout.splitlines():
            parts = line.split(" ", 3)
            if len(parts) < 3 or parts[1] != "blob":
                continue
            try:
                size = int(parts[2])
            except ValueError:
                continue
            blobs.append({"sha": parts[0], "size_bytes": size, "path": parts[3] if len(parts) == 4 else ""})
        blobs.sort(key=lambda item: item["size_bytes"], reverse=True)
        warnings = [item for item in blobs if item["size_bytes"] >= settings.large_file_warning_bytes]
        blockers = [item for item in blobs if item["size_bytes"] >= settings.large_file_blocker_bytes]
        return {
            "enabled": True,
            "status": "completed",
            "migration_method": "none; discovery evidence only",
            "objects_examined": len(blobs),
            "largest_blob_bytes": blobs[0]["size_bytes"] if blobs else 0,
            "warning_threshold_bytes": settings.large_file_warning_bytes,
            "blocker_threshold_bytes": settings.large_file_blocker_bytes,
            "warning_count": len(warnings),
            "blocker_count": len(blockers),
            "largest_objects": blobs[: settings.large_file_scan_top_n],
        }
