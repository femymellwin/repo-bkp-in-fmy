from __future__ import annotations

import hashlib
from types import SimpleNamespace
from typing import Any

from sqlalchemy.orm import Session

from app.models import (
    Connector,
    ConnectorKind,
    Job,
    JobStatus,
    MigrationMethod,
    MigrationRun,
    RepoMigration,
    RepoMigrationStatus,
    RepositoryInventory,
    ValidationRun,
    utcnow,
)
from app.security import decrypt_secret
from app.services.github_client import GitHubApiError, GitHubClient
from app.services.job_utils import append_job_log, update_job


def check(name: str, source: Any, target: Any, severity: str = "error", note: str | None = None) -> dict[str, Any]:
    matched = source == target
    return {
        "name": name,
        "status": "pass" if matched else ("warning" if severity == "warning" else "fail"),
        "source": source,
        "target": target,
        "note": note,
    }


def refs_map(refs: list[dict[str, Any]]) -> dict[str, str | None]:
    result: dict[str, str | None] = {}
    for item in refs:
        ref = item.get("ref", "")
        obj = item.get("object") or {}
        result[ref] = obj.get("sha")
    return result


def hash_text(value: str | None) -> str | None:
    if value is None:
        return None
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def validate_one_real(
    run: MigrationRun,
    item: RepoMigration,
    source_client: GitHubClient,
    target_client: GitHubClient,
) -> dict[str, Any]:
    source_repo = source_client.get_repository(run.source_org, item.source_repo)
    target_repo = target_client.get_repository(run.target_org, item.target_repo)
    checks: list[dict[str, Any]] = []
    checks.append(check("default_branch", source_repo.get("default_branch"), target_repo.get("default_branch")))
    checks.append(check("visibility", source_repo.get("visibility"), target_repo.get("visibility")))
    checks.append(check("repository_name", item.target_repo, target_repo.get("name")))
    checks.append(check("has_issues", source_repo.get("has_issues"), target_repo.get("has_issues")))
    checks.append(check("has_wiki", source_repo.get("has_wiki"), target_repo.get("has_wiki")))
    checks.append(check("has_pages", source_repo.get("has_pages"), target_repo.get("has_pages"), "warning"))

    source_latest = source_client.get_latest_commit(run.source_org, item.source_repo, source_repo.get("default_branch"))
    target_latest = target_client.get_latest_commit(run.target_org, item.target_repo, target_repo.get("default_branch"))
    source_sha = (source_latest or {}).get("sha")
    target_sha = (target_latest or {}).get("sha")
    checks.append(check("default_branch_head_sha", source_sha, target_sha))
    item.target_sha_after = target_sha

    source_branches = refs_map(source_client.list_refs(run.source_org, item.source_repo, "heads/"))
    target_branches = refs_map(target_client.list_refs(run.target_org, item.target_repo, "heads/"))
    source_tags = refs_map(source_client.list_refs(run.source_org, item.source_repo, "tags/"))
    target_tags = refs_map(target_client.list_refs(run.target_org, item.target_repo, "tags/"))
    checks.append(check("all_branch_refs", source_branches, target_branches))
    checks.append(check("all_tag_refs", source_tags, target_tags))

    source_workflows = source_client.list_workflows(run.source_org, item.source_repo)
    target_workflows = target_client.list_workflows(run.target_org, item.target_repo)
    source_paths = sorted(item.get("path") for item in source_workflows if item.get("path"))
    target_paths = sorted(item.get("path") for item in target_workflows if item.get("path"))
    checks.append(check("workflow_file_paths", source_paths, target_paths))
    workflow_hashes: list[dict[str, Any]] = []
    for path in source_paths:
        source_text = source_client.get_content_text(run.source_org, item.source_repo, path, source_repo.get("default_branch"))
        target_text = target_client.get_content_text(run.target_org, item.target_repo, path, target_repo.get("default_branch"))
        workflow_hashes.append(check(f"workflow_hash:{path}", hash_text(source_text), hash_text(target_text)))
    checks.extend(workflow_hashes)

    source_releases = source_client.count_endpoint(f"/repos/{run.source_org}/{item.source_repo}/releases")
    target_releases = target_client.count_endpoint(f"/repos/{run.target_org}/{item.target_repo}/releases")
    checks.append(check("release_count", source_releases, target_releases, "warning"))

    source_prs = source_client.count_endpoint(f"/repos/{run.source_org}/{item.source_repo}/pulls", {"state": "all"})
    target_prs = target_client.count_endpoint(f"/repos/{run.target_org}/{item.target_repo}/pulls", {"state": "all"})
    checks.append(check("pull_request_count", source_prs, target_prs))

    source_issues = int(source_repo.get("open_issues_count", 0))
    target_issues = int(target_repo.get("open_issues_count", 0))
    issue_note = None
    issue_severity = "error"
    if run.method == MigrationMethod.gei and target_issues == source_issues + 1:
        issue_note = "Expected difference: GitHub Enterprise Importer can create a Migration Log issue when Issues are enabled."
        issue_severity = "warning"
    checks.append(check("open_issue_and_pr_counter", source_issues, target_issues, issue_severity, issue_note))

    if item.repository.has_lfs and run.method == MigrationMethod.gei:
        checks.append(
            {
                "name": "git_lfs_objects",
                "status": "warning",
                "source": "LFS detected",
                "target": "Not validated",
                "note": "GEI migrates Git pointers but does not migrate LFS objects. Transfer and validate LFS separately.",
            }
        )

    statuses = [entry["status"] for entry in checks]
    overall = "fail" if "fail" in statuses else ("warning" if "warning" in statuses else "pass")
    item.status = RepoMigrationStatus.warning if overall == "warning" else item.status
    item.result_json = {**(item.result_json or {}), "validation_overall": overall}
    return {
        "repo": item.source_repo,
        "target_repo": item.target_repo,
        "overall": overall,
        "checks": checks,
        "source_sha": source_sha,
        "target_sha": target_sha,
    }


def _simulated_report(repository: RepositoryInventory, target_repo: str, method: MigrationMethod) -> dict[str, Any]:
    checks = [
        check("default_branch_head_sha", repository.last_commit_sha, repository.last_commit_sha),
        check("all_branch_refs", repository.branches_count, repository.branches_count),
        check("all_tag_refs", repository.tags_count, repository.tags_count),
        check("pull_request_count", repository.pull_requests_count, repository.pull_requests_count),
        check("workflow_file_count", repository.workflows_count, repository.workflows_count),
        check("target_repository_exists", True, True),
    ]
    if method == MigrationMethod.gei:
        checks.append(
            {
                "name": "migration_log_issue",
                "status": "warning",
                "source": 0,
                "target": 1,
                "note": "Expected GitHub-generated metadata difference in a GEI migration.",
            }
        )
    if repository.has_lfs and method == MigrationMethod.gei:
        checks.append(
            {
                "name": "git_lfs_objects",
                "status": "warning",
                "source": "present",
                "target": "manual validation required",
                "note": "GEI does not migrate LFS objects; object-level validation is a separate acceptance item.",
            }
        )
    overall = "warning" if any(c["status"] == "warning" for c in checks) else "pass"
    return {"repo": repository.name, "target_repo": target_repo, "overall": overall, "checks": checks}


def run_validation_job(db: Session, job: Job) -> dict[str, Any]:
    validation = db.get(ValidationRun, job.payload_json["validation_run_id"])
    if not validation:
        raise RuntimeError("Validation run not found")

    run = db.get(MigrationRun, validation.migration_run_id) if validation.migration_run_id else None
    if run:
        source = db.get(Connector, run.source_connector_id)
        target = db.get(Connector, run.target_connector_id)
        source_org = run.source_org
        target_org = run.target_org
        method = run.method
        db.refresh(run, attribute_names=["repositories"])
        pairs: list[tuple[Any, RepositoryInventory, str, str]] = [
            (item, item.repository, item.source_repo, item.target_repo)
            for item in run.repositories
            if item.status in (
                RepoMigrationStatus.completed,
                RepoMigrationStatus.warning,
                RepoMigrationStatus.ready_for_cutover,
            )
        ]
    else:
        source = db.get(Connector, validation.source_connector_id) if validation.source_connector_id else None
        target = db.get(Connector, validation.target_connector_id) if validation.target_connector_id else None
        source_org = validation.source_org or ""
        target_org = validation.target_org or ""
        method_value = str((validation.scope_json or {}).get("method") or "gei")
        method = MigrationMethod(method_value) if method_value in {item.value for item in MigrationMethod} else MigrationMethod.gei
        selected_ids = [str(value) for value in (validation.scope_json or {}).get("repository_ids", [])]
        repositories = [db.get(RepositoryInventory, repo_id) for repo_id in selected_ids]
        repositories = [
            item
            for item in repositories
            if item and item.workspace_id == validation.workspace_id and (not source_org or item.source_org == source_org)
        ]
        pairs = []
        for repository in repositories:
            target_names = (validation.scope_json or {}).get("target_names") or {}
            target_name = str(target_names.get(repository.id) or repository.target_name or repository.name)
            adapter = SimpleNamespace(
                source_repo=repository.name,
                target_repo=target_name,
                repository=repository,
                target_sha_after=None,
                status=RepoMigrationStatus.completed,
                result_json={},
            )
            pairs.append((adapter, repository, repository.name, target_name))

    if not source or not target:
        raise RuntimeError("Validation source or target connector is missing")
    if not source_org or not target_org:
        raise RuntimeError("Validation source and target organizations are required")
    if not pairs:
        raise RuntimeError("There are no selected repositories to validate")

    validation.status = JobStatus.running
    db.add(validation)
    db.commit()
    update_job(db, job, status=JobStatus.running, progress=1, step="Validation started")
    append_job_log(
        job,
        "Validation started",
        {
            "source_org": source_org,
            "target_org": target_org,
            "repository_count": len(pairs),
            "migration_run_id": validation.migration_run_id,
        },
    )
    reports: list[dict[str, Any]] = []

    simulated = source.kind == ConnectorKind.simulated_ghes or target.kind == ConnectorKind.simulated_ghec
    if simulated:
        for index, (_, repository, _, target_repo) in enumerate(pairs, start=1):
            report = _simulated_report(repository, target_repo, method)
            reports.append(report)
            update_job(db, job, progress=int(index / len(pairs) * 95), step=f"Validated {repository.name}")
    else:
        source_token = decrypt_secret(source.encrypted_token)
        target_token = decrypt_secret(target.encrypted_token)
        if not source_token or not target_token:
            raise RuntimeError("Connector tokens are missing")
        run_adapter = run or SimpleNamespace(source_org=source_org, target_org=target_org, method=method)
        with GitHubClient(source.api_url, source_token, source.verify_ssl) as source_client, GitHubClient(
            target.api_url, target_token, target.verify_ssl
        ) as target_client:
            for index, (item, repository, source_repo, target_repo) in enumerate(pairs, start=1):
                try:
                    report = validate_one_real(run_adapter, item, source_client, target_client)
                except GitHubApiError as exc:
                    report = {
                        "repo": source_repo,
                        "target_repo": target_repo,
                        "overall": "fail",
                        "error": str(exc),
                        "checks": [],
                    }
                reports.append(report)
                if run and isinstance(item, RepoMigration):
                    db.add(item)
                    db.commit()
                update_job(db, job, progress=int(index / len(pairs) * 95), step=f"Validated {source_repo}")
                append_job_log(job, "Repository validated", {"repo": source_repo, "overall": report["overall"]})

    passed = sum(1 for report in reports if report["overall"] == "pass")
    warned = sum(1 for report in reports if report["overall"] == "warning")
    failed = sum(1 for report in reports if report["overall"] == "fail")
    all_checks = [entry for report in reports for entry in (report.get("checks") or [])]
    passed_checks = sum(1 for entry in all_checks if entry.get("status") == "pass")
    warning_checks = sum(1 for entry in all_checks if entry.get("status") == "warning")
    failed_checks = sum(1 for entry in all_checks if entry.get("status") == "fail")
    check_total = len(all_checks)
    score = int(round(((passed_checks + 0.5 * warning_checks) / check_total) * 100)) if check_total else 0
    if failed_checks or failed:
        grade = "F"
    elif score >= 95:
        grade = "A"
    elif score >= 85:
        grade = "B"
    elif score >= 75:
        grade = "C"
    elif score >= 65:
        grade = "D"
    else:
        grade = "F"
    report_json = {
        "source_org": source_org,
        "target_org": target_org,
        "method": method.value,
        "migration_run_id": validation.migration_run_id,
        "repositories": reports,
        "score": score,
        "grade": grade,
        "check_counts": {"pass": passed_checks, "warning": warning_checks, "fail": failed_checks, "total": check_total},
        "acceptance_note": (
            "Repository validation compares supported source/target evidence. It does not prove restoration of secrets, "
            "runners, teams, access, Apps, packages, projects or security findings; those require explicit owner sign-off."
        ),
    }
    validation.passed_count = passed
    validation.warning_count = warned
    validation.failed_count = failed
    validation.score = score
    validation.grade = grade
    validation.report_json = report_json
    validation.status = JobStatus.failed if failed else JobStatus.succeeded
    validation.finished_at = utcnow()
    db.add(validation)
    db.commit()
    result = {
        "validation_run_id": validation.id,
        "passed": passed,
        "warnings": warned,
        "failed": failed,
        "score": score,
        "grade": grade,
        **report_json,
    }
    update_job(
        db,
        job,
        status=validation.status,
        progress=100,
        step="Validation complete",
        result=result,
        error="Validation mismatches found" if failed else None,
    )
    return result
