from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from fastapi import UploadFile

from app.config import Settings

DEFAULT_THEME: dict[str, str] = {
    "primary": "#243144",
    "accent": "#3B82F6",
    "gradient_from": "#F8FAFC",
    "gradient_to": "#EEF4FF",
    "border": "#D7DEE8",
    "button_bg": "#FFFFFF",
    "button_border": "#CBD5E1",
    "button_text": "#243144",
}

_HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")
_MAX_LOGO_BYTES = 2 * 1024 * 1024
_LOGO_FILES = ("logo.png", "logo.jpg", "logo.webp")


def safe_color(value: Any, fallback: str) -> str:
    text = str(value or "").strip()
    return text.upper() if _HEX_COLOR.fullmatch(text) else fallback


def normalized_theme(value: Any) -> dict[str, str]:
    supplied = value if isinstance(value, dict) else {}
    return {
        key: safe_color(supplied.get(key), fallback)
        for key, fallback in DEFAULT_THEME.items()
    }


def safe_logo_url(value: Any) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    if text.startswith("/") and not text.startswith("//"):
        return text[:1024]
    parsed = urlparse(text)
    if parsed.scheme == "https" and parsed.netloc:
        return text[:1024]
    raise ValueError("Logo URL must be an HTTPS URL or an application-relative path.")


def current_logo_file(settings: Settings) -> Path | None:
    for name in _LOGO_FILES:
        path = settings.branding_dir / name
        if path.is_file():
            return path
    return None


def logo_media_type(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".png":
        return "image/png"
    if suffix == ".webp":
        return "image/webp"
    return "image/jpeg"


def _detect_logo(data: bytes) -> tuple[str, str]:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png", "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg", "image/jpeg"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp", "image/webp"
    raise ValueError("Logo must be a PNG, JPEG, or WebP image.")


async def persist_logo(upload: UploadFile | None, settings: Settings) -> str | None:
    if upload is None or not getattr(upload, "filename", None):
        return None
    data = await upload.read(_MAX_LOGO_BYTES + 1)
    if not data:
        raise ValueError("The uploaded logo is empty.")
    if len(data) > _MAX_LOGO_BYTES:
        raise ValueError("Logo exceeds the 2 MB limit.")
    extension, _ = _detect_logo(data)
    settings.branding_dir.mkdir(parents=True, exist_ok=True)
    target = settings.branding_dir / f"logo{extension}"
    temporary = settings.branding_dir / f".logo{extension}.tmp"
    temporary.write_bytes(data)
    os.replace(temporary, target)
    for name in _LOGO_FILES:
        other = settings.branding_dir / name
        if other != target:
            other.unlink(missing_ok=True)
    return "/branding/logo"


def delete_logo(settings: Settings) -> None:
    for name in _LOGO_FILES:
        (settings.branding_dir / name).unlink(missing_ok=True)
