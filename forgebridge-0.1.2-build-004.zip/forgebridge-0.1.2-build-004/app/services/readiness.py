from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Finding:
    code: str
    severity: str
    title: str
    message: str
    remediation: str
    category: str
    score_deduction: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "severity": self.severity,
            "title": self.title,
            "message": self.message,
            "remediation": self.remediation,
            "category": self.category,
            "score_deduction": self.score_deduction,
        }


def _finding(
    code: str,
    severity: str,
    title: str,
    message: str,
    remediation: str,
    category: str,
    deduction: int,
) -> Finding:
    return Finding(code, severity, title, message, remediation, category, deduction)


def assess_repository(data: dict[str, Any], method: str = "gei") -> dict[str, Any]:
    """Produce a deterministic, explainable migration-readiness assessment.

    The grade is a prioritization aid, not a GitHub compatibility guarantee. A
    repository can migrate technically while still requiring owners to restore
    unsupported data such as secrets, runners, applications, packages or access.
    """

    method = (method or "gei").lower()
    blockers: list[Finding] = []
    warnings: list[Finding] = []
    info: list[Finding] = []

    target = data.get("target_state_json") or {}
    pipeline = data.get("pipeline_report_json") or {}
    detail = data.get("detail_json") or {}

    if target.get("exists"):
        blockers.append(
            _finding(
                "TARGET_EXISTS",
                "blocker",
                "Destination repository already exists",
                f"The mapped destination repository already exists (ID {target.get('id') or 'unknown'}). Official migration tools create a destination repository and ForgeBridge will not merge into or overwrite it.",
                "Choose a unique trial name, purge an eligible ForgeBridge-created trial target, or resolve the destination repository through change control.",
                "target",
                45,
            )
        )
    if data.get("disabled"):
        blockers.append(
            _finding(
                "SOURCE_DISABLED",
                "blocker",
                "Source repository is disabled",
                "GitHub reports the source repository as disabled.",
                "Restore source availability and repeat discovery before migration.",
                "source",
                35,
            )
        )
    if not data.get("default_branch") or not data.get("last_commit_sha"):
        blockers.append(
            _finding(
                "NO_VALID_DEFAULT_REF",
                "blocker",
                "Default branch or head commit is unavailable",
                "ForgeBridge could not establish a default branch head for source-to-target validation.",
                "Confirm that the repository is non-empty, repair the default branch if necessary, and repeat deep discovery.",
                "source",
                35,
            )
        )
    if not detail.get("deep_scan_complete"):
        blockers.append(
            _finding(
                "DEEP_DISCOVERY_REQUIRED",
                "blocker",
                "Deep discovery is incomplete",
                "Production readiness cannot be established from a basic repository listing.",
                "Run deep discovery with pipeline analysis and target probing before a production wave.",
                "discovery",
                30,
            )
        )

    hardcoded = pipeline.get("hardcoded_credential_findings") or []
    if hardcoded:
        blockers.append(
            _finding(
                "HARDCODED_PIPELINE_CREDENTIAL",
                "blocker",
                "Potential hard-coded pipeline credential",
                f"Static inspection reported {len(hardcoded)} potential credential assignment(s). Values are redacted in ForgeBridge.",
                "Have the repository owner remove/rotate the credential and move the value to 1Password before enabling target pipelines.",
                "pipeline",
                35,
            )
        )

    if method == "elm" and data.get("visibility") == "public":
        blockers.append(
            _finding(
                "ELM_PUBLIC_REPOSITORY",
                "blocker",
                "Public repository is not eligible for the configured ELM lane",
                "The selected live-migration method and destination profile do not permit this public repository.",
                "Use the supported GEI path or change the repository/destination design with GitHub Support.",
                "method",
                45,
            )
        )
    if method == "elm" and int(data.get("largest_release_asset_bytes") or 0) > 2 * 1024**3:
        blockers.append(
            _finding(
                "ELM_RELEASE_ASSET_OVER_2_GIB",
                "blocker",
                "Release asset exceeds the ELM per-asset limit",
                "At least one discovered release asset is larger than 2 GiB.",
                "Remove or separately preserve the oversized asset under an approved plan before using ELM.",
                "size",
                45,
            )
        )

    if data.get("has_lfs") and method == "gei":
        warnings.append(
            _finding(
                "GEI_LFS_SEPARATE_TRANSFER",
                "warning",
                "Git LFS requires a separate workstream with GEI",
                "LFS pointers were discovered. GEI repository migration does not provide an end-to-end LFS object transfer guarantee.",
                "Inventory, transfer and validate LFS objects separately, or assess eligible ELM for a GHE.com destination.",
                "content",
                18,
            )
        )
    if int(data.get("open_pull_requests_count") or 0) > 0:
        warnings.append(
            _finding(
                "OPEN_PULL_REQUESTS",
                "warning",
                "Open pull requests require cutover coordination",
                f"{int(data.get('open_pull_requests_count') or 0)} open pull request(s) were discovered.",
                "Assign repository owners, stop force pushes, communicate the cutover window, and validate PR heads/base branches after migration.",
                "cutover",
                8,
            )
        )
    if data.get("is_fork"):
        warnings.append(
            _finding(
                "FORK_RELATIONSHIP_REVIEW",
                "warning",
                "Fork relationship requires review",
                "The repository is a fork; fork-network behavior and destination eligibility must be verified.",
                "Place related repositories in the same migration plan where supported and review the migration log for relationship warnings.",
                "relationships",
                12,
            )
        )
    if data.get("archived"):
        warnings.append(
            _finding(
                "SOURCE_ALREADY_ARCHIVED",
                "warning",
                "Source repository is already archived",
                "The repository is read-only at source and may represent retired content.",
                "Confirm with the owner whether it should be migrated, retained for audit only, or excluded.",
                "source",
                4,
            )
        )
    if int(data.get("inactive_days") or 0) >= 365:
        warnings.append(
            _finding(
                "INACTIVE_REPOSITORY",
                "warning",
                "Repository has been inactive for at least one year",
                f"The last discovered commit is approximately {int(data.get('inactive_days') or 0)} days old.",
                "Confirm ownership, business retention requirements and whether the repository should be archived instead of migrated.",
                "ownership",
                6,
            )
        )
    if int(data.get("external_pipeline_count") or 0) > 0:
        warnings.append(
            _finding(
                "EXTERNAL_PIPELINE_FILES",
                "warning",
                "External CI/CD configuration detected",
                f"{int(data.get('external_pipeline_count') or 0)} non-GitHub Actions pipeline configuration file(s) were discovered.",
                "Validate external CI service connections, webhooks, credentials and source URLs after the repository moves.",
                "pipeline",
                10,
            )
        )
    if int(data.get("self_hosted_runner_count") or 0) > 0:
        warnings.append(
            _finding(
                "SELF_HOSTED_RUNNERS",
                "warning",
                "Self-hosted runner labels detected",
                "Target runner groups, labels, network access and trust boundaries must be recreated or remapped.",
                "Document runner dependencies and reconfigure them in GHEC before enabling migrated workflows.",
                "pipeline",
                12,
            )
        )
    secret_count = int(data.get("secrets_count") or 0)
    if secret_count:
        warnings.append(
            _finding(
                "ACTIONS_SECRETS_MANUAL",
                "warning",
                "Actions secret values require manual reconfiguration",
                f"{secret_count} repository secret name(s) were discovered; GitHub APIs do not return their values.",
                "Populate approved values in 1Password, update workflows through reviewed pull requests, and keep target Actions disabled until owner sign-off.",
                "pipeline",
                12,
            )
        )
    if int(data.get("environments_count") or 0):
        warnings.append(
            _finding(
                "ACTIONS_ENVIRONMENTS_RECREATE",
                "warning",
                "Actions environments require target review",
                "Environment protection rules, approvers, variables and secrets require explicit target configuration and validation.",
                "Use the pipeline owner report to recreate environments and protection policies before deployment workflows are enabled.",
                "pipeline",
                10,
            )
        )
    if int(data.get("large_file_blocker_count") or 0) > 0:
        warnings.append(
            _finding(
                "LARGE_BLOBS_REVIEW",
                "warning",
                "Very large Git blobs require migration-method review",
                f"The optional mirror scan reported {int(data.get('large_file_blocker_count') or 0)} blob(s) above the configured blocker threshold.",
                "Review exact paths and object sizes, confirm GitHub limits with Support, and test the repository in a trial migration.",
                "size",
                18,
            )
        )
    elif int(data.get("large_file_warning_count") or 0) > 0:
        warnings.append(
            _finding(
                "LARGE_BLOBS_WARNING",
                "warning",
                "Large Git blobs detected",
                f"The optional mirror scan reported {int(data.get('large_file_warning_count') or 0)} blob(s) above the configured warning threshold.",
                "Run a representative trial and preserve the large-file evidence in the acceptance package.",
                "size",
                8,
            )
        )
    if int(data.get("release_assets_bytes") or 0) > 10 * 1024**3 and method == "gei":
        warnings.append(
            _finding(
                "GEI_RELEASE_DATA_REVIEW",
                "warning",
                "Release data is above the standard GEI release threshold",
                "The API-based release asset total is above 10 GiB and may require releases to be excluded from the migration.",
                "Confirm the authoritative limit immediately before migration, obtain owner approval, and use the official skip-releases option only when necessary.",
                "size",
                18,
            )
        )
    if float(data.get("pipeline_risk_score") or 0) >= 70:
        warnings.append(
            _finding(
                "HIGH_PIPELINE_RISK",
                "warning",
                "Pipeline remediation risk is high",
                "The deterministic pipeline scanner assigned a high dependency/remediation score.",
                "Require repository-owner review of secrets, variables, environments, runner labels, URLs, permissions and action dependencies.",
                "pipeline",
                12,
            )
        )

    info.append(
        _finding(
            "UNSUPPORTED_DATA_ACCEPTANCE",
            "info",
            "Separate acceptance remains mandatory",
            "A repository grade does not prove migration of teams, access, Apps, packages, projects, security results, Actions history or secret values.",
            "Track every unsupported object in the owner acceptance checklist and evidence bundle.",
            "governance",
            0,
        )
    )

    score = 100
    score -= sum(item.score_deduction for item in blockers)
    score -= sum(item.score_deduction for item in warnings)
    score = max(0, min(100, score))
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"

    if blockers:
        status = "blocked"
        # Blockers are deliberately visible even if a nominal arithmetic score
        # remains high because readiness is conjunctive, not just numeric.
        grade = "F"
    elif warnings:
        status = "needs_review"
    else:
        status = "ready"

    return {
        "method": method,
        "score": float(score),
        "grade": grade,
        "status": status,
        "blockers": [item.as_dict() for item in blockers],
        "warnings": [item.as_dict() for item in warnings],
        "information": [item.as_dict() for item in info],
        "calculation": {
            "starting_score": 100,
            "blocker_deduction": sum(item.score_deduction for item in blockers),
            "warning_deduction": sum(item.score_deduction for item in warnings),
            "not_a_guarantee": True,
        },
    }


def apply_assessment(
    repository: Any,
    *,
    method: Any = "gei",
    target_flavor: Any | None = None,
    source_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Apply a deterministic assessment to a RepositoryInventory row.

    ``target_flavor`` and ``source_metadata`` are retained in the evidence so
    operators can see which connector context was used. The assessment itself
    remains deterministic and never calls an AI service.
    """

    method_value = getattr(method, "value", method) or "gei"
    data = {column.name: getattr(repository, column.name) for column in repository.__table__.columns}
    if not data.get("target_state_json"):
        data["target_state_json"] = {
            "probed": bool(getattr(repository, "target_org_checked", None)),
            "exists": bool(getattr(repository, "target_exists", False)),
            "id": getattr(repository, "target_repository_id", None),
            "visibility": getattr(repository, "target_visibility", None),
            "default_branch": getattr(repository, "target_default_branch", None),
            "default_branch_sha": getattr(repository, "target_last_commit_sha", None),
        }
    assessment = assess_repository(data, method=str(method_value))
    repository.readiness_score = int(round(float(assessment["score"])))
    repository.readiness_grade = str(assessment["grade"])
    repository.readiness_status = str(assessment["status"])
    repository.blocker_count = len(assessment["blockers"])
    repository.warning_count = len(assessment["warnings"])
    repository.blockers_json = assessment["blockers"]
    repository.warnings_json = assessment["warnings"]
    repository.readiness_json = {
        **assessment,
        "connector_context": {
            "target_flavor": getattr(target_flavor, "value", target_flavor),
            "source_metadata": source_metadata or {},
        },
    }
    return repository.readiness_json
