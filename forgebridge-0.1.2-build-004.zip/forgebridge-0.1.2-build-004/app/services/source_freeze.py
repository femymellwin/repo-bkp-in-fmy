from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import (
    Connector,
    ConnectorKind,
    Job,
    JobStatus,
    RepositoryInventory,
    SourceFreezeRun,
    utcnow,
)
from app.security import decrypt_secret
from app.services.github_client import GitHubApiError, GitHubClient
from app.services.job_utils import append_job_log, update_job
from app.services.source_protection import validate_source_freeze_evidence


def run_source_freeze_job(db: Session, job: Job) -> dict[str, Any]:
    settings = get_settings()
    payload = job.payload_json
    freeze = db.get(SourceFreezeRun, payload.get("freeze_run_id"))
    if not freeze:
        raise RuntimeError("Source freeze run not found")
    connector = db.get(Connector, freeze.source_connector_id)
    if not connector or connector.workspace_id != freeze.workspace_id:
        raise RuntimeError("Source connector not found")
    if connector.kind not in (ConnectorKind.ghes, ConnectorKind.simulated_ghes):
        raise RuntimeError("Source read-only actions require a GHES connector")

    repo_ids = [str(value) for value in (freeze.scope_json or {}).get("repository_ids", [])]
    repositories = [db.get(RepositoryInventory, repo_id) for repo_id in repo_ids]
    repositories = [item for item in repositories if item and item.workspace_id == freeze.workspace_id and item.source_org == freeze.source_org]
    if not repositories:
        raise RuntimeError("No valid source repositories were selected")

    freeze.status = JobStatus.running
    db.add(freeze)
    db.commit()
    update_job(db, job, status=JobStatus.running, progress=1, step="Validating source read-only scope")
    append_job_log(
        job,
        "Source read-only workflow started",
        {"source_org": freeze.source_org, "dry_run": freeze.dry_run, "repositories": [item.name for item in repositories]},
    )

    simulated = connector.kind == ConnectorKind.simulated_ghes
    if not freeze.dry_run and not simulated and not settings.enable_source_freeze:
        raise RuntimeError(
            "Real source archival is disabled. Set ENABLE_SOURCE_FREEZE=true only for an approved cutover change."
        )

    evidence: dict[str, dict[str, Any]] = {}
    if not freeze.dry_run and not simulated:
        evidence = (freeze.scope_json or {}).get("approved_evidence") or {}
        if set(evidence) != {item.id for item in repositories}:
            raise RuntimeError("Every selected repository must include approved migration and validation evidence")
        validate_source_freeze_evidence(
            db,
            workspace_id=freeze.workspace_id,
            source_connector_id=freeze.source_connector_id,
            source_org=freeze.source_org,
            evidence=evidence,
        )

    token = None if simulated else decrypt_secret(connector.encrypted_token)
    if not freeze.dry_run and not simulated and not token:
        raise RuntimeError("Source connector token is unavailable")

    live_preflight: dict[str, dict[str, Any]] = {}
    if not freeze.dry_run and not simulated:
        # Re-check every source and target before changing even one source
        # repository. This closes the window where commits or target state can
        # change after validation but before the archive job starts.
        assert token is not None
        target_clients: dict[str, GitHubClient] = {}
        try:
            with GitHubClient(connector.api_url, token, connector.verify_ssl) as source_client:
                for repository in repositories:
                    approved = evidence[repository.id]
                    source_data = source_client.get_repository(freeze.source_org, repository.name)
                    source_latest = source_client.get_latest_commit(
                        freeze.source_org,
                        repository.name,
                        source_data.get("default_branch"),
                    )
                    current_source_sha = (source_latest or {}).get("sha")
                    expected_source_sha = approved.get("validated_source_sha")
                    if not expected_source_sha or current_source_sha != expected_source_sha:
                        raise RuntimeError(
                            f"{repository.name}: source changed after validation "
                            f"(validated {expected_source_sha or 'missing'}, current {current_source_sha or 'missing'}). "
                            "Run discovery, migration/ELM synchronization, and validation again before archival."
                        )

                    target_connector_id = str(approved.get("target_connector_id") or "")
                    target_connector = db.get(Connector, target_connector_id)
                    if (
                        not target_connector
                        or target_connector.workspace_id != freeze.workspace_id
                        or target_connector.kind != ConnectorKind.ghec
                    ):
                        raise RuntimeError(f"{repository.name}: validated destination connector is unavailable")
                    target_token = decrypt_secret(target_connector.encrypted_token)
                    if not target_token:
                        raise RuntimeError(f"{repository.name}: validated destination token is unavailable")
                    target_client = target_clients.get(target_connector.id)
                    if target_client is None:
                        target_client = GitHubClient(
                            target_connector.api_url,
                            target_token,
                            target_connector.verify_ssl,
                        )
                        target_clients[target_connector.id] = target_client
                    target_org = str(approved.get("target_org") or "")
                    target_repo = str(approved.get("target_repo") or "")
                    target_data = target_client.get_repository(target_org, target_repo)
                    expected_target_id = approved.get("target_repository_id")
                    if expected_target_id is None or str(target_data.get("id")) != str(expected_target_id):
                        raise RuntimeError(
                            f"{repository.name}: destination repository identity no longer matches the migration ledger"
                        )
                    target_latest = target_client.get_latest_commit(
                        target_org,
                        target_repo,
                        target_data.get("default_branch"),
                    )
                    current_target_sha = (target_latest or {}).get("sha")
                    expected_target_sha = approved.get("validated_target_sha")
                    if not expected_target_sha or current_target_sha != expected_target_sha:
                        raise RuntimeError(
                            f"{repository.name}: destination changed after validation "
                            f"(validated {expected_target_sha or 'missing'}, current {current_target_sha or 'missing'}). "
                            "Repeat validation before source archival."
                        )
                    if current_source_sha != current_target_sha:
                        raise RuntimeError(
                            f"{repository.name}: source and destination heads differ at source-read-only preflight"
                        )
                    live_preflight[repository.id] = {
                        "source_sha": current_source_sha,
                        "target_sha": current_target_sha,
                        "target_repository_id": target_data.get("id"),
                        "checked_at": utcnow().isoformat(),
                    }
        finally:
            for target_client in target_clients.values():
                target_client.close()

    results: list[dict[str, Any]] = []
    archived = skipped = failed = 0
    client: GitHubClient | None = None
    try:
        if token:
            client = GitHubClient(connector.api_url, token, connector.verify_ssl)
        total = len(repositories)
        for index, repository in enumerate(repositories, start=1):
            update_job(db, job, progress=max(2, int((index - 1) / max(total, 1) * 94)), step=f"Reviewing {repository.name}")
            if repository.archived:
                skipped += 1
                result = {"repository": repository.name, "status": "skipped", "reason": "Source is already archived"}
            elif freeze.dry_run:
                skipped += 1
                result = {
                    "repository": repository.name,
                    "status": "would_archive",
                    "action": "PATCH repository archived=true",
                    "source_modified": False,
                }
            elif simulated:
                archived += 1
                result = {
                    "repository": repository.name,
                    "status": "archived",
                    "simulation": True,
                    "source_modified": False,
                }
            else:
                try:
                    assert client is not None
                    approved = evidence[repository.id]

                    # Close the residual race between the batch preflight and
                    # this individual archive request. Both endpoints must still
                    # identify the same repositories and the same validated head.
                    source_data = client.get_repository(freeze.source_org, repository.name)
                    source_latest = client.get_latest_commit(
                        freeze.source_org,
                        repository.name,
                        source_data.get("default_branch"),
                    )
                    current_source_sha = (source_latest or {}).get("sha")
                    if current_source_sha != approved.get("validated_source_sha"):
                        raise RuntimeError(
                            f"{repository.name}: source changed immediately before archival; "
                            "the batch was halted for this repository"
                        )

                    target_connector = db.get(Connector, str(approved.get("target_connector_id") or ""))
                    if not target_connector or target_connector.workspace_id != freeze.workspace_id:
                        raise RuntimeError(f"{repository.name}: validated destination connector is unavailable")
                    target_token = decrypt_secret(target_connector.encrypted_token)
                    if not target_token:
                        raise RuntimeError(f"{repository.name}: validated destination token is unavailable")
                    with GitHubClient(
                        target_connector.api_url,
                        target_token,
                        target_connector.verify_ssl,
                    ) as target_client:
                        target_org = str(approved.get("target_org") or "")
                        target_repo = str(approved.get("target_repo") or "")
                        target_data = target_client.get_repository(target_org, target_repo)
                        if str(target_data.get("id")) != str(approved.get("target_repository_id")):
                            raise RuntimeError(
                                f"{repository.name}: destination identity changed immediately before archival"
                            )
                        target_latest = target_client.get_latest_commit(
                            target_org,
                            target_repo,
                            target_data.get("default_branch"),
                        )
                        current_target_sha = (target_latest or {}).get("sha")
                    if (
                        current_target_sha != approved.get("validated_target_sha")
                        or current_source_sha != current_target_sha
                    ):
                        raise RuntimeError(
                            f"{repository.name}: destination changed immediately before archival; "
                            "repeat validation"
                        )

                    response = client.archive_repository(freeze.source_org, repository.name)
                    archived += 1
                    repository.archived = bool((response or {}).get("archived", True))
                    db.add(repository)
                    db.commit()
                    result = {
                        "repository": repository.name,
                        "status": "archived",
                        "source_modified": True,
                        "repository_id": (response or {}).get("id"),
                        "source_sha_rechecked": current_source_sha,
                        "target_sha_rechecked": current_target_sha,
                        "rechecked_at": utcnow().isoformat(),
                    }
                except (GitHubApiError, RuntimeError) as exc:
                    failed += 1
                    result = {"repository": repository.name, "status": "failed", "error": str(exc)}
            results.append(result)
            append_job_log(job, "Source read-only repository result", result)
    finally:
        if client:
            client.close()

    freeze.archived_count = archived
    freeze.skipped_count = skipped
    freeze.failed_count = failed
    freeze.status = JobStatus.failed if failed else JobStatus.succeeded
    freeze.result_json = {
        "source_org": freeze.source_org,
        "dry_run": freeze.dry_run,
        "archived": archived,
        "skipped": skipped,
        "failed": failed,
        "results": results,
        "live_preflight": live_preflight,
        "important_note": (
            "Archiving is reversible in GitHub but is still a source-side change. "
            "ForgeBridge never deletes source repositories. ELM final cutover uses the official ELM archive behavior instead."
        ),
    }
    freeze.finished_at = utcnow()
    db.add(freeze)
    db.commit()
    status = JobStatus.failed if failed else JobStatus.succeeded
    update_job(db, job, status=status, progress=100, step="Source read-only workflow complete", result=freeze.result_json)
    return freeze.result_json
