# ForgeBridge 0.1.2 validation and test plan

## Automated build gate

Build 004 deliberately contains only one shell entrypoint, so validation uses the standard Python/Alembic tools directly during release engineering:

```bash
bash -n forgebridge.sh
python3 -m compileall -q app scripts tests alembic
pytest -q
```

The release gate performs:

1. Bash syntax validation of the single operator entrypoint.
2. Python compilation of application, Alembic, scripts, and tests.
3. Forty automated regression tests.
4. Fresh temporary SQLite database upgrade to Alembic head.
5. Alembic model/schema drift check.
6. Seeded 0.1.0 schema upgrade to 0.1.2 with record-retention and branding-schema assertions.
7. Active Alembic revision verification.
8. Complete release-manifest verification and archive extraction checks.
9. Static Docker/Compose checks for port 3002, pip/PyPI absence, standalone GEI pinning, and GitHub-supported-only method enforcement.

Automated coverage includes:

- Workflow scanner extraction for secrets, variables, list-valued runners, nested permissions, URLs, actions, and risk findings.
- Official GEI command construction and source-lock/target flags.
- Current embedded ELM patch-floor eligibility and fail-closed behavior for unknown trains.
- Full simulated login, deep discovery, selected migration, method concurrency cap, duplicate delivery suppression, validation, evidence ZIP, and target-purge dry run.
- All requested menu families and pages.
- Workspace migration-profile validation.
- Standalone validation scoring and grading.
- Source read-only dry-run state transition.
- Menu/branding/user/AI administration persistence and authorization behavior.
- Grouped top-menu shell, browser favicon, logo rendering, dynamic theme CSS, editable build identity, port 3002, and production launcher contract.

## Schema-upgrade acceptance

Before upgrading a deployed 0.1.0 environment:

1. Back up PostgreSQL and the token-encryption key.
2. Restore the backup into a non-production environment.
3. Run `alembic upgrade head` using 0.1.2.
4. Confirm users, workspaces, connectors, discovery runs, jobs, migrations, validations, purge records, and audit history remain available.
5. Run the 0.1.2 idempotent seed phase once, then confirm 19 menu settings and one AI configuration record exist.
6. Confirm branding version/build are updated only when the record still contains an earlier packaged default; custom product identity is retained.
7. Exercise rollback only in a disposable environment and document data implications.

## Required enterprise acceptance tests

### Identity and tenancy

- URL substitution cannot access another user's workspace.
- Standard users cannot access admin routes.
- Deactivated users cannot authenticate.
- Self-disable/self-demotion and removal of last active admin are rejected.
- Enterprise SSO group-role mapping, MFA, session revocation, and deprovisioning work after integration.
- Audit captures actor, workspace, action, resource, IP, and timestamp.
- Menu hiding does not bypass route authorization.

### Connector and credential tests

- Correct GHES/GHEC identity, version, scopes, target flavor, and accessible organizations are returned.
- Bad/expired PAT, missing scope, SAML authorization failure, IP allow-list failure, TLS failure, proxy failure, timeout, rate limit, and service incident are handled.
- Source/target connector reversal is rejected.
- Token values are absent from UI, command previews, structured job logs/results, CLI stdout/stderr logs, process arguments, reports, exceptions, and APM payloads.
- Token rotation invalidates prior test status.
- Connector deletion is blocked while referenced.

### Discovery tests

- At least one repository from each category: empty, archived, fork, LFS, release-heavy, large, monorepo, Actions-heavy, reusable workflows, no Actions, packages, Pages, restricted visibility, and limited token permissions.
- Quick and deep scan behavior is distinguishable.
- Target probe correctly marks absent, present, renamed, and inaccessible targets.
- Discovery rerun updates materialized inventory and appends a snapshot.
- Last commit, author/committer, activity age, refs, counts, and release assets match source evidence.
- API permission gaps are reported rather than misrepresented as confirmed zero.
- Optional large-object scan cleans temporary storage and does not expose PATs.
- Ten or more organizations remain segregated by workspace/run.

### Readiness, filters, and scopes

- Each blocker/warning is reproducible from stored evidence.
- Grade changes deterministically when evidence changes.
- Client-side grade/filter manipulation cannot bypass server preflight.
- Saved scopes cannot reference another workspace.
- Duplicate or invalid destination names are rejected.
- ELM is rejected for `github.com`, unsupported GHES patch, HTTP source, public repository, and release asset over 2 GiB.
- Unknown future GHES train fails closed until policy update.

### Pipeline and 1Password tests

- Secrets/variables in expressions and reusable workflows.
- Scalar/list/matrix runner configurations.
- Environments, OIDC permissions, container credentials, URLs, action dependencies, and custom actions.
- Hard-coded credential false-positive and false-negative review.
- Malformed and very large workflow files fail safely.
- Pipeline reports contain names/context but no secret values.
- Workflow path and content hash remain unchanged after migration.
- Proposed `op://` paths follow enterprise vault naming standards.
- Real 1Password Connect test and least-privilege access are validated separately.

### GEI trial matrix

- Representative repository from every readiness/risk category.
- Standard GHEC and GHE.com target.
- Destination absent versus destination conflict.
- Releases included and approved `--skip-releases` case.
- Archive/storage limit error, large file, LFS, and release-heavy cases.
- PAT, SSO, IP allow-list, rate-limit, network, and GitHub service failures.
- Five concurrent operations and queued overflow.
- Retry only failed repositories.
- Duplicate worker delivery does not repeat a completed repository.
- Trial leaves source unlocked and unchanged.
- Production plan cannot omit official source lock.
- Final source SHA is captured at the approved freeze point.
- Standalone source archive revalidates source identity/SHA and destination identity/SHA immediately before each individual archive request.

### ELM trial matrix

- Each currently supported minimum patch and each immediately prior unsupported patch.
- GHE.com eligibility and GitHub enablement.
- Public repository and oversized release-asset rejection.
- Ten-per-source concurrency control.
- Initial migration to ready-for-cutover.
- Official supported live-update types.
- Initial-backfill-only and unsupported changes are documented.
- Explicit cutover, final synchronization, source archive, and destination validation.
- SSH interruption and polling timeout reconciliation.

### Background jobs and recovery

- Queue dispatch failure marks the job failed before external work.
- Browser navigation does not interrupt work.
- Web process restart while a job is queued.
- Worker restart before claim.
- Worker termination during an external migration.
- Redis interruption and redelivery.
- PostgreSQL failover.
- Report/log storage unavailable.
- Official migration state is reconciled before retry after ambiguous failure.
- Backup/restore retains evidence and encryption-key access.

### Azure OpenAI tests

- Managed identity and API-key authentication in approved network paths.
- Endpoint validation rejects non-Azure or insecure URLs.
- Redirects are refused.
- Disabled configuration and disabled use case reject interpretation.
- Sanitization tests for PATs, bearer tokens, API keys, passwords, and known internal secret patterns.
- Input/output limits and timeout behavior.
- Model outage, throttling, malformed response, and content-filter errors do not affect migration state.
- Prompt injection embedded in job logs cannot trigger tools because no tool execution path exists.
- Output clearly remains advisory and never changes grade, retry, freeze, cutover, or purge authorization.

### Standalone and migration-linked validation

- Default-branch head SHA.
- Every branch and tag ref.
- Workflow path and SHA-256 content hash.
- Pull-request and release counts.
- Issue/PR counter expected differences.
- Visibility, default branch, and selected settings.
- LFS objects through clean clone and object fetch.
- Packages, Pages, teams, access, Apps, webhooks, runners, Actions configuration, OIDC, rulesets, and Advanced Security through external checks.
- Score/grade is deterministic from check status.
- A failure blocks source-read-only evidence approval.

### Target purge tests

- Dry run lists only repositories owned by the selected trial run.
- Wrong cleanup token, confirmation, mode, feature flag, org, name, or repository ID is rejected.
- Production run is rejected.
- Replaced/renamed target is rejected.
- Already absent target is safely reported.
- Repeated purge is idempotent.
- Source API receives no purge/delete call.
- No marker file/tag/branch/issue/PR is required.

### Source read-only tests

- Dry run makes no source API mutation.
- Feature flag off blocks real execution.
- Non-GHES connector is rejected.
- Missing completed migration or failed/missing validation evidence blocks archival.
- Already archived source is skipped.
- Selected repositories only are archived.
- Source delete API is never called.
- ELM run uses official ELM cutover rather than standalone archival.
- Audit and job evidence identify every source-side change.

## Production wave acceptance gate

A repository can be signed off only when:

- Official migration reports success or an approved exception exists.
- All critical validation checks pass.
- Warnings have named owners and dispositions.
- Final source SHA and all branch/tag refs match the approved cutover point.
- Access, identities/mannequins, Actions/1Password, runners, integrations, LFS, packages, Pages, rulesets, and security workstreams are complete or explicitly accepted.
- Clean clone, fetch, build, test, deployment, rollback, and monitoring checks pass.
- Evidence bundle is retained and approved by repository owner and migration authority.
