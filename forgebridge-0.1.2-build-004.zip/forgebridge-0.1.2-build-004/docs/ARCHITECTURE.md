# ForgeBridge 0.1.2 architecture

## Product boundary

ForgeBridge is a control plane for one product path: **GHES source to GHEC destination**. It coordinates discovery, official migration methods, validation, remediation evidence, and guarded operational controls. It is not a Git transport implementation.

## Logical view

```text
Browser
  |
  v
FastAPI web/control plane
  |-- login, CSRF, admin/user RBAC, workspace isolation
  |-- GitHub operational lanes and filters
  |-- connector/workspace/branding/user/menu/AI administration
  |-- job detail, reports, audit, help
  |
  +--> PostgreSQL / SQLite
  |      users, branding, menu settings, AI configuration,
  |      workspaces, encrypted connectors, discovery snapshots,
  |      saved scopes, jobs, migration runs, validation runs,
  |      purge runs, source-freeze runs, audit records
  |
  +--> Redis/Celery (production) or local executor (demo/test)
           |
           +--> Connector test --> GHES/GHEC/1Password REST APIs
           +--> Discovery ------> GHES REST APIs (read-only)
           +--> Large scan -----> temporary read-only Git mirror (optional)
           +--> GEI ------------> official checksum-pinned standalone GEI CLI
           +--> ELM ------------> SSH --> GHES admin shell --> official elm CLI
           +--> Validation -----> GHES and GHEC REST APIs
           +--> Target purge ---> GHEC REST API only, trial-only guarded delete
           +--> Source freeze --> GHES archive API, guarded and disabled by default
           +--> AI -------------> Azure OpenAI Responses API, advisory only
           +--> Reports --------> CSV/JSON/Markdown/ZIP evidence
```

## Navigation architecture

The web shell separates responsibilities:

- **GitHub** — discovery, pipeline lanes, migrations, validation, target purge, source read-only.
- **Operations** — jobs and reports.
- **Configure** — connectors, workspaces, branding, users, menu enablement, audit, AI.
- **Help** — product index and migration guide.

Menu enablement controls navigation visibility only. Route authorization and workspace ownership remain independent security checks.

## Trust boundaries

1. **Browser/session boundary** — signed cookie, CSRF, active-user, role, and workspace checks.
2. **Application/database boundary** — tenant-scoped records and encrypted connector/API-key fields.
3. **Worker boundary** — queued payloads contain record IDs, not plaintext PATs.
4. **GHES boundary** — read-only discovery; explicit official GEI lock, ELM cutover, or guarded archive only.
5. **GHEC boundary** — official import, validation, and strictly scoped trial purge.
6. **1Password boundary** — connectivity and owner-remediation planning, not secret extraction.
7. **Azure OpenAI boundary** — sanitized bounded evidence and advisory text; no tools or mutating functions.

## Core entities

- `User` — local identity, role, active state, login timestamps.
- `Branding` — product name, tagline, version, logo, support address.
- `MenuSetting` — navigation group/item state and administrator restriction.
- `AIConfiguration` — encrypted Azure credential option, endpoint/deployment, allowlist, guardrail, limits, status.
- `Workspace` — owner-scoped migration boundary and default migration profile.
- `Connector` — GHES, GHEC, 1Password, or simulation endpoint with encrypted credential.
- `DiscoveryRun` — source scan, options, status, and organization summary.
- `RepositoryInventory` — latest materialized source state and readiness evidence.
- `RepositorySnapshot` — point-in-time inventory payload for a discovery run.
- `SavedRepositoryScope` — named list of repository IDs for repeated selection.
- `Job` — persistent asynchronous unit with status, progress, payload, result, error, and log.
- `MigrationRun` — method, mode, connectors, orgs, lane, policy, concurrency, acknowledgement, cleanup token, preflight.
- `RepoMigration` — one source/target mapping, attempts, official migration ID, SHAs, destination ID, result/error.
- `ValidationRun` — standalone or migration-linked checks, score, grade, and report.
- `PurgeRun` — destination-only trial cleanup request/result.
- `SourceFreezeRun` — source archive dry-run/execution request/result.
- `AuditLog` — actor, action, resource, workspace, IP, details, timestamp.

## Discovery flow

1. Operator chooses a GHES source, source organization, target connector/organization, method, and scan options.
2. ForgeBridge commits a `DiscoveryRun` and persistent `Job` before dispatch.
3. Worker atomically claims the job.
4. Source organization/repository APIs are queried; workflow text is parsed without modification.
5. Optional target probe identifies collisions.
6. Optional large-object scan creates a temporary read-only mirror using `GIT_ASKPASS`; credentials are not placed in the command line and the mirror is removed.
7. Deterministic readiness checks calculate blocker/warning evidence, score, and grade for the selected method.
8. Current inventory is upserted and a point-in-time snapshot is appended.
9. Progress and JSONL logs are persisted; reports become available.

Discovery never calls a source mutation or delete API.

## Plan and preflight flow

1. Operator uses all/pipeline/non-pipeline lane, filters, saved scope, and target mappings.
2. Browser selection is submitted with explicit unsupported-workstream acknowledgement.
3. Server verifies connector roles, org/name syntax, uniqueness, method/mode, destination flavor, concurrency, and source-lock policy.
4. Every repository is re-evaluated using current deterministic readiness checks; client-side grade/filter values are not trusted.
5. Accepted and rejected repository evidence is saved in the run preflight.
6. Run, per-repository rows, job, and internal cleanup token are committed before queue dispatch.

## GEI flow

1. Worker performs current preflight and validates tooling.
2. Each repository is claimed atomically within the five-operation cap.
3. ForgeBridge invokes GitHub's official standalone `gei migrate-repo` with source and destination PATs in process environment variables.
4. Production runs include official `--lock-source-repo`; trials do not.
5. Full command output is streamed to a bounded-tail log; PAT values are not intentionally printed.
6. Official migration ID and destination repository ID are captured where available.
7. Completed, warning, and failed entries retain evidence and remediation guidance.
8. Retry creates work only for failed/warning-eligible entries and never repeats a completed claim blindly.

## ELM flow

1. Preflight verifies GHE.com destination, current embedded patch floor, HTTPS, visibility, release assets, concurrency, and SSH configuration.
2. Official ELM commands run through the GHES administrative shell.
3. Initial migration is monitored until ready-for-cutover or failure/timeout.
4. Cutover is a separate audited action.
5. Official ELM completes final synchronization and source archival behavior.
6. ForgeBridge validates destination evidence.

## Validation flow

Validation may be migration-linked or standalone:

1. Resolve source and target mapping.
2. Read both repositories.
3. Compare selected settings, default head, every branch/tag ref, workflow paths/hashes, and available counts.
4. Classify each check as pass, warning/expected difference, or failure.
5. Produce deterministic score/grade and JSON evidence.
6. Keep external workstreams outside the automated-pass claim.

## Pipeline and 1Password flow

1. Parse workflow YAML and API metadata.
2. Inventory secret/variable names, environments, URLs, runner labels, action dependencies, permissions, OIDC indicators, and probable credential literals.
3. Generate owner CSV and proposed `op://` mappings.
4. Owners populate approved vault items after migration.
5. Workflow conversion occurs through ordinary reviewed PRs; ForgeBridge does not rewrite repository content.

## AI flow

1. Administrator configures Azure OpenAI and an explicit use-case allowlist.
2. Operator requests interpretation from a job detail page.
3. A separate background job loads bounded source-job status/result/log evidence.
4. Common credential patterns are redacted.
5. Administrator system guardrail plus fixed ForgeBridge safety instruction are sent with `store=false`.
6. Output is stored as advisory job evidence only; no function/tool call path exists.

## Target purge safety

A repository is eligible only when all conditions hold:

- Migration mode is trial.
- `ENABLE_DESTRUCTIVE_PURGE=true` for real deletion.
- Exact run cleanup token is supplied.
- Exact destructive confirmation is supplied.
- Target repository completed under this run.
- Captured destination repository ID still matches the API result.
- Organization and mapped repository name match.
- Destination connector is used; source connector is never passed.

Dry-run is the default. No marker is written into the repository.

## Source read-only safety

- Dry-run is the default.
- Real execution requires `ENABLE_SOURCE_FREEZE=true`.
- Source connector must be GHES.
- Each selected repository must have approved completed-migration and validation evidence for real non-simulated execution.
- Already archived repositories are skipped.
- Archive is reversible in GitHub, but remains a source mutation and must be change-controlled.
- No source delete operation exists.
- For ELM, official ELM cutover remains authoritative.

## Deployment profiles

### Demo/test

- SQLite
- Local thread executor
- Simulation connectors
- Alembic-managed schema
- Mutating feature flags disabled

### Production baseline

- Approved TLS ingress and enterprise SSO/OIDC
- PostgreSQL
- Redis and Celery workers
- Alembic before application startup
- Unique session/encryption secrets and managed secret bootstrap
- `DEMO_MODE=false`, `AUTO_CREATE_TABLES=false`, `TASK_MODE=celery`
- Central logs, metrics, queue monitoring, backup/restore, SIEM, and alerting
- Restricted network paths to GHES, GHEC, Azure OpenAI, and 1Password
- Change-controlled migration, purge, and source-freeze flags


## Build 004 runtime packaging

The production image is based on Debian 13 Trixie. Python modules are installed from Debian's signed repositories; the Dockerfile contains no pip/PyPI dependency step. GitHub Enterprise Importer is the pinned standalone v1.30.3 executable, selected for the Docker target architecture and checked against GitHub's published SHA-256 value.

The same versioned image is reused by migrate, seed, web, and worker services, reducing runtime drift. Port 3002 remains the only application port exposed by the image.
