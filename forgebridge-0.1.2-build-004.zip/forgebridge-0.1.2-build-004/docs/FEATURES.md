# ForgeBridge 0.1.2 feature inventory

Policy reference: **2026-07-14**

Status meanings:

- **Implemented** — present and covered by the reference build.
- **Implemented with constraints** — present, but limited by method, permissions, feature flags, or external systems.
- **Integration point** — product configuration or evidence exists, but enterprise integration remains customer work.
- **Not implemented** — deliberately absent or a future hardening item.

## Navigation and product shell

| Area | Feature | Status | Notes |
|---|---|---|---|
| GitHub | Repository discovery | Implemented | Background source inventory, target probes, pipeline scans, readiness grades, filters, snapshots, and exports. |
| GitHub | Repository with pipelines | Implemented | Isolated lane for repositories with detected Actions workflows. |
| GitHub | Pipeline owner handoff | Implemented | Owner-ready Actions, environment, runner, URL, secret-name, variable, dependency, Markdown/JSON/CSV exports, and proposed 1Password remediation evidence; never secret values. |
| GitHub | Repository without pipelines | Implemented | Isolated lane for repositories without detected Actions workflows. |
| GitHub | Migration runs | Implemented | Planning, queuing, monitoring, retry, cutover, validation, purge, and evidence. |
| GitHub | Repository validation | Implemented | Standalone source/target validation for selected repositories. |
| GitHub | Target purge | Implemented with constraints | Trial-only destination cleanup with dry run, cleanup token, confirmation, and repository-ID match. |
| GitHub | Source read-only | Implemented with constraints | Dry-run or guarded source archive; no source deletion. |
| Operations | Jobs | Implemented | Persistent job ledger and job detail with log/result evidence. |
| Operations | Reports | Implemented | CSV, JSON, Markdown, and ZIP evidence. |
| Configure | Connectors | Implemented | GHES, GHEC, GHE.com, 1Password Connect, and simulation. |
| Configure | Workspaces | Implemented | User-owned migration boundaries. |
| Configure | Branding | Implemented | Name, tagline, displayed version, logo URL, and support email. |
| Configure | Users | Implemented | Create, update role/email/active state/password; protects last administrator. |
| Configure | Menu enablement | Implemented | Administrator can hide navigation; authorization remains route-enforced. |
| Configure | Audit log activity | Implemented | Global administrator view plus workspace audit view. |
| Configure | AI configuration | Implemented with constraints | Azure OpenAI advisory analysis only. |
| Help | Help index | Implemented | Product workflow and safety entry point. |
| Help | GitHub Enterprise migration guide | Implemented | Method selection, discovery, trial, cutover, validation, and remediation guide. |

## Authentication, tenancy, and administration

| Feature | Status | Notes |
|---|---|---|
| Login and logout | Implemented | Argon2 password hashing and signed HTTP-only session cookie. Local auth is for the reference build. |
| Administrator and user roles | Implemented | Admin-only pages are route-protected. |
| User lifecycle | Implemented | Administrator can create, activate/deactivate, change role/email, and reset password. Self-demotion/disable and removal of the last active admin are blocked. |
| Workspace ownership | Implemented | Standard users can access their own workspaces; admins can inspect all. |
| Workspace migration profile | Implemented | Default source/target connectors, organizations, method, and concurrency. Connector roles are validated server-side. |
| Menu visibility control | Implemented | Configuration menu cannot hide itself; hidden routes retain authorization. |
| Branding | Implemented | Editable product identity shown by the UI. |
| Enterprise SSO/OIDC/SAML/SCIM | Integration point | Required before production. |
| Fine-grained workspace roles | Not implemented | Current authorization is global admin or workspace owner. |

## Connectors and credentials

| Feature | Status | Notes |
|---|---|---|
| GHES source connector | Implemented | Base/API URL, classic PAT, TLS verification, live test, identity, scopes, org access, and version metadata where available. |
| GHEC on `github.com` | Implemented | Standard cloud target. |
| GHEC with data residency on `GHE.com` | Implemented | Target API URL and ELM eligibility path. |
| 1Password Connect | Implemented with constraints | Connectivity verification and remediation/report support; no GitHub secret-value extraction. |
| Simulation connectors | Implemented | Generated organization/repository data for safe local testing. |
| Connector-role enforcement | Implemented | Source must be GHES; target must be GHEC. |
| Token encryption | Implemented | Fernet encryption at rest; UI shows only last four characters. |
| Token rotation | Implemented | Replacing a token resets connector test state. |
| Connector delete guard | Implemented | Referenced connectors cannot be casually removed. |
| Managed identity for Azure OpenAI | Implemented | Uses `DefaultAzureCredential`; interactive browser authentication is disabled. |
| Managed identity for GitHub PAT replacement | Not available in this build | GitHub migration credentials remain governed classic PATs according to current method requirements. |

## Discovery and repository intelligence

| Feature | Status | Notes |
|---|---|---|
| Background discovery | Implemented | Job continues after navigation and is visible in Jobs. |
| Quick/deep options | Implemented | Deep scan gathers extended repository, Actions, release, access, and integration evidence. |
| Target probe | Implemented | Detects destination existence/conflicts before planning. |
| Pipeline scan | Implemented | Scans workflow YAML without modification. |
| External pipeline evidence | Implemented where APIs permit | Environments, runners, settings, and related metadata. |
| Discovery history | Implemented | One persistent run per scan with timestamps, options, status, and summary. |
| Point-in-time snapshots | Implemented | Repository snapshot retained for every discovery run. |
| Organization evidence | Implemented where permissions permit | Organization metadata, teams, members, outside collaborators, hooks, rulesets, secret names, and variable names. |
| Repository identity/settings | Implemented | Numeric/node ID, visibility, default branch, description, homepage, language, license, topics, dates, size, fork/archive/disabled state. |
| Last activity | Implemented | Last commit SHA/time and author/committer evidence as returned by GitHub; inactivity days calculated. |
| Refs/counts | Implemented | Branches, protected branches, tags, issues, pull requests, releases, forks, stars, and watchers. |
| Contributors/collaborators | Implemented where permissions permit | Login, role/permissions, contribution count, and account type. |
| Releases/assets | Implemented | Tags, names, sizes, total bytes, largest asset, and ELM 2 GiB screening. |
| LFS indicator | Implemented as heuristic | Detects LFS attributes; GEI LFS transfer remains a separate workstream. |
| Optional large-object scan | Implemented with constraints | Temporary read-only mirror and blob-size report; disabled by default; never used for migration. |
| Repository creator | Limited by GitHub API | No reliable universal creator field; ForgeBridge does not fabricate it. |
| Private email recovery | Not possible | Only API/commit values returned by GitHub are stored. |

## Readiness checks, grades, filters, and scopes

| Feature | Status | Notes |
|---|---|---|
| Deterministic readiness score | Implemented | Derived from explicit checks, not AI. |
| Letter grade | Implemented | A–F or not assessed, with blocker/warning counts. |
| GEI-specific checks | Implemented | Connector readiness, destination conflict, archive/release/LFS indicators, source mode, and applicable limits. |
| ELM-specific checks | Implemented | GHE.com target, current embedded patch floor, HTTPS, private/internal visibility, 2 GiB release-asset limit, and source configuration. |
| Search | Implemented | Repository text search in discovery and lane tables. |
| Filters | Implemented | Grade, pipeline presence, blocker status, visibility, activity, size/risk, and available table dimensions. |
| Select visible | Implemented | Client convenience only; server preflight remains authoritative. |
| Saved repository scopes | Implemented | Save and delete exact repository-ID selections per workspace; stale or removed IDs are surfaced rather than substituted. |
| Target-name mapping | Implemented | Validated destination names with duplicate detection. |
| Server-side plan re-evaluation | Implemented | Recomputes method readiness for every selected repository and records accepted/rejected items. |
| Plan/execute separation | Implemented | Plan-only creation performs no migration; queueing requires exact `QUEUE <run-id>` confirmation. |
| AI-generated grades | Not used | AI cannot set readiness, approval, or execution state. |

## GitHub Actions and pipeline assessment

| Feature | Status | Notes |
|---|---|---|
| Workflow inventory | Implemented | Paths, content hash inputs, and parsed evidence. |
| Secret references/names | Implemented | Detects expressions and API-listed names; never retrieves values. |
| Variable references/names | Implemented | Detects expressions and API-listed names. |
| Environment inventory | Implemented | Names and available protection/deployment metadata. |
| Runner labels | Implemented | Scalar/list `runs-on`, self-hosted, and GitHub-hosted labels. |
| External URLs | Implemented | Extracted for network, DNS, and endpoint review. |
| Action dependencies | Implemented | Captures `uses:` references. |
| Permissions and OIDC indicators | Implemented | Workflow/job mappings and token-related permissions. |
| Hard-coded credential heuristics | Implemented | Flags probable patterns; manual review is mandatory. |
| Pipeline risk score | Implemented | Heuristic owner-review score, separate from migration approval. |
| Owner remediation CSV | Implemented | Secrets, variables, environments, URLs, runners, actions, workflows, and findings. |
| 1Password Markdown plan | Implemented | Proposed `op://` references and owner actions. |
| Automatic secret extraction | Not possible | GitHub does not expose secret values. |
| Automatic 1Password write | Not implemented | Vault population requires separately governed credentials and ownership. |
| Automatic workflow rewrite | Intentionally not implemented | Would alter repository content; use reviewed post-migration PRs. |

## Migration planning and official execution

| Feature | Status | Notes |
|---|---|---|
| Organization-to-organization mapping | Implemented | Destination organization must already exist. |
| Selected repository migration | Implemented | One source-to-target mapping per repository. |
| All/pipeline/non-pipeline lanes | Implemented | Same discovery evidence; separate operational views and plan lane. |
| Trial and production mode | Implemented | Different source-lock and purge behavior. |
| Manual-action acknowledgement | Implemented | Operator confirms unsupported/separate workstreams before plan creation. |
| GEI | Implemented | Invokes GitHub's official standalone `gei migrate-repo` executable. |
| GEI source lock | Implemented | Required for production GEI plans through official `--lock-source-repo`. |
| GEI release skip | Implemented | Explicit official option where approved. |
| GEI delta | Rejected | No supported delta synchronization. |
| ELM | Implemented as guarded adapter | Official `elm` CLI over GHES admin-shell SSH for eligible GHE.com destinations. |
| ELM cutover | Implemented | Separate explicit action after ready-for-cutover. |
| Simulation | Implemented | Exercises state transitions without external mutation. |
| Method concurrency | Implemented | ForgeBridge defaults to five parallel GEI tasks as a conservative application throttle, not an official GitHub service maximum. ELM is capped at the documented ten concurrent migrations per source GHES. |
| Retry failed | Implemented | Does not repeat completed repositories. |
| Idempotent background claim | Implemented | Duplicate task delivery is ignored after claim/completion. |
| Destination conflict protection | Implemented | Existing targets reject or block applicable plans. |
| Source deletion | Not implemented | Product invariant. |
| Custom mirror/API migration | Not implemented | Optional mirror is screening only. |

## Jobs, diagnostics, and AI

| Feature | Status | Notes |
|---|---|---|
| Persistent job ledger | Implemented | Type, workspace, creator, status, progress, step, payload, result, error, timestamps, and log path. |
| Job detail | Implemented | Bounded log display, result/error details, and related AI interpretations. |
| JSON status API | Implemented | Supports UI polling. |
| JSONL log download | Implemented | Path-contained download. |
| Local executor | Implemented | Demo/test thread pool. |
| Celery/Redis executor | Implemented | Production topology baseline. |
| Queue-dispatch failure handling | Implemented | Job marked failed before external work starts. |
| Worker lease/reaper | Not implemented | External status must be reconciled after hard worker loss. |
| Azure OpenAI configuration | Implemented | Endpoint, deployment, managed identity/API key, limits, allowlist, guardrail, and test. |
| Job interpretation | Implemented with constraints | Sanitized bounded evidence; output is advisory. |
| AI tool/function execution | Not implemented | Model cannot call GitHub or mutate ForgeBridge state. |
| AI approval/grade override | Prohibited by design | Deterministic checks remain authoritative. |
| Central metrics/notifications | Not implemented | Production integration required. |

## Validation, purge, source read-only, and evidence

| Feature | Status | Notes |
|---|---|---|
| Migration-linked validation | Implemented | Starts from a migration run. |
| Standalone validation | Implemented | Select connectors, orgs, method, lane, repos, and target names. |
| Ref comparison | Implemented | Default head, all branch refs, and all tag refs. |
| Workflow comparison | Implemented | Path and SHA-256 content hash. |
| Metadata comparison | Implemented | Selected settings and counts, with expected-difference handling. |
| Validation score/grade | Implemented | Deterministic aggregate with pass/warning/failure counts. |
| Trial purge dry run | Implemented | Default behavior. |
| Destructive trial purge | Implemented with constraints | Feature flag, exact token, exact confirmation, destination ID/name/org match, trial only. |
| Production purge | Blocked | Not available. |
| Internal cleanup token | Implemented | Stored in ForgeBridge; no repository marker is created. |
| Source read-only dry run | Implemented | Shows intended archives without source mutation. |
| Real source archive | Implemented with constraints | Feature flag, accepted migration/validation evidence, batch preflight, and immediate per-repository source/target identity and SHA recheck; uses GitHub repository archive API. |
| ELM source handling | Official method | Use official ELM cutover, not standalone source archive, for ELM. |
| Source repository deletion | Not implemented | Never available. |
| Discovery CSV | Implemented | Current repository inventory. |
| Pipeline CSV | Implemented | Owner remediation. |
| Mapping CSV | Implemented | One-to-one mappings, IDs, SHAs, attempts, status, errors. |
| Summary JSON | Implemented | Machine-readable migration-run state. |
| Validation JSON | Implemented | Full check evidence and grade. |
| 1Password Markdown | Implemented | Owner handoff. |
| Evidence ZIP | Implemented | Manifest, method policy, limitations, discovery, pipeline, mappings, summary, validation, and remediation files. |

## Operator interface and branding

| Feature | Status | Notes |
|---|---|---|
| Syncline-style grouped navigation | Implemented | Overview, GitHub, Operations, Configure, and Help in a compact responsive top bar. |
| Workspace selector | Implemented | Switches the active accessible workspace from the global navigation. |
| Browser favicon | Implemented | Packaged or configured product logo is emitted as the tab/bookmark identity. |
| Editable build number | Implemented | Displayed in navigation/user context, footer, login, branding preview, and health metadata. |
| Theme colors | Implemented | Eight persisted colors generate safe same-origin CSS variables. |
| Logo upload | Implemented | PNG/JPEG/WebP, content-signature validation, 2 MB ceiling, atomic persistent storage. |
| Dark mode | Implemented | Local presentation preference; does not alter migration data. |
| Port 3002 | Implemented | Docker, Compose, health checks, management script, and tests. |
| Single production management script | Implemented | Init, build, clean-build, start, stop, restart, status, health, tooling, logs, backup, upgrade, and doctor. |

## Security and deployment

| Feature | Status | Notes |
|---|---|---|
| CSRF | Implemented | Required on state-changing HTML forms. |
| Session protection | Implemented | Signed HTTP-only cookie; secure behavior in production. |
| Security headers | Implemented | CSP, frame denial, MIME protection, referrer/permissions policy, and production HSTS. |
| Workspace authorization | Implemented | Checked on workspace routes and resources. |
| Connector URL validation | Implemented | Restricts endpoint form and connector role. |
| Azure endpoint validation | Implemented | HTTPS Azure OpenAI endpoint allowlisting logic. |
| Redirect refusal for AI requests | Implemented | Protects credentials from redirected POSTs. |
| Input/log sanitization for AI | Implemented | Redacts common token/password patterns and bounds input. |
| Central job/result redaction | Implemented | Credential-bearing fields and token-shaped free text are redacted before persistence; safe secret-name and token-scope inventory remains visible. |
| Production configuration guard | Implemented | Rejects demo mode, SQLite, default/weak keys, auto-create schema, and local task mode. |
| PostgreSQL | Implemented/configured | Production baseline. |
| Redis/Celery | Implemented/configured | Production baseline. |
| Alembic 0.1.0→0.1.2 upgrade | Implemented and tested | Preserves existing core records and adds enhanced control-plane plus branding/build tables/columns. |
| Docker/Compose | Implemented | Web, worker, migration, PostgreSQL, and Redis. |
| SSO/MFA/PAM | Integration point | Mandatory production hardening. |
| KMS envelope encryption | Not implemented | Current encryption key is application-wide. |
| Tamper-evident SIEM audit | Not implemented | Relational audit exists; export/integration required. |
| SBOM/image signing/hash-locked dependencies | Not implemented | Required production supply-chain hardening. |

## Build 004 production packaging

- Production Docker does not run pip or contact PyPI.
- Python and application modules come from Debian 13 Trixie's signed repositories.
- Native `linux/arm64` and `linux/amd64` package resolution is automatic.
- GitHub's standalone GEI v1.30.3 is selected by architecture and SHA-256 verified.
- No startup-time extension installation occurs.
- No global custom-CA workflow is required.
- Standard TLS verification remains enabled.
