# ForgeBridge Build 004 installation and operations

## Prerequisites

- macOS or Linux
- Docker Desktop or Docker Engine running
- Docker Compose v2
- At least 4 GiB free disk space; 10 GiB or more is recommended
- Outbound access to Docker registries, Debian package repositories, and the official GitHub GEI release asset during the image build
- Port 3002 available on the selected bind address

No local Python installation, virtual environment, `pip install`, Node.js installation, custom CA import, or separate database installation is required.

## Recommended single-file installation

```bash
cd ~/Downloads
chmod +x forgebridge-0.1.2-build-004-installer.sh
./forgebridge-0.1.2-build-004-installer.sh
```

The self-extracting installer creates `forgebridge-0.1.2-build-004` in the current directory and invokes the one packaged management script. It refuses to overwrite an existing Build 004 directory.

To extract under a specific parent directory and import an earlier protected configuration:

```bash
./forgebridge-0.1.2-build-004-installer.sh \
  --target-dir /Users/femy.pancy/sites/ForgeBridge/v3 \
  --import-env /Users/femy.pancy/sites/ForgeBridge/v3/forgebridge-0.1.2/.env.production
```

## ZIP installation

```bash
cd ~/Downloads
unzip forgebridge-0.1.2-build-004.zip
cd forgebridge-0.1.2-build-004
chmod +x forgebridge.sh
./forgebridge.sh install
```

The `install` command performs all of the following:

1. Verifies `RELEASE-SHA256SUMS`.
2. Verifies Build 004 identity and port 3002.
3. Rejects any Dockerfile containing pip or PyPI installation.
4. Rejects unsupported migration-engine commands.
5. Creates `.env.production` with random secrets when needed.
6. Pulls PostgreSQL and Redis images.
7. Builds the ForgeBridge image without Docker cache.
8. Installs Python components from Debian's signed repositories.
9. Downloads GitHub's official standalone GEI v1.30.3 and verifies its published SHA-256 digest.
10. Verifies Python imports and `gei migrate-repo --help`.
11. Starts PostgreSQL and Redis.
12. Applies Alembic database migrations.
13. Applies idempotent application seed data.
14. Starts the web and Celery worker services.
15. Verifies `http://127.0.0.1:3002/health`.
16. Writes a non-secret installation receipt.

## Upgrade from an earlier ForgeBridge folder

Do not copy the new files over the old directory. Extract Build 004 into its uniquely named directory and import only the protected environment configuration:

```bash
cd ~/Downloads
unzip forgebridge-0.1.2-build-004.zip
cd forgebridge-0.1.2-build-004
chmod +x forgebridge.sh
./forgebridge.sh install --import-env /absolute/path/to/old/forgebridge/.env.production
```

When a Build 004 `.env.production` already exists and must deliberately be replaced:

```bash
./forgebridge.sh install --replace-env /absolute/path/to/approved/.env.production
```

The previous environment is backed up before replacement.

## Daily operation

Start:

```bash
./forgebridge.sh start
```

Stop without deleting data:

```bash
./forgebridge.sh stop
```

Restart:

```bash
./forgebridge.sh restart
```

Status:

```bash
./forgebridge.sh status
```

Health:

```bash
./forgebridge.sh health
```

Application logs:

```bash
./forgebridge.sh logs
```

Worker logs:

```bash
./forgebridge.sh logs worker
```

Database logs:

```bash
./forgebridge.sh logs postgres
```

## Verification

Release, Docker, Compose, settings, build identity, port, and migration-policy checks:

```bash
./forgebridge.sh doctor
```

Python and official GEI checks:

```bash
./forgebridge.sh tooling
```

Version and build:

```bash
./forgebridge.sh version
```

## Backup and upgrade

Backup:

```bash
./forgebridge.sh backup
```

Upgrade the extracted Build 004 source after an approved patch:

```bash
./forgebridge.sh upgrade
```

`upgrade` performs a backup when PostgreSQL is running, forces a no-cache application build, verifies the image, applies database migrations and seed data, recreates web/worker containers, and runs the health check.

## Runtime removal

Remove containers and the application image while preserving named volumes and configuration:

```bash
./forgebridge.sh uninstall
```

Reinstall later:

```bash
./forgebridge.sh install
```

## First access

Open:

```text
http://127.0.0.1:3002
```

The first successful install displays the initial administrator username and password. Change the password immediately after login.

## Enabling mutation capabilities

The generated configuration keeps real migration, ELM, target purge, and source read-only disabled. Enable them only after approvals and test evidence. The migration policy must remain:

```text
MIGRATION_POLICY_MODE=github-supported-only
```

Standard GHEC uses GEI. `ENABLE_ELM=true` is valid only after GitHub eligibility/enablement for a `GHE.com` data-residency destination.
