# Operator UI and production start

## Menu shell

ForgeBridge 0.1.2 follows the supplied reference application's compact enterprise navigation pattern:

- Overview
- GitHub
- Operations
- Configure
- Help

The GitHub menu exposes discovery, pipeline/non-pipeline lanes, owner handoff, migration, validation, purge, and source read-only. Configure exposes connectors, workspaces, branding, users, menu enablement, audit activity, and AI configuration.

## Browser identity

The page title, favicon, navigation logo, login identity, footer, version, and build number come from the branding record. A custom uploaded logo or HTTPS logo URL becomes the browser favicon through the rendered icon link.

## First production installation

Run the one packaged script:

```bash
chmod +x forgebridge.sh
./forgebridge.sh install
```

The installer verifies the package, builds the application image without pip/PyPI, initializes PostgreSQL and Redis, applies database migrations, seeds the application, starts the background worker, and starts the web application.

## Subsequent starts

```bash
./forgebridge.sh start
```

Open `http://127.0.0.1:3002` for loopback deployment. Place ForgeBridge behind approved HTTPS ingress and set `SESSION_COOKIE_SECURE=true` before network exposure.

Run `./forgebridge.sh help` for all management commands.
