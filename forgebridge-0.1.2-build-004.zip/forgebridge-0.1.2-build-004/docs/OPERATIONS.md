# ForgeBridge 0.1.2 operations runbook

Policy reference: **2026-07-14**


## 0. Start and manage the production stack

Use the single packaged installer and management script:

```bash
chmod +x forgebridge.sh
./forgebridge.sh install
```

The `install` command performs release-integrity checks, validates the GitHub-supported-only method policy, creates or imports the protected `.env.production`, pulls PostgreSQL and Redis, performs a no-cache application image build, verifies the official standalone GEI executable, applies Alembic migrations and idempotent seed data, starts the web and Celery worker services, and waits for the health endpoint on `http://127.0.0.1:3002`.

After installation, use `start`, `stop`, `restart`, `status`, `health`, `logs`, `backup`, `upgrade`, `uninstall`, or `doctor` as the first argument. `stop` preserves named volumes. Before network exposure, terminate TLS, set `SESSION_COOKIE_SECURE=true`, restrict proxy trust and firewall rules, and integrate enterprise identity controls.

## 1. Establish the migration program

Before using ForgeBridge, define:

- Executive, technical, security, and repository-owner accountability.
- Mapping for every GHES organization to an already-created GHEC organization.
- Destination identity, SSO, membership, naming, visibility, and policy standards.
- Accepted-parity criteria, expected differences, and separate remediation workstreams.
- Repository waves: low risk, standard, Actions-heavy, LFS, large/monorepo, and business critical.
- GEI maintenance-window or eligible ELM cutover model per wave.
- GitHub Support escalation path.
- Trial organization and destination-cleanup authority.

## 2. Prepare GitHub access

Use dedicated migration identities and time-bounded classic PATs with current GitHub-documented roles/scopes. Authorize destination tokens for SAML SSO where required and verify IP allow lists and network paths.

Never place PATs in source control, shell history, issues, reports, tickets, or chat transcripts.

Build 004 packages GitHub's official standalone GEI executable. Verify it through the production image:

```bash
./forgebridge.sh tooling
```

Expected readiness includes `gei --version` and a successful `gei migrate-repo --help`. The executable is pinned to v1.30.3, selected for `linux/arm64` or `linux/amd64`, and checked against GitHub's published SHA-256 digest. Do not install a floating latest extension during startup.

## 3. Configure identity and administration

1. Sign in with the bootstrap administrator.
2. Change bootstrap credentials and branding.
3. Create users or integrate enterprise SSO before production.
4. Deactivate unused accounts and retain at least one active administrator.
5. Configure menu visibility only for navigation clarity; it does not change authorization.
6. Review the global audit page after privileged changes.

## 4. Create workspaces

Create a workspace for an organization, wave, program, or isolated trial. Standard users manage their own workspaces; administrators can inspect all.

Configure the workspace migration profile:

- Default GHES source connector
- Default GHEC target connector
- Source organization
- Destination organization
- Default method
- Default concurrency

Do not share a workspace across unrelated programs unless the ownership and evidence-retention model explicitly requires it.

## 5. Configure connectors

For each workspace:

1. Create a GHES source connector.
2. Create a GHEC destination connector and choose `github.com` or `GHE.com` data residency.
3. Optionally create a 1Password Connect connector.
4. Keep TLS verification enabled.
5. Run every connection test as a background job.
6. Confirm identity, GHES version, token scopes, organization access, and destination flavor.
7. Correct all warnings before discovery or planning.

Rotate credentials through connector update. The previous plaintext is never displayed.

## 6. Use the product navigation

- **GitHub**: Repository discovery, Repository with pipelines, Repository without pipelines, Pipeline owner handoff, Migration runs, Repository validation, Target purge, Source read-only.
- **Operations**: Jobs and Reports.
- **Configure**: Connectors, Workspaces, Branding, Users, Menu enablement, Audit log activity, AI configuration.
- **Help**: Help index and GitHub Enterprise migration guide.

## 7. Run discovery

Run deep discovery for each source organization. The background job continues while the user visits other pages.

Choose as appropriate:

- Deep repository and organization scan
- Pipeline scan
- External Actions/environment/runner scan
- Target collision probe
- Readiness method: GEI or ELM
- Optional large-object scan, enabled only under capacity control

Review:

- Repository identity, visibility, default branch, size, fork/archive state, language, license, and topics.
- Last commit SHA/time, inactivity, author/committer evidence.
- Branches, protected branches, tags, issues, pull requests, releases, and assets.
- Contributors, collaborators, teams, outside collaborators, webhooks, deploy keys, and rulesets.
- Workflows, secret/variable names, environments, runners, URLs, dependencies, permissions, and hard-coded credential indicators.
- LFS indicators, release limits, large-object evidence, destination conflicts, blockers, warnings, score, and grade.

Export discovery and pipeline reports, use the Pipeline owner handoff page to generate owner-ready remediation evidence, and assign every item to a named owner.

## 8. Review lanes, filters, and saved scopes

Use:

- **Repository with pipelines** for Actions-bearing repositories.
- **Repository without pipelines** for repositories without detected workflow files.
- Search, grade, visibility, blocker, activity, and risk filters.
- Select visible for convenience.
- Saved scopes for repeatable selection.
- Target-name overrides for approved renaming.

Client filtering is not safety evidence. ForgeBridge recomputes eligibility server-side when the plan is created. Saved scopes retain exact repository IDs; removed or stale IDs are surfaced instead of being replaced silently.

## 9. Plan representative trials

Use the plan-only action first. Review the immutable repository mapping, blockers, warnings, owner handoff, method, run mode, source-lock policy, and command previews. Queueing requires the exact confirmation `QUEUE <run-id>`; creating a plan does not start migration work.


Trial at least one repository from every risk category in a disposable organization or disposable target names.

### GEI trial rules

- Do not lock the source.
- Do not treat the trial as a delta baseline.
- Record duration, archive/storage issues, warnings, missing objects, mannequin impact, and remediation effort.
- Validate destination refs, workflows, and metadata.
- Retain evidence before target purge.

### ELM trial rules

- Confirm GitHub has enabled ELM for the enterprise.
- Confirm current patch-floor eligibility and GHE.com destination.
- Test live-update behavior plus initial-backfill-only/unsupported changes.
- Exercise ready-for-cutover and cutover in a non-production repository.

## 10. Create and execute a migration run

1. Choose source/target connectors and organizations.
2. Select GEI or eligible ELM. Simulation is restricted to development/test environments and is not a production migration method.
3. Choose trial or production mode.
4. Choose all/pipeline/non-pipeline lane.
5. Select repositories and target mappings.
6. Choose pipeline policy and release behavior.
7. Set concurrency within the ForgeBridge GEI safety ceiling or documented ELM source limit.
8. Acknowledge the separate manual workstreams.
9. Create a plan-only run and review the server-side accepted/rejected preflight result.
10. Queue only after entering the exact `QUEUE <run-id>` confirmation.

GEI production requires the official source-lock option. ELM cutover remains a separate action.

## 11. Monitor Jobs

The persistent Jobs page shows type, status, percentage, current step, timestamps, error, result, and log. The job detail page shows bounded log content and downloadable JSONL evidence.

Operational interpretation:

- `queued`: inspect worker/queue health if prolonged.
- `running`: inspect the current step and official GitHub migration state.
- `failed`: resolve root cause and reconcile external state before retry.
- `succeeded`: continue to validation; success does not complete separate workstreams.

A hard worker loss can leave a job marked running because 0.1.2 currently has no lease reaper. Never blindly restart an ambiguous external migration.

## 12. Retry failures

Use Retry Failed only after fixing the root cause and reconciling GitHub's external state. Completed repository entries are not reprocessed.

Common causes:

- PAT scope, SSO, or IP allow-list issue
- GHES/GHEC connectivity
- Destination conflict
- Archive/storage or release limit
- ELM source patch, visibility, or release-asset restriction
- Ruleset/policy rejection
- Rate limit or GitHub incident

Preserve original logs and migration identifiers.

## 13. Remediate pipelines and 1Password

ForgeBridge reports secret names/references, never values.

Recommended owner workflow:

1. Confirm secret owner, environment, rotation date, and least-privilege requirement.
2. Create approved 1Password items/vault structure.
3. Use narrowly scoped service accounts or Connect.
4. Protect the bootstrap 1Password credential separately.
5. Recreate target variables, environments, protection rules, runner groups, OIDC trust, and permissions.
6. Update workflows through a reviewed post-migration pull request.
7. Pin third-party actions according to supply-chain policy.
8. Run controlled pipeline validation.

## 14. Perform production cutover

### GEI

Because GEI has no delta synchronization:

1. Announce the maintenance window.
2. Stop writes, merges, issue/PR updates, and source automation.
3. Record final source SHA and owner approval.
4. Start the production run with official source lock enabled.
5. Validate the destination.
6. Complete access, identities, Actions, 1Password, runners, integrations, LFS, packages, Pages, rulesets, and security workstreams.
7. Change developer/automation remotes.
8. Obtain owner acceptance.

### ELM

1. Start the official initial live migration.
2. Monitor supported live updates and known unsupported update types.
3. Complete external remediation workstreams.
4. Schedule a short final cutover window.
5. Invoke explicit ELM cutover.
6. Validate final refs and metadata.
7. Confirm official source archival and destination ownership.

## 15. Validate and sign off

Run migration-linked or standalone validation. A failure blocks sign-off; every warning requires a named disposition.

Also validate externally:

- Teams, user access, and mannequin reclamation
- Actions secrets, variables, environments, runners, and OIDC
- Webhooks, Apps, deploy keys, and CI/CD integrations
- LFS objects and packages
- Pages/custom domains
- Branch protections, rulesets, and required status checks
- Advanced Security configuration and fresh scans
- Clone/fetch, build, deployment, performance, rollback, and monitoring

Download the evidence ZIP and obtain repository-owner and migration-authority approval.

## 16. Clean trial targets

1. Retain evidence.
2. Open Target purge or the trial run.
3. Run a purge dry run.
4. Confirm each organization/name mapping and captured repository ID.
5. Temporarily enable `ENABLE_DESTRUCTIVE_PURGE=true` under approved change control.
6. Enter the exact cleanup token and destructive confirmation.
7. Execute and inspect the job/audit result.
8. Return the flag to false.

Production runs are ineligible. Purge never receives the source connector.

## 17. Make sources read-only

The Source read-only page is an optional operational archive control, not a migration or delta method.

1. Complete migration and validation.
2. Run a dry run against selected source repositories.
3. Confirm completed-migration and passing-validation evidence.
4. Prefer official GEI `--lock-source-repo` for final GEI execution.
5. Use official ELM cutover for ELM; do not replace it with standalone archival.
6. Enable `ENABLE_SOURCE_FREEZE=true` only for an approved change window if separate archival is required.
7. Execute selected repositories and inspect job/audit evidence.
8. Return the flag to false.

ForgeBridge archives via GitHub's repository API and never deletes source repositories. Archival is reversible but remains a source-side change.

## 18. Operate Azure OpenAI safely

Azure OpenAI is optional and advisory.

1. Configure endpoint/deployment under **Configure → AI configuration**.
2. Prefer managed identity; use an API key only under approved secret-management controls.
3. Keep the use-case allowlist minimal.
4. Test connectivity as a background job.
5. Request interpretation only from a job detail page.
6. Treat the output as analyst guidance, not authoritative state.
7. Never use model output alone to approve retry, cutover, source archive, or target purge.

The model has no GitHub tool/function path and cannot mutate migration state. Disabling AI does not interrupt migration execution.

## 19. Back up and recover

Back up:

- PostgreSQL database
- Token-encryption key under enterprise key management
- JSONL job logs
- Evidence bundles
- Deployment configuration and image digest

Test restoration. Restoring the database without the matching encryption key makes stored credentials unreadable and requires credential rotation.

## 20. Build 004 dependency and TLS behavior

The production image does not invoke pip and does not contact PyPI. Python and application libraries are installed from Debian's signed repositories. The official standalone GEI binary is fetched from GitHub Releases and checksum-verified.

Normal system TLS verification remains enabled. No customer-supplied CA is required merely to install or operate ForgeBridge for a GHES-to-GHEC migration. Actual GHES, GHEC, Azure OpenAI, and 1Password endpoints must present a certificate chain trusted by the container's system trust store. Never disable TLS verification as a workaround.

When replacing Build 001, Build 002, or Build 003, extract Build 004 into its uniquely named directory and let the one installer import the previous protected configuration:

```bash
chmod +x forgebridge.sh
./forgebridge.sh install --import-env /absolute/path/to/previous/.env.production
```

Do not overwrite the old directory. Build 004 validates its complete release hash manifest and refuses an older Dockerfile before Docker is invoked.
