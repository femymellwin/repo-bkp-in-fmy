# ForgeBridge 0.1.2 security model and hardening checklist

Policy reference: **2026-07-14**

## Current controls

- Argon2 password hashing.
- Signed session cookies with configurable `Secure` behavior; the generated loopback configuration uses `false`, and approved HTTPS ingress must set `SESSION_COOKIE_SECURE=true`.
- CSRF validation on state-changing form actions.
- Admin/user role enforcement.
- Workspace ownership enforcement on every workspace route.
- Fernet encryption of connector tokens at rest.
- PAT masking and no plaintext token display.
- Tokens passed to GEI through environment variables rather than command arguments.
- Central persistence redaction for credential-shaped structured fields and free-form job/CLI error text while preserving safe metadata names.
- Input validation for organization/repository names.
- Source/destination connector-type validation.
- Source-safe purge guards.
- Guarded source read-only with dry-run, explicit feature flag, migration/validation evidence, batch preflight, and immediate per-repository source/target identity and SHA rechecks.
- Security response headers and production HSTS.
- Production startup rejects demo mode, SQLite, weak/default keys, automatic schema creation, and local task mode.
- Audit trail for security- and migration-relevant operations.
- Azure OpenAI endpoint validation, managed-identity option, encrypted API-key option, bounded/redacted evidence, redirect refusal, use-case allowlist, and no tool execution.
- Download path containment checks for job logs.

## Production gaps that must be closed

### Identity

Replace local credentials with enterprise OIDC/SAML SSO, MFA policy, centralized deprovisioning, and group-to-role mapping. Add session revocation, account disable/reactivate UI, login throttling, and privileged-action step-up authentication.

### Authorization

The current model has workspace owner plus global admin. A production program will usually need explicit workspace roles such as owner, planner, operator, validator, auditor, and cleanup approver, with separation of duties.

### Secret management

The application-wide Fernet key is adequate for a reference build, not a complete enterprise key-management design. Use a managed KMS/HSM or approved secret manager, rotate keys, version ciphertext, restrict decrypt capability to workers that need it, and prevent secrets from reaching crash dumps or APM payloads.

Use short-lived migration credentials where GitHub supports them. Time-bound PATs, restrict scopes, authorize only required organizations, and revoke after each wave.

### Network

- TLS termination at approved ingress.
- Private or restricted connectivity to GHES, GHEC, PostgreSQL, Redis, and 1Password.
- Egress allowlist.
- No direct database or Redis exposure.
- TLS for PostgreSQL/Redis where required.
- Keep connector TLS verification enabled.
- Protect GHES administrative-shell SSH key and restrict source IPs.

### Application security

- Independent security review and penetration test.
- Dependency lockfile/SBOM/signing and automated CVE scans.
- Static analysis, secret scanning, container scanning, and IaC scanning.
- Rate limits and brute-force protection.
- Stronger CSP with nonces if inline content is later introduced.
- Secure file-report retention and access logging.
- Data classification and retention policy for user emails, commit metadata, and integration URLs.

### Audit and evidence

Move or stream audit events to a tamper-evident SIEM. Include deployment version, image digest, operator identity, approval/change ticket, and official GitHub migration IDs. Define retention and legal-hold requirements.

### Background jobs

Use durable Celery configuration, dead-letter handling, worker heartbeats, lease expiry/reconciliation, bounded retry, and idempotency keys. Monitor queue age, failure rate, and worker health.

### Azure OpenAI

Keep AI optional and read-only. Prefer managed identity, private networking, least-privilege Azure RBAC, deployment allowlisting, and strict outbound controls. Treat all model output as untrusted advisory text. Add formal DLP/redaction, prompt-injection regression tests, model/deployment change control, token/cost monitoring, and retention review before production. Never introduce a function-call route that can migrate, retry, freeze, cut over, or purge without an independent deterministic authorization service and explicit human approval.

## Threat scenarios

| Threat | Current mitigation | Required production addition |
|---|---|---|
| PAT theft from database | Fernet encryption | KMS envelope encryption, decrypt-service isolation, rotation, DB access monitoring |
| Cross-workspace access | Route-level ownership checks | Automated authorization tests and finer workspace roles |
| CSRF/destructive action | CSRF plus cleanup token and feature flag | Step-up approval/two-person control |
| Accidental source deletion | No source delete implementation; source archive is separately guarded | Keep invariant under code review, policy tests, and two-person source-change approval |
| Deleting wrong target during purge | Trial-only, destination ID match, cleanup token | Two-person approval, target backup/retention, deletion log export |
| Duplicate migration after queue redelivery | Atomic claim | External migration reconciliation and job leases |
| Malicious workflow/job content | Scanner is read-only; AI has no tools and bounded/redacted input | Sandbox parsers, formal DLP, prompt-injection tests, input-size limits, malware/content policy |
| Token exposure in logs | Structured/job/CLI/AI persistence redaction with regression tests | APM filtering, centralized log-pipeline DLP, and independent security review |
| Compromised admin | Role checks | SSO MFA, PAM, step-up auth, audit alerts, separation of duties |
| Supply-chain compromise | Version constraints | Hash-locked dependencies, signed images, SBOM, provenance |

## 1Password design note

ForgeBridge does not use 1Password as a covert substitute for GitHub migration. It creates a remediation plan because GitHub secret values cannot be retrieved. Repository owners must populate the approved vault and update workflows through governed code review.

The initial credential used by `1password/load-secrets-action` or Connect is itself a secret and must have narrowly scoped vault access. Prefer service accounts/Connect and environment-specific vault separation.

## Runtime dependency and TLS policy

Build `FB-0.1.2-004` removes production pip/PyPI access and installs Python modules through Debian's signed repositories. GitHub's standalone GEI executable is pinned and SHA-256 verified before installation.

The normal system public trust store remains active. A custom CA is not a generic GitHub migration prerequisite and is not part of normal ForgeBridge startup. Endpoints must present a trusted certificate chain. Do not use `--trusted-host`, `curl -k`, `GIT_SSL_NO_VERIFY`, connector `verify_ssl=false`, or equivalent bypasses in production.

For stronger supply-chain assurance, production operators should mirror approved Debian packages and the verified GEI asset into an internal artifact repository, produce an SBOM, sign the resulting image, and enforce image-digest deployment.
