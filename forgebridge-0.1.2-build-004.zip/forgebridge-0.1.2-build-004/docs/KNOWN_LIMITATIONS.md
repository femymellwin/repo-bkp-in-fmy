# Known limitations

Version: **0.1.2**  
Policy reference: **2026-07-14**

1. **GEI has no supported delta migration.** Repeated imports are not represented as incremental synchronization. Production GEI requires official source locking and a maintenance window.
2. **ELM is restricted to eligible GHES-to-GHE.com data-residency migrations and remains a GitHub public-preview dependency.** Current enablement, patch floors, limits, and behavior must be rechecked.
3. **One repository migration cannot move every organization, identity, Actions, security, package, or integration object.** Separate workstreams and sign-off are required.
4. **GitHub secret values cannot be exported.** ForgeBridge stores names/references and proposed 1Password mappings only.
5. **GEI does not migrate LFS objects.** Detection is heuristic and object transfer/validation is external.
6. **Repository creator identity is not reliably exposed.** Owner and available contributor/commit identities are captured instead.
7. **Private user emails may be hidden.** ForgeBridge stores only values returned by GitHub.
8. **Readiness grades are deterministic screening aids, not GitHub certification.** A high grade cannot guarantee migration success.
9. **Raw repository/release/blob sizes are not official compressed migration archive sizes.** Large-object screening cannot prove GEI eligibility.
10. **The optional Git mirror scan can be expensive.** It is disabled by default, requires temporary local storage, and is discovery-only.
11. **Static pipeline analysis is heuristic.** Dynamic expressions, reusable workflows, generated files, custom actions, external scripts, and encrypted/config files need manual review.
12. **1Password conversion is not automatic.** Vault population and workflow updates remain owner-controlled post-migration changes.
13. **Local password authentication is not enterprise production identity.** SSO/OIDC, MFA, provisioning, deprovisioning, login controls, and privileged step-up are required.
14. **Authorization is global admin or workspace owner.** Planner/operator/validator/auditor/approver separation is not implemented.
15. **Menu enablement is cosmetic navigation control.** It does not replace authorization.
16. **No worker lease/heartbeat reaper exists.** A killed worker can leave a job running; official GitHub state must be reconciled before retry.
17. **No built-in Prometheus, alerting, email, Teams, Slack, PagerDuty, or SIEM export exists.** Production integrations are required.
18. **Azure OpenAI interpretation is advisory and probabilistic.** It may be wrong and cannot authorize, grade, or execute work. The current implementation supports sanitized job interpretation only.
19. **The AI redaction pattern is defensive but not a formal DLP system.** Do not place secrets in logs or evidence.
20. **Destination organization creation is out of scope.** Organizations must exist before planning.
21. **Teams, memberships, access assignments, runners, webhooks, Apps, deploy keys, environments, OIDC, Pages DNS, packages, and security configuration are not automatically recreated.** Evidence is collected where possible.
22. **Standalone source read-only performs a real archive operation when enabled.** It is dry-run by default and guarded, but requires enterprise change control and is not a migration method.
23. **Purge is deliberately narrow.** It deletes only verified trial targets created by a ForgeBridge run; it is not a general cleanup utility.
24. **External CLI compatibility can change.** Rebuild, upgrade, and regression-test GEI/ELM tooling before production waves.
25. **The build has not been exercised against the user's real GHES/GHEC tenants.** No real migration or production certification is claimed.
26. **The embedded GitHub policy is dated.** Refresh it under change control whenever official guidance changes.
