# Reference application comparison

Reviewed package: **Syncline v7.11.25 GitHub repository/GEI build**  
ForgeBridge target: **0.1.2**

This document records which product patterns were adopted from the supplied application and which technical behaviors were deliberately not carried into ForgeBridge.

## Adopted product patterns

| Reference pattern | ForgeBridge 0.1.2 implementation |
|---|---|
| One repository discovery workflow feeding two operational lanes | Repository discovery plus With pipelines and Without pipelines pages backed by one inventory. |
| Dedicated repository validation, target purge, and source read-only pages | Separate GitHub menu entries and persistent background runs for all three. |
| Rich repository tables | Search, grade, pipeline, blocker, visibility, activity, risk filters; select visible; detailed repository page. |
| Checks and grades | Deterministic method-specific blockers, warnings, score, and A–F grade. |
| Saved scopes | Named workspace repository selections. |
| Inline/current job visibility and Jobs menu | Persistent Jobs ledger, job detail, live polling, result/error/log evidence. |
| Owner-oriented pipeline validation | Secret/variable references, environments, URLs, runners, dependencies, permissions, file evidence, risk, and owner exports. |
| No product markers in migrated repositories | ForgeBridge creates no tag, topic, README marker, hidden file/folder, branch marker, commit, issue, or pull request. |
| Repeatable target cleanup | Trial-only purge using internal run token plus captured destination repository ID; no source access. |
| Source freeze/read-only workflow | Guarded dry-run/archive workflow with evidence checks; no source deletion. |
| Configuration administration | Connectors, workspaces, branding, users, menu enablement, global audit, and AI configuration. |
| Help content | Help index and dedicated GHES-to-GHEC migration guide. |
| Compact grouped menu shell | Reference-style top navigation with Overview, GitHub, Operations, Configure, Help, workspace context, user menu, and responsive mobile behavior. |
| Visual identity and palette | Supplied dark-slate/blue/light-surface palette, local logo assets, light/dark rendering, and consistent form/table/card styling. |
| Browser-tab identity | Branding-backed favicon plus product/version/build title so operators can identify the application without opening the tab. |
| Editable release identity | Configure → Branding controls product name, company, tagline, version, build number, edition, support contact, logo/favicon, and theme colors. |
| Managed production entry point | One `forgebridge.sh` command surface for initialization, start, stop, restart, status, health, logs, backup, upgrade, and diagnostics on port 3002. |
| Runtime ledger/evidence | Persistent discovery, migration, validation, purge, freeze, job, and audit records plus downloadable reports. |

## Reimplemented for ForgeBridge's product boundary

The supplied application is a broad enterprise migration hub. ForgeBridge 0.1.2 intentionally narrows the architecture to one source/destination product pair:

```text
GitHub Enterprise Server -> GitHub Enterprise Cloud
```

The UI and workflow ideas were translated into FastAPI, SQLAlchemy, Alembic, Celery/Redis, Jinja, and a workspace-scoped domain model. They were not copied as a generic multi-platform migration engine.

## Deliberately not adopted

| Reference behavior | ForgeBridge decision | Reason |
|---|---|---|
| Custom mirror migration engine | Not a migration method | ForgeBridge invokes official GitHub GEI or eligible ELM only. Optional mirror clone is read-only large-object discovery. |
| Custom delta synchronization for standard GHEC | Rejected | GEI does not support delta. ForgeBridge does not label a custom Git copy as enterprise metadata synchronization. |
| Multiple source/destination platforms in one product | Excluded | User requested a dedicated product per source/destination pair. |
| Broad target cleanup across arbitrary artifact types | Excluded | ForgeBridge purge is limited to verified trial repositories created by one recorded migration run. |
| Repository-content markers for cleanup/traceability | Excluded | Ledger-only identity avoids extra refs, files, issues, or pull requests. |
| Automatic workflow mutation | Excluded | It would break apple-to-apple content validation. 1Password changes belong in reviewed post-migration PRs. |
| AI-controlled execution | Excluded | Azure OpenAI is advisory only and has no GitHub tools or mutation path. |

## Additional ForgeBridge safeguards

ForgeBridge adds controls required by its official-method model:

- Method policy dated and visible in evidence.
- Current embedded ELM patch-floor gate and fail-closed future trains.
- Server-side repository re-evaluation at plan creation.
- GEI production source-lock requirement.
- ELM destination/HTTPS/visibility/release-asset/concurrency checks.
- PATs passed through environment variables, not command arguments.
- Atomic job and per-repository claims.
- Destination repository-ID verification before purge.
- Completed migration and validation evidence before real standalone source archival.
- Azure OpenAI use-case allowlist, guardrail, sanitization, redirect refusal, bounded input, and no tool execution.
- Upgrade path from the 0.1.0 database schema.

## Remaining production work

The reference application review improved the product surface but does not remove enterprise-hardening requirements. ForgeBridge still needs customer-specific SSO, fine-grained roles, durable worker reconciliation, central monitoring/alerts, KMS-backed secret handling, SIEM, security testing, and real GHES/GHEC pilots before production approval.
