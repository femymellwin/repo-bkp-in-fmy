# ForgeBridge 0.1.2 Build 004 manifest

Version: **0.1.2**  
Build: **FB-0.1.2-004**  
Port: **3002**  
Policy reference date: **2026-07-14**

## Operator entrypoint

```text
forgebridge.sh
```

This is the only `.sh` file in the application package. It provides installation, startup, shutdown, status, health, tooling verification, logs, backup, upgrade, diagnostics, version output, and runtime removal.

## Core runtime files

```text
BUILD-INFO.env
RELEASE-SHA256SUMS
Dockerfile
docker-compose.yml
forgebridge.sh
.env.example
runtime-packages.txt
```

## Application areas

```text
app/                    FastAPI application, templates, static assets, services
alembic/                Database migrations
scripts/*.py            Internal Python seed/verification helpers
docs/                   Product, operations, method, security, and test guidance
vendor/gei/GEI.lock     Official GEI release identity and published checksums
tests/                  Automated regression tests
```

## Production services

```text
postgres     PostgreSQL 16
redis        Redis 7
migrate      Alembic one-shot task
seed         Idempotent seed one-shot task
web          FastAPI/Uvicorn on container port 3002
worker       Celery background workers
```

## Packaged identity

```text
Application image: forgebridge/app:0.1.2-004
GEI:              official standalone v1.30.3
Migration policy: github-supported-only
Default bind:      127.0.0.1:3002
```

## Build 004 changes

- Replaces the previous operator script with one installer/manager, `forgebridge.sh`.
- Adds `install` and environment-import workflows.
- Uses a uniquely named extraction directory to prevent execution from an old build folder.
- Adds full packaged-file SHA-256 verification.
- Forces a no-cache application build during installation.
- Verifies the built OCI image revision label before startup.
- Removes production `requirements.txt` and all auxiliary shell scripts.
- Removes GitHub CLI extension fallback from the migration runtime.
- Enforces `MIGRATION_POLICY_MODE=github-supported-only`.
- Keeps ELM disabled by default and eligible only for GHE.com when explicitly approved.
- Preserves port 3002, branding, favicon, menus, discovery, grading, pipeline lanes, jobs, validation, purge, read-only, reports, users, audit, and AI configuration.

Build 004 changes runtime packaging and control enforcement. It does not add a database schema revision.
