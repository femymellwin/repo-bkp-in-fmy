# Build 004 runtime packaging

## Objective

Build `FB-0.1.2-004` removes the production PyPI dependency and exposes exactly one shell entrypoint: `forgebridge.sh`.

## Python runtime

The Docker image is based on `debian:trixie-slim`. Runtime Python components are installed from Debian's signed repositories using `apt`. The Dockerfile:

- does not contain `pip install`;
- does not run `python -m pip`;
- does not contact `pypi.org`;
- does not copy a production `requirements.txt`;
- verifies required imports during the image build;
- supports Docker's native `linux/amd64` and `linux/arm64` package architectures.

The package intentionally contains no production `requirements.txt` file.

## GitHub Enterprise Importer

GitHub's official standalone GEI executable is pinned to v1.30.3. The Dockerfile selects:

```text
linux/amd64 -> gei-linux-amd64
linux/arm64 -> gei-linux-arm64
```

It verifies the official published SHA-256 values before installation:

```text
gei-linux-amd64
18980c737704c49ce57455f0792ef3a5ae01b3bfeed9eaa19a41d26f7e971735

gei-linux-arm64
5a7ae4257fcf38297e3089ec3a1a4dc409b72a8dc984e860f0fb6c066d338d76
```

The image then executes:

```text
gei --version
gei migrate-repo --help
```

The application refuses `gh gei` extension mode, floating extension installation, `ghe-migrator`, and Git mirror push as migration engines.

## Network behavior during installation

The image build still needs normal outbound HTTPS access to:

- Docker image registries;
- Debian package repositories;
- GitHub's official GEI release asset.

It does not need PyPI. A customer-supplied CA is not a normal installation requirement. Standard operating-system and Docker HTTPS trust stores remain active.

A GHES connector may require organization-specific TLS handling only when that GHES endpoint itself uses a private or invalid certificate. This is separate from ForgeBridge application installation.

## Release integrity

`RELEASE-SHA256SUMS` covers every packaged source file except the manifest itself. Before installation, `forgebridge.sh` verifies:

- the complete hash manifest;
- `BUILD-INFO.env`;
- the Dockerfile base and port;
- the Build 004 image tag;
- the GEI version pin;
- absence of pip/PyPI production instructions;
- absence of unsupported migration-engine commands;
- presence of exactly one shell entrypoint.

The install command always performs a no-cache application image build. This prevents an old Dockerfile layer from being mistaken for Build 004.
