# Discovery data dictionary

ForgeBridge stores the most complete practical inventory available through the configured GitHub APIs and token permissions. A zero count can mean “none” or “not visible”; deep discovery logs and permission review must be used to distinguish them.

## Organization snapshot

- Organization login, name, type, and API payload.
- Teams: ID, slug, name, privacy, default permission.
- Members and outside collaborators: ID, login, type.
- Organization webhooks: ID, type, active state, events, endpoint URL.
- Organization rulesets: ID, name, target, enforcement.
- Organization Actions secret names and variable names.
- Aggregate counts and discovery-completeness note.

Secret values are never captured.

## Repository identity and lifecycle

- GitHub numeric ID and node ID.
- Source organization, name, full name, proposed target name.
- Owner login/type.
- Description, homepage, primary language, license, topics.
- Visibility, default branch, archive/disabled/fork state.
- GitHub repository size in KiB.
- Source created, updated, and pushed timestamps.
- Discovery timestamp and point-in-time snapshot payload.

## Latest commit and activity

- Latest commit SHA and timestamp.
- Author name/email/login when available.
- Committer name/email/login when available.
- Inactive day count.

GitHub privacy settings can hide emails. Repository creator is not asserted unless a reliable source is later added.

## Git and repository metadata

- Branch count and protected-branch count.
- Branch names, protected flags, and head SHAs in detail payload.
- Tag count.
- Open issue count separated from open PRs where possible.
- Total pull-request count.
- Release count.
- Fork, star, and watcher counts.
- LFS heuristic from `.gitattributes`.

## Releases and assets

- Release ID and tag.
- Asset ID, name, size, and download count.
- Total asset bytes.
- Largest asset bytes.
- Count of assets over the ELM 2 GiB limit.

## Access and integrations

- Collaborator IDs, logins, type, role, and permission map.
- Contributor IDs/logins and contribution count.
- Repository webhooks: endpoint URL, events, active state.
- Deploy keys: ID, title, read-only state, verified state.
- GitHub Actions repository permission payload.


## Target probe and readiness evidence

- Target organization checked and destination existence state.
- Destination repository ID, visibility, default branch, and latest target SHA when visible.
- Target API evidence payload and access/permission ambiguity.
- Selected migration method and target flavor context.
- Deterministic readiness score, A–F grade, and status (`ready`, `needs_review`, or `blocked`).
- Blocker and warning counts, codes, human-readable reasons, and remediation guidance.
- Empty-repository, open-PR, external-pipeline, self-hosted-runner, large-file, release-asset, and LFS indicators.
- Optional largest Git blob evidence from the read-only discovery mirror.

Readiness is recalculated server-side when a migration plan is created; table filters and saved scopes are operator conveniences, not safety authorization.

## Actions/pipeline report

- Workflow file path and per-workflow risk score.
- Secret names/references.
- Variable names/references.
- Environment names and available protection/branch policy data.
- External URLs.
- Actions used through `uses:`.
- Runner labels, including self-hosted composite lists.
- Workflow/job permissions.
- Potential hard-coded credential findings with file/line/key/reason.
- Proposed 1Password reference per secret name.
- Aggregate risk score.


## Pipeline owner handoff evidence

- Repository and proposed destination mapping.
- Last available commit author/committer name and email evidence.
- Contributor/collaborator evidence returned by GitHub.
- Workflow paths, secret/variable names, environments, external URLs, runners, action dependencies, permissions, OIDC indicators, and security findings.
- Proposed 1Password `op://` reference and repository-owner remediation checklist.
- Markdown, JSON, and CSV exports.

Commit metadata is not treated as proof of current business ownership, and secret values are never included.

## Migration evidence

- Source/destination organization and repository mapping.
- Migration method/mode/pipeline policy.
- Internal run and cleanup IDs.
- Official external migration ID when available.
- Attempt count and timestamps.
- Source SHA at plan start and target SHA after migration.
- Captured destination repository ID.
- Status, warnings, error, command preview, and result payload.
- Per-check validation evidence.

## Validation and operational evidence

- Validation run scope, linked migration run when applicable, source/target connectors and organizations, lane, score, grade, and check totals.
- Per-repository ref, default-head, workflow-path/hash, setting, issue/PR, release, and expected-difference checks.
- Target-purge dry-run/execution scope, cleanup token association, captured target ID checks, and per-repository result.
- Source-read-only dry-run/execution scope, evidence gate, archived/skipped/failed counts, and explicit source-modified flag.
- Background job state, progress, step, result, bounded error, timestamps, and JSONL log path.
- Audit actor, workspace, action, resource, source IP, timestamp, and structured details.
- Azure OpenAI configuration/test metadata and advisory interpretations; no AI decision changes migration, validation, purge, freeze, or cutover state.

## Branding and release identity

- Product name and tagline.
- Company/owner display name.
- Product version and operator-managed build number.
- Edition label and support email.
- Packaged, uploaded, or approved HTTPS logo source.
- Browser favicon resolved from the active branding record.
- Configurable primary, accent, surface, gradient, border, button, and text colors.
- Branding update/reset actor and audit event.

Uploaded branding assets are stored in the persistent application data volume rather than committed to repositories or inserted into migrated GitHub content.
