# ForgeBridge 0.1.2 - Build FB-0.1.2-004

**Controlled, auditable GHES-to-GHEC migrations.**

ForgeBridge is a focused migration control plane for GitHub Enterprise Server to GitHub Enterprise Cloud. Build 004 provides one operator-facing script, runs on port **3002**, verifies the release before installation, and removes the production `pip`/PyPI dependency that caused the earlier Docker build failure.

## Release identity

| Item | Value |
|---|---|
| Product | ForgeBridge |
| Company | Inception UAE |
| Version | 0.1.2 |
| Build | FB-0.1.2-004 |
| Port | 3002 |
| Primary method | GitHub Enterprise Importer |
| GEI package | Official standalone v1.30.3 |
| Runtime | Docker Compose, PostgreSQL, Redis, FastAPI, Celery |
| User-facing shell scripts | One: `forgebridge.sh` |

## Recommended single-file installer

The release is also distributed as one self-extracting installer file. Docker Desktop must be installed and running.

```bash
chmod +x forgebridge-0.1.2-build-004-installer.sh
./forgebridge-0.1.2-build-004-installer.sh
```

The installer extracts the verified application into `./forgebridge-0.1.2-build-004` and then runs its sole operator entrypoint, `./forgebridge.sh install`. To import a previous protected configuration during extraction:

```bash
./forgebridge-0.1.2-build-004-installer.sh \
  --target-dir /Users/femy.pancy/sites/ForgeBridge/v3 \
  --import-env /Users/femy.pancy/sites/ForgeBridge/v3/forgebridge-0.1.2/.env.production
```

## ZIP installation commands

Docker Desktop must be installed and running.

```bash
cd ~/Downloads
unzip forgebridge-0.1.2-build-004.zip
cd forgebridge-0.1.2-build-004
chmod +x forgebridge.sh
./forgebridge.sh install
```

Open:

```text
http://127.0.0.1:3002
```

On first installation, `forgebridge.sh` creates `.env.production` with restricted file permissions, random application secrets, a random PostgreSQL password, and an initial administrator password. The password is displayed after a successful first installation.

## Upgrade while preserving the previous configuration

Use the Build 004 folder; do not overwrite or run the earlier folder.

```bash
cd ~/Downloads
unzip forgebridge-0.1.2-build-004.zip
cd forgebridge-0.1.2-build-004
chmod +x forgebridge.sh
./forgebridge.sh install --import-env /Users/femy.pancy/sites/ForgeBridge/v3/forgebridge-0.1.2/.env.production
```

The same Docker project name is retained, so existing named PostgreSQL, Redis, and application-data volumes are reused. Packaged build identities `FB-0.1.2-001`, `FB-0.1.2-002`, and `FB-0.1.2-003` advance to Build 004. An administrator-defined custom build number is preserved.

## One management script

All installation and operational commands use the same file:

```bash
./forgebridge.sh init
./forgebridge.sh install
./forgebridge.sh build
./forgebridge.sh clean-build
./forgebridge.sh start
./forgebridge.sh stop
./forgebridge.sh restart
./forgebridge.sh status
./forgebridge.sh health
./forgebridge.sh tooling
./forgebridge.sh logs
./forgebridge.sh logs worker
./forgebridge.sh backup
./forgebridge.sh upgrade
./forgebridge.sh uninstall
./forgebridge.sh doctor
./forgebridge.sh version
./forgebridge.sh help
```

`uninstall` removes containers and the Build 004 application image but preserves named data volumes and `.env.production`.

## Why the earlier error cannot occur through this build path

The failed build used an older Dockerfile containing:

```text
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Build 004:

- uses `debian:trixie-slim`;
- installs Python runtime components from Debian's signed repositories;
- contains no production `requirements.txt`;
- never invokes `pip` in the Dockerfile;
- never contacts PyPI;
- performs a clean, no-cache image build during `install`;
- verifies every packaged source file against `RELEASE-SHA256SUMS`;
- checks the image label for `FB-0.1.2-004` before startup;
- refuses to run when an older or modified Dockerfile is detected.

A customer-supplied CA certificate is not part of normal installation. Standard HTTPS certificate validation remains enabled.

## GitHub-supported migration policy

ForgeBridge does not implement a custom repository-copy engine.

Allowed production methods are:

1. **GitHub Enterprise Importer (GEI)** for standard GHES-to-GHEC repository migrations. ForgeBridge invokes GitHub's official standalone `gei migrate-repo` executable.
2. **Enterprise Live Migrations (ELM)** only when explicitly enabled for an eligible GitHub Enterprise Cloud with data residency destination on `GHE.com`. ELM remains a GitHub public-preview capability.

Not implemented as migration methods:

- `git push --mirror`;
- a custom metadata copier;
- `ghe-migrator` for a GHEC destination;
- an unofficial GEI delta synchronizer;
- overwriting an occupied destination repository.

GEI does not support delta synchronization. A production GEI migration therefore requires an approved maintenance window and the official source-lock option. ELM is the only supported live-update path represented by ForgeBridge, and only for eligible `GHE.com` destinations.

## Safety defaults

The generated configuration starts with these disabled:

```text
ENABLE_REAL_MIGRATIONS=false
ENABLE_ELM=false
ENABLE_DESTRUCTIVE_PURGE=false
ENABLE_SOURCE_FREEZE=false
```

Discovery, planning, grading, filtering, reports, and validation can be prepared before mutation controls are approved. Do not enable production migration, target purge, or source read-only functions until connector tests, trial migrations, validation, access review, backup, rollback, and change approval are complete.

## Included application areas

### GitHub

- Repository discovery
- Repository checks, filters, risk scores, and grades
- Repositories with pipelines
- Pipeline-owner handoff
- Repositories without pipelines
- Migration runs and retry-failed workflow
- Repository validation
- Target purge for guarded trial cleanup
- Source read-only controls

### Operations

- Persistent background jobs
- Progress and structured logs
- Reports and evidence bundles

### Configure

- GHES, GHEC, and 1Password connectors
- Workspaces
- Branding, logo, favicon, version, and build number
- Users and roles
- Menu enablement
- Audit-log activity
- Azure OpenAI configuration for read-only operational explanation

### Help

- Help index
- GitHub Enterprise migration guide

## Production notes

The default bind address is loopback-only:

```text
127.0.0.1:3002
```

Before network exposure, place ForgeBridge behind an approved HTTPS reverse proxy and configure secure cookies and trusted proxy addresses.

The build is a tested reference implementation, not a certification of a customer migration. Real GHES/GHEC pilots, GitHub Support engagement for exceptional repositories, enterprise SSO, centralized secrets, monitoring, backup/restore testing, and security assessment remain required before production migration waves.
