"""ForgeBridge 0.1.1 enhanced GitHub migration control plane.

Revision ID: fb011enhanced
Revises: d5b3d22c2592
Create Date: 2026-07-12
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "fb011enhanced"
down_revision: Union[str, Sequence[str], None] = "d5b3d22c2592"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

migration_lane = sa.Enum(
    "all", "with_pipelines", "without_pipelines",
    name="migrationlane", native_enum=False,
)
job_status = sa.Enum(
    "queued", "running", "succeeded", "failed", "cancelled",
    name="jobstatus", native_enum=False,
)


def upgrade() -> None:
    op.create_table(
        "menu_settings",
        sa.Column("key", sa.String(length=120), primary_key=True),
        sa.Column("group_name", sa.String(length=80), nullable=False),
        sa.Column("label", sa.String(length=160), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("admin_only", sa.Boolean(), nullable=False),
        sa.Column("sort_order", sa.Integer(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_menu_settings_group_name", "menu_settings", ["group_name"], unique=False)

    op.create_table(
        "ai_configuration",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("provider", sa.String(length=80), nullable=False),
        sa.Column("endpoint", sa.String(length=1024), nullable=True),
        sa.Column("deployment", sa.String(length=255), nullable=True),
        sa.Column("model", sa.String(length=255), nullable=True),
        sa.Column("api_style", sa.String(length=40), nullable=False),
        sa.Column("api_version", sa.String(length=80), nullable=False),
        sa.Column("auth_mode", sa.String(length=40), nullable=False),
        sa.Column("encrypted_api_key", sa.Text(), nullable=True),
        sa.Column("api_key_last4", sa.String(length=8), nullable=True),
        sa.Column("temperature", sa.Float(), nullable=False),
        sa.Column("max_output_tokens", sa.Integer(), nullable=False),
        sa.Column("max_input_chars", sa.Integer(), nullable=False),
        sa.Column("system_prompt", sa.Text(), nullable=False),
        sa.Column("allowed_use_cases_json", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=40), nullable=False),
        sa.Column("status_message", sa.Text(), nullable=True),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
        sa.Column("last_tested_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_by_id", sa.String(length=64), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["updated_by_id"], ["users.id"]),
    )

    op.create_table(
        "saved_repository_scopes",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("created_by_id", sa.String(length=64), nullable=False),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("lane", sa.String(length=40), nullable=False),
        sa.Column("filters_json", sa.JSON(), nullable=False),
        sa.Column("repository_ids_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["created_by_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["workspace_id"], ["workspaces.id"], ondelete="CASCADE"),
        sa.UniqueConstraint("workspace_id", "name", name="uq_scope_workspace_name"),
    )
    op.create_index("ix_saved_repository_scopes_created_by_id", "saved_repository_scopes", ["created_by_id"], unique=False)
    op.create_index("ix_saved_repository_scopes_workspace_id", "saved_repository_scopes", ["workspace_id"], unique=False)

    op.create_table(
        "source_freeze_runs",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("source_connector_id", sa.String(length=64), nullable=False),
        sa.Column("created_by_id", sa.String(length=64), nullable=False),
        sa.Column("source_org", sa.String(length=255), nullable=False),
        sa.Column("status", job_status, nullable=False),
        sa.Column("dry_run", sa.Boolean(), nullable=False),
        sa.Column("scope_json", sa.JSON(), nullable=False),
        sa.Column("archived_count", sa.Integer(), nullable=False),
        sa.Column("skipped_count", sa.Integer(), nullable=False),
        sa.Column("failed_count", sa.Integer(), nullable=False),
        sa.Column("result_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["created_by_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["source_connector_id"], ["connectors.id"]),
        sa.ForeignKeyConstraint(["workspace_id"], ["workspaces.id"], ondelete="CASCADE"),
    )
    op.create_index("ix_source_freeze_runs_source_connector_id", "source_freeze_runs", ["source_connector_id"], unique=False)
    op.create_index("ix_source_freeze_runs_source_org", "source_freeze_runs", ["source_org"], unique=False)
    op.create_index("ix_source_freeze_runs_workspace_id", "source_freeze_runs", ["workspace_id"], unique=False)

    with op.batch_alter_table("workspaces") as batch:
        batch.add_column(sa.Column("default_source_connector_id", sa.String(length=64), nullable=True))
        batch.add_column(sa.Column("default_target_connector_id", sa.String(length=64), nullable=True))
        batch.add_column(sa.Column("source_org", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("target_org", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("settings_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))
        batch.add_column(sa.Column("migration_profile_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))

    with op.batch_alter_table("discovery_runs") as batch:
        batch.add_column(sa.Column("target_connector_id", sa.String(length=64), nullable=True))
        batch.add_column(sa.Column("target_org", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("assess_target", sa.Boolean(), nullable=False, server_default=sa.false()))
        batch.add_column(sa.Column("options_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))
        batch.create_index("ix_discovery_runs_target_connector_id", ["target_connector_id"], unique=False)

    with op.batch_alter_table("migration_runs") as batch:
        batch.add_column(sa.Column("acknowledged_manual_actions", sa.Boolean(), nullable=False, server_default=sa.false()))
        batch.add_column(sa.Column("lane", migration_lane, nullable=False, server_default="all"))
        batch.add_column(sa.Column("selection_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))
        batch.add_column(sa.Column("preflight_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))
        batch.create_index("ix_migration_runs_lane", ["lane"], unique=False)

    with op.batch_alter_table("purge_runs") as batch:
        batch.add_column(sa.Column("scope_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))

    with op.batch_alter_table("repository_inventory") as batch:
        batch.add_column(sa.Column("empty_repository", sa.Boolean(), nullable=False, server_default=sa.false()))
        batch.add_column(sa.Column("open_pull_requests_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("pipeline_lane", sa.String(length=40), nullable=False, server_default="without_pipelines"))
        batch.add_column(sa.Column("external_pipeline_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("self_hosted_runner_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("large_file_blocker_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("large_file_warning_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("largest_blob_bytes", sa.BigInteger(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("target_org_checked", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("target_exists", sa.Boolean(), nullable=False, server_default=sa.false()))
        batch.add_column(sa.Column("target_repository_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("target_visibility", sa.String(length=40), nullable=True))
        batch.add_column(sa.Column("target_default_branch", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("target_last_commit_sha", sa.String(length=128), nullable=True))
        batch.add_column(sa.Column("target_state_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))
        batch.add_column(sa.Column("readiness_score", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("readiness_grade", sa.String(length=4), nullable=False, server_default="N/A"))
        batch.add_column(sa.Column("readiness_status", sa.String(length=40), nullable=False, server_default="not_assessed"))
        batch.add_column(sa.Column("blocker_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("warning_count", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("blockers_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'")))
        batch.add_column(sa.Column("warnings_json", sa.JSON(), nullable=False, server_default=sa.text("'[]'")))
        batch.add_column(sa.Column("readiness_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))
        batch.create_index("ix_repository_inventory_pipeline_lane", ["pipeline_lane"], unique=False)
        batch.create_index("ix_repository_inventory_readiness_grade", ["readiness_grade"], unique=False)
        batch.create_index("ix_repository_inventory_readiness_score", ["readiness_score"], unique=False)
        batch.create_index("ix_repository_inventory_readiness_status", ["readiness_status"], unique=False)

    with op.batch_alter_table("validation_runs") as batch:
        batch.alter_column("migration_run_id", existing_type=sa.String(length=64), nullable=True)
        batch.add_column(sa.Column("source_connector_id", sa.String(length=64), nullable=True))
        batch.add_column(sa.Column("target_connector_id", sa.String(length=64), nullable=True))
        batch.add_column(sa.Column("source_org", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("target_org", sa.String(length=255), nullable=True))
        batch.add_column(sa.Column("lane", migration_lane, nullable=False, server_default="all"))
        batch.add_column(sa.Column("scope_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")))
        batch.add_column(sa.Column("score", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("grade", sa.String(length=4), nullable=False, server_default="N/A"))
        batch.create_foreign_key("fk_validation_source_connector", "connectors", ["source_connector_id"], ["id"])
        batch.create_foreign_key("fk_validation_target_connector", "connectors", ["target_connector_id"], ["id"])


def downgrade() -> None:
    with op.batch_alter_table("validation_runs") as batch:
        batch.drop_constraint("fk_validation_target_connector", type_="foreignkey")
        batch.drop_constraint("fk_validation_source_connector", type_="foreignkey")
        for name in ("grade", "score", "scope_json", "lane", "target_org", "source_org", "target_connector_id", "source_connector_id"):
            batch.drop_column(name)
        batch.alter_column("migration_run_id", existing_type=sa.String(length=64), nullable=False)

    with op.batch_alter_table("repository_inventory") as batch:
        for index in (
            "ix_repository_inventory_readiness_status", "ix_repository_inventory_readiness_score",
            "ix_repository_inventory_readiness_grade", "ix_repository_inventory_pipeline_lane",
        ):
            batch.drop_index(index)
        for name in (
            "readiness_json", "warnings_json", "blockers_json", "warning_count", "blocker_count",
            "readiness_status", "readiness_grade", "readiness_score", "target_state_json",
            "target_last_commit_sha", "target_default_branch", "target_visibility", "target_repository_id",
            "target_exists", "target_org_checked", "largest_blob_bytes", "large_file_warning_count",
            "large_file_blocker_count", "self_hosted_runner_count", "external_pipeline_count",
            "pipeline_lane", "open_pull_requests_count", "empty_repository",
        ):
            batch.drop_column(name)

    with op.batch_alter_table("purge_runs") as batch:
        batch.drop_column("scope_json")

    with op.batch_alter_table("migration_runs") as batch:
        batch.drop_index("ix_migration_runs_lane")
        for name in ("preflight_json", "selection_json", "lane", "acknowledged_manual_actions"):
            batch.drop_column(name)

    with op.batch_alter_table("discovery_runs") as batch:
        batch.drop_index("ix_discovery_runs_target_connector_id")
        for name in ("options_json", "assess_target", "target_org", "target_connector_id"):
            batch.drop_column(name)

    with op.batch_alter_table("workspaces") as batch:
        for name in ("migration_profile_json", "settings_json", "target_org", "source_org", "default_target_connector_id", "default_source_connector_id"):
            batch.drop_column(name)

    op.drop_index("ix_source_freeze_runs_workspace_id", table_name="source_freeze_runs")
    op.drop_index("ix_source_freeze_runs_source_org", table_name="source_freeze_runs")
    op.drop_index("ix_source_freeze_runs_source_connector_id", table_name="source_freeze_runs")
    op.drop_table("source_freeze_runs")
    op.drop_index("ix_saved_repository_scopes_workspace_id", table_name="saved_repository_scopes")
    op.drop_index("ix_saved_repository_scopes_created_by_id", table_name="saved_repository_scopes")
    op.drop_table("saved_repository_scopes")
    op.drop_table("ai_configuration")
    op.drop_index("ix_menu_settings_group_name", table_name="menu_settings")
    op.drop_table("menu_settings")
