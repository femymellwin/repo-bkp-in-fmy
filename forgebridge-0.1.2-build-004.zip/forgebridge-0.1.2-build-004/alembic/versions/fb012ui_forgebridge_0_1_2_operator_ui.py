"""ForgeBridge 0.1.2 operator UI and branding controls.

Revision ID: fb012ui
Revises: fb011enhanced
Create Date: 2026-07-12
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "fb012ui"
down_revision: Union[str, Sequence[str], None] = "fb011enhanced"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_DEFAULT_THEME = (
    '{"primary":"#243144","accent":"#3B82F6",'
    '"gradient_from":"#F8FAFC","gradient_to":"#EEF4FF",'
    '"border":"#D7DEE8","button_bg":"#FFFFFF",'
    '"button_border":"#CBD5E1","button_text":"#243144"}'
)


def upgrade() -> None:
    with op.batch_alter_table("branding") as batch:
        batch.add_column(
            sa.Column(
                "build_number",
                sa.String(length=80),
                nullable=False,
                server_default="FB-0.1.2-001",
            )
        )
        batch.add_column(
            sa.Column(
                "company_name",
                sa.String(length=120),
                nullable=False,
                server_default="Inception UAE",
            )
        )
        batch.add_column(
            sa.Column(
                "edition_label",
                sa.String(length=80),
                nullable=True,
                server_default="Enterprise",
            )
        )
        batch.add_column(
            sa.Column(
                "theme_json",
                sa.JSON(),
                nullable=False,
                server_default=sa.text(f"'{_DEFAULT_THEME}'"),
            )
        )


def downgrade() -> None:
    with op.batch_alter_table("branding") as batch:
        batch.drop_column("theme_json")
        batch.drop_column("edition_label")
        batch.drop_column("company_name")
        batch.drop_column("build_number")
