from __future__ import annotations

import pytest

from app.models import ConnectorKind, TargetFlavor
from app.services.url_validation import (
    UrlValidationError,
    validate_azure_openai_endpoint,
    validate_connector_urls,
)


def test_supported_connector_urls_are_normalized() -> None:
    ghes = validate_connector_urls(
        ConnectorKind.ghes,
        TargetFlavor.not_applicable,
        "https://ghes.example.com/",
        "https://ghes.example.com/api/v3/",
    )
    assert ghes.base_url == "https://ghes.example.com"
    assert ghes.api_url == "https://ghes.example.com/api/v3"

    cloud = validate_connector_urls(
        ConnectorKind.ghec,
        TargetFlavor.github_com,
        "https://github.com",
        "https://api.github.com",
    )
    assert cloud.api_url == "https://api.github.com"

    data_residency = validate_connector_urls(
        ConnectorKind.ghec,
        TargetFlavor.ghe_com,
        "https://acme.ghe.com",
        "https://api.acme.ghe.com",
    )
    assert data_residency.base_url == "https://acme.ghe.com"

    onepassword = validate_connector_urls(
        ConnectorKind.onepassword,
        TargetFlavor.not_applicable,
        "https://connect.internal.example:8443",
        "https://connect.internal.example:8443",
    )
    assert onepassword.api_url.endswith(":8443")

    explicit_default_port = validate_connector_urls(
        ConnectorKind.ghes,
        TargetFlavor.not_applicable,
        "https://ghes.example.com",
        "https://ghes.example.com:443/api/v3",
    )
    assert explicit_default_port.base_url == "https://ghes.example.com"


def test_connector_url_validation_rejects_credential_leaks_and_cross_origin_pairs() -> None:
    with pytest.raises(UrlValidationError, match="HTTPS"):
        validate_connector_urls(
            ConnectorKind.ghes,
            TargetFlavor.not_applicable,
            "http://ghes.example.com",
            "http://ghes.example.com/api/v3",
        )
    with pytest.raises(UrlValidationError, match="embedded credentials"):
        validate_connector_urls(
            ConnectorKind.ghes,
            TargetFlavor.not_applicable,
            "https://user:password@ghes.example.com",
            "https://ghes.example.com/api/v3",
        )
    with pytest.raises(UrlValidationError, match="same origin"):
        validate_connector_urls(
            ConnectorKind.ghes,
            TargetFlavor.not_applicable,
            "https://ghes-a.example.com",
            "https://ghes-b.example.com/api/v3",
        )
    with pytest.raises(UrlValidationError, match="same enterprise origin"):
        validate_connector_urls(
            ConnectorKind.ghec,
            TargetFlavor.ghe_com,
            "https://alpha.ghe.com",
            "https://api.beta.ghe.com",
        )
    with pytest.raises(UrlValidationError, match="without /v1"):
        validate_connector_urls(
            ConnectorKind.onepassword,
            TargetFlavor.not_applicable,
            "https://connect.example.com/v1",
            "https://connect.example.com/v1",
        )


def test_azure_openai_endpoint_is_restricted_to_azure_origins() -> None:
    assert (
        validate_azure_openai_endpoint("https://forgebridge.openai.azure.com/openai/v1/")
        == "https://forgebridge.openai.azure.com/openai/v1"
    )
    assert (
        validate_azure_openai_endpoint("https://forgebridge.services.ai.azure.com")
        == "https://forgebridge.services.ai.azure.com"
    )
    with pytest.raises(UrlValidationError, match="Azure OpenAI endpoint"):
        validate_azure_openai_endpoint("https://openai.example.com")
    with pytest.raises(UrlValidationError, match="path"):
        validate_azure_openai_endpoint("https://forgebridge.openai.azure.com/private/path")
