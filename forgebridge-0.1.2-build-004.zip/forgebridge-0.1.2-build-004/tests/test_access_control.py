from __future__ import annotations

import re
import uuid

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import User, UserRole, Workspace
from app.security import hash_password


def _csrf(html: str) -> str:
    match = re.search(r'name="csrf_token" value="([^"]+)"', html)
    assert match
    return match.group(1)


def test_standard_user_is_isolated_to_owned_workspaces_and_admin_pages() -> None:
    suffix = uuid.uuid4().hex[:8]
    username = f"operator-{suffix}"
    password = "StrongPassword123!"
    with TestClient(app) as client:
        with SessionLocal() as db:
            admin = db.scalar(select(User).where(User.username == "admin"))
            assert admin
            operator = User(
                username=username,
                email=f"{username}@example.com",
                password_hash=hash_password(password),
                role=UserRole.user,
                active=True,
            )
            db.add(operator)
            db.flush()
            owned = Workspace(name=f"Owned {suffix}", slug=f"owned-{suffix}", owner_id=operator.id)
            foreign = Workspace(name=f"Foreign {suffix}", slug=f"foreign-{suffix}", owner_id=admin.id)
            db.add_all([owned, foreign])
            db.commit()
            owned_id, foreign_id = owned.id, foreign.id

        token = _csrf(client.get("/login").text)
        login = client.post(
            "/login",
            data={"csrf_token": token, "username": username, "password": password},
            follow_redirects=False,
        )
        assert login.status_code == 303

        listing = client.get("/workspaces")
        assert listing.status_code == 200
        assert f"Owned {suffix}" in listing.text
        assert f"Foreign {suffix}" not in listing.text
        assert client.get(f"/workspaces/{owned_id}").status_code == 200
        assert client.get(f"/workspaces/{foreign_id}").status_code == 403
        assert client.get("/admin/users").status_code == 403
        assert client.get("/admin/ai").status_code == 403
