from __future__ import annotations

from app.services import ai


def test_managed_identity_uses_injected_token_without_sdk(monkeypatch) -> None:
    monkeypatch.setenv("AZURE_ACCESS_TOKEN", "controlled-test-token")
    assert ai._access_token() == "controlled-test-token"


def test_app_service_managed_identity_endpoint_is_used(monkeypatch) -> None:
    monkeypatch.delenv("AZURE_ACCESS_TOKEN", raising=False)
    monkeypatch.setenv("IDENTITY_ENDPOINT", "http://127.0.0.1:40342/msi/token")
    monkeypatch.setenv("IDENTITY_HEADER", "identity-header")
    monkeypatch.setenv("AZURE_CLIENT_ID", "client-id")
    observed = {}

    def fake_request(url, *, headers, params):
        observed.update(url=url, headers=headers, params=params)
        return "managed-token"

    monkeypatch.setattr(ai, "_managed_identity_token_request", fake_request)
    assert ai._access_token() == "managed-token"
    assert observed["headers"] == {"X-IDENTITY-HEADER": "identity-header"}
    assert observed["params"]["client_id"] == "client-id"
    assert observed["params"]["resource"] == "https://cognitiveservices.azure.com/"
