from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base
from app.models import DiscoveryRun, Job, JobStatus, User, UserRole, Workspace
from app import tasks


def test_worker_failure_marks_job_and_domain_record_failed(monkeypatch) -> None:
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    SessionFactory = sessionmaker(bind=engine, expire_on_commit=False)
    Base.metadata.create_all(engine)
    with SessionFactory() as db:
        user = User(
            username="worker-test",
            email="worker-test@example.com",
            password_hash="unused",
            role=UserRole.admin,
        )
        db.add(user)
        db.flush()
        workspace = Workspace(name="Worker test", slug="worker-test", owner_id=user.id)
        db.add(workspace)
        db.flush()
        discovery = DiscoveryRun(
            workspace_id=workspace.id,
            connector_id="missing-connector",
            created_by_id=user.id,
            source_org="legacy",
            status=JobStatus.queued,
        )
        db.add(discovery)
        db.flush()
        job = Job(
            workspace_id=workspace.id,
            created_by_id=user.id,
            kind="discovery",
            status=JobStatus.queued,
            payload_json={"discovery_run_id": discovery.id},
        )
        db.add(job)
        db.commit()
        job_id, discovery_id = job.id, discovery.id

    def fail_handler(db, job):
        raise RuntimeError("synthetic preflight failure")

    monkeypatch.setattr(tasks, "SessionLocal", SessionFactory)
    monkeypatch.setitem(tasks.HANDLERS, "discovery", fail_handler)
    result = tasks.execute_job(job_id)
    assert result["status"] == "failed"

    with SessionFactory() as db:
        job = db.get(Job, job_id)
        discovery = db.get(DiscoveryRun, discovery_id)
        assert job and job.status == JobStatus.failed
        assert job.error_message == "synthetic preflight failure"
        assert discovery and discovery.status == JobStatus.failed
        assert discovery.summary_json["error"] == "synthetic preflight failure"
