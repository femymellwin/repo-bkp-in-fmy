from app.models import (
    Connector,
    ConnectorKind,
    MigrationMethod,
    MigrationMode,
    MigrationRun,
    PipelinePolicy,
    RepoMigration,
    RepositoryInventory,
    TargetFlavor,
)
from app.services.migration import build_gei_command


def test_gei_command_uses_official_flags_and_production_lock() -> None:
    inventory = RepositoryInventory(
        workspace_id="wsp_test",
        connector_id="con_source",
        source_org="legacy-org",
        name="payments-api",
        full_name="legacy-org/payments-api",
        target_name="payments-api",
        visibility="private",
    )
    item = RepoMigration(
        migration_run_id="mig_test",
        repository_inventory_id="rep_test",
        source_repo="payments-api",
        target_repo="payments-api",
        repository=inventory,
    )
    run = MigrationRun(
        id="mig_test",
        workspace_id="wsp_test",
        created_by_id="usr_test",
        source_connector_id="con_source",
        target_connector_id="con_target",
        source_org="legacy-org",
        target_org="cloud-org",
        method=MigrationMethod.gei,
        mode=MigrationMode.production,
        pipeline_policy=PipelinePolicy.preserve_disable_actions,
        lock_source_at_cutover=True,
        storage_mode="github_owned",
    )
    source = Connector(
        id="con_source",
        workspace_id="wsp_test",
        name="GHES",
        kind=ConnectorKind.ghes,
        target_flavor=TargetFlavor.not_applicable,
        base_url="https://ghes.example.com",
        api_url="https://ghes.example.com/api/v3",
        verify_ssl=True,
    )
    target = Connector(
        id="con_target",
        workspace_id="wsp_test",
        name="GHEC",
        kind=ConnectorKind.ghec,
        target_flavor=TargetFlavor.ghe_com,
        base_url="https://enterprise.ghe.com",
        api_url="https://api.enterprise.ghe.com",
        verify_ssl=True,
    )

    command = build_gei_command(run, item, source, target)
    assert command[:2] == ["gei", "migrate-repo"]
    assert "--use-github-storage" in command
    assert "--lock-source-repo" in command
    assert "--target-api-url" in command
    assert "--github-source-org" in command
    assert "--github-target-org" in command


def test_elm_command_uses_official_create_flags(monkeypatch) -> None:
    from app.services import migration

    inventory = RepositoryInventory(
        workspace_id="wsp_test",
        connector_id="con_source",
        source_org="legacy-org",
        name="monorepo",
        full_name="legacy-org/monorepo",
        target_name="monorepo",
        visibility="internal",
    )
    item = RepoMigration(
        migration_run_id="mig_elm",
        repository_inventory_id="rep_elm",
        source_repo="monorepo",
        target_repo="monorepo-cloud",
        repository=inventory,
    )
    run = MigrationRun(
        id="mig_elm",
        workspace_id="wsp_test",
        created_by_id="usr_test",
        source_connector_id="con_source",
        target_connector_id="con_target",
        source_org="legacy-org",
        target_org="cloud-org",
        method=MigrationMethod.elm,
        mode=MigrationMode.production,
        pipeline_policy=PipelinePolicy.preserve_current_settings,
    )
    target = Connector(
        id="con_target",
        workspace_id="wsp_test",
        name="GHE.com",
        kind=ConnectorKind.ghec,
        target_flavor=TargetFlavor.ghe_com,
        base_url="https://enterprise.ghe.com",
        api_url="https://api.enterprise.ghe.com",
        verify_ssl=True,
    )
    monkeypatch.setattr(migration, "_ssh_base_command", lambda: ["ssh", "admin@ghes"])

    command = migration.build_elm_create_command(run, item, target)
    assert command[:2] == ["ssh", "admin@ghes"]
    remote = command[-1]
    assert "elm migration create" in remote
    assert "--source-org legacy-org" in remote
    assert "--source-repo monorepo" in remote
    assert "--target-org cloud-org" in remote
    assert "--target-repo monorepo-cloud" in remote
    assert "--target-api https://api.enterprise.ghe.com" in remote
    assert "--pat-name system-pat" in remote
    assert "--start" in remote
    assert migration.build_elm_cutover_command.__name__ == "build_elm_cutover_command"
