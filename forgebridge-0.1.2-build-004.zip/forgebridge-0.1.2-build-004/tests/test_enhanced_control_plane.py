from __future__ import annotations

import re
import time

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import (
    AIConfiguration,
    Connector,
    ConnectorKind,
    Job,
    JobStatus,
    MenuSetting,
    RepositoryInventory,
    SourceFreezeRun,
    ValidationRun,
    Workspace,
)


def _csrf(html: str) -> str:
    match = re.search(r'name="csrf_token" value="([^"]+)"', html)
    assert match
    return match.group(1)


def _login(client: TestClient) -> None:
    token = _csrf(client.get("/login").text)
    response = client.post(
        "/login",
        data={"csrf_token": token, "username": "admin", "password": "ChangeMe123!"},
        follow_redirects=False,
    )
    assert response.status_code == 303


def _wait_job(job_id: str, timeout: float = 15.0) -> Job:
    deadline = time.time() + timeout
    while time.time() < deadline:
        with SessionLocal() as db:
            job = db.get(Job, job_id)
            if job and job.status in (JobStatus.succeeded, JobStatus.failed, JobStatus.cancelled):
                db.expunge(job)
                return job
        time.sleep(0.05)
    raise AssertionError(f"Job did not finish: {job_id}")


def _demo_context() -> tuple[str, str, str]:
    with SessionLocal() as db:
        workspace = db.scalar(select(Workspace).where(Workspace.slug == "demo-migration"))
        assert workspace
        source = db.scalar(
            select(Connector).where(
                Connector.workspace_id == workspace.id,
                Connector.kind == ConnectorKind.simulated_ghes,
            )
        )
        target = db.scalar(
            select(Connector).where(
                Connector.workspace_id == workspace.id,
                Connector.kind == ConnectorKind.simulated_ghec,
            )
        )
        assert source and target
        return workspace.id, source.id, target.id


def _ensure_discovery(client: TestClient, workspace_id: str, source_id: str, target_id: str) -> None:
    with SessionLocal() as db:
        if db.scalar(
            select(RepositoryInventory.id).where(RepositoryInventory.workspace_id == workspace_id).limit(1)
        ):
            return
    page = client.get(f"/workspaces/{workspace_id}/github/discovery")
    response = client.post(
        f"/workspaces/{workspace_id}/github/discovery",
        data={
            "csrf_token": _csrf(page.text),
            "connector_id": source_id,
            "source_org": "legacy-engineering",
            "target_connector_id": target_id,
            "target_org": "cloud-engineering",
            "readiness_method": "gei",
            "deep_scan": "on",
            "pipeline_scan": "on",
            "external_pipeline_scan": "on",
            "target_probe": "on",
        },
        follow_redirects=False,
    )
    assert response.status_code == 303
    with SessionLocal() as db:
        job = db.scalar(
            select(Job)
            .where(Job.workspace_id == workspace_id, Job.kind == "discovery")
            .order_by(Job.created_at.desc())
        )
        assert job
        job_id = job.id
    completed = _wait_job(job_id)
    assert completed.status == JobStatus.succeeded, completed.error_message


def test_enhanced_navigation_workflows_and_administration() -> None:
    with TestClient(app) as client:
        _login(client)
        workspace_id, source_id, target_id = _demo_context()
        _ensure_discovery(client, workspace_id, source_id, target_id)

        pages = {
            f"/workspaces/{workspace_id}": "Workspace migration profile",
            f"/workspaces/{workspace_id}/github/discovery": "Repository discovery",
            f"/workspaces/{workspace_id}/github/with-pipelines": "Repositories with pipelines",
            f"/workspaces/{workspace_id}/github/without-pipelines": "Repositories without pipelines",
            f"/workspaces/{workspace_id}/github/migrations": "Migration runs",
            f"/workspaces/{workspace_id}/github/validation": "Repository validation",
            f"/workspaces/{workspace_id}/github/target-purge": "Target purge",
            f"/workspaces/{workspace_id}/github/source-read-only": "Source read-only",
            f"/workspaces/{workspace_id}/jobs": "Persisted job ledger",
            f"/workspaces/{workspace_id}/reports": "Migration evidence bundles",
            "/admin/branding": "Branding",
            "/admin/users": "Users",
            "/admin/menu": "Menu enablement",
            "/admin/audit": "Audit activity",
            "/admin/ai": "Azure OpenAI configuration",
            "/help": "Help index",
            "/help/github-enterprise-migration": "GitHub Enterprise migration guide",
        }
        for path, marker in pages.items():
            response = client.get(path)
            assert response.status_code == 200, path
            assert marker in response.text, path

        lane_page = client.get(f"/workspaces/{workspace_id}/github/with-pipelines").text
        assert "Migration checks" in lane_page
        assert "All grades" in lane_page
        assert "Select visible" in lane_page
        assert "acknowledged_manual_actions" in lane_page
        discovery_page = client.get(f"/workspaces/{workspace_id}/github/discovery").text
        assert "data-filter=\"grade\"" in discovery_page
        assert "Pipeline owner report" in discovery_page

        # Save validated workspace defaults.
        profile_page = client.get(f"/workspaces/{workspace_id}")
        response = client.post(
            f"/workspaces/{workspace_id}/profile",
            data={
                "csrf_token": _csrf(profile_page.text),
                "source_connector_id": source_id,
                "target_connector_id": target_id,
                "source_org": "legacy-engineering",
                "target_org": "cloud-engineering",
                "default_method": "gei",
                "default_concurrency": "5",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            workspace = db.get(Workspace, workspace_id)
            assert workspace
            assert workspace.default_source_connector_id == source_id
            assert workspace.default_target_connector_id == target_id
            assert workspace.migration_profile_json["default_concurrency"] == 5

        # Standalone source/target validation and deterministic grade.
        with SessionLocal() as db:
            repository = db.scalar(
                select(RepositoryInventory)
                .where(RepositoryInventory.workspace_id == workspace_id)
                .order_by(RepositoryInventory.name)
            )
            assert repository
            repository_id = repository.id
            target_name = repository.target_name
        validation_page = client.get(f"/workspaces/{workspace_id}/github/validation")
        response = client.post(
            f"/workspaces/{workspace_id}/github/validation",
            data={
                "csrf_token": _csrf(validation_page.text),
                "source_connector_id": source_id,
                "target_connector_id": target_id,
                "source_org": "legacy-engineering",
                "target_org": "cloud-engineering",
                "method": "gei",
                "lane": "all",
                "repository_ids": [repository_id],
                f"target_name_{repository_id}": target_name,
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            validation = db.scalar(
                select(ValidationRun)
                .where(ValidationRun.workspace_id == workspace_id)
                .order_by(ValidationRun.created_at.desc())
            )
            job = db.scalar(
                select(Job)
                .where(Job.workspace_id == workspace_id, Job.kind == "validation")
                .order_by(Job.created_at.desc())
            )
            assert validation and job
            validation_id, job_id = validation.id, job.id
        completed = _wait_job(job_id)
        assert completed.status == JobStatus.succeeded
        with SessionLocal() as db:
            validation = db.get(ValidationRun, validation_id)
            assert validation
            assert validation.grade in {"A", "B", "C", "D"}
            assert validation.score > 0
            assert validation.report_json["check_counts"]["total"] > 0

        # Source read-only is a dry-run by default and cannot mutate source.
        freeze_page = client.get(f"/workspaces/{workspace_id}/github/source-read-only")
        response = client.post(
            f"/workspaces/{workspace_id}/github/source-read-only",
            data={
                "csrf_token": _csrf(freeze_page.text),
                "source_connector_id": source_id,
                "source_org": "legacy-engineering",
                "repository_ids": [repository_id],
                "dry_run": "on",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            freeze = db.scalar(
                select(SourceFreezeRun)
                .where(SourceFreezeRun.workspace_id == workspace_id)
                .order_by(SourceFreezeRun.created_at.desc())
            )
            job = db.scalar(
                select(Job)
                .where(Job.workspace_id == workspace_id, Job.kind == "source_freeze")
                .order_by(Job.created_at.desc())
            )
            assert freeze and job
            freeze_id, job_id = freeze.id, job.id
        completed = _wait_job(job_id)
        assert completed.status == JobStatus.succeeded
        with SessionLocal() as db:
            freeze = db.get(SourceFreezeRun, freeze_id)
            assert freeze and freeze.dry_run is True
            assert freeze.archived_count == 0
            assert freeze.failed_count == 0
            assert all(item.get("source_modified") is False for item in freeze.result_json["results"])

        # Azure OpenAI settings persist securely without contacting Azure.
        ai_page = client.get("/admin/ai")
        response = client.post(
            "/admin/ai",
            data={
                "csrf_token": _csrf(ai_page.text),
                "enabled": "on",
                "endpoint": "https://example.openai.azure.com",
                "deployment": "migration-assistant",
                "model": "configured-by-admin",
                "auth_mode": "api_key",
                "api_key": "test-key-not-for-network-use",
                "temperature": "0.1",
                "max_input_chars": "60000",
                "max_output_tokens": "1200",
                "allowed_use_cases": ["job_interpretation", "validation_summary"],
                "system_prompt": "Use supplied migration evidence only and never execute a mutating action.",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            config = db.get(AIConfiguration, 1)
            assert config and config.enabled is True
            assert config.api_key_last4 == "-use"
            assert config.encrypted_api_key and "test-key" not in config.encrypted_api_key
            assert set(config.allowed_use_cases_json) == {"job_interpretation", "validation_summary"}
            assert "never execute" in config.system_prompt

        # Menu enablement hides navigation but never removes route authorization.
        menu_page = client.get("/admin/menu")
        with SessionLocal() as db:
            enabled_keys = [row.key for row in db.scalars(select(MenuSetting)).all() if row.enabled and row.key != "github.target_purge"]
        response = client.post(
            "/admin/menu",
            data={"csrf_token": _csrf(menu_page.text), "enabled_keys": enabled_keys},
            follow_redirects=False,
        )
        assert response.status_code == 303
        page = client.get(f"/workspaces/{workspace_id}")
        assert "href=\"/workspaces/%s/github/purge\"" % workspace_id not in page.text
        assert client.get(f"/workspaces/{workspace_id}/github/target-purge").status_code == 200

        # Restore all menu items for subsequent tests and packaged demo behavior.
        restore_page = client.get("/admin/menu")
        with SessionLocal() as db:
            all_keys = [row.key for row in db.scalars(select(MenuSetting)).all()]
        response = client.post(
            "/admin/menu",
            data={"csrf_token": _csrf(restore_page.text), "enabled_keys": all_keys},
            follow_redirects=False,
        )
        assert response.status_code == 303
        restored = client.get(f"/workspaces/{workspace_id}").text
        assert f'href="/workspaces/{workspace_id}/github/purge"' in restored


def test_saved_scope_plan_gate_and_pipeline_owner_handoff() -> None:
    from app.models import MigrationRun, MigrationStatus, SavedRepositoryScope

    with TestClient(app) as client:
        _login(client)
        workspace_id, source_id, target_id = _demo_context()
        _ensure_discovery(client, workspace_id, source_id, target_id)

        with SessionLocal() as db:
            repository = db.scalar(
                select(RepositoryInventory).where(
                    RepositoryInventory.workspace_id == workspace_id,
                    RepositoryInventory.name == "payments-api",
                )
            )
            assert repository and repository.pipeline_lane == "with_pipelines"
            repository_id = repository.id

        lane = client.get(f"/workspaces/{workspace_id}/github/with-pipelines")
        response = client.post(
            f"/workspaces/{workspace_id}/github/scopes",
            data={
                "csrf_token": _csrf(lane.text),
                "lane": "with_pipelines",
                "scope_name": "Payments rehearsal",
                "repository_ids": [repository_id],
                "scope_filter_search": "payments",
                "scope_filter_status": "needs_review",
                "scope_filter_grade": "B",
                "scope_filter_risk": "medium",
                "scope_filter_dependency": "secrets",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            scope = db.scalar(
                select(SavedRepositoryScope).where(
                    SavedRepositoryScope.workspace_id == workspace_id,
                    SavedRepositoryScope.name == "Payments rehearsal",
                )
            )
            assert scope
            assert scope.repository_ids_json == [repository_id]
            scope_id = scope.id
        loaded = client.get(f"/workspaces/{workspace_id}/github/with-pipelines?scope={scope_id}")
        assert loaded.status_code == 200
        assert "Payments rehearsal" in loaded.text
        assert f'value="{repository_id}" checked' in loaded.text

        handoff = client.get(f"/workspaces/{workspace_id}/github/pipeline-owner-handoff")
        assert handoff.status_code == 200
        assert "Pipeline owner handoff" in handoff.text
        assert "Secret references" in handoff.text
        markdown = client.get(f"/workspaces/{workspace_id}/reports/pipeline-owner.md")
        assert markdown.status_code == 200
        assert "No GitHub secret values are present" in markdown.text
        assert "payments-api" in markdown.text
        assert "***REDACTED***" not in markdown.text or "Security findings" in markdown.text
        owner_json = client.get(f"/workspaces/{workspace_id}/reports/pipeline-owner.json")
        assert owner_json.status_code == 200
        assert owner_json.json()["secret_values_included"] is False

        # Create a persisted, auditable plan without starting a background job.
        response = client.post(
            f"/workspaces/{workspace_id}/migrations",
            data={
                "csrf_token": _csrf(loaded.text),
                "execution_intent": "plan",
                "lane": "with_pipelines",
                "source_connector_id": source_id,
                "target_connector_id": target_id,
                "source_org": "legacy-engineering",
                "target_org": "cloud-engineering",
                "method": "gei",
                "mode": "trial",
                "pipeline_policy": "preserve_disable_actions",
                "concurrency": "3",
                "storage_mode": "github_owned",
                "acknowledged_manual_actions": "on",
                "repository_ids": [repository_id],
                f"target_name_{repository_id}": "payments-api-plan-gate",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            run = db.scalar(
                select(MigrationRun)
                .where(MigrationRun.workspace_id == workspace_id)
                .order_by(MigrationRun.created_at.desc())
            )
            assert run and run.status == MigrationStatus.planned
            run_id = run.id
            active = [
                item for item in db.scalars(select(Job).where(Job.workspace_id == workspace_id)).all()
                if (item.payload_json or {}).get("migration_run_id") == run_id
            ]
            assert not active

        detail = client.get(f"/workspaces/{workspace_id}/migrations/{run_id}")
        assert "Queue planned wave" in detail.text
        response = client.post(
            f"/workspaces/{workspace_id}/migrations/{run_id}/queue",
            data={"csrf_token": _csrf(detail.text), "confirmation": f"QUEUE {run_id}"},
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            job = next(
                item for item in db.scalars(
                    select(Job).where(Job.workspace_id == workspace_id, Job.kind == "migration")
                ).all()
                if (item.payload_json or {}).get("migration_run_id") == run_id
            )
            job_id = job.id
        completed = _wait_job(job_id)
        assert completed.status == JobStatus.succeeded
        with SessionLocal() as db:
            run = db.get(MigrationRun, run_id)
            assert run and run.status in {MigrationStatus.completed, MigrationStatus.completed_with_warnings}
