import json
from pathlib import Path

from sqlalchemy import select

from app.database import Base, SessionLocal, engine
from app.models import Job, JobStatus, User, UserRole
from app.security import hash_password
from app.services.job_utils import append_job_log, update_job


def test_job_log_and_result_redact_credentials_but_preserve_secret_names(tmp_path: Path) -> None:
    Base.metadata.create_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.username == "redaction-test-admin"))
        if not user:
            user = User(
                username="redaction-test-admin",
                email="redaction-test-admin@example.com",
                password_hash=hash_password("StrongPassword123!"),
                role=UserRole.admin,
                active=True,
            )
            db.add(user)
            db.flush()

        job = Job(
            kind="test",
            created_by_id=user.id,
            status=JobStatus.queued,
            payload_json={},
            result_json={},
            log_path=str(tmp_path / "job.jsonl"),
        )
        db.add(job)
        db.commit()

        raw_pat = "github_" + "pat_abcdefghijklmnopqrstuvwxyz123456"
        append_job_log(
            job,
            f"Authorization: Bearer {raw_pat}",
            {
                "access_token": raw_pat,
                "secret_names": ["PROD_API_TOKEN"],
                "message": f"token={raw_pat}",
            },
        )
        update_job(
            db,
            job,
            result={"cleanup_token": "purge-me", "secret_names": ["PROD_API_TOKEN"]},
            error=f"api_key={raw_pat}",
        )

        record = json.loads(Path(job.log_path).read_text().splitlines()[0])
        assert raw_pat not in json.dumps(record)
        assert record["data"]["access_token"] == "***REDACTED***"
        assert record["data"]["secret_names"] == ["PROD_API_TOKEN"]
        assert job.result_json["cleanup_token"] == "***REDACTED***"
        assert job.result_json["secret_names"] == ["PROD_API_TOKEN"]
        assert raw_pat not in (job.error_message or "")
