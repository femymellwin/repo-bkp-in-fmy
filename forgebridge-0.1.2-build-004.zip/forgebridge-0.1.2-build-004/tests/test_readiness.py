from __future__ import annotations

from app.services.readiness import assess_repository


def _repository(**overrides):
    data = {
        "default_branch": "main",
        "last_commit_sha": "a" * 40,
        "visibility": "private",
        "target_state_json": {"probed": True, "exists": False},
        "pipeline_report_json": {},
        "detail_json": {"deep_scan_complete": True},
        "open_pull_requests_count": 0,
        "inactive_days": 10,
        "largest_release_asset_bytes": 0,
        "release_assets_bytes": 0,
    }
    data.update(overrides)
    return data


def _codes(result, key):
    return {item["code"] for item in result[key]}


def test_clean_repository_receives_ready_grade() -> None:
    result = assess_repository(_repository(), method="gei")
    assert result["status"] == "ready"
    assert result["grade"] == "A"
    assert result["score"] == 100
    assert result["calculation"]["not_a_guarantee"] is True


def test_target_conflict_and_hardcoded_credential_are_blockers() -> None:
    result = assess_repository(
        _repository(
            target_state_json={"probed": True, "exists": True, "id": 1234},
            pipeline_report_json={"hardcoded_credential_findings": [{"path": "deploy.yml"}]},
        ),
        method="gei",
    )
    assert result["status"] == "blocked"
    assert result["grade"] == "F"
    assert {"TARGET_EXISTS", "HARDCODED_PIPELINE_CREDENTIAL"}.issubset(_codes(result, "blockers"))


def test_method_specific_elm_and_gei_findings() -> None:
    elm = assess_repository(
        _repository(visibility="public", largest_release_asset_bytes=2 * 1024**3 + 1),
        method="elm",
    )
    assert elm["status"] == "blocked"
    assert {"ELM_PUBLIC_REPOSITORY", "ELM_RELEASE_ASSET_OVER_2_GIB"}.issubset(
        _codes(elm, "blockers")
    )

    gei = assess_repository(_repository(has_lfs=True), method="gei")
    assert gei["status"] == "needs_review"
    assert "GEI_LFS_SEPARATE_TRANSFER" in _codes(gei, "warnings")
