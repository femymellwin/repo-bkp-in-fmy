from __future__ import annotations

import re
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app

ROOT = Path(__file__).resolve().parents[1]


def csrf(html: str) -> str:
    match = re.search(r'name="csrf_token" value="([^"]+)"', html)
    assert match
    return match.group(1)


def login(client: TestClient) -> None:
    page = client.get("/login")
    response = client.post(
        "/login",
        data={"csrf_token": csrf(page.text), "username": "admin", "password": "ChangeMe123!"},
        follow_redirects=False,
    )
    assert response.status_code == 303


def test_login_has_product_logo_favicon_and_no_demo_credentials() -> None:
    with TestClient(app) as client:
        page = client.get("/login")
        assert page.status_code == 200
        assert 'rel="icon" href="/favicon.svg' in page.text
        assert "GHES → GHEC" in page.text
        assert "GitHub Enterprise Importer" in page.text
        assert "Enterprise Live Migrations" in page.text
        assert "ChangeMe123!" not in page.text
        favicon = client.get("/favicon.svg")
        assert favicon.status_code == 200
        assert favicon.headers["content-type"].startswith("image/svg+xml")


def test_grouped_navigation_and_brand_build_identity() -> None:
    with TestClient(app) as client:
        login(client)
        page = client.get("/")
        assert page.status_code == 200
        for label in ("Overview", "GitHub", "Operations", "Configure", "Help"):
            assert f">{label}<" in page.text
        assert "Repository discovery" in page.text
        assert "Repository with pipelines" in page.text
        assert "Repository without pipelines" in page.text
        assert "Repository validation" in page.text
        assert "Target purge" in page.text
        assert "Source read-only" in page.text
        assert "AI configuration" in page.text
        assert "Build FB-0.1.2-004" in page.text


def test_branding_page_updates_build_number_and_theme() -> None:
    with TestClient(app) as client:
        login(client)
        page = client.get("/admin/branding")
        assert page.status_code == 200
        assert "Branding and build identity" in page.text
        assert 'name="build_number"' in page.text
        assert 'name="logo_file"' in page.text
        assert 'name="theme_accent"' in page.text
        response = client.post(
            "/admin/branding",
            data={
                "csrf_token": csrf(page.text),
                "product_name": "ForgeBridge",
                "company_name": "Inception UAE",
                "tagline": "Controlled, auditable GHES-to-GHEC migrations.",
                "version": "0.1.2",
                "build_number": "FB-0.1.2-TEST",
                "edition_label": "Enterprise",
                "support_email": "platform@example.com",
                "theme_primary": "#243144",
                "theme_accent": "#3367D6",
                "theme_gradient_from": "#F8FAFC",
                "theme_gradient_to": "#EEF4FF",
                "theme_border": "#D7DEE8",
                "theme_button_bg": "#FFFFFF",
                "theme_button_border": "#CBD5E1",
                "theme_button_text": "#243144",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        assert "Build FB-0.1.2-TEST" in client.get("/").text
        theme = client.get("/branding/theme.css")
        assert theme.status_code == 200
        assert "--ado2-accent: #3367D6" in theme.text

        # Restore the packaged build identity for later tests and release output.
        page = client.get("/admin/branding")
        response = client.post(
            "/admin/branding",
            data={
                "csrf_token": csrf(page.text),
                "product_name": "ForgeBridge",
                "company_name": "Inception UAE",
                "tagline": "Controlled, auditable GHES-to-GHEC migrations.",
                "version": "0.1.2",
                "build_number": "FB-0.1.2-004",
                "edition_label": "Enterprise",
                "support_email": "",
                "theme_primary": "#243144",
                "theme_accent": "#3B82F6",
                "theme_gradient_from": "#F8FAFC",
                "theme_gradient_to": "#EEF4FF",
                "theme_border": "#D7DEE8",
                "theme_button_bg": "#FFFFFF",
                "theme_button_border": "#CBD5E1",
                "theme_button_text": "#243144",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303


def test_production_contract_uses_port_3002_and_single_management_script() -> None:
    dockerfile = (ROOT / "Dockerfile").read_text()
    compose = (ROOT / "docker-compose.yml").read_text()
    launcher = (ROOT / "forgebridge.sh").read_text()
    assert "EXPOSE 3002" in dockerfile
    assert "127.0.0.1:3002/health" in dockerfile
    assert ':3002"' in compose
    assert 'DEFAULT_PORT="3002"' in launcher
    assert "FORGEBRIDGE_PORT=${DEFAULT_PORT}" in launcher
    assert "run_demo" not in launcher
    assert "start_stack" in launcher
    assert "backup_stack" in launcher
    assert "upgrade_stack" in launcher
    assert "ENABLE_REAL_MIGRATIONS=false" in launcher


def test_uploaded_logo_is_used_as_browser_favicon() -> None:
    # Valid 1x1 PNG, used only in the isolated pytest branding directory.
    png = bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
        "0000000d49444154789c6360f8cfc000000301010018dd8db10000000049454e44ae426082"
    )
    with TestClient(app) as client:
        login(client)
        page = client.get("/admin/branding")
        response = client.post(
            "/admin/branding",
            data={
                "csrf_token": csrf(page.text),
                "product_name": "ForgeBridge",
                "company_name": "Inception UAE",
                "tagline": "Controlled, auditable GHES-to-GHEC migrations.",
                "version": "0.1.2",
                "build_number": "FB-0.1.2-004",
                "edition_label": "Enterprise",
                "support_email": "",
                "theme_primary": "#243144",
                "theme_accent": "#3B82F6",
                "theme_gradient_from": "#F8FAFC",
                "theme_gradient_to": "#EEF4FF",
                "theme_border": "#D7DEE8",
                "theme_button_bg": "#FFFFFF",
                "theme_button_border": "#CBD5E1",
                "theme_button_text": "#243144",
            },
            files={"logo_file": ("forgebridge.png", png, "image/png")},
            follow_redirects=False,
        )
        assert response.status_code == 303
        home = client.get("/")
        assert 'rel="icon" href="/branding/logo?v=' in home.text
        logo = client.get("/branding/logo")
        assert logo.status_code == 200
        assert logo.headers["content-type"].startswith("image/png")
        assert logo.content.startswith(b"\x89PNG\r\n\x1a\n")

        reset = client.get("/admin/branding")
        response = client.post(
            "/admin/branding/reset-logo",
            data={"csrf_token": csrf(reset.text)},
            follow_redirects=False,
        )
        assert response.status_code == 303
        assert 'rel="icon" href="/favicon.svg?v=' in client.get("/").text
