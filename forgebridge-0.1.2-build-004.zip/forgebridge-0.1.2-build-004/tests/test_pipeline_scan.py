from app.services.pipeline_scan import merge_pipeline_reports, scan_workflow


def test_pipeline_scan_inventories_dependencies_without_exposing_values() -> None:
    workflow = """
name: deploy
on: push
permissions:
  id-token: write
jobs:
  deploy:
    runs-on: [self-hosted, linux]
    environment: production
    steps:
      - uses: actions/checkout@v4
      - run: curl https://api.example.internal/deploy?token=should-not-appear
        env:
          API_TOKEN: ${{ secrets.PROD_API_TOKEN }}
          RELEASE_CHANNEL: ${{ vars.RELEASE_CHANNEL }}
          password: hard-coded-demo-value
"""
    report = scan_workflow(".github/workflows/deploy.yml", workflow)
    assert report["secret_references"] == ["PROD_API_TOKEN"]
    assert report["variable_references"] == ["RELEASE_CHANNEL"]
    assert report["deployment_environments"] == ["production"]
    assert "self-hosted" in report["runners"]
    assert report["external_urls"] == ["https://api.example.internal/deploy"]
    assert len(report["hardcoded_credential_findings"]) == 1
    assert report["hardcoded_credential_findings"][0]["key"] == "password"
    assert report["hardcoded_credential_findings"][0]["value"] == "***REDACTED***"
    assert "hard-coded-demo-value" not in str(report)
    assert all(item["key"] != "id-token" for item in report["hardcoded_credential_findings"])

    merged = merge_pipeline_reports([report], ["REPO_SECRET"], ["REPO_VAR"])
    assert merged["secret_names"] == ["PROD_API_TOKEN", "REPO_SECRET"]
    assert all(item["value_available_from_github"] is False for item in merged["onepassword_mapping"])
