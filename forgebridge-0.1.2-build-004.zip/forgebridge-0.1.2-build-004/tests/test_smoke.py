from __future__ import annotations

import re
import time

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import (
    Connector,
    ConnectorKind,
    DiscoveryRun,
    Job,
    JobStatus,
    MigrationRun,
    PurgeRun,
    RepositoryInventory,
    RepoMigration,
    ValidationRun,
    Workspace,
)
from app.tasks import execute_job


def _csrf(html: str) -> str:
    match = re.search(r'name="csrf_token" value="([^"]+)"', html)
    assert match
    return match.group(1)


def _wait_job(job_id: str, timeout: float = 15.0) -> Job:
    deadline = time.time() + timeout
    while time.time() < deadline:
        with SessionLocal() as db:
            job = db.get(Job, job_id)
            if job and job.status in (JobStatus.succeeded, JobStatus.failed, JobStatus.cancelled):
                db.expunge(job)
                return job
        time.sleep(0.05)
    raise AssertionError(f"Job did not finish: {job_id}")


def test_end_to_end_simulated_migration() -> None:
    with TestClient(app) as client:
        assert client.get("/health").json()["status"] == "ok"
        login_token = _csrf(client.get("/login").text)
        response = client.post(
            "/login",
            data={"csrf_token": login_token, "username": "admin", "password": "ChangeMe123!"},
            follow_redirects=False,
        )
        assert response.status_code == 303

        with SessionLocal() as db:
            workspace = db.scalar(select(Workspace).where(Workspace.slug == "demo-migration"))
            assert workspace
            source = db.scalar(
                select(Connector).where(
                    Connector.workspace_id == workspace.id,
                    Connector.kind == ConnectorKind.simulated_ghes,
                )
            )
            target = db.scalar(
                select(Connector).where(
                    Connector.workspace_id == workspace.id,
                    Connector.kind == ConnectorKind.simulated_ghec,
                )
            )
            assert source and target
            workspace_id, source_id, target_id = workspace.id, source.id, target.id

        discovery_token = _csrf(client.get(f"/workspaces/{workspace_id}/discovery").text)
        response = client.post(
            f"/workspaces/{workspace_id}/discovery",
            data={
                "csrf_token": discovery_token,
                "connector_id": source_id,
                "source_org": "legacy-engineering",
                "deep_scan": "on",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            discovery = db.scalar(
                select(DiscoveryRun)
                .where(DiscoveryRun.workspace_id == workspace_id)
                .order_by(DiscoveryRun.created_at.desc())
            )
            assert discovery and discovery.job_id
            discovery_job_id = discovery.job_id
        discovery_job = _wait_job(discovery_job_id)
        assert discovery_job.status == JobStatus.succeeded, discovery_job.error_message
        assert discovery_job.result_json["repositories"] == 5

        with SessionLocal() as db:
            repositories = db.scalars(
                select(RepositoryInventory).where(RepositoryInventory.workspace_id == workspace_id)
            ).all()
            assert len(repositories) == 5
            assert all((repo.detail_json or {}).get("deep_scan_complete") for repo in repositories)
            chosen = next(repo for repo in repositories if repo.name == "payments-api")
            chosen_id, chosen_name = chosen.id, chosen.name

        migration_token = _csrf(client.get(f"/workspaces/{workspace_id}/migrations").text)
        response = client.post(
            f"/workspaces/{workspace_id}/migrations",
            data={
                "csrf_token": migration_token,
                "source_connector_id": source_id,
                "target_connector_id": target_id,
                "source_org": "legacy-engineering",
                "target_org": "cloud-engineering",
                "method": "gei",
                "mode": "trial",
                "pipeline_policy": "preserve_disable_actions",
                "concurrency": "9",
                "storage_mode": "github_owned",
                "acknowledged_manual_actions": "on",
                "repository_ids": [chosen_id],
                f"target_name_{chosen_id}": chosen_name,
            },
            follow_redirects=False,
        )
        assert response.status_code == 303

        with SessionLocal() as db:
            run = db.scalar(
                select(MigrationRun)
                .where(MigrationRun.workspace_id == workspace_id)
                .order_by(MigrationRun.created_at.desc())
            )
            assert run and run.concurrency == 5
            assert run.acknowledged_manual_actions is True
            assert run.preflight_json["accepted_count"] == 1
            assert run.preflight_json["manual_actions_acknowledged"] is True
            assert run.preflight_json["concurrency_limit"] == 5
            run_id, cleanup_token = run.id, run.cleanup_token
            migration_job = db.scalar(
                select(Job)
                .where(Job.workspace_id == workspace_id, Job.kind == "migration")
                .order_by(Job.created_at.desc())
            )
            assert migration_job
            migration_job_id = migration_job.id
        completed_job = _wait_job(migration_job_id)
        assert completed_job.status == JobStatus.succeeded, completed_job.error_message
        assert completed_job.result_json["completed"] == 1

        with SessionLocal() as db:
            item = db.scalar(select(RepoMigration).where(RepoMigration.migration_run_id == run_id))
            assert item and item.attempt_count == 1
            assert item.result_json.get("target_repository_id")
            repo_migration_id = item.id
        duplicate = execute_job(migration_job_id)
        assert duplicate["ignored"] is True
        with SessionLocal() as db:
            item = db.scalar(select(RepoMigration).where(RepoMigration.migration_run_id == run_id))
            assert item.attempt_count == 1

        detail_token = _csrf(client.get(f"/workspaces/{workspace_id}/migrations/{run_id}").text)
        response = client.post(
            f"/workspaces/{workspace_id}/migrations/{run_id}/validate",
            data={"csrf_token": detail_token},
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            validation = db.scalar(
                select(ValidationRun)
                .where(ValidationRun.migration_run_id == run_id)
                .order_by(ValidationRun.created_at.desc())
            )
            validation_job = db.scalar(
                select(Job)
                .where(Job.workspace_id == workspace_id, Job.kind == "validation")
                .order_by(Job.created_at.desc())
            )
            assert validation and validation_job
            validation_id, validation_job_id = validation.id, validation_job.id
        validation_result = _wait_job(validation_job_id)
        assert validation_result.status == JobStatus.succeeded
        assert validation_result.result_json["failed"] == 0

        bundle = client.get(f"/workspaces/{workspace_id}/reports/migrations/{run_id}.zip")
        assert bundle.status_code == 200
        assert bundle.headers["content-type"].startswith("application/zip")
        assert b"method-policy.json" in bundle.content
        assert client.get(
            f"/workspaces/{workspace_id}/reports/validations/{validation_id}.json"
        ).status_code == 200

        purge_token = _csrf(client.get(f"/workspaces/{workspace_id}/migrations/{run_id}").text)
        response = client.post(
            f"/workspaces/{workspace_id}/migrations/{run_id}/purge",
            data={
                "csrf_token": purge_token,
                "cleanup_token": cleanup_token,
                "repo_migration_ids": [repo_migration_id],
                "dry_run": "on",
                "confirmation": "",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            purge = db.scalar(
                select(PurgeRun)
                .where(PurgeRun.migration_run_id == run_id)
                .order_by(PurgeRun.created_at.desc())
            )
            purge_job = db.scalar(
                select(Job)
                .where(Job.workspace_id == workspace_id, Job.kind == "purge")
                .order_by(Job.created_at.desc())
            )
            assert purge and purge_job
            purge_job_id = purge_job.id
        purge_result = _wait_job(purge_job_id)
        assert purge_result.status == JobStatus.succeeded
        assert purge_result.result_json["source_touched"] is False
        assert purge_result.result_json["deleted"] == 0

        for path in (
            "/",
            f"/workspaces/{workspace_id}",
            f"/workspaces/{workspace_id}/connectors",
            f"/workspaces/{workspace_id}/jobs",
            f"/workspaces/{workspace_id}/reports",
            f"/workspaces/{workspace_id}/audit",
            "/admin/branding",
            "/admin/users",
        ):
            assert client.get(path).status_code == 200
