from __future__ import annotations

import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_docker_runtime_is_pypi_free_and_architecture_native() -> None:
    dockerfile = (ROOT / "Dockerfile").read_text()
    assert "FROM debian:trixie-slim" in dockerfile
    assert "python3-fastapi" in dockerfile
    assert "python3-uvicorn" in dockerfile
    assert "python3-psycopg" in dockerfile
    assert "python3-celery" in dockerfile
    assert "python3-pydantic-settings" in dockerfile
    assert "python_multipart" in dockerfile
    assert "python -m pip" not in dockerfile
    assert "python3 -m pip" not in dockerfile
    assert "pip install" not in dockerfile
    assert "https://pypi.org" not in dockerfile
    assert "COPY requirements.txt" not in dockerfile
    assert "COPY certs/" not in dockerfile
    assert "PIP_CERT=" not in dockerfile
    migration_source = (ROOT / "app/services/migration.py").read_text()
    assert 'command.append("--no-ssl-verify")' not in migration_source
    assert "TLS certificate verification must remain enabled" in migration_source


def test_official_standalone_gei_is_pinned_for_amd64_and_arm64() -> None:
    dockerfile = (ROOT / "Dockerfile").read_text()
    lock = (ROOT / "vendor/gei/GEI.lock").read_text()
    assert "ARG GEI_VERSION=1.30.3" in dockerfile
    assert "gei-linux-amd64" in dockerfile
    assert "gei-linux-arm64" in dockerfile
    assert "18980c737704c49ce57455f0792ef3a5ae01b3bfeed9eaa19a41d26f7e971735" in dockerfile
    assert "5a7ae4257fcf38297e3089ec3a1a4dc409b72a8dc984e860f0fb6c066d338d76" in dockerfile
    assert "sha256sum --check --strict" in dockerfile
    assert "gei migrate-repo --help" in dockerfile
    assert "release=v1.30.3" in lock
    shell_scripts = sorted(path.relative_to(ROOT).as_posix() for path in ROOT.rglob("*.sh"))
    assert shell_scripts == ["forgebridge.sh"]


def test_production_script_has_no_global_ca_workflow() -> None:
    launcher = (ROOT / "forgebridge.sh").read_text()
    for obsolete in ("ca-install", "ca-import-macos", "ca-status", "ca-remove", "ca-probe"):
        assert obsolete not in launcher
    assert "FB-0.1.2-004" in launcher
    assert "Build 004 does not invoke pip or contact PyPI" in launcher
    assert "clean-build" in launcher
    assert "tooling" in launcher


def test_init_advances_only_previous_packaged_build_numbers(tmp_path: Path) -> None:
    for old_build in ("FB-0.1.2-001", "FB-0.1.2-002", "FB-0.1.2-003"):
        environment_file = tmp_path / f"{old_build}.env"
        environment_file.write_text(
            "\n".join(
                [
                    "APP_NAME=ForgeBridge",
                    "APP_VERSION=0.1.2",
                    f"APP_BUILD_NUMBER={old_build}",
                    "SECRET_KEY=test-secret-key-with-sufficient-length",
                    "TOKEN_ENCRYPTION_KEY=QkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkI=",
                    "POSTGRES_DB=forgebridge",
                    "POSTGRES_USER=forgebridge",
                    "POSTGRES_PASSWORD=test-database-password",
                    "MIGRATION_POLICY_MODE=github-supported-only",
                    "FORGEBRIDGE_BIND_ADDRESS=127.0.0.1",
                    "FORGEBRIDGE_PORT=3002",
                    "DEFAULT_ADMIN_USERNAME=admin",
                    "DEFAULT_ADMIN_PASSWORD=test-password",
                    "SESSION_COOKIE_SECURE=false",
                ]
            )
            + "\n"
        )
        environment = {**os.environ, "FORGEBRIDGE_ENV_FILE": str(environment_file)}
        result = subprocess.run(
            [str(ROOT / "forgebridge.sh"), "init"],
            cwd=ROOT,
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )
        assert result.returncode == 0, result.stderr
        assert "APP_BUILD_NUMBER=FB-0.1.2-004" in environment_file.read_text()

    custom_file = tmp_path / "custom.env"
    custom_file.write_text(
        "\n".join(
            [
                "APP_NAME=ForgeBridge",
                "APP_VERSION=0.1.2",
                "APP_BUILD_NUMBER=CUSTOM-UAT-17",
                "SECRET_KEY=test-secret-key-with-sufficient-length",
                "TOKEN_ENCRYPTION_KEY=QkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkI=",
                "POSTGRES_DB=forgebridge",
                "POSTGRES_USER=forgebridge",
                "POSTGRES_PASSWORD=test-database-password",
                "MIGRATION_POLICY_MODE=github-supported-only",
                "FORGEBRIDGE_BIND_ADDRESS=127.0.0.1",
                "FORGEBRIDGE_PORT=3002",
                "DEFAULT_ADMIN_USERNAME=admin",
                "DEFAULT_ADMIN_PASSWORD=test-password",
                "SESSION_COOKIE_SECURE=false",
            ]
        )
        + "\n"
    )
    environment = {**os.environ, "FORGEBRIDGE_ENV_FILE": str(custom_file)}
    result = subprocess.run(
        [str(ROOT / "forgebridge.sh"), "init"],
        cwd=ROOT,
        env=environment,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "APP_BUILD_NUMBER=CUSTOM-UAT-17" in custom_file.read_text()


def test_migration_page_describes_standalone_runtime() -> None:
    template = (ROOT / "app/templates/migrations.html").read_text()
    assert "standalone Enterprise Importer" in template
    assert "GitHub CLI and the official GitHub Enterprise Importer extension" not in template
    assert "gei migrate-repo --help failed" in template
