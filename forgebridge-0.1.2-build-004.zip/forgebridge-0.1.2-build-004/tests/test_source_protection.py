from __future__ import annotations

from datetime import timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.database import Base
from app.models import (
    Connector,
    ConnectorKind,
    JobStatus,
    MigrationMethod,
    MigrationMode,
    MigrationRun,
    MigrationStatus,
    RepoMigration,
    RepoMigrationStatus,
    RepositoryInventory,
    TargetFlavor,
    User,
    UserRole,
    ValidationRun,
    Workspace,
    utcnow,
)
from app.services.source_protection import source_freeze_evidence, validate_source_freeze_evidence


def _fixture(*, method: MigrationMethod = MigrationMethod.gei, warning_name: str | None = None):
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    db = Session(engine, expire_on_commit=False)
    user = User(
        username="migration-admin",
        email="migration-admin@example.com",
        password_hash="unused",
        role=UserRole.admin,
    )
    db.add(user)
    db.flush()
    workspace = Workspace(name="Wave", slug="wave", owner_id=user.id)
    db.add(workspace)
    db.flush()
    source = Connector(
        workspace_id=workspace.id,
        name="Source",
        kind=ConnectorKind.ghes,
        target_flavor=TargetFlavor.not_applicable,
        base_url="https://ghes.example.com",
        api_url="https://ghes.example.com/api/v3",
        status="connected",
    )
    target = Connector(
        workspace_id=workspace.id,
        name="Target",
        kind=ConnectorKind.ghec,
        target_flavor=TargetFlavor.github_com,
        base_url="https://github.com",
        api_url="https://api.github.com",
        status="connected",
    )
    db.add_all([source, target])
    db.flush()
    sha = "a" * 40
    repository = RepositoryInventory(
        workspace_id=workspace.id,
        connector_id=source.id,
        source_org="legacy",
        name="payments",
        full_name="legacy/payments",
        target_name="payments",
        visibility="private",
        default_branch="main",
        last_commit_sha=sha,
        detail_json={"deep_scan_complete": True},
    )
    db.add(repository)
    db.flush()
    run = MigrationRun(
        workspace_id=workspace.id,
        created_by_id=user.id,
        source_connector_id=source.id,
        target_connector_id=target.id,
        source_org="legacy",
        target_org="cloud",
        method=method,
        mode=MigrationMode.production,
        status=MigrationStatus.completed,
        lock_source_at_cutover=True,
        acknowledged_manual_actions=True,
    )
    db.add(run)
    db.flush()
    mapping = RepoMigration(
        migration_run_id=run.id,
        repository_inventory_id=repository.id,
        source_repo="payments",
        target_repo="payments",
        status=RepoMigrationStatus.completed,
        source_sha_at_start=sha,
        target_sha_after=sha,
        result_json={"target_repository_id": 991},
    )
    db.add(mapping)
    db.flush()
    checks = [{"name": "default_branch_head_sha", "status": "passed"}]
    if warning_name:
        checks.append({"name": warning_name, "status": "warning"})
    validation = ValidationRun(
        workspace_id=workspace.id,
        migration_run_id=run.id,
        source_connector_id=source.id,
        target_connector_id=target.id,
        source_org="legacy",
        target_org="cloud",
        created_by_id=user.id,
        status=JobStatus.succeeded,
        failed_count=0,
        score=100,
        grade="A",
        report_json={
            "repositories": [
                {
                    "repo": "payments",
                    "target_repo": "payments",
                    "source_sha": sha,
                    "target_sha": sha,
                    "checks": checks,
                }
            ]
        },
        finished_at=utcnow(),
    )
    db.add(validation)
    db.commit()
    return db, workspace, source, repository, run


def test_source_freeze_requires_gei_and_matching_validation_evidence() -> None:
    db, workspace, source, repository, run = _fixture()
    try:
        approved, blockers = source_freeze_evidence(
            db,
            workspace_id=workspace.id,
            source_connector_id=source.id,
            source_org="legacy",
            repository_ids=[repository.id],
        )
        assert blockers == {}
        evidence = approved[repository.id]
        assert evidence["migration_run_id"] == run.id
        assert evidence["validated_source_sha"] == evidence["validated_target_sha"]
        assert evidence["target_repository_id"] == 991
        validate_source_freeze_evidence(
            db,
            workspace_id=workspace.id,
            source_connector_id=source.id,
            source_org="legacy",
            evidence=approved,
        )
    finally:
        db.close()


def test_source_freeze_blocks_critical_validation_warning() -> None:
    db, workspace, source, repository, _ = _fixture(warning_name="git_lfs_objects")
    try:
        approved, blockers = source_freeze_evidence(
            db,
            workspace_id=workspace.id,
            source_connector_id=source.id,
            source_org="legacy",
            repository_ids=[repository.id],
        )
        assert approved == {}
        assert "git_lfs_objects" in blockers[repository.id]
    finally:
        db.close()


def test_source_freeze_directs_elm_to_official_cutover() -> None:
    db, workspace, source, repository, _ = _fixture(method=MigrationMethod.elm)
    try:
        approved, blockers = source_freeze_evidence(
            db,
            workspace_id=workspace.id,
            source_connector_id=source.id,
            source_org="legacy",
            repository_ids=[repository.id],
        )
        assert approved == {}
        assert "official ELM cutover" in blockers[repository.id]
    finally:
        db.close()


def test_latest_elm_evidence_cannot_fall_back_to_older_gei() -> None:
    db, workspace, source, repository, older_gei = _fixture()
    try:
        target = db.get(Connector, older_gei.target_connector_id)
        assert target
        user_id = older_gei.created_by_id
        newer_elm = MigrationRun(
            workspace_id=workspace.id,
            created_by_id=user_id,
            source_connector_id=source.id,
            target_connector_id=target.id,
            source_org="legacy",
            target_org="cloud",
            method=MigrationMethod.elm,
            mode=MigrationMode.production,
            status=MigrationStatus.completed,
            lock_source_at_cutover=True,
            acknowledged_manual_actions=True,
            created_at=older_gei.created_at + timedelta(seconds=1),
        )
        db.add(newer_elm)
        db.flush()
        db.add(
            RepoMigration(
                migration_run_id=newer_elm.id,
                repository_inventory_id=repository.id,
                source_repo="payments",
                target_repo="payments",
                status=RepoMigrationStatus.completed,
                result_json={"target_repository_id": 992},
            )
        )
        db.commit()

        approved, blockers = source_freeze_evidence(
            db,
            workspace_id=workspace.id,
            source_connector_id=source.id,
            source_org="legacy",
            repository_ids=[repository.id],
        )
        assert approved == {}
        assert "official ELM cutover" in blockers[repository.id]
    finally:
        db.close()
