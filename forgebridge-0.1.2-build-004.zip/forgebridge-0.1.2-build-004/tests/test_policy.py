from app.policy import (
    ELM_MAX_CONCURRENT_REPOSITORIES_PER_GHES,
    GEI_MAX_CONCURRENT_REPOSITORIES,
    METHOD_POLICY,
    POLICY_REFERENCE_DATE,
)
from app.services.migration import _elm_version_supported


def test_current_method_policy_is_explicit() -> None:
    assert POLICY_REFERENCE_DATE == "2026-07-14"
    assert GEI_MAX_CONCURRENT_REPOSITORIES == 5
    assert ELM_MAX_CONCURRENT_REPOSITORIES_PER_GHES == 10
    assert METHOD_POLICY["gei"]["delta_supported"] is False
    assert METHOD_POLICY["gei"]["github_documented_service_maximum"] is None
    assert METHOD_POLICY["elm"]["eligible_destination"].endswith("GHE.com")
    assert METHOD_POLICY["elm"]["minimum_patch_releases"] == [
        "3.17.17", "3.18.11", "3.19.8", "3.20.4", "3.21.2"
    ]


def test_elm_patch_floor_gate() -> None:
    for supported, previous in [
        ("3.17.17", "3.17.16"),
        ("3.18.11", "3.18.10"),
        ("3.19.8", "3.19.7"),
        ("3.20.4", "3.20.3"),
        ("3.21.2", "3.21.1"),
    ]:
        assert _elm_version_supported(supported)
        assert not _elm_version_supported(previous)
    assert not _elm_version_supported("3.22.0")  # unknown future train: fail closed
    assert not _elm_version_supported("unknown")
