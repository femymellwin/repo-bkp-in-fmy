from __future__ import annotations

import os
import tempfile
from pathlib import Path

TEST_ROOT = Path(tempfile.mkdtemp(prefix="forgebridge-pytest-"))
os.environ["DATABASE_URL"] = f"sqlite:///{TEST_ROOT / 'forgebridge-test.db'}"
os.environ["REPORTS_DIR"] = str(TEST_ROOT / "reports")
os.environ["LOGS_DIR"] = str(TEST_ROOT / "logs")
os.environ["BRANDING_DIR"] = str(TEST_ROOT / "branding")
os.environ["SECRET_KEY"] = "pytest-secret-key-that-is-longer-than-thirty-two-characters"
os.environ["TOKEN_ENCRYPTION_KEY"] = "Kp4TAd9EVXngsUcp1fRbVr8OzK76HTAvrfW0gHUcDpA="
os.environ["DEMO_MODE"] = "true"
os.environ["TASK_MODE"] = "local"
os.environ["AUTO_CREATE_TABLES"] = "true"
os.environ["ENABLE_REAL_MIGRATIONS"] = "false"
os.environ["ENABLE_DESTRUCTIVE_PURGE"] = "false"
