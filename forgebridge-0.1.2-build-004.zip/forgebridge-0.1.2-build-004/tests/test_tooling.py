from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.services import migration


def _settings(**overrides):
    values = {
        "gei_binary": "gei",
    }
    values.update(overrides)
    return SimpleNamespace(**values)


def test_gei_tooling_status_detects_packaged_standalone_binary(monkeypatch) -> None:
    monkeypatch.setattr(migration, "get_settings", lambda: _settings())
    monkeypatch.setattr(migration.shutil, "which", lambda _: "/usr/local/bin/gei")
    calls = []

    def fake_output(command, **kwargs):
        calls.append((command, kwargs.get("env", {})))
        if command == ["gei", "--version"]:
            return 0, "1.30.3"
        if command == ["gei", "migrate-repo", "--help"]:
            return 0, "Usage: gei migrate-repo"
        raise AssertionError(command)

    monkeypatch.setattr(migration, "_tool_output", fake_output)
    result = migration.gei_tooling_status(target_token="not-logged")
    assert result["ready"] is True
    assert result["mode"] == "standalone"
    assert calls[0][1]["GEI_SKIP_VERSION_CHECK"] == "true"
    assert all("not-logged" not in " ".join(command) for command, _ in calls)


def test_gei_command_prefix_refuses_floating_gh_extension(monkeypatch) -> None:
    monkeypatch.setattr(migration, "get_settings", lambda: _settings(gei_binary="gh"))
    with pytest.raises(RuntimeError, match="standalone gei"):
        migration.gei_command_prefix()


def test_gei_tooling_status_refuses_gh_extension_mode(monkeypatch) -> None:
    monkeypatch.setattr(migration, "get_settings", lambda: _settings(gei_binary="gh"))
    monkeypatch.setattr(migration.shutil, "which", lambda _: "/usr/local/bin/gh")
    result = migration.gei_tooling_status()
    assert result["ready"] is False
    assert "extension mode is disabled" in result["error"].lower()


def test_gei_tooling_status_fails_when_packaged_binary_is_missing(monkeypatch) -> None:
    monkeypatch.setattr(migration, "get_settings", lambda: _settings())
    monkeypatch.setattr(migration.shutil, "which", lambda _: None)
    result = migration.gei_tooling_status()
    assert result["ready"] is False
    assert "not installed" in result["error"].lower()
