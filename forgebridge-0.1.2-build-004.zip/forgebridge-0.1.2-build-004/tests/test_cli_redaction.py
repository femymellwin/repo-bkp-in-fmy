from app.services.migration import _cli_redaction_values, redact_cli_output


def test_cli_output_redacts_environment_secrets_and_github_tokens() -> None:
    source_pat = "gh" + "p_sourceSecret123"
    target_pat = "github_" + "pat_targetSecret456"
    env = {
        "GH_SOURCE_PAT": source_pat,
        "GH_PAT": target_pat,
        "NORMAL_VALUE": "keep-me",
        "SHORT_TOKEN": "tiny",
    }
    values = _cli_redaction_values(env)
    output = (
        f"source={source_pat} target={target_pat} "
        "Authorization: Bearer bearer-secret unrelated=keep-me"
    )
    cleaned = redact_cli_output(output, values)
    assert "sourceSecret123" not in cleaned
    assert "targetSecret456" not in cleaned
    assert "bearer-secret" not in cleaned
    assert "keep-me" in cleaned
    assert cleaned.count("***REDACTED***") >= 3
