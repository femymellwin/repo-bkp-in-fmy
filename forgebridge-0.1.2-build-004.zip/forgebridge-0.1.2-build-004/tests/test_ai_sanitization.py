from app.services.ai import sanitize_evidence, sanitize_text


def test_ai_evidence_redacts_nested_sensitive_fields_and_tokens() -> None:
    evidence = {
        "result": {
            "token": "github_" + "pat_thismustnotleave",
            "nested": [{"api_key": "top-secret", "message": "Authorization: Bearer abc123"}],
            "safe": "migration completed",
        },
        "encrypted_token": "ciphertext",
    }
    cleaned = sanitize_evidence(evidence)
    assert cleaned["result"]["token"] == "***REDACTED***"
    assert cleaned["result"]["nested"][0]["api_key"] == "***REDACTED***"
    assert "abc123" not in cleaned["result"]["nested"][0]["message"]
    assert cleaned["encrypted_token"] == "***REDACTED***"
    assert cleaned["result"]["safe"] == "migration completed"


def test_ai_text_sanitization_is_bounded() -> None:
    value = "token=secret-value " + ("x" * 100)
    cleaned = sanitize_text(value, 20)
    assert len(cleaned) <= 20
    assert "secret-value" not in cleaned
