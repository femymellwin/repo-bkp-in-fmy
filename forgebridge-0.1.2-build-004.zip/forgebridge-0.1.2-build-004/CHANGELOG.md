# Changelog

## 0.1.2 — Build FB-0.1.2-004 — 2026-07-14

### One-script installation and operations

- Added one operator-facing entrypoint: `forgebridge.sh`.
- Added a self-extracting single-file installer distribution that extracts Build 004 and invokes the same verified entrypoint.
- Added a complete `install` command that verifies the release, imports or creates protected configuration, performs a no-cache image build, verifies runtime tooling, runs Alembic, applies seed data, starts PostgreSQL/Redis/web/worker services, and confirms health on port 3002.
- Added clear fresh-install and configuration-preserving upgrade modes.
- Added install receipt, version, doctor, health, tooling, logs, backup, upgrade, uninstall, and recovery-oriented management commands.
- Removed every other shell script from the application package.

### Sealed GitHub-supported-only method policy

- Added `MIGRATION_POLICY_MODE=github-supported-only` and deterministic startup/preflight enforcement.
- Restricted GEI execution to the checksum-pinned official standalone `gei` executable.
- Disabled GitHub CLI extension mode and any runtime extension installation.
- Rejected custom mirror-push migration, `ghe-migrator`, custom metadata copying, and fabricated GEI delta behavior.
- Kept ELM disabled by default; it can be enabled only for an eligible GHE.com data-residency migration after the required GitHub preparation and approval.

### Release-integrity and stale-build protection

- Added `BUILD-INFO.env` and a complete `RELEASE-SHA256SUMS` manifest.
- The installer validates every packaged file before reading production configuration or invoking Docker.
- The installer refuses old `python:3.12-slim`/pip/PyPI Docker contracts and instructs the operator to use the uniquely named Build 004 directory.
- Added OCI build labels and runtime image-revision verification.

### Production dependency correction

- Retained the Debian Trixie, pip-free/PyPI-free application image.
- Retained architecture-native ARM64/AMD64 dependencies from signed Debian repositories.
- Retained GitHub Enterprise Importer v1.30.3 with GitHub-published SHA-256 verification.
- Removed the global customer-CA installation workflow. Standard HTTPS certificate validation remains enabled.

## 0.1.2 — Build FB-0.1.2-003 — 2026-07-13

### PyPI-free production packaging

- Removed every production `pip install` and `pip --upgrade` operation.
- Removed all production Docker access to PyPI.
- Changed the application image from `python:3.12-slim` to `debian:trixie-slim`.
- Installed the Python runtime and application modules through Debian's signed, architecture-native packages.
- Added `runtime-packages.txt` as the production dependency inventory.
- Added an image-build import test that fails immediately when a required runtime module is unavailable.

### Official GEI standalone runtime

- Replaced startup-time `gh-gei` extension installation with GitHub's official standalone `gei` executable.
- Pinned GEI to `v1.30.3`.
- Added automatic `linux/amd64` and `linux/arm64` asset selection.
- Added SHA-256 verification using the checksums published with the GitHub release.
- Added `vendor/gei/GEI.lock` and a checksum-verified non-container installer.
- Preserved explicit compatibility with externally managed legacy `gh gei` workers, while production defaults to `gei`.

### Startup and TLS correction

- Removed the mandatory/global custom-CA workflow and all `ca-*` management commands.
- Retained normal system TLS certificate verification.
- Added `build`, `clean-build`, and `tooling` commands to the single production script.
- Added detection for accidentally running an older cached Dockerfile.
- Preserved port 3002 and the existing production topology.
- Automatically advances only default Build 001/002 branding to Build 003; custom build numbers remain unchanged.

### Azure OpenAI dependency simplification

- Removed the Azure Identity SDK from the production dependency set.
- Added managed-identity token acquisition through Azure's documented environment/IMDS endpoints using the existing HTTP client.
- Preserved encrypted API-key configuration and advisory-only AI boundaries.

### Verification

- Expanded source regression coverage to 40 automated tests.
- Added tests for PyPI-free packaging, Debian dependencies, architecture-specific GEI checksums, removal of global CA commands, build-number upgrade behavior, and Azure managed identity token acquisition.

## 0.1.2 — Build FB-0.1.2-002 — 2026-07-12

Interim certificate-import workaround for the PyPI-dependent image. Superseded by Build 003.

## 0.1.2 — Build FB-0.1.2-001 — 2026-07-12

Introduced the Syncline-style menu shell, branding/favicon controls, port 3002, and the single production management script.

## 0.1.1 — 2026-07-12

Expanded the GHES-to-GHEC control plane with discovery grades, pipeline lanes, owner handoff, migration planning, validation, purge, source read-only, AI configuration, and administration.

## 0.1.0 — 2026-07-12

Initial reference build.
