# Learning Workspace — School Edition

Learning Workspace is a private, rebrandable teacher assistant for local Ollama models. It is designed around school books and syllabus work rather than timetable, attendance, fee, or student-information-system functions.

Version: **2.0.0**

## What this edition adds

- A corrected first-run login flow with **one password field**.
- Users, password hashes, sessions, branding, workspaces, and document indexes stored in a local **SQLite database**.
- Automatic migration of the previous build's `data/users.json` account file when present.
- A generic default identity and an administrator **Branding page** with school, technology, and professional themes.
- Separate teacher accounts and private teaching workspaces.
- A book library for PDF, Word, PowerPoint, Excel, EPUB, ODT, HTML, text, and image files.
- Optional OCR for scanned PDFs and images.
- Book-grounded chat with page/section citations.
- Textbook and curriculum comparison.
- Teacher Studio workflows for lesson plans, question papers, answer keys, rubrics, worksheets, answer-paper review, and grade-to-grade comparison.
- An optional **Full-book pass** that sends every extracted document chunk through the selected local model before final synthesis.
- Optional web search with DuckDuckGo, SearXNG, Brave Search, Serper, Tavily, Google Custom Search, or Ollama web search.
- Seven CPU-oriented local-model recommendations, license labels, and one-click Ollama pulls from the administrator page.
- Cross-platform startup, password-recovery, backup, and operational scripts.

## Quick start

### macOS or Linux

```bash
unzip learning-workspace-school-edition-v2.0.0.zip
cd learning-workspace-school-edition
chmod +x *.sh maintenance.py
./install.sh
./start-background.sh
```

Open `http://127.0.0.1:8787`.

### Windows PowerShell

```powershell
Expand-Archive .\learning-workspace-school-edition-v2.0.0.zip
cd .\learning-workspace-school-edition
powershell -ExecutionPolicy Bypass -File .\install-windows.ps1
powershell -ExecutionPolicy Bypass -File .\start-windows-background.ps1
```

Open `http://127.0.0.1:8787`.

There are no built-in credentials. The first browser visit creates the administrator account. The setup form asks for the password once; the server immediately converts it to a salted `scrypt` hash in SQLite and creates a persistent server-side session.

## Recommended first model

For an ordinary CPU-only school computer, start with:

```bash
ollama pull qwen3:1.7b
```

Use `qwen3:0.6b` only for ultra-light query rewriting or rough drafts, `gemma3:1b` on very limited hardware, `llama3.2:3b` as a general alternative, and `qwen3:4b` on a 16 GB-or-better machine when textbook comparison and assessment quality matter more than speed. These are practical starting points, not guaranteed RAM limits; actual speed and memory depend on CPU, operating system, quantization, context length, and concurrent users.

Local Ollama models do not incur a per-token API charge. Hardware, electricity, internet access, optional search APIs, and each model's license still require review.

## Documentation

- `INSTALL.md` — complete installation and upgrade instructions.
- `SCHOOL-WORKFLOWS.md` — teacher workflows and full-book processing.
- `SEARCH-PROVIDERS.md` — provider selection and `.env` examples.
- `RUNBOOK.md` — daily operation, accounts, backups, and troubleshooting.
- `SECURITY.md` — controls, deployment boundaries, and student-data guidance.
- `CHANGELOG.md` — changes from the previous build.
- `BUILD-INFO.md` — validation and release contents.

## Deliberate scope

This release focuses on teacher work with syllabus and learning content. It does **not** implement timetable, attendance, payroll, fee collection, admissions, parent communication, student records, or final-grade publishing. Suggested marks are advisory and must be reviewed and approved by a teacher.

## Important accuracy boundary

“Full-book pass” means every successfully extracted and indexed chunk is processed. It cannot recover content that the source parser or OCR did not read. Scanned pages, handwriting, equations, diagrams, unusual fonts, and complex multi-column layouts require human verification. Keep the original books and answer papers available during review.
