#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

stop_pid_file() {
  local file="$1" label="$2"
  if [ ! -f "$file" ]; then return; fi
  local pid
  pid="$(cat "$file" 2>/dev/null || true)"
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
    for _ in $(seq 1 20); do
      kill -0 "$pid" 2>/dev/null || break
      sleep 0.2
    done
    if kill -0 "$pid" 2>/dev/null; then kill -9 "$pid" 2>/dev/null || true; fi
    echo "$label stopped."
  fi
  rm -f "$file"
}

stop_pid_file run/app.pid "Learning Workspace"
# Stop Ollama only when this application started that process.
stop_pid_file run/ollama.pid "Ollama"
