param(
    [string]$Output = ""
)
$ErrorActionPreference = "Stop"
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppDir
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    & (Join-Path $AppDir "install-windows.ps1")
}
$Python = Join-Path $AppDir ".venv\Scripts\python.exe"
if ($Output) {
    & $Python maintenance.py backup --output $Output
} else {
    & $Python maintenance.py backup
}
exit $LASTEXITCODE
