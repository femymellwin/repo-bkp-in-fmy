# Operations Runbook

## Start and stop

### macOS/Linux

```bash
./start-background.sh
./stop-background.sh
```

Foreground troubleshooting:

```bash
./start-foreground.sh
```

### Windows

```powershell
powershell -ExecutionPolicy Bypass -File .\start-windows-background.ps1
powershell -ExecutionPolicy Bypass -File .\stop-windows.ps1
```

Foreground troubleshooting:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-windows.ps1
```

Default URL: `http://127.0.0.1:8787`

Health endpoint: `http://127.0.0.1:8787/healthz`

## Runtime locations

- Database: `data/learning-workspace.db`
- SQLite WAL files while running: `data/learning-workspace.db-wal` and `-shm`
- Uploaded source files: `data/uploads/`
- Application log: `logs/app.log`
- Windows error log: `logs/app-error.log`
- Ollama log when started by the launcher: `logs/ollama.log`
- PID files: `run/`

Do not edit the SQLite database directly while the application is running.

## Account administration

Browser administration is under **School Admin → Teacher accounts**.

Terminal commands are available for recovery:

```bash
.venv/bin/python server.py --list-users
.venv/bin/python server.py --create-admin another-admin
.venv/bin/python server.py --create-teacher teacher.name
.venv/bin/python server.py --reset-password teacher.name
```

The command-line create/reset operations ask for password confirmation. The first-run browser setup and normal browser login use one password field.

## Branding

The administrator can change:

- application name;
- school/organization name;
- up to four logo letters;
- tagline;
- login and welcome messages;
- school, tech, or professional theme;
- primary and accent colors.

Branding is stored in SQLite and applies to the login page and application shell.

## Install or update a model

From a terminal:

```bash
ollama list
ollama pull qwen3:0.6b
ollama pull qwen3:1.7b
ollama pull llama3.2:3b
ollama pull qwen3:4b
```

The School Admin model cards can also start a pull. Model files are managed by Ollama and are not stored in this application's directory.

## Backup

Create a backup ZIP:

```bash
./backup.sh
```

or on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\backup-windows.ps1
```

The archive contains a consistent SQLite backup, uploaded files, a content manifest, and backup metadata. It excludes `.env`, logs, and runtime files.

Store the archive in an access-controlled, encrypted location. Do not email an unencrypted backup that contains student or school material.

## Restore

1. Stop Learning Workspace.
2. Extract the backup ZIP in a temporary location.
3. Make a safety copy of the existing `data` directory.
4. Replace `data/learning-workspace.db` with the backed-up database.
5. Replace `data/uploads` with the backed-up uploads directory.
6. Ensure the application account can read and write the files.
7. Start the application and verify login, workspaces, and documents.

The backup deliberately omits `.env`; restore search keys and network settings from the school's separate secrets backup.

## Update the application

1. Stop the old release.
2. Run a backup.
3. Extract the new release into a new directory.
4. Copy `.env`, `data/`, and any operational proxy configuration into the new directory.
5. Run the new installer to update Python dependencies.
6. Start in the foreground and inspect logs.
7. Confirm login, branding, model connectivity, document access, and web-search readiness.
8. Switch production traffic only after the checks pass.

## Common problems

### The setup page reappears after account creation

- Confirm the application can write to `data/`.
- Check `logs/app.log` or the foreground console.
- Confirm browser cookies are enabled for the application URL.
- Do not alternate between `localhost`, `127.0.0.1`, a LAN IP, and a proxy hostname during the same login test; cookies are scoped to the host.
- Confirm the database file exists and is not being deleted by a cleanup script.

The current browser setup page uses one password field and the session is stored server-side in SQLite.

### Ollama shows offline

```bash
ollama list
ollama serve
```

Verify `.env` contains the correct endpoint:

```dotenv
OLLAMA_BASE_URL=http://127.0.0.1:11434
```

### A model is slow on CPU

- Choose `qwen3:0.6b` for query rewriting only, or `gemma3:1b` / `qwen3:1.7b` for normal teacher work.
- Select fewer books.
- Use standard evidence mode instead of Full-book pass.
- Close other memory-intensive applications.
- Avoid simultaneous large jobs from several teachers on one small computer.
- Use a shorter answer request and split a large curriculum task by subject or unit.

### A PDF has very little text

- Install Tesseract.
- Confirm `ENABLE_OCR=true`.
- Install the required OCR language packs.
- Re-upload the file after restarting.
- Inspect whether the book uses handwriting, diagrams, unusual fonts, or protected/encrypted pages.

### Search is disabled in the interface

Open School Admin and inspect the provider status. Check the corresponding `.env` variables, restart, and review the log. DuckDuckGo is ready without a key; other providers require a URL or API key.

### Search results contain weak sources

- Use an allowlist for official or curriculum-approved domains.
- Increase result quality by switching provider.
- Keep `WEB_SEARCH_SAFE=true`.
- Ask focused questions with grade, subject, jurisdiction, date, and desired source type.
- Verify citations manually before classroom use.

### A suggested mark is wrong

Treat the output as an advisory review. Check OCR, question numbering, answer-key alignment, partial-credit rules, arithmetic, and the student's original work. The teacher must approve the final mark.
