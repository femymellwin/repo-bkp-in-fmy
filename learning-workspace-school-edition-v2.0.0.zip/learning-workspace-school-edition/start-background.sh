#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ ! -x .venv/bin/python ]; then
  "$APP_DIR/install.sh"
fi
mkdir -p data logs run
PY="$APP_DIR/.venv/bin/python"

read_env_value() {
  local key="$1"
  if [ -f .env ]; then
    local line
    line="$(grep -E "^[[:space:]]*${key}=" .env | tail -n 1 || true)"
    if [ -n "$line" ]; then
      line="${line#*=}"
      line="${line%\"}"; line="${line#\"}"
      line="${line%\'}"; line="${line#\'}"
      printf '%s' "$line"
      return
    fi
  fi
}

HOST_VALUE="${HOST:-$(read_env_value HOST)}"
PORT_VALUE="${PORT:-$(read_env_value PORT)}"
OLLAMA_URL="${OLLAMA_BASE_URL:-$(read_env_value OLLAMA_BASE_URL)}"
HOST_VALUE="${HOST_VALUE:-127.0.0.1}"
PORT_VALUE="${PORT_VALUE:-8787}"
OLLAMA_URL="${OLLAMA_URL:-http://127.0.0.1:11434}"

if [ -f run/app.pid ] && kill -0 "$(cat run/app.pid)" 2>/dev/null; then
  echo "Learning Workspace is already running with PID $(cat run/app.pid)."
  exit 0
fi

if ! "$PY" - "$OLLAMA_URL" <<'PY' >/dev/null 2>&1
import sys, urllib.request
urllib.request.urlopen(sys.argv[1].rstrip('/') + '/api/tags', timeout=2).read(1)
PY
then
  if command -v ollama >/dev/null 2>&1 && [[ "$OLLAMA_URL" == http://127.0.0.1:* || "$OLLAMA_URL" == http://localhost:* ]]; then
    nohup ollama serve >>logs/ollama.log 2>&1 &
    echo $! >run/ollama.pid
    sleep 2
  else
    echo "Warning: Ollama is not reachable at $OLLAMA_URL." >&2
  fi
fi

nohup "$PY" server.py >>logs/app.log 2>&1 &
APP_PID=$!
echo "$APP_PID" >run/app.pid

healthy=0
for _ in $(seq 1 30); do
  if "$PY" - "$HOST_VALUE" "$PORT_VALUE" <<'PY' >/dev/null 2>&1
import sys, urllib.request
host = sys.argv[1]
if host in ('0.0.0.0', '::'): host = '127.0.0.1'
urllib.request.urlopen(f'http://{host}:{sys.argv[2]}/healthz', timeout=1).read()
PY
  then
    healthy=1
    break
  fi
  if ! kill -0 "$APP_PID" 2>/dev/null; then
    break
  fi
  sleep 1
done

if [ "$healthy" -ne 1 ]; then
  echo "The application did not start successfully. Review logs/app.log." >&2
  tail -n 40 logs/app.log >&2 || true
  exit 1
fi

OPEN_HOST="$HOST_VALUE"
if [ "$OPEN_HOST" = "0.0.0.0" ] || [ "$OPEN_HOST" = "::" ]; then OPEN_HOST="127.0.0.1"; fi
echo "Learning Workspace started with PID $APP_PID"
echo "Open http://$OPEN_HOST:$PORT_VALUE"
echo "Logs: $APP_DIR/logs/app.log"
