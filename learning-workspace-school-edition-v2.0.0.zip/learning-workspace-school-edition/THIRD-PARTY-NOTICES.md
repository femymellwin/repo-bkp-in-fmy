# Third-Party and Licensing Notes

This application installs Python packages listed in `requirements.txt` and connects to separately installed Ollama models and optional search services. Each dependency, model, and service has its own license and terms.

Before redistributing or deploying the complete system, review at least:

- the license of the original user-supplied interface on which this build is based;
- Python and each Python package's license;
- Ollama's license and deployment terms;
- the license card for every model pulled into Ollama;
- copyright and permitted use of uploaded school books, question papers, and answer material;
- the contract, privacy terms, and usage restrictions of the selected web-search provider;
- local requirements for processing student and employee data.

“No per-token model charge” describes local inference economics; it is not a statement that every model is unrestricted for every commercial, educational, or redistribution use.

The built-in recommendation labels identify the current model-license family for convenience: Qwen3 uses Apache 2.0, Phi-4-mini uses MIT, Llama 3.2 uses the Llama 3.2 Community License, and Gemma 3 uses the Gemma Terms. These labels are not legal advice and do not replace the complete license text supplied with the model.

No third-party model weights or proprietary search credentials are included in this archive.
