# Security and Privacy Notes

## Implemented controls

- No built-in username or password.
- First administrator created only when the user database is empty.
- Passwords stored as salted `scrypt` hashes.
- Maximum and minimum password-length checks.
- Login attempt throttling.
- Random server-side sessions stored in SQLite.
- Only a SHA-256 hash of the session token is stored in the database.
- `HttpOnly`, `SameSite=Strict` cookies; optional `Secure` flag for HTTPS.
- CSRF token checks on state-changing authenticated requests.
- same-origin validation.
- Content Security Policy and defensive response headers.
- Role checks for administrator functions.
- Teacher-level ownership checks for workspaces, files, search, and comparisons.
- Search API keys held in server environment configuration and not returned to the browser.
- Ollama proxied through authenticated same-origin endpoints.
- Web-page fetch protection against private, loopback, link-local, multicast, and otherwise unsafe destination addresses.
- Redirect, response-size, timeout, and content-type controls for page extraction.
- Uploaded filenames normalized and stored under generated document identifiers.
- Database and data-directory permissions tightened where supported.
- Audit records for important authentication, user, document, and search actions.

## Deployment boundaries

The built-in server is suitable for a trusted local computer or as an application backend behind an HTTPS reverse proxy. It is not intended to be exposed directly to the public internet.

For a school LAN deployment:

- terminate HTTPS at a maintained reverse proxy;
- set `COOKIE_SECURE=true`;
- restrict firewall access to the school network or VPN;
- keep the operating system, Python, dependencies, Ollama, proxy, and models patched;
- protect `.env`, the data directory, and backup files;
- use unique named accounts;
- disable departed users promptly;
- review logs and backups;
- apply the school's retention and incident-response policy.

## Student and staff data

Uploaded answer papers and school books can contain personal data, copyrighted material, examination content, accommodations, or safeguarding information.

- Upload only material the school is authorized to process.
- Remove unnecessary student names and identifiers.
- Do not configure external web search to send student-identifying prompts.
- Keep the Web switch off for confidential tasks.
- Store backups securely and delete them according to policy.
- Delete workspaces and documents when retention is no longer justified.
- Review local law, school policy, contractual requirements, and model licenses before deployment.

Local Ollama inference keeps the model request on the configured Ollama endpoint. A remote Ollama endpoint, external search provider, or fetched web page changes the data-flow boundary.

## Limitations

This release does not provide:

- multi-factor authentication;
- SAML, OIDC, LDAP, or Active Directory integration;
- password-expiry policy;
- centralized secrets management;
- tamper-evident or externally shipped audit logs;
- disk encryption;
- malware scanning of uploads;
- content-disarm and reconstruction;
- high-availability clustering;
- legal-records retention automation;
- enterprise data-loss prevention;
- a parent or student portal.

Use compensating controls appropriate to the deployment. Whole-disk encryption, endpoint protection, secure backups, HTTPS, VPN access, and restricted operating-system accounts are strongly recommended.

## Model and content safety

Model output can be incorrect, biased, age-inappropriate, or inconsistent. Search results can contain misinformation or prompt-injection text. The server labels external evidence as untrusted, but no prompt can guarantee perfect model behavior.

Teachers must verify source citations, answer keys, mark totals, factual claims, translations, and final grades. Do not use this release as the sole decision-maker for high-impact student outcomes.
