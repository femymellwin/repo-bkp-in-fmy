#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ ! -x .venv/bin/python ]; then
  "$APP_DIR/install.sh"
fi
mkdir -p data logs run

PY="$APP_DIR/.venv/bin/python"
OLLAMA_URL="${OLLAMA_BASE_URL:-http://127.0.0.1:11434}"

if ! "$PY" - "$OLLAMA_URL" <<'PY' >/dev/null 2>&1
import sys, urllib.request
urllib.request.urlopen(sys.argv[1].rstrip('/') + '/api/tags', timeout=2).read(1)
PY
then
  if command -v ollama >/dev/null 2>&1 && [[ "$OLLAMA_URL" == http://127.0.0.1:* || "$OLLAMA_URL" == http://localhost:* ]]; then
    echo "Starting local Ollama service..."
    nohup ollama serve >>"$APP_DIR/logs/ollama.log" 2>&1 &
    echo $! >"$APP_DIR/run/ollama.pid"
    sleep 2
  else
    echo "Warning: Ollama is not reachable at $OLLAMA_URL. The interface will start, but a model is required for generation." >&2
  fi
fi

exec "$PY" server.py "$@"
