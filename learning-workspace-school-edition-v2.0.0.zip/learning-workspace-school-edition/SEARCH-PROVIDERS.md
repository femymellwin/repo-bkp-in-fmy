# Web Search Providers

Learning Workspace keeps web search optional at two levels:

- `ENABLE_WEB_SEARCH` controls whether the feature exists for the server.
- The teacher's **Web** switch controls whether a particular request searches the internet.

The selected provider is configured in `.env`. Restart the application after changing provider settings.

## Shared behavior

```dotenv
ENABLE_WEB_SEARCH=true
WEB_SEARCH_RESULT_COUNT=6
WEB_SEARCH_QUERY_MODE=model
WEB_SEARCH_TIMEOUT=18
WEB_SEARCH_SAFE=true
WEB_SEARCH_FETCH_PAGES=true
WEB_SEARCH_FETCH_COUNT=3
WEB_SEARCH_PAGE_MAX_CHARS=9000
WEB_SEARCH_DOMAIN_DENYLIST=pinterest.com,facebook.com,instagram.com,tiktok.com
```

`WEB_SEARCH_QUERY_MODE=model` asks the selected local Ollama model to generate a small set of focused search queries. Use `direct` to search only the teacher's original wording.

When `WEB_SEARCH_FETCH_PAGES=true`, the server fetches a limited number of result pages, extracts readable text, and adds it to the result snippet. It blocks local/private network destinations, strips tracking parameters, limits redirects and payload sizes, and treats page content as untrusted. Some sites block automated access or require JavaScript, so extraction is not guaranteed.

## Recommended provider choices

### Serper — Google-backed results

Use when Google-style result coverage is the main requirement and a modest API expense is acceptable.

```dotenv
WEB_SEARCH_PROVIDER=serper
SERPER_API_KEY=replace-with-your-key
```

The provider's pricing and quota can change; confirm the current plan before school-wide rollout.

### Tavily — extracted content for RAG

Use when the priority is answer-oriented results and extracted page content rather than only links.

```dotenv
WEB_SEARCH_PROVIDER=tavily
TAVILY_API_KEY=replace-with-your-key
```

Tavily can supply its own extracted content. Learning Workspace can still perform bounded page extraction where useful.

### Brave Search — independent index

Use when an independent search index and an official API are preferred.

```dotenv
WEB_SEARCH_PROVIDER=brave
BRAVE_SEARCH_API_KEY=replace-with-your-key
```

Review Brave's current quota and pricing before deployment.

### SearXNG — self-hosted metasearch

Use when the school can operate a SearXNG instance and wants to avoid a direct commercial search API contract.

```dotenv
WEB_SEARCH_PROVIDER=searxng
SEARXNG_URL=http://127.0.0.1:8080/search
```

The SearXNG instance must enable JSON output. The quality and legality of upstream engines depend on the instance configuration and local policy.

### DuckDuckGo — no-key fallback

```dotenv
WEB_SEARCH_PROVIDER=duckduckgo
```

This provider uses DuckDuckGo's HTML results and does not require a key. It is suitable as a simple fallback, but HTML markup and anti-automation behavior can change without an API compatibility guarantee.

### Google Custom Search JSON API

```dotenv
WEB_SEARCH_PROVIDER=google_cse
GOOGLE_SEARCH_API_KEY=replace-with-your-key
GOOGLE_SEARCH_ENGINE_ID=replace-with-your-engine-id
```

Use only when the organization already has compatible Google Custom Search access. Google has restricted new access and announced transition requirements for existing customers. Do not choose this as the default path for a new school deployment without confirming current availability.

### Ollama web search

```dotenv
WEB_SEARCH_PROVIDER=ollama_cloud
OLLAMA_WEB_SEARCH_API_KEY=replace-with-your-key
OLLAMA_WEB_SEARCH_URL=https://ollama.com
```

This is separate from local Ollama inference and requires the provider's web-search key and network access.

## Domain controls

Allow only selected domains:

```dotenv
WEB_SEARCH_DOMAIN_ALLOWLIST=education.gov.example,who.int,nasa.gov
```

Block selected domains:

```dotenv
WEB_SEARCH_DOMAIN_DENYLIST=pinterest.com,facebook.com,instagram.com,tiktok.com
```

An allowlist takes precedence by excluding all domains not listed. Domain controls apply to result URLs and page-fetching.

## Practical school default

A sensible progression is:

1. Begin with DuckDuckGo during evaluation.
2. Use SearXNG when the school has technical capacity to maintain it.
3. Use Serper when Google-backed coverage is required.
4. Use Tavily when extracted RAG content is more valuable than conventional result presentation.
5. Use Brave when an independent official index is preferred.

Whichever provider is selected, teach users to open and inspect cited pages. Search ranking is not a statement of accuracy or suitability for learners.
