# Build Information

Product: Learning Workspace — School Edition  
Version: 2.0.0  
Build date: 2026-07-18  
Runtime: Python 3.10+ and a modern browser  
Local model service: Ollama

## Release contents

- `server.py` — authenticated application server, Ollama proxy, and search providers.
- `storage.py` — SQLite accounts, sessions, settings, workspaces, documents, FTS index, and audit records.
- `document_pipeline.py` — extraction, OCR, chunking, and deterministic comparison.
- `index.html` and `app.js` — responsive teacher and administrator interface.
- `maintenance.py` — SQLite-aware backup utility.
- `requirements.txt` — Python dependencies.
- `.env.example` — documented runtime configuration.
- Cross-platform install, start, stop, and backup scripts.
- Seven CPU-model recommendations with one-click Ollama pulls and visible license-family labels.
- Tests and operational documentation.

## Validation performed

- Python bytecode compilation.
- JavaScript syntax validation.
- POSIX shell syntax validation.
- HTML parsing and DOM-ID reference checks.
- Unit and integration tests for:
  - one-field browser administrator setup;
  - absence of plaintext passwords and raw session tokens in SQLite;
  - session persistence across a server restart;
  - CSRF enforcement;
  - branding and teacher administration;
  - document upload, extraction, indexing, search, segment pagination, and comparison;
  - mocked SearXNG and Ollama requests;
  - legacy JSON-account migration;
  - TXT, HTML, DOCX, PPTX, XLSX, and EPUB extraction.
- Headless Chromium checks for login-page rendering and authenticated application bootstrap using intercepted mock API responses; server-side persistence is covered separately by integration tests.
- Release manifest, ZIP integrity, clean extraction, and test execution from the extracted archive.

## Test-environment boundary

External search providers and live Ollama downloads are network-dependent and are not embedded in the archive. Automated tests use local mock endpoints so provider request/response handling can be verified without sending school data to an external service.

The release includes no model weights, API keys, default passwords, populated database, uploaded school books, or student records.
