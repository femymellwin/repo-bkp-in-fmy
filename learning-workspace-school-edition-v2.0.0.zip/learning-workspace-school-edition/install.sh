#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

find_python() {
  if [ -n "${PYTHON_BIN:-}" ] && command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    printf '%s\n' "$PYTHON_BIN"
    return
  fi
  for candidate in python3.13 python3.12 python3.11 python3.10 python3 python; do
    if command -v "$candidate" >/dev/null 2>&1; then
      printf '%s\n' "$candidate"
      return
    fi
  done
  return 1
}

PYTHON="$(find_python || true)"
if [ -z "$PYTHON" ]; then
  echo "Python 3.10 or newer is required." >&2
  exit 1
fi

"$PYTHON" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10 or newer is required.")
print(f"Using Python {sys.version.split()[0]}")
PY

if [ ! -d .venv ]; then
  "$PYTHON" -m venv .venv
fi

VENV_PY="$APP_DIR/.venv/bin/python"
"$VENV_PY" -m pip install --upgrade pip setuptools wheel
"$VENV_PY" -m pip install -r requirements.txt

mkdir -p data logs run
chmod 700 data logs run 2>/dev/null || true

if command -v tesseract >/dev/null 2>&1; then
  echo "Tesseract OCR detected: $(tesseract --version 2>/dev/null | head -n 1)"
else
  echo "Optional: install Tesseract OCR to read scanned PDFs and images. Text-based files work without it."
fi

if command -v ollama >/dev/null 2>&1; then
  echo "Ollama detected: $(command -v ollama)"
else
  echo "Ollama is not installed or not on PATH. Install it from the official Ollama distribution before running local models."
fi

echo "Installation complete. Start with ./start-foreground.sh or ./start-background.sh"
