#!/usr/bin/env python3
"""Offline maintenance utilities for Learning Workspace.

The backup command uses SQLite's online backup API and copies uploaded source
files. It deliberately excludes .env, logs, session cookies, and runtime files.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent


def load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def backup(output_dir: Path) -> Path:
    load_dotenv(APP_DIR / ".env")
    data_dir = Path(os.getenv("APP_DATA_DIR", os.getenv("AEGIS_DATA_DIR", str(APP_DIR / "data")))).expanduser().resolve()
    database = Path(os.getenv("DATABASE_PATH", str(data_dir / "learning-workspace.db"))).expanduser().resolve()
    uploads = Path(os.getenv("UPLOAD_DIR", str(data_dir / "uploads"))).expanduser().resolve()
    if not database.exists():
        raise RuntimeError(f"Database not found: {database}")

    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%SZ")
    archive_base = output_dir / f"learning-workspace-backup-{stamp}"

    with tempfile.TemporaryDirectory(prefix="learning-workspace-backup-") as temp_name:
        stage = Path(temp_name) / "learning-workspace-backup"
        stage.mkdir(parents=True)
        copied_db = stage / "learning-workspace.db"
        source = sqlite3.connect(database, timeout=30)
        destination = sqlite3.connect(copied_db)
        try:
            source.backup(destination)
        finally:
            destination.close()
            source.close()

        copied_uploads = stage / "uploads"
        if uploads.exists():
            shutil.copytree(uploads, copied_uploads, dirs_exist_ok=True)
        else:
            copied_uploads.mkdir()

        version_path = APP_DIR / "VERSION"
        version = version_path.read_text(encoding="utf-8").strip() if version_path.exists() else "unknown"
        info = {
            "application": "Learning Workspace",
            "version": version,
            "created_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
            "contents": ["learning-workspace.db", "uploads/"],
            "excluded": [".env", "logs/", "run/", "browser cookies"],
            "restore_note": "Stop the application before replacing its database and uploads directory.",
        }
        (stage / "backup-info.json").write_text(json.dumps(info, indent=2), encoding="utf-8")

        manifest_lines = []
        for path in sorted(p for p in stage.rglob("*") if p.is_file()):
            manifest_lines.append(f"{sha256(path)}  {path.relative_to(stage).as_posix()}")
        (stage / "MANIFEST.sha256").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

        archive = Path(shutil.make_archive(str(archive_base), "zip", root_dir=stage.parent, base_dir=stage.name))
    return archive


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Learning Workspace maintenance")
    subparsers = parser.add_subparsers(dest="command", required=True)
    backup_parser = subparsers.add_parser("backup", help="Create a portable database and uploads backup")
    backup_parser.add_argument("--output", default=str(APP_DIR / "backups"), help="Directory for the backup ZIP")
    args = parser.parse_args(argv)
    try:
        if args.command == "backup":
            path = backup(Path(args.output).expanduser().resolve())
            print(path)
            return 0
    except (OSError, RuntimeError, sqlite3.Error) as exc:
        print(f"Backup failed: {exc}", file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
