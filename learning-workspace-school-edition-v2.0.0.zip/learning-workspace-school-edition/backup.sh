#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"
if [ ! -x .venv/bin/python ]; then
  "$APP_DIR/install.sh"
fi
exec "$APP_DIR/.venv/bin/python" maintenance.py backup "$@"
