# Changelog

## 2.0.0 — 2026-07-18

### Authentication and persistence

- Replaced the JSON-only account store with SQLite.
- Reduced first-run browser setup to one password field.
- Added persistent, hashed server-side sessions.
- Added automatic migration of compatible `data/users.json` password records.
- Added administrator account provisioning, reset, enable/disable, and command-line recovery.

### School product scope

- Rebranded the default product to the generic **Learning Workspace** name.
- Added an administrator branding page with school, tech, and professional themes.
- Added independent teacher workspaces.
- Added server-side document storage, extraction, chunking, and full-text indexing.
- Added textbook chat citations and deterministic book comparison.
- Added lesson plan, question paper, answer key/rubric, worksheet, answer-paper review, and curriculum-comparison workflows.
- Added Full-book pass for exhaustive processing of every extracted chunk.
- Explicitly excluded timetable and school-management functions.

### Models and search

- Added seven CPU-oriented local-model recommendations, visible license families, and Ollama pull controls.
- Added DuckDuckGo, SearXNG, Brave, Serper, Tavily, Google CSE, and Ollama cloud search adapters.
- Added query expansion with a local model, safe search, domain controls, bounded page extraction, and source citations.

### Operations and security

- Added macOS/Linux and Windows install/start/stop scripts.
- Added SQLite-aware backup tooling.
- Added CSRF, same-origin, CSP, secure-cookie option, rate limiting, API-key isolation, and SSRF protections.
- Added integration tests for authentication persistence, document processing, comparison, search, and Ollama proxying.
