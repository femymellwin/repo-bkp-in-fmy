param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ServerArguments
)
$ErrorActionPreference = "Stop"
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppDir
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    & (Join-Path $AppDir "install-windows.ps1")
}
@("data", "logs", "run") | ForEach-Object { New-Item -ItemType Directory -Path $_ -Force | Out-Null }
$Python = Join-Path $AppDir ".venv\Scripts\python.exe"
$OllamaUrl = if ($env:OLLAMA_BASE_URL) { $env:OLLAMA_BASE_URL } else { "http://127.0.0.1:11434" }

try {
    Invoke-RestMethod -Uri ($OllamaUrl.TrimEnd("/") + "/api/tags") -TimeoutSec 2 | Out-Null
} catch {
    if ((Get-Command ollama -ErrorAction SilentlyContinue) -and ($OllamaUrl -match "^http://(127\.0\.0\.1|localhost):")) {
        $Process = Start-Process -FilePath "ollama" -ArgumentList "serve" -RedirectStandardOutput (Join-Path $AppDir "logs\ollama.log") -RedirectStandardError (Join-Path $AppDir "logs\ollama-error.log") -PassThru -WindowStyle Hidden
        Set-Content -Path (Join-Path $AppDir "run\ollama.pid") -Value $Process.Id
        Start-Sleep -Seconds 2
    } else {
        Write-Warning "Ollama is not reachable at $OllamaUrl."
    }
}

& $Python server.py @ServerArguments
exit $LASTEXITCODE
