$ErrorActionPreference = "Stop"
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppDir

function Invoke-SystemPython([string[]]$Arguments) {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 @Arguments
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python @Arguments
    } else {
        throw "Python 3.10 or newer is required. Install Python and enable Add Python to PATH."
    }
    if ($LASTEXITCODE -ne 0) { throw "Python command failed." }
}

Invoke-SystemPython @("-c", "import sys; assert sys.version_info >= (3,10), 'Python 3.10 or newer is required'; print('Using Python', sys.version.split()[0])")
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Invoke-SystemPython @("-m", "venv", ".venv")
}

$Python = Join-Path $AppDir ".venv\Scripts\python.exe"
& $Python -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { throw "Could not update pip." }
& $Python -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "Could not install Python dependencies." }

@("data", "logs", "run") | ForEach-Object { New-Item -ItemType Directory -Path $_ -Force | Out-Null }

if (Get-Command tesseract -ErrorAction SilentlyContinue) {
    Write-Host "Tesseract OCR detected."
} else {
    Write-Host "Optional: install Tesseract OCR to read scanned PDFs and images."
}
if (Get-Command ollama -ErrorAction SilentlyContinue) {
    Write-Host "Ollama detected."
} else {
    Write-Warning "Ollama is not installed or is not on PATH. Install the official Ollama application before using local models."
}
Write-Host "Installation complete. Run .\start-windows.ps1 or .\start-windows-background.ps1"
