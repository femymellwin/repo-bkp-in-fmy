$ErrorActionPreference = "SilentlyContinue"
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppDir

function Stop-FromPidFile([string]$Path, [string]$Label) {
    if (-not (Test-Path $Path)) { return }
    $ProcessId = Get-Content $Path
    if ($ProcessId) {
        $Process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
        if ($Process) {
            Stop-Process -Id $ProcessId -Force
            Write-Host "$Label stopped."
        }
    }
    Remove-Item $Path -Force
}

Stop-FromPidFile (Join-Path $AppDir "run\app.pid") "Learning Workspace"
# Ollama is stopped only when this application started it.
Stop-FromPidFile (Join-Path $AppDir "run\ollama.pid") "Ollama"
