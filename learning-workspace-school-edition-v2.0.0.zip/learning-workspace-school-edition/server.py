#!/usr/bin/env python3
"""Learning Workspace local application server.

Features:
- SQLite-backed users and durable sessions
- rebrandable login and application shell
- per-teacher workspaces and textbook library
- PDF/DOCX/PPTX/XLSX/EPUB/ODT/text/image extraction with optional OCR
- local full-text retrieval for textbook-grounded chat and school workflows
- optional web search with safe-search, page extraction, and citations
- authenticated same-origin proxy for local Ollama models
"""
from __future__ import annotations

import argparse
import base64
import binascii
import getpass
import hashlib
import hmac
import html
import http.cookies
import ipaddress
import json
import logging
import mimetypes
import os
import re
import secrets
import shutil
import signal
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from html.parser import HTMLParser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from typing import Any, Iterable

from document_pipeline import (
    ExtractionError,
    ExtractionOptions,
    SUPPORTED_EXTENSIONS,
    chunk_sections,
    compare_documents,
    extract_document,
    normalize_text,
)
from storage import Database, PASSWORD_MAX_LENGTH, PASSWORD_MIN_LENGTH

APP_DIR = Path(__file__).resolve().parent
DEFAULT_DATA_DIR = APP_DIR / "data"
COOKIE_NAME = "learning_workspace_session"
MAX_USERNAME_LENGTH = 64
MAX_MODEL_NAME_LENGTH = 256
MAX_SEARCH_QUERY_LENGTH = 2000
MODEL_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}$")
LOG = logging.getLogger("learning-workspace")

RECOMMENDED_MODELS = [
    {
        "name": "qwen3:0.6b",
        "label": "Ultra-light",
        "download_size": "523 MB",
        "context": "40K",
        "suggested_ram": "4-8 GB+",
        "license": "Apache 2.0",
        "purpose": "Search-query rewriting, short drafts, and basic summaries on very small computers; not recommended for final marking.",
    },
    {
        "name": "gemma3:1b",
        "label": "Lightweight",
        "download_size": "815 MB",
        "context": "32K",
        "suggested_ram": "8 GB+",
        "license": "Gemma Terms",
        "purpose": "Fast summaries, simple worksheets, and low-memory computers.",
    },
    {
        "name": "qwen3:1.7b",
        "label": "Balanced CPU default",
        "download_size": "1.4 GB",
        "context": "40K",
        "suggested_ram": "8-12 GB+",
        "license": "Apache 2.0",
        "purpose": "Multilingual school work, lesson planning, and everyday textbook questions.",
        "recommended": True,
    },
    {
        "name": "llama3.2:3b",
        "label": "General alternative",
        "download_size": "2.0 GB",
        "context": "128K",
        "suggested_ram": "12-16 GB+",
        "license": "Llama 3.2 Community License",
        "purpose": "General English instruction, lesson drafts, and longer-context work from a different model family.",
    },
    {
        "name": "qwen3:4b",
        "label": "Best quality on affordable CPU",
        "download_size": "2.5 GB",
        "context": "256K",
        "suggested_ram": "16 GB+",
        "license": "Apache 2.0",
        "purpose": "Book comparison, question papers, rubrics, and stronger reasoning.",
    },
    {
        "name": "phi4-mini",
        "label": "Math and reasoning",
        "download_size": "2.5 GB",
        "context": "128K",
        "suggested_ram": "16 GB+",
        "license": "MIT",
        "purpose": "Mathematics, logic, marking rubrics, and structured evaluation.",
    },
    {
        "name": "gemma3:4b",
        "label": "Text and image",
        "download_size": "3.3 GB",
        "context": "128K",
        "suggested_ram": "16 GB+",
        "license": "Gemma Terms",
        "purpose": "Textbook work plus diagrams or photographed answer sheets.",
    },
]


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc
    return max(minimum, min(maximum, value))


def load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            LOG.warning("Ignoring malformed .env line %s", line_number)
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            LOG.warning("Ignoring invalid .env key on line %s", line_number)
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def normalize_base_url(value: str, label: str) -> str:
    try:
        parsed = urllib.parse.urlparse(value.strip())
    except ValueError as exc:
        raise ValueError(f"{label} is not a valid URL") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"{label} must be an http:// or https:// URL")
    if parsed.username or parsed.password:
        raise ValueError(f"{label} must not contain credentials")
    return value.rstrip("/")


def normalize_provider(value: str) -> str:
    provider = value.strip().lower().replace("-", "_")
    aliases = {
        "ddg": "duckduckgo",
        "searx": "searxng",
        "google": "google_cse",
        "google_custom_search": "google_cse",
        "ollama": "ollama_cloud",
        "ollama_search": "ollama_cloud",
    }
    provider = aliases.get(provider, provider)
    allowed = {"duckduckgo", "searxng", "brave", "serper", "tavily", "google_cse", "ollama_cloud"}
    if provider not in allowed:
        raise ValueError(f"WEB_SEARCH_PROVIDER must be one of: {', '.join(sorted(allowed))}")
    return provider


def split_domains(value: str) -> tuple[str, ...]:
    domains: list[str] = []
    for item in value.split(","):
        domain = item.strip().lower().lstrip(".")
        if not domain:
            continue
        if not re.fullmatch(r"[a-z0-9.-]+", domain):
            raise ValueError(f"Invalid domain: {domain}")
        domains.append(domain)
    return tuple(dict.fromkeys(domains))


@dataclass(frozen=True)
class AppConfig:
    host: str
    port: int
    data_dir: Path
    database_path: Path
    upload_dir: Path
    ollama_base_url: str
    enable_web_search: bool
    web_search_provider: str
    web_search_result_count: int
    web_search_timeout: int
    web_search_query_mode: str
    web_search_domain_allowlist: tuple[str, ...]
    web_search_domain_denylist: tuple[str, ...]
    web_search_safe: bool
    web_fetch_pages: bool
    web_fetch_count: int
    web_page_max_chars: int
    searxng_url: str
    ollama_web_search_url: str
    ollama_web_search_api_key: str
    brave_search_api_key: str
    serper_api_key: str
    tavily_api_key: str
    google_search_api_key: str
    google_search_engine_id: str
    session_ttl_seconds: int
    cookie_secure: bool
    max_request_bytes: int
    max_upload_bytes: int
    ollama_request_timeout: int
    enable_ocr: bool
    ocr_languages: str
    max_document_chars: int
    document_query_mode: str
    log_level: str

    @classmethod
    def from_env(cls, args: argparse.Namespace) -> "AppConfig":
        data_dir = Path(os.getenv("APP_DATA_DIR", os.getenv("AEGIS_DATA_DIR", str(DEFAULT_DATA_DIR)))).expanduser().resolve()
        database_path = Path(os.getenv("DATABASE_PATH", str(data_dir / "learning-workspace.db"))).expanduser().resolve()
        upload_dir = Path(os.getenv("UPLOAD_DIR", str(data_dir / "uploads"))).expanduser().resolve()
        query_mode = os.getenv("WEB_SEARCH_QUERY_MODE", "model").strip().lower()
        if query_mode not in {"direct", "model"}:
            raise ValueError("WEB_SEARCH_QUERY_MODE must be direct or model")
        document_query_mode = os.getenv("DOCUMENT_QUERY_MODE", "model").strip().lower()
        if document_query_mode not in {"direct", "model"}:
            raise ValueError("DOCUMENT_QUERY_MODE must be direct or model")

        enabled = env_bool("ENABLE_WEB_SEARCH", True)
        if args.enable_web_search:
            enabled = True
        if args.disable_web_search:
            enabled = False

        searxng_raw = os.getenv("SEARXNG_URL", "").strip()
        return cls(
            host=args.host or os.getenv("HOST", "127.0.0.1"),
            port=args.port if args.port is not None else env_int("PORT", 8787, 1, 65535),
            data_dir=data_dir,
            database_path=database_path,
            upload_dir=upload_dir,
            ollama_base_url=normalize_base_url(
                args.ollama_url or os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434"),
                "OLLAMA_BASE_URL",
            ),
            enable_web_search=enabled,
            web_search_provider=normalize_provider(args.web_search_provider or os.getenv("WEB_SEARCH_PROVIDER", "duckduckgo")),
            web_search_result_count=max(
                1,
                min(
                    12,
                    args.web_results
                    if args.web_results is not None
                    else env_int("WEB_SEARCH_RESULT_COUNT", 6, 1, 12),
                ),
            ),
            web_search_timeout=env_int("WEB_SEARCH_TIMEOUT", 18, 3, 120),
            web_search_query_mode=query_mode,
            web_search_domain_allowlist=split_domains(os.getenv("WEB_SEARCH_DOMAIN_ALLOWLIST", "")),
            web_search_domain_denylist=split_domains(
                os.getenv("WEB_SEARCH_DOMAIN_DENYLIST", "pinterest.com,facebook.com,instagram.com,tiktok.com")
            ),
            web_search_safe=env_bool("WEB_SEARCH_SAFE", True),
            web_fetch_pages=env_bool("WEB_SEARCH_FETCH_PAGES", True),
            web_fetch_count=env_int("WEB_SEARCH_FETCH_COUNT", 3, 0, 8),
            web_page_max_chars=env_int("WEB_SEARCH_PAGE_MAX_CHARS", 9000, 1000, 40000),
            searxng_url=normalize_base_url(searxng_raw, "SEARXNG_URL") if searxng_raw else "",
            ollama_web_search_url=normalize_base_url(
                os.getenv("OLLAMA_WEB_SEARCH_URL", "https://ollama.com"), "OLLAMA_WEB_SEARCH_URL"
            ),
            ollama_web_search_api_key=os.getenv("OLLAMA_WEB_SEARCH_API_KEY", "").strip(),
            brave_search_api_key=os.getenv("BRAVE_SEARCH_API_KEY", "").strip(),
            serper_api_key=os.getenv("SERPER_API_KEY", "").strip(),
            tavily_api_key=os.getenv("TAVILY_API_KEY", "").strip(),
            google_search_api_key=os.getenv("GOOGLE_SEARCH_API_KEY", "").strip(),
            google_search_engine_id=os.getenv("GOOGLE_SEARCH_ENGINE_ID", "").strip(),
            session_ttl_seconds=env_int("SESSION_TTL_HOURS", 72, 1, 720) * 3600,
            cookie_secure=env_bool("COOKIE_SECURE", False),
            max_request_bytes=env_int("MAX_REQUEST_MB", 96, 2, 512) * 1024 * 1024,
            max_upload_bytes=env_int("MAX_UPLOAD_MB", 64, 1, 256) * 1024 * 1024,
            ollama_request_timeout=env_int("OLLAMA_REQUEST_TIMEOUT", 900, 10, 7200),
            enable_ocr=env_bool("ENABLE_OCR", True),
            ocr_languages=os.getenv("OCR_LANGUAGES", "eng").strip() or "eng",
            max_document_chars=env_int("MAX_DOCUMENT_CHARS", 8_000_000, 100_000, 30_000_000),
            document_query_mode=document_query_mode,
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
        )


class LoginLimiter:
    def __init__(self, max_attempts: int = 8, window_seconds: int = 600):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self._attempts: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def _recent(self, key: str) -> list[float]:
        cutoff = time.time() - self.window_seconds
        return [stamp for stamp in self._attempts.get(key, []) if stamp >= cutoff]

    def allowed(self, key: str) -> bool:
        with self._lock:
            recent = self._recent(key)
            self._attempts[key] = recent
            return len(recent) < self.max_attempts

    def fail(self, key: str) -> None:
        with self._lock:
            recent = self._recent(key)
            recent.append(time.time())
            self._attempts[key] = recent

    def success(self, key: str) -> None:
        with self._lock:
            self._attempts.pop(key, None)


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str
    content: str = ""

    def as_dict(self) -> dict[str, str]:
        return {"title": self.title, "url": self.url, "snippet": self.snippet, "content": self.content}


class DuckDuckGoHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.results: list[SearchResult] = []
        self._anchor_depth = 0
        self._snippet_depth = 0
        self._current_url = ""
        self._title_parts: list[str] = []
        self._snippet_parts: list[str] = []

    @staticmethod
    def _classes(attrs: list[tuple[str, str | None]]) -> set[str]:
        value = next((value or "" for key, value in attrs if key == "class"), "")
        return set(value.split())

    @staticmethod
    def _attr(attrs: list[tuple[str, str | None]], name: str) -> str:
        return next((value or "" for key, value in attrs if key == name), "")

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        classes = self._classes(attrs)
        if tag == "a" and "result__a" in classes:
            self._current_url = self._attr(attrs, "href")
            self._title_parts = []
            self._anchor_depth = 1
            return
        if self._anchor_depth:
            self._anchor_depth += 1
        if "result__snippet" in classes:
            self._snippet_parts = []
            self._snippet_depth = 1
            return
        if self._snippet_depth:
            self._snippet_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if self._anchor_depth:
            self._anchor_depth -= 1
            if self._anchor_depth == 0:
                title = " ".join("".join(self._title_parts).split())
                url = decode_duckduckgo_url(self._current_url)
                if title and url:
                    self.results.append(SearchResult(title=title, url=url, snippet=""))
                self._current_url = ""
                self._title_parts = []
        if self._snippet_depth:
            self._snippet_depth -= 1
            if self._snippet_depth == 0:
                snippet = " ".join("".join(self._snippet_parts).split())
                if snippet and self.results and not self.results[-1].snippet:
                    self.results[-1].snippet = snippet
                self._snippet_parts = []

    def handle_data(self, data: str) -> None:
        if self._anchor_depth:
            self._title_parts.append(data)
        if self._snippet_depth:
            self._snippet_parts.append(data)


class MainTextParser(HTMLParser):
    """Dependency-free fallback for extracting readable web-page text."""

    BLOCKS = {"p", "div", "article", "section", "main", "li", "br", "h1", "h2", "h3", "h4", "h5", "tr"}
    SKIP = {"script", "style", "noscript", "svg", "canvas", "nav", "footer"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self.SKIP:
            self.skip_depth += 1
        elif not self.skip_depth and tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.SKIP and self.skip_depth:
            self.skip_depth -= 1
        elif not self.skip_depth and tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self.skip_depth:
            self.parts.append(data)

    def text(self) -> str:
        return normalize_text(" ".join(self.parts))


def decode_duckduckgo_url(raw_url: str) -> str:
    value = html.unescape(raw_url.strip())
    if value.startswith("//"):
        value = "https:" + value
    elif value.startswith("/"):
        value = "https://duckduckgo.com" + value
    parsed = urllib.parse.urlparse(value)
    if parsed.netloc.endswith("duckduckgo.com") and parsed.path.startswith("/l/"):
        target = urllib.parse.parse_qs(parsed.query).get("uddg", [""])[0]
        if target:
            value = urllib.parse.unquote(target)
    return sanitize_result_url(value)


def sanitize_result_url(value: str) -> str:
    try:
        parsed = urllib.parse.urlparse(value.strip())
    except ValueError:
        return ""
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
        return ""
    return urllib.parse.urlunparse(parsed._replace(fragment=""))


def host_matches(host: str, domains: Iterable[str]) -> bool:
    host = host.lower().rstrip(".")
    return any(host == domain or host.endswith("." + domain) for domain in domains)


def result_domain_allowed(url: str, allowlist: Iterable[str], denylist: Iterable[str]) -> bool:
    host = (urllib.parse.urlparse(url).hostname or "").lower().rstrip(".")
    if not host:
        return False
    if tuple(denylist) and host_matches(host, denylist):
        return False
    return not tuple(allowlist) or host_matches(host, allowlist)


def canonical_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    query_items = [
        (key, value)
        for key, value in urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
        if not key.lower().startswith("utm_") and key.lower() not in {"gclid", "fbclid", "mc_cid", "mc_eid"}
    ]
    return urllib.parse.urlunparse(
        parsed._replace(
            scheme=parsed.scheme.lower(),
            netloc=parsed.netloc.lower(),
            path=parsed.path.rstrip("/") or "/",
            query=urllib.parse.urlencode(query_items, doseq=True),
            fragment="",
        )
    )


def extract_json_object(text: str) -> dict[str, Any]:
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise ValueError("No JSON object found")


def validate_public_url(url: str) -> str:
    clean = sanitize_result_url(url)
    if not clean:
        raise ValueError("URL must use public HTTP or HTTPS")
    parsed = urllib.parse.urlparse(clean)
    host = parsed.hostname or ""
    if host.lower() in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise ValueError("Local network URLs are blocked")
    try:
        addresses = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ValueError("Could not resolve page host") from exc
    for info in addresses:
        address = ipaddress.ip_address(info[4][0].split("%", 1)[0])
        if (
            address.is_private
            or address.is_loopback
            or address.is_link_local
            or address.is_multicast
            or address.is_reserved
            or address.is_unspecified
        ):
            raise ValueError("Private and local network URLs are blocked")
    return clean


class SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req: urllib.request.Request, fp: Any, code: int, msg: str, headers: Any, newurl: str):
        validate_public_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def web_html_to_text(raw: bytes, encoding: str | None = None) -> str:
    text = raw.decode(encoding or "utf-8", errors="replace")
    try:
        import trafilatura

        extracted = trafilatura.extract(
            text,
            include_comments=False,
            include_tables=True,
            include_links=False,
            favor_recall=True,
        )
        if extracted:
            return normalize_text(extracted)
    except Exception:
        pass
    try:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(text, "html.parser")
        for node in soup(["script", "style", "noscript", "svg", "canvas", "nav", "footer"]):
            node.decompose()
        root = soup.find("main") or soup.find("article") or soup.body or soup
        return normalize_text(root.get_text("\n", strip=True))
    except Exception:
        parser = MainTextParser()
        parser.feed(text)
        return parser.text()


@dataclass
class AppState:
    config: AppConfig
    db: Database
    login_limiter: LoginLimiter = field(default_factory=LoginLimiter)

    def bootstrap_admin_from_environment(self) -> None:
        if self.db.has_users():
            return
        username = os.getenv("APP_ADMIN_USERNAME", os.getenv("AEGIS_ADMIN_USERNAME", "")).strip()
        password = os.getenv("APP_ADMIN_PASSWORD", os.getenv("AEGIS_ADMIN_PASSWORD", ""))
        if not username and not password:
            return
        if not username or not password:
            raise ValueError("Set both APP_ADMIN_USERNAME and APP_ADMIN_PASSWORD, or neither.")
        self.db.create_user(username, password, role="admin", only_if_empty=True)
        LOG.info("Created initial administrator from environment: %s", username)

    def provider_ready(self) -> bool:
        provider = self.config.web_search_provider
        if provider == "duckduckgo":
            return True
        if provider == "searxng":
            return bool(self.config.searxng_url)
        if provider == "brave":
            return bool(self.config.brave_search_api_key)
        if provider == "serper":
            return bool(self.config.serper_api_key)
        if provider == "tavily":
            return bool(self.config.tavily_api_key)
        if provider == "google_cse":
            return bool(self.config.google_search_api_key and self.config.google_search_engine_id)
        if provider == "ollama_cloud":
            return bool(self.config.ollama_web_search_api_key)
        return False

    def public_config(self) -> dict[str, Any]:
        return {
            "ollama_base_url": self.config.ollama_base_url,
            "web_search_enabled": self.config.enable_web_search,
            "web_search_provider": self.config.web_search_provider,
            "web_search_provider_ready": self.provider_ready(),
            "web_search_result_count": self.config.web_search_result_count,
            "web_search_query_mode": self.config.web_search_query_mode,
            "web_search_fetch_pages": self.config.web_fetch_pages,
            "document_query_mode": self.config.document_query_mode,
            "ocr_enabled": self.config.enable_ocr,
            "ocr_languages": self.config.ocr_languages,
            "max_upload_mb": self.config.max_upload_bytes // (1024 * 1024),
            "max_document_chars": self.config.max_document_chars,
            "supported_extensions": sorted(SUPPORTED_EXTENSIONS),
            "recommended_models": RECOMMENDED_MODELS,
            "model_notice": "Local models have no per-token API charge; review each model's license before deployment.",
            "bind_host": self.config.host,
            "port": self.config.port,
        }

    def ollama_json(self, path: str, payload: dict[str, Any], timeout: int | None = None) -> dict[str, Any]:
        request = urllib.request.Request(
            self.config.ollama_base_url + path,
            data=json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "LearningWorkspace/2.0",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout or self.config.ollama_request_timeout) as response:
            body = response.read(16_000_000)
        decoded = json.loads(body.decode("utf-8"))
        if not isinstance(decoded, dict):
            raise ValueError("Ollama returned an unexpected response")
        return decoded

    def generate_queries(self, prompt: str, model: str, purpose: str) -> list[str]:
        mode = self.config.web_search_query_mode if purpose == "web" else self.config.document_query_mode
        if mode != "model" or not model:
            return [prompt]
        if purpose == "web":
            instruction = (
                "Generate one to three precise web search queries for this teacher request. Preserve names, dates, grade, "
                "curriculum, location, and source type. Return JSON only: {\"queries\":[\"query\"]}."
            )
        else:
            instruction = (
                "Generate two to four short keyword searches for finding relevant passages in uploaded school books. "
                "Include important subject terms and synonyms. Return JSON only: {\"queries\":[\"query\"]}."
            )
        payload = {
            "model": model,
            "stream": False,
            "format": "json",
            "options": {"temperature": 0, "num_predict": 180},
            "messages": [{"role": "system", "content": instruction}, {"role": "user", "content": prompt}],
        }
        try:
            response = self.ollama_json("/api/chat", payload, timeout=min(self.config.ollama_request_timeout, 150))
            content = str((response.get("message") or {}).get("content") or "")
            parsed = extract_json_object(content)
            queries: list[str] = []
            for item in parsed.get("queries", []):
                query = " ".join(str(item).split())[:MAX_SEARCH_QUERY_LENGTH]
                if query and query not in queries:
                    queries.append(query)
            if queries:
                return queries[: (3 if purpose == "web" else 4)]
        except Exception as exc:
            LOG.warning("%s query expansion failed; using original query: %s", purpose, exc)
        return [prompt]

    def search_documents(
        self,
        *,
        user_id: int,
        workspace_id: str,
        query: str,
        model: str,
        document_ids: list[str] | None,
        limit: int,
    ) -> tuple[list[str], list[dict[str, Any]]]:
        queries = self.generate_queries(query, model, "document")
        merged: list[dict[str, Any]] = []
        seen: set[int] = set()
        per_query = max(limit, 6)
        for expanded in queries:
            for item in self.db.search_chunks(
                user_id=user_id,
                workspace_id=workspace_id,
                query=expanded,
                document_ids=document_ids,
                limit=per_query,
            ):
                chunk_id = int(item["id"])
                if chunk_id in seen:
                    continue
                seen.add(chunk_id)
                merged.append(item)
                if len(merged) >= limit:
                    return queries, merged
        return queries, merged

    def search_web(self, prompt: str, model: str) -> tuple[list[str], list[SearchResult]]:
        if not self.config.enable_web_search:
            raise PermissionError("Web search is disabled by server configuration.")
        if not self.provider_ready():
            raise RuntimeError(f"Web search provider '{self.config.web_search_provider}' is not configured.")
        queries = self.generate_queries(prompt, model, "web")
        provider = self.config.web_search_provider
        per_query = max(self.config.web_search_result_count, 4)

        def execute(query: str) -> list[SearchResult]:
            if provider == "duckduckgo":
                return self.search_duckduckgo(query, per_query)
            if provider == "searxng":
                return self.search_searxng(query, per_query)
            if provider == "brave":
                return self.search_brave(query, per_query)
            if provider == "serper":
                return self.search_serper(query, per_query)
            if provider == "tavily":
                return self.search_tavily(query, per_query)
            if provider == "google_cse":
                return self.search_google_cse(query, per_query)
            if provider == "ollama_cloud":
                return self.search_ollama_cloud(query, per_query)
            raise RuntimeError(f"Unsupported search provider: {provider}")

        gathered: list[SearchResult] = []
        errors: list[str] = []
        with ThreadPoolExecutor(max_workers=min(3, len(queries))) as executor:
            futures = {executor.submit(execute, query): query for query in queries}
            for future in as_completed(futures):
                try:
                    gathered.extend(future.result())
                except Exception as exc:
                    errors.append(f"{futures[future]}: {exc}")
        if not gathered and errors:
            raise RuntimeError(f"All web searches failed for {provider}. {errors[0]}")

        merged: list[SearchResult] = []
        seen_urls: set[str] = set()
        for item in gathered:
            url = sanitize_result_url(item.url)
            if not url or not result_domain_allowed(
                url, self.config.web_search_domain_allowlist, self.config.web_search_domain_denylist
            ):
                continue
            canonical = canonical_url(url)
            if canonical in seen_urls:
                continue
            seen_urls.add(canonical)
            title = " ".join(item.title.split())[:300] or url
            snippet = " ".join(item.snippet.split())[:1500]
            content = normalize_text(item.content)[: self.config.web_page_max_chars]
            merged.append(SearchResult(title=title, url=url, snippet=snippet, content=content))
            if len(merged) >= self.config.web_search_result_count:
                break

        if self.config.web_fetch_pages and self.config.web_fetch_count > 0:
            self.enrich_results(merged[: self.config.web_fetch_count])
        return queries, merged

    def enrich_results(self, results: list[SearchResult]) -> None:
        def enrich(item: SearchResult) -> tuple[SearchResult, str]:
            if len(item.content) >= min(2500, self.config.web_page_max_chars // 2):
                return item, item.content
            try:
                return item, self.fetch_page_text(item.url)
            except Exception as exc:
                LOG.info("Could not extract %s: %s", item.url, exc)
                return item, ""

        with ThreadPoolExecutor(max_workers=min(4, len(results) or 1)) as executor:
            futures = [executor.submit(enrich, item) for item in results]
            for future in as_completed(futures):
                item, content = future.result()
                if content:
                    item.content = content[: self.config.web_page_max_chars]

    def fetch_page_text(self, url: str) -> str:
        safe_url = validate_public_url(url)
        request = urllib.request.Request(
            safe_url,
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; LearningWorkspace/2.0; educational search)",
                "Accept": "text/html,application/xhtml+xml,application/pdf,text/plain;q=0.9,*/*;q=0.2",
                "Accept-Language": "en,*;q=0.7",
            },
        )
        opener = urllib.request.build_opener(SafeRedirectHandler())
        with opener.open(request, timeout=self.config.web_search_timeout) as response:
            content_type = response.headers.get_content_type()
            charset = response.headers.get_content_charset()
            raw = response.read(6_000_001)
        if len(raw) > 6_000_000:
            raw = raw[:6_000_000]
        if content_type == "application/pdf" or raw.startswith(b"%PDF"):
            try:
                from pypdf import PdfReader

                reader = PdfReader(BytesIO(raw))
                parts: list[str] = []
                used = 0
                for index, page in enumerate(reader.pages[:40], start=1):
                    text = normalize_text(page.extract_text() or "")
                    if text:
                        piece = f"Page {index}\n{text}"
                        parts.append(piece)
                        used += len(piece)
                        if used >= self.config.web_page_max_chars:
                            break
                return normalize_text("\n\n".join(parts))[: self.config.web_page_max_chars]
            except Exception:
                return ""
        if content_type.startswith("text/") or "html" in content_type or not content_type:
            return web_html_to_text(raw, charset)[: self.config.web_page_max_chars]
        return ""

    def search_duckduckgo(self, query: str, count: int) -> list[SearchResult]:
        params = {"q": query}
        if self.config.web_search_safe:
            params["kp"] = "1"
        request = urllib.request.Request(
            "https://html.duckduckgo.com/html/?" + urllib.parse.urlencode(params),
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; LearningWorkspace/2.0; educational search)",
                "Accept": "text/html",
            },
        )
        with urllib.request.urlopen(request, timeout=self.config.web_search_timeout) as response:
            raw = response.read(4_000_000).decode("utf-8", errors="replace")
        parser = DuckDuckGoHTMLParser()
        parser.feed(raw)
        return parser.results[:count]

    def search_searxng(self, query: str, count: int) -> list[SearchResult]:
        if not self.config.searxng_url:
            raise RuntimeError("SEARXNG_URL is not set")
        params = urllib.parse.urlencode(
            {
                "q": query,
                "format": "json",
                "safesearch": "2" if self.config.web_search_safe else "0",
                "categories": "general",
            }
        )
        separator = "&" if "?" in self.config.searxng_url else "?"
        request = urllib.request.Request(
            self.config.searxng_url + separator + params,
            headers={"Accept": "application/json", "User-Agent": "LearningWorkspace/2.0"},
        )
        with urllib.request.urlopen(request, timeout=self.config.web_search_timeout) as response:
            payload = json.loads(response.read(5_000_000).decode("utf-8"))
        raw_results = payload.get("results", []) if isinstance(payload, dict) else []
        return [
            SearchResult(
                title=str(item.get("title") or item.get("url") or ""),
                url=str(item.get("url") or ""),
                snippet=str(item.get("content") or item.get("snippet") or ""),
            )
            for item in raw_results[:count]
        ]

    def search_brave(self, query: str, count: int) -> list[SearchResult]:
        if not self.config.brave_search_api_key:
            raise RuntimeError("BRAVE_SEARCH_API_KEY is not set")
        params = urllib.parse.urlencode(
            {"q": query, "count": min(count, 20), "safesearch": "strict" if self.config.web_search_safe else "off"}
        )
        request = urllib.request.Request(
            "https://api.search.brave.com/res/v1/web/search?" + params,
            headers={
                "X-Subscription-Token": self.config.brave_search_api_key,
                "Accept": "application/json",
                "User-Agent": "LearningWorkspace/2.0",
            },
        )
        with urllib.request.urlopen(request, timeout=self.config.web_search_timeout) as response:
            payload = json.loads(response.read(5_000_000).decode("utf-8"))
        raw_results = ((payload.get("web") or {}).get("results") or []) if isinstance(payload, dict) else []
        return [
            SearchResult(
                title=str(item.get("title") or item.get("url") or ""),
                url=str(item.get("url") or ""),
                snippet=str(item.get("description") or ""),
                content="\n".join(str(value) for value in (item.get("extra_snippets") or []) if value),
            )
            for item in raw_results[:count]
        ]

    def search_serper(self, query: str, count: int) -> list[SearchResult]:
        if not self.config.serper_api_key:
            raise RuntimeError("SERPER_API_KEY is not set")
        payload = {"q": query, "num": min(count, 10), "safe": "active" if self.config.web_search_safe else "off"}
        request = urllib.request.Request(
            "https://google.serper.dev/search",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "X-API-KEY": self.config.serper_api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "LearningWorkspace/2.0",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.config.web_search_timeout) as response:
            data = json.loads(response.read(5_000_000).decode("utf-8"))
        raw_results = data.get("organic", []) if isinstance(data, dict) else []
        return [
            SearchResult(
                title=str(item.get("title") or item.get("link") or ""),
                url=str(item.get("link") or ""),
                snippet=str(item.get("snippet") or ""),
            )
            for item in raw_results[:count]
        ]

    def search_tavily(self, query: str, count: int) -> list[SearchResult]:
        if not self.config.tavily_api_key:
            raise RuntimeError("TAVILY_API_KEY is not set")
        payload = {
            "query": query,
            "search_depth": "basic",
            "max_results": min(count, 20),
            "include_answer": False,
            "include_raw_content": True,
        }
        request = urllib.request.Request(
            "https://api.tavily.com/search",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.config.tavily_api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "LearningWorkspace/2.0",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.config.web_search_timeout) as response:
            data = json.loads(response.read(8_000_000).decode("utf-8"))
        raw_results = data.get("results", []) if isinstance(data, dict) else []
        return [
            SearchResult(
                title=str(item.get("title") or item.get("url") or ""),
                url=str(item.get("url") or ""),
                snippet=str(item.get("content") or ""),
                content=str(item.get("raw_content") or ""),
            )
            for item in raw_results[:count]
        ]

    def search_google_cse(self, query: str, count: int) -> list[SearchResult]:
        if not self.config.google_search_api_key or not self.config.google_search_engine_id:
            raise RuntimeError("GOOGLE_SEARCH_API_KEY and GOOGLE_SEARCH_ENGINE_ID are required")
        params = urllib.parse.urlencode(
            {
                "key": self.config.google_search_api_key,
                "cx": self.config.google_search_engine_id,
                "q": query,
                "num": min(count, 10),
                "safe": "active" if self.config.web_search_safe else "off",
            }
        )
        request = urllib.request.Request(
            "https://customsearch.googleapis.com/customsearch/v1?" + params,
            headers={"Accept": "application/json", "User-Agent": "LearningWorkspace/2.0"},
        )
        with urllib.request.urlopen(request, timeout=self.config.web_search_timeout) as response:
            data = json.loads(response.read(5_000_000).decode("utf-8"))
        return [
            SearchResult(
                title=str(item.get("title") or item.get("link") or ""),
                url=str(item.get("link") or ""),
                snippet=str(item.get("snippet") or ""),
            )
            for item in (data.get("items") or [])[:count]
        ]

    def search_ollama_cloud(self, query: str, count: int) -> list[SearchResult]:
        if not self.config.ollama_web_search_api_key:
            raise RuntimeError("OLLAMA_WEB_SEARCH_API_KEY is not set")
        request = urllib.request.Request(
            self.config.ollama_web_search_url + "/api/web_search",
            data=json.dumps({"query": query, "max_results": count}).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.config.ollama_web_search_api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "LearningWorkspace/2.0",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.config.web_search_timeout) as response:
            data = json.loads(response.read(5_000_000).decode("utf-8"))
        raw_results = data.get("results", data if isinstance(data, list) else [])
        return [
            SearchResult(
                title=str(item.get("title") or item.get("url") or ""),
                url=str(item.get("url") or ""),
                snippet=str(item.get("content") or item.get("snippet") or ""),
            )
            for item in raw_results[:count]
            if isinstance(item, dict)
        ]


class LearningHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address: tuple[str, int], handler: type[BaseHTTPRequestHandler], state: AppState):
        super().__init__(server_address, handler)
        self.state = state


class LearningHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "LearningWorkspace/2.0"
    sys_version = ""

    @property
    def state(self) -> AppState:
        return self.server.state  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        LOG.info("%s - %s", self.address_string(), fmt % args)

    def _security_headers(self, content_type: str, cache_control: str = "no-store") -> dict[str, str]:
        return {
            "Content-Type": content_type,
            "Cache-Control": cache_control,
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "Referrer-Policy": "no-referrer",
            "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
            "Cross-Origin-Opener-Policy": "same-origin",
            "Cross-Origin-Resource-Policy": "same-origin",
            "Content-Security-Policy": (
                "default-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; object-src 'none'; "
                "script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
                "connect-src 'self'; font-src 'self';"
            ),
        }

    def _send_bytes(
        self,
        status: int,
        body: bytes,
        content_type: str,
        extra_headers: dict[str, str] | None = None,
        cache_control: str = "no-store",
    ) -> None:
        self.send_response(status)
        headers = self._security_headers(content_type, cache_control)
        if extra_headers:
            headers.update(extra_headers)
        headers["Content-Length"] = str(len(body))
        for key, value in headers.items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD" and body:
            self.wfile.write(body)

    def _send_json(
        self,
        status: int,
        payload: dict[str, Any] | list[Any],
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self._send_bytes(status, body, "application/json; charset=utf-8", extra_headers)

    def _send_error_json(self, status: int, message: str) -> None:
        self._send_json(status, {"error": message})

    def _read_json(self) -> dict[str, Any]:
        media_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
        if media_type != "application/json" and not media_type.endswith("+json"):
            raise ValueError("Content-Type must be application/json")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid Content-Length") from exc
        if length < 0 or length > self.state.config.max_request_bytes:
            raise OverflowError("Request body is too large")
        body = self.rfile.read(length)
        try:
            payload = json.loads(body.decode("utf-8")) if body else {}
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Request body must be valid JSON") from exc
        if not isinstance(payload, dict):
            raise ValueError("JSON body must be an object")
        return payload

    def _client_key(self) -> str:
        return self.client_address[0]

    def _same_origin_request(self) -> bool:
        fetch_site = self.headers.get("Sec-Fetch-Site", "").strip().lower()
        if fetch_site == "cross-site":
            return False
        origin = self.headers.get("Origin", "").strip()
        if not origin:
            return True
        try:
            parsed = urllib.parse.urlparse(origin)
        except ValueError:
            return False
        request_host = self.headers.get("Host", "").strip().casefold()
        return parsed.scheme in {"http", "https"} and bool(request_host) and parsed.netloc.casefold() == request_host

    def _cookie_token(self) -> str | None:
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        cookie = http.cookies.SimpleCookie()
        try:
            cookie.load(raw)
        except http.cookies.CookieError:
            return None
        morsel = cookie.get(COOKIE_NAME)
        return morsel.value if morsel else None

    def _session(self) -> tuple[str | None, dict[str, Any] | None]:
        token = self._cookie_token()
        return token, self.state.db.get_session(token, self.state.config.session_ttl_seconds)

    def _require_auth(self, require_csrf: bool = False) -> tuple[str, dict[str, Any]] | None:
        token, session = self._session()
        if not token or not session:
            self._send_error_json(HTTPStatus.UNAUTHORIZED, "Authentication required.")
            return None
        if require_csrf:
            supplied = self.headers.get("X-CSRF-Token", "")
            if not supplied or not hmac.compare_digest(supplied, str(session["csrf_token"])):
                self._send_error_json(HTTPStatus.FORBIDDEN, "Invalid CSRF token.")
                return None
        return token, session

    def _require_admin(self, require_csrf: bool = False) -> tuple[str, dict[str, Any]] | None:
        auth = self._require_auth(require_csrf=require_csrf)
        if not auth:
            return None
        if auth[1]["user"]["role"] != "admin":
            self._send_error_json(HTTPStatus.FORBIDDEN, "Administrator access is required.")
            return None
        return auth

    def _set_session_cookie(self, token: str) -> str:
        parts = [
            f"{COOKIE_NAME}={token}",
            "Path=/",
            "HttpOnly",
            "SameSite=Strict",
            f"Max-Age={self.state.config.session_ttl_seconds}",
        ]
        if self.state.config.cookie_secure:
            parts.append("Secure")
        return "; ".join(parts)

    @staticmethod
    def _clear_session_cookie() -> str:
        return f"{COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"

    def do_HEAD(self) -> None:  # noqa: N802
        self.do_GET()

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        try:
            if path in {"/", "/index.html"}:
                self._serve_static("index.html", "text/html; charset=utf-8")
            elif path == "/app.js":
                self._serve_static("app.js", "text/javascript; charset=utf-8")
            elif path == "/healthz":
                self._send_json(HTTPStatus.OK, {"status": "ok", "version": "2.0.0"})
            elif path == "/api/branding/public":
                self._send_json(HTTPStatus.OK, self.state.db.get_branding())
            elif path == "/api/auth/status":
                self._auth_status()
            elif path == "/api/config":
                if self._require_auth():
                    self._send_json(HTTPStatus.OK, self.state.public_config())
            elif path == "/api/workspaces":
                auth = self._require_auth()
                if auth:
                    self._send_json(HTTPStatus.OK, {"workspaces": self.state.db.list_workspaces(auth[1]["user"]["id"])})
            elif path == "/api/users":
                if self._require_admin():
                    self._send_json(HTTPStatus.OK, {"users": self.state.db.list_users()})
            elif path == "/api/ollama/tags":
                if self._require_auth():
                    self._proxy_ollama_tags()
            elif re.fullmatch(r"/api/workspaces/[0-9a-f]{32}/documents", path):
                auth = self._require_auth()
                if auth:
                    workspace_id = path.split("/")[3]
                    if not self.state.db.get_workspace(auth[1]["user"]["id"], workspace_id):
                        self._send_error_json(HTTPStatus.NOT_FOUND, "Workspace not found.")
                    else:
                        self._send_json(
                            HTTPStatus.OK,
                            {"documents": self.state.db.list_documents(auth[1]["user"]["id"], workspace_id)},
                        )
            elif path == "/favicon.ico":
                self._send_bytes(HTTPStatus.NO_CONTENT, b"", "image/x-icon", cache_control="public, max-age=86400")
            else:
                self._send_error_json(HTTPStatus.NOT_FOUND, "Not found.")
        except BrokenPipeError:
            pass
        except Exception:
            LOG.exception("Unhandled GET request error")
            try:
                self._send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "Internal server error.")
            except BrokenPipeError:
                pass

    def do_POST(self) -> None:  # noqa: N802
        path = urllib.parse.urlparse(self.path).path
        if not self._same_origin_request():
            self._send_error_json(HTTPStatus.FORBIDDEN, "Cross-origin requests are not allowed.")
            return
        try:
            if path == "/api/auth/setup":
                self._auth_setup()
            elif path == "/api/auth/login":
                self._auth_login()
            elif path == "/api/auth/logout":
                self._auth_logout()
            elif path == "/api/auth/change-password":
                self._auth_change_password()
            elif path == "/api/branding":
                self._update_branding()
            elif path == "/api/users":
                self._create_user()
            elif re.fullmatch(r"/api/users/\d+/password", path):
                self._admin_reset_password(int(path.split("/")[3]))
            elif re.fullmatch(r"/api/users/\d+/toggle", path):
                self._admin_toggle_user(int(path.split("/")[3]))
            elif path == "/api/workspaces":
                self._create_workspace()
            elif re.fullmatch(r"/api/workspaces/[0-9a-f]{32}/update", path):
                self._update_workspace(path.split("/")[3])
            elif re.fullmatch(r"/api/workspaces/[0-9a-f]{32}/delete", path):
                self._delete_workspace(path.split("/")[3])
            elif re.fullmatch(r"/api/workspaces/[0-9a-f]{32}/documents/upload", path):
                self._upload_document(path.split("/")[3])
            elif re.fullmatch(r"/api/documents/[0-9a-f]{32}/delete", path):
                self._delete_document(path.split("/")[3])
            elif path == "/api/documents/search":
                self._document_search()
            elif path == "/api/documents/coverage":
                self._document_coverage()
            elif path == "/api/documents/segments":
                self._document_segments()
            elif path == "/api/documents/compare":
                self._document_compare()
            elif path == "/api/web-search":
                self._web_search()
            elif path == "/api/ollama/chat":
                self._proxy_ollama_chat()
            elif path == "/api/ollama/pull":
                self._proxy_ollama_pull()
            else:
                self._send_error_json(HTTPStatus.NOT_FOUND, "Not found.")
        except OverflowError as exc:
            self._send_error_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, str(exc))
        except ExtractionError as exc:
            self._send_error_json(HTTPStatus.UNPROCESSABLE_ENTITY, str(exc))
        except ValueError as exc:
            self._send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
        except (BrokenPipeError, ConnectionResetError):
            LOG.info("Client disconnected")
        except Exception:
            LOG.exception("Unhandled POST request error")
            try:
                self._send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "Internal server error.")
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _serve_static(self, filename: str, content_type: str) -> None:
        path = APP_DIR / filename
        if not path.exists():
            self._send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, f"{filename} is missing.")
            return
        self._send_bytes(HTTPStatus.OK, path.read_bytes(), content_type, cache_control="no-cache")

    # Authentication ------------------------------------------------------------
    def _auth_status(self) -> None:
        _, session = self._session()
        user = session["user"] if session else None
        self._send_json(
            HTTPStatus.OK,
            {
                "setup_required": not self.state.db.has_users(),
                "authenticated": session is not None,
                "user": user,
                "username": user["username"] if user else None,
                "role": user["role"] if user else None,
                "csrf_token": session["csrf_token"] if session else None,
                "branding": self.state.db.get_branding(),
            },
        )

    @staticmethod
    def _login_payload(payload: dict[str, Any]) -> tuple[str, str]:
        username = str(payload.get("username") or "").strip()
        password = str(payload.get("password") or "")
        if len(username) > MAX_USERNAME_LENGTH or len(password) > PASSWORD_MAX_LENGTH:
            raise ValueError("Invalid credentials.")
        return username, password

    def _new_session_response(self, user: dict[str, Any], status: int) -> None:
        token, csrf, _ = self.state.db.create_session(user["id"], self.state.config.session_ttl_seconds)
        self._send_json(
            status,
            {"authenticated": True, "user": user, "username": user["username"], "role": user["role"], "csrf_token": csrf},
            {"Set-Cookie": self._set_session_cookie(token)},
        )

    def _auth_setup(self) -> None:
        key = self._client_key()
        if not self.state.login_limiter.allowed(key):
            self._send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "Too many attempts. Try again later.")
            return
        if self.state.db.has_users():
            self._send_error_json(HTTPStatus.CONFLICT, "Initial administrator has already been created.")
            return
        username, password = self._login_payload(self._read_json())
        try:
            user = self.state.db.create_user(username, password, role="admin", only_if_empty=True)
        except ValueError:
            self.state.login_limiter.fail(key)
            raise
        self.state.login_limiter.success(key)
        self.state.db.log(user["id"], "initial_admin_created")
        self._new_session_response(user, HTTPStatus.CREATED)

    def _auth_login(self) -> None:
        key = self._client_key()
        if not self.state.login_limiter.allowed(key):
            self._send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "Too many attempts. Try again later.")
            return
        if not self.state.db.has_users():
            self._send_error_json(HTTPStatus.CONFLICT, "Administrator setup is required.")
            return
        username, password = self._login_payload(self._read_json())
        user = self.state.db.verify_user(username, password)
        if not user:
            self.state.login_limiter.fail(key)
            time.sleep(0.25)
            self._send_error_json(HTTPStatus.UNAUTHORIZED, "Invalid username or password.")
            return
        self.state.login_limiter.success(key)
        self.state.db.log(user["id"], "login")
        self._new_session_response(user, HTTPStatus.OK)

    def _auth_logout(self) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        self.state.db.delete_session(auth[0])
        self._send_json(HTTPStatus.OK, {"authenticated": False}, {"Set-Cookie": self._clear_session_cookie()})

    def _auth_change_password(self) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        payload = self._read_json()
        current = str(payload.get("current_password") or "")
        new_password = str(payload.get("new_password") or "")
        user = auth[1]["user"]
        if not self.state.db.verify_user(user["username"], current):
            self._send_error_json(HTTPStatus.UNAUTHORIZED, "Current password is incorrect.")
            return
        self.state.db.set_password(user["id"], new_password, invalidate_sessions=False)
        self.state.db.log(user["id"], "password_changed")
        self._send_json(HTTPStatus.OK, {"updated": True})

    # Admin ---------------------------------------------------------------------
    def _update_branding(self) -> None:
        auth = self._require_admin(require_csrf=True)
        if not auth:
            return
        branding = self.state.db.set_branding(self._read_json())
        self.state.db.log(auth[1]["user"]["id"], "branding_updated", branding)
        self._send_json(HTTPStatus.OK, branding)

    def _create_user(self) -> None:
        auth = self._require_admin(require_csrf=True)
        if not auth:
            return
        payload = self._read_json()
        user = self.state.db.create_user(
            str(payload.get("username") or ""),
            str(payload.get("password") or ""),
            role=str(payload.get("role") or "teacher"),
        )
        self.state.db.log(auth[1]["user"]["id"], "user_created", {"user_id": user["id"], "role": user["role"]})
        self._send_json(HTTPStatus.CREATED, user)

    def _admin_reset_password(self, user_id: int) -> None:
        auth = self._require_admin(require_csrf=True)
        if not auth:
            return
        password = str(self._read_json().get("password") or "")
        self.state.db.set_password(user_id, password, invalidate_sessions=True)
        self.state.db.log(auth[1]["user"]["id"], "user_password_reset", {"user_id": user_id})
        self._send_json(HTTPStatus.OK, {"updated": True})

    def _admin_toggle_user(self, user_id: int) -> None:
        auth = self._require_admin(require_csrf=True)
        if not auth:
            return
        if user_id == auth[1]["user"]["id"]:
            raise ValueError("You cannot disable your own account.")
        active = bool(self._read_json().get("active", True))
        self.state.db.set_user_active(user_id, active)
        self.state.db.log(auth[1]["user"]["id"], "user_status_changed", {"user_id": user_id, "active": active})
        self._send_json(HTTPStatus.OK, {"updated": True, "active": active})

    # Workspaces and documents --------------------------------------------------
    def _create_workspace(self) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        workspace = self.state.db.create_workspace(auth[1]["user"]["id"], self._read_json())
        self.state.db.log(auth[1]["user"]["id"], "workspace_created", {"workspace_id": workspace["id"]})
        self._send_json(HTTPStatus.CREATED, workspace)

    def _update_workspace(self, workspace_id: str) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        workspace = self.state.db.update_workspace(auth[1]["user"]["id"], workspace_id, self._read_json())
        self._send_json(HTTPStatus.OK, workspace)

    def _delete_workspace(self, workspace_id: str) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        user_id = auth[1]["user"]["id"]
        documents = self.state.db.list_documents(user_id, workspace_id)
        if not self.state.db.delete_workspace(user_id, workspace_id):
            self._send_error_json(HTTPStatus.NOT_FOUND, "Workspace not found.")
            return
        for document in documents:
            self._remove_stored_file(str(document.get("storage_path") or ""))
        self._send_json(HTTPStatus.OK, {"deleted": True})

    @staticmethod
    def _safe_filename(name: str) -> str:
        base = Path(name.replace("\\", "/")).name.strip()
        base = re.sub(r"[^A-Za-z0-9._ -]+", "_", base).strip(" .")
        return (base or "document")[:180]

    def _upload_document(self, workspace_id: str) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        user_id = auth[1]["user"]["id"]
        if not self.state.db.get_workspace(user_id, workspace_id):
            self._send_error_json(HTTPStatus.NOT_FOUND, "Workspace not found.")
            return
        payload = self._read_json()
        original_name = self._safe_filename(str(payload.get("name") or ""))
        suffix = Path(original_name).suffix.lower()
        if suffix not in SUPPORTED_EXTENSIONS:
            raise ExtractionError(
                "Unsupported file type. Upload PDF, DOCX, PPTX, XLSX, EPUB, ODT, text/Markdown/CSV/HTML, or an image."
            )
        encoded = str(payload.get("data_base64") or "")
        try:
            raw = base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error) as exc:
            raise ValueError("File data is not valid base64.") from exc
        if not raw:
            raise ValueError("The uploaded file is empty.")
        if len(raw) > self.state.config.max_upload_bytes:
            raise OverflowError(
                f"File exceeds the {self.state.config.max_upload_bytes // (1024 * 1024)} MB upload limit."
            )
        storage_dir = self.state.config.upload_dir / str(user_id) / workspace_id
        storage_dir.mkdir(parents=True, exist_ok=True)
        storage_path = storage_dir / f"{uuid.uuid4().hex}-{original_name}"
        storage_path.write_bytes(raw)
        try:
            relative_path = str(storage_path.relative_to(self.state.config.data_dir))
        except ValueError:
            relative_path = str(storage_path)
        document = self.state.db.create_document_record(
            user_id=user_id,
            workspace_id=workspace_id,
            original_name=original_name,
            storage_path=relative_path,
            mime_type=str(payload.get("mime_type") or mimetypes.guess_type(original_name)[0] or "application/octet-stream"),
            size_bytes=len(raw),
        )
        try:
            options = ExtractionOptions(
                enable_ocr=self.state.config.enable_ocr,
                ocr_languages=self.state.config.ocr_languages,
                max_document_chars=self.state.config.max_document_chars,
            )
            sections, metadata = extract_document(storage_path, original_name, document["mime_type"], options)
            chunks = chunk_sections(sections)
            if not chunks:
                raise ExtractionError("No indexable text was found in this file.")
            page_count = int(
                metadata.get("pages")
                or metadata.get("slides")
                or metadata.get("sheets")
                or metadata.get("chapters")
                or metadata.get("section_count")
                or len(sections)
            )
            document = self.state.db.complete_document(
                user_id=user_id,
                document_id=document["id"],
                page_count=page_count,
                char_count=sum(len(section.text) for section in sections),
                chunks=chunks,
                metadata=metadata,
            )
            self.state.db.log(
                user_id,
                "document_uploaded",
                {"document_id": document["id"], "workspace_id": workspace_id, "name": original_name},
            )
            self._send_json(HTTPStatus.CREATED, document)
        except Exception as exc:
            self.state.db.fail_document(user_id, document["id"], str(exc))
            if isinstance(exc, (ExtractionError, ValueError, OverflowError)):
                raise
            raise ExtractionError(f"Could not process {original_name}: {exc}") from exc

    def _resolve_stored_path(self, stored: str) -> Path | None:
        if not stored:
            return None
        candidate = Path(stored)
        if not candidate.is_absolute():
            candidate = (self.state.config.data_dir / candidate).resolve()
        else:
            candidate = candidate.resolve()
        try:
            candidate.relative_to(self.state.config.upload_dir.resolve())
        except ValueError:
            return None
        return candidate

    def _remove_stored_file(self, stored: str) -> None:
        path = self._resolve_stored_path(stored)
        if path:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                LOG.warning("Could not delete stored file: %s", path)

    def _delete_document(self, document_id: str) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        document = self.state.db.delete_document(auth[1]["user"]["id"], document_id)
        if not document:
            self._send_error_json(HTTPStatus.NOT_FOUND, "Document not found.")
            return
        self._remove_stored_file(str(document.get("storage_path") or ""))
        self._send_json(HTTPStatus.OK, {"deleted": True})

    def _document_search(self) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        payload = self._read_json()
        workspace_id = str(payload.get("workspace_id") or "")
        query = " ".join(str(payload.get("query") or "").split())
        model = str(payload.get("model") or "").strip()
        if not workspace_id or not self.state.db.get_workspace(auth[1]["user"]["id"], workspace_id):
            raise ValueError("A valid workspace is required.")
        if not query:
            raise ValueError("A document search query is required.")
        if len(query) > MAX_SEARCH_QUERY_LENGTH:
            raise ValueError("Document query is too long.")
        raw_ids = payload.get("document_ids")
        document_ids = [str(value) for value in raw_ids if re.fullmatch(r"[0-9a-f]{32}", str(value))] if isinstance(raw_ids, list) else None
        limit = max(1, min(20, int(payload.get("limit") or 8)))
        queries, results = self.state.search_documents(
            user_id=auth[1]["user"]["id"],
            workspace_id=workspace_id,
            query=query,
            model=model,
            document_ids=document_ids,
            limit=limit,
        )
        response_results = []
        for index, item in enumerate(results, start=1):
            response_results.append(
                {
                    "citation": f"B{index}",
                    "document_id": item["document_id"],
                    "title": item["original_name"],
                    "locator": item["locator"],
                    "heading": item["heading"],
                    "content": item["content"],
                }
            )
        self._send_json(HTTPStatus.OK, {"queries": queries, "results": response_results})

    def _document_coverage(self) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        payload = self._read_json()
        raw_ids = payload.get("document_ids")
        if not isinstance(raw_ids, list) or not raw_ids:
            raise ValueError("Select at least one source document.")
        document_ids = [str(value) for value in raw_ids if re.fullmatch(r"[0-9a-f]{32}", str(value))]
        if not document_ids:
            raise ValueError("Select valid source documents.")
        chunks = self.state.db.coverage_chunks(
            user_id=auth[1]["user"]["id"],
            document_ids=document_ids,
            max_chars=int(payload.get("max_chars") or 32000),
            max_chunks_per_document=int(payload.get("max_chunks_per_document") or 24),
        )
        for index, item in enumerate(chunks, start=1):
            item["citation"] = f"B{index}"
        self._send_json(HTTPStatus.OK, {"results": chunks})

    def _document_segments(self) -> None:
        """Return a bounded page of extracted chunks for an exhaustive local-model pass."""
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        payload = self._read_json()
        document_id = str(payload.get("document_id") or "")
        if not re.fullmatch(r"[0-9a-f]{32}", document_id):
            raise ValueError("A valid document is required.")
        user_id = auth[1]["user"]["id"]
        document = self.state.db.get_document(user_id, document_id)
        if not document or document.get("status") != "ready":
            raise ValueError("The document is not ready or does not belong to this account.")
        try:
            offset = max(0, int(payload.get("offset") or 0))
            limit = max(1, min(60, int(payload.get("limit") or 30)))
        except (TypeError, ValueError) as exc:
            raise ValueError("Offset and limit must be integers.") from exc
        chunks = self.state.db.get_chunks(user_id, document_id)
        page = chunks[offset : offset + limit]
        output = [
            {
                "ordinal": int(item.get("ordinal") or 0),
                "locator": str(item.get("locator") or ""),
                "heading": str(item.get("heading") or ""),
                "content": str(item.get("content") or ""),
            }
            for item in page
        ]
        self._send_json(
            HTTPStatus.OK,
            {
                "document": {
                    "id": document["id"],
                    "title": document["original_name"],
                    "char_count": document.get("char_count", 0),
                    "chunk_count": len(chunks),
                },
                "offset": offset,
                "limit": limit,
                "total": len(chunks),
                "next_offset": offset + len(output) if offset + len(output) < len(chunks) else None,
                "chunks": output,
            },
        )

    def _document_compare(self) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        payload = self._read_json()
        left_id = str(payload.get("left_id") or "")
        right_id = str(payload.get("right_id") or "")
        if left_id == right_id:
            raise ValueError("Select two different documents.")
        user_id = auth[1]["user"]["id"]
        left = self.state.db.get_document(user_id, left_id)
        right = self.state.db.get_document(user_id, right_id)
        if not left or not right or left.get("status") != "ready" or right.get("status") != "ready":
            raise ValueError("Both comparison documents must be ready and belong to your workspace.")
        comparison = compare_documents(
            left,
            self.state.db.get_chunks(user_id, left_id),
            right,
            self.state.db.get_chunks(user_id, right_id),
            max_chars=int(payload.get("max_chars") or 32000),
        )
        self._send_json(HTTPStatus.OK, comparison)

    # Ollama --------------------------------------------------------------------
    def _proxy_ollama_tags(self) -> None:
        request = urllib.request.Request(
            self.state.config.ollama_base_url + "/api/tags",
            headers={"Accept": "application/json", "User-Agent": "LearningWorkspace/2.0"},
        )
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                body = response.read(8_000_000)
                status = response.status
                content_type = response.headers.get("Content-Type", "application/json; charset=utf-8")
            self._send_bytes(status, body, content_type)
        except urllib.error.HTTPError as exc:
            self._send_upstream_error(exc)
        except urllib.error.URLError as exc:
            self._send_error_json(
                HTTPStatus.BAD_GATEWAY,
                f"Cannot reach Ollama at {self.state.config.ollama_base_url}: {exc.reason}",
            )

    def _proxy_ollama_chat(self) -> None:
        if not self._require_auth(require_csrf=True):
            return
        payload = self._read_json()
        model = str(payload.get("model") or "").strip()
        messages = payload.get("messages")
        if not MODEL_NAME_RE.fullmatch(model):
            raise ValueError("A valid model is required.")
        if not isinstance(messages, list) or not messages:
            raise ValueError("At least one chat message is required.")
        if len(messages) > 300:
            raise ValueError("Too many chat messages.")
        stream = bool(payload.get("stream", False))
        allowed = {"model", "messages", "stream", "tools", "options", "format", "keep_alive", "think"}
        outbound = {key: value for key, value in payload.items() if key in allowed}
        outbound["model"] = model
        outbound["stream"] = stream
        request = urllib.request.Request(
            self.state.config.ollama_base_url + "/api/chat",
            data=json.dumps(outbound, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/x-ndjson" if stream else "application/json",
                "User-Agent": "LearningWorkspace/2.0",
            },
            method="POST",
        )
        try:
            response = urllib.request.urlopen(request, timeout=self.state.config.ollama_request_timeout)
        except urllib.error.HTTPError as exc:
            self._send_upstream_error(exc)
            return
        except urllib.error.URLError as exc:
            self._send_error_json(
                HTTPStatus.BAD_GATEWAY,
                f"Cannot reach Ollama at {self.state.config.ollama_base_url}: {exc.reason}",
            )
            return
        self._stream_or_send_upstream(response, stream)

    def _proxy_ollama_pull(self) -> None:
        if not self._require_admin(require_csrf=True):
            return
        payload = self._read_json()
        model = str(payload.get("model") or "").strip()
        if not MODEL_NAME_RE.fullmatch(model):
            raise ValueError("A valid model name is required.")
        request = urllib.request.Request(
            self.state.config.ollama_base_url + "/api/pull",
            data=json.dumps({"name": model, "stream": True}).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/x-ndjson",
                "User-Agent": "LearningWorkspace/2.0",
            },
            method="POST",
        )
        try:
            response = urllib.request.urlopen(request, timeout=7200)
        except urllib.error.HTTPError as exc:
            self._send_upstream_error(exc)
            return
        except urllib.error.URLError as exc:
            self._send_error_json(HTTPStatus.BAD_GATEWAY, f"Cannot reach Ollama: {exc.reason}")
            return
        self._stream_or_send_upstream(response, True)

    def _stream_or_send_upstream(self, response: Any, stream: bool) -> None:
        with response:
            if not stream:
                body = response.read(self.state.config.max_request_bytes)
                self._send_bytes(
                    response.status,
                    body,
                    response.headers.get("Content-Type", "application/json; charset=utf-8"),
                )
                return
            self.send_response(response.status)
            headers = self._security_headers("application/x-ndjson; charset=utf-8", "no-cache")
            headers.update({"Connection": "close", "X-Accel-Buffering": "no"})
            for key, value in headers.items():
                self.send_header(key, value)
            self.end_headers()
            self.close_connection = True
            while True:
                chunk = response.read(4096)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()

    def _send_upstream_error(self, exc: urllib.error.HTTPError) -> None:
        try:
            body = exc.read(2_000_000)
        except OSError:
            body = b""
        content_type = (
            exc.headers.get("Content-Type", "application/json; charset=utf-8")
            if exc.headers
            else "application/json; charset=utf-8"
        )
        if not body:
            body = json.dumps({"error": f"Upstream returned HTTP {exc.code}"}).encode("utf-8")
        self._send_bytes(exc.code, body, content_type)

    # Web search ----------------------------------------------------------------
    def _web_search(self) -> None:
        auth = self._require_auth(require_csrf=True)
        if not auth:
            return
        if not self.state.config.enable_web_search:
            self._send_error_json(HTTPStatus.FORBIDDEN, "Web search is disabled by server configuration.")
            return
        payload = self._read_json()
        query = " ".join(str(payload.get("query") or "").split())
        model = str(payload.get("model") or "").strip()
        if not query:
            raise ValueError("A search query is required.")
        if len(query) > MAX_SEARCH_QUERY_LENGTH:
            raise ValueError(f"Search query must be at most {MAX_SEARCH_QUERY_LENGTH} characters.")
        if model and not MODEL_NAME_RE.fullmatch(model):
            raise ValueError("Model name is invalid.")
        try:
            queries, results = self.state.search_web(query, model)
        except PermissionError as exc:
            self._send_error_json(HTTPStatus.FORBIDDEN, str(exc))
            return
        except urllib.error.HTTPError as exc:
            self._send_error_json(HTTPStatus.BAD_GATEWAY, f"Search provider returned HTTP {exc.code}.")
            return
        except urllib.error.URLError as exc:
            self._send_error_json(HTTPStatus.BAD_GATEWAY, f"Search provider is unreachable: {exc.reason}")
            return
        except RuntimeError as exc:
            self._send_error_json(HTTPStatus.SERVICE_UNAVAILABLE, str(exc))
            return
        if not results:
            self._send_error_json(HTTPStatus.NOT_FOUND, "No web search results were found.")
            return
        self.state.db.log(auth[1]["user"]["id"], "web_search", {"provider": self.state.config.web_search_provider})
        self._send_json(
            HTTPStatus.OK,
            {
                "provider": self.state.config.web_search_provider,
                "query_mode": self.state.config.web_search_query_mode,
                "queries": queries,
                "results": [item.as_dict() | {"citation": f"W{index}"} for index, item in enumerate(results, start=1)],
            },
        )


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Learning Workspace local school AI server")
    parser.add_argument("--host", help="Bind host (default: HOST or 127.0.0.1)")
    parser.add_argument("--port", type=int, help="Bind port (default: PORT or 8787)")
    parser.add_argument("--ollama-url", help="Ollama base URL")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--enable-web-search", action="store_true", help="Enable web search")
    group.add_argument("--disable-web-search", action="store_true", help="Disable web search")
    parser.add_argument("--web-search-provider", help="duckduckgo, searxng, brave, serper, tavily, google_cse, ollama_cloud")
    parser.add_argument("--web-results", type=int, help="Number of web results (1-12)")
    parser.add_argument("--create-admin", metavar="USERNAME", help="Create an administrator, then exit")
    parser.add_argument("--create-teacher", metavar="USERNAME", help="Create a teacher, then exit")
    parser.add_argument("--reset-password", metavar="USERNAME", help="Reset a user's password, then exit")
    parser.add_argument("--list-users", action="store_true", help="List users, then exit")
    return parser


def prompt_password(confirm: bool = True) -> str:
    password = getpass.getpass("Password: ")
    Database.validate_password(password)
    if confirm:
        repeated = getpass.getpass("Confirm password: ")
        if not hmac.compare_digest(password, repeated):
            raise ValueError("Passwords do not match.")
    return password


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )


def main(argv: list[str] | None = None) -> int:
    load_dotenv(APP_DIR / ".env")
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    try:
        config = AppConfig.from_env(args)
    except ValueError as exc:
        parser.error(str(exc))
        return 2
    configure_logging(config.log_level)
    config.data_dir.mkdir(parents=True, exist_ok=True)
    config.upload_dir.mkdir(parents=True, exist_ok=True)
    db = Database(config.database_path)
    imported = db.import_legacy_users(config.data_dir / "users.json")
    if imported:
        LOG.info("Migrated %s legacy account(s) from users.json into SQLite", imported)

    try:
        if args.list_users:
            for user in db.list_users():
                print(f"{user['username']}\t{user['role']}\t{'active' if user['active'] else 'disabled'}")
            return 0
        if args.create_admin or args.create_teacher:
            username = args.create_admin or args.create_teacher
            role = "admin" if args.create_admin else "teacher"
            user = db.create_user(username, prompt_password(), role=role)
            print(f"Created {role}: {user['username']}")
            return 0
        if args.reset_password:
            db.set_password_by_username(args.reset_password, prompt_password())
            print(f"Password updated: {args.reset_password}")
            return 0
    except (ValueError, RuntimeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    state = AppState(config=config, db=db)
    try:
        state.bootstrap_admin_from_environment()
    except (ValueError, RuntimeError) as exc:
        LOG.error("Administrator bootstrap failed: %s", exc)
        return 1

    try:
        server = LearningHTTPServer((config.host, config.port), LearningHandler, state)
    except OSError as exc:
        LOG.error("Could not bind to %s:%s: %s", config.host, config.port, exc)
        return 1

    stopping = threading.Event()

    def shutdown(signum: int, _frame: Any) -> None:
        if stopping.is_set():
            return
        stopping.set()
        LOG.info("Received signal %s; shutting down", signum)
        threading.Thread(target=server.shutdown, daemon=True).start()

    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, shutdown)

    LOG.info("Learning Workspace listening on http://%s:%s", config.host, config.port)
    LOG.info("Database: %s", config.database_path)
    LOG.info("Ollama endpoint: %s", config.ollama_base_url)
    LOG.info(
        "Web search: %s (%s, ready=%s, page extraction=%s)",
        "enabled" if config.enable_web_search else "disabled",
        config.web_search_provider,
        state.provider_ready(),
        config.web_fetch_pages,
    )
    LOG.info("OCR: %s (%s)", "enabled" if config.enable_ocr else "disabled", config.ocr_languages)
    if not db.has_users():
        LOG.warning("First-run administrator setup is required in the browser.")
    if config.host not in {"127.0.0.1", "localhost", "::1"} and not config.cookie_secure:
        LOG.warning("Network access is enabled without secure cookies. Use HTTPS and COOKIE_SECURE=true.")

    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
