# School Workflows

Learning Workspace is organized around the work a teacher performs with syllabus material. It intentionally avoids timetable and school-management functions.

## Teacher workspaces

Each user receives an independent default workspace and can create more workspaces, for example:

- Grade 7 Science — 2026/27
- Grade 8 Science — 2026/27
- Grade 6 Mathematics — Term 1
- English — Reading assessments

Documents and searches are restricted to the signed-in teacher's workspaces. Administrators provision accounts and branding; they do not receive a cross-teacher document browser in this release.

## Book Library

Supported source types:

- PDF
- DOCX
- PPTX
- XLSX and XLSM
- EPUB
- ODT
- HTML
- Markdown and plain text
- CSV, JSON, XML, and similar text files
- PNG, JPEG, WebP, TIFF, and BMP through OCR

The server extracts text, preserves page/slide/sheet/section locators, splits material into overlapping chunks, and indexes those chunks in SQLite FTS5 when available.

A normal textbook is well below the default 8,000,000-character extraction ceiling. When a source reaches the configured ceiling, the library shows **content limit reached** rather than silently claiming complete coverage. Raise `MAX_DOCUMENT_CHARS` and re-upload that file before using Full-book pass.

For PDF books, the extractor removes only repeated edge lines that look like recurring headers or footers. It does not remove the original file.

## AI Assistant

The **Books** switch controls whether selected workspace books are retrieved for a prompt. The assistant provides `[B1]`, `[B2]`, and similar citations back to book titles and page or section locators.

The **Web** switch is independent. When enabled, web sources receive `[W1]`, `[W2]`, and similar citations. The local model receives both book and web evidence as untrusted reference material and is instructed not to follow instructions embedded inside that material.

## Textbook and curriculum comparison

The Book Library includes two levels of comparison:

1. **Structure scan** — deterministic headings, distinctive terms, and evenly distributed passages. This works without a model response and gives the model a broad comparison frame.
2. **AI explanation** — the selected local model interprets the structure scan and cited samples, while distinguishing verified differences from uncertain inferences.

Teacher Studio's **Curriculum comparison** can run with Full-book pass to process every extracted chunk from exactly two selected books. This is the preferred mode for grade-to-grade progression questions such as:

- What new concepts appear in Grade 8?
- Which Grade 7 concepts are assumed rather than retaught?
- What terminology, examples, activity types, and assessment expectations changed?
- Which topics moved earlier or later?
- What bridging lesson is required?

## Standard evidence mode

Standard mode is designed for speed. It takes a bounded set of chunks distributed across each selected document and relevant search hits. Use it for:

- a lesson on a known chapter;
- a worksheet on a specific topic;
- a short answer key;
- a targeted book question;
- routine chat.

It is not an exhaustive proof that a topic is absent from a long book.

## Full-book pass

Full-book pass performs a local map-reduce workflow:

1. The browser retrieves every indexed chunk from each selected document.
2. Chunks are grouped into bounded batches.
3. The local model creates dense coverage notes for every batch while preserving `[D#:C#]` citations.
4. Very large coverage notes are recursively condensed without intentionally dropping unique topics or citations.
5. The final workflow uses the consolidated notes.

The release limits Full-book pass to six documents at a time. A long book can require many local-model calls and may take substantially longer on a CPU. Use a more capable model and keep the computer connected to power for large comparisons.

“Every indexed chunk” does not mean every visual or handwritten detail in the original was extracted. Inspect OCR pages, diagrams, equations, tables, and unusual layouts manually.

## Lesson-plan draft

The lesson workflow requests:

- measurable objectives;
- prerequisite knowledge;
- vocabulary and resources;
- a timed sequence;
- teacher and student actions;
- checks for understanding;
- likely misconceptions;
- support and extension;
- formative assessment;
- closure and follow-up.

The generated plan is a draft. The teacher remains responsible for curriculum alignment, class context, safeguarding, accessibility, and local policy.

## Question paper

The question-paper workflow asks for a duration, total marks, grade, subject, topic, language, and teacher instructions. The model is instructed to:

- balance question types and difficulty;
- map questions to stated outcomes;
- put a mark value on every item;
- verify that marks sum to the requested total;
- keep the student paper separate from a teacher-only blueprint.

The teacher must still check the arithmetic, reading level, ambiguity, source coverage, answerability, cultural appropriateness, and school assessment policy.

## Answer key and rubric

The answer-key workflow requests expected answers, essential points, acceptable alternatives, common errors, partial-credit rules, exact mark splits, and moderation notes.

For best results, select the source book plus the question paper. Include the school's existing rubric as another uploaded document when available.

## Worksheet or quiz

The worksheet workflow progresses from warm-up and guided practice to independent work, misconception checks, and a challenge item, followed by a concise teacher answer section.

## Answer-paper review and suggested marking

The marking workflow is designed as a teacher decision-support tool, not an autonomous grading authority. Upload or select:

- the question paper;
- the answer key or rubric;
- the relevant book or syllabus;
- the student's answer paper.

For image-based or handwritten submissions, OCR may misread names, symbols, equations, diagrams, and handwriting. The result includes suggested marks, reasoning, evidence, feedback, and flags for items that require human verification. The teacher must decide and publish the final mark.

Avoid including unnecessary student identifiers. Follow the school's retention, consent, and access-control requirements.

## Web-assisted preparation

Web search is most useful for:

- current examples and statistics;
- primary-source references;
- recent science or technology developments;
- alternate explanations;
- fact checking beyond an older textbook.

Uploaded books should remain the authority for syllabus-specific questions unless the teacher explicitly asks to update or challenge them. Search results are external and can be inaccurate, unsuitable, or malicious. Check the cited page before using it in class material.

## What is not included

- Timetabling
- Attendance
- Admissions
- Fees or payroll
- Parent communication
- Student information records
- Automated final-grade publication
- Plagiarism adjudication
- Exam-proctoring or surveillance

Those functions should remain in dedicated school systems with their own governance and audit requirements.
