#!/usr/bin/env python3
"""SQLite persistence for Learning Workspace.

The database stores users, durable sessions, branding, teacher workspaces,
document metadata, and a local full-text index. Passwords are never stored in
plaintext.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator

PASSWORD_MIN_LENGTH = 12
PASSWORD_MAX_LENGTH = 256
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{3,64}$")
HEX_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")

DEFAULT_BRANDING: dict[str, str] = {
    "app_name": "Learning Workspace",
    "school_name": "",
    "tagline": "Private AI tools for teaching and learning",
    "logo_text": "LW",
    "theme_style": "school",
    "primary_color": "#4169E1",
    "accent_color": "#F59E0B",
    "login_message": "Sign in to your private teaching workspace.",
    "welcome_title": "Your teaching workspace",
    "welcome_text": "Upload textbooks, compare editions, prepare lessons and assessments, and review student answers with your local AI model.",
}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


class Database:
    """Thread-safe SQLite facade using short-lived connections."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._write_lock = threading.RLock()
        self.fts_available = True
        self._initialize()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 30000")
        try:
            yield conn
        finally:
            conn.close()

    def _initialize(self) -> None:
        with self._write_lock, self.connect() as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    role TEXT NOT NULL DEFAULT 'teacher' CHECK(role IN ('admin','teacher')),
                    password_salt BLOB NOT NULL,
                    password_hash BLOB NOT NULL,
                    scrypt_n INTEGER NOT NULL DEFAULT 16384,
                    scrypt_r INTEGER NOT NULL DEFAULT 8,
                    scrypt_p INTEGER NOT NULL DEFAULT 1,
                    active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    password_updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS sessions (
                    token_hash TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    csrf_token TEXT NOT NULL,
                    expires_at REAL NOT NULL,
                    created_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS workspaces (
                    id TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    name TEXT NOT NULL,
                    grade TEXT NOT NULL DEFAULT '',
                    subject TEXT NOT NULL DEFAULT '',
                    academic_year TEXT NOT NULL DEFAULT '',
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_workspaces_user ON workspaces(user_id, updated_at DESC);

                CREATE TABLE IF NOT EXISTS documents (
                    id TEXT PRIMARY KEY,
                    workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    original_name TEXT NOT NULL,
                    storage_path TEXT NOT NULL,
                    mime_type TEXT NOT NULL DEFAULT '',
                    size_bytes INTEGER NOT NULL DEFAULT 0,
                    page_count INTEGER NOT NULL DEFAULT 0,
                    char_count INTEGER NOT NULL DEFAULT 0,
                    chunk_count INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'processing',
                    error TEXT NOT NULL DEFAULT '',
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_documents_workspace ON documents(workspace_id, created_at DESC);

                CREATE TABLE IF NOT EXISTS document_chunks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
                    workspace_id TEXT NOT NULL,
                    user_id INTEGER NOT NULL,
                    ordinal INTEGER NOT NULL,
                    locator TEXT NOT NULL DEFAULT '',
                    heading TEXT NOT NULL DEFAULT '',
                    content TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_chunks_document ON document_chunks(document_id, ordinal);
                CREATE INDEX IF NOT EXISTS idx_chunks_workspace ON document_chunks(workspace_id, user_id);

                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    action TEXT NOT NULL,
                    details_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                """
            )
            try:
                conn.execute(
                    """
                    CREATE VIRTUAL TABLE IF NOT EXISTS document_chunks_fts USING fts5(
                        content,
                        heading,
                        document_id UNINDEXED,
                        chunk_id UNINDEXED,
                        workspace_id UNINDEXED,
                        user_id UNINDEXED,
                        locator UNINDEXED,
                        tokenize='unicode61 remove_diacritics 2'
                    )
                    """
                )
            except sqlite3.OperationalError:
                self.fts_available = False
            conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (time.time(),))
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    @staticmethod
    def validate_username(username: str) -> str:
        value = username.strip()
        if not USERNAME_RE.fullmatch(value):
            raise ValueError("Username must be 3-64 characters using letters, numbers, dot, underscore, or hyphen.")
        return value

    @staticmethod
    def validate_password(password: str) -> None:
        if len(password) < PASSWORD_MIN_LENGTH:
            raise ValueError(f"Password must contain at least {PASSWORD_MIN_LENGTH} characters.")
        if len(password) > PASSWORD_MAX_LENGTH:
            raise ValueError(f"Password must contain at most {PASSWORD_MAX_LENGTH} characters.")

    @staticmethod
    def _derive(password: str, salt: bytes, n: int = 2**14, r: int = 8, p: int = 1) -> bytes:
        return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=n, r=r, p=p, dklen=32)

    def has_users(self) -> bool:
        with self.connect() as conn:
            return conn.execute("SELECT 1 FROM users WHERE active=1 LIMIT 1").fetchone() is not None

    def create_user(self, username: str, password: str, role: str = "teacher", only_if_empty: bool = False) -> dict[str, Any]:
        username = self.validate_username(username)
        self.validate_password(password)
        role = role if role in {"admin", "teacher"} else "teacher"
        salt = secrets.token_bytes(16)
        digest = self._derive(password, salt)
        now = utc_now_iso()
        with self._write_lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                if only_if_empty and conn.execute("SELECT 1 FROM users LIMIT 1").fetchone():
                    raise ValueError("Initial administrator has already been created.")
                cursor = conn.execute(
                    """
                    INSERT INTO users(username, role, password_salt, password_hash, created_at, password_updated_at)
                    VALUES(?,?,?,?,?,?)
                    """,
                    (username, role, salt, digest, now, now),
                )
                user_id = int(cursor.lastrowid)
                self._create_default_workspace_conn(conn, user_id)
                conn.execute("COMMIT")
            except sqlite3.IntegrityError as exc:
                conn.execute("ROLLBACK")
                raise ValueError("That username already exists.") from exc
            except Exception:
                conn.execute("ROLLBACK")
                raise
        return {"id": user_id, "username": username, "role": role, "active": True, "created_at": now}

    def import_legacy_users(self, legacy_path: Path) -> int:
        """Import the previous build's JSON password records without knowing passwords."""
        if not legacy_path.exists() or self.has_users():
            return 0
        try:
            payload = json.loads(legacy_path.read_text(encoding="utf-8"))
            records = payload.get("users", [])
        except (OSError, json.JSONDecodeError, AttributeError):
            return 0
        imported = 0
        with self._write_lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                for item in records:
                    try:
                        username = self.validate_username(str(item["username"]))
                        role = str(item.get("role") or "admin")
                        if role not in {"admin", "teacher"}:
                            role = "teacher"
                        salt = base64.b64decode(item["salt"], validate=True)
                        digest = base64.b64decode(item["hash"], validate=True)
                        params = item.get("scrypt") or {}
                        created = str(item.get("created_at") or utc_now_iso())
                        updated = str(item.get("password_updated_at") or created)
                        cursor = conn.execute(
                            """
                            INSERT OR IGNORE INTO users(
                                username, role, password_salt, password_hash,
                                scrypt_n, scrypt_r, scrypt_p, created_at, password_updated_at
                            ) VALUES(?,?,?,?,?,?,?,?,?)
                            """,
                            (
                                username,
                                role,
                                salt,
                                digest,
                                int(params.get("n", 2**14)),
                                int(params.get("r", 8)),
                                int(params.get("p", 1)),
                                created,
                                updated,
                            ),
                        )
                        if cursor.rowcount:
                            self._create_default_workspace_conn(conn, int(cursor.lastrowid))
                            imported += 1
                    except (KeyError, ValueError, TypeError):
                        continue
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        if imported:
            try:
                legacy_path.rename(legacy_path.with_suffix(legacy_path.suffix + ".migrated"))
            except OSError:
                pass
        return imported

    def verify_user(self, username: str, password: str) -> dict[str, Any] | None:
        fallback_salt = b"LearningWorkspace"
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM users WHERE username=? COLLATE NOCASE AND active=1",
                (username.strip(),),
            ).fetchone()
        if row is None:
            self._derive(password[:PASSWORD_MAX_LENGTH], fallback_salt)
            return None
        try:
            actual = self._derive(
                password[:PASSWORD_MAX_LENGTH],
                bytes(row["password_salt"]),
                n=int(row["scrypt_n"]),
                r=int(row["scrypt_r"]),
                p=int(row["scrypt_p"]),
            )
        except (ValueError, TypeError):
            return None
        if not hmac.compare_digest(actual, bytes(row["password_hash"])):
            return None
        return self._public_user(row)

    def get_user(self, user_id: int) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM users WHERE id=? AND active=1", (user_id,)).fetchone()
        return self._public_user(row) if row else None

    @staticmethod
    def _public_user(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": int(row["id"]),
            "username": str(row["username"]),
            "role": str(row["role"]),
            "active": bool(row["active"]),
            "created_at": str(row["created_at"]),
        }

    def list_users(self) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT id, username, role, active, created_at FROM users ORDER BY username COLLATE NOCASE"
            ).fetchall()
        return [dict(row) | {"active": bool(row["active"])} for row in rows]

    def set_password(self, user_id: int, password: str, invalidate_sessions: bool = True) -> None:
        self.validate_password(password)
        salt = secrets.token_bytes(16)
        digest = self._derive(password, salt)
        with self._write_lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute(
                """
                UPDATE users SET password_salt=?, password_hash=?, scrypt_n=?, scrypt_r=?, scrypt_p=?, password_updated_at=?
                WHERE id=? AND active=1
                """,
                (salt, digest, 2**14, 8, 1, utc_now_iso(), user_id),
            )
            if cursor.rowcount != 1:
                conn.execute("ROLLBACK")
                raise ValueError("User not found.")
            if invalidate_sessions:
                conn.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
            conn.execute("COMMIT")

    def set_password_by_username(self, username: str, password: str) -> None:
        username = self.validate_username(username)
        with self.connect() as conn:
            row = conn.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
        if not row:
            raise ValueError("User not found.")
        self.set_password(int(row["id"]), password)

    def set_user_active(self, user_id: int, active: bool) -> None:
        with self._write_lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute("UPDATE users SET active=? WHERE id=?", (1 if active else 0, user_id))
            if cursor.rowcount != 1:
                conn.execute("ROLLBACK")
                raise ValueError("User not found.")
            if not active:
                conn.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
            conn.execute("COMMIT")

    # Sessions -----------------------------------------------------------------
    def create_session(self, user_id: int, ttl_seconds: int) -> tuple[str, str, float]:
        raw_token = secrets.token_urlsafe(36)
        csrf = secrets.token_urlsafe(24)
        expires = time.time() + ttl_seconds
        now = utc_now_iso()
        with self._write_lock, self.connect() as conn:
            conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (time.time(),))
            conn.execute(
                """
                INSERT INTO sessions(token_hash, user_id, csrf_token, expires_at, created_at, last_seen_at)
                VALUES(?,?,?,?,?,?)
                """,
                (_token_hash(raw_token), user_id, csrf, expires, now, now),
            )
        return raw_token, csrf, expires

    def get_session(self, raw_token: str | None, ttl_seconds: int, slide: bool = True) -> dict[str, Any] | None:
        if not raw_token:
            return None
        now_ts = time.time()
        with self._write_lock, self.connect() as conn:
            row = conn.execute(
                """
                SELECT s.token_hash, s.csrf_token, s.expires_at, u.id, u.username, u.role, u.active, u.created_at
                FROM sessions s JOIN users u ON u.id=s.user_id
                WHERE s.token_hash=? AND s.expires_at>? AND u.active=1
                """,
                (_token_hash(raw_token), now_ts),
            ).fetchone()
            if row is None:
                return None
            expires = float(row["expires_at"])
            if slide:
                expires = now_ts + ttl_seconds
                conn.execute(
                    "UPDATE sessions SET expires_at=?, last_seen_at=? WHERE token_hash=?",
                    (expires, utc_now_iso(), row["token_hash"]),
                )
        return {
            "token_hash": str(row["token_hash"]),
            "csrf_token": str(row["csrf_token"]),
            "expires_at": expires,
            "user": {
                "id": int(row["id"]),
                "username": str(row["username"]),
                "role": str(row["role"]),
                "active": bool(row["active"]),
                "created_at": str(row["created_at"]),
            },
        }

    def delete_session(self, raw_token: str | None) -> None:
        if not raw_token:
            return
        with self._write_lock, self.connect() as conn:
            conn.execute("DELETE FROM sessions WHERE token_hash=?", (_token_hash(raw_token),))

    # Settings / branding -------------------------------------------------------
    def get_setting(self, key: str, default: Any = None) -> Any:
        with self.connect() as conn:
            row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if row is None:
            return default
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            return default

    def set_setting(self, key: str, value: Any) -> None:
        now = utc_now_iso()
        with self._write_lock, self.connect() as conn:
            conn.execute(
                """
                INSERT INTO settings(key, value, updated_at) VALUES(?,?,?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
                """,
                (key, _json(value), now),
            )

    def get_branding(self) -> dict[str, str]:
        custom = self.get_setting("branding", {})
        result = dict(DEFAULT_BRANDING)
        if isinstance(custom, dict):
            for key in result:
                if key in custom:
                    result[key] = str(custom[key])
        return result

    def set_branding(self, payload: dict[str, Any]) -> dict[str, str]:
        result = self.get_branding()
        limits = {
            "app_name": 60,
            "school_name": 80,
            "tagline": 140,
            "logo_text": 4,
            "login_message": 220,
            "welcome_title": 100,
            "welcome_text": 500,
        }
        for key, limit in limits.items():
            if key in payload:
                result[key] = str(payload[key]).strip()[:limit]
        if not result["app_name"]:
            result["app_name"] = DEFAULT_BRANDING["app_name"]
        result["logo_text"] = (result["logo_text"] or "LW")[:4].upper()
        style = str(payload.get("theme_style", result["theme_style"])).strip().lower()
        result["theme_style"] = style if style in {"school", "tech", "professional"} else "school"
        for key in ("primary_color", "accent_color"):
            value = str(payload.get(key, result[key])).strip()
            if not HEX_COLOR_RE.fullmatch(value):
                raise ValueError(f"{key.replace('_', ' ').title()} must be a six-digit hex color such as #4169E1.")
            result[key] = value.upper()
        self.set_setting("branding", result)
        return result

    # Workspaces ----------------------------------------------------------------
    def _create_default_workspace_conn(self, conn: sqlite3.Connection, user_id: int) -> str:
        workspace_id = uuid.uuid4().hex
        now = utc_now_iso()
        conn.execute(
            """
            INSERT INTO workspaces(id, user_id, name, grade, subject, academic_year, notes, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?)
            """,
            (workspace_id, user_id, "My Teaching Workspace", "", "", "", "", now, now),
        )
        return workspace_id

    def list_workspaces(self, user_id: int) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT w.*, COUNT(d.id) AS document_count
                FROM workspaces w LEFT JOIN documents d ON d.workspace_id=w.id AND d.status='ready'
                WHERE w.user_id=? GROUP BY w.id ORDER BY w.updated_at DESC, w.name COLLATE NOCASE
                """,
                (user_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def get_workspace(self, user_id: int, workspace_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM workspaces WHERE id=? AND user_id=?", (workspace_id, user_id)).fetchone()
        return dict(row) if row else None

    def create_workspace(self, user_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        name = str(payload.get("name") or "").strip()[:120]
        if not name:
            raise ValueError("Workspace name is required.")
        workspace_id = uuid.uuid4().hex
        now = utc_now_iso()
        values = (
            workspace_id,
            user_id,
            name,
            str(payload.get("grade") or "").strip()[:60],
            str(payload.get("subject") or "").strip()[:100],
            str(payload.get("academic_year") or "").strip()[:40],
            str(payload.get("notes") or "").strip()[:1000],
            now,
            now,
        )
        with self._write_lock, self.connect() as conn:
            conn.execute(
                """
                INSERT INTO workspaces(id,user_id,name,grade,subject,academic_year,notes,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                """,
                values,
            )
        return self.get_workspace(user_id, workspace_id) or {}

    def update_workspace(self, user_id: int, workspace_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        existing = self.get_workspace(user_id, workspace_id)
        if not existing:
            raise ValueError("Workspace not found.")
        name = str(payload.get("name", existing["name"])).strip()[:120]
        if not name:
            raise ValueError("Workspace name is required.")
        values = (
            name,
            str(payload.get("grade", existing["grade"])).strip()[:60],
            str(payload.get("subject", existing["subject"])).strip()[:100],
            str(payload.get("academic_year", existing["academic_year"])).strip()[:40],
            str(payload.get("notes", existing["notes"])).strip()[:1000],
            utc_now_iso(),
            workspace_id,
            user_id,
        )
        with self._write_lock, self.connect() as conn:
            conn.execute(
                """
                UPDATE workspaces SET name=?, grade=?, subject=?, academic_year=?, notes=?, updated_at=?
                WHERE id=? AND user_id=?
                """,
                values,
            )
        return self.get_workspace(user_id, workspace_id) or {}

    def delete_workspace(self, user_id: int, workspace_id: str) -> bool:
        with self._write_lock, self.connect() as conn:
            count = conn.execute("SELECT COUNT(*) FROM workspaces WHERE user_id=?", (user_id,)).fetchone()[0]
            if count <= 1:
                raise ValueError("Keep at least one workspace. Rename the current workspace instead.")
            document_ids = [row[0] for row in conn.execute("SELECT id FROM documents WHERE workspace_id=? AND user_id=?", (workspace_id, user_id))]
            conn.execute("BEGIN IMMEDIATE")
            if self.fts_available:
                for doc_id in document_ids:
                    conn.execute("DELETE FROM document_chunks_fts WHERE document_id=?", (doc_id,))
            cursor = conn.execute("DELETE FROM workspaces WHERE id=? AND user_id=?", (workspace_id, user_id))
            conn.execute("COMMIT")
            return cursor.rowcount == 1

    # Documents -----------------------------------------------------------------
    def create_document_record(
        self,
        *,
        user_id: int,
        workspace_id: str,
        original_name: str,
        storage_path: str,
        mime_type: str,
        size_bytes: int,
    ) -> dict[str, Any]:
        if not self.get_workspace(user_id, workspace_id):
            raise ValueError("Workspace not found.")
        document_id = uuid.uuid4().hex
        now = utc_now_iso()
        with self._write_lock, self.connect() as conn:
            conn.execute(
                """
                INSERT INTO documents(
                    id,workspace_id,user_id,original_name,storage_path,mime_type,size_bytes,status,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    document_id,
                    workspace_id,
                    user_id,
                    original_name[:255],
                    storage_path,
                    mime_type[:160],
                    int(size_bytes),
                    "processing",
                    now,
                    now,
                ),
            )
        return self.get_document(user_id, document_id) or {}

    def complete_document(
        self,
        *,
        user_id: int,
        document_id: str,
        page_count: int,
        char_count: int,
        chunks: Iterable[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        chunk_list = list(chunks)
        with self._write_lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT workspace_id FROM documents WHERE id=? AND user_id=?",
                (document_id, user_id),
            ).fetchone()
            if row is None:
                conn.execute("ROLLBACK")
                raise ValueError("Document not found.")
            workspace_id = str(row["workspace_id"])
            conn.execute("DELETE FROM document_chunks WHERE document_id=?", (document_id,))
            if self.fts_available:
                conn.execute("DELETE FROM document_chunks_fts WHERE document_id=?", (document_id,))
            for ordinal, chunk in enumerate(chunk_list):
                cursor = conn.execute(
                    """
                    INSERT INTO document_chunks(document_id,workspace_id,user_id,ordinal,locator,heading,content)
                    VALUES(?,?,?,?,?,?,?)
                    """,
                    (
                        document_id,
                        workspace_id,
                        user_id,
                        ordinal,
                        str(chunk.get("locator") or "")[:120],
                        str(chunk.get("heading") or "")[:300],
                        str(chunk.get("content") or ""),
                    ),
                )
                if self.fts_available:
                    conn.execute(
                        """
                        INSERT INTO document_chunks_fts(content,heading,document_id,chunk_id,workspace_id,user_id,locator)
                        VALUES(?,?,?,?,?,?,?)
                        """,
                        (
                            str(chunk.get("content") or ""),
                            str(chunk.get("heading") or ""),
                            document_id,
                            str(cursor.lastrowid),
                            workspace_id,
                            str(user_id),
                            str(chunk.get("locator") or ""),
                        ),
                    )
            conn.execute(
                """
                UPDATE documents SET page_count=?, char_count=?, chunk_count=?, status='ready', error='', metadata_json=?, updated_at=?
                WHERE id=? AND user_id=?
                """,
                (page_count, char_count, len(chunk_list), _json(metadata), utc_now_iso(), document_id, user_id),
            )
            conn.execute("UPDATE workspaces SET updated_at=? WHERE id=?", (utc_now_iso(), workspace_id))
            conn.execute("COMMIT")
        return self.get_document(user_id, document_id) or {}

    def fail_document(self, user_id: int, document_id: str, error: str) -> None:
        with self._write_lock, self.connect() as conn:
            conn.execute(
                "UPDATE documents SET status='error', error=?, updated_at=? WHERE id=? AND user_id=?",
                (error[:1000], utc_now_iso(), document_id, user_id),
            )

    @staticmethod
    def _document_dict(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        try:
            item["metadata"] = json.loads(item.pop("metadata_json", "{}"))
        except json.JSONDecodeError:
            item["metadata"] = {}
        return item

    def get_document(self, user_id: int, document_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM documents WHERE id=? AND user_id=?", (document_id, user_id)).fetchone()
        return self._document_dict(row) if row else None

    def list_documents(self, user_id: int, workspace_id: str) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM documents WHERE workspace_id=? AND user_id=? ORDER BY created_at DESC",
                (workspace_id, user_id),
            ).fetchall()
        return [self._document_dict(row) for row in rows]

    def delete_document(self, user_id: int, document_id: str) -> dict[str, Any] | None:
        document = self.get_document(user_id, document_id)
        if not document:
            return None
        with self._write_lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            if self.fts_available:
                conn.execute("DELETE FROM document_chunks_fts WHERE document_id=?", (document_id,))
            conn.execute("DELETE FROM documents WHERE id=? AND user_id=?", (document_id, user_id))
            conn.execute("COMMIT")
        return document

    def get_chunks(self, user_id: int, document_id: str) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT c.*, d.original_name FROM document_chunks c JOIN documents d ON d.id=c.document_id
                WHERE c.document_id=? AND c.user_id=? ORDER BY c.ordinal
                """,
                (document_id, user_id),
            ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _search_tokens(query: str) -> list[str]:
        stop = {
            "the", "and", "for", "with", "from", "that", "this", "what", "when", "where", "which", "who",
            "are", "was", "were", "will", "would", "could", "should", "into", "about", "than", "then", "how",
            "can", "does", "did", "have", "has", "had", "your", "their", "there", "these", "those", "please",
        }
        tokens = [token.casefold() for token in re.findall(r"[^\W_][\w'-]{1,40}", query, flags=re.UNICODE)]
        filtered = [token for token in tokens if token not in stop and len(token) >= 2]
        return list(dict.fromkeys(filtered))[:16]

    def search_chunks(
        self,
        *,
        user_id: int,
        workspace_id: str,
        query: str,
        document_ids: list[str] | None = None,
        limit: int = 8,
    ) -> list[dict[str, Any]]:
        limit = max(1, min(30, int(limit)))
        tokens = self._search_tokens(query)
        params: list[Any] = []
        doc_filter = ""
        if document_ids:
            placeholders = ",".join("?" for _ in document_ids)
            doc_filter = f" AND c.document_id IN ({placeholders})"
        if self.fts_available and tokens:
            match = " OR ".join('"' + token.replace('"', '""') + '"' for token in tokens)
            sql = f"""
                SELECT c.id, c.document_id, c.ordinal, c.locator, c.heading, c.content,
                       d.original_name, bm25(document_chunks_fts, 1.0, 1.5) AS score
                FROM document_chunks_fts
                JOIN document_chunks c ON c.id=CAST(document_chunks_fts.chunk_id AS INTEGER)
                JOIN documents d ON d.id=c.document_id
                WHERE document_chunks_fts MATCH ? AND c.workspace_id=? AND c.user_id=? {doc_filter}
                ORDER BY score ASC LIMIT ?
            """
            params = [match, workspace_id, user_id]
            if document_ids:
                params.extend(document_ids)
            params.append(limit)
            try:
                with self.connect() as conn:
                    rows = conn.execute(sql, params).fetchall()
                if rows:
                    return [dict(row) for row in rows]
            except sqlite3.OperationalError:
                pass

        # Unicode-aware fallback for queries that FTS cannot parse or match.
        terms = tokens or [query.strip().casefold()]
        with self.connect() as conn:
            sql = f"""
                SELECT c.id, c.document_id, c.ordinal, c.locator, c.heading, c.content, d.original_name
                FROM document_chunks c JOIN documents d ON d.id=c.document_id
                WHERE c.workspace_id=? AND c.user_id=? {doc_filter}
                ORDER BY c.document_id, c.ordinal
            """
            params = [workspace_id, user_id]
            if document_ids:
                params.extend(document_ids)
            rows = conn.execute(sql, params).fetchall()
        ranked: list[tuple[float, sqlite3.Row]] = []
        for row in rows:
            haystack = (str(row["heading"]) + " " + str(row["content"])).casefold()
            score = sum(haystack.count(term) for term in terms if term)
            if score:
                ranked.append((-float(score), row))
        ranked.sort(key=lambda item: (item[0], int(item[1]["ordinal"])))
        result: list[dict[str, Any]] = []
        for score, row in ranked[:limit]:
            item = dict(row)
            item["score"] = score
            result.append(item)
        return result

    def coverage_chunks(
        self,
        *,
        user_id: int,
        document_ids: list[str],
        max_chars: int = 30000,
        max_chunks_per_document: int = 24,
    ) -> list[dict[str, Any]]:
        max_chars = max(2000, min(120000, int(max_chars)))
        output: list[dict[str, Any]] = []
        used = 0
        for document_id in document_ids[:12]:
            chunks = self.get_chunks(user_id, document_id)
            if not chunks:
                continue
            count = min(max_chunks_per_document, len(chunks))
            if count == 1:
                indices = [0]
            else:
                indices = sorted({round(i * (len(chunks) - 1) / (count - 1)) for i in range(count)})
            for index in indices:
                item = chunks[index]
                text = str(item["content"])
                remaining = max_chars - used
                if remaining <= 0:
                    return output
                if len(text) > remaining:
                    text = text[:remaining]
                output.append(
                    {
                        "document_id": document_id,
                        "title": item["original_name"],
                        "locator": item["locator"],
                        "heading": item["heading"],
                        "content": text,
                        "ordinal": item["ordinal"],
                    }
                )
                used += len(text)
                if used >= max_chars:
                    return output
        return output

    def log(self, user_id: int | None, action: str, details: dict[str, Any] | None = None) -> None:
        with self._write_lock, self.connect() as conn:
            conn.execute(
                "INSERT INTO audit_log(user_id, action, details_json, created_at) VALUES(?,?,?,?)",
                (user_id, action[:100], _json(details or {}), utc_now_iso()),
            )
