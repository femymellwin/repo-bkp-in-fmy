from __future__ import annotations

import base64
import http.client
import json
import sqlite3
import tempfile
import threading
import unittest
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from server import AppConfig, AppState, LearningHTTPServer, LearningHandler
from storage import Database


class FakeServicesHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, _fmt: str, *_args: Any) -> None:
        return

    def send_json(self, payload: Any, status: int = 200, content_type: str = "application/json") -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/api/tags"):
            self.send_json({"models": [{"name": "qwen3:1.7b", "size": 1_400_000_000}]})
            return
        if self.path.startswith("/search?"):
            self.send_json(
                {
                    "results": [
                        {
                            "title": "School science reference",
                            "url": "https://example.org/science/photosynthesis",
                            "content": "A reliable overview of photosynthesis for school learners.",
                        }
                    ]
                }
            )
            return
        self.send_json({"error": "not found"}, status=404)

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        if self.path == "/api/chat":
            if payload.get("stream"):
                lines = [
                    {"message": {"content": "Grounded "}, "done": False},
                    {"message": {"content": "response [B1]."}, "done": True},
                ]
                body = b"".join(json.dumps(item).encode("utf-8") + b"\n" for item in lines)
                self.send_response(200)
                self.send_header("Content-Type", "application/x-ndjson")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                system = " ".join(str(item.get("content", "")) for item in payload.get("messages", []))
                if "queries" in system.lower() and payload.get("format") == "json":
                    content = '{"queries":["photosynthesis plants"]}'
                else:
                    content = "Generated teacher draft [B1]."
                self.send_json({"message": {"role": "assistant", "content": content}, "done": True})
            return
        if self.path == "/api/pull":
            body = b'{"status":"pulling","completed":1,"total":1}\n{"status":"success"}\n'
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_json({"error": "not found"}, status=404)


class HttpClient:
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self.cookie = ""
        self.csrf = ""

    def request(self, method: str, path: str, payload: Any | None = None, *, csrf: bool = False) -> tuple[int, dict[str, str], bytes]:
        connection = http.client.HTTPConnection(self.host, self.port, timeout=20)
        headers = {"Accept": "application/json"}
        body = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if self.cookie:
            headers["Cookie"] = self.cookie
        if csrf and self.csrf:
            headers["X-CSRF-Token"] = self.csrf
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        data = response.read()
        result_headers = {key.lower(): value for key, value in response.getheaders()}
        if "set-cookie" in result_headers:
            self.cookie = result_headers["set-cookie"].split(";", 1)[0]
        connection.close()
        return response.status, result_headers, data

    def json(self, method: str, path: str, payload: Any | None = None, *, csrf: bool = False) -> tuple[int, Any]:
        status, _headers, data = self.request(method, path, payload, csrf=csrf)
        return status, json.loads(data.decode("utf-8") or "{}")


class ApplicationIntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

        self.fake = ThreadingHTTPServer(("127.0.0.1", 0), FakeServicesHandler)
        self.fake_thread = threading.Thread(target=self.fake.serve_forever, daemon=True)
        self.fake_thread.start()
        fake_url = f"http://127.0.0.1:{self.fake.server_address[1]}"

        self.db = Database(self.root / "data" / "learning-workspace.db")
        self.config = AppConfig(
            host="127.0.0.1",
            port=0,
            data_dir=self.root / "data",
            database_path=self.root / "data" / "learning-workspace.db",
            upload_dir=self.root / "data" / "uploads",
            ollama_base_url=fake_url,
            enable_web_search=True,
            web_search_provider="searxng",
            web_search_result_count=4,
            web_search_timeout=5,
            web_search_query_mode="direct",
            web_search_domain_allowlist=(),
            web_search_domain_denylist=(),
            web_search_safe=True,
            web_fetch_pages=False,
            web_fetch_count=0,
            web_page_max_chars=5000,
            searxng_url=fake_url + "/search",
            ollama_web_search_url=fake_url,
            ollama_web_search_api_key="",
            brave_search_api_key="",
            serper_api_key="",
            tavily_api_key="",
            google_search_api_key="",
            google_search_engine_id="",
            session_ttl_seconds=3600,
            cookie_secure=False,
            max_request_bytes=8 * 1024 * 1024,
            max_upload_bytes=4 * 1024 * 1024,
            ollama_request_timeout=20,
            enable_ocr=False,
            ocr_languages="eng",
            max_document_chars=1_000_000,
            document_query_mode="direct",
            log_level="ERROR",
        )
        self.config.data_dir.mkdir(parents=True, exist_ok=True)
        self.config.upload_dir.mkdir(parents=True, exist_ok=True)
        self.app = LearningHTTPServer(("127.0.0.1", 0), LearningHandler, AppState(self.config, self.db))
        self.app_thread = threading.Thread(target=self.app.serve_forever, daemon=True)
        self.app_thread.start()
        self.client = HttpClient("127.0.0.1", self.app.server_address[1])

    def tearDown(self) -> None:
        self.app.shutdown()
        self.app.server_close()
        self.fake.shutdown()
        self.fake.server_close()
        self.temp.cleanup()

    def setup_admin(self) -> dict[str, Any]:
        status, data = self.client.json("POST", "/api/auth/setup", {"username": "school-admin", "password": "a-secure-school-password"})
        self.assertEqual(status, 201, data)
        self.client.csrf = data["csrf_token"]
        return data

    def upload_text(self, workspace_id: str, name: str, content: str) -> dict[str, Any]:
        status, data = self.client.json(
            "POST",
            f"/api/workspaces/{workspace_id}/documents/upload",
            {
                "name": name,
                "mime_type": "text/plain",
                "data_base64": base64.b64encode(content.encode("utf-8")).decode("ascii"),
            },
            csrf=True,
        )
        self.assertEqual(status, 201, data)
        return data

    def test_setup_uses_one_password_and_persists_in_sqlite(self) -> None:
        status, initial = self.client.json("GET", "/api/auth/status")
        self.assertEqual(status, 200)
        self.assertTrue(initial["setup_required"])
        auth = self.setup_admin()
        self.assertEqual(auth["user"]["role"], "admin")

        db_bytes = self.config.database_path.read_bytes()
        self.assertNotIn(b"a-secure-school-password", db_bytes)
        raw_cookie_token = self.client.cookie.split("=", 1)[1].encode("ascii")
        self.assertNotIn(raw_cookie_token, db_bytes)

        status, current = self.client.json("GET", "/api/auth/status")
        self.assertEqual(status, 200)
        self.assertTrue(current["authenticated"])
        self.assertEqual(current["username"], "school-admin")

    def test_csrf_auth_branding_users_documents_search_segments_compare_and_chat(self) -> None:
        self.setup_admin()
        status, no_csrf = self.client.json("POST", "/api/workspaces", {"name": "Grade 7"})
        self.assertEqual(status, 403, no_csrf)

        status, config = self.client.json("GET", "/api/config")
        self.assertEqual(status, 200)
        models = {item["name"]: item for item in config["recommended_models"]}
        self.assertGreaterEqual(len(models), 7)
        self.assertEqual(config["max_document_chars"], self.config.max_document_chars)
        self.assertEqual(models["qwen3:0.6b"]["license"], "Apache 2.0")
        self.assertIn("llama3.2:3b", models)

        status, workspaces = self.client.json("GET", "/api/workspaces")
        self.assertEqual(status, 200)
        workspace_id = workspaces["workspaces"][0]["id"]

        book_a = self.upload_text(
            workspace_id,
            "grade-7-science.txt",
            "Chapter 1 Photosynthesis\nPlants use light, water and carbon dioxide to make glucose.\n"
            "Chapter 2 Cells\nPlant cells include chloroplasts and a cell wall.\n",
        )
        book_b = self.upload_text(
            workspace_id,
            "grade-8-science.txt",
            "Unit 1 Photosynthesis\nChlorophyll captures light energy and oxygen is released.\n"
            "Unit 2 Respiration\nCells release energy from glucose.\n",
        )
        self.assertEqual(book_a["status"], "ready")
        self.assertGreater(book_a["char_count"], 20)

        status, search = self.client.json(
            "POST",
            "/api/documents/search",
            {"workspace_id": workspace_id, "query": "How do plants make food?", "model": "qwen3:1.7b", "document_ids": [book_a["id"]]},
            csrf=True,
        )
        self.assertEqual(status, 200, search)
        self.assertTrue(search["results"])
        self.assertEqual(search["results"][0]["citation"], "B1")

        status, segments = self.client.json(
            "POST", "/api/documents/segments", {"document_id": book_a["id"], "offset": 0, "limit": 10}, csrf=True
        )
        self.assertEqual(status, 200, segments)
        self.assertEqual(segments["document"]["title"], "grade-7-science.txt")
        self.assertEqual(segments["total"], book_a["chunk_count"])
        self.assertTrue(segments["chunks"])

        status, comparison = self.client.json(
            "POST", "/api/documents/compare", {"left_id": book_a["id"], "right_id": book_b["id"]}, csrf=True
        )
        self.assertEqual(status, 200, comparison)
        self.assertEqual(comparison["left"]["title"], "grade-7-science.txt")
        self.assertIn("structure", comparison)

        status, web = self.client.json(
            "POST", "/api/web-search", {"query": "photosynthesis school reference", "model": "qwen3:1.7b"}, csrf=True
        )
        self.assertEqual(status, 200, web)
        self.assertEqual(web["provider"], "searxng")
        self.assertEqual(web["results"][0]["citation"], "W1")

        status, chat = self.client.json(
            "POST",
            "/api/ollama/chat",
            {"model": "qwen3:1.7b", "stream": False, "messages": [{"role": "user", "content": "Create a lesson"}]},
            csrf=True,
        )
        self.assertEqual(status, 200, chat)
        self.assertIn("Generated teacher draft", chat["message"]["content"])

        status, branding = self.client.json(
            "POST",
            "/api/branding",
            {"app_name": "School Learning Lab", "school_name": "Example School", "theme_style": "tech", "primary_color": "#123456", "accent_color": "#ABCDEF"},
            csrf=True,
        )
        self.assertEqual(status, 200, branding)
        self.assertEqual(branding["app_name"], "School Learning Lab")

        status, teacher = self.client.json(
            "POST", "/api/users", {"username": "teacher.one", "password": "teacher-one-password", "role": "teacher"}, csrf=True
        )
        self.assertEqual(status, 201, teacher)
        self.assertEqual(teacher["role"], "teacher")

    def test_session_survives_server_restart(self) -> None:
        self.setup_admin()
        cookie = self.client.cookie
        self.app.shutdown()
        self.app.server_close()
        self.app_thread.join(timeout=2)

        self.app = LearningHTTPServer(("127.0.0.1", 0), LearningHandler, AppState(self.config, Database(self.config.database_path)))
        self.app_thread = threading.Thread(target=self.app.serve_forever, daemon=True)
        self.app_thread.start()
        self.client = HttpClient("127.0.0.1", self.app.server_address[1])
        self.client.cookie = cookie
        status, data = self.client.json("GET", "/api/auth/status")
        self.assertEqual(status, 200)
        self.assertTrue(data["authenticated"])
        self.assertEqual(data["username"], "school-admin")

    def test_static_ui_has_single_setup_password_field_and_security_headers(self) -> None:
        status, headers, body = self.client.request("GET", "/")
        self.assertEqual(status, 200)
        text = body.decode("utf-8")
        self.assertIn('id="authPassword"', text)
        self.assertNotIn("authConfirm", text)
        self.assertIn('id="brandAppName"', text)
        self.assertIn('id="studioFullCoverage"', text)
        self.assertIn("content-security-policy", headers)
        self.assertIn("script-src 'self'", headers["content-security-policy"])


class StorageMigrationTests(unittest.TestCase):
    def test_legacy_json_password_hash_is_migrated(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source_db = Database(root / "source.db")
            user = source_db.create_user("legacy-admin", "legacy-password-123", "admin")
            with closing(sqlite3.connect(source_db.path)) as conn:
                row = conn.execute(
                    "SELECT username, role, password_salt, password_hash, scrypt_n, scrypt_r, scrypt_p, created_at, password_updated_at FROM users WHERE id=?",
                    (user["id"],),
                ).fetchone()
            legacy = {
                "users": [
                    {
                        "username": row[0],
                        "role": row[1],
                        "salt": base64.b64encode(row[2]).decode("ascii"),
                        "hash": base64.b64encode(row[3]).decode("ascii"),
                        "scrypt": {"n": row[4], "r": row[5], "p": row[6]},
                        "created_at": row[7],
                        "password_updated_at": row[8],
                    }
                ]
            }
            path = root / "users.json"
            path.write_text(json.dumps(legacy), encoding="utf-8")
            target = Database(root / "target.db")
            self.assertEqual(target.import_legacy_users(path), 1)
            self.assertIsNotNone(target.verify_user("legacy-admin", "legacy-password-123"))
            self.assertTrue((root / "users.json.migrated").exists())


if __name__ == "__main__":
    unittest.main()
