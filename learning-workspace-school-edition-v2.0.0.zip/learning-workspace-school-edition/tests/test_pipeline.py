from __future__ import annotations

import tempfile
import unittest
import zipfile
from pathlib import Path

from document_pipeline import ExtractionOptions, chunk_sections, compare_documents, extract_document


class DocumentPipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.options = ExtractionOptions(enable_ocr=False, max_document_chars=1_000_000)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_text_html_docx_pptx_xlsx_and_epub_extract(self) -> None:
        text = self.root / "book.txt"
        text.write_text("Chapter 1\nWater cycle and evaporation.\n\nChapter 2\nCondensation and rainfall.", encoding="utf-8")

        html = self.root / "lesson.html"
        html.write_text("<html><body><h1>Forces</h1><p>Gravity attracts masses.</p><script>ignore()</script></body></html>", encoding="utf-8")

        from docx import Document
        doc = Document()
        doc.add_heading("Fractions", level=1)
        doc.add_paragraph("Equivalent fractions have the same value.")
        docx = self.root / "math.docx"
        doc.save(docx)

        from pptx import Presentation
        presentation = Presentation()
        slide = presentation.slides.add_slide(presentation.slide_layouts[1])
        slide.shapes.title.text = "Ecosystems"
        slide.placeholders[1].text = "Producers, consumers and decomposers"
        pptx = self.root / "science.pptx"
        presentation.save(pptx)

        from openpyxl import Workbook
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Marks"
        sheet.append(["Student", "Score"])
        sheet.append(["Learner A", 18])
        xlsx = self.root / "marks.xlsx"
        workbook.save(xlsx)
        workbook.close()

        epub = self.root / "reader.epub"
        with zipfile.ZipFile(epub, "w") as archive:
            archive.writestr("META-INF/container.xml", """<?xml version='1.0'?><container xmlns='urn:oasis:names:tc:opendocument:xmlns:container'><rootfiles><rootfile full-path='OEBPS/content.opf'/></rootfiles></container>""")
            archive.writestr("OEBPS/content.opf", """<package xmlns='http://www.idpf.org/2007/opf'><manifest><item id='c1' href='chapter.xhtml' media-type='application/xhtml+xml'/></manifest><spine><itemref idref='c1'/></spine></package>""")
            archive.writestr("OEBPS/chapter.xhtml", "<html><body><h1>Atoms</h1><p>Matter is made of atoms.</p></body></html>")

        cases = [
            (text, "text/plain", "evaporation"),
            (html, "text/html", "Gravity"),
            (docx, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "Equivalent fractions"),
            (pptx, "application/vnd.openxmlformats-officedocument.presentationml.presentation", "Producers"),
            (xlsx, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Learner A"),
            (epub, "application/epub+zip", "Matter is made"),
        ]
        for path, mime, expected in cases:
            with self.subTest(path=path.name):
                sections, metadata = extract_document(path, path.name, mime, self.options)
                combined = "\n".join(section.text for section in sections)
                self.assertIn(expected, combined)
                self.assertTrue(metadata["format"])
                self.assertTrue(chunk_sections(sections))

    def test_deterministic_comparison_reports_structure_and_samples(self) -> None:
        left_chunks = [
            {"heading": "Plants", "locator": "Page 1", "content": "Plants use chlorophyll for photosynthesis."},
            {"heading": "Cells", "locator": "Page 2", "content": "Plant cells contain chloroplasts."},
        ]
        right_chunks = [
            {"heading": "Plants", "locator": "Page 1", "content": "Photosynthesis releases oxygen."},
            {"heading": "Respiration", "locator": "Page 3", "content": "Respiration releases energy from glucose."},
        ]
        result = compare_documents(
            {"id": "a", "original_name": "Grade 7", "page_count": 2, "char_count": 90},
            left_chunks,
            {"id": "b", "original_name": "Grade 8", "page_count": 3, "char_count": 100},
            right_chunks,
        )
        self.assertIn("Cells", result["structure"]["only_in_left"])
        self.assertIn("Respiration", result["structure"]["only_in_right"])
        self.assertEqual(result["left"]["samples"][0]["citation"], "A1")
        self.assertEqual(result["right"]["samples"][0]["citation"], "B1")


if __name__ == "__main__":
    unittest.main()
