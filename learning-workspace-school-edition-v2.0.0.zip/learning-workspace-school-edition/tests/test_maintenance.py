from __future__ import annotations

import os
import sqlite3
import tempfile
import unittest
import zipfile
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

from maintenance import backup
from storage import Database


class MaintenanceTests(unittest.TestCase):
    def test_backup_contains_consistent_database_and_uploads(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            data = root / "data"
            uploads = data / "uploads"
            uploads.mkdir(parents=True)
            database = data / "learning-workspace.db"
            store = Database(database)
            store.create_user("backup-admin", "backup-password-123", "admin")
            (uploads / "book.txt").write_text("School book content", encoding="utf-8")

            with patch.dict(
                os.environ,
                {
                    "APP_DATA_DIR": str(data),
                    "DATABASE_PATH": str(database),
                    "UPLOAD_DIR": str(uploads),
                },
                clear=False,
            ):
                archive = backup(root / "backups")

            self.assertTrue(archive.exists())
            with tempfile.TemporaryDirectory() as extracted:
                with zipfile.ZipFile(archive) as zip_file:
                    zip_file.testzip()
                    zip_file.extractall(extracted)
                backup_root = Path(extracted) / "learning-workspace-backup"
                with closing(sqlite3.connect(backup_root / "learning-workspace.db")) as conn:
                    self.assertEqual(conn.execute("SELECT username FROM users").fetchone()[0], "backup-admin")
                self.assertEqual((backup_root / "uploads" / "book.txt").read_text(encoding="utf-8"), "School book content")
                self.assertTrue((backup_root / "MANIFEST.sha256").exists())


if __name__ == "__main__":
    unittest.main()
