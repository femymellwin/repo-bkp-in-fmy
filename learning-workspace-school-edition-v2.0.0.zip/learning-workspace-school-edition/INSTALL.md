# Learning Workspace School Edition — Installation Guide

This guide installs version 2.0.0 on a teacher computer or a small school server.

## 1. Requirements

Required:

- A 64-bit Windows, macOS, or Linux computer.
- Python 3.10 or newer.
- Ollama, installed from its official distribution.
- Enough free disk space for the application, uploaded books, and local models.

Recommended:

- 4-8 GB RAM for ultra-light `qwen3:0.6b` query rewriting and rough drafts.
- 8 GB RAM for light single-user `gemma3:1b` use.
- 12 GB RAM for a more comfortable `qwen3:1.7b` deployment.
- 16 GB or more for `qwen3:4b`, `phi4-mini`, `gemma3:4b`, long books, or multiple active users.
- Tesseract OCR for scanned PDFs and photographed pages.
- An SSD rather than a mechanical disk.

The RAM figures are operational guidance rather than model-vendor guarantees. Long context, image input, concurrent teachers, other applications, and operating-system overhead increase memory use.

The default document-text ceiling is 8,000,000 extracted characters per file. The Book Library displays a warning if that limit is reached. Increase `MAX_DOCUMENT_CHARS` in `.env` (up to 30,000,000) and re-upload the source when a very large book is truncated.

## 2. Install Ollama

Install Ollama using its official instructions, then verify it:

```bash
ollama --version
```

Pull a starter model:

```bash
ollama pull qwen3:1.7b
```

Alternative starter models:

```bash
ollama pull qwen3:0.6b
ollama pull gemma3:1b
ollama pull llama3.2:3b
ollama pull qwen3:4b
ollama pull phi4-mini
ollama pull gemma3:4b
```

`qwen3:0.6b` is an emergency low-memory option for simple drafts and search-query expansion, not a reliable marking model. The School Admin model page shows the download size, context window, practical RAM guidance, purpose, and license family for all seven recommendations.

The application's School Admin page can also initiate a model pull after Ollama is reachable.

## 3. Install the application

### macOS or Linux

```bash
unzip learning-workspace-school-edition-v2.0.0.zip
cd learning-workspace-school-edition
chmod +x *.sh maintenance.py
./install.sh
```

Start in the foreground during the first check:

```bash
./start-foreground.sh
```

Or start in the background:

```bash
./start-background.sh
```

Stop a background instance with:

```bash
./stop-background.sh
```

### Windows PowerShell

```powershell
Expand-Archive .\learning-workspace-school-edition-v2.0.0.zip
cd .\learning-workspace-school-edition
powershell -ExecutionPolicy Bypass -File .\install-windows.ps1
```

Start in the foreground:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-windows.ps1
```

Start in the background:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-windows-background.ps1
```

Stop the background instance:

```powershell
powershell -ExecutionPolicy Bypass -File .\stop-windows.ps1
```

## 4. Create the administrator

Open:

```text
http://127.0.0.1:8787
```

On a new installation, the page displays **Create the school administrator**. Enter a username and a password of at least 12 characters. There is one password field on the browser setup page.

The account is stored in:

```text
data/learning-workspace.db
```

The plaintext password is not stored. The database contains a salted `scrypt` password hash. The login cookie contains a random token; the database stores only its SHA-256 hash.

## 5. Upgrade from the previous secure-web-search build

1. Stop the old application.
2. Make a copy of the old `data` directory.
3. Install this release in a new directory.
4. Copy the old `data/users.json` into the new release's `data` directory before the first start.
5. Start Learning Workspace.

When the database has no users, the server imports compatible password hashes from `data/users.json`, creates the administrator's default workspace, and renames the source file to `users.json.migrated`.

If the old build never created `users.json`, use the first-run setup page. Browser-only chat history from the original static application is not imported.

## 6. Configure the application

Copy the example configuration:

### macOS or Linux

```bash
cp .env.example .env
```

### Windows PowerShell

```powershell
Copy-Item .env.example .env
```

The default configuration listens only on the local computer:

```dotenv
HOST=127.0.0.1
PORT=8787
OLLAMA_BASE_URL=http://127.0.0.1:11434
```

The server loads `.env` when it starts. Restart after changing it.

## 7. OCR for scanned books and answer papers

Text-based PDF files work without Tesseract. Scanned pages and image files require the Tesseract executable.

Ubuntu/Debian example:

```bash
sudo apt update
sudo apt install tesseract-ocr tesseract-ocr-eng
```

macOS with Homebrew:

```bash
brew install tesseract
```

On Windows, install Tesseract and add it to `PATH`, or define:

```dotenv
TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe
```

For additional languages, install the corresponding Tesseract language packs and set, for example:

```dotenv
OCR_LANGUAGES=eng+ara
```

OCR quality varies. Always check extracted page counts, page citations, equations, diagrams, tables, and handwritten work.

## 8. Configure web search

Web search is enabled globally by default but remains off for each prompt until a teacher selects the **Web** switch. The default provider is DuckDuckGo and needs no API key:

```dotenv
ENABLE_WEB_SEARCH=true
WEB_SEARCH_PROVIDER=duckduckgo
```

For more predictable school use, configure SearXNG, Brave, Serper, or Tavily. See `SEARCH-PROVIDERS.md`.

Search-provider keys stay in `.env` on the server. The browser receives readiness status but not the key.

## 9. Configure a school LAN deployment

Do not expose the built-in HTTP server directly to the public internet.

For access from other computers:

1. Set `HOST=0.0.0.0` or a specific private-LAN address.
2. Put an HTTPS reverse proxy such as Caddy, Nginx, or an organizational gateway in front.
3. Set `COOKIE_SECURE=true` once HTTPS is used.
4. Restrict firewall access to the school network or VPN.
5. Use unique teacher accounts and disable accounts that are no longer required.
6. Back up `data/learning-workspace.db` and `data/uploads` regularly.

Example application settings behind HTTPS:

```dotenv
HOST=127.0.0.1
PORT=8787
COOKIE_SECURE=true
```

The reverse proxy should connect to `127.0.0.1:8787` and terminate TLS.

## 10. First teacher setup

As administrator:

1. Open **School Admin**.
2. Set the application name, school name, logo letters, theme, colors, and login message.
3. Create one account per teacher.
4. Confirm an Ollama model is installed.
5. Configure the selected web-search provider in `.env` if required.

As a teacher:

1. Create a workspace for a class or subject, such as `Grade 7 Science`.
2. Upload the relevant books, syllabus, question papers, answer keys, and rubrics.
3. Check that each file reports a ready status and a plausible page/chunk count.
4. Select only the sources required for the task.
5. Use the standard evidence mode for quick work or Full-book pass for deliberate comparison.

## 11. Password recovery

An administrator can reset another user's password in School Admin.

For administrator lockout, stop the application and run the command-line reset. It intentionally asks twice because it is a terminal recovery command rather than the browser login screen.

macOS/Linux:

```bash
.venv/bin/python server.py --reset-password school-admin
```

Windows:

```powershell
.\.venv\Scripts\python.exe server.py --reset-password school-admin
```

## 12. Backups

A backup ZIP includes the SQLite database and uploaded source files. It excludes `.env`, logs, and runtime files.

macOS/Linux:

```bash
./backup.sh
```

Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\backup-windows.ps1
```

Avoid starting a large upload during a backup. Store backup ZIPs in an access-controlled location because they contain school documents and account records.
