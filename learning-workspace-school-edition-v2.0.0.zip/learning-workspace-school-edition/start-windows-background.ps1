$ErrorActionPreference = "Stop"
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppDir
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    & (Join-Path $AppDir "install-windows.ps1")
}
@("data", "logs", "run") | ForEach-Object { New-Item -ItemType Directory -Path $_ -Force | Out-Null }
$Python = Join-Path $AppDir ".venv\Scripts\python.exe"

function Read-DotEnvValue([string]$Name) {
    if (-not (Test-Path ".env")) { return $null }
    $Line = Get-Content ".env" | Where-Object { $_ -match "^\s*$([regex]::Escape($Name))=" } | Select-Object -Last 1
    if (-not $Line) { return $null }
    $Value = ($Line -split "=", 2)[1].Trim()
    return $Value.Trim('"').Trim("'")
}

$HostValue = if ($env:HOST) { $env:HOST } else { Read-DotEnvValue "HOST" }
$PortValue = if ($env:PORT) { $env:PORT } else { Read-DotEnvValue "PORT" }
$OllamaUrl = if ($env:OLLAMA_BASE_URL) { $env:OLLAMA_BASE_URL } else { Read-DotEnvValue "OLLAMA_BASE_URL" }
if (-not $HostValue) { $HostValue = "127.0.0.1" }
if (-not $PortValue) { $PortValue = "8787" }
if (-not $OllamaUrl) { $OllamaUrl = "http://127.0.0.1:11434" }

$AppPidFile = Join-Path $AppDir "run\app.pid"
if (Test-Path $AppPidFile) {
    $ExistingPid = Get-Content $AppPidFile -ErrorAction SilentlyContinue
    if ($ExistingPid -and (Get-Process -Id $ExistingPid -ErrorAction SilentlyContinue)) {
        Write-Host "Learning Workspace is already running with PID $ExistingPid."
        exit 0
    }
}

try {
    Invoke-RestMethod -Uri ($OllamaUrl.TrimEnd("/") + "/api/tags") -TimeoutSec 2 | Out-Null
} catch {
    if ((Get-Command ollama -ErrorAction SilentlyContinue) -and ($OllamaUrl -match "^http://(127\.0\.0\.1|localhost):")) {
        $OllamaProcess = Start-Process -FilePath "ollama" -ArgumentList "serve" -RedirectStandardOutput (Join-Path $AppDir "logs\ollama.log") -RedirectStandardError (Join-Path $AppDir "logs\ollama-error.log") -PassThru -WindowStyle Hidden
        Set-Content -Path (Join-Path $AppDir "run\ollama.pid") -Value $OllamaProcess.Id
        Start-Sleep -Seconds 2
    } else {
        Write-Warning "Ollama is not reachable at $OllamaUrl."
    }
}

$AppProcess = Start-Process -FilePath $Python -ArgumentList "server.py" -WorkingDirectory $AppDir -RedirectStandardOutput (Join-Path $AppDir "logs\app.log") -RedirectStandardError (Join-Path $AppDir "logs\app-error.log") -PassThru -WindowStyle Hidden
Set-Content -Path $AppPidFile -Value $AppProcess.Id

$OpenHost = if ($HostValue -in @("0.0.0.0", "::")) { "127.0.0.1" } else { $HostValue }
$Healthy = $false
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 1
    if (-not (Get-Process -Id $AppProcess.Id -ErrorAction SilentlyContinue)) { break }
    try {
        Invoke-RestMethod -Uri "http://${OpenHost}:$PortValue/healthz" -TimeoutSec 1 | Out-Null
        $Healthy = $true
        break
    } catch { }
}
if (-not $Healthy) {
    throw "The application did not start successfully. Review logs\app-error.log and logs\app.log."
}
Write-Host "Learning Workspace started with PID $($AppProcess.Id)"
Write-Host "Open http://${OpenHost}:$PortValue"
