#!/usr/bin/env python3
"""Document extraction, OCR, chunking, and deterministic textbook comparison."""
from __future__ import annotations

import csv
import html
import io
import json
import math
import os
import re
import shutil
import statistics
import tempfile
import zipfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree as ET


@dataclass
class ExtractionOptions:
    enable_ocr: bool = True
    ocr_languages: str = "eng"
    max_document_chars: int = 8_000_000
    pdf_password: str = ""


@dataclass
class ExtractedSection:
    locator: str
    heading: str
    text: str


TEXT_EXTENSIONS = {
    ".txt", ".md", ".markdown", ".csv", ".tsv", ".json", ".log", ".xml", ".yml", ".yaml",
    ".toml", ".ini", ".cfg", ".conf", ".py", ".js", ".ts", ".css", ".sql", ".java", ".c", ".cpp",
}
HTML_EXTENSIONS = {".html", ".htm", ".xhtml"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff", ".bmp"}
SUPPORTED_EXTENSIONS = TEXT_EXTENSIONS | HTML_EXTENSIONS | IMAGE_EXTENSIONS | {
    ".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".epub", ".odt",
}


class ExtractionError(RuntimeError):
    pass


def normalize_text(value: str) -> str:
    value = value.replace("\x00", " ").replace("\r\n", "\n").replace("\r", "\n")
    value = re.sub(r"[\t\f\v]+", " ", value)
    value = re.sub(r"[ \u00a0]+", " ", value)
    value = re.sub(r" *\n *", "\n", value)
    value = re.sub(r"\n{4,}", "\n\n\n", value)
    return value.strip()


def detect_heading(text: str, fallback: str = "") -> str:
    for line in text.splitlines():
        line = line.strip(" #-\t")
        if 3 <= len(line) <= 140 and not line.endswith((".", ",", ";")):
            return line
    return fallback


def decode_text(data: bytes) -> str:
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig", errors="replace")
    for encoding in ("utf-8", "utf-16", "utf-16-le", "utf-16-be", "cp1252", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _html_to_text(raw: str) -> str:
    try:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(raw, "html.parser")
        for element in soup(["script", "style", "noscript", "svg", "nav"]):
            element.decompose()
        root = soup.find("main") or soup.find("article") or soup.body or soup
        return normalize_text(root.get_text("\n", strip=True))
    except ImportError:
        from html.parser import HTMLParser

        class Parser(HTMLParser):
            def __init__(self) -> None:
                super().__init__()
                self.parts: list[str] = []
                self.skip = 0

            def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
                if tag in {"script", "style", "noscript", "svg"}:
                    self.skip += 1
                elif tag in {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "tr"}:
                    self.parts.append("\n")

            def handle_endtag(self, tag: str) -> None:
                if tag in {"script", "style", "noscript", "svg"} and self.skip:
                    self.skip -= 1
                elif tag in {"p", "div", "li", "h1", "h2", "h3", "h4", "tr"}:
                    self.parts.append("\n")

            def handle_data(self, data: str) -> None:
                if not self.skip:
                    self.parts.append(data)

        parser = Parser()
        parser.feed(raw)
        return normalize_text(html.unescape(" ".join(parser.parts)))


def _ocr_image(image: Any, languages: str) -> str:
    try:
        import pytesseract
    except ImportError as exc:
        raise ExtractionError("OCR requires the pytesseract Python package.") from exc
    command = os.getenv("TESSERACT_CMD", "").strip()
    if command:
        pytesseract.pytesseract.tesseract_cmd = command
    elif not shutil.which("tesseract") and os.name != "nt":
        raise ExtractionError("OCR was requested, but the Tesseract executable was not found.")
    try:
        return normalize_text(pytesseract.image_to_string(image, lang=languages or "eng"))
    except Exception as exc:
        raise ExtractionError(f"OCR failed: {exc}") from exc


def _extract_pdf(path: Path, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ExtractionError("PDF support requires the pypdf package.") from exc

    try:
        reader = PdfReader(str(path))
        if reader.is_encrypted:
            if not options.pdf_password or reader.decrypt(options.pdf_password) == 0:
                raise ExtractionError("This PDF is password protected. Remove the password before uploading it.")
    except ExtractionError:
        raise
    except Exception as exc:
        raise ExtractionError(f"Could not open PDF: {exc}") from exc

    pdfium_doc = None
    ocr_pages: list[int] = []
    raw_pages: list[str] = []
    for index, page in enumerate(reader.pages):
        try:
            text = page.extract_text(extraction_mode="layout") or ""
        except TypeError:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = normalize_text(text)
        meaningful = len(re.sub(r"\W+", "", text, flags=re.UNICODE))
        if meaningful < 40 and options.enable_ocr:
            try:
                if pdfium_doc is None:
                    import pypdfium2 as pdfium

                    pdfium_doc = pdfium.PdfDocument(str(path))
                bitmap = pdfium_doc[index].render(scale=2.0)
                image = bitmap.to_pil()
                ocr_text = _ocr_image(image, options.ocr_languages)
                if len(ocr_text) > len(text):
                    text = ocr_text
                    ocr_pages.append(index + 1)
            except Exception:
                # A single OCR failure must not discard extractable pages.
                pass
        raw_pages.append(text)

    # Remove only repeated edge lines, a common textbook header/footer artifact.
    edge_counter: Counter[str] = Counter()
    page_edges: list[set[str]] = []
    for text in raw_pages:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        edges = {line for line in (lines[:2] + lines[-2:]) if 2 <= len(line) <= 90}
        page_edges.append(edges)
        edge_counter.update(edges)
    threshold = max(4, math.ceil(len(raw_pages) * 0.35))
    repeated_edges = {line for line, count in edge_counter.items() if count >= threshold}

    sections: list[ExtractedSection] = []
    total = 0
    for index, text in enumerate(raw_pages):
        if repeated_edges:
            lines = [line for line in text.splitlines() if line.strip() not in repeated_edges]
            text = normalize_text("\n".join(lines))
        if not text:
            text = "[No machine-readable text was detected on this page.]"
        remaining = options.max_document_chars - total
        if remaining <= 0:
            break
        text = text[:remaining]
        total += len(text)
        sections.append(
            ExtractedSection(locator=f"Page {index + 1}", heading=detect_heading(text, f"Page {index + 1}"), text=text)
        )
    metadata = {
        "format": "PDF",
        "pages": len(reader.pages),
        "extracted_pages": len(sections),
        "ocr_pages": ocr_pages,
        "repeated_headers_removed": len(repeated_edges),
    }
    return sections, metadata


def _extract_docx(path: Path, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    try:
        from docx import Document
    except ImportError as exc:
        raise ExtractionError("Word document support requires python-docx.") from exc
    try:
        document = Document(str(path))
    except Exception as exc:
        raise ExtractionError(f"Could not open Word document: {exc}") from exc

    sections: list[ExtractedSection] = []
    heading = "Document"
    buffer: list[str] = []
    section_no = 1
    total = 0

    def flush() -> None:
        nonlocal buffer, section_no, total
        text = normalize_text("\n\n".join(buffer))
        if text and total < options.max_document_chars:
            text = text[: options.max_document_chars - total]
            sections.append(ExtractedSection(locator=f"Section {section_no}", heading=heading, text=text))
            total += len(text)
            section_no += 1
        buffer = []

    for paragraph in document.paragraphs:
        text = normalize_text(paragraph.text)
        if not text:
            continue
        style_name = str(getattr(paragraph.style, "name", "") or "")
        if style_name.casefold().startswith("heading") or style_name.casefold() in {"title", "subtitle"}:
            flush()
            heading = text[:200]
        else:
            buffer.append(text)
    flush()

    for table_index, table in enumerate(document.tables, start=1):
        rows: list[str] = []
        for row in table.rows:
            cells = [normalize_text(cell.text).replace("\n", " / ") for cell in row.cells]
            rows.append(" | ".join(cells))
        text = normalize_text("\n".join(rows))
        if text and total < options.max_document_chars:
            text = text[: options.max_document_chars - total]
            sections.append(ExtractedSection(locator=f"Table {table_index}", heading=f"Table {table_index}", text=text))
            total += len(text)
    if not sections:
        raise ExtractionError("No readable text was found in this Word document.")
    return sections, {"format": "DOCX", "sections": len(sections), "tables": len(document.tables)}


def _extract_pptx(path: Path, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    try:
        from pptx import Presentation
    except ImportError as exc:
        raise ExtractionError("PowerPoint support requires python-pptx.") from exc
    try:
        presentation = Presentation(str(path))
    except Exception as exc:
        raise ExtractionError(f"Could not open PowerPoint presentation: {exc}") from exc

    sections: list[ExtractedSection] = []
    total = 0
    for slide_index, slide in enumerate(presentation.slides, start=1):
        parts: list[str] = []
        title = ""
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                text = normalize_text(shape.text)
                if text:
                    if not title and getattr(shape, "is_placeholder", False):
                        title = text.splitlines()[0][:180]
                    parts.append(text)
            if getattr(shape, "has_table", False):
                rows = []
                for row in shape.table.rows:
                    rows.append(" | ".join(normalize_text(cell.text).replace("\n", " / ") for cell in row.cells))
                parts.append("\n".join(rows))
        text = normalize_text("\n\n".join(parts))
        if not text:
            continue
        remaining = options.max_document_chars - total
        if remaining <= 0:
            break
        text = text[:remaining]
        total += len(text)
        sections.append(
            ExtractedSection(locator=f"Slide {slide_index}", heading=title or detect_heading(text, f"Slide {slide_index}"), text=text)
        )
    if not sections:
        raise ExtractionError("No readable text was found in this PowerPoint file.")
    return sections, {"format": "PPTX", "slides": len(presentation.slides), "extracted_slides": len(sections)}


def _extract_xlsx(path: Path, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    try:
        import openpyxl
    except ImportError as exc:
        raise ExtractionError("Spreadsheet support requires openpyxl.") from exc
    try:
        workbook = openpyxl.load_workbook(path, read_only=True, data_only=False)
    except Exception as exc:
        raise ExtractionError(f"Could not open spreadsheet: {exc}") from exc
    sections: list[ExtractedSection] = []
    total = 0
    for sheet in workbook.worksheets:
        rows: list[str] = []
        for row in sheet.iter_rows(values_only=True):
            values = ["" if value is None else str(value) for value in row]
            if any(value.strip() for value in values):
                rows.append("\t".join(values).rstrip())
            if sum(len(item) for item in rows[-100:]) + total > options.max_document_chars:
                break
        text = normalize_text("\n".join(rows))
        if text:
            remaining = options.max_document_chars - total
            text = text[:remaining]
            total += len(text)
            sections.append(ExtractedSection(locator=f"Sheet {sheet.title}", heading=sheet.title, text=text))
        if total >= options.max_document_chars:
            break
    workbook.close()
    if not sections:
        raise ExtractionError("No readable cell content was found in this spreadsheet.")
    return sections, {"format": "XLSX", "sheets": len(workbook.sheetnames), "extracted_sheets": len(sections)}


def _epub_order(archive: zipfile.ZipFile) -> list[str]:
    names = set(archive.namelist())
    try:
        container = ET.fromstring(archive.read("META-INF/container.xml"))
        rootfile = next(element for element in container.iter() if element.tag.endswith("rootfile"))
        opf_path = rootfile.attrib["full-path"]
        opf = ET.fromstring(archive.read(opf_path))
        base = Path(opf_path).parent
        manifest: dict[str, str] = {}
        for element in opf.iter():
            if element.tag.endswith("item") and "id" in element.attrib and "href" in element.attrib:
                manifest[element.attrib["id"]] = str((base / element.attrib["href"]).as_posix())
        order = []
        for element in opf.iter():
            if element.tag.endswith("itemref"):
                href = manifest.get(element.attrib.get("idref", ""))
                if href and href in names:
                    order.append(href)
        if order:
            return order
    except Exception:
        pass
    return sorted(name for name in names if Path(name).suffix.lower() in HTML_EXTENSIONS)


def _extract_epub(path: Path, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    try:
        archive = zipfile.ZipFile(path)
    except Exception as exc:
        raise ExtractionError(f"Could not open EPUB: {exc}") from exc
    sections: list[ExtractedSection] = []
    total = 0
    with archive:
        for index, name in enumerate(_epub_order(archive), start=1):
            try:
                raw = decode_text(archive.read(name))
            except Exception:
                continue
            text = _html_to_text(raw)
            if not text:
                continue
            remaining = options.max_document_chars - total
            if remaining <= 0:
                break
            text = text[:remaining]
            total += len(text)
            sections.append(
                ExtractedSection(locator=f"Chapter {index}", heading=detect_heading(text, Path(name).stem), text=text)
            )
    if not sections:
        raise ExtractionError("No readable text was found in this EPUB.")
    return sections, {"format": "EPUB", "chapters": len(sections)}


def _extract_odt(path: Path, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    try:
        with zipfile.ZipFile(path) as archive:
            root = ET.fromstring(archive.read("content.xml"))
    except Exception as exc:
        raise ExtractionError(f"Could not open OpenDocument file: {exc}") from exc
    parts: list[str] = []
    for element in root.iter():
        if element.tag.endswith(("}h", "}p")):
            text = normalize_text("".join(element.itertext()))
            if text:
                parts.append(text)
    text = normalize_text("\n\n".join(parts))[: options.max_document_chars]
    if not text:
        raise ExtractionError("No readable text was found in this OpenDocument file.")
    return [ExtractedSection(locator="Document", heading=detect_heading(text, "Document"), text=text)], {
        "format": "ODT",
        "paragraphs": len(parts),
    }


def _extract_image(path: Path, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    if not options.enable_ocr:
        raise ExtractionError("This image needs OCR. Enable OCR in .env and install Tesseract.")
    try:
        from PIL import Image

        with Image.open(path) as image:
            text = _ocr_image(image, options.ocr_languages)
            dimensions = [image.width, image.height]
    except ExtractionError:
        raise
    except Exception as exc:
        raise ExtractionError(f"Could not read image: {exc}") from exc
    if not text:
        raise ExtractionError("OCR did not detect readable text in this image.")
    return [ExtractedSection(locator="Image", heading=path.stem, text=text[: options.max_document_chars])], {
        "format": path.suffix.upper().lstrip("."),
        "ocr": True,
        "dimensions": dimensions,
    }


def extract_document(path: Path, original_name: str, mime_type: str, options: ExtractionOptions) -> tuple[list[ExtractedSection], dict[str, Any]]:
    suffix = Path(original_name).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ExtractionError(
            "Unsupported file type. Use PDF, DOCX, PPTX, XLSX, EPUB, ODT, text/Markdown/CSV/HTML, or an image."
        )
    if suffix == ".pdf":
        sections, metadata = _extract_pdf(path, options)
    elif suffix == ".docx":
        sections, metadata = _extract_docx(path, options)
    elif suffix == ".pptx":
        sections, metadata = _extract_pptx(path, options)
    elif suffix in {".xlsx", ".xlsm"}:
        sections, metadata = _extract_xlsx(path, options)
    elif suffix == ".epub":
        sections, metadata = _extract_epub(path, options)
    elif suffix == ".odt":
        sections, metadata = _extract_odt(path, options)
    elif suffix in IMAGE_EXTENSIONS:
        sections, metadata = _extract_image(path, options)
    else:
        data = path.read_bytes()
        raw = decode_text(data)
        if suffix in HTML_EXTENSIONS:
            text = _html_to_text(raw)
        elif suffix == ".json":
            try:
                text = json.dumps(json.loads(raw), ensure_ascii=False, indent=2)
            except json.JSONDecodeError:
                text = raw
        else:
            text = normalize_text(raw)
        text = text[: options.max_document_chars]
        if not text:
            raise ExtractionError("No readable text was found in this file.")
        sections = [ExtractedSection(locator="Document", heading=detect_heading(text, Path(original_name).stem), text=text)]
        metadata = {"format": suffix.upper().lstrip(".") or mime_type or "TEXT"}

    char_count = sum(len(section.text) for section in sections)
    word_count = sum(len(re.findall(r"\b\w+\b", section.text, flags=re.UNICODE)) for section in sections)
    metadata.update(
        {
            "original_name": original_name,
            "mime_type": mime_type,
            "section_count": len(sections),
            "char_count": char_count,
            "word_count": word_count,
            "truncated": char_count >= options.max_document_chars,
        }
    )
    return sections, metadata


def _split_long_text(text: str, target_chars: int, overlap_chars: int) -> list[str]:
    text = normalize_text(text)
    if len(text) <= target_chars:
        return [text] if text else []
    paragraphs = [part.strip() for part in re.split(r"\n{2,}", text) if part.strip()]
    chunks: list[str] = []
    current = ""
    for paragraph in paragraphs:
        pieces = [paragraph]
        if len(paragraph) > target_chars:
            pieces = []
            sentences = re.split(r"(?<=[.!?。！？])\s+", paragraph)
            sentence_buffer = ""
            for sentence in sentences:
                if len(sentence_buffer) + len(sentence) + 1 <= target_chars:
                    sentence_buffer = (sentence_buffer + " " + sentence).strip()
                else:
                    if sentence_buffer:
                        pieces.append(sentence_buffer)
                    if len(sentence) <= target_chars:
                        sentence_buffer = sentence
                    else:
                        start = 0
                        while start < len(sentence):
                            pieces.append(sentence[start : start + target_chars])
                            start += max(1, target_chars - overlap_chars)
                        sentence_buffer = ""
            if sentence_buffer:
                pieces.append(sentence_buffer)
        for piece in pieces:
            candidate = (current + "\n\n" + piece).strip() if current else piece
            if len(candidate) <= target_chars:
                current = candidate
            else:
                if current:
                    chunks.append(current)
                prefix = current[-overlap_chars:] if current and overlap_chars else ""
                current = (prefix + "\n" + piece).strip() if prefix else piece
                while len(current) > target_chars * 1.4:
                    chunks.append(current[:target_chars])
                    current = current[max(1, target_chars - overlap_chars) :]
    if current:
        chunks.append(current)
    return [normalize_text(chunk) for chunk in chunks if normalize_text(chunk)]


def chunk_sections(
    sections: Iterable[ExtractedSection], target_chars: int = 1800, overlap_chars: int = 220
) -> list[dict[str, str]]:
    chunks: list[dict[str, str]] = []
    for section in sections:
        for part_index, content in enumerate(_split_long_text(section.text, target_chars, overlap_chars), start=1):
            locator = section.locator
            if part_index > 1:
                locator = f"{locator}, part {part_index}"
            chunks.append({"locator": locator, "heading": section.heading, "content": content})
    return chunks


STOPWORDS = {
    "the", "and", "for", "with", "from", "that", "this", "these", "those", "into", "about", "there", "their",
    "they", "them", "then", "than", "when", "where", "which", "while", "what", "were", "was", "are", "is", "be",
    "been", "being", "have", "has", "had", "can", "could", "should", "would", "will", "may", "might", "must", "not",
    "you", "your", "our", "its", "his", "her", "she", "him", "who", "how", "why", "also", "each", "other", "such",
    "more", "most", "some", "any", "all", "only", "over", "under", "between", "within", "through", "using", "used",
    "one", "two", "three", "chapter", "page", "section", "example", "examples", "student", "students",
}


def _terms(chunks: Iterable[dict[str, Any]], limit: int = 80) -> Counter[str]:
    counter: Counter[str] = Counter()
    for chunk in chunks:
        for token in re.findall(r"[^\W_][\w'-]{2,40}", str(chunk.get("content") or ""), flags=re.UNICODE):
            token = token.casefold().strip("'-")
            if len(token) >= 3 and token not in STOPWORDS and not token.isdigit():
                counter[token] += 1
    return Counter(dict(counter.most_common(limit)))


def document_outline(chunks: list[dict[str, Any]], limit: int = 80) -> list[str]:
    outline: list[str] = []
    seen: set[str] = set()
    for chunk in chunks:
        heading = normalize_text(str(chunk.get("heading") or ""))[:180]
        if heading and heading.casefold() not in seen:
            outline.append(heading)
            seen.add(heading.casefold())
            if len(outline) >= limit:
                break
    return outline


def compare_documents(
    left_document: dict[str, Any],
    left_chunks: list[dict[str, Any]],
    right_document: dict[str, Any],
    right_chunks: list[dict[str, Any]],
    max_chars: int = 30000,
) -> dict[str, Any]:
    left_terms = _terms(left_chunks, 180)
    right_terms = _terms(right_chunks, 180)
    left_total = sum(left_terms.values()) or 1
    right_total = sum(right_terms.values()) or 1
    union = set(left_terms) | set(right_terms)
    distinct_left = sorted(
        union,
        key=lambda term: (left_terms[term] / left_total) - (right_terms[term] / right_total),
        reverse=True,
    )[:30]
    distinct_right = sorted(
        union,
        key=lambda term: (right_terms[term] / right_total) - (left_terms[term] / left_total),
        reverse=True,
    )[:30]

    left_outline = document_outline(left_chunks)
    right_outline = document_outline(right_chunks)
    left_norm = {re.sub(r"\W+", " ", item.casefold()).strip(): item for item in left_outline}
    right_norm = {re.sub(r"\W+", " ", item.casefold()).strip(): item for item in right_outline}
    only_left = [original for normalized, original in left_norm.items() if normalized and normalized not in right_norm][:40]
    only_right = [original for normalized, original in right_norm.items() if normalized and normalized not in left_norm][:40]
    common = [left_norm[key] for key in left_norm.keys() & right_norm.keys()][:40]

    def sample(chunks: list[dict[str, Any]], label: str, budget: int) -> list[dict[str, Any]]:
        if not chunks:
            return []
        desired = min(14, len(chunks))
        indices = sorted({round(i * (len(chunks) - 1) / max(1, desired - 1)) for i in range(desired)})
        result = []
        used = 0
        for number, index in enumerate(indices, start=1):
            chunk = chunks[index]
            content = str(chunk.get("content") or "")
            remaining = budget - used
            if remaining <= 0:
                break
            content = content[: min(1800, remaining)]
            used += len(content)
            result.append(
                {
                    "citation": f"{label}{number}",
                    "locator": chunk.get("locator", ""),
                    "heading": chunk.get("heading", ""),
                    "content": content,
                }
            )
        return result

    per_side = max(4000, max_chars // 2)
    left_samples = sample(left_chunks, "A", per_side)
    right_samples = sample(right_chunks, "B", per_side)

    return {
        "left": {
            "id": left_document["id"],
            "title": left_document["original_name"],
            "pages": left_document.get("page_count", 0),
            "characters": left_document.get("char_count", 0),
            "chunks": len(left_chunks),
            "outline": left_outline,
            "distinctive_terms": distinct_left,
            "samples": left_samples,
        },
        "right": {
            "id": right_document["id"],
            "title": right_document["original_name"],
            "pages": right_document.get("page_count", 0),
            "characters": right_document.get("char_count", 0),
            "chunks": len(right_chunks),
            "outline": right_outline,
            "distinctive_terms": distinct_right,
            "samples": right_samples,
        },
        "structure": {
            "common_headings": common,
            "only_in_left": only_left,
            "only_in_right": only_right,
        },
        "method_note": (
            "The deterministic comparison uses extracted headings, term-frequency differences, and evenly distributed passages. "
            "The language model should verify claims against the cited passages and label uncertain differences."
        ),
    }
