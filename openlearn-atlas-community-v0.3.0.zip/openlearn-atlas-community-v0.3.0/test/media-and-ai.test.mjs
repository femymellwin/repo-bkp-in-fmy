import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { initializePortal } from '../src/app.mjs';
import { formatForFilename, sanitizeSvg } from '../src/formats.mjs';
import { markdownToHtml } from '../src/markdown.mjs';

function setCookies(response) {
  const values = response.headers.getSetCookie
    ? response.headers.getSetCookie()
    : [response.headers.get('set-cookie')].filter(Boolean);
  return values.map((value) => value.split(';', 1)[0]);
}

function mergeCookieJar(existing, response) {
  const jar = new Map();
  for (const pair of String(existing || '').split(';').map((value) => value.trim()).filter(Boolean)) {
    const index = pair.indexOf('=');
    if (index > 0) jar.set(pair.slice(0, index), pair.slice(index + 1));
  }
  for (const pair of setCookies(response)) {
    const index = pair.indexOf('=');
    if (index > 0) jar.set(pair.slice(0, index), pair.slice(index + 1));
  }
  return [...jar.entries()].map(([name, value]) => `${name}=${value}`).join('; ');
}

function csrfFrom(html) {
  return html.match(/<meta name="csrf-token" content="([^"]+)"/)?.[1]
    || html.match(/name="csrf" value="([^"]+)"/)?.[1]
    || '';
}

test('format registry classifies every requested learning format and sanitizes SVG', () => {
  assert.equal(formatForFilename('lesson.mp4').kind, 'video');
  assert.equal(formatForFilename('lesson.webm').viewer, 'video');
  assert.equal(formatForFilename('guide.pdf').viewer, 'pdf');
  assert.equal(formatForFilename('deck.pptx').viewer, 'download');
  assert.equal(formatForFilename('notes.docx').viewer, 'download');
  assert.equal(formatForFilename('data.xlsx').kind, 'spreadsheet');
  assert.equal(formatForFilename('article.md').viewer, 'markdown');
  assert.equal(formatForFilename('diagram.svg').kind, 'image');
  assert.equal(formatForFilename('flow.gif').label, 'Animated flow (GIF)');
  assert.equal(formatForFilename('app.html').viewer, 'sandbox');
  assert.equal(formatForFilename('bundle.zip').viewer, 'sandbox');
  assert.equal(formatForFilename('virus.exe'), null);

  const dirty = '<svg viewBox="0 0 24 24" onload="alert(1)"><script>alert(2)</script><a href="https://evil.example"><circle r="4"/></a></svg>';
  const clean = sanitizeSvg(dirty);
  assert.doesNotMatch(clean, /script|onload|https:\/\/evil/);
  assert.match(clean, /<circle r="4"\/>/);
  assert.throws(() => sanitizeSvg('not an svg'));
});

test('markdown renderer escapes raw HTML and supports core structures', () => {
  const html = markdownToHtml('# Title\n\nSome **bold** and `code`.\n\n- one\n- two\n\n<script>alert(1)</script>');
  assert.match(html, /<h1>Title<\/h1>/);
  assert.match(html, /<strong>bold<\/strong>/);
  assert.match(html, /<ul>/);
  assert.doesNotMatch(html, /<script>/);
  assert.match(html, /&lt;script&gt;/);
});

test('v0.3 media pipeline: video, markdown, svg uploads, viewers, icon library, AI and SharePoint settings', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-v03-test-'));
  const portal = await initializePortal({
    projectRoot: path.resolve('.'),
    dataDir: path.join(root, 'data'),
    backupDir: path.join(root, 'backups'),
    publicBaseUrl: 'http://127.0.0.1',
    sessionSecret: 'test-session-secret-with-at-least-thirty-two-characters',
    privacySalt: 'test-privacy-salt-with-at-least-thirty-two-characters',
    nodeEnv: 'test',
    captchaBypass: true
  });
  const server = portal.createHttpServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;

  try {
    // sign in as the bootstrap administrator
    const loginResponse = await fetch(`${base}/admin/login`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ email: 'admin@example.com', password: 'ChangeMe123!', next: '/admin' })
    });
    let adminCookie = mergeCookieJar('', loginResponse);
    const adminHtml = await (await fetch(`${base}/admin`, { headers: { Cookie: adminCookie } })).text();
    const adminCsrf = csrfFrom(adminHtml);
    assert.ok(adminCsrf);
    assert.match(adminHtml, /AI studio/);
    assert.match(adminHtml, /Icons/);
    assert.match(adminHtml, /accept="\.html,/);

    // ---- video upload with poster thumbnail ----
    const videoForm = new FormData();
    videoForm.set('csrf', adminCsrf);
    videoForm.set('title', 'Bearing Replacement Video');
    videoForm.set('category', 'Maintenance');
    videoForm.set('contentType', 'Video Lesson');
    videoForm.set('icon', 'video');
    videoForm.set('version', '1.0');
    videoForm.set('accessLevel', 'public');
    videoForm.set('tags', 'video,bearing');
    videoForm.set('summary', 'Step-by-step bearing replacement.');
    videoForm.set('description', 'A recorded walkthrough of the full procedure.');
    videoForm.set('published', 'on');
    videoForm.set('verificationEnabled', 'on');
    const fakeVideo = Buffer.alloc(4096, 7);
    videoForm.set('package', new Blob([fakeVideo], { type: 'video/mp4' }), 'bearing-replacement.mp4');
    const poster = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
    videoForm.set('thumbnail', new Blob([poster], { type: 'image/png' }), 'poster.png');
    const videoUpload = await fetch(`${base}/admin/content`, { method: 'POST', redirect: 'manual', headers: { Cookie: adminCookie }, body: videoForm });
    assert.equal(videoUpload.status, 303);

    const videoContent = portal.db.getContentBySlug('bearing-replacement-video', true);
    assert.ok(videoContent);
    assert.equal(videoContent.media_kind, 'video');
    assert.match(videoContent.thumbnail_key, /thumbnail\.png$/);

    const videoDetail = await (await fetch(`${base}/learn/bearing-replacement-video`)).text();
    assert.match(videoDetail, /data-video-player/);
    assert.match(videoDetail, /Play video/);
    assert.match(videoDetail, /type="video\/mp4"/);

    // inline view route streams with HTTP range support
    const fullView = await fetch(`${base}/view/${videoContent.id}`);
    assert.equal(fullView.status, 200);
    assert.equal(fullView.headers.get('content-type'), 'video/mp4');
    const rangedView = await fetch(`${base}/view/${videoContent.id}`, { headers: { Range: 'bytes=0-99' } });
    assert.equal(rangedView.status, 206);
    assert.equal(rangedView.headers.get('content-range'), `bytes 0-99/${fakeVideo.length}`);
    assert.equal((await rangedView.arrayBuffer()).byteLength, 100);

    // ---- markdown upload renders a styled article preview ----
    const mdForm = new FormData();
    mdForm.set('csrf', adminCsrf);
    mdForm.set('title', 'Torque Specification Notes');
    mdForm.set('category', 'Maintenance');
    mdForm.set('contentType', 'Markdown Article');
    mdForm.set('icon', 'book');
    mdForm.set('version', '1.0');
    mdForm.set('accessLevel', 'public');
    mdForm.set('tags', 'torque');
    mdForm.set('summary', 'Reference torque values.');
    mdForm.set('description', 'Written reference notes.');
    mdForm.set('published', 'on');
    mdForm.set('package', new Blob(['# Torque\n\n- M8: 25 Nm\n- M10: 49 Nm\n'], { type: 'text/markdown' }), 'torque.md');
    const mdUpload = await fetch(`${base}/admin/content`, { method: 'POST', redirect: 'manual', headers: { Cookie: adminCookie }, body: mdForm });
    assert.equal(mdUpload.status, 303);
    const mdContent = portal.db.getContentBySlug('torque-specification-notes', true);
    assert.equal(mdContent.media_kind, 'markdown');
    const article = await (await fetch(`${base}/preview/${mdContent.id}/index.html`)).text();
    assert.match(article, /<h1>Torque<\/h1>/);
    assert.match(article, /<li>M8: 25 Nm<\/li>/);

    // ---- svg upload is sanitized and self-thumbnails ----
    const svgForm = new FormData();
    svgForm.set('csrf', adminCsrf);
    svgForm.set('title', 'Cooling Loop Diagram');
    svgForm.set('category', 'Thermal');
    svgForm.set('contentType', 'Diagram / Image');
    svgForm.set('icon', 'diagram');
    svgForm.set('version', '1.0');
    svgForm.set('accessLevel', 'public');
    svgForm.set('tags', 'cooling');
    svgForm.set('summary', 'Closed-loop cooling schematic.');
    svgForm.set('description', 'Schematic of the cooling loop.');
    svgForm.set('published', 'on');
    svgForm.set('package', new Blob(['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10" onload="alert(1)"><rect width="10" height="10"/></svg>'], { type: 'image/svg+xml' }), 'cooling.svg');
    const svgUpload = await fetch(`${base}/admin/content`, { method: 'POST', redirect: 'manual', headers: { Cookie: adminCookie }, body: svgForm });
    assert.equal(svgUpload.status, 303);
    const svgContent = portal.db.getContentBySlug('cooling-loop-diagram', true);
    assert.equal(svgContent.media_kind, 'image');
    assert.match(svgContent.thumbnail_key, /thumbnail\.svg$/);
    const svgBody = await (await fetch(`${base}/view/${svgContent.id}`)).text();
    assert.doesNotMatch(svgBody, /onload/);

    // unsupported formats are rejected
    const badForm = new FormData();
    badForm.set('csrf', adminCsrf);
    badForm.set('title', 'Bad Upload');
    badForm.set('category', 'X');
    badForm.set('contentType', 'Reference Document');
    badForm.set('icon', 'generic');
    badForm.set('version', '1.0');
    badForm.set('summary', 's');
    badForm.set('description', 'd');
    badForm.set('package', new Blob([Buffer.alloc(64)], { type: 'application/octet-stream' }), 'tool.exe');
    const badUpload = await fetch(`${base}/admin/content`, { method: 'POST', redirect: 'manual', headers: { Cookie: adminCookie }, body: badForm });
    assert.equal(badUpload.status, 303);
    assert.match(decodeURIComponent(badUpload.headers.get('location') || ''), /Unsupported package format/);

    // ---- icon library: sanitized SVG upload, selection, deletion fallback ----
    const iconForm = new FormData();
    iconForm.set('csrf', adminCsrf);
    iconForm.set('name', 'Pump');
    iconForm.set('icon', new Blob(['<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" onclick="x()"/></svg>'], { type: 'image/svg+xml' }), 'pump.svg');
    const iconUpload = await fetch(`${base}/admin/icons/upload`, { method: 'POST', redirect: 'manual', headers: { Cookie: adminCookie }, body: iconForm });
    assert.equal(iconUpload.status, 303);
    const icons = portal.db.listCustomIcons();
    assert.equal(icons.length, 1);
    assert.doesNotMatch(icons[0].svg, /onclick/);

    const iconsPage = await (await fetch(`${base}/admin/icons`, { headers: { Cookie: adminCookie } })).text();
    assert.match(iconsPage, /Pump/);
    const adminAfterIcon = await (await fetch(`${base}/admin`, { headers: { Cookie: adminCookie } })).text();
    assert.match(adminAfterIcon, new RegExp(`custom:${icons[0].id}`));

    // resource can use the custom icon; deleting the icon falls back to generic
    const editVideo = await fetch(`${base}/admin/content/${videoContent.id}/edit`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        csrf: adminCsrf,
        title: videoContent.title,
        category: videoContent.category,
        contentType: videoContent.content_type,
        summary: videoContent.summary,
        description: videoContent.description,
        icon: `custom:${icons[0].id}`,
        tags: 'video',
        accessLevel: 'public',
        verificationEnabled: 'on'
      })
    });
    assert.equal(editVideo.status, 303);
    assert.equal(portal.db.getContentById(videoContent.id).icon, `custom:${icons[0].id}`);
    const deleteIcon = await fetch(`${base}/admin/icons/${icons[0].id}/delete`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ csrf: adminCsrf })
    });
    assert.equal(deleteIcon.status, 303);
    assert.equal(portal.db.getContentById(videoContent.id).icon, 'cube');

    // ---- AI studio settings save with masked secrets ----
    const aiSave = await fetch(`${base}/admin/ai`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        csrf: adminCsrf,
        anthropic_apiKey: 'sk-ant-test-key-value-123456',
        anthropic_model: 'claude-sonnet-4-5',
        azure_openai_apiKey: 'azure-key-abcdef',
        azure_openai_endpoint: 'https://demo.openai.azure.com',
        azure_openai_deployment: 'gpt-4o',
        azure_openai_apiVersion: '2024-10-21',
        ollama_baseUrl: 'http://localhost:11434',
        ollama_model: 'llama3.2',
        defaultProvider: 'anthropic'
      })
    });
    assert.equal(aiSave.status, 303);
    const aiSettings = portal.db.getJsonSetting('ai_settings');
    assert.equal(aiSettings.defaultProvider, 'anthropic');
    assert.equal(aiSettings.providers.anthropic.model, 'claude-sonnet-4-5');
    assert.equal(aiSettings.providers.azure_openai.deployment, 'gpt-4o');
    const aiPage = await (await fetch(`${base}/admin/ai`, { headers: { Cookie: adminCookie } })).text();
    assert.doesNotMatch(aiPage, /sk-ant-test-key-value-123456/);
    assert.match(aiPage, /sk-a\.\.\.3456/);

    // testing an unconfigured provider fails cleanly
    const aiTest = await fetch(`${base}/admin/ai/test`, {
      method: 'POST',
      headers: { Cookie: adminCookie, 'content-type': 'application/json', 'X-CSRF-Token': adminCsrf },
      body: JSON.stringify({ provider: 'gemini' })
    });
    assert.equal(aiTest.status, 400);

    // AI icon generation requires a reachable provider; failure is a clean 502
    const generate = await fetch(`${base}/admin/icons/generate`, {
      method: 'POST',
      headers: { Cookie: adminCookie, 'content-type': 'application/json', 'X-CSRF-Token': adminCsrf },
      body: JSON.stringify({ name: 'Turbine', description: 'wind turbine', provider: 'ollama' })
    });
    assert.equal(generate.status, 502);

    // ---- SharePoint provision saves and keeps the secret masked ----
    const spSave = await fetch(`${base}/admin/integrations`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        csrf: adminCsrf,
        tenantId: '11111111-2222-3333-4444-555555555555',
        clientId: 'aaaa-bbbb',
        clientSecret: 'super-secret-value',
        siteHostname: 'contoso.sharepoint.com',
        sitePath: '/sites/Learning',
        enabled: 'on'
      })
    });
    assert.equal(spSave.status, 303);
    const spSettings = portal.db.getJsonSetting('sharepoint_settings');
    assert.equal(spSettings.enabled, true);
    assert.equal(spSettings.clientSecret, 'super-secret-value');
    const spPage = await (await fetch(`${base}/admin/integrations`, { headers: { Cookie: adminCookie } })).text();
    assert.doesNotMatch(spPage, /super-secret-value/);

    // home page shows the media-kind pills and play overlay
    const home = await (await fetch(`${base}/`)).text();
    assert.match(home, /kind-video/);
    assert.match(home, /play-overlay/);
  } finally {
    await new Promise((resolve) => server.close(resolve));
    portal.close();
    fs.rmSync(root, { recursive: true, force: true });
  }
});
