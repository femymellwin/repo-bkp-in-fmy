import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { initializePortal } from '../src/app.mjs';
import { createBackup } from '../src/backup.mjs';
import { PortalDatabase } from '../src/db.mjs';

const projectRoot = path.resolve('.');

test('restore preserves its selected source, creates a safety backup, and restores database and local packages', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-restore-test-'));
  const dataDir = path.join(root, 'data');
  const backupDir = path.join(root, 'backups');
  let portal;
  try {
    portal = await initializePortal({
      projectRoot,
      dataDir,
      backupDir,
      publicBaseUrl: 'http://127.0.0.1',
      adminEmail: 'restore-owner@example.com',
      adminName: 'Restore Owner',
      adminPassword: 'Restore-Test-Password-123!',
      sessionSecret: 'restore-session-secret-with-at-least-thirty-two-characters',
      privacySalt: 'restore-privacy-salt-with-at-least-thirty-two-characters',
      nodeEnv: 'test',
      backupRetentionCount: 1
    });

    const content = portal.db.getContentById('sample-turbofan-engine');
    portal.db.updateBranding({ portalName: 'Before backup' }, 'restore-test');
    portal.db.createComment({
      contentId: content.id,
      versionId: content.current_version_id,
      authorName: 'Retained commenter',
      commentType: 'suggestion',
      body: 'This comment must survive the restore.'
    });
    const backup = await createBackup({ db: portal.db, storage: portal.storage, config: portal.config });
    const selectedArchive = backup.archivePath;

    portal.db.updateBranding({ portalName: 'After backup' }, 'restore-test');
    portal.db.createComment({
      contentId: content.id,
      versionId: content.current_version_id,
      authorName: 'Later commenter',
      commentType: 'error',
      body: 'This later comment must disappear after restore.'
    });
    portal.close();
    portal = null;

    const result = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', 'scripts/restore.mjs', selectedArchive, '--yes'], {
      cwd: projectRoot,
      encoding: 'utf8',
      env: {
        ...process.env,
        DATA_DIR: dataDir,
        BACKUP_DIR: backupDir,
        BACKUP_RETENTION_COUNT: '1',
        STORAGE_DRIVER: 'local',
        SESSION_SECRET: 'restore-session-secret-with-at-least-thirty-two-characters',
        PRIVACY_SALT: 'restore-privacy-salt-with-at-least-thirty-two-characters',
        NODE_ENV: 'test'
      }
    });
    assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
    assert.match(result.stdout, /Creating a safety backup before restore/);
    assert.match(result.stdout, /Restore completed/);

    const restored = new PortalDatabase(path.join(dataDir, 'portal.sqlite'));
    try {
      assert.equal(restored.getBranding().portalName, 'Before backup');
      const comments = restored.listCommentsForContent(content.id, true);
      assert.equal(comments.length, 1);
      assert.equal(comments[0].body, 'This comment must survive the restore.');
      assert.ok(restored.getUserByEmail('restore-owner@example.com'));
    } finally {
      restored.close();
    }

    assert.ok(fs.existsSync(path.join(dataDir, 'storage', 'content', content.id, 'versions', content.current_version_id, 'preview', 'index.html')));
    assert.ok(fs.readdirSync(dataDir).some((name) => name.startsWith('portal.sqlite.pre-restore-')));
    assert.ok(fs.readdirSync(dataDir).some((name) => name.startsWith('storage.pre-restore-')));
    assert.equal(fs.readdirSync(backupDir).filter((name) => name.endsWith('.tgz')).length, 1);
  } finally {
    if (portal) portal.close();
    fs.rmSync(root, { recursive: true, force: true });
  }
});
