import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { deflateRawSync } from 'node:zlib';
import { extractZipBuffer } from '../src/zip.mjs';

let crcTable;
function crc32(buffer) {
  if (!crcTable) {
    crcTable = new Uint32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      crcTable[n] = c >>> 0;
    }
  }
  let crc = 0xffffffff;
  for (const byte of buffer) crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function makeZip(entries) {
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;

  for (const entry of entries) {
    const name = Buffer.from(entry.name, 'utf8');
    const body = Buffer.isBuffer(entry.data) ? entry.data : Buffer.from(entry.data || '', 'utf8');
    const method = entry.method ?? 0;
    const compressed = method === 8 ? deflateRawSync(body) : body;
    const flags = entry.flags || 0;
    const crc = entry.crc ?? crc32(body);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(flags, 6);
    local.writeUInt16LE(method, 8);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compressed.length, 18);
    local.writeUInt32LE(entry.uncompressedSize ?? body.length, 22);
    local.writeUInt16LE(name.length, 26);
    localParts.push(local, name, compressed);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(0x0314, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(flags, 8);
    central.writeUInt16LE(method, 10);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(compressed.length, 20);
    central.writeUInt32LE(entry.uncompressedSize ?? body.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt32LE(entry.externalAttributes || 0, 38);
    central.writeUInt32LE(localOffset, 42);
    centralParts.push(central, name);

    localOffset += local.length + name.length + compressed.length;
  }

  const centralDirectory = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralDirectory.length, 12);
  eocd.writeUInt32LE(localOffset, 16);
  return Buffer.concat([...localParts, centralDirectory, eocd]);
}

function withTempDirectory(fn) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-zip-test-'));
  try {
    return fn(root);
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

test('extracts a valid deflated HTML package and chooses its entrypoint', () => withTempDirectory((root) => {
  const archive = makeZip([
    { name: 'lesson/index.html', data: '<!doctype html><h1>Lesson</h1>', method: 8 },
    { name: 'lesson/assets/app.js', data: 'console.log("ok")', method: 8 }
  ]);
  const result = extractZipBuffer(archive, root);
  assert.equal(result.entrypoint, 'lesson/index.html');
  assert.equal(fs.readFileSync(path.join(root, 'lesson/index.html'), 'utf8'), '<!doctype html><h1>Lesson</h1>');
  assert.equal(result.entries.length, 2);
}));

test('rejects ZIP traversal, duplicate filenames, encrypted entries, symlinks, and expanded-size excess', () => {
  withTempDirectory((root) => {
    assert.throws(
      () => extractZipBuffer(makeZip([{ name: '../index.html', data: 'bad' }]), root),
      /path traversal/
    );
  });

  withTempDirectory((root) => {
    assert.throws(
      () => extractZipBuffer(makeZip([
        { name: 'index.html', data: 'first' },
        { name: 'INDEX.HTML', data: 'second' }
      ]), root),
      /duplicate filename/
    );
  });

  withTempDirectory((root) => {
    assert.throws(
      () => extractZipBuffer(makeZip([{ name: 'index.html', data: 'secret', flags: 1 }]), root),
      /Encrypted ZIP/
    );
  });

  withTempDirectory((root) => {
    assert.throws(
      () => extractZipBuffer(makeZip([{
        name: 'index.html',
        data: 'target',
        externalAttributes: (0o120777 << 16) >>> 0
      }]), root),
      /Symbolic links/
    );
  });

  withTempDirectory((root) => {
    assert.throws(
      () => extractZipBuffer(makeZip([{ name: 'index.html', data: '1234567890' }]), root, { maxUncompressedBytes: 5 }),
      /Expanded ZIP content exceeds/
    );
  });
});
