import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { initializePortal } from '../src/app.mjs';
import { createBackup, verifyBackupArchive } from '../src/backup.mjs';

function setCookies(response) {
  const values = response.headers.getSetCookie
    ? response.headers.getSetCookie()
    : [response.headers.get('set-cookie')].filter(Boolean);
  return values.map((value) => value.split(';', 1)[0]);
}

function mergeCookieJar(existing, response) {
  const jar = new Map();
  for (const pair of String(existing || '').split(';').map((value) => value.trim()).filter(Boolean)) {
    const index = pair.indexOf('=');
    if (index > 0) jar.set(pair.slice(0, index), pair.slice(index + 1));
  }
  for (const pair of setCookies(response)) {
    const index = pair.indexOf('=');
    if (index > 0) jar.set(pair.slice(0, index), pair.slice(index + 1));
  }
  return [...jar.entries()].map(([name, value]) => `${name}=${value}`).join('; ');
}

function csrfFrom(html) {
  return html.match(/<meta name="csrf-token" content="([^"]+)"/)?.[1]
    || html.match(/name="csrf" value="([^"]+)"/)?.[1]
    || '';
}

function htmlPackage(title, marker = 'v1') {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title></head><body><h1>${title}</h1><p>${marker}</p></body></html>`;
}

async function login(base, email, password, cookie = '') {
  const response = await fetch(`${base}/login`, {
    method: 'POST',
    redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ email, password, next: '/my-library' })
  });
  return { response, cookie: mergeCookieJar(cookie, response) };
}

test('community portal supports public access, accounts, SPIN votes, comments, revisions, premium gates, administration, branding, and backups', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-v02-test-'));
  const portal = await initializePortal({
    projectRoot: path.resolve('.'),
    dataDir: path.join(root, 'data'),
    backupDir: path.join(root, 'backups'),
    publicBaseUrl: 'http://127.0.0.1',
    adminEmail: 'owner@example.com',
    adminName: 'Portal Owner',
    adminPassword: 'A-Test-Password-123!',
    sessionSecret: 'test-session-secret-with-at-least-thirty-two-characters',
    privacySalt: 'test-privacy-salt-with-at-least-thirty-two-characters',
    nodeEnv: 'test',
    captchaBypass: true,
    spinVerifiedMinVotes: 1,
    spinVerifiedThresholdPercent: 75
  });
  const server = portal.createHttpServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  const base = `http://127.0.0.1:${address.port}`;

  try {
    const health = await fetch(`${base}/health`);
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { ok: true, storage: 'local', version: '0.3.0', users: 1 });

    const home = await fetch(`${base}/`);
    assert.equal(home.status, 200);
    const anonymousCookie = mergeCookieJar('', home);
    const homeHtml = await home.text();
    assert.match(homeHtml, /class="catalog-banner"/);
    assert.match(homeHtml, /class="card-grid"/);
    assert.doesNotMatch(homeHtml, /class="hero"/);
    assert.match(homeHtml, /Turbofan Engine Exploded View/);

    const initialContent = portal.db.getContentById('sample-turbofan-engine');
    const initialVersionId = initialContent.current_version_id;
    assert.equal(initialContent.version, '1.0');

    const detail = await fetch(`${base}/learn/turbofan-engine-exploded-view`, { headers: { Cookie: anonymousCookie } });
    assert.equal(detail.status, 200);
    const detailHtml = await detail.text();
    assert.match(detailHtml, /SPIN verified/);
    assert.match(detailHtml, /I am able to install/);
    assert.match(detailHtml, /Community message box/);
    assert.match(detailHtml, /Open interactive view/);

    const eventResponse = await fetch(`${base}/api/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: anonymousCookie },
      body: JSON.stringify({ eventType: 'content_view', contentId: initialContent.id, metadata: { test: true } })
    });
    assert.equal(eventResponse.status, 202);

    const likeResponse = await fetch(`${base}/api/content/${initialContent.id}/like`, {
      method: 'POST',
      headers: { Cookie: anonymousCookie }
    });
    assert.equal(likeResponse.status, 200);
    assert.equal((await likeResponse.json()).active, true);

    const voteResponse = await fetch(`${base}/api/content/${initialContent.id}/install-vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: anonymousCookie },
      body: JSON.stringify({ vote: 'able' })
    });
    assert.equal(voteResponse.status, 200);
    const vote = await voteResponse.json();
    assert.equal(vote.vote, 'able');
    assert.equal(vote.able, 1);
    assert.equal(vote.status.label, 'SPIN verified');

    const anonymousComment = await fetch(`${base}/content/${initialContent.id}/comments`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: anonymousCookie },
      body: new URLSearchParams({
        authorName: 'Mac Tester',
        commentType: 'error',
        body: 'Step 4 fails on macOS. Please add the missing permission command.'
      })
    });
    assert.equal(anonymousComment.status, 303);
    assert.match(anonymousComment.headers.get('location') || '', /\?message=.*#community-comments$/);
    const rootComment = portal.db.listCommentsForContent(initialContent.id, true).find((item) => !item.parent_id);
    assert.ok(rootComment);
    assert.equal(rootComment.version_id, initialVersionId);
    assert.equal(rootComment.comment_type, 'error');

    const register = await fetch(`${base}/register`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: anonymousCookie },
      body: new URLSearchParams({
        name: 'Community Member',
        email: 'member@example.com',
        password: 'Member-Password-123!',
        next: '/my-library'
      })
    });
    assert.equal(register.status, 303);
    let memberCookie = mergeCookieJar(anonymousCookie, register);
    const member = portal.db.getUserByEmail('member@example.com');
    assert.ok(member);
    assert.equal(member.role, 'member');
    assert.equal(member.subscription_status, 'free');

    const memberDetail = await fetch(`${base}/learn/turbofan-engine-exploded-view`, { headers: { Cookie: memberCookie } });
    const memberDetailHtml = await memberDetail.text();
    const memberCsrf = csrfFrom(memberDetailHtml);
    assert.ok(memberCsrf);
    assert.match(memberDetailHtml, /Favorite/);
    assert.match(memberDetailHtml, /Follow updates/);

    const favorite = await fetch(`${base}/api/content/${initialContent.id}/favorite`, {
      method: 'POST',
      headers: { Cookie: memberCookie, 'X-CSRF-Token': memberCsrf }
    });
    assert.equal(favorite.status, 200);
    assert.equal((await favorite.json()).active, true);

    const follow = await fetch(`${base}/api/content/${initialContent.id}/follow`, {
      method: 'POST',
      headers: { Cookie: memberCookie, 'X-CSRF-Token': memberCsrf }
    });
    assert.equal(follow.status, 200);
    assert.equal((await follow.json()).active, true);

    const memberLibrary = await fetch(`${base}/my-library`, { headers: { Cookie: memberCookie } });
    assert.equal(memberLibrary.status, 200);
    assert.match(await memberLibrary.text(), /Turbofan Engine Exploded View/);

    const badLogin = await login(base, 'owner@example.com', 'wrong-password', anonymousCookie);
    assert.equal(badLogin.response.status, 401);

    const adminLogin = await login(base, 'owner@example.com', 'A-Test-Password-123!', anonymousCookie);
    assert.equal(adminLogin.response.status, 303);
    let adminCookie = adminLogin.cookie;

    const admin = await fetch(`${base}/admin`, { headers: { Cookie: adminCookie } });
    assert.equal(admin.status, 200);
    const adminHtml = await admin.text();
    assert.match(adminHtml, /Content and community/);
    assert.match(adminHtml, /Install success/);
    assert.match(adminHtml, /Message inbox/);
    const adminCsrf = csrfFrom(adminHtml);
    assert.ok(adminCsrf);

    const invalidForm = new FormData();
    invalidForm.set('csrf', 'invalid');
    invalidForm.set('title', 'Rejected');
    const invalidUpload = await fetch(`${base}/admin/content`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie },
      body: invalidForm
    });
    assert.equal(invalidUpload.status, 403);

    const premiumForm = new FormData();
    premiumForm.set('csrf', adminCsrf);
    premiumForm.set('title', 'Premium Hydraulic Pump X-Ray');
    premiumForm.set('category', 'Industrial');
    premiumForm.set('contentType', 'X-Ray View');
    premiumForm.set('icon', 'xray');
    premiumForm.set('version', '1.0');
    premiumForm.set('accessLevel', 'premium');
    premiumForm.set('tags', 'hydraulic,pump,premium');
    premiumForm.set('summary', 'Inspect a premium internal flow path.');
    premiumForm.set('description', 'Premium access test document.');
    premiumForm.set('published', 'on');
    premiumForm.set('verificationEnabled', 'on');
    premiumForm.set('package', new Blob([htmlPackage('Premium Hydraulic Pump')], { type: 'text/html' }), 'pump.html');

    const premiumUpload = await fetch(`${base}/admin/content`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie },
      body: premiumForm
    });
    assert.equal(premiumUpload.status, 303);
    const premium = portal.db.listAdminContents().find((item) => item.title === 'Premium Hydraulic Pump X-Ray');
    assert.ok(premium);
    assert.equal(premium.access_level, 'premium');

    const premiumAnonymousPage = await fetch(`${base}/learn/${premium.slug}`, { headers: { Cookie: anonymousCookie } });
    assert.equal(premiumAnonymousPage.status, 200);
    const premiumAnonymousHtml = await premiumAnonymousPage.text();
    assert.match(premiumAnonymousHtml, /Premium learning package/);
    assert.match(premiumAnonymousHtml, /Access required to post feedback/);
    assert.doesNotMatch(premiumAnonymousHtml, /data-install-vote="able"/);
    const premiumAnonymousVote = await fetch(`${base}/api/content/${premium.id}/install-vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: anonymousCookie },
      body: JSON.stringify({ vote: 'able' })
    });
    assert.equal(premiumAnonymousVote.status, 403);
    const premiumAnonymousComment = await fetch(`${base}/content/${premium.id}/comments`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: anonymousCookie },
      body: new URLSearchParams({ authorName: 'No Access', commentType: 'error', body: 'Should not be accepted.' })
    });
    assert.equal(premiumAnonymousComment.status, 303);
    assert.equal(portal.db.listCommentsForContent(premium.id, true).length, 0);
    const premiumAnonymousPreview = await fetch(`${base}/preview/${premium.id}`, { headers: { Cookie: anonymousCookie }, redirect: 'manual' });
    assert.equal(premiumAnonymousPreview.status, 403);
    const premiumFreePreview = await fetch(`${base}/preview/${premium.id}`, { headers: { Cookie: memberCookie }, redirect: 'manual' });
    assert.equal(premiumFreePreview.status, 403);

    const revisionForm = new FormData();
    revisionForm.set('csrf', adminCsrf);
    revisionForm.set('version', '1.1');
    revisionForm.set('changeNotes', 'Added the missing macOS permission step reported by the community.');
    revisionForm.set('published', 'on');
    revisionForm.set('package', new Blob([htmlPackage('Turbofan Engine Exploded View', 'revision-1.1')], { type: 'text/html' }), 'turbofan-v1.1.html');
    const revisionUpload = await fetch(`${base}/admin/content/${initialContent.id}/versions`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie },
      body: revisionForm
    });
    assert.equal(revisionUpload.status, 303);

    const revised = portal.db.getContentById(initialContent.id);
    assert.equal(revised.version, '1.1');
    assert.notEqual(revised.current_version_id, initialVersionId);
    const versions = portal.db.listContentVersions(initialContent.id);
    assert.equal(versions.length, 2);
    assert.equal(versions.find((item) => item.id === initialVersionId)?.status, 'archived');
    assert.equal(versions.find((item) => item.id === revised.current_version_id)?.status, 'published');
    assert.deepEqual(portal.db.installVoteStats(initialContent.id, revised.current_version_id), { able: 0, unable: 0, total: 0, ablePercent: 0 });
    assert.equal(portal.db.getComment(rootComment.id).version_id, initialVersionId);

    const followedAfterRevision = portal.db.listUserLibrary(member.id).following.find((item) => item.id === initialContent.id);
    assert.ok(followedAfterRevision);
    assert.equal(Number(followedAfterRevision.has_update), 1);

    const revisedPublicPage = await fetch(`${base}/learn/turbofan-engine-exploded-view`, { headers: { Cookie: anonymousCookie } });
    const revisedPublicHtml = await revisedPublicPage.text();
    assert.match(revisedPublicHtml, /Revision 1\.1/);
    assert.match(revisedPublicHtml, /Revision 1\.0/);
    assert.match(revisedPublicHtml, /Step 4 fails on macOS/);

    const commentsPage = await fetch(`${base}/admin/comments`, { headers: { Cookie: adminCookie } });
    assert.equal(commentsPage.status, 200);
    assert.match(await commentsPage.text(), /Step 4 fails on macOS/);

    const reply = await fetch(`${base}/admin/comments/${rootComment.id}/reply`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
      body: new URLSearchParams({ csrf: adminCsrf, body: 'Thank you. The missing command is included in revision 1.1.' })
    });
    assert.equal(reply.status, 303);
    assert.match(reply.headers.get('location') || '', /\?status=open&message=.*#comment-/);

    const resolved = await fetch(`${base}/admin/comments/${rootComment.id}/status`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
      body: new URLSearchParams({ csrf: adminCsrf, status: 'resolved' })
    });
    assert.equal(resolved.status, 303);
    assert.equal(portal.db.getComment(rootComment.id).status, 'resolved');

    const publicResolvedPage = await fetch(`${base}/learn/turbofan-engine-exploded-view`, { headers: { Cookie: anonymousCookie } });
    const publicResolvedHtml = await publicResolvedPage.text();
    assert.match(publicResolvedHtml, /Publisher team/);
    assert.match(publicResolvedHtml, /Resolved/);
    assert.match(publicResolvedHtml, /included in revision 1\.1/);

    const createAdmin = await fetch(`${base}/admin/users`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
      body: new URLSearchParams({
        csrf: adminCsrf,
        name: 'Second Administrator',
        email: 'admin2@example.com',
        password: 'Second-Admin-Password-123!',
        role: 'admin',
        subscriptionStatus: 'premium'
      })
    });
    assert.equal(createAdmin.status, 303);
    assert.equal(portal.db.getUserByEmail('admin2@example.com').role, 'admin');

    const premiumGrant = await fetch(`${base}/admin/users/${member.id}`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
      body: new URLSearchParams({ csrf: adminCsrf, role: 'member', status: 'active', subscriptionStatus: 'premium' })
    });
    assert.equal(premiumGrant.status, 303);
    assert.equal(portal.db.getUserById(member.id).subscription_status, 'premium');

    const owner = portal.db.getUserByEmail('owner@example.com');
    const lastSuperAdminGuard = await fetch(`${base}/admin/users/${owner.id}`, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
      body: new URLSearchParams({ csrf: adminCsrf, role: 'admin', status: 'active', subscriptionStatus: 'premium' })
    });
    assert.equal(lastSuperAdminGuard.status, 303);
    assert.match(lastSuperAdminGuard.headers.get('location') || '', /last%20active%20super%20administrator/i);
    assert.equal(portal.db.getUserById(owner.id).role, 'super_admin');

    const premiumMemberPreview = await fetch(`${base}/preview/${premium.id}`, { headers: { Cookie: memberCookie } });
    assert.equal(premiumMemberPreview.status, 200);
    assert.match(await premiumMemberPreview.text(), /Premium Hydraulic Pump/);

    const directPackageBypass = await fetch(`${base}/media/${premium.package_key}`, { headers: { Cookie: anonymousCookie } });
    assert.equal(directPackageBypass.status, 404);

    const branding = new FormData();
    branding.set('csrf', adminCsrf);
    branding.set('portalName', 'SPIN Learning Commons');
    branding.set('organizationName', 'Example Engineering');
    branding.set('productTagline', 'Test every step. Improve every revision.');
    branding.set('portalTagline', 'A community-reviewed library for practical systems learning.');
    const brandingSave = await fetch(`${base}/admin/branding`, {
      method: 'POST',
      redirect: 'manual',
      headers: { Cookie: adminCookie },
      body: branding
    });
    assert.equal(brandingSave.status, 303);
    const brandedHome = await fetch(`${base}/`);
    const brandedHtml = await brandedHome.text();
    assert.match(brandedHtml, /SPIN Learning Commons/);
    assert.match(brandedHtml, /Test every step\. Improve every revision\./);

    const backup = await createBackup({ db: portal.db, storage: portal.storage, config: portal.config });
    assert.ok(fs.existsSync(backup.archivePath));
    const verified = verifyBackupArchive(backup.archivePath);
    assert.equal(verified.valid, true);
    assert.equal(verified.archiveChecksumVerified, true);
    assert.equal(verified.manifest.applicationVersion, '0.3.0');
    assert.ok(verified.manifest.files.some((file) => file.path === 'portal.sqlite'));

    const checksumPath = `${backup.archivePath}.sha256`;
    const originalChecksum = fs.readFileSync(checksumPath, 'utf8');
    fs.writeFileSync(checksumPath, `${'0'.repeat(64)}  ${path.basename(backup.archivePath)}\n`);
    assert.throws(() => verifyBackupArchive(backup.archivePath), /checksum does not match/);
    fs.writeFileSync(checksumPath, originalChecksum);
  } finally {
    await new Promise((resolve) => server.close(resolve));
    portal.close();
    fs.rmSync(root, { recursive: true, force: true });
  }
});
