import test from 'node:test';
import assert from 'node:assert/strict';
import { createHumanChallenge, verifyHumanChallenge } from '../src/captcha.mjs';
import { completeGoogleAuthorization, createGoogleAuthorization } from '../src/oauth.mjs';

const baseConfig = {
  sessionSecret: 'test-session-secret-with-at-least-thirty-two-characters',
  turnstileEnabled: false,
  captchaBypass: false,
  googleEnabled: true,
  googleClientId: 'example-client.apps.googleusercontent.com',
  googleClientSecret: 'example-client-secret',
  googleRedirectUri: 'http://localhost:3000/auth/google/callback'
};

const request = { headers: {}, socket: { remoteAddress: '127.0.0.1' } };

test('local human challenge validates the signed answer and rejects a wrong answer', async () => {
  const challenge = createHumanChallenge(baseConfig, 'register');
  assert.equal(challenge.mode, 'local');
  const [left, right] = challenge.question.split('+').map((value) => Number.parseInt(value.trim(), 10));
  const correct = await verifyHumanChallenge({
    config: baseConfig,
    fields: { captchaToken: challenge.token, captchaAnswer: String(left + right) },
    req: request,
    action: 'register'
  });
  assert.equal(correct.success, true);

  const wrong = await verifyHumanChallenge({
    config: baseConfig,
    fields: { captchaToken: challenge.token, captchaAnswer: String(left + right + 1) },
    req: request,
    action: 'register'
  });
  assert.equal(wrong.success, false);
});

test('Google sign-in uses state and PKCE, then requires a verified Google email profile', async () => {
  const authorization = createGoogleAuthorization(baseConfig, '/learn/example');
  const authorizationUrl = new URL(authorization.authorizationUrl);
  assert.equal(authorizationUrl.origin, 'https://accounts.google.com');
  assert.equal(authorizationUrl.pathname, '/o/oauth2/v2/auth');
  assert.equal(authorizationUrl.searchParams.get('response_type'), 'code');
  assert.equal(authorizationUrl.searchParams.get('scope'), 'openid email profile');
  assert.equal(authorizationUrl.searchParams.get('code_challenge_method'), 'S256');
  assert.ok(authorizationUrl.searchParams.get('code_challenge'));
  assert.ok(authorizationUrl.searchParams.get('state'));

  const originalFetch = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, options = {}) => {
    calls.push({ url: String(url), options });
    if (calls.length === 1) {
      return new Response(JSON.stringify({ access_token: 'access-token' }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    return new Response(JSON.stringify({
      sub: 'google-subject-123',
      email: 'verified@example.com',
      email_verified: true,
      name: 'Verified User',
      picture: 'https://example.com/avatar.png'
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };

  try {
    const profile = await completeGoogleAuthorization({
      config: baseConfig,
      code: 'authorization-code',
      state: authorizationUrl.searchParams.get('state'),
      cookieToken: authorization.cookieToken
    });
    assert.deepEqual(profile, {
      subject: 'google-subject-123',
      email: 'verified@example.com',
      name: 'Verified User',
      picture: 'https://example.com/avatar.png',
      returnTo: '/learn/example'
    });
    assert.equal(calls[0].url, 'https://oauth2.googleapis.com/token');
    assert.match(String(calls[0].options.body), /code_verifier=/);
    assert.equal(calls[1].url, 'https://openidconnect.googleapis.com/v1/userinfo');
    assert.equal(calls[1].options.headers.Authorization, 'Bearer access-token');
  } finally {
    globalThis.fetch = originalFetch;
  }
});
