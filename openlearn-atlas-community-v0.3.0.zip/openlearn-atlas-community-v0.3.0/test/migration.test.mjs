import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { PortalDatabase } from '../src/db.mjs';

function createV1Database(databasePath) {
  fs.mkdirSync(path.dirname(databasePath), { recursive: true });
  const db = new DatabaseSync(databasePath);
  db.exec(`
    PRAGMA foreign_keys=ON;
    CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
    INSERT INTO schema_migrations(version, applied_at) VALUES (1, '2026-01-01T00:00:00.000Z');
    CREATE TABLE contents (
      id TEXT PRIMARY KEY,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      summary TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL,
      content_type TEXT NOT NULL,
      tags_json TEXT NOT NULL DEFAULT '[]',
      icon TEXT NOT NULL DEFAULT '&#9672;',
      version TEXT NOT NULL DEFAULT '1.0',
      status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft', 'published', 'archived')),
      featured INTEGER NOT NULL DEFAULT 0,
      package_key TEXT NOT NULL,
      package_filename TEXT NOT NULL,
      package_size INTEGER NOT NULL DEFAULT 0,
      preview_entry TEXT NOT NULL,
      thumbnail_key TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      content_id TEXT,
      visitor_hash TEXT NOT NULL,
      session_hash TEXT,
      referrer TEXT,
      user_agent TEXT,
      metadata_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE SET NULL
    );
    CREATE TABLE likes (
      content_id TEXT NOT NULL,
      visitor_hash TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(content_id, visitor_hash),
      FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE
    );
    CREATE TABLE content_revisions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      content_id TEXT NOT NULL,
      snapshot_json TEXT NOT NULL,
      changed_by TEXT NOT NULL,
      reason TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE
    );
    CREATE TABLE audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor TEXT NOT NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT,
      metadata_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL
    );
  `);
  db.prepare(`
    INSERT INTO contents (
      id, slug, title, summary, description, category, content_type, tags_json, icon,
      version, status, featured, package_key, package_filename, package_size,
      preview_entry, thumbnail_key, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'legacy-doc',
    'legacy-document',
    'Legacy Document',
    'Existing summary',
    'Existing description',
    'Legacy',
    'Interactive HTML',
    '["existing","safe"]',
    'book',
    '4.7',
    'published',
    1,
    'content/legacy-doc/package/legacy.html',
    'legacy.html',
    1234,
    'index.html',
    'content/legacy-doc/thumbnail.svg',
    '2026-01-01T00:00:00.000Z',
    '2026-02-01T00:00:00.000Z'
  );
  db.prepare(`INSERT INTO events(event_type, content_id, visitor_hash, metadata_json, created_at) VALUES (?, ?, ?, ?, ?)`)
    .run('content_view', 'legacy-doc', 'visitor-1', '{}', '2026-02-02T00:00:00.000Z');
  db.prepare(`INSERT INTO likes(content_id, visitor_hash, active, updated_at) VALUES (?, ?, 1, ?)`)
    .run('legacy-doc', 'visitor-1', '2026-02-02T00:00:00.000Z');
  db.close();
}

test('v0.1 database migrates to the current schema without deleting content, events, likes, or package references', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-migration-test-'));
  const databasePath = path.join(root, 'portal.sqlite');
  createV1Database(databasePath);

  const db = new PortalDatabase(databasePath);
  try {
    const migrated = db.getContentById('legacy-doc');
    assert.ok(migrated);
    assert.equal(migrated.title, 'Legacy Document');
    assert.equal(migrated.version, '4.7');
    assert.equal(migrated.access_level, 'public');
    assert.equal(migrated.verification_enabled, true);
    assert.equal(migrated.current_version_id, 'legacy-legacy-doc');
    assert.deepEqual(migrated.tags, ['existing', 'safe']);

    const versions = db.listContentVersions('legacy-doc');
    assert.equal(versions.length, 1);
    assert.equal(versions[0].id, 'legacy-legacy-doc');
    assert.equal(versions[0].status, 'published');
    assert.equal(versions[0].package_key, 'content/legacy-doc/package/legacy.html');

    assert.equal(db.db.prepare('SELECT COUNT(*) AS count FROM events').get().count, 1);
    assert.equal(db.likeCount('legacy-doc'), 1);
    assert.equal(db.db.prepare('SELECT MAX(version) AS version FROM schema_migrations').get().version, 3);
    assert.equal(migrated.media_kind, 'interactive');
  } finally {
    db.close();
    fs.rmSync(root, { recursive: true, force: true });
  }
});
