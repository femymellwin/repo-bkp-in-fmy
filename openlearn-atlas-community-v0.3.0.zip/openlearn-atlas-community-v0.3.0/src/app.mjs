import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { loadConfig } from './config.mjs';
import { PortalDatabase } from './db.mjs';
import { PortalStorage } from './storage.mjs';
import { extractZipBuffer } from './zip.mjs';
import { parseMultipartRequest } from './multipart.mjs';
import { createBackup } from './backup.mjs';
import { createHumanChallenge, verifyHumanChallenge } from './captcha.mjs';
import { completeGoogleAuthorization, createGoogleAuthorization, googleOauthCookieName } from './oauth.mjs';
import { formatForFilename, sanitizeSvg, UPLOAD_ACCEPT } from './formats.mjs';
import { AI_PROVIDERS, generateIconSvg, maskSecret, providerDefinition, testProvider } from './ai.mjs';
import { SHAREPOINT_FIELDS, testSharePointConnection } from './sharepoint.mjs';
import {
  appendSetCookie,
  boolValue,
  cookieString,
  csvCell,
  decodePathSafely,
  escapeXml,
  parseCookies,
  parseFormBody,
  parseJsonBody,
  randomId,
  redirect,
  safeFilename,
  sendFile,
  sendHtml,
  sendJson,
  sendText,
  sha256,
  slugify
} from './utils.mjs';
import {
  createPasswordHash,
  createSession,
  getPortalSession,
  sessionCookieName,
  SlidingWindowRateLimiter,
  validateCsrf,
  verifyPassword
} from './auth.mjs';
import {
  adminCommentsPage,
  adminPage,
  adminUsersPage,
  aiSettingsPage,
  brandingPage,
  contentPage,
  editContentPage,
  errorPage,
  forbiddenPage,
  homePage,
  iconLibraryPage,
  integrationsPage,
  loginPage,
  myLibraryPage,
  notFoundPage,
  registerPage
} from './templates.mjs';
import { renderMarkdown } from './markdown.mjs';

const VISITOR_COOKIE = 'portal_visitor';
const ANALYTICS_SESSION_COOKIE = 'portal_visit_session';
const EVENT_TYPES = new Set([
  'content_view',
  'preview_open',
  'preview_loaded',
  'download_click',
  'preview_new_window',
  'video_play',
  'share',
  'search'
]);
const BUILTIN_ICONS = new Set(['gear', 'xray', 'cube', 'book', 'tool', 'aircraft', 'circuit', 'anatomy', 'video', 'document', 'presentation', 'spreadsheet', 'image', 'diagram', 'flow', 'generic']);

function resolveIconValue(db, value, fallback = 'generic') {
  const requested = String(value || '').trim();
  if (BUILTIN_ICONS.has(requested)) return requested;
  if (requested.startsWith('custom:')) {
    const icon = db.getCustomIcon(requested.slice('custom:'.length));
    if (icon) return requested;
  }
  return fallback;
}
const STAFF_ROLES = new Set(['super_admin', 'admin', 'publisher', 'moderator']);

function generatedThumbnail(title, category, icon) {
  const safeTitle = escapeXml(title).slice(0, 80);
  const safeCategory = escapeXml(category).slice(0, 50);
  const iconText = ({ gear: '&#9881;', xray: 'X-RAY', aircraft: '&#9992;', circuit: '&#9889;', anatomy: '&#9829;', book: 'BOOK', tool: '&#9874;', cube: '&#9672;' })[icon] || '&#9672;';
  return Buffer.from(`<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="900" viewBox="0 0 1200 900">
  <defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#082d27"/><stop offset="0.62" stop-color="#0a6858"/><stop offset="1" stop-color="#15947c"/></linearGradient><radialGradient id="glow"><stop offset="0" stop-color="#f1a64a" stop-opacity="0.72"/><stop offset="1" stop-color="#f1a64a" stop-opacity="0"/></radialGradient></defs>
  <rect width="1200" height="900" fill="url(#bg)"/><circle cx="930" cy="210" r="310" fill="url(#glow)"/>
  <g fill="none" stroke="#ffffff" stroke-opacity="0.18"><ellipse cx="840" cy="420" rx="300" ry="170" transform="rotate(-18 840 420)"/><ellipse cx="840" cy="420" rx="180" ry="320" transform="rotate(25 840 420)"/></g>
  <g transform="translate(815 405)"><rect x="-92" y="-92" width="184" height="184" rx="52" fill="#ffffff" fill-opacity="0.94"/><text x="0" y="24" text-anchor="middle" font-family="Arial, sans-serif" font-size="72" font-weight="700" fill="#0a6858">${iconText}</text></g>
  <g font-family="Arial, sans-serif" fill="#ffffff"><text x="90" y="118" font-size="28" font-weight="700" letter-spacing="5" fill="#b7e6dc">${safeCategory.toUpperCase()}</text><text x="90" y="655" font-size="58" font-weight="700">${safeTitle}</text><text x="90" y="710" font-size="25" fill="#cce4de">Versioned interactive learning</text></g>
</svg>`);
}

function sampleInteractiveHtml() {
  return Buffer.from(`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Turbofan Engine Exploded View</title><style>
:root{--spread:0px;--ink:#112725;--brand:#0a6858;--paper:#eef4f1}*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:var(--paper);color:var(--ink)}header{padding:22px 26px;background:#092e29;color:white;display:flex;justify-content:space-between;align-items:center}header h1{margin:0;font-size:22px}header span{color:#b8d9d2;font-size:12px}.layout{display:grid;grid-template-columns:1fr 300px;min-height:calc(100vh - 74px)}.stage{position:relative;overflow:hidden;display:grid;place-items:center;background:radial-gradient(circle at center,#fff 0,#eef4f1 55%,#dce9e4 100%)}.engine{position:relative;width:min(840px,88vw);height:330px;display:flex;align-items:center;justify-content:center;filter:drop-shadow(0 18px 22px rgba(12,47,40,.14))}.part{position:absolute;height:160px;border-radius:50%;display:grid;place-items:center;transition:transform .35s ease;cursor:pointer;border:3px solid rgba(9,70,59,.18)}.part span{width:66%;height:66%;border-radius:50%;border:9px repeating-conic-gradient(#0a6858 0 9deg,#d6e8e2 9deg 18deg)}.fan{width:170px;background:#dfece7;transform:translateX(calc(-250px - var(--spread)*2))}.compressor{width:145px;background:#c6ded5;transform:translateX(calc(-100px - var(--spread)))}.combustor{width:175px;height:180px;border-radius:42%;background:#efb361;transform:translateX(45px)}.turbine{width:140px;background:#a9d2c5;transform:translateX(calc(185px + var(--spread)))}.nozzle{width:105px;height:130px;background:#789c93;transform:translateX(calc(300px + var(--spread)*2))}.part.active{outline:5px solid rgba(241,166,74,.42);z-index:5}.panel{padding:26px;background:white;border-left:1px solid #cfddd7}.panel h2{margin-top:0}.panel p{color:#53635f;line-height:1.55}.control{margin:28px 0}.control label{display:block;font-size:12px;font-weight:bold;margin-bottom:8px}.control input{width:100%}.parts{display:grid;gap:8px}.parts button{padding:10px 12px;text-align:left;border:1px solid #d3dfda;border-radius:10px;background:#f8fbfa;cursor:pointer}.parts button:hover{border-color:var(--brand)}.legend{position:absolute;left:22px;bottom:20px;background:rgba(255,255,255,.88);padding:10px 12px;border-radius:10px;font-size:11px}@media(max-width:760px){.layout{grid-template-columns:1fr}.panel{border-left:0;border-top:1px solid #cfddd7}.stage{min-height:460px}.engine{transform:scale(.7)}}
</style></head><body><header><h1>Turbofan Engine / Exploded View</h1><span>Interactive sample included with the portal</span></header><div class="layout"><main class="stage"><div class="engine"><div class="part fan" data-name="Fan" data-text="The fan accelerates a large mass of air. Most bypasses the core and produces efficient thrust."><span></span></div><div class="part compressor" data-name="Compressor" data-text="Multiple compressor stages raise the pressure of the core airflow before combustion."><span></span></div><div class="part combustor" data-name="Combustor" data-text="Fuel mixes with compressed air and burns, adding thermal energy to the flow."></div><div class="part turbine" data-name="Turbine" data-text="Turbine stages extract energy from hot gas to drive the compressor and fan."><span></span></div><div class="part nozzle" data-name="Nozzle" data-text="The nozzle accelerates the exhaust stream and contributes to net thrust."></div></div><div class="legend">Select a component or adjust the exploded spacing.</div></main><aside class="panel"><h2 id="name">Engine overview</h2><p id="text">This demonstration shows a simplified turbofan flow path. Use the slider to separate the major assemblies and select a component for an explanation.</p><div class="control"><label for="spread">Exploded spacing</label><input id="spread" type="range" min="0" max="80" value="0"></div><div class="parts"><button data-target="fan">1. Fan</button><button data-target="compressor">2. Compressor</button><button data-target="combustor">3. Combustor</button><button data-target="turbine">4. Turbine</button><button data-target="nozzle">5. Nozzle</button></div></aside></div><script>const parts=[...document.querySelectorAll('.part')];const name=document.getElementById('name');const text=document.getElementById('text');function select(part){parts.forEach(p=>p.classList.toggle('active',p===part));name.textContent=part.dataset.name;text.textContent=part.dataset.text}parts.forEach(p=>p.addEventListener('click',()=>select(p)));document.getElementById('spread').addEventListener('input',e=>document.documentElement.style.setProperty('--spread',e.target.value+'px'));document.querySelectorAll('[data-target]').forEach(b=>b.addEventListener('click',()=>select(document.querySelector('.'+b.dataset.target))));</script></body></html>`);
}

async function ensureSampleContent(db, storage) {
  if (db.countContents() > 0) return;
  const id = 'sample-turbofan-engine';
  const versionId = 'sample-turbofan-engine-v1';
  const packageBuffer = sampleInteractiveHtml();
  const packageKey = `content/${id}/versions/${versionId}/package/turbofan-engine.html`;
  const previewRoot = `content/${id}/versions/${versionId}/preview`;
  const thumbnailKey = `content/${id}/versions/${versionId}/thumbnail.svg`;
  await storage.putBuffer(packageKey, packageBuffer, { contentType: 'text/html; charset=utf-8', cacheControl: 'public, max-age=31536000, immutable', contentDisposition: 'attachment; filename="turbofan-engine.html"' });
  await storage.putBuffer(`${previewRoot}/index.html`, packageBuffer, { contentType: 'text/html; charset=utf-8', cacheControl: 'public, max-age=31536000, immutable' });
  await storage.putBuffer(thumbnailKey, generatedThumbnail('Turbofan Engine Exploded View', 'Aviation', 'aircraft'), { contentType: 'image/svg+xml', cacheControl: 'public, max-age=31536000, immutable' });
  db.createContent({
    id,
    versionId,
    slug: 'turbofan-engine-exploded-view',
    title: 'Turbofan Engine Exploded View',
    summary: 'Separate and inspect the fan, compressor, combustor, turbine, and exhaust nozzle in a guided interactive view.',
    description: 'A self-contained interactive HTML learning package that demonstrates how the major modules of a high-bypass turbofan engine align along the core airflow path. Use the exploded-spacing control and component selectors to explore each module.\n\nThis sample is included so you can test previews, downloads, SPIN verification, community comments, favorites, follows, revision publishing, and analytics immediately after starting the portal.',
    category: 'Aviation',
    contentType: 'Exploded View',
    tags: ['Turbofan', 'Engine', 'Maintenance', 'Aviation'],
    icon: 'aircraft',
    version: '1.0',
    status: 'published',
    featured: true,
    accessLevel: 'public',
    verificationEnabled: true,
    packageKey,
    packageFilename: 'turbofan-engine.html',
    packageSize: packageBuffer.length,
    previewEntry: 'index.html',
    thumbnailKey,
    changeNotes: 'Initial sample release'
  }, 'system-seed');
}

function listBackups(config) {
  if (!fs.existsSync(config.backupDir)) return [];
  return fs.readdirSync(config.backupDir)
    .filter((name) => name.endsWith('.tgz'))
    .map((name) => {
      const stat = fs.statSync(path.join(config.backupDir, name));
      return { name, size: stat.size, mtime: stat.mtimeMs };
    })
    .sort((a, b) => b.mtime - a.mtime)
    .slice(0, 10);
}

function makeVisitorContext(req, res, config) {
  const cookies = parseCookies(req.headers.cookie || '');
  let visitorId = cookies[VISITOR_COOKIE];
  let sessionId = cookies[ANALYTICS_SESSION_COOKIE];
  if (!visitorId || visitorId.length < 20) {
    visitorId = randomId(24);
    appendSetCookie(res, cookieString(VISITOR_COOKIE, visitorId, { maxAge: 365 * 86400, secure: config.secureCookies, sameSite: 'Lax' }));
  }
  if (!sessionId || sessionId.length < 20) {
    sessionId = randomId(18);
    appendSetCookie(res, cookieString(ANALYTICS_SESSION_COOKIE, sessionId, { maxAge: 12 * 3600, secure: config.secureCookies, sameSite: 'Lax' }));
  }
  return {
    visitorHash: sha256(`${config.privacySalt}:${visitorId}`),
    sessionHash: sha256(`${config.privacySalt}:session:${sessionId}`)
  };
}

function applyCommonHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin-allow-popups');
}

function pageHeaders(config) {
  let frameSources = "'self' https://challenges.cloudflare.com";
  if (config.cdnBaseUrl) {
    try { frameSources += ` ${new URL(config.cdnBaseUrl).origin}`; } catch {}
  }
  return {
    'Content-Security-Policy': `default-src 'self'; base-uri 'none'; object-src 'none'; form-action 'self'; frame-ancestors 'none'; script-src 'self' https://challenges.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; frame-src ${frameSources}; connect-src 'self' https://challenges.cloudflare.com; font-src 'self';`,
    'X-Frame-Options': 'DENY'
  };
}

function previewHeaders(config) {
  let ancestor = "'self'";
  try { ancestor = new URL(config.publicBaseUrl).origin; } catch {}
  return {
    'Content-Security-Policy': `sandbox allow-scripts allow-forms allow-modals allow-popups allow-downloads; default-src 'self' data: blob: https:; script-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; style-src 'self' 'unsafe-inline' data: https:; img-src 'self' data: blob: https:; media-src 'self' data: blob: https:; font-src 'self' data: https:; connect-src 'self' https:; worker-src 'self' blob:; frame-src https:; object-src 'none'; base-uri 'self'; frame-ancestors ${ancestor};`,
    'X-Frame-Options': 'SAMEORIGIN',
    'Cross-Origin-Resource-Policy': 'same-site',
    'Referrer-Policy': 'no-referrer'
  };
}

function sendPage(res, status, html, config) {
  sendHtml(res, status, html, pageHeaders(config));
}

function flashRedirect(res, destination, message, type = 'success') {
  const hashIndex = destination.indexOf('#');
  const base = hashIndex >= 0 ? destination.slice(0, hashIndex) : destination;
  const fragment = hashIndex >= 0 ? destination.slice(hashIndex) : '';
  const separator = base.includes('?') ? '&' : '?';
  redirect(res, `${base}${separator}message=${encodeURIComponent(message)}&type=${encodeURIComponent(type)}${fragment}`);
}

function absoluteUrl(config, url) {
  try { return new URL(url, config.publicBaseUrl).toString(); } catch { return url; }
}

function verificationStatus(stats, config) {
  if (!stats || !stats.total) return { ...stats, label: 'Awaiting community votes', className: 'pending' };
  if (stats.total < config.spinVerifiedMinVotes) return { ...stats, label: 'Verification in progress', className: 'pending' };
  if (stats.ablePercent >= config.spinVerifiedThresholdPercent) return { ...stats, label: 'SPIN verified', className: 'verified' };
  return { ...stats, label: 'Needs revision', className: 'issue' };
}

function decorateContent(content, db, storage, config) {
  const stats = db.contentStats(content.id);
  const format = formatForFilename(content.package_filename) || { kind: content.media_kind || 'interactive', label: 'Interactive package', viewer: 'sandbox' };
  return {
    ...content,
    thumbnailUrl: storage.mediaUrl(content.thumbnail_key),
    thumbnailAbsoluteUrl: absoluteUrl(config, storage.mediaUrl(content.thumbnail_key)),
    previewUrl: content.preview_entry ? storage.previewUrl(content.id, content.current_version_id, content.preview_entry) : '',
    viewUrl: `/view/${encodeURIComponent(content.id)}`,
    format,
    stats,
    verificationStatus: verificationStatus(stats.verification, config)
  };
}

function uniqueSlug(db, requested) {
  const base = slugify(requested);
  let candidate = base;
  let index = 2;
  while (db.slugExists(candidate)) {
    candidate = `${base}-${index}`;
    index += 1;
  }
  return candidate;
}

function validatePackage(file) {
  if (!file || !file.data?.length) throw new Error('Choose a learning package file');
  const descriptor = formatForFilename(file.filename || '');
  if (!descriptor) throw new Error(`Unsupported package format. Allowed: ${UPLOAD_ACCEPT}`);
  if (descriptor.magic && !descriptor.magic(file.data)) throw new Error(`The selected ${descriptor.label} file is not valid`);
  return descriptor;
}

function validateImage(file, label = 'Image') {
  if (!file || !file.data?.length) return null;
  if (file.data.length > 10 * 1024 * 1024) throw new Error(`${label} must be smaller than 10 MB`);
  const extension = path.extname(file.filename || '').toLowerCase();
  const allowed = new Map([['.png', 'image/png'], ['.jpg', 'image/jpeg'], ['.jpeg', 'image/jpeg'], ['.webp', 'image/webp']]);
  if (!allowed.has(extension)) throw new Error(`${label} must be PNG, JPG, or WebP`);
  return { extension, contentType: allowed.get(extension) };
}

function requiredText(fields, name, max) {
  const value = String(fields[name] || '').trim();
  if (!value) throw new Error(`${name} is required`);
  return value.slice(0, max);
}

function clientKey(req) {
  return String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
}

function safeNext(value, fallback = '/') {
  const next = String(value || fallback);
  return next.startsWith('/') && !next.startsWith('//') ? next.slice(0, 500) : fallback;
}

function flashFromUrl(url) {
  return url.searchParams.get('message')
    ? { message: url.searchParams.get('message'), type: url.searchParams.get('type') }
    : null;
}

function permissionsFor(session) {
  const role = session?.role || '';
  return {
    staff: STAFF_ROLES.has(role),
    publish: ['super_admin', 'admin', 'publisher'].includes(role),
    moderate: ['super_admin', 'admin', 'publisher', 'moderator'].includes(role),
    manageBranding: ['super_admin', 'admin'].includes(role),
    manageUsers: role === 'super_admin',
    backup: ['super_admin', 'admin'].includes(role)
  };
}

function canAccessContent(content, session) {
  if (session && STAFF_ROLES.has(session.role)) return { allowed: true, reason: 'staff' };
  if (content.access_level === 'public') return { allowed: true, reason: 'public' };
  if (content.access_level === 'login') {
    return session
      ? { allowed: true, reason: 'account' }
      : { allowed: false, reason: 'login', message: 'Create a free account or sign in to open this resource.' };
  }
  if (content.access_level === 'premium') {
    return session?.subscriptionStatus === 'premium'
      ? { allowed: true, reason: 'premium' }
      : { allowed: false, reason: 'premium', message: session ? 'This resource requires premium membership. An administrator can grant premium access in this build.' : 'Sign in with a premium account to open this resource.' };
  }
  return { allowed: false, reason: 'unknown', message: 'This resource is restricted.' };
}

async function storePackageRevision({ storage, config, contentId, versionId, packageFile, thumbnailFile, currentThumbnailKey, title, category, icon }) {
  const descriptor = validatePackage(packageFile);
  const thumbnailInfo = validateImage(thumbnailFile, 'Thumbnail');
  let packageData = packageFile.data;
  if (descriptor.sanitizeSvg) {
    packageData = Buffer.from(sanitizeSvg(packageData.toString('utf8')), 'utf8');
  }
  const packageFilename = safeFilename(packageFile.filename || `package${descriptor.extension}`);
  const versionRoot = `content/${contentId}/versions/${versionId}`;
  const packageKey = `${versionRoot}/package/${packageFilename}`;
  const previewRoot = `${versionRoot}/preview`;
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-upload-'));
  try {
    let previewEntry = '';
    const previewDirectory = path.join(tempRoot, 'preview');
    if (descriptor.viewer === 'sandbox') {
      fs.mkdirSync(previewDirectory, { recursive: true });
      previewEntry = 'index.html';
      if (descriptor.extension === '.zip') {
        const result = extractZipBuffer(packageData, previewDirectory, { maxFiles: config.maxZipFiles, maxUncompressedBytes: config.maxExtractedBytes });
        previewEntry = result.entrypoint;
      } else {
        fs.writeFileSync(path.join(previewDirectory, 'index.html'), packageData);
      }
    } else if (descriptor.viewer === 'markdown') {
      // Markdown and plain-text articles are rendered once at upload time into a
      // styled standalone HTML preview, so both storage drivers serve them statically.
      fs.mkdirSync(previewDirectory, { recursive: true });
      previewEntry = 'index.html';
      fs.writeFileSync(path.join(previewDirectory, 'index.html'), renderMarkdown(packageData.toString('utf8'), { title }));
    }

    await storage.putBuffer(packageKey, packageData, {
      contentType: descriptor.contentType,
      cacheControl: 'public, max-age=31536000, immutable',
      contentDisposition: descriptor.viewer === 'download'
        ? `attachment; filename="${packageFilename.replaceAll('"', '')}"`
        : `inline; filename="${packageFilename.replaceAll('"', '')}"`
    });
    if (previewEntry) {
      await storage.putDirectory(previewRoot, previewDirectory, { cacheControl: 'public, max-age=31536000, immutable' });
    }

    let thumbnailKey = currentThumbnailKey || null;
    if (thumbnailInfo) {
      thumbnailKey = `${versionRoot}/thumbnail${thumbnailInfo.extension}`;
      await storage.putBuffer(thumbnailKey, thumbnailFile.data, { contentType: thumbnailInfo.contentType, cacheControl: 'public, max-age=31536000, immutable' });
    } else if (descriptor.kind === 'image' && packageData.length <= 8 * 1024 * 1024) {
      // Image resources can use themselves as the gallery thumbnail.
      thumbnailKey = `${versionRoot}/thumbnail${descriptor.extension}`;
      await storage.putBuffer(thumbnailKey, packageData, { contentType: descriptor.contentType, cacheControl: 'public, max-age=31536000, immutable' });
    } else if (!thumbnailKey) {
      thumbnailKey = `${versionRoot}/thumbnail.svg`;
      await storage.putBuffer(thumbnailKey, generatedThumbnail(title, category, icon), { contentType: 'image/svg+xml', cacheControl: 'public, max-age=31536000, immutable' });
    }

    return {
      packageKey,
      packageFilename,
      packageSize: packageData.length,
      previewEntry,
      thumbnailKey,
      mediaKind: descriptor.kind
    };
  } finally {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
}

export async function initializePortal(overrides = {}) {
  const config = loadConfig(overrides);
  fs.mkdirSync(config.dataDir, { recursive: true });
  fs.mkdirSync(config.backupDir, { recursive: true });
  const db = new PortalDatabase(config.databasePath);
  const storage = new PortalStorage(config);
  db.ensureBrandingDefaults(config);
  db.ensureBootstrapAdmin({
    email: config.adminEmail,
    name: config.adminName,
    passwordHash: config.adminPasswordHash || createPasswordHash(config.adminPassword)
  });
  await ensureSampleContent(db, storage);

  const loginLimiter = new SlidingWindowRateLimiter({ limit: 10, windowMs: 15 * 60 * 1000 });
  const registrationLimiter = new SlidingWindowRateLimiter({ limit: 8, windowMs: 60 * 60 * 1000 });
  const eventLimiter = new SlidingWindowRateLimiter({ limit: 240, windowMs: 60 * 1000 });
  const likeLimiter = new SlidingWindowRateLimiter({ limit: 30, windowMs: 60 * 1000 });
  const voteLimiter = new SlidingWindowRateLimiter({ limit: 40, windowMs: 60 * 1000 });
  const commentLimiter = new SlidingWindowRateLimiter({ limit: 12, windowMs: 15 * 60 * 1000 });
  const eventDedupe = new Map();

  function uiConfig() {
    const branding = db.getBranding(config);
    let logoUrl = '';
    if (branding.logoKey) {
      try { logoUrl = storage.mediaUrl(branding.logoKey); } catch {}
    }
    const customIcons = db.listCustomIcons();
    return {
      ...config,
      ...branding,
      logoUrl,
      customIcons,
      customIconMap: Object.fromEntries(customIcons.map((icon) => [`custom:${icon.id}`, icon.svg]))
    };
  }

  function getSession(req) {
    const token = getPortalSession(req, config.sessionSecret);
    if (!token) return null;
    const user = token.userId ? db.getUserById(token.userId) : db.getUserByEmail(token.email);
    if (!user || user.status !== 'active') return null;
    return {
      ...token,
      userId: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      subscriptionStatus: user.subscription_status,
      avatarUrl: user.avatar_url
    };
  }

  function requireSession(req, res, nextPath = req.url || '/') {
    const session = getSession(req);
    if (!session) {
      redirect(res, `/login?next=${encodeURIComponent(safeNext(nextPath))}`);
      return null;
    }
    return session;
  }

  function requirePermission(req, res, permission, nextPath = req.url || '/') {
    const session = requireSession(req, res, nextPath);
    if (!session) return null;
    const permissions = permissionsFor(session);
    if (!permissions[permission]) {
      const viewConfig = uiConfig();
      sendPage(res, 403, forbiddenPage({ config: viewConfig, session }), viewConfig);
      return null;
    }
    return { session, permissions };
  }

  async function handler(req, res) {
    applyCommonHeaders(res);
    const url = new URL(req.url || '/', config.publicBaseUrl);
    const pathname = url.pathname;
    const visitor = makeVisitorContext(req, res, config);
    const session = getSession(req);
    const viewConfig = uiConfig();

    if (pathname === '/health' && req.method === 'GET') {
      return sendJson(res, 200, { ok: db.health(), storage: storage.driver, version: config.applicationVersion, users: db.countUsers() });
    }

    if ((req.method === 'GET' || req.method === 'HEAD') && pathname.startsWith('/assets/')) {
      const relative = decodePathSafely(pathname.slice('/assets/'.length));
      if (!relative) return sendText(res, 400, 'Invalid path');
      return sendFile(req, res, path.join(config.projectRoot, 'public', ...relative.split('/')), { cacheControl: config.nodeEnv === 'production' ? 'public, max-age=86400' : 'no-cache' });
    }

    if ((req.method === 'GET' || req.method === 'HEAD') && pathname.startsWith('/media/')) {
      const key = decodePathSafely(pathname.slice('/media/'.length));
      if (!key) return sendText(res, 400, 'Invalid media path');
      if (key.includes('/package/') || key.includes('/preview/')) return sendText(res, 404, 'Media not found');
      if (storage.driver === 's3') return redirect(res, storage.mediaUrl(key), 302);
      return sendFile(req, res, storage.localPath(key), { cacheControl: 'public, max-age=86400' });
    }

    if ((pathname === '/login' || pathname === '/admin/login') && req.method === 'GET') {
      const next = safeNext(url.searchParams.get('next'), pathname === '/admin/login' ? '/admin' : '/my-library');
      if (session) return redirect(res, next);
      return sendPage(res, 200, loginPage({ config: viewConfig, message: url.searchParams.get('message') || '', next }), viewConfig);
    }

    if ((pathname === '/login' || pathname === '/admin/login') && req.method === 'POST') {
      if (!loginLimiter.consume(clientKey(req))) return sendPage(res, 429, loginPage({ config: viewConfig, message: 'Too many login attempts. Try again later.', next: '/my-library' }), viewConfig);
      const form = await parseFormBody(req, 32 * 1024);
      const next = safeNext(form.next, pathname === '/admin/login' ? '/admin' : '/my-library');
      const user = db.getUserByEmail(form.email);
      const passwordMatches = user && verifyPassword(String(form.password || ''), user.password_hash || '');
      if (!user || !passwordMatches || user.status !== 'active') {
        return sendPage(res, 401, loginPage({ config: viewConfig, message: 'The email or password is incorrect, or the account is disabled.', next }), viewConfig);
      }
      db.touchUserLogin(user.id);
      const token = createSession(user, config.sessionSecret, config.sessionMaxAgeSeconds);
      appendSetCookie(res, cookieString(sessionCookieName(), token, { maxAge: config.sessionMaxAgeSeconds, secure: config.secureCookies, sameSite: 'Lax' }));
      db.recordAudit(user.email, 'user.login', 'session', user.id, { provider: 'local', userAgent: req.headers['user-agent'] || '' });
      return redirect(res, next);
    }

    if (pathname === '/register' && req.method === 'GET') {
      if (!config.allowRegistration) return sendPage(res, 404, notFoundPage({ config: viewConfig, session }), viewConfig);
      if (session) return redirect(res, '/my-library');
      const next = safeNext(url.searchParams.get('next'), '/my-library');
      return sendPage(res, 200, registerPage({ config: viewConfig, message: url.searchParams.get('message') || '', captcha: createHumanChallenge(config, 'register'), next }), viewConfig);
    }

    if (pathname === '/register' && req.method === 'POST') {
      if (!config.allowRegistration) return sendPage(res, 404, notFoundPage({ config: viewConfig, session }), viewConfig);
      if (!registrationLimiter.consume(clientKey(req))) return sendText(res, 429, 'Too many registration attempts');
      const form = await parseFormBody(req, 64 * 1024);
      const next = safeNext(form.next, '/my-library');
      const human = await verifyHumanChallenge({ config, fields: form, req, action: 'register' });
      if (!human.success) return flashRedirect(res, `/register?next=${encodeURIComponent(next)}`, human.reason, 'error');
      try {
        const name = requiredText(form, 'name', 120);
        const email = requiredText(form, 'email', 320).toLowerCase();
        const password = String(form.password || '');
        if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('Enter a valid email address');
        if (password.length < 10) throw new Error('Password must contain at least 10 characters');
        const user = db.createUser({ email, name, passwordHash: createPasswordHash(password), role: 'member', subscriptionStatus: 'free', provider: 'local' });
        db.touchUserLogin(user.id);
        appendSetCookie(res, cookieString(sessionCookieName(), createSession(user, config.sessionSecret, config.sessionMaxAgeSeconds), { maxAge: config.sessionMaxAgeSeconds, secure: config.secureCookies, sameSite: 'Lax' }));
        return redirect(res, next);
      } catch (error) {
        return flashRedirect(res, `/register?next=${encodeURIComponent(next)}`, error.message || 'Account could not be created', 'error');
      }
    }

    if (pathname === '/auth/google' && req.method === 'GET') {
      if (!config.googleEnabled) return flashRedirect(res, '/login', 'Google sign-in is not configured yet.', 'error');
      const auth = createGoogleAuthorization(config, safeNext(url.searchParams.get('next'), '/my-library'));
      appendSetCookie(res, cookieString(googleOauthCookieName(), auth.cookieToken, { maxAge: 600, secure: config.secureCookies, sameSite: 'Lax', path: '/auth/google' }));
      return redirect(res, auth.authorizationUrl, 302);
    }

    if (pathname === '/auth/google/callback' && req.method === 'GET') {
      try {
        const cookies = parseCookies(req.headers.cookie || '');
        const profile = await completeGoogleAuthorization({ config, code: url.searchParams.get('code'), state: url.searchParams.get('state'), cookieToken: cookies[googleOauthCookieName()] });
        const user = db.upsertGoogleUser(profile);
        if (user.status !== 'active') throw new Error('This account is disabled');
        db.touchUserLogin(user.id);
        appendSetCookie(res, cookieString(googleOauthCookieName(), '', { maxAge: 0, secure: config.secureCookies, sameSite: 'Lax', path: '/auth/google' }));
        appendSetCookie(res, cookieString(sessionCookieName(), createSession(user, config.sessionSecret, config.sessionMaxAgeSeconds), { maxAge: config.sessionMaxAgeSeconds, secure: config.secureCookies, sameSite: 'Lax' }));
        db.recordAudit(user.email, 'user.login', 'session', user.id, { provider: 'google' });
        return redirect(res, profile.returnTo);
      } catch (error) {
        appendSetCookie(res, cookieString(googleOauthCookieName(), '', { maxAge: 0, secure: config.secureCookies, sameSite: 'Lax', path: '/auth/google' }));
        return flashRedirect(res, '/login', error.message || 'Google sign-in failed', 'error');
      }
    }

    if ((pathname === '/logout' || pathname === '/admin/logout') && req.method === 'POST') {
      const active = requireSession(req, res, '/');
      if (!active) return;
      const form = await parseFormBody(req, 16 * 1024);
      if (!validateCsrf(req, active, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      appendSetCookie(res, cookieString(sessionCookieName(), '', { maxAge: 0, secure: config.secureCookies, sameSite: 'Lax' }));
      return redirect(res, '/');
    }

    if (pathname === '/my-library' && req.method === 'GET') {
      const active = requireSession(req, res, '/my-library');
      if (!active) return;
      const library = db.listUserLibrary(active.userId);
      const favorites = library.favorites.map((item) => decorateContent(item, db, storage, viewConfig));
      const following = library.following.map((item) => decorateContent(item, db, storage, viewConfig));
      return sendPage(res, 200, myLibraryPage({ config: viewConfig, session: active, favorites, following }), viewConfig);
    }

    const previewMatch = pathname.match(/^\/preview\/([^/]+)(?:\/(.*))?$/);
    if (previewMatch && (req.method === 'GET' || req.method === 'HEAD')) {
      const id = decodeURIComponent(previewMatch[1]);
      const content = db.getContentById(id, true);
      const access = content ? canAccessContent(content, session) : null;
      if (!content || (content.status !== 'published' && !permissionsFor(session).publish) || !access?.allowed) return sendText(res, 403, 'Preview access denied');
      const relative = decodePathSafely(previewMatch[2] || content.preview_entry);
      if (!relative) return sendText(res, 400, 'Invalid preview path');
      const key = storage.previewKey(content.id, content.current_version_id, relative);
      if (storage.driver === 's3') return redirect(res, storage.mediaUrl(key), 302);
      return sendFile(req, res, storage.localPath(key), { cacheControl: 'public, max-age=300', headers: previewHeaders(config) });
    }

    const downloadMatch = pathname.match(/^\/download\/([^/]+)$/);
    if (downloadMatch && (req.method === 'GET' || req.method === 'HEAD')) {
      const id = decodeURIComponent(downloadMatch[1]);
      const content = db.getContentById(id, true);
      if (!content || (content.status !== 'published' && !permissionsFor(session).publish)) return sendText(res, 404, 'Download not found');
      const access = canAccessContent(content, session);
      if (!access.allowed) return flashRedirect(res, `/learn/${encodeURIComponent(content.slug)}`, access.message, 'error');
      if (req.method === 'GET') db.recordEvent({ eventType: 'download', contentId: content.id, ...visitor, referrer: req.headers.referer, userAgent: req.headers['user-agent'], metadata: { filename: content.package_filename, version: content.version } });
      if (storage.driver === 's3') return redirect(res, storage.mediaUrl(content.package_key), 302);
      return sendFile(req, res, storage.localPath(content.package_key), { downloadName: content.package_filename, cacheControl: 'private, no-store' });
    }

    // Inline delivery for the current published package: streams video with
    // HTTP range support and serves PDF/image/SVG packages for in-page viewers.
    const viewMatch = pathname.match(/^\/view\/([^/]+)$/);
    if (viewMatch && (req.method === 'GET' || req.method === 'HEAD')) {
      const id = decodeURIComponent(viewMatch[1]);
      const content = db.getContentById(id, true);
      if (!content || (content.status !== 'published' && !permissionsFor(session).publish)) return sendText(res, 404, 'Resource not found');
      const access = canAccessContent(content, session);
      if (!access.allowed) return sendText(res, 403, access.message || 'Access denied');
      const descriptor = formatForFilename(content.package_filename);
      if (!descriptor || descriptor.viewer === 'download' || descriptor.viewer === 'sandbox') return sendText(res, 404, 'This resource has no inline view');
      if (storage.driver === 's3') return redirect(res, storage.mediaUrl(content.package_key), 302);
      return sendFile(req, res, storage.localPath(content.package_key), {
        contentType: descriptor.contentType,
        cacheControl: 'private, max-age=3600',
        headers: descriptor.viewer === 'pdf' || descriptor.viewer === 'image'
          ? { 'Content-Security-Policy': "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'", 'X-Content-Type-Options': 'nosniff' }
          : { 'X-Content-Type-Options': 'nosniff' }
      });
    }

    if (pathname === '/api/events' && req.method === 'POST') {
      if (!eventLimiter.consume(`${visitor.visitorHash}:${clientKey(req)}`)) return sendJson(res, 429, { error: 'Too many analytics events' });
      const payload = await parseJsonBody(req, 32 * 1024);
      const eventType = String(payload.eventType || '');
      if (!EVENT_TYPES.has(eventType)) return sendJson(res, 400, { error: 'Unsupported event type' });
      const contentId = payload.contentId ? String(payload.contentId) : null;
      if (contentId && !db.getContentById(contentId, false)) return sendJson(res, 404, { error: 'Content not found' });
      const metadata = payload.metadata && typeof payload.metadata === 'object' ? payload.metadata : {};
      const dedupeSeconds = eventType === 'content_view' ? 1800 : eventType === 'preview_loaded' ? 300 : 0;
      const dedupeKey = `${visitor.visitorHash}:${eventType}:${contentId || ''}`;
      const previous = eventDedupe.get(dedupeKey) || 0;
      if (!dedupeSeconds || Date.now() - previous > dedupeSeconds * 1000) {
        db.recordEvent({ eventType, contentId, ...visitor, referrer: req.headers.referer, userAgent: req.headers['user-agent'], metadata });
        if (dedupeSeconds) eventDedupe.set(dedupeKey, Date.now());
      }
      return sendJson(res, 202, { accepted: true });
    }

    const likeMatch = pathname.match(/^\/api\/content\/([^/]+)\/like$/);
    if (likeMatch && req.method === 'POST') {
      if (!likeLimiter.consume(visitor.visitorHash)) return sendJson(res, 429, { error: 'Please slow down' });
      const contentId = decodeURIComponent(likeMatch[1]);
      const result = db.toggleLike(contentId, visitor.visitorHash);
      if (!result) return sendJson(res, 404, { error: 'Content not found' });
      db.recordEvent({ eventType: result.active ? 'like_added' : 'like_removed', contentId, ...visitor, referrer: req.headers.referer, userAgent: req.headers['user-agent'], metadata: {} });
      return sendJson(res, 200, result);
    }

    const voteMatch = pathname.match(/^\/api\/content\/([^/]+)\/install-vote$/);
    if (voteMatch && req.method === 'POST') {
      if (!voteLimiter.consume(session ? `user:${session.userId}` : visitor.visitorHash)) return sendJson(res, 429, { error: 'Please slow down' });
      const contentId = decodeURIComponent(voteMatch[1]);
      const content = db.getContentById(contentId, false);
      if (!content) return sendJson(res, 404, { error: 'Content not found' });
      const access = canAccessContent(content, session);
      if (!access.allowed) return sendJson(res, 403, { error: access.message });
      const payload = await parseJsonBody(req, 16 * 1024);
      const voterKey = session ? `user:${session.userId}` : `visitor:${visitor.visitorHash}`;
      const result = db.voteInstall({ contentId, versionId: content.current_version_id, voterKey, userId: session?.userId || null, visitorHash: visitor.visitorHash, vote: String(payload.vote || '') });
      if (!result) return sendJson(res, 409, { error: 'Verification is unavailable for this revision' });
      db.recordEvent({ eventType: `install_${result.vote}`, contentId, ...visitor, referrer: req.headers.referer, userAgent: req.headers['user-agent'], metadata: { version: content.version } });
      return sendJson(res, 200, { ...result, status: verificationStatus(result, config) });
    }

    const favoriteMatch = pathname.match(/^\/api\/content\/([^/]+)\/favorite$/);
    if (favoriteMatch && req.method === 'POST') {
      if (!session) return sendJson(res, 401, { error: 'Sign in to save favorites' });
      if (!validateCsrf(req, session, req.headers['x-csrf-token'])) return sendJson(res, 403, { error: 'Invalid CSRF token' });
      const result = db.toggleFavorite(session.userId, decodeURIComponent(favoriteMatch[1]));
      if (!result) return sendJson(res, 404, { error: 'Content not found' });
      return sendJson(res, 200, result);
    }

    const followMatch = pathname.match(/^\/api\/content\/([^/]+)\/follow$/);
    if (followMatch && req.method === 'POST') {
      if (!session) return sendJson(res, 401, { error: 'Sign in to follow revisions' });
      if (!validateCsrf(req, session, req.headers['x-csrf-token'])) return sendJson(res, 403, { error: 'Invalid CSRF token' });
      const result = db.toggleFollow(session.userId, decodeURIComponent(followMatch[1]));
      if (!result) return sendJson(res, 404, { error: 'Content not found' });
      return sendJson(res, 200, result);
    }

    const commentPostMatch = pathname.match(/^\/content\/([^/]+)\/comments$/);
    if (commentPostMatch && req.method === 'POST') {
      const contentId = decodeURIComponent(commentPostMatch[1]);
      const content = db.getContentById(contentId, false);
      if (!content) return sendText(res, 404, 'Content not found');
      const access = canAccessContent(content, session);
      if (!access.allowed) return flashRedirect(res, `/learn/${encodeURIComponent(content.slug)}`, access.message, 'error');
      const limiterKey = session ? `user:${session.userId}` : `${visitor.visitorHash}:${clientKey(req)}`;
      if (!commentLimiter.consume(limiterKey)) return flashRedirect(res, `/learn/${encodeURIComponent(content.slug)}#community-comments`, 'Too many comments were submitted. Please try again later.', 'error');
      const form = await parseFormBody(req, 64 * 1024);
      if (session) {
        if (!validateCsrf(req, session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      } else {
        const human = await verifyHumanChallenge({ config, fields: form, req, action: 'comment' });
        if (!human.success) return flashRedirect(res, `/learn/${encodeURIComponent(content.slug)}#community-comments`, human.reason, 'error');
      }
      try {
        const body = requiredText(form, 'body', config.maxCommentLength);
        const authorName = session ? session.name || session.email : requiredText(form, 'authorName', 120);
        const comment = db.createComment({ contentId, versionId: content.current_version_id, userId: session?.userId || null, authorName, commentType: String(form.commentType || 'general'), body });
        db.recordEvent({ eventType: 'comment_created', contentId, ...visitor, referrer: req.headers.referer, userAgent: req.headers['user-agent'], metadata: { commentType: comment.comment_type, version: content.version } });
        return flashRedirect(res, `/learn/${encodeURIComponent(content.slug)}#community-comments`, 'Your comment was added to the document message box.');
      } catch (error) {
        return flashRedirect(res, `/learn/${encodeURIComponent(content.slug)}#community-comments`, error.message || 'Comment could not be saved', 'error');
      }
    }

    if (pathname === '/' && req.method === 'GET') {
      const filters = {
        q: String(url.searchParams.get('q') || '').trim().slice(0, 200),
        category: String(url.searchParams.get('category') || '').trim().slice(0, 100),
        type: String(url.searchParams.get('type') || '').trim().slice(0, 100),
        access: String(url.searchParams.get('access') || '').trim().slice(0, 30)
      };
      const contents = db.listPublished({ q: filters.q, category: filters.category, contentType: filters.type, accessLevel: filters.access }).map((item) => decorateContent(item, db, storage, viewConfig));
      return sendPage(res, 200, homePage({ config: viewConfig, contents, categories: db.categories(), types: db.contentTypes(), filters, session }), viewConfig);
    }

    const learnMatch = pathname.match(/^\/learn\/([^/]+)$/);
    if (learnMatch && req.method === 'GET') {
      const slug = decodeURIComponent(learnMatch[1]);
      const content = db.getContentBySlug(slug, permissionsFor(session).publish);
      if (!content) return sendPage(res, 404, notFoundPage({ config: viewConfig, session }), viewConfig);
      const decorated = decorateContent(content, db, storage, viewConfig);
      const access = canAccessContent(content, session);
      const related = db.listPublished({ category: content.category }).filter((item) => item.id !== content.id).slice(0, 3).map((item) => decorateContent(item, db, storage, viewConfig));
      const voterKey = session ? `user:${session.userId}` : `visitor:${visitor.visitorHash}`;
      decorated.currentVote = db.getInstallVote(content.id, content.current_version_id, voterKey);
      const userState = db.userContentState(session?.userId, content.id);
      if (session && userState.following) db.markFollowSeen(session.userId, content.id, content.current_version_id);
      const comments = db.listCommentsForContent(content.id, permissionsFor(session).moderate);
      const captcha = session || !access.allowed ? null : createHumanChallenge(config, 'comment');
      return sendPage(res, 200, contentPage({ config: viewConfig, content: decorated, related, liked: db.isLiked(content.id, visitor.visitorHash), session, userState, comments, captcha, access, flash: flashFromUrl(url) }), viewConfig);
    }

    if (pathname === '/admin' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'staff', '/admin');
      if (!authorized) return;
      const analytics = db.analytics(30);
      const contents = db.listAdminContents();
      const commentsPreview = db.listCommentInbox('open').slice(0, 6);
      return sendPage(res, 200, adminPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, analytics, contents, backups: listBackups(config), flash: flashFromUrl(url), commentsPreview }), viewConfig);
    }

    if (pathname === '/admin/content' && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', '/admin');
      if (!authorized) return;
      try {
        const { fields, files } = await parseMultipartRequest(req, config.maxUploadBytes + 12 * 1024 * 1024);
        if (!validateCsrf(req, authorized.session, fields.csrf)) return sendText(res, 403, 'Invalid CSRF token');
        const title = requiredText(fields, 'title', 180);
        const category = requiredText(fields, 'category', 100);
        const contentType = requiredText(fields, 'contentType', 80);
        const summary = requiredText(fields, 'summary', 500);
        const description = requiredText(fields, 'description', 10000);
        const version = requiredText(fields, 'version', 30);
        const icon = resolveIconValue(db, fields.icon);
        const tags = [...new Set(String(fields.tags || '').split(',').map((tag) => tag.trim()).filter(Boolean))].slice(0, 30);
        const id = randomUUID();
        const versionId = randomUUID();
        const assets = await storePackageRevision({ storage, config, contentId: id, versionId, packageFile: files.package, thumbnailFile: files.thumbnail, title, category, icon });
        db.createContent({
          id,
          versionId,
          slug: uniqueSlug(db, title),
          title,
          summary,
          description,
          category,
          contentType,
          tags,
          icon,
          version,
          status: boolValue(fields.published) ? 'published' : 'draft',
          featured: boolValue(fields.featured),
          accessLevel: ['public', 'login', 'premium'].includes(fields.accessLevel) ? fields.accessLevel : 'public',
          verificationEnabled: boolValue(fields.verificationEnabled),
          ...assets
        }, authorized.session.email);
        return flashRedirect(res, '/admin', `Created ${title}`);
      } catch (error) {
        return flashRedirect(res, '/admin', error.message || 'Upload failed', 'error');
      }
    }

    const editMatch = pathname.match(/^\/admin\/content\/([^/]+)\/edit$/);
    if (editMatch && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const content = db.getContentById(decodeURIComponent(editMatch[1]), true);
      if (!content) return sendPage(res, 404, notFoundPage({ config: viewConfig, session: authorized.session }), viewConfig);
      return sendPage(res, 200, editContentPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, content, versions: db.listContentVersions(content.id), metadataRevisions: db.listMetadataRevisions(content.id), flash: flashFromUrl(url) }), viewConfig);
    }

    if (editMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 32 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      const id = decodeURIComponent(editMatch[1]);
      try {
        const updated = db.updateContentMetadata(id, {
          title: requiredText(form, 'title', 180),
          category: requiredText(form, 'category', 100),
          contentType: requiredText(form, 'contentType', 80),
          summary: requiredText(form, 'summary', 500),
          description: requiredText(form, 'description', 10000),
          icon: resolveIconValue(db, form.icon),
          tags: [...new Set(String(form.tags || '').split(',').map((tag) => tag.trim()).filter(Boolean))].slice(0, 30),
          accessLevel: String(form.accessLevel || 'public'),
          verificationEnabled: boolValue(form.verificationEnabled)
        }, authorized.session.email);
        if (!updated) throw new Error('Content not found');
        return flashRedirect(res, `/admin/content/${encodeURIComponent(id)}/edit`, 'Metadata saved');
      } catch (error) {
        return flashRedirect(res, `/admin/content/${encodeURIComponent(id)}/edit`, error.message || 'Update failed', 'error');
      }
    }

    const versionUploadMatch = pathname.match(/^\/admin\/content\/([^/]+)\/versions$/);
    if (versionUploadMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const contentId = decodeURIComponent(versionUploadMatch[1]);
      const content = db.getContentById(contentId, true);
      if (!content) return flashRedirect(res, '/admin', 'Content not found', 'error');
      try {
        const { fields, files } = await parseMultipartRequest(req, config.maxUploadBytes + 12 * 1024 * 1024);
        if (!validateCsrf(req, authorized.session, fields.csrf)) return sendText(res, 403, 'Invalid CSRF token');
        const versionLabel = requiredText(fields, 'version', 30);
        const changeNotes = requiredText(fields, 'changeNotes', 3000);
        const versionId = randomUUID();
        const assets = await storePackageRevision({ storage, config, contentId, versionId, packageFile: files.package, thumbnailFile: files.thumbnail, currentThumbnailKey: content.thumbnail_key, title: content.title, category: content.category, icon: content.icon });
        db.createContentVersion(contentId, { id: versionId, versionLabel, changeNotes, ...assets }, authorized.session.email, boolValue(fields.published));
        return flashRedirect(res, `/admin/content/${encodeURIComponent(contentId)}/edit`, `Revision ${versionLabel} created${boolValue(fields.published) ? ' and published' : ' as a draft'}`);
      } catch (error) {
        return flashRedirect(res, `/admin/content/${encodeURIComponent(contentId)}/edit`, error.message || 'Revision upload failed', 'error');
      }
    }

    const versionPublishMatch = pathname.match(/^\/admin\/content\/([^/]+)\/versions\/([^/]+)\/publish$/);
    if (versionPublishMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 16 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      const contentId = decodeURIComponent(versionPublishMatch[1]);
      const versionId = decodeURIComponent(versionPublishMatch[2]);
      try {
        const updated = db.publishContentVersion(contentId, versionId, authorized.session.email);
        if (!updated) throw new Error('Content not found');
        return flashRedirect(res, `/admin/content/${encodeURIComponent(contentId)}/edit`, `Revision ${updated.version} is now published; prior revisions are archived`);
      } catch (error) {
        return flashRedirect(res, `/admin/content/${encodeURIComponent(contentId)}/edit`, error.message || 'Revision could not be published', 'error');
      }
    }

    const versionDownloadMatch = pathname.match(/^\/admin\/content\/([^/]+)\/versions\/([^/]+)\/download$/);
    if (versionDownloadMatch && (req.method === 'GET' || req.method === 'HEAD')) {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const contentId = decodeURIComponent(versionDownloadMatch[1]);
      const version = db.getContentVersion(decodeURIComponent(versionDownloadMatch[2]));
      if (!version || version.content_id !== contentId) return sendText(res, 404, 'Revision not found');
      if (storage.driver === 's3') return redirect(res, storage.mediaUrl(version.package_key), 302);
      return sendFile(req, res, storage.localPath(version.package_key), { downloadName: version.package_filename, cacheControl: 'private, no-store' });
    }

    const statusMatch = pathname.match(/^\/admin\/content\/([^/]+)\/status$/);
    if (statusMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 32 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const updated = db.setContentStatus(decodeURIComponent(statusMatch[1]), String(form.status || ''), authorized.session.email);
        if (!updated) throw new Error('Content not found');
        return flashRedirect(res, '/admin', `${updated.title} is now ${updated.status}`);
      } catch (error) {
        return flashRedirect(res, '/admin', error.message || 'Status could not be changed', 'error');
      }
    }

    const featureMatch = pathname.match(/^\/admin\/content\/([^/]+)\/feature$/);
    if (featureMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 32 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      const updated = db.toggleFeatured(decodeURIComponent(featureMatch[1]), authorized.session.email);
      if (!updated) return flashRedirect(res, '/admin', 'Content not found', 'error');
      return flashRedirect(res, '/admin', `${updated.title} ${updated.featured ? 'is featured' : 'is no longer featured'}`);
    }

    if (pathname === '/admin/comments' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'moderate', pathname);
      if (!authorized) return;
      const filter = ['open', 'resolved', 'hidden', 'all'].includes(url.searchParams.get('status')) ? url.searchParams.get('status') : 'open';
      const roots = db.listCommentInbox(filter === 'all' ? '' : filter);
      const cache = new Map();
      const comments = roots.map((root) => {
        if (!cache.has(root.content_id)) cache.set(root.content_id, db.listCommentsForContent(root.content_id, true));
        return { ...root, replies: cache.get(root.content_id).filter((reply) => reply.parent_id === root.id) };
      });
      return sendPage(res, 200, adminCommentsPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, comments, filter, flash: flashFromUrl(url) }), viewConfig);
    }

    const commentReplyMatch = pathname.match(/^\/admin\/comments\/([^/]+)\/reply$/);
    if (commentReplyMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'moderate', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 32 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const parent = db.getComment(decodeURIComponent(commentReplyMatch[1]));
        if (!parent) throw new Error('Comment not found');
        db.createComment({ contentId: parent.content_id, versionId: parent.version_id, parentId: parent.id, userId: authorized.session.userId, authorName: authorized.session.name || authorized.session.email, commentType: 'general', body: requiredText(form, 'body', config.maxCommentLength) });
        db.recordAudit(authorized.session.email, 'comment.reply', 'comment', parent.id, {});
        return flashRedirect(res, `/admin/comments?status=open#comment-${encodeURIComponent(parent.id)}`, 'Reply posted');
      } catch (error) {
        return flashRedirect(res, '/admin/comments', error.message || 'Reply could not be posted', 'error');
      }
    }

    const commentStatusMatch = pathname.match(/^\/admin\/comments\/([^/]+)\/status$/);
    if (commentStatusMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'moderate', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 16 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const updated = db.setCommentStatus(decodeURIComponent(commentStatusMatch[1]), String(form.status || ''), authorized.session.email);
        if (!updated) throw new Error('Comment not found');
        return flashRedirect(res, `/admin/comments?status=${encodeURIComponent(updated.status === 'hidden' ? 'hidden' : 'open')}`, `Comment marked ${updated.status}`);
      } catch (error) {
        return flashRedirect(res, '/admin/comments', error.message || 'Comment status could not be changed', 'error');
      }
    }

    if (pathname === '/admin/users' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'manageUsers', pathname);
      if (!authorized) return;
      return sendPage(res, 200, adminUsersPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, users: db.listUsers(), flash: flashFromUrl(url) }), viewConfig);
    }

    if (pathname === '/admin/users' && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'manageUsers', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 64 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const password = String(form.password || '');
        if (password.length < 10) throw new Error('Temporary password must contain at least 10 characters');
        const user = db.createUser({ email: requiredText(form, 'email', 320), name: requiredText(form, 'name', 120), passwordHash: createPasswordHash(password), role: String(form.role || 'member'), subscriptionStatus: String(form.subscriptionStatus || 'free'), provider: 'local' }, authorized.session.email);
        return flashRedirect(res, '/admin/users', `Created ${user.email}`);
      } catch (error) {
        return flashRedirect(res, '/admin/users', error.message || 'User could not be created', 'error');
      }
    }

    const userUpdateMatch = pathname.match(/^\/admin\/users\/([^/]+)$/);
    if (userUpdateMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'manageUsers', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 32 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const updated = db.updateUserAdministration(decodeURIComponent(userUpdateMatch[1]), { role: String(form.role || ''), status: String(form.status || ''), subscriptionStatus: String(form.subscriptionStatus || '') }, authorized.session.email);
        if (!updated) throw new Error('User not found');
        return flashRedirect(res, '/admin/users', `Updated ${updated.email}`);
      } catch (error) {
        return flashRedirect(res, '/admin/users', error.message || 'User could not be updated', 'error');
      }
    }

    if (pathname === '/admin/branding' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'manageBranding', pathname);
      if (!authorized) return;
      return sendPage(res, 200, brandingPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, flash: flashFromUrl(url) }), viewConfig);
    }

    if (pathname === '/admin/branding' && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'manageBranding', pathname);
      if (!authorized) return;
      try {
        const { fields, files } = await parseMultipartRequest(req, 12 * 1024 * 1024);
        if (!validateCsrf(req, authorized.session, fields.csrf)) return sendText(res, 403, 'Invalid CSRF token');
        const changes = {
          portalName: requiredText(fields, 'portalName', 120),
          organizationName: String(fields.organizationName || '').trim().slice(0, 120),
          productTagline: String(fields.productTagline || '').trim().slice(0, 300),
          portalTagline: String(fields.portalTagline || '').trim().slice(0, 300)
        };
        const logoInfo = validateImage(files.logo, 'Logo');
        if (logoInfo) {
          changes.logoKey = `branding/logo-${Date.now()}${logoInfo.extension}`;
          await storage.putBuffer(changes.logoKey, files.logo.data, { contentType: logoInfo.contentType, cacheControl: 'public, max-age=31536000, immutable' });
        }
        db.updateBranding(changes, authorized.session.email);
        return flashRedirect(res, '/admin/branding', 'Branding updated');
      } catch (error) {
        return flashRedirect(res, '/admin/branding', error.message || 'Branding could not be saved', 'error');
      }
    }

    // ---- AI studio: runtime provider configuration ----

    if (pathname === '/admin/ai' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'manageBranding', pathname);
      if (!authorized) return;
      const aiSettings = db.getJsonSetting('ai_settings', { defaultProvider: '', providers: {} }) || { defaultProvider: '', providers: {} };
      return sendPage(res, 200, aiSettingsPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, aiSettings, providers: AI_PROVIDERS, maskSecret, flash: flashFromUrl(url) }), viewConfig);
    }

    if (pathname === '/admin/ai' && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'manageBranding', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 64 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const existing = db.getJsonSetting('ai_settings', { defaultProvider: '', providers: {} }) || { defaultProvider: '', providers: {} };
        const providers = { ...(existing.providers || {}) };
        for (const provider of AI_PROVIDERS) {
          const settings = { ...(providers[provider.id] || {}) };
          let touched = false;
          for (const field of provider.fields) {
            const raw = String(form[`${provider.id}_${field.name}`] ?? '').trim();
            if (field.type === 'password') {
              if (raw) { settings[field.name] = raw.slice(0, 500); touched = true; }
            } else if (raw !== String(settings[field.name] ?? '')) {
              settings[field.name] = raw.slice(0, 500);
              touched = true;
            }
          }
          if (boolValue(form[`${provider.id}_clear`])) {
            delete providers[provider.id];
          } else if (touched || providers[provider.id]) {
            providers[provider.id] = settings;
          }
        }
        const defaultProvider = AI_PROVIDERS.some((provider) => provider.id === form.defaultProvider) && providers[form.defaultProvider]
          ? form.defaultProvider
          : (existing.defaultProvider && providers[existing.defaultProvider] ? existing.defaultProvider : Object.keys(providers)[0] || '');
        db.setJsonSetting('ai_settings', { defaultProvider, providers }, authorized.session.email);
        return flashRedirect(res, '/admin/ai', 'AI provider settings saved');
      } catch (error) {
        return flashRedirect(res, '/admin/ai', error.message || 'AI settings could not be saved', 'error');
      }
    }

    if (pathname === '/admin/ai/test' && req.method === 'POST') {
      const session = getSession(req);
      if (!session || !permissionsFor(session).manageBranding) return sendJson(res, 403, { error: 'Not permitted' });
      if (!validateCsrf(req, session, req.headers['x-csrf-token'])) return sendJson(res, 403, { error: 'Invalid CSRF token' });
      const payload = await parseJsonBody(req, 16 * 1024);
      const providerId = String(payload?.provider || '');
      if (!providerDefinition(providerId)) return sendJson(res, 400, { error: 'Unknown provider' });
      const aiSettings = db.getJsonSetting('ai_settings', { providers: {} }) || { providers: {} };
      const settings = aiSettings.providers?.[providerId];
      if (!settings) return sendJson(res, 400, { error: 'Save the provider settings before testing' });
      try {
        const result = await testProvider({ providerId, settings });
        db.recordAudit(session.email, 'ai.test', 'portal', providerId, { ok: true, latencyMs: result.latencyMs }, false);
        return sendJson(res, 200, result);
      } catch (error) {
        return sendJson(res, 502, { error: error.message || 'Provider test failed' });
      }
    }

    // ---- Icon library: built-in, uploaded, and AI-generated icons ----

    if (pathname === '/admin/icons' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const aiSettings = db.getJsonSetting('ai_settings', { defaultProvider: '', providers: {} }) || { defaultProvider: '', providers: {} };
      return sendPage(res, 200, iconLibraryPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, customIcons: db.listCustomIcons(), aiReady: Boolean(aiSettings.defaultProvider && aiSettings.providers?.[aiSettings.defaultProvider]), flash: flashFromUrl(url) }), viewConfig);
    }

    if (pathname === '/admin/icons/upload' && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      try {
        const { fields, files } = await parseMultipartRequest(req, 2 * 1024 * 1024);
        if (!validateCsrf(req, authorized.session, fields.csrf)) return sendText(res, 403, 'Invalid CSRF token');
        const name = requiredText(fields, 'name', 80);
        if (!files.icon?.data?.length) throw new Error('Choose an SVG icon file');
        if (files.icon.data.length > 200 * 1024) throw new Error('Icon SVG must be under 200 KB');
        const svg = sanitizeSvg(files.icon.data.toString('utf8'));
        const icon = db.createCustomIcon({ id: randomUUID(), name, svg, source: 'uploaded' }, authorized.session.email);
        return flashRedirect(res, '/admin/icons', `Icon "${icon.name}" added to the library`);
      } catch (error) {
        return flashRedirect(res, '/admin/icons', error.message || 'Icon upload failed', 'error');
      }
    }

    if (pathname === '/admin/icons/generate' && req.method === 'POST') {
      const session = getSession(req);
      if (!session || !permissionsFor(session).publish) return sendJson(res, 403, { error: 'Not permitted' });
      if (!validateCsrf(req, session, req.headers['x-csrf-token'])) return sendJson(res, 403, { error: 'Invalid CSRF token' });
      const payload = await parseJsonBody(req, 16 * 1024);
      const description = String(payload?.description || '').trim().slice(0, 300);
      const name = String(payload?.name || '').trim().slice(0, 80);
      if (!description || !name) return sendJson(res, 400, { error: 'Provide an icon name and a description' });
      const aiSettings = db.getJsonSetting('ai_settings', { defaultProvider: '', providers: {} }) || { defaultProvider: '', providers: {} };
      const providerId = AI_PROVIDERS.some((provider) => provider.id === payload?.provider) ? payload.provider : aiSettings.defaultProvider;
      const settings = aiSettings.providers?.[providerId];
      if (!providerId || !settings) return sendJson(res, 400, { error: 'Configure an AI provider in the AI studio first' });
      try {
        const svg = await generateIconSvg({ providerId, settings, description });
        const icon = db.createCustomIcon({ id: randomUUID(), name, svg, source: 'ai' }, session.email);
        db.recordAudit(session.email, 'icon.generate', 'custom_icon', icon.id, { providerId }, false);
        return sendJson(res, 200, { id: icon.id, name: icon.name, svg: icon.svg, value: `custom:${icon.id}` });
      } catch (error) {
        return sendJson(res, 502, { error: error.message || 'Icon generation failed' });
      }
    }

    const iconDeleteMatch = pathname.match(/^\/admin\/icons\/([^/]+)\/delete$/);
    if (iconDeleteMatch && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'publish', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 16 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      const removed = db.deleteCustomIcon(decodeURIComponent(iconDeleteMatch[1]), authorized.session.email);
      return flashRedirect(res, '/admin/icons', removed ? 'Icon removed. Resources using it now show the generic icon.' : 'Icon not found', removed ? 'success' : 'error');
    }

    // ---- Integrations: SharePoint provision (stage two) ----

    if (pathname === '/admin/integrations' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'manageBranding', pathname);
      if (!authorized) return;
      const sharePoint = db.getJsonSetting('sharepoint_settings', {}) || {};
      return sendPage(res, 200, integrationsPage({ config: viewConfig, session: authorized.session, permissions: authorized.permissions, sharePoint, fields: SHAREPOINT_FIELDS, maskSecret, flash: flashFromUrl(url) }), viewConfig);
    }

    if (pathname === '/admin/integrations' && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'manageBranding', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 32 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const existing = db.getJsonSetting('sharepoint_settings', {}) || {};
        const next = { ...existing };
        for (const field of SHAREPOINT_FIELDS) {
          const raw = String(form[field.name] ?? '').trim().slice(0, 500);
          if (field.secret) {
            if (raw) next[field.name] = raw;
          } else {
            next[field.name] = raw;
          }
        }
        next.enabled = boolValue(form.enabled);
        db.setJsonSetting('sharepoint_settings', next, authorized.session.email);
        return flashRedirect(res, '/admin/integrations', 'SharePoint settings saved');
      } catch (error) {
        return flashRedirect(res, '/admin/integrations', error.message || 'Integration settings could not be saved', 'error');
      }
    }

    if (pathname === '/admin/integrations/test' && req.method === 'POST') {
      const session = getSession(req);
      if (!session || !permissionsFor(session).manageBranding) return sendJson(res, 403, { error: 'Not permitted' });
      if (!validateCsrf(req, session, req.headers['x-csrf-token'])) return sendJson(res, 403, { error: 'Invalid CSRF token' });
      const sharePoint = db.getJsonSetting('sharepoint_settings', {}) || {};
      try {
        const result = await testSharePointConnection(sharePoint);
        db.setJsonSetting('sharepoint_settings', { ...sharePoint, lastTest: { at: new Date().toISOString(), ok: true, siteName: result.siteName } }, session.email);
        return sendJson(res, 200, result);
      } catch (error) {
        return sendJson(res, 502, { error: error.message || 'SharePoint connection failed' });
      }
    }

    if (pathname === '/admin/backup' && req.method === 'POST') {
      const authorized = requirePermission(req, res, 'backup', pathname);
      if (!authorized) return;
      const form = await parseFormBody(req, 32 * 1024);
      if (!validateCsrf(req, authorized.session, form.csrf)) return sendText(res, 403, 'Invalid CSRF token');
      try {
        const result = await createBackup({ db, storage, config });
        db.recordAudit(authorized.session.email, 'backup.create', 'backup', path.basename(result.archivePath), { checksum: result.checksum });
        return flashRedirect(res, '/admin', `Backup created: ${path.basename(result.archivePath)}`);
      } catch (error) {
        return flashRedirect(res, '/admin', `Backup failed: ${error.message}`, 'error');
      }
    }

    if (pathname === '/admin/export.csv' && req.method === 'GET') {
      const authorized = requirePermission(req, res, 'staff', pathname);
      if (!authorized) return;
      const rows = db.exportEvents();
      const headers = ['id', 'event_type', 'content_id', 'content_title', 'visitor_hash', 'session_hash', 'referrer', 'user_agent', 'metadata_json', 'created_at'];
      const csv = [headers.map(csvCell).join(','), ...rows.map((row) => headers.map((header) => csvCell(row[header])).join(','))].join('\n');
      const body = Buffer.from(`${csv}\n`);
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Length': body.length, 'Content-Disposition': `attachment; filename="portal-events-${new Date().toISOString().slice(0, 10)}.csv"`, 'Cache-Control': 'no-store' });
      return res.end(body);
    }

    return sendPage(res, 404, notFoundPage({ config: viewConfig, session }), viewConfig);
  }

  const wrappedHandler = (req, res) => {
    handler(req, res).catch((error) => {
      console.error(error);
      if (res.headersSent) return res.end();
      const viewConfig = uiConfig();
      sendPage(res, error.statusCode || 500, errorPage({ config: viewConfig, message: config.nodeEnv === 'development' || config.nodeEnv === 'test' ? error.message : 'The request could not be completed.', session: getSession(req) }), viewConfig);
    });
  };

  let autoBackupTimer = null;
  if (config.autoBackup) {
    const schedule = () => {
      const now = new Date();
      const next = new Date(now);
      next.setUTCHours(config.autoBackupHourUtc, 0, 0, 0);
      if (next <= now) next.setUTCDate(next.getUTCDate() + 1);
      autoBackupTimer = setTimeout(async () => {
        try { await createBackup({ db, storage, config }); } catch (error) { console.error('Automatic backup failed:', error); }
        schedule();
      }, next.getTime() - now.getTime());
      autoBackupTimer.unref?.();
    };
    schedule();
  }

  return {
    config,
    db,
    storage,
    handler: wrappedHandler,
    createHttpServer() { return createServer(wrappedHandler); },
    close() {
      if (autoBackupTimer) clearTimeout(autoBackupTimer);
      db.close();
    }
  };
}
