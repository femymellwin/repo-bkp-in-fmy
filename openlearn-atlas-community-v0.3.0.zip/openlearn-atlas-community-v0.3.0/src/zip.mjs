import path from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';

const SIG_EOCD = 0x06054b50;
const SIG_CENTRAL = 0x02014b50;
const SIG_LOCAL = 0x04034b50;

let crcTable;
function getCrcTable() {
  if (crcTable) return crcTable;
  crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    crcTable[n] = c >>> 0;
  }
  return crcTable;
}

function crc32(buffer) {
  const table = getCrcTable();
  let crc = 0xffffffff;
  for (const byte of buffer) crc = table[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function findEocd(buffer) {
  const minimum = Math.max(0, buffer.length - 65557);
  for (let index = buffer.length - 22; index >= minimum; index -= 1) {
    if (buffer.readUInt32LE(index) === SIG_EOCD) return index;
  }
  return -1;
}

function normalizeEntryName(name) {
  if (!name || name.includes('\0')) throw new Error('ZIP contains an invalid filename');
  if (name.includes('\\')) throw new Error('ZIP filenames must use forward slashes');
  if (name.startsWith('/') || /^[a-zA-Z]:\//.test(name)) throw new Error('ZIP contains an absolute path');
  const normalized = path.posix.normalize(name).replace(/^\.\//, '');
  const segments = normalized.split('/');
  if (normalized === '..' || normalized.startsWith('../') || segments.includes('..')) {
    throw new Error('ZIP contains a path traversal entry');
  }
  return normalized;
}

export function extractZipBuffer(buffer, destination, options = {}) {
  const maxFiles = options.maxFiles || 3000;
  const maxUncompressedBytes = options.maxUncompressedBytes || 300 * 1024 * 1024;
  const eocdOffset = findEocd(buffer);
  if (eocdOffset < 0) throw new Error('ZIP end-of-directory record was not found');

  const totalEntries = buffer.readUInt16LE(eocdOffset + 10);
  const centralSize = buffer.readUInt32LE(eocdOffset + 12);
  const centralOffset = buffer.readUInt32LE(eocdOffset + 16);
  if (totalEntries > maxFiles) throw new Error(`ZIP contains more than ${maxFiles} files`);
  if (centralOffset + centralSize > buffer.length) throw new Error('ZIP central directory is outside the archive');

  mkdirSync(destination, { recursive: true });
  const extracted = [];
  const seenEntries = new Set();
  let totalUncompressed = 0;
  let cursor = centralOffset;

  for (let index = 0; index < totalEntries; index += 1) {
    if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== SIG_CENTRAL) {
      throw new Error('ZIP central directory is malformed');
    }

    const flags = buffer.readUInt16LE(cursor + 8);
    const method = buffer.readUInt16LE(cursor + 10);
    const expectedCrc = buffer.readUInt32LE(cursor + 16);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const externalAttributes = buffer.readUInt32LE(cursor + 38);
    const localOffset = buffer.readUInt32LE(cursor + 42);

    if ([compressedSize, uncompressedSize, localOffset].includes(0xffffffff)) {
      throw new Error('ZIP64 packages are not supported by this build');
    }
    if (flags & 0x1) throw new Error('Encrypted ZIP packages are not supported');
    if (![0, 8].includes(method)) throw new Error(`Unsupported ZIP compression method: ${method}`);

    const nameStart = cursor + 46;
    const nameEnd = nameStart + nameLength;
    if (nameEnd > buffer.length) throw new Error('ZIP filename is truncated');
    const entryName = normalizeEntryName(buffer.subarray(nameStart, nameEnd).toString('utf8'));
    const duplicateKey = entryName.toLowerCase();
    if (seenEntries.has(duplicateKey)) throw new Error(`ZIP contains a duplicate filename: ${entryName}`);
    seenEntries.add(duplicateKey);

    const unixMode = (externalAttributes >>> 16) & 0xffff;
    if ((unixMode & 0o170000) === 0o120000) throw new Error('Symbolic links are not allowed in ZIP packages');

    totalUncompressed += uncompressedSize;
    if (totalUncompressed > maxUncompressedBytes) {
      throw new Error(`Expanded ZIP content exceeds ${Math.round(maxUncompressedBytes / 1024 / 1024)} MB`);
    }

    const isDirectory = entryName.endsWith('/');
    const outputPath = path.join(destination, ...entryName.split('/'));
    const relativeCheck = path.relative(destination, outputPath);
    if (relativeCheck.startsWith('..') || path.isAbsolute(relativeCheck)) throw new Error('ZIP path escaped destination');

    if (isDirectory) {
      mkdirSync(outputPath, { recursive: true });
    } else {
      if (localOffset + 30 > buffer.length || buffer.readUInt32LE(localOffset) !== SIG_LOCAL) {
        throw new Error('ZIP local file header is malformed');
      }
      const localNameLength = buffer.readUInt16LE(localOffset + 26);
      const localExtraLength = buffer.readUInt16LE(localOffset + 28);
      const dataStart = localOffset + 30 + localNameLength + localExtraLength;
      const dataEnd = dataStart + compressedSize;
      if (dataEnd > buffer.length) throw new Error('ZIP file data is truncated');

      const localName = normalizeEntryName(buffer.subarray(localOffset + 30, localOffset + 30 + localNameLength).toString('utf8'));
      if (localName !== entryName) throw new Error('ZIP local and central filenames do not match');

      const compressed = buffer.subarray(dataStart, dataEnd);
      const output = method === 0 ? Buffer.from(compressed) : inflateRawSync(compressed, { maxOutputLength: maxUncompressedBytes });
      if (output.length !== uncompressedSize) throw new Error(`ZIP size mismatch for ${entryName}`);
      if (crc32(output) !== expectedCrc) throw new Error(`ZIP checksum mismatch for ${entryName}`);

      mkdirSync(path.dirname(outputPath), { recursive: true });
      writeFileSync(outputPath, output, { mode: 0o644 });
      extracted.push({ name: entryName, size: output.length, path: outputPath });
    }

    cursor = nameEnd + extraLength + commentLength;
  }

  const candidates = extracted
    .filter((entry) => /(^|\/)index\.html?$/i.test(entry.name))
    .sort((a, b) => a.name.split('/').length - b.name.split('/').length || a.name.length - b.name.length);
  if (!candidates.length) throw new Error('ZIP package must contain an index.html or index.htm file');

  return {
    entries: extracted,
    entrypoint: candidates[0].name,
    totalUncompressedBytes: totalUncompressed
  };
}
