import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { walkDirectory } from './storage.mjs';

function compactTimestamp(date = new Date()) {
  return date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
}

function fileHash(filePath) {
  return createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function buildManifest(root, metadata) {
  const files = walkDirectory(root).map((filePath) => ({
    path: path.relative(root, filePath).split(path.sep).join('/'),
    size: fs.statSync(filePath).size,
    sha256: fileHash(filePath)
  })).sort((a, b) => a.path.localeCompare(b.path));
  return { ...metadata, files };
}

function runTar(args) {
  const result = spawnSync('tar', args, { encoding: 'utf8' });
  if (result.status !== 0) throw new Error(`tar failed: ${result.stderr || result.stdout}`);
}

export async function createBackup({ db, storage, config }) {
  fs.mkdirSync(config.backupDir, { recursive: true });
  const name = `learning-portal-${compactTimestamp()}`;
  const workRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'learning-portal-backup-'));
  const snapshotRoot = path.join(workRoot, 'snapshot');
  fs.mkdirSync(snapshotRoot, { recursive: true });

  try {
    db.backupTo(path.join(snapshotRoot, 'portal.sqlite'));
    if (storage.driver === 'local') {
      const sourceStorage = path.join(config.dataDir, 'storage');
      if (fs.existsSync(sourceStorage)) fs.cpSync(sourceStorage, path.join(snapshotRoot, 'storage'), { recursive: true });
    }

    const manifest = buildManifest(snapshotRoot, {
      formatVersion: 1,
      createdAt: new Date().toISOString(),
      applicationVersion: config.applicationVersion || '0.2.0',
      storageDriver: storage.driver,
      note: storage.driver === 's3'
        ? 'Content files are protected separately by S3 Versioning; this archive contains the database.'
        : 'This archive contains the database and local content files.'
    });
    fs.writeFileSync(path.join(snapshotRoot, 'manifest.json'), JSON.stringify(manifest, null, 2));

    const archivePath = path.join(config.backupDir, `${name}.tgz`);
    runTar(['-czf', archivePath, '-C', snapshotRoot, '.']);
    const checksum = fileHash(archivePath);
    fs.writeFileSync(`${archivePath}.sha256`, `${checksum}  ${path.basename(archivePath)}\n`);

    if (storage.backupBucket) {
      await storage.putBackup(path.basename(archivePath), fs.readFileSync(archivePath));
      await storage.putBackup(`${path.basename(archivePath)}.sha256`, Buffer.from(`${checksum}  ${path.basename(archivePath)}\n`));
    }

    const archives = fs.readdirSync(config.backupDir)
      .filter((entry) => entry.endsWith('.tgz'))
      .map((entry) => ({ entry, path: path.join(config.backupDir, entry), mtime: fs.statSync(path.join(config.backupDir, entry)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);
    for (const old of archives.slice(config.backupRetentionCount)) {
      fs.rmSync(old.path, { force: true });
      fs.rmSync(`${old.path}.sha256`, { force: true });
    }

    return { archivePath, checksum, uploadedToS3: Boolean(storage.backupBucket), manifest };
  } finally {
    fs.rmSync(workRoot, { recursive: true, force: true });
  }
}

export function verifyBackupArchive(archivePath) {
  if (!fs.existsSync(archivePath)) throw new Error(`Backup not found: ${archivePath}`);

  const checksumPath = `${archivePath}.sha256`;
  let archiveChecksumVerified = false;
  if (fs.existsSync(checksumPath)) {
    const expected = fs.readFileSync(checksumPath, 'utf8').trim().split(/\s+/, 1)[0];
    if (!/^[a-f0-9]{64}$/i.test(expected)) throw new Error('Backup checksum sidecar is malformed');
    const actual = fileHash(archivePath);
    if (actual.toLowerCase() !== expected.toLowerCase()) throw new Error('Backup archive checksum does not match its .sha256 file');
    archiveChecksumVerified = true;
  }

  const listing = spawnSync('tar', ['-tzf', archivePath], { encoding: 'utf8' });
  if (listing.status !== 0) throw new Error(`Backup archive is unreadable: ${listing.stderr}`);
  const entries = listing.stdout.split('\n').filter(Boolean);
  for (const entry of entries) {
    const clean = entry.replace(/^\.\//, '');
    if (clean.startsWith('/') || clean === '..' || clean.startsWith('../') || clean.includes('/../')) {
      throw new Error(`Unsafe path in backup: ${entry}`);
    }
  }

  const verboseListing = spawnSync('tar', ['-tvzf', archivePath], { encoding: 'utf8' });
  if (verboseListing.status !== 0) throw new Error(`Backup archive cannot be inspected: ${verboseListing.stderr}`);
  for (const line of verboseListing.stdout.split('\n').filter(Boolean)) {
    const type = line[0];
    if (type !== '-' && type !== 'd') throw new Error('Backup contains a link or unsupported file type');
  }

  const workRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'learning-portal-verify-'));
  try {
    runTar(['-xzf', archivePath, '-C', workRoot]);
    const manifestPath = path.join(workRoot, 'manifest.json');
    if (!fs.existsSync(manifestPath)) throw new Error('Backup has no manifest.json');
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    for (const file of manifest.files || []) {
      const manifestPathValue = String(file.path || '').replaceAll('\\', '/');
      const segments = manifestPathValue.split('/');
      if (!manifestPathValue || manifestPathValue.startsWith('/') || segments.some((segment) => segment === '..' || segment.includes('\0'))) {
        throw new Error(`Unsafe manifest path: ${file.path}`);
      }
      if (!Number.isSafeInteger(file.size) || file.size < 0 || !/^[a-f0-9]{64}$/i.test(String(file.sha256 || ''))) {
        throw new Error(`Invalid manifest entry for ${file.path}`);
      }
      const target = path.join(workRoot, ...segments);
      const relative = path.relative(workRoot, target);
      if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error(`Unsafe manifest path: ${file.path}`);
      if (!fs.existsSync(target)) throw new Error(`Backup is missing ${file.path}`);
      const stat = fs.statSync(target);
      if (!stat.isFile()) throw new Error(`Backup manifest entry is not a file: ${file.path}`);
      if (stat.size !== file.size) throw new Error(`Size mismatch for ${file.path}`);
      if (fileHash(target) !== file.sha256) throw new Error(`Checksum mismatch for ${file.path}`);
    }
    return { valid: true, archiveChecksumVerified, manifest, entries };
  } finally {
    fs.rmSync(workRoot, { recursive: true, force: true });
  }
}

export function extractVerifiedBackup(archivePath, destination) {
  verifyBackupArchive(archivePath);
  fs.mkdirSync(destination, { recursive: true });
  runTar(['-xzf', archivePath, '-C', destination]);
}
