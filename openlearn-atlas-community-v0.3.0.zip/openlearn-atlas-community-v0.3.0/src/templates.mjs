import { escapeHtml } from './utils.mjs';
import { mediaKindLabel, UPLOAD_ACCEPT } from './formats.mjs';

const STAFF_ROLES = new Set(['super_admin', 'admin', 'publisher', 'moderator']);

const svgIcon = (paths) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;

export const BUILTIN_ICON_SVGS = {
  gear: svgIcon('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.01a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.01a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>'),
  xray: svgIcon('<circle cx="12" cy="12" r="9"/><path d="M12 3v18M5 8h14M5 16h14"/>'),
  cube: svgIcon('<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="M3.27 6.96 12 12.01l8.73-5.05M12 22.08V12"/>'),
  book: svgIcon('<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>'),
  tool: svgIcon('<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>'),
  aircraft: svgIcon('<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>'),
  circuit: svgIcon('<polyline points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'),
  anatomy: svgIcon('<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7z"/>'),
  video: svgIcon('<rect x="2" y="5" width="14" height="14" rx="2"/><path d="m22 8-6 4 6 4V8z"/>'),
  document: svgIcon('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>'),
  presentation: svgIcon('<rect x="2" y="3" width="20" height="13" rx="2"/><path d="M8 21h8M12 16v5M9 9l2 2 4-4"/>'),
  spreadsheet: svgIcon('<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>'),
  image: svgIcon('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>'),
  diagram: svgIcon('<rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="15" width="6" height="6" rx="1"/><rect x="15" y="3" width="6" height="6" rx="1"/><path d="M9 6h6M18 9v6M6 9v9a2 2 0 0 0 2 2h7"/>'),
  flow: svgIcon('<circle cx="5" cy="6" r="2.5"/><circle cx="19" cy="6" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M7.5 6h9M6 8.2l4.5 7.3M18 8.2l-4.5 7.3"/>'),
  generic: svgIcon('<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>')
};

export const BUILTIN_ICON_OPTIONS = [
  ['gear', 'Gear / mechanical'], ['cube', 'Assembly'], ['circuit', 'Interactive / electrical'], ['video', 'Video'],
  ['document', 'Document'], ['presentation', 'Presentation'], ['spreadsheet', 'Dataset'], ['image', 'Image'],
  ['diagram', 'Diagram'], ['flow', 'Animated flow'], ['book', 'Reference'], ['aircraft', 'Aircraft'],
  ['xray', 'X-ray'], ['anatomy', 'Anatomy'], ['tool', 'Tool'], ['generic', 'Generic']
];

function iconMarkup(icon, config = {}) {
  const value = String(icon || '');
  if (BUILTIN_ICON_SVGS[value]) return `<span class="ui-icon">${BUILTIN_ICON_SVGS[value]}</span>`;
  if (config.customIconMap && config.customIconMap[value]) return `<span class="ui-icon custom">${config.customIconMap[value]}</span>`;
  return `<span class="ui-icon">${BUILTIN_ICON_SVGS.generic}</span>`;
}

function iconSelect(name, selected, config = {}) {
  const custom = (config.customIcons || []).map((icon) => `<option value="custom:${escapeHtml(icon.id)}" ${selected === `custom:${icon.id}` ? 'selected' : ''}>${escapeHtml(icon.name)}${icon.source === 'ai' ? ' (AI)' : ''}</option>`).join('');
  return `<select name="${escapeHtml(name)}">${BUILTIN_ICON_OPTIONS.map(([value, label]) => `<option value="${value}" ${selected === value ? 'selected' : ''}>${label}</option>`).join('')}${custom ? `<optgroup label="Icon library">${custom}</optgroup>` : ''}</select>`;
}

const CONTENT_TYPES = ['Interactive HTML', 'Exploded View', 'X-Ray View', 'Video Lesson', 'Animated Flow', 'PDF Guide', 'Presentation', 'Word Document', 'Markdown Article', 'Diagram / Image', 'Dataset', 'Technical Walkthrough', 'Reference Document'];

function formatNumber(value) {
  return new Intl.NumberFormat('en-US').format(Number(value || 0));
}

function formatBytes(value) {
  const bytes = Number(value || 0);
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

function formatDate(value, includeTime = false) {
  if (!value) return '';
  try {
    return new Intl.DateTimeFormat('en', includeTime
      ? { dateStyle: 'medium', timeStyle: 'short' }
      : { dateStyle: 'medium' }).format(new Date(value));
  } catch {
    return value || '';
  }
}

function isStaff(session) {
  return Boolean(session && STAFF_ROLES.has(session.role));
}

function brandMark(config, className = '') {
  if (config.logoUrl) {
    return `<span class="brand-logo ${className}"><img src="${escapeHtml(config.logoUrl)}" alt=""></span>`;
  }
  return `<span class="brand-mark ${className}" aria-hidden="true"><span></span><span></span><span></span></span>`;
}

function nav(config, session) {
  const account = session
    ? `<div class="account-cluster"><a class="account-link" href="/my-library"><span>${escapeHtml((session.name || session.email).slice(0, 24))}</span><small>${escapeHtml(session.subscriptionStatus === 'premium' ? 'Premium' : session.role.replace('_', ' '))}</small></a><form method="post" action="/logout"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><button type="submit" class="nav-button">Sign out</button></form></div>`
    : `<a class="nav-button emphasized" href="/login">Sign in</a>`;
  return `
    <header class="site-header">
      <div class="shell nav-shell">
        <a class="brand" href="/" aria-label="${escapeHtml(config.portalName)} home">
          ${brandMark(config)}
          <span><strong>${escapeHtml(config.portalName)}</strong><small>${escapeHtml(config.organizationName || 'Global learning library')}</small></span>
        </a>
        <nav class="main-nav" aria-label="Primary navigation">
          <a href="/">Explore</a>
          ${session ? '<a href="/my-library">My library</a>' : ''}
          ${isStaff(session) ? '<a href="/admin">Publisher console</a>' : ''}
          ${account}
        </nav>
      </div>
    </header>`;
}

export function layout({ config, title, description = '', body, session = null, bodyClass = '', extraHead = '' }) {
  const csrfMeta = session ? `<meta name="csrf-token" content="${escapeHtml(session.csrf)}">` : '';
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="${escapeHtml(description || config.portalTagline)}">
  <meta name="color-scheme" content="light">
  ${csrfMeta}
  <title>${escapeHtml(title)} | ${escapeHtml(config.portalName)}</title>
  <link rel="stylesheet" href="/assets/app.css">
  ${extraHead}
</head>
<body class="${escapeHtml(bodyClass)}">
  ${nav(config, session)}
  ${body}
  <footer class="site-footer">
    <div class="shell footer-grid">
      <div><strong>${escapeHtml(config.portalName)}</strong><p>${escapeHtml(config.portalTagline)}</p></div>
      <div><span>Public exploration</span><span>Versioned learning</span><span>Community feedback</span></div>
    </div>
  </footer>
  <div class="toast" id="toast" role="status" aria-live="polite"></div>
  <script src="/assets/public.js" defer></script>
</body>
</html>`;
}

function accessBadge(content) {
  if (content.access_level === 'premium') return '<span class="access-pill premium">Premium</span>';
  if (content.access_level === 'login') return '<span class="access-pill login">Sign-in access</span>';
  return '<span class="access-pill public">Open</span>';
}

function verificationBadge(content) {
  if (!content.verification_enabled) return '';
  const verification = content.verificationStatus || {};
  const label = verification.label || 'Verification starting';
  const className = verification.className || 'pending';
  return `<span class="verify-pill ${escapeHtml(className)}"><span aria-hidden="true">&#10003;</span> ${escapeHtml(label)}</span>`;
}

function contentCard(content, config = {}) {
  return `
    <article class="content-card">
      <a class="card-image" href="/learn/${encodeURIComponent(content.slug)}" aria-label="Open ${escapeHtml(content.title)}">
        <img src="${escapeHtml(content.thumbnailUrl)}" alt="" loading="lazy">
        ${content.media_kind === 'video' ? '<span class="play-overlay" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></span>' : ''}
        <div class="card-badges"><span class="type-pill kind-${escapeHtml(content.media_kind || 'interactive')}">${escapeHtml(mediaKindLabel(content.media_kind))}</span>${accessBadge(content)}</div>
        ${content.featured ? '<span class="featured-pill">Featured</span>' : ''}
      </a>
      <div class="card-body">
        <div class="card-kicker"><span class="mini-icon">${iconMarkup(content.icon, config)}</span>${escapeHtml(content.category)} ${verificationBadge(content)}</div>
        <h2><a href="/learn/${encodeURIComponent(content.slug)}">${escapeHtml(content.title)}</a></h2>
        <p>${escapeHtml(content.summary)}</p>
        <div class="tag-row">${content.tags.slice(0, 3).map((tag) => `<span>${escapeHtml(tag)}</span>`).join('')}</div>
      </div>
      <div class="card-footer">
        <span title="Views">&#128065; ${formatNumber(content.stats.views)}</span>
        <span title="Downloads">&#8681; ${formatNumber(content.stats.downloads)}</span>
        <span title="Comments">&#128172; ${formatNumber(content.stats.comments)}</span>
        <a href="/learn/${encodeURIComponent(content.slug)}">Open <span aria-hidden="true">&#8594;</span></a>
      </div>
    </article>`;
}

export function homePage({ config, contents, categories, types, filters, session }) {
  const empty = contents.length === 0
    ? `<section class="empty-state"><div class="empty-icon">&#9711;</div><h2>No matching learning items</h2><p>Try a different search or remove one of the filters.</p><a class="button secondary" href="/">Clear filters</a></section>`
    : `<section class="card-grid">${contents.map((item) => contentCard(item, config)).join('')}</section>`;

  const body = `
    <main>
      <section class="catalog-banner">
        <div class="shell catalog-banner-grid">
          <div><span class="eyebrow">Open learning, community improved</span><h1>${escapeHtml(config.productTagline)}</h1><p>${escapeHtml(config.portalTagline)}</p></div>
          <div class="catalog-summary"><span><strong>${formatNumber(contents.length)}</strong> resources</span><span><strong>${formatNumber(categories.length)}</strong> categories</span><span><strong>0</strong> login barriers for open content</span></div>
        </div>
      </section>

      <section class="catalog shell">
        <form class="filter-panel compact-filter" method="get" action="/" data-search-form>
          <label class="search-box"><span class="sr-only">Search</span><span aria-hidden="true">&#128269;</span><input name="q" value="${escapeHtml(filters.q)}" placeholder="Search systems, steps, tags..." autocomplete="off"></label>
          <label><span>Category</span><select name="category"><option value="">All categories</option>${categories.map((row) => `<option value="${escapeHtml(row.category)}" ${filters.category === row.category ? 'selected' : ''}>${escapeHtml(row.category)} (${row.count})</option>`).join('')}</select></label>
          <label><span>Format</span><select name="type"><option value="">All formats</option>${types.map((row) => `<option value="${escapeHtml(row.content_type)}" ${filters.type === row.content_type ? 'selected' : ''}>${escapeHtml(row.content_type)} (${row.count})</option>`).join('')}</select></label>
          <label><span>Access</span><select name="access"><option value="">All access</option><option value="public" ${filters.access === 'public' ? 'selected' : ''}>Open</option><option value="login" ${filters.access === 'login' ? 'selected' : ''}>Sign-in</option><option value="premium" ${filters.access === 'premium' ? 'selected' : ''}>Premium</option></select></label>
          <button class="button primary" type="submit">Search</button>
        </form>
        <div class="section-heading gallery-heading"><div><span class="eyebrow">Learning gallery</span><h2>${filters.q || filters.category || filters.type || filters.access ? 'Search results' : 'Latest resources'}</h2></div><p>${formatNumber(contents.length)} item${contents.length === 1 ? '' : 's'} shown</p></div>
        ${empty}
      </section>
    </main>`;
  return layout({ config, title: 'Explore', description: config.portalTagline, body, session, bodyClass: 'public-page' });
}

function captchaMarkup(captcha) {
  if (!captcha) return '';
  if (captcha.mode === 'turnstile') {
    return `<div class="captcha-block"><div class="cf-turnstile" data-sitekey="${escapeHtml(captcha.siteKey)}" data-action="${escapeHtml(captcha.action)}"></div></div>`;
  }
  return `<label class="captcha-field"><span>Human check: what is ${escapeHtml(captcha.question)}?</span><input name="captchaAnswer" inputmode="numeric" required autocomplete="off"><input type="hidden" name="captchaToken" value="${escapeHtml(captcha.token)}"></label>`;
}

function commentTypeLabel(type) {
  return ({ error: 'Step not working', suggestion: 'Suggested improvement', question: 'Question', general: 'General comment' })[type] || 'Comment';
}

function commentThreads(comments) {
  const roots = comments.filter((comment) => !comment.parent_id);
  const replies = new Map();
  for (const comment of comments) {
    if (!comment.parent_id) continue;
    if (!replies.has(comment.parent_id)) replies.set(comment.parent_id, []);
    replies.get(comment.parent_id).push(comment);
  }
  const renderComment = (comment, reply = false) => `
    <article class="comment-card ${reply ? 'reply' : ''} ${comment.is_staff ? 'staff-reply' : ''}">
      <div class="comment-head"><div><strong>${escapeHtml(comment.author_name)}</strong>${comment.is_staff ? '<span class="staff-badge">Publisher team</span>' : ''}<span class="comment-type ${escapeHtml(comment.comment_type)}">${escapeHtml(commentTypeLabel(comment.comment_type))}</span></div><time>${formatDate(comment.created_at, true)}</time></div>
      <p>${escapeHtml(comment.body).replaceAll('\n', '<br>')}</p>
      <div class="comment-meta"><span>Revision ${escapeHtml(comment.version_label || 'current')}</span>${comment.status === 'resolved' ? '<span class="resolved-label">Resolved</span>' : ''}</div>
    </article>`;
  return roots.map((root) => `<div class="comment-thread">${renderComment(root)}${(replies.get(root.id) || []).map((reply) => renderComment(reply, true)).join('')}</div>`).join('');
}

export function contentPage({ config, content, related, liked, session, userState, comments, captcha, access, flash }) {
  const stats = content.stats;
  const canonicalUrl = `${config.publicBaseUrl.replace(/\/$/, '')}/learn/${encodeURIComponent(content.slug)}`;
  const loginUrl = `/login?next=${encodeURIComponent(`/learn/${content.slug}`)}`;
  const viewer = content.format?.viewer || 'sandbox';
  const primaryAction = {
    sandbox: `<button class="button primary large" type="button" data-preview-open data-preview-url="${escapeHtml(content.previewUrl)}">Open interactive view</button>`,
    markdown: `<a class="button primary large" href="#resource-viewer">Read the article</a>`,
    video: `<a class="button primary large" href="#resource-viewer"><span aria-hidden="true">&#9654;</span> Play video</a>`,
    pdf: `<a class="button primary large" href="#resource-viewer">Open document</a>`,
    image: `<a class="button primary large" href="#resource-viewer">View full size</a>`,
    download: `<a class="button primary large" href="/download/${encodeURIComponent(content.id)}" data-event="download_click">Download ${escapeHtml(content.format?.label || 'file')}</a>`
  }[viewer];
  const accessibleActions = access.allowed
    ? `${primaryAction}<a class="button secondary large" href="/download/${encodeURIComponent(content.id)}" data-event="download_click">Download ${formatBytes(content.package_size)}</a>`
    : `<a class="button primary large" href="${escapeHtml(loginUrl)}">${content.access_level === 'premium' ? 'Unlock premium access' : 'Sign in to open'}</a><span class="access-note">${escapeHtml(access.message)}</span>`;
  const accountActions = session
    ? `<button class="button icon-button ${userState.favorite ? 'active' : ''}" type="button" data-favorite aria-pressed="${userState.favorite ? 'true' : 'false'}"><span aria-hidden="true">${userState.favorite ? '&#9733;' : '&#9734;'}</span><span data-favorite-label>${userState.favorite ? 'Favorited' : 'Favorite'}</span></button><button class="button icon-button ${userState.following ? 'active' : ''}" type="button" data-follow aria-pressed="${userState.following ? 'true' : 'false'}"><span aria-hidden="true">&#128276;</span><span data-follow-label>${userState.following ? 'Following' : 'Follow updates'}</span></button>`
    : `<a class="quiet-signin" href="${escapeHtml(loginUrl)}">Sign in to favorite or follow revisions</a>`;
  const verification = content.verificationStatus;
  const vote = content.currentVote;
  const verificationControls = access.allowed
    ? `<div class="vote-row"><button type="button" class="vote-button success ${vote === 'able' ? 'selected' : ''}" data-install-vote="able"><span>&#10003;</span> I am able to install</button><button type="button" class="vote-button issue ${vote === 'unable' ? 'selected' : ''}" data-install-vote="unable"><span>!</span> I am not able to install</button></div>`
    : `<div class="verification-locked"><span aria-hidden="true">&#128274;</span><p>Open this revision with the required access before submitting an installation vote.</p><a href="${escapeHtml(loginUrl)}">Sign in for access</a></div>`;
  const verificationSection = content.verification_enabled ? `
      <section class="community-strip">
        <div class="shell community-grid">
          <article class="verification-panel" data-verification data-version-id="${escapeHtml(content.current_version_id || '')}">
            <div class="verification-title"><span class="spin-mark">S</span><div><span class="eyebrow">SPIN verified</span><h2>Did revision ${escapeHtml(content.version)} install or work for you?</h2></div></div>
            <p>Vote after following the steps. A vote applies only to this revision, so a revised document starts with a fresh result.</p>
            ${verificationControls}
            <div class="verification-result"><div class="verification-bar"><span data-verification-bar style="width:${verification.ablePercent}%"></span></div><div><strong data-verification-label>${escapeHtml(verification.label)}</strong><span><b data-able-count>${formatNumber(verification.able)}</b> successful / <b data-unable-count>${formatNumber(verification.unable)}</b> unable</span></div></div>
          </article>
          <aside class="feedback-callout"><span aria-hidden="true">&#128172;</span><h3>Found a broken step?</h3><p>Post the exact error or correction below. The publisher can reply, resolve it, and issue a new revision without losing this history.</p><a href="#community-comments">Go to comments</a></aside>
        </div>
      </section>` : '';
  const lockedSection = `
      <section class="locked-preview shell"><span class="locked-icon">&#128274;</span><div><span class="eyebrow">Restricted resource</span><h2>${content.access_level === 'premium' ? 'Premium learning package' : 'Account access required'}</h2><p>${escapeHtml(access.message)}</p></div><a class="button primary" href="${escapeHtml(loginUrl)}">Sign in</a></section>`;
  const viewerSections = {
    sandbox: `
      <section class="preview-section shell" id="resource-viewer">
        <div class="section-heading"><div><span class="eyebrow">Interactive workspace</span><h2>Explore in your browser</h2></div><a href="${escapeHtml(content.previewUrl)}" target="_blank" rel="noopener" data-event="preview_new_window">Open in a new window &#8599;</a></div>
        <div class="preview-shell" data-preview-shell>
          <div class="preview-placeholder" data-preview-placeholder><div class="preview-symbol">${iconMarkup(content.icon, config)}</div><h3>Ready to launch</h3><p>The package loads only when you open it.</p><button class="button primary" type="button" data-preview-open data-preview-url="${escapeHtml(content.previewUrl)}">Launch preview</button></div>
          <iframe title="Interactive preview: ${escapeHtml(content.title)}" data-preview-frame sandbox="allow-scripts allow-forms allow-modals allow-popups allow-downloads" referrerpolicy="no-referrer" loading="lazy"></iframe>
        </div>
      </section>`,
    video: `
      <section class="preview-section shell" id="resource-viewer">
        <div class="section-heading"><div><span class="eyebrow">Video lesson</span><h2>Watch in your browser</h2></div><span class="format-note">${escapeHtml(content.format?.label || 'Video')} / ${formatBytes(content.package_size)}</span></div>
        <div class="video-shell">
          <video controls preload="metadata" playsinline poster="${escapeHtml(content.thumbnailUrl)}" data-video-player>
            <source src="${escapeHtml(content.viewUrl)}" type="${escapeHtml((content.format?.contentType || 'video/mp4').split(';')[0])}">
            Your browser cannot play this video. <a href="/download/${encodeURIComponent(content.id)}">Download it instead.</a>
          </video>
        </div>
      </section>`,
    pdf: `
      <section class="preview-section shell" id="resource-viewer">
        <div class="section-heading"><div><span class="eyebrow">Document</span><h2>Read in your browser</h2></div><a href="${escapeHtml(content.viewUrl)}" target="_blank" rel="noopener" data-event="preview_new_window">Open in a new tab &#8599;</a></div>
        <div class="document-shell"><iframe title="Document: ${escapeHtml(content.title)}" src="${escapeHtml(content.viewUrl)}" loading="lazy" referrerpolicy="no-referrer"></iframe></div>
      </section>`,
    image: `
      <section class="preview-section shell" id="resource-viewer">
        <div class="section-heading"><div><span class="eyebrow">${escapeHtml(content.format?.label || 'Visual')}</span><h2>Full-size view</h2></div><a href="${escapeHtml(content.viewUrl)}" target="_blank" rel="noopener" data-event="preview_new_window">Open original &#8599;</a></div>
        <figure class="image-shell"><img src="${escapeHtml(content.viewUrl)}" alt="${escapeHtml(content.title)}" loading="lazy"></figure>
      </section>`,
    markdown: `
      <section class="preview-section shell" id="resource-viewer">
        <div class="section-heading"><div><span class="eyebrow">Article</span><h2>Read in your browser</h2></div><a href="${escapeHtml(content.previewUrl)}" target="_blank" rel="noopener" data-event="preview_new_window">Open in a new tab &#8599;</a></div>
        <div class="article-shell"><iframe title="Article: ${escapeHtml(content.title)}" src="${escapeHtml(content.previewUrl)}" sandbox="allow-popups" loading="lazy" referrerpolicy="no-referrer"></iframe></div>
      </section>`,
    download: `
      <section class="preview-section shell" id="resource-viewer">
        <div class="download-panel"><div class="download-icon">${iconMarkup(content.icon, config)}</div><div><span class="eyebrow">${escapeHtml(content.format?.label || 'Learning package')}</span><h2>Download to open</h2><p>This format opens in its native application (for example Microsoft Office). The file is delivered exactly as the publisher uploaded it, ${formatBytes(content.package_size)}.</p></div><a class="button primary large" href="/download/${encodeURIComponent(content.id)}" data-event="download_click">Download ${escapeHtml(content.package_filename)}</a></div>
      </section>`
  };
  const previewSection = access.allowed ? (viewerSections[viewer] || viewerSections.sandbox) : lockedSection;

  const body = `
    <main class="content-main" data-content-id="${escapeHtml(content.id)}" data-content-title="${escapeHtml(content.title)}" data-content-url="${escapeHtml(canonicalUrl)}">
      <div class="shell breadcrumb"><a href="/">Explore</a><span>/</span><a href="/?category=${encodeURIComponent(content.category)}">${escapeHtml(content.category)}</a><span>/</span><span>${escapeHtml(content.title)}</span></div>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}</div>
      <section class="detail-hero shell">
        <div class="detail-cover"><img src="${escapeHtml(content.thumbnailUrl)}" alt="Preview image for ${escapeHtml(content.title)}"><span class="cover-icon">${iconMarkup(content.icon, config)}</span></div>
        <div class="detail-copy">
          <div class="detail-badges"><span>${escapeHtml(content.content_type)}</span><span>Revision ${escapeHtml(content.version)}</span><span>Updated ${formatDate(content.updated_at)}</span>${accessBadge(content)}${verificationBadge(content)}</div>
          <h1>${escapeHtml(content.title)}</h1>
          <p class="lead">${escapeHtml(content.summary)}</p>
          <div class="tag-row large">${content.tags.map((tag) => `<a href="/?q=${encodeURIComponent(tag)}">${escapeHtml(tag)}</a>`).join('')}</div>
          <div class="action-row">${accessibleActions}<button class="button icon-button ${liked ? 'active' : ''}" type="button" data-like aria-pressed="${liked ? 'true' : 'false'}"><span aria-hidden="true">${liked ? '&#9829;' : '&#9825;'}</span><span data-like-label>${liked ? 'Liked' : 'Like'}</span></button>${accountActions}</div>
          <div class="share-row"><span>Share:</span><button type="button" data-share="native">Device</button><button type="button" data-share="whatsapp">WhatsApp</button><button type="button" data-share="linkedin">LinkedIn</button><button type="button" data-share="email">Email</button><button type="button" data-share="copy">Copy link</button></div>
        </div>
      </section>

      <section class="stats-strip"><div class="shell stats-grid"><div><strong data-stat="views">${formatNumber(stats.views)}</strong><span>views</span></div><div><strong data-stat="previews">${formatNumber(stats.previews)}</strong><span>preview opens</span></div><div><strong data-stat="downloads">${formatNumber(stats.downloads)}</strong><span>downloads</span></div><div><strong data-stat="likes">${formatNumber(stats.likes)}</strong><span>likes</span></div><div><strong data-stat="comments">${formatNumber(stats.comments)}</strong><span>comments and replies</span></div></div></section>

      <section class="detail-grid shell">
        <article class="prose-panel"><span class="eyebrow">About this resource</span><h2>Learning overview</h2><div class="rich-copy">${escapeHtml(content.description).replaceAll('\n', '<br>')}</div><dl class="metadata-list"><div><dt>Category</dt><dd>${escapeHtml(content.category)}</dd></div><div><dt>Format</dt><dd>${escapeHtml(content.content_type)}</dd></div><div><dt>Package</dt><dd>${escapeHtml(content.package_filename)}</dd></div><div><dt>Revision</dt><dd>${escapeHtml(content.version)}</dd></div></dl></article>
        <aside class="safety-panel"><span class="panel-icon">&#128737;</span><h3>Version-safe learning</h3><p>Comments and install votes are attached to the exact revision shown here. When a new revision is published, the previous package and its feedback remain archived.</p><p class="small">Interactive HTML is isolated in a restricted browser sandbox and can be served from a separate CloudFront content domain.</p></aside>
      </section>

      ${verificationSection}
      ${previewSection}

      <section class="comments-section shell" id="community-comments">
        <div class="section-heading"><div><span class="eyebrow">Community message box</span><h2>Corrections, errors, and discussion</h2></div><p>${formatNumber(comments.length)} message${comments.length === 1 ? '' : 's'}</p></div>
        <div class="comments-layout">
          <div class="comment-list">${comments.length ? commentThreads(comments) : '<div class="empty-comments"><span>&#128172;</span><h3>No comments yet</h3><p>Be the first to report a failed step or suggest an improvement.</p></div>'}</div>
          <aside class="comment-form-panel">
            <h3>Send feedback on revision ${escapeHtml(content.version)}</h3>
            <p>The publisher sees this in the document inbox and can reply or mark it resolved after a revised release.</p>
            ${access.allowed ? `<form method="post" action="/content/${encodeURIComponent(content.id)}/comments" class="stack-form">
              ${session ? `<input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><div class="signed-commenter">Posting as <strong>${escapeHtml(session.name || session.email)}</strong></div>` : '<label><span>Your display name</span><input name="authorName" maxlength="120" required placeholder="Name shown publicly"></label>'}
              <label><span>Feedback type</span><select name="commentType"><option value="error">A step is not working</option><option value="suggestion">Suggested improvement</option><option value="question">Question</option><option value="general">General comment</option></select></label>
              <label><span>Comment</span><textarea name="body" maxlength="${config.maxCommentLength}" rows="7" required placeholder="Include the step number, error text, environment, and suggested correction when possible."></textarea></label>
              ${session ? '' : captchaMarkup(captcha)}
              <button class="button primary full" type="submit">Post comment</button>
            </form>` : `<div class="comment-access-gate"><span aria-hidden="true">&#128274;</span><strong>Access required to post feedback</strong><p>${escapeHtml(access.message)}</p><a class="button primary full" href="${escapeHtml(loginUrl)}">Sign in</a></div>`}
          </aside>
        </div>
      </section>

      ${related.length ? `<section class="related shell"><div class="section-heading"><div><span class="eyebrow">Continue learning</span><h2>Related resources</h2></div></div><div class="card-grid compact">${related.map((item) => contentCard(item, config)).join('')}</div></section>` : ''}
    </main>`;

  const turnstileScript = captcha?.mode === 'turnstile' ? '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>' : '';
  const extraHead = `<meta property="og:title" content="${escapeHtml(content.title)}"><meta property="og:description" content="${escapeHtml(content.summary)}"><meta property="og:type" content="article"><meta property="og:url" content="${escapeHtml(canonicalUrl)}"><meta property="og:image" content="${escapeHtml(content.thumbnailAbsoluteUrl)}">${turnstileScript}`;
  return layout({ config, title: content.title, description: content.summary, body, session, bodyClass: 'detail-page', extraHead });
}

export function loginPage({ config, message = '', next = '/', session = null }) {
  const googleButton = config.googleEnabled
    ? `<a class="button google-button full" href="/auth/google?next=${encodeURIComponent(next)}"><span class="google-g">G</span> Continue with Google</a><div class="auth-divider"><span>or use email</span></div>`
    : '';
  const body = `
    <main class="auth-main">
      <section class="auth-card">
        <a class="brand auth-brand" href="/">${brandMark(config)}<span><strong>${escapeHtml(config.portalName)}</strong><small>${escapeHtml(config.productTagline)}</small></span></a>
        <span class="eyebrow">Optional account</span><h1>Sign in</h1><p>Exploration stays public. Sign in only to favorite resources, follow revisions, comment under your name, or access restricted content.</p>
        ${message ? `<div class="alert error">${escapeHtml(message)}</div>` : ''}
        ${googleButton}
        <form method="post" action="/login" class="stack-form">
          <input type="hidden" name="next" value="${escapeHtml(next)}">
          <label><span>Email</span><input type="email" name="email" autocomplete="username" required></label>
          <label><span>Password</span><input type="password" name="password" autocomplete="current-password" required></label>
          <button class="button primary full" type="submit">Sign in securely</button>
        </form>
        ${config.allowRegistration ? `<p class="auth-switch">New here? <a href="/register?next=${encodeURIComponent(next)}">Create a free account</a></p>` : ''}
        <p class="form-note"><a href="/">Continue without signing in</a></p>
      </section>
    </main>`;
  return layout({ config, title: 'Sign in', body, session, bodyClass: 'auth-page' });
}

export function registerPage({ config, message = '', captcha, next = '/' }) {
  const body = `
    <main class="auth-main">
      <section class="auth-card">
        <a class="brand auth-brand" href="/">${brandMark(config)}<span><strong>${escapeHtml(config.portalName)}</strong><small>Create a community account</small></span></a>
        <span class="eyebrow">Free community account</span><h1>Create an account</h1><p>Use it for favorites, followed revisions, named comments, and account-only learning resources.</p>
        ${message ? `<div class="alert error">${escapeHtml(message)}</div>` : ''}
        <form method="post" action="/register" class="stack-form">
          <input type="hidden" name="next" value="${escapeHtml(next)}">
          <label><span>Name</span><input name="name" maxlength="120" autocomplete="name" required></label>
          <label><span>Email</span><input type="email" name="email" maxlength="320" autocomplete="email" required></label>
          <label><span>Password</span><input type="password" name="password" minlength="10" maxlength="200" autocomplete="new-password" required><small>Use at least 10 characters.</small></label>
          ${captchaMarkup(captcha)}
          <button class="button primary full" type="submit">Create account</button>
        </form>
        <p class="auth-switch">Already registered? <a href="/login?next=${encodeURIComponent(next)}">Sign in</a></p>
      </section>
    </main>`;
  const extraHead = captcha?.mode === 'turnstile' ? '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>' : '';
  return layout({ config, title: 'Create account', body, bodyClass: 'auth-page', extraHead });
}

export function myLibraryPage({ config, session, favorites, following }) {
  const body = `
    <main class="library-main">
      <section class="page-header shell"><div><span class="eyebrow">Personal library</span><h1>Welcome, ${escapeHtml(session.name || session.email)}</h1><p>Your saved resources and followed document revisions.</p></div><span class="membership-chip ${session.subscriptionStatus === 'premium' ? 'premium' : ''}">${escapeHtml(session.subscriptionStatus === 'premium' ? 'Premium member' : 'Free member')}</span></section>
      <section class="library-section shell"><div class="section-heading"><div><span class="eyebrow">Bookmarks</span><h2>Favorites</h2></div><p>${favorites.length} saved</p></div>${favorites.length ? `<div class="card-grid">${favorites.map((item) => contentCard(item, config)).join('')}</div>` : '<div class="empty-state compact"><h3>No favorites yet</h3><p>Open a resource and select Favorite.</p><a class="button secondary" href="/">Explore resources</a></div>'}</section>
      <section class="library-section shell"><div class="section-heading"><div><span class="eyebrow">Revision watchlist</span><h2>Following</h2></div><p>${following.length} followed</p></div>${following.length ? `<div class="follow-list">${following.map((content) => `<article><div>${content.has_update ? '<span class="update-dot">New revision</span>' : '<span class="quiet-status">Up to date</span>'}<h3><a href="/learn/${encodeURIComponent(content.slug)}">${escapeHtml(content.title)}</a></h3><p>${escapeHtml(content.summary)}</p></div><div><span>Current revision</span><strong>${escapeHtml(content.version)}</strong><a href="/learn/${encodeURIComponent(content.slug)}">Open</a></div></article>`).join('')}</div>` : '<div class="empty-state compact"><h3>No followed resources yet</h3><p>Follow a document to see when a new revision is published.</p><a class="button secondary" href="/">Browse the gallery</a></div>'}</section>
    </main>`;
  return layout({ config, title: 'My library', body, session, bodyClass: 'library-page' });
}

function statusBadge(status) {
  return `<span class="status-badge ${escapeHtml(status)}">${escapeHtml(status)}</span>`;
}

function metric(label, value, note, icon) {
  return `<article class="metric-card"><div class="metric-icon">${icon}</div><div><span>${escapeHtml(label)}</span><strong class="value">${formatNumber(value)}</strong><small>${escapeHtml(note)}</small></div></article>`;
}

function adminNav(session, permissions) {
  return `<nav class="console-nav"><a href="/admin">Overview</a><a href="/admin/comments">Messages</a>${permissions.publish ? '<a href="/admin/icons">Icons</a>' : ''}${permissions.manageBranding ? '<a href="/admin/ai">AI studio</a><a href="/admin/integrations">Integrations</a>' : ''}${permissions.manageUsers ? '<a href="/admin/users">Users</a>' : ''}${permissions.manageBranding ? '<a href="/admin/branding">Branding</a>' : ''}<a href="/">Public portal</a><span>${escapeHtml(session.role.replace('_', ' '))}</span></nav>`;
}

export function adminPage({ config, session, permissions, analytics, contents, backups, flash, commentsPreview }) {
  const maxDaily = Math.max(1, ...analytics.daily.map((row) => Number(row.views || 0)));
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">Publisher console</span><h1>Content and community</h1><p>Manage revisions, feedback, access, users, and recovery from one place.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">
        ${config.defaultCredentials ? '<div class="alert warning"><strong>Demo credentials are active.</strong> Change the bootstrap password before exposing this portal to the internet.</div>' : ''}
        ${config.weakSecrets ? '<div class="alert warning"><strong>Security secrets need attention.</strong> Set SESSION_SECRET and PRIVACY_SALT to separate random values of at least 32 characters.</div>' : ''}
        ${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}
      </div>

      <section class="metrics shell">
        ${metric('Unique visitors', analytics.totals.uniqueVisitors, `${analytics.days}-day anonymous IDs`, '&#9673;')}
        ${metric('Content views', analytics.totals.views, 'Detail-page views', '&#128065;')}
        ${metric('Downloads', analytics.totals.downloads, 'Tracked deliveries', '&#8681;')}
        ${metric('Open messages', analytics.totals.openComments, 'Need publisher review', '&#128172;')}
        ${metric('Install success', analytics.totals.ableVotes, 'SPIN able votes', '&#10003;')}
        ${metric('Install issues', analytics.totals.unableVotes, 'SPIN unable votes', '!')}
        ${metric('Active users', analytics.totals.users, 'Registered accounts', '&#128101;')}
        ${metric('Active likes', analytics.totals.activeLikes, 'One per browser', '&#9829;')}
      </section>

      <section class="dashboard-grid shell">
        <article class="dashboard-panel chart-panel"><div class="panel-heading"><div><span class="eyebrow">Activity trend</span><h2>Daily content views</h2></div><span>${analytics.days} days</span></div><div class="bar-chart" role="img" aria-label="Daily content views">${analytics.daily.map((row) => `<div class="bar-column" title="${escapeHtml(row.day)}: ${row.views} views"><span style="height:${Math.max(2, Math.round((row.views / maxDaily) * 100))}%"></span><small>${escapeHtml(row.day.slice(5))}</small></div>`).join('')}</div></article>
        <article class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Message inbox</span><h2>Latest open feedback</h2></div><a href="/admin/comments">Open inbox</a></div>${commentsPreview.length ? `<ol class="message-preview">${commentsPreview.map((comment) => `<li><a href="/admin/comments#comment-${encodeURIComponent(comment.id)}"><strong>${escapeHtml(comment.content_title)}</strong><span>${escapeHtml(comment.author_name)}: ${escapeHtml(comment.body.slice(0, 110))}${comment.body.length > 110 ? '...' : ''}</span><small>Revision ${escapeHtml(comment.version_label || 'current')} / ${formatDate(comment.created_at)}</small></a></li>`).join('')}</ol>` : '<p class="muted">No open community messages.</p>'}</article>
      </section>

      <section class="dashboard-grid shell">
        <article class="dashboard-panel wide-panel"><div class="panel-heading"><div><span class="eyebrow">Performance</span><h2>Top learning resources</h2></div><a href="/admin/export.csv">Export event CSV</a></div><div class="table-scroll"><table><thead><tr><th>Resource</th><th>Views</th><th>Downloads</th><th>Shares</th><th>Messages</th></tr></thead><tbody>${analytics.topContent.map((row) => `<tr><td><a href="/learn/${encodeURIComponent(row.slug)}">${escapeHtml(row.title)}</a></td><td>${formatNumber(row.views)}</td><td>${formatNumber(row.downloads)}</td><td>${formatNumber(row.shares)}</td><td>${formatNumber(row.comments)}</td></tr>`).join('') || '<tr><td colspan="5">No activity yet.</td></tr>'}</tbody></table></div></article>
      </section>

      ${permissions.publish ? `<section class="publisher-grid shell"><article class="dashboard-panel upload-panel"><div class="panel-heading"><div><span class="eyebrow">New resource</span><h2>Upload the first revision</h2></div></div><form method="post" action="/admin/content" enctype="multipart/form-data" class="upload-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><div class="form-grid"><label class="span-two"><span>Title</span><input name="title" maxlength="180" required placeholder="Example: Turbofan engine exploded view"></label><label><span>Category</span><input name="category" maxlength="100" required placeholder="Aviation"></label><label><span>Content type</span><select name="contentType">${CONTENT_TYPES.map((type) => `<option>${escapeHtml(type)}</option>`).join('')}</select></label><label><span>Icon</span>${iconSelect('icon', 'generic', config)}<small>Manage or AI-generate icons in the <a href="/admin/icons">icon library</a>.</small></label><label><span>Initial revision</span><input name="version" maxlength="30" value="1.0" required></label><label><span>Access</span><select name="accessLevel"><option value="public">Open without login</option><option value="login">Login required</option><option value="premium">Premium member</option></select></label><label class="span-two"><span>Tags</span><input name="tags" maxlength="500" placeholder="engine, maintenance, turbine"></label><label class="span-two"><span>Short summary</span><textarea name="summary" maxlength="500" required rows="2"></textarea></label><label class="span-two"><span>Full description</span><textarea name="description" maxlength="10000" required rows="6"></textarea></label><label><span>Learning package</span><input type="file" name="package" accept="${UPLOAD_ACCEPT}" required><small>Interactive HTML/ZIP, video (MP4/WebM/MOV), PDF, PPT/PPTX, DOC/DOCX, XLSX/CSV, Markdown, SVG, PNG/JPG/WebP, or animated GIF flows. Maximum ${Math.round(config.maxUploadBytes / 1024 / 1024)} MB.</small></label><label><span>Thumbnail / video poster</span><input type="file" name="thumbnail" accept="image/png,image/jpeg,image/webp"><small>Recommended for videos (used as the player poster). A generated cover is used otherwise; image resources use themselves.</small></label></div><div class="checkbox-row"><label><input type="checkbox" name="published" checked> Publish immediately</label><label><input type="checkbox" name="featured"> Feature in gallery</label><label><input type="checkbox" name="verificationEnabled" checked> Enable SPIN verification</label></div><button class="button primary" type="submit">Upload resource</button></form></article><aside class="dashboard-panel backup-panel"><div class="panel-heading"><div><span class="eyebrow">Recovery</span><h2>Verified backups</h2></div></div><p>Backups include users, comments, votes, versions, settings, analytics, and local packages. In S3 mode, object versions protect uploaded files separately.</p>${permissions.backup ? `<form method="post" action="/admin/backup"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><button class="button secondary full" type="submit">Create backup now</button></form>` : ''}<ul class="backup-list">${backups.map((backup) => `<li><span>${escapeHtml(backup.name)}</span><small>${formatBytes(backup.size)}</small></li>`).join('') || '<li><span>No backups created yet</span></li>'}</ul></aside></section>` : ''}

      <section class="dashboard-panel shell content-management"><div class="panel-heading"><div><span class="eyebrow">Library management</span><h2>All content</h2></div><span>${contents.length} resources</span></div><div class="table-scroll"><table><thead><tr><th>Resource</th><th>Access</th><th>Status</th><th>Revision</th><th>Messages</th><th>Updated</th><th>Actions</th></tr></thead><tbody>${contents.map((content) => `<tr><td><div class="table-title"><span>${iconMarkup(content.icon, config)}</span><div><strong>${escapeHtml(content.title)}</strong><small>${escapeHtml(content.content_type)} / ${escapeHtml(content.category)}${content.featured ? ' / Featured' : ''}</small></div></div></td><td>${accessBadge(content)}</td><td>${statusBadge(content.status)}</td><td>${escapeHtml(content.version)} <small>(${content.revision_count || 1})</small></td><td>${content.open_comment_count ? `<a class="message-count" href="/admin/comments">${formatNumber(content.open_comment_count)} open</a>` : '<span class="quiet-status">None</span>'}</td><td>${formatDate(content.updated_at)}</td><td><div class="table-actions">${permissions.publish ? `<a href="/admin/content/${encodeURIComponent(content.id)}/edit">Edit / revisions</a>` : ''}<a href="/learn/${encodeURIComponent(content.slug)}">View</a>${permissions.publish ? `<form method="post" action="/admin/content/${encodeURIComponent(content.id)}/feature"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><button type="submit">${content.featured ? 'Unfeature' : 'Feature'}</button></form><form method="post" action="/admin/content/${encodeURIComponent(content.id)}/status"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><input type="hidden" name="status" value="${content.status === 'published' ? 'draft' : 'published'}"><button type="submit">${content.status === 'published' ? 'Unpublish' : 'Publish current'}</button></form>${content.status !== 'archived' ? `<form method="post" action="/admin/content/${encodeURIComponent(content.id)}/status" data-confirm="Archive this resource? Files, revisions, votes, and comments will be retained."><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><input type="hidden" name="status" value="archived"><button type="submit" class="danger-link">Archive resource</button></form>` : ''}` : ''}</div></td></tr>`).join('')}</tbody></table></div></section>
    </main>`;
  return layout({ config, title: 'Publisher console', body, session, bodyClass: 'admin-page' });
}

export function editContentPage({ config, session, permissions, content, versions, metadataRevisions, flash = null }) {
  const contentTypes = CONTENT_TYPES.includes(content.content_type) ? CONTENT_TYPES : [content.content_type, ...CONTENT_TYPES];
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">Publisher console</span><h1>Edit and revise</h1><p>Metadata is audited; package revisions are immutable and published atomically.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}</div>
      <section class="edit-grid shell">
        <article class="dashboard-panel edit-panel"><div class="panel-heading"><div><span class="eyebrow">${escapeHtml(content.status)}</span><h2>Document metadata</h2></div><a href="/learn/${encodeURIComponent(content.slug)}">View resource</a></div><form method="post" action="/admin/content/${encodeURIComponent(content.id)}/edit" class="upload-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><div class="form-grid"><label class="span-two"><span>Title</span><input name="title" maxlength="180" required value="${escapeHtml(content.title)}"></label><label><span>Category</span><input name="category" maxlength="100" required value="${escapeHtml(content.category)}"></label><label><span>Content type</span><select name="contentType">${contentTypes.map((type) => `<option ${content.content_type === type ? 'selected' : ''}>${escapeHtml(type)}</option>`).join('')}</select></label><label><span>Icon</span>${iconSelect('icon', content.icon, config)}</label><label><span>Access</span><select name="accessLevel"><option value="public" ${content.access_level === 'public' ? 'selected' : ''}>Open without login</option><option value="login" ${content.access_level === 'login' ? 'selected' : ''}>Login required</option><option value="premium" ${content.access_level === 'premium' ? 'selected' : ''}>Premium member</option></select></label><label class="span-two"><span>Tags</span><input name="tags" maxlength="500" value="${escapeHtml(content.tags.join(', '))}"></label><label class="span-two"><span>Short summary</span><textarea name="summary" maxlength="500" required rows="3">${escapeHtml(content.summary)}</textarea></label><label class="span-two"><span>Full description</span><textarea name="description" maxlength="10000" required rows="9">${escapeHtml(content.description)}</textarea></label></div><div class="checkbox-row"><label><input type="checkbox" name="verificationEnabled" ${content.verification_enabled ? 'checked' : ''}> Enable SPIN verification for the current revision</label></div><div class="action-row"><button class="button primary" type="submit">Save metadata</button><a class="button secondary" href="/admin">Cancel</a></div></form></article>

        <aside class="dashboard-panel revision-upload"><div class="panel-heading"><div><span class="eyebrow">New package</span><h2>Upload revised steps</h2></div></div><p>Use a new revision label. Publishing archives every earlier package revision while retaining its comments and install votes.</p><form method="post" action="/admin/content/${encodeURIComponent(content.id)}/versions" enctype="multipart/form-data" class="stack-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><label><span>Revision label</span><input name="version" maxlength="30" required placeholder="Example: 1.1"></label><label><span>Change notes</span><textarea name="changeNotes" maxlength="3000" rows="5" required placeholder="What was corrected or added?"></textarea></label><label><span>Revised learning package</span><input type="file" name="package" accept="${UPLOAD_ACCEPT}" required><small>Any supported format; the resource type follows the newly published revision.</small></label><label><span>Replacement thumbnail</span><input type="file" name="thumbnail" accept="image/png,image/jpeg,image/webp"><small>Optional. The current thumbnail is reused otherwise.</small></label><label class="inline-check"><input type="checkbox" name="published" checked> Publish this revision now</label><button class="button primary full" type="submit">Create revision</button></form></aside>
      </section>

      <section class="dashboard-panel shell revision-history"><div class="panel-heading"><div><span class="eyebrow">Immutable history</span><h2>Package revisions</h2></div><span>${versions.length} revision${versions.length === 1 ? '' : 's'}</span></div><div class="table-scroll"><table><thead><tr><th>Revision</th><th>Status</th><th>Created</th><th>Publisher</th><th>SPIN votes</th><th>Messages</th><th>Notes</th><th>Actions</th></tr></thead><tbody>${versions.map((version) => `<tr class="${version.id === content.current_version_id ? 'current-row' : ''}"><td><strong>${escapeHtml(version.version_label)}</strong>${version.id === content.current_version_id ? '<span class="current-label">Current</span>' : ''}</td><td>${statusBadge(version.status)}</td><td>${formatDate(version.created_at)}</td><td>${escapeHtml(version.created_by)}</td><td><span class="vote-mini success">${formatNumber(version.able_votes)} able</span> <span class="vote-mini issue">${formatNumber(version.unable_votes)} unable</span></td><td>${formatNumber(version.comment_count)}</td><td class="notes-cell">${escapeHtml(version.change_notes || 'No notes')}</td><td><div class="table-actions"><a href="/admin/content/${encodeURIComponent(content.id)}/versions/${encodeURIComponent(version.id)}/download">Download</a>${version.status !== 'published' ? `<form method="post" action="/admin/content/${encodeURIComponent(content.id)}/versions/${encodeURIComponent(version.id)}/publish" data-confirm="Publish revision ${escapeHtml(version.version_label)} and archive every earlier revision?"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><button type="submit">Publish</button></form>` : ''}</div></td></tr>`).join('')}</tbody></table></div></section>

      <section class="dashboard-panel shell metadata-history"><div class="panel-heading"><div><span class="eyebrow">Audit trail</span><h2>Recent metadata changes</h2></div></div>${metadataRevisions.length ? `<ol class="audit-list">${metadataRevisions.slice(0, 20).map((revision) => `<li><div><strong>${escapeHtml(revision.reason)}</strong><span>${escapeHtml(revision.changed_by)}</span></div><time>${formatDate(revision.created_at, true)}</time></li>`).join('')}</ol>` : '<p class="muted">No metadata changes recorded yet.</p>'}</section>
    </main>`;
  return layout({ config, title: `Edit ${content.title}`, body, session, bodyClass: 'admin-page' });
}

export function adminCommentsPage({ config, session, permissions, comments, filter, flash = null }) {
  const filters = ['open', 'resolved', 'hidden', 'all'];
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">Community operations</span><h1>Document message inbox</h1><p>Reply to feedback, resolve fixed issues, and keep every conversation attached to its revision.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}<nav class="filter-tabs">${filters.map((value) => `<a class="${filter === value ? 'active' : ''}" href="/admin/comments?status=${value}">${value}</a>`).join('')}</nav></div>
      <section class="message-inbox shell">${comments.length ? comments.map((comment) => `<article class="inbox-card" id="comment-${escapeHtml(comment.id)}"><header><div><span class="comment-type ${escapeHtml(comment.comment_type)}">${escapeHtml(commentTypeLabel(comment.comment_type))}</span><h2><a href="/learn/${encodeURIComponent(comment.content_slug)}#community-comments">${escapeHtml(comment.content_title)}</a></h2><p>Revision ${escapeHtml(comment.version_label || 'current')} / ${escapeHtml(comment.author_name)} / ${formatDate(comment.created_at, true)}</p></div>${statusBadge(comment.status)}</header><div class="inbox-message">${escapeHtml(comment.body).replaceAll('\n', '<br>')}</div>${comment.replies?.length ? `<div class="inbox-replies">${comment.replies.map((reply) => `<article><strong>${escapeHtml(reply.author_name)}</strong>${reply.is_staff ? '<span class="staff-badge">Publisher team</span>' : ''}<p>${escapeHtml(reply.body).replaceAll('\n', '<br>')}</p><time>${formatDate(reply.created_at, true)}</time></article>`).join('')}</div>` : ''}<div class="inbox-actions"><form method="post" action="/admin/comments/${encodeURIComponent(comment.id)}/reply" class="reply-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><textarea name="body" maxlength="${config.maxCommentLength}" rows="3" required placeholder="Reply to the community member..."></textarea><button class="button primary" type="submit">Reply</button></form><div class="status-actions">${comment.status !== 'resolved' ? `<form method="post" action="/admin/comments/${encodeURIComponent(comment.id)}/status"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><input type="hidden" name="status" value="resolved"><button type="submit">Mark resolved</button></form>` : `<form method="post" action="/admin/comments/${encodeURIComponent(comment.id)}/status"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><input type="hidden" name="status" value="open"><button type="submit">Reopen</button></form>`}${comment.status !== 'hidden' ? `<form method="post" action="/admin/comments/${encodeURIComponent(comment.id)}/status" data-confirm="Hide this thread from the public document page?"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><input type="hidden" name="status" value="hidden"><button type="submit" class="danger-link">Hide</button></form>` : ''}</div></div></article>`).join('') : '<div class="empty-state"><div class="empty-icon">&#128172;</div><h2>No messages in this view</h2><p>Community feedback will appear here by document and revision.</p></div>'}</section>
    </main>`;
  return layout({ config, title: 'Message inbox', body, session, bodyClass: 'admin-page' });
}

export function adminUsersPage({ config, session, permissions, users, flash = null }) {
  const roles = ['member', 'moderator', 'publisher', 'admin', 'super_admin'];
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">Identity and access</span><h1>User management</h1><p>Create staff accounts, assign roles, disable access, and grant premium entitlement.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}</div>
      <section class="publisher-grid shell"><article class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Create account</span><h2>Add a user or administrator</h2></div></div><form method="post" action="/admin/users" class="upload-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><div class="form-grid"><label><span>Name</span><input name="name" maxlength="120" required></label><label><span>Email</span><input type="email" name="email" maxlength="320" required></label><label><span>Temporary password</span><input type="password" name="password" minlength="10" maxlength="200" required></label><label><span>Role</span><select name="role">${roles.map((role) => `<option value="${role}">${escapeHtml(role.replace('_', ' '))}</option>`).join('')}</select></label><label><span>Subscription</span><select name="subscriptionStatus"><option value="free">Free</option><option value="premium">Premium</option></select></label></div><button class="button primary" type="submit">Create account</button></form></article><aside class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Role guide</span><h2>Permissions</h2></div></div><dl class="role-guide"><div><dt>Super admin</dt><dd>Users, branding, content, comments, backups.</dd></div><div><dt>Admin</dt><dd>Content, comments, branding, backups.</dd></div><div><dt>Publisher</dt><dd>Upload, edit, and publish revisions.</dd></div><div><dt>Moderator</dt><dd>Reply to and resolve comments.</dd></div><div><dt>Member</dt><dd>Favorites, follows, comments, gated access.</dd></div></dl></aside></section>
      <section class="dashboard-panel shell content-management"><div class="panel-heading"><div><span class="eyebrow">Accounts</span><h2>All users</h2></div><span>${users.length} accounts</span></div><div class="table-scroll"><table><thead><tr><th>User</th><th>Provider</th><th>Activity</th><th>Role and access</th><th>Last login</th></tr></thead><tbody>${users.map((user) => `<tr><td><div class="user-cell">${user.avatar_url ? `<img src="${escapeHtml(user.avatar_url)}" alt="">` : `<span>${escapeHtml((user.name || user.email).slice(0, 1).toUpperCase())}</span>`}<div><strong>${escapeHtml(user.name)}</strong><small>${escapeHtml(user.email)}</small></div></div></td><td>${escapeHtml(user.provider)}</td><td><small>${formatNumber(user.favorite_count)} favorites / ${formatNumber(user.follow_count)} follows / ${formatNumber(user.comment_count)} comments</small></td><td><form method="post" action="/admin/users/${encodeURIComponent(user.id)}" class="inline-admin-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><select name="role" aria-label="Role for ${escapeHtml(user.email)}">${roles.map((role) => `<option value="${role}" ${user.role === role ? 'selected' : ''}>${escapeHtml(role.replace('_', ' '))}</option>`).join('')}</select><select name="status" aria-label="Status for ${escapeHtml(user.email)}"><option value="active" ${user.status === 'active' ? 'selected' : ''}>Active</option><option value="disabled" ${user.status === 'disabled' ? 'selected' : ''}>Disabled</option></select><select name="subscriptionStatus" aria-label="Subscription for ${escapeHtml(user.email)}"><option value="free" ${user.subscription_status === 'free' ? 'selected' : ''}>Free</option><option value="premium" ${user.subscription_status === 'premium' ? 'selected' : ''}>Premium</option></select><button type="submit" class="table-save">Save</button></form></td><td>${user.last_login_at ? formatDate(user.last_login_at, true) : 'Never'}</td></tr>`).join('')}</tbody></table></div></section>
    </main>`;
  return layout({ config, title: 'User management', body, session, bodyClass: 'admin-page' });
}

export function brandingPage({ config, session, permissions, flash = null }) {
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">Publisher identity</span><h1>Branding settings</h1><p>Change the product name, company identity, taglines, and logo without editing source code.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}</div>
      <section class="branding-grid shell"><article class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Brand profile</span><h2>Portal identity</h2></div></div><form method="post" action="/admin/branding" enctype="multipart/form-data" class="upload-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><div class="form-grid"><label><span>Product name</span><input name="portalName" maxlength="120" required value="${escapeHtml(config.portalName)}"></label><label><span>Company / organization</span><input name="organizationName" maxlength="120" value="${escapeHtml(config.organizationName)}"></label><label class="span-two"><span>Product tagline</span><input name="productTagline" maxlength="300" value="${escapeHtml(config.productTagline)}"></label><label class="span-two"><span>Portal description</span><textarea name="portalTagline" maxlength="300" rows="4">${escapeHtml(config.portalTagline)}</textarea></label><label class="span-two"><span>Logo image</span><input type="file" name="logo" accept="image/png,image/jpeg,image/webp"><small>PNG, JPG, or WebP. A safe geometric mark is used when no logo is uploaded.</small></label></div><button class="button primary" type="submit">Save branding</button></form></article><aside class="brand-preview"><span class="eyebrow">Live preview</span><div class="preview-brand">${brandMark(config, 'large')}<div><strong>${escapeHtml(config.portalName)}</strong><small>${escapeHtml(config.organizationName)}</small></div></div><h2>${escapeHtml(config.productTagline)}</h2><p>${escapeHtml(config.portalTagline)}</p><span class="palette-note">The current green and amber palette remains fixed in this release.</span></aside></section>
    </main>`;
  return layout({ config, title: 'Branding', body, session, bodyClass: 'admin-page' });
}

export function aiSettingsPage({ config, session, permissions, aiSettings, providers, maskSecret, flash = null }) {
  const configured = aiSettings.providers || {};
  const cards = providers.map((provider) => {
    const saved = configured[provider.id] || null;
    const fields = provider.fields.map((field) => {
      const savedValue = saved?.[field.name] || '';
      if (field.type === 'password') {
        return `<label><span>${escapeHtml(field.label)}</span><input type="password" name="${provider.id}_${field.name}" autocomplete="off" placeholder="${savedValue ? `Saved (${escapeHtml(maskSecret(savedValue))}) - leave blank to keep` : 'Enter key'}"></label>`;
      }
      return `<label><span>${escapeHtml(field.label)}</span><input name="${provider.id}_${field.name}" value="${escapeHtml(savedValue)}" placeholder="${escapeHtml(field.placeholder || '')}" autocomplete="off"></label>`;
    }).join('');
    return `
      <article class="dashboard-panel provider-card ${saved ? 'configured' : ''}" id="provider-${provider.id}">
        <div class="panel-heading"><div><span class="eyebrow">${saved ? 'Configured' : 'Not configured'}</span><h2>${escapeHtml(provider.label)}</h2></div>${provider.docs ? `<a href="${escapeHtml(provider.docs)}" target="_blank" rel="noopener">Docs &#8599;</a>` : ''}</div>
        <div class="form-grid">${fields}</div>
        <div class="provider-actions">
          <label class="inline-check radio"><input type="radio" name="defaultProvider" value="${provider.id}" ${aiSettings.defaultProvider === provider.id ? 'checked' : ''} ${saved ? '' : 'disabled'}> Default provider</label>
          ${saved ? `<button type="button" class="button secondary" data-ai-test="${provider.id}">Test connection</button><span class="test-result" data-ai-result="${provider.id}"></span><label class="inline-check danger"><input type="checkbox" name="${provider.id}_clear"> Remove</label>` : ''}
        </div>
      </article>`;
  }).join('');
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">AI configuration</span><h1>AI studio</h1><p>Connect Claude, ChatGPT, Azure OpenAI, Gemini, or free model endpoints. Keys are stored server-side and never rendered back in full. The default provider powers AI icon generation and future assistant features.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}</div>
      <form method="post" action="/admin/ai" class="shell ai-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}">
        <div class="provider-grid">${cards}</div>
        <div class="sticky-save"><button class="button primary" type="submit">Save AI settings</button><span class="muted">Leave key fields blank to keep saved values. Select Remove to delete a provider configuration.</span></div>
      </form>
    </main>`;
  return layout({ config, title: 'AI studio', body, session, bodyClass: 'admin-page' });
}

export function iconLibraryPage({ config, session, permissions, customIcons, aiReady, flash = null }) {
  const builtinGrid = BUILTIN_ICON_OPTIONS.map(([value, label]) => `<figure class="icon-tile"><span class="ui-icon">${BUILTIN_ICON_SVGS[value]}</span><figcaption>${escapeHtml(label)}</figcaption></figure>`).join('');
  const customGrid = customIcons.length
    ? customIcons.map((icon) => `<figure class="icon-tile custom"><span class="ui-icon custom">${icon.svg}</span><figcaption>${escapeHtml(icon.name)}<small>${icon.source === 'ai' ? 'AI generated' : 'Uploaded'}</small></figcaption><form method="post" action="/admin/icons/${encodeURIComponent(icon.id)}/delete" data-confirm="Remove this icon? Resources using it fall back to the generic icon."><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><button type="submit" class="danger-link">Remove</button></form></figure>`).join('')
    : '<p class="muted">No custom icons yet. Upload an SVG or generate one with AI.</p>';
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">Visual identity</span><h1>Icon library</h1><p>Resources without a matching icon automatically use the generic mark. Add uploaded SVG icons or generate new ones with your configured AI provider; every icon here becomes selectable on upload and edit forms.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}</div>
      <section class="publisher-grid shell">
        <article class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Add icon</span><h2>Upload an SVG</h2></div></div><form method="post" action="/admin/icons/upload" enctype="multipart/form-data" class="stack-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><label><span>Icon name</span><input name="name" maxlength="80" required placeholder="Hydraulic pump"></label><label><span>SVG file</span><input type="file" name="icon" accept=".svg,image/svg+xml" required><small>Scripts, event handlers, and external references are stripped automatically.</small></label><button class="button primary" type="submit">Add to library</button></form></article>
        <article class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Create with AI</span><h2>Generate an icon</h2></div></div>${aiReady ? `<div class="stack-form" data-icon-generator><label><span>Icon name</span><input maxlength="80" data-icon-name placeholder="Wind turbine"></label><label><span>Describe the icon</span><textarea rows="3" maxlength="300" data-icon-description placeholder="A three-blade wind turbine on a mast, minimal line style"></textarea></label><button class="button primary" type="button" data-icon-generate>Generate and save</button><span class="test-result" data-icon-result></span><div class="icon-preview" data-icon-preview></div></div>` : '<p class="muted">Configure a default provider in the <a href="/admin/ai">AI studio</a> to generate icons.</p>'}</article>
      </section>
      <section class="dashboard-panel shell"><div class="panel-heading"><div><span class="eyebrow">Custom icons</span><h2>Library</h2></div><span>${customIcons.length} icon${customIcons.length === 1 ? '' : 's'}</span></div><div class="icon-grid">${customGrid}</div></section>
      <section class="dashboard-panel shell"><div class="panel-heading"><div><span class="eyebrow">Built in</span><h2>Standard icon set</h2></div></div><div class="icon-grid">${builtinGrid}</div></section>
    </main>`;
  return layout({ config, title: 'Icon library', body, session, bodyClass: 'admin-page' });
}

export function integrationsPage({ config, session, permissions, sharePoint, fields, maskSecret, flash = null }) {
  const inputs = fields.map((field) => {
    const savedValue = sharePoint?.[field.name] || '';
    if (field.secret) {
      return `<label><span>${escapeHtml(field.label)}</span><input type="password" name="${field.name}" autocomplete="off" placeholder="${savedValue ? `Saved (${escapeHtml(maskSecret(savedValue))}) - leave blank to keep` : 'Enter secret'}"></label>`;
    }
    return `<label><span>${escapeHtml(field.label)}</span><input name="${field.name}" value="${escapeHtml(savedValue)}" placeholder="${escapeHtml(field.placeholder || '')}" autocomplete="off"></label>`;
  }).join('');
  const body = `
    <main class="admin-main">
      <section class="admin-header shell"><div><span class="eyebrow">Connected sources</span><h1>Integrations</h1><p>Stage two of the platform plan connects enterprise content sources. SharePoint configuration and connectivity testing are available now; catalog import from document libraries ships in the next stage.</p></div>${adminNav(session, permissions)}</section>
      <div class="shell">${flash?.message ? `<div class="alert ${flash.type === 'error' ? 'error' : 'success'}">${escapeHtml(flash.message)}</div>` : ''}</div>
      <section class="publisher-grid shell">
        <article class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Microsoft 365</span><h2>SharePoint (Microsoft Graph)</h2></div><span class="stage-pill">Stage 2 provision</span></div>
          <form method="post" action="/admin/integrations" class="upload-form"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf)}"><div class="form-grid">${inputs}</div><div class="checkbox-row"><label><input type="checkbox" name="enabled" ${sharePoint?.enabled ? 'checked' : ''}> Enable this connection for the upcoming import feature</label></div><div class="action-row"><button class="button primary" type="submit">Save SharePoint settings</button><button class="button secondary" type="button" data-sharepoint-test>Test connection</button><span class="test-result" data-sharepoint-result>${sharePoint?.lastTest?.ok ? `Last verified: ${escapeHtml(sharePoint.lastTest.siteName || '')} (${escapeHtml(sharePoint.lastTest.at || '')})` : ''}</span></div></form>
        </article>
        <aside class="dashboard-panel"><div class="panel-heading"><div><span class="eyebrow">Setup guide</span><h2>App registration</h2></div></div><ol class="setup-steps"><li>In Entra ID, register an application and create a client secret.</li><li>Grant the application permission <code>Sites.Read.All</code> (Microsoft Graph, application type) and give admin consent.</li><li>Enter the tenant, client, secret, and the site hostname and path here, then test.</li><li>Next stage: browse the site's document library and import files as catalog drafts.</li></ol></aside>
      </section>
    </main>`;
  return layout({ config, title: 'Integrations', body, session, bodyClass: 'admin-page' });
}

export function forbiddenPage({ config, session, message = 'You do not have permission to open this page.' }) {
  const body = `<main class="message-main"><section class="empty-state"><div class="empty-icon">403</div><h1>Access denied</h1><p>${escapeHtml(message)}</p><a class="button primary" href="/">Return to the library</a></section></main>`;
  return layout({ config, title: 'Access denied', body, session });
}

export function notFoundPage({ config, session }) {
  const body = `<main class="message-main"><section class="empty-state"><div class="empty-icon">404</div><h1>Page not found</h1><p>The requested learning resource is unavailable or has not been published.</p><a class="button primary" href="/">Return to the library</a></section></main>`;
  return layout({ config, title: 'Not found', body, session });
}

export function errorPage({ config, message, session }) {
  const body = `<main class="message-main"><section class="empty-state"><div class="empty-icon">!</div><h1>Something went wrong</h1><p>${escapeHtml(message || 'The request could not be completed.')}</p><a class="button primary" href="/">Return to the library</a></section></main>`;
  return layout({ config, title: 'Error', body, session });
}
