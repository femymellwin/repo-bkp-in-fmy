import path from 'node:path';
import { boolValue, clampInt } from './utils.mjs';

export const APPLICATION_VERSION = '0.3.0';

export function loadConfig(overrides = {}) {
  const projectRoot = path.resolve(overrides.projectRoot || process.cwd());
  const dataDir = path.resolve(projectRoot, overrides.dataDir || process.env.DATA_DIR || './data');
  const backupDir = path.resolve(projectRoot, overrides.backupDir || process.env.BACKUP_DIR || './backups');
  const port = clampInt(overrides.port ?? process.env.PORT, 1, 65535, 3000);
  const host = overrides.host || process.env.HOST || '127.0.0.1';
  const publicBaseUrl = String(overrides.publicBaseUrl || process.env.PUBLIC_BASE_URL || `http://localhost:${port}`).replace(/\/+$/, '');
  const storageDriver = String(overrides.storageDriver || process.env.STORAGE_DRIVER || 'local').toLowerCase();
  const nodeEnv = overrides.nodeEnv || process.env.NODE_ENV || 'development';
  const turnstileSiteKey = overrides.turnstileSiteKey || process.env.TURNSTILE_SITE_KEY || '';
  const turnstileSecretKey = overrides.turnstileSecretKey || process.env.TURNSTILE_SECRET_KEY || '';
  const googleClientId = overrides.googleClientId || process.env.GOOGLE_CLIENT_ID || '';
  const googleClientSecret = overrides.googleClientSecret || process.env.GOOGLE_CLIENT_SECRET || '';

  return {
    applicationVersion: APPLICATION_VERSION,
    projectRoot,
    dataDir,
    backupDir,
    databasePath: path.join(dataDir, 'portal.sqlite'),
    port,
    host,
    publicBaseUrl,
    portalName: overrides.portalName || process.env.PORTAL_NAME || 'OpenLearn Atlas',
    portalTagline: overrides.portalTagline || process.env.PORTAL_TAGLINE || 'Interactive knowledge, open to everyone.',
    organizationName: overrides.organizationName || process.env.ORGANIZATION_NAME || 'Your organization',
    productTagline: overrides.productTagline || process.env.PRODUCT_TAGLINE || 'Learn it. Test it. Improve it together.',
    adminName: overrides.adminName || process.env.ADMIN_NAME || 'Portal Owner',
    adminEmail: overrides.adminEmail || process.env.ADMIN_EMAIL || 'admin@example.com',
    adminPassword: overrides.adminPassword || process.env.ADMIN_PASSWORD || 'ChangeMe123!',
    adminPasswordHash: overrides.adminPasswordHash || process.env.ADMIN_PASSWORD_HASH || '',
    sessionSecret: overrides.sessionSecret || process.env.SESSION_SECRET || 'local-demo-session-secret-change-before-production',
    privacySalt: overrides.privacySalt || process.env.PRIVACY_SALT || 'local-demo-privacy-salt-change-before-production',
    secureCookies: nodeEnv === 'production',
    nodeEnv,
    sessionMaxAgeSeconds: clampInt(overrides.sessionMaxAgeSeconds ?? process.env.SESSION_MAX_AGE_SECONDS, 900, 30 * 86400, 8 * 3600),
    allowRegistration: boolValue(overrides.allowRegistration ?? process.env.ALLOW_REGISTRATION, true),
    maxUploadBytes: clampInt(overrides.maxUploadMb ?? process.env.MAX_UPLOAD_MB, 1, 2048, 100) * 1024 * 1024,
    maxExtractedBytes: clampInt(overrides.maxExtractedMb ?? process.env.MAX_EXTRACTED_MB, 1, 8192, 300) * 1024 * 1024,
    maxZipFiles: clampInt(overrides.maxZipFiles ?? process.env.MAX_ZIP_FILES, 1, 100000, 3000),
    maxCommentLength: clampInt(overrides.maxCommentLength ?? process.env.MAX_COMMENT_LENGTH, 100, 10000, 3000),
    spinVerifiedMinVotes: clampInt(overrides.spinVerifiedMinVotes ?? process.env.SPIN_VERIFIED_MIN_VOTES, 1, 100000, 3),
    spinVerifiedThresholdPercent: clampInt(overrides.spinVerifiedThresholdPercent ?? process.env.SPIN_VERIFIED_THRESHOLD_PERCENT, 1, 100, 75),
    storageDriver,
    awsRegion: overrides.awsRegion || process.env.AWS_REGION || 'me-central-1',
    awsAccessKeyId: overrides.awsAccessKeyId || process.env.AWS_ACCESS_KEY_ID || '',
    awsSecretAccessKey: overrides.awsSecretAccessKey || process.env.AWS_SECRET_ACCESS_KEY || '',
    awsSessionToken: overrides.awsSessionToken || process.env.AWS_SESSION_TOKEN || '',
    contentS3Bucket: overrides.contentS3Bucket || process.env.CONTENT_S3_BUCKET || '',
    backupS3Bucket: overrides.backupS3Bucket || process.env.BACKUP_S3_BUCKET || '',
    cdnBaseUrl: overrides.cdnBaseUrl || process.env.CDN_BASE_URL || '',
    s3Prefix: overrides.s3Prefix || process.env.S3_PREFIX || '',
    backupRetentionCount: clampInt(overrides.backupRetentionCount ?? process.env.BACKUP_RETENTION_COUNT, 1, 3650, 30),
    autoBackup: boolValue(overrides.autoBackup ?? process.env.AUTO_BACKUP, false),
    autoBackupHourUtc: clampInt(overrides.autoBackupHourUtc ?? process.env.AUTO_BACKUP_HOUR_UTC, 0, 23, 2),
    googleClientId,
    googleClientSecret,
    googleRedirectUri: overrides.googleRedirectUri || process.env.GOOGLE_REDIRECT_URI || `${publicBaseUrl}/auth/google/callback`,
    googleEnabled: Boolean(googleClientId && googleClientSecret),
    turnstileSiteKey,
    turnstileSecretKey,
    turnstileEnabled: Boolean(turnstileSiteKey && turnstileSecretKey),
    captchaBypass: nodeEnv === 'test' && boolValue(overrides.captchaBypass ?? process.env.CAPTCHA_BYPASS, false),
    defaultCredentials: (overrides.adminEmail || process.env.ADMIN_EMAIL || 'admin@example.com') === 'admin@example.com' &&
      !overrides.adminPasswordHash && !process.env.ADMIN_PASSWORD_HASH &&
      (overrides.adminPassword || process.env.ADMIN_PASSWORD || 'ChangeMe123!') === 'ChangeMe123!',
    weakSecrets: (overrides.sessionSecret || process.env.SESSION_SECRET || '').length < 32 ||
      (overrides.privacySalt || process.env.PRIVACY_SALT || '').length < 32
  };
}
