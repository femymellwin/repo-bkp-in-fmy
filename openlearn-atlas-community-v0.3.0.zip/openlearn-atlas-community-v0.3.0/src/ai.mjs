// AI provider integration layer.
// Providers are configured at runtime in the publisher console (AI studio).
// Keys are stored in portal_settings and never rendered back to the browser
// in full; only a masked fingerprint is shown after saving.

import { sanitizeSvg } from './formats.mjs';

export const AI_PROVIDERS = Object.freeze([
  {
    id: 'anthropic',
    label: 'Anthropic Claude',
    docs: 'https://docs.claude.com',
    fields: [
      { name: 'apiKey', label: 'API key', type: 'password', required: true },
      { name: 'model', label: 'Model', type: 'text', placeholder: 'claude-sonnet-4-5', required: true }
    ]
  },
  {
    id: 'openai',
    label: 'OpenAI ChatGPT',
    docs: 'https://platform.openai.com/docs',
    fields: [
      { name: 'apiKey', label: 'API key', type: 'password', required: true },
      { name: 'model', label: 'Model', type: 'text', placeholder: 'gpt-4o-mini', required: true },
      { name: 'baseUrl', label: 'Base URL (optional override)', type: 'text', placeholder: 'https://api.openai.com/v1' }
    ]
  },
  {
    id: 'azure_openai',
    label: 'Azure OpenAI (GPT)',
    docs: 'https://learn.microsoft.com/azure/ai-services/openai/',
    fields: [
      { name: 'apiKey', label: 'API key', type: 'password', required: true },
      { name: 'endpoint', label: 'Resource endpoint', type: 'text', placeholder: 'https://your-resource.openai.azure.com', required: true },
      { name: 'deployment', label: 'Deployment name', type: 'text', placeholder: 'gpt-4o', required: true },
      { name: 'apiVersion', label: 'API version', type: 'text', placeholder: '2024-10-21', required: true }
    ]
  },
  {
    id: 'gemini',
    label: 'Google Gemini',
    docs: 'https://ai.google.dev',
    fields: [
      { name: 'apiKey', label: 'API key', type: 'password', required: true },
      { name: 'model', label: 'Model', type: 'text', placeholder: 'gemini-2.0-flash', required: true }
    ]
  },
  {
    id: 'ollama',
    label: 'Ollama (free, local models)',
    docs: 'https://ollama.com',
    fields: [
      { name: 'baseUrl', label: 'Server URL', type: 'text', placeholder: 'http://localhost:11434', required: true },
      { name: 'model', label: 'Model', type: 'text', placeholder: 'llama3.2', required: true }
    ]
  },
  {
    id: 'openrouter',
    label: 'OpenRouter (free model tier)',
    docs: 'https://openrouter.ai/docs',
    fields: [
      { name: 'apiKey', label: 'API key', type: 'password', required: true },
      { name: 'model', label: 'Model', type: 'text', placeholder: 'meta-llama/llama-3.3-70b-instruct:free', required: true }
    ]
  },
  {
    id: 'groq',
    label: 'Groq (free tier)',
    docs: 'https://console.groq.com/docs',
    fields: [
      { name: 'apiKey', label: 'API key', type: 'password', required: true },
      { name: 'model', label: 'Model', type: 'text', placeholder: 'llama-3.3-70b-versatile', required: true }
    ]
  },
  {
    id: 'custom',
    label: 'Custom OpenAI-compatible endpoint',
    docs: '',
    fields: [
      { name: 'baseUrl', label: 'Base URL', type: 'text', placeholder: 'https://your-gateway.example.com/v1', required: true },
      { name: 'apiKey', label: 'API key (optional)', type: 'password' },
      { name: 'model', label: 'Model', type: 'text', required: true }
    ]
  }
]);

export function providerDefinition(id) {
  return AI_PROVIDERS.find((provider) => provider.id === id) || null;
}

export function maskSecret(value = '') {
  const text = String(value);
  if (!text) return '';
  if (text.length <= 8) return '****';
  return `${text.slice(0, 4)}...${text.slice(-4)}`;
}

function requireFields(providerId, settings, names) {
  for (const name of names) {
    if (!String(settings?.[name] || '').trim()) throw new Error(`${providerId}: ${name} is not configured`);
  }
}

async function readJson(response, label) {
  const text = await response.text();
  let payload = null;
  try { payload = JSON.parse(text); } catch { /* keep raw text */ }
  if (!response.ok) {
    const detail = payload?.error?.message || payload?.message || text.slice(0, 300) || response.statusText;
    throw new Error(`${label} request failed (${response.status}): ${detail}`);
  }
  return payload;
}

function openAiCompatibleUrl(baseUrl) {
  const clean = String(baseUrl || '').replace(/\/+$/, '');
  return clean.endsWith('/v1') ? `${clean}/chat/completions` : `${clean}/v1/chat/completions`;
}

// Single entry point: run a chat completion against any configured provider.
export async function chatComplete({ providerId, settings, system = '', prompt, maxTokens = 1200, timeoutMs = 45000 }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    if (providerId === 'anthropic') {
      requireFields(providerId, settings, ['apiKey', 'model']);
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        signal: controller.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': settings.apiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: settings.model, max_tokens: maxTokens, system: system || undefined, messages: [{ role: 'user', content: prompt }] })
      });
      const payload = await readJson(response, 'Anthropic');
      return (payload.content || []).filter((block) => block.type === 'text').map((block) => block.text).join('\n').trim();
    }

    if (providerId === 'gemini') {
      requireFields(providerId, settings, ['apiKey', 'model']);
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(settings.model)}:generateContent`;
      const response = await fetch(url, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': settings.apiKey },
        body: JSON.stringify({
          system_instruction: system ? { parts: [{ text: system }] } : undefined,
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: maxTokens }
        })
      });
      const payload = await readJson(response, 'Gemini');
      return (payload.candidates?.[0]?.content?.parts || []).map((part) => part.text || '').join('\n').trim();
    }

    if (providerId === 'azure_openai') {
      requireFields(providerId, settings, ['apiKey', 'endpoint', 'deployment', 'apiVersion']);
      const endpoint = String(settings.endpoint).replace(/\/+$/, '');
      const url = `${endpoint}/openai/deployments/${encodeURIComponent(settings.deployment)}/chat/completions?api-version=${encodeURIComponent(settings.apiVersion)}`;
      const response = await fetch(url, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'content-type': 'application/json', 'api-key': settings.apiKey },
        body: JSON.stringify({
          messages: [...(system ? [{ role: 'system', content: system }] : []), { role: 'user', content: prompt }],
          max_tokens: maxTokens
        })
      });
      const payload = await readJson(response, 'Azure OpenAI');
      return String(payload.choices?.[0]?.message?.content || '').trim();
    }

    if (providerId === 'ollama') {
      requireFields(providerId, settings, ['baseUrl', 'model']);
      const url = `${String(settings.baseUrl).replace(/\/+$/, '')}/api/chat`;
      const response = await fetch(url, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          model: settings.model,
          stream: false,
          messages: [...(system ? [{ role: 'system', content: system }] : []), { role: 'user', content: prompt }]
        })
      });
      const payload = await readJson(response, 'Ollama');
      return String(payload.message?.content || '').trim();
    }

    // openai, openrouter, groq, custom all speak the OpenAI chat completions API.
    const bases = {
      openai: settings.baseUrl || 'https://api.openai.com/v1',
      openrouter: 'https://openrouter.ai/api/v1',
      groq: 'https://api.groq.com/openai/v1',
      custom: settings.baseUrl
    };
    if (!(providerId in bases)) throw new Error(`Unknown AI provider: ${providerId}`);
    requireFields(providerId, settings, providerId === 'custom' ? ['baseUrl', 'model'] : ['apiKey', 'model']);
    const headers = { 'content-type': 'application/json' };
    if (settings.apiKey) headers.authorization = `Bearer ${settings.apiKey}`;
    const response = await fetch(openAiCompatibleUrl(bases[providerId]), {
      method: 'POST',
      signal: controller.signal,
      headers,
      body: JSON.stringify({
        model: settings.model,
        max_tokens: maxTokens,
        messages: [...(system ? [{ role: 'system', content: system }] : []), { role: 'user', content: prompt }]
      })
    });
    const payload = await readJson(response, providerDefinition(providerId)?.label || providerId);
    return String(payload.choices?.[0]?.message?.content || '').trim();
  } finally {
    clearTimeout(timer);
  }
}

export async function testProvider({ providerId, settings }) {
  const startedAt = Date.now();
  const text = await chatComplete({
    providerId,
    settings,
    prompt: 'Reply with the single word: ready',
    maxTokens: 20,
    timeoutMs: 25000
  });
  return { ok: true, latencyMs: Date.now() - startedAt, sample: text.slice(0, 120) };
}

const ICON_SYSTEM_PROMPT = [
  'You generate small monochrome SVG icons for a learning platform.',
  'Rules:',
  '- Respond with ONLY one <svg> element and nothing else. No markdown fences, no commentary.',
  '- Use viewBox="0 0 24 24", no width/height attributes.',
  '- Use stroke="currentColor" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round".',
  '- No <script>, no event handlers, no external references, no raster images, no text elements.',
  '- Keep it simple: at most 12 shape elements.'
].join('\n');

export async function generateIconSvg({ providerId, settings, description }) {
  const raw = await chatComplete({
    providerId,
    settings,
    system: ICON_SYSTEM_PROMPT,
    prompt: `Create an icon representing: ${String(description).slice(0, 300)}`,
    maxTokens: 900
  });
  const cleaned = raw.replace(/```(?:svg|xml|html)?/gi, '').replace(/```/g, '').trim();
  const svg = sanitizeSvg(cleaned);
  if (svg.length > 20000) throw new Error('The generated icon is too large');
  return svg;
}
