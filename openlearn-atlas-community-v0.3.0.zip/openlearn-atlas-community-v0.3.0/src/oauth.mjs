import { createHash } from 'node:crypto';
import { createSignedToken, verifySignedToken } from './auth.mjs';
import { randomId } from './utils.mjs';

const GOOGLE_AUTHORIZATION_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
const GOOGLE_USERINFO_ENDPOINT = 'https://openidconnect.googleapis.com/v1/userinfo';
const GOOGLE_OAUTH_COOKIE = 'portal_google_oauth';

function safeReturnTo(value) {
  const path = String(value || '/my-library');
  return path.startsWith('/') && !path.startsWith('//') ? path.slice(0, 500) : '/my-library';
}

function codeChallenge(verifier) {
  return createHash('sha256').update(verifier).digest('base64url');
}

export function googleOauthCookieName() {
  return GOOGLE_OAUTH_COOKIE;
}

export function createGoogleAuthorization(config, returnTo = '/my-library') {
  if (!config.googleEnabled) throw new Error('Google sign-in is not configured');
  const state = randomId(24);
  const verifier = randomId(48);
  const cookieToken = createSignedToken({
    state,
    verifier,
    returnTo: safeReturnTo(returnTo),
    exp: Math.floor(Date.now() / 1000) + 10 * 60
  }, config.sessionSecret);
  const url = new URL(GOOGLE_AUTHORIZATION_ENDPOINT);
  url.searchParams.set('client_id', config.googleClientId);
  url.searchParams.set('redirect_uri', config.googleRedirectUri);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', 'openid email profile');
  url.searchParams.set('state', state);
  url.searchParams.set('code_challenge', codeChallenge(verifier));
  url.searchParams.set('code_challenge_method', 'S256');
  url.searchParams.set('prompt', 'select_account');
  return { authorizationUrl: url.toString(), cookieToken };
}

export async function completeGoogleAuthorization({ config, code, state, cookieToken }) {
  if (!config.googleEnabled) throw new Error('Google sign-in is not configured');
  const oauth = verifySignedToken(cookieToken, config.sessionSecret);
  if (!oauth || !state || oauth.state !== state || !code) throw new Error('Google sign-in state could not be verified');

  const tokenResponse = await fetch(GOOGLE_TOKEN_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code: String(code),
      client_id: config.googleClientId,
      client_secret: config.googleClientSecret,
      redirect_uri: config.googleRedirectUri,
      grant_type: 'authorization_code',
      code_verifier: oauth.verifier
    }),
    signal: AbortSignal.timeout(12000)
  });
  const tokenResult = await tokenResponse.json().catch(() => ({}));
  if (!tokenResponse.ok || !tokenResult.access_token) throw new Error('Google did not accept the authorization code');

  const profileResponse = await fetch(GOOGLE_USERINFO_ENDPOINT, {
    headers: { Authorization: `Bearer ${tokenResult.access_token}` },
    signal: AbortSignal.timeout(12000)
  });
  const profile = await profileResponse.json().catch(() => ({}));
  if (!profileResponse.ok || !profile.sub || !profile.email || profile.email_verified !== true) {
    throw new Error('A verified Google email address is required');
  }

  return {
    subject: String(profile.sub),
    email: String(profile.email).trim().toLowerCase(),
    name: String(profile.name || profile.email).trim().slice(0, 120),
    picture: String(profile.picture || '').slice(0, 1000),
    returnTo: oauth.returnTo
  };
}
