// Minimal, dependency-free Markdown renderer used to pre-render .md and .txt
// learning packages into a styled standalone HTML article at upload time.
// Output is fully escaped first, then a small allow-list of markup is applied,
// so no raw HTML from the source document ever reaches the page.

import { escapeHtml } from './utils.mjs';

function inline(text) {
  return text
    .replace(/`([^`]+)`/g, (_, code) => `<code>${code}</code>`)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/!\[([^\]]*)\]\((https?:\/\/[^)\s]+)\)/g, '<img src="$2" alt="$1" loading="lazy">')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}

export function markdownToHtml(source = '') {
  const lines = escapeHtml(String(source).replaceAll('\r\n', '\n')).split('\n');
  const output = [];
  let index = 0;
  let listType = null;

  const closeList = () => {
    if (listType) {
      output.push(`</${listType}>`);
      listType = null;
    }
  };

  while (index < lines.length) {
    const line = lines[index];

    if (line.startsWith('```')) {
      closeList();
      const block = [];
      index += 1;
      while (index < lines.length && !lines[index].startsWith('```')) {
        block.push(lines[index]);
        index += 1;
      }
      index += 1;
      output.push(`<pre><code>${block.join('\n')}</code></pre>`);
      continue;
    }

    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      closeList();
      const level = heading[1].length;
      output.push(`<h${level}>${inline(heading[2])}</h${level}>`);
      index += 1;
      continue;
    }

    if (/^\s*([-*+])\s+/.test(line)) {
      if (listType !== 'ul') { closeList(); output.push('<ul>'); listType = 'ul'; }
      output.push(`<li>${inline(line.replace(/^\s*[-*+]\s+/, ''))}</li>`);
      index += 1;
      continue;
    }

    if (/^\s*\d+\.\s+/.test(line)) {
      if (listType !== 'ol') { closeList(); output.push('<ol>'); listType = 'ol'; }
      output.push(`<li>${inline(line.replace(/^\s*\d+\.\s+/, ''))}</li>`);
      index += 1;
      continue;
    }

    if (/^\s*(---|\*\*\*|___)\s*$/.test(line)) {
      closeList();
      output.push('<hr>');
      index += 1;
      continue;
    }

    if (line.startsWith('&gt;')) {
      closeList();
      const quote = [];
      while (index < lines.length && lines[index].startsWith('&gt;')) {
        quote.push(inline(lines[index].replace(/^&gt;\s?/, '')));
        index += 1;
      }
      output.push(`<blockquote><p>${quote.join('<br>')}</p></blockquote>`);
      continue;
    }

    if (!line.trim()) {
      closeList();
      index += 1;
      continue;
    }

    closeList();
    const paragraph = [inline(line)];
    index += 1;
    while (index < lines.length && lines[index].trim() && !/^(#{1,6}\s|\s*[-*+]\s|\s*\d+\.\s|```|&gt;)/.test(lines[index]) && !/^\s*(---|\*\*\*|___)\s*$/.test(lines[index])) {
      paragraph.push(inline(lines[index]));
      index += 1;
    }
    output.push(`<p>${paragraph.join('<br>')}</p>`);
  }
  closeList();
  return output.join('\n');
}

export function renderMarkdown(source, { title = 'Article' } = {}) {
  const body = markdownToHtml(source);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light">
<title>${escapeHtml(title)}</title>
<style>
  :root { color-scheme: light; }
  body { margin: 0; padding: 48px 24px 80px; background: #ffffff; color: #1c2530; font: 16px/1.75 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
  article { max-width: 760px; margin: 0 auto; }
  h1, h2, h3, h4 { line-height: 1.25; color: #101820; letter-spacing: -0.01em; }
  h1 { font-size: 2rem; margin-top: 0; }
  h2 { font-size: 1.5rem; margin-top: 2.2em; border-bottom: 1px solid #e6ebf1; padding-bottom: 0.35em; }
  a { color: #0f6d4e; }
  code { background: #f2f5f8; border: 1px solid #e3e9ef; border-radius: 5px; padding: 0.1em 0.4em; font-size: 0.92em; }
  pre { background: #0f1720; color: #e8eef5; border-radius: 10px; padding: 18px 20px; overflow-x: auto; }
  pre code { background: transparent; border: none; color: inherit; padding: 0; }
  blockquote { margin: 1.4em 0; padding: 0.4em 1.2em; border-left: 4px solid #0f6d4e; background: #f4faf7; border-radius: 0 8px 8px 0; }
  img { max-width: 100%; border-radius: 10px; }
  hr { border: none; border-top: 1px solid #e6ebf1; margin: 2.5em 0; }
  table { border-collapse: collapse; }
</style>
</head>
<body><article>${body}</article></body>
</html>`;
}
