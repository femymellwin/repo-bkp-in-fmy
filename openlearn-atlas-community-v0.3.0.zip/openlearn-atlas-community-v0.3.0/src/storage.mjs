import fs from 'node:fs';
import path from 'node:path';
import { putS3Object } from './s3.mjs';
import { encodePathSegments, mimeType } from './utils.mjs';

function validateKey(key) {
  const normalized = String(key).replaceAll('\\', '/').replace(/^\/+/, '');
  const segments = normalized.split('/');
  if (!normalized || segments.some((segment) => segment === '..' || segment.includes('\0'))) {
    throw new Error('Invalid storage key');
  }
  return normalized;
}

export function walkDirectory(root) {
  const output = [];
  const visit = (directory) => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const fullPath = path.join(directory, entry.name);
      if (entry.isDirectory()) visit(fullPath);
      else if (entry.isFile()) output.push(fullPath);
    }
  };
  visit(root);
  return output;
}

export class PortalStorage {
  constructor(config) {
    this.driver = config.storageDriver;
    this.dataDir = config.dataDir;
    this.localRoot = path.join(this.dataDir, 'storage');
    this.region = config.awsRegion;
    this.contentBucket = config.contentS3Bucket;
    this.backupBucket = config.backupS3Bucket;
    this.accessKeyId = config.awsAccessKeyId;
    this.secretAccessKey = config.awsSecretAccessKey;
    this.sessionToken = config.awsSessionToken;
    this.cdnBaseUrl = String(config.cdnBaseUrl || '').replace(/\/+$/, '');
    this.prefix = String(config.s3Prefix || '').replace(/^\/+|\/+$/g, '');
    fs.mkdirSync(this.localRoot, { recursive: true });
  }

  prefixed(key) {
    const clean = validateKey(key);
    return this.prefix ? `${this.prefix}/${clean}` : clean;
  }

  localPath(key) {
    const clean = validateKey(key);
    const full = path.join(this.localRoot, ...clean.split('/'));
    const relative = path.relative(this.localRoot, full);
    if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('Storage path escaped root');
    return full;
  }

  async putBuffer(key, buffer, options = {}) {
    const clean = validateKey(key);
    if (this.driver === 's3') {
      return putS3Object({
        bucket: this.contentBucket,
        key: this.prefixed(clean),
        body: buffer,
        region: this.region,
        accessKeyId: this.accessKeyId,
        secretAccessKey: this.secretAccessKey,
        sessionToken: this.sessionToken,
        contentType: options.contentType || mimeType(clean),
        cacheControl: options.cacheControl || 'public, max-age=31536000, immutable',
        contentDisposition: options.contentDisposition
      });
    }

    const target = this.localPath(clean);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const temp = `${target}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(temp, buffer);
    fs.renameSync(temp, target);
    return { key: clean };
  }

  async putFile(key, filePath, options = {}) {
    return this.putBuffer(key, fs.readFileSync(filePath), {
      contentType: options.contentType || mimeType(filePath),
      cacheControl: options.cacheControl,
      contentDisposition: options.contentDisposition
    });
  }

  async putDirectory(prefix, directory, options = {}) {
    const files = walkDirectory(directory);
    for (const file of files) {
      const relative = path.relative(directory, file).split(path.sep).join('/');
      await this.putFile(`${prefix}/${relative}`, file, options);
    }
    return files.length;
  }

  mediaUrl(key) {
    const clean = validateKey(key);
    if (this.driver === 's3') {
      if (!this.cdnBaseUrl) throw new Error('CDN_BASE_URL is required in S3 mode');
      return `${this.cdnBaseUrl}/${encodePathSegments(this.prefixed(clean))}`;
    }
    return `/media/${encodePathSegments(clean)}`;
  }

  previewKey(contentId, versionId, entrypoint) {
    const root = String(versionId || '').startsWith('legacy-')
      ? `content/${contentId}/preview`
      : `content/${contentId}/versions/${versionId}/preview`;
    return `${root}/${entrypoint}`;
  }

  previewUrl(contentId, versionId, entrypoint) {
    if (this.driver === 's3') return this.mediaUrl(this.previewKey(contentId, versionId, entrypoint));
    return `/preview/${encodeURIComponent(contentId)}/${encodePathSegments(entrypoint)}`;
  }

  async putBackup(key, buffer) {
    if (!this.backupBucket) return null;
    return putS3Object({
      bucket: this.backupBucket,
      key: this.prefixed(`backups/${key}`),
      body: buffer,
      region: this.region,
      accessKeyId: this.accessKeyId,
      secretAccessKey: this.secretAccessKey,
      sessionToken: this.sessionToken,
      contentType: String(key).endsWith('.sha256') ? 'text/plain; charset=utf-8' : 'application/gzip',
      cacheControl: 'private, max-age=0',
      storageClass: 'STANDARD'
    });
  }
}
