// SharePoint connector (stage-two provision).
// This release ships configuration, connectivity testing, and read-only site
// discovery through Microsoft Graph using the client-credentials flow.
// Bulk import of SharePoint document libraries into the catalog is planned
// for the next stage and will build on getGraphToken / listDriveChildren.

export const SHAREPOINT_FIELDS = Object.freeze([
  { name: 'tenantId', label: 'Directory (tenant) ID', required: true },
  { name: 'clientId', label: 'Application (client) ID', required: true },
  { name: 'clientSecret', label: 'Client secret', required: true, secret: true },
  { name: 'siteHostname', label: 'Site hostname', placeholder: 'contoso.sharepoint.com', required: true },
  { name: 'sitePath', label: 'Site path', placeholder: '/sites/Learning', required: true }
]);

async function readJson(response, label) {
  const text = await response.text();
  let payload = null;
  try { payload = JSON.parse(text); } catch { /* raw */ }
  if (!response.ok) {
    const detail = payload?.error_description || payload?.error?.message || text.slice(0, 300) || response.statusText;
    throw new Error(`${label} failed (${response.status}): ${detail}`);
  }
  return payload;
}

export async function getGraphToken(settings, timeoutMs = 20000) {
  for (const field of ['tenantId', 'clientId', 'clientSecret']) {
    if (!String(settings?.[field] || '').trim()) throw new Error(`SharePoint: ${field} is not configured`);
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const body = new URLSearchParams({
      client_id: settings.clientId,
      client_secret: settings.clientSecret,
      scope: 'https://graph.microsoft.com/.default',
      grant_type: 'client_credentials'
    });
    const response = await fetch(`https://login.microsoftonline.com/${encodeURIComponent(settings.tenantId)}/oauth2/v2.0/token`, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    });
    const payload = await readJson(response, 'Microsoft identity token');
    return payload.access_token;
  } finally {
    clearTimeout(timer);
  }
}

export async function testSharePointConnection(settings) {
  const startedAt = Date.now();
  const token = await getGraphToken(settings);
  const sitePath = String(settings.sitePath || '/').replace(/^\/+/, '');
  const url = `https://graph.microsoft.com/v1.0/sites/${encodeURIComponent(settings.siteHostname)}:/${sitePath}`;
  const response = await fetch(url, { headers: { authorization: `Bearer ${token}` } });
  const site = await readJson(response, 'Microsoft Graph site lookup');
  return {
    ok: true,
    latencyMs: Date.now() - startedAt,
    siteId: site.id || '',
    siteName: site.displayName || site.name || '',
    webUrl: site.webUrl || ''
  };
}

// Reserved for the stage-two import job: list files inside the default
// document library of the configured site.
export async function listDriveChildren(settings, folderPath = '') {
  const token = await getGraphToken(settings);
  const sitePath = String(settings.sitePath || '/').replace(/^\/+/, '');
  const siteResponse = await fetch(`https://graph.microsoft.com/v1.0/sites/${encodeURIComponent(settings.siteHostname)}:/${sitePath}`, {
    headers: { authorization: `Bearer ${token}` }
  });
  const site = await readJson(siteResponse, 'Microsoft Graph site lookup');
  const itemPath = folderPath ? `:/${folderPath.replace(/^\/+/, '')}:` : '';
  const listResponse = await fetch(`https://graph.microsoft.com/v1.0/sites/${site.id}/drive/root${itemPath}/children?$top=200`, {
    headers: { authorization: `Bearer ${token}` }
  });
  const listing = await readJson(listResponse, 'Microsoft Graph drive listing');
  return (listing.value || []).map((item) => ({
    id: item.id,
    name: item.name,
    size: item.size || 0,
    isFolder: Boolean(item.folder),
    webUrl: item.webUrl || '',
    lastModified: item.lastModifiedDateTime || ''
  }));
}
