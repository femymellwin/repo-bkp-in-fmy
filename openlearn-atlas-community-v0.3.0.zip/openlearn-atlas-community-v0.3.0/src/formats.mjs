// Format registry for OpenLearn Atlas.
// Every uploadable learning package format is declared here with its viewer
// strategy so the rest of the application never hard-codes an extension.

export const MEDIA_KINDS = new Set(['interactive', 'video', 'document', 'image', 'markdown', 'presentation', 'spreadsheet', 'archive']);

// viewer values:
//   sandbox   - HTML/ZIP interactive package rendered in the sandboxed preview iframe
//   video     - HTML5 <video> player with poster thumbnail and range streaming
//   pdf       - browser-native PDF rendering in a restricted iframe
//   image     - inline <img> viewer (covers PNG, SVG, animated GIF/WebP flows)
//   markdown  - server-rendered Markdown article view
//   download  - office formats the browser cannot render; card with download action
export const FORMATS = Object.freeze({
  '.html': { kind: 'interactive', label: 'Interactive HTML', viewer: 'sandbox', contentType: 'text/html; charset=utf-8', icon: 'circuit' },
  '.htm': { kind: 'interactive', label: 'Interactive HTML', viewer: 'sandbox', contentType: 'text/html; charset=utf-8', icon: 'circuit' },
  '.zip': { kind: 'interactive', label: 'Interactive package (ZIP)', viewer: 'sandbox', contentType: 'application/zip', icon: 'cube', magic: (data) => data.length > 3 && data[0] === 0x50 && data[1] === 0x4b },

  '.mp4': { kind: 'video', label: 'Video (MP4)', viewer: 'video', contentType: 'video/mp4', icon: 'video' },
  '.m4v': { kind: 'video', label: 'Video (M4V)', viewer: 'video', contentType: 'video/mp4', icon: 'video' },
  '.webm': { kind: 'video', label: 'Video (WebM)', viewer: 'video', contentType: 'video/webm', icon: 'video' },
  '.mov': { kind: 'video', label: 'Video (QuickTime)', viewer: 'video', contentType: 'video/quicktime', icon: 'video' },

  '.pdf': { kind: 'document', label: 'PDF document', viewer: 'pdf', contentType: 'application/pdf', icon: 'document', magic: (data) => data.length > 4 && data[0] === 0x25 && data[1] === 0x50 && data[2] === 0x44 && data[3] === 0x46 },
  '.md': { kind: 'markdown', label: 'Markdown article', viewer: 'markdown', contentType: 'text/markdown; charset=utf-8', icon: 'book' },
  '.markdown': { kind: 'markdown', label: 'Markdown article', viewer: 'markdown', contentType: 'text/markdown; charset=utf-8', icon: 'book' },
  '.txt': { kind: 'markdown', label: 'Text article', viewer: 'markdown', contentType: 'text/plain; charset=utf-8', icon: 'book' },

  '.svg': { kind: 'image', label: 'SVG diagram', viewer: 'image', contentType: 'image/svg+xml', icon: 'diagram', sanitizeSvg: true },
  '.png': { kind: 'image', label: 'PNG image', viewer: 'image', contentType: 'image/png', icon: 'image' },
  '.jpg': { kind: 'image', label: 'JPEG image', viewer: 'image', contentType: 'image/jpeg', icon: 'image' },
  '.jpeg': { kind: 'image', label: 'JPEG image', viewer: 'image', contentType: 'image/jpeg', icon: 'image' },
  '.webp': { kind: 'image', label: 'WebP image', viewer: 'image', contentType: 'image/webp', icon: 'image' },
  '.gif': { kind: 'image', label: 'Animated flow (GIF)', viewer: 'image', contentType: 'image/gif', icon: 'flow' },

  '.pptx': { kind: 'presentation', label: 'PowerPoint (PPTX)', viewer: 'download', contentType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', icon: 'presentation' },
  '.ppt': { kind: 'presentation', label: 'PowerPoint (PPT)', viewer: 'download', contentType: 'application/vnd.ms-powerpoint', icon: 'presentation' },
  '.docx': { kind: 'document', label: 'Word document (DOCX)', viewer: 'download', contentType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', icon: 'document' },
  '.doc': { kind: 'document', label: 'Word document (DOC)', viewer: 'download', contentType: 'application/msword', icon: 'document' },
  '.xlsx': { kind: 'spreadsheet', label: 'Excel workbook (XLSX)', viewer: 'download', contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', icon: 'spreadsheet' },
  '.csv': { kind: 'spreadsheet', label: 'CSV dataset', viewer: 'download', contentType: 'text/csv; charset=utf-8', icon: 'spreadsheet' }
});

export const UPLOAD_ACCEPT = Object.keys(FORMATS).join(',');

export function formatForFilename(filename = '') {
  const match = String(filename).toLowerCase().match(/\.[a-z0-9]+$/);
  if (!match) return null;
  const descriptor = FORMATS[match[0]];
  return descriptor ? { extension: match[0], ...descriptor } : null;
}

export function formatForExtension(extension = '') {
  const descriptor = FORMATS[String(extension).toLowerCase()];
  return descriptor ? { extension: String(extension).toLowerCase(), ...descriptor } : null;
}

export function mediaKindLabel(kind) {
  return ({
    interactive: 'Interactive',
    video: 'Video',
    document: 'Document',
    image: 'Visual',
    markdown: 'Article',
    presentation: 'Presentation',
    spreadsheet: 'Dataset',
    archive: 'Package'
  })[kind] || 'Resource';
}

export function supportedFormatSummary() {
  const byKind = new Map();
  for (const [extension, descriptor] of Object.entries(FORMATS)) {
    if (!byKind.has(descriptor.kind)) byKind.set(descriptor.kind, []);
    byKind.get(descriptor.kind).push(extension);
  }
  return byKind;
}

// Very small allow-list based SVG sanitizer used for uploaded SVG packages and
// AI-generated icons. It removes script blocks, event handlers, foreignObject,
// and any external references so stored SVG stays inert.
export function sanitizeSvg(input = '') {
  let svg = String(input);
  const start = svg.indexOf('<svg');
  const end = svg.lastIndexOf('</svg>');
  if (start === -1 || end === -1) throw new Error('The file does not contain a valid <svg> element');
  svg = svg.slice(start, end + 6);
  svg = svg.replace(/<script[\s\S]*?<\/script>/gi, '');
  svg = svg.replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi, '');
  svg = svg.replace(/<(iframe|embed|object|link|meta|style)[\s\S]*?(\/>|<\/\1>)/gi, '');
  svg = svg.replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, '');
  svg = svg.replace(/\son[a-z]+\s*=\s*'[^']*'/gi, '');
  svg = svg.replace(/(xlink:href|href)\s*=\s*"(?!#)[^"]*"/gi, '');
  svg = svg.replace(/(xlink:href|href)\s*=\s*'(?!#)[^']*'/gi, '');
  svg = svg.replace(/url\s*\(\s*(['"]?)(?!#)[^)]*\1\s*\)/gi, 'none');
  if (/javascript:|data:text\/html/i.test(svg)) throw new Error('The SVG contains disallowed script content');
  return svg;
}
