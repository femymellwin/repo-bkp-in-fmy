import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { parseCookies, randomId, sha256 } from './utils.mjs';

const SESSION_COOKIE = 'portal_session';

function b64url(value) {
  return Buffer.from(value).toString('base64url');
}

function sign(value, secret) {
  return createHmac('sha256', secret).update(value).digest('base64url');
}

function safeEqual(leftValue, rightValue) {
  const left = Buffer.from(String(leftValue || ''));
  const right = Buffer.from(String(rightValue || ''));
  return left.length === right.length && timingSafeEqual(left, right);
}

export function createSignedToken(payload, secret) {
  const encoded = b64url(JSON.stringify(payload));
  return `${encoded}.${sign(encoded, secret)}`;
}

export function verifySignedToken(token, secret) {
  if (!token || !secret) return null;
  const [encoded, signature] = String(token).split('.');
  if (!encoded || !signature || !safeEqual(signature, sign(encoded, secret))) return null;
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

export function createPasswordHash(password) {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('base64url')}$${hash.toString('base64url')}`;
}

export function verifyPassword(password, storedHash, plainFallback = '') {
  if (storedHash && storedHash.startsWith('scrypt$')) {
    const [, saltText, hashText] = storedHash.split('$');
    if (!saltText || !hashText) return false;
    const salt = Buffer.from(saltText, 'base64url');
    const expected = Buffer.from(hashText, 'base64url');
    const actual = scryptSync(password, salt, expected.length);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  }
  if (!plainFallback) return false;
  return safeEqual(sha256(plainFallback), sha256(password));
}

export function createSession(user, secret, maxAgeSeconds = 8 * 60 * 60) {
  const identity = typeof user === 'string'
    ? { id: user, email: user, name: user, role: 'admin', subscription_status: 'free' }
    : user;
  const payload = {
    userId: identity.id,
    email: identity.email,
    name: identity.name || identity.email,
    role: identity.role || 'member',
    subscriptionStatus: identity.subscription_status || 'free',
    exp: Math.floor(Date.now() / 1000) + maxAgeSeconds,
    csrf: randomId(24),
    nonce: randomId(16)
  };
  return createSignedToken(payload, secret);
}

export function verifySessionToken(token, secret) {
  const payload = verifySignedToken(token, secret);
  if (!payload || !payload.exp || !payload.email || !payload.csrf) return null;
  return payload;
}

export function getPortalSession(req, secret) {
  const cookies = parseCookies(req.headers.cookie || '');
  return verifySessionToken(cookies[SESSION_COOKIE], secret);
}

// Backward-compatible export name used by earlier code and external tests.
export const getAdminSession = getPortalSession;

export function sessionCookieName() {
  return SESSION_COOKIE;
}

export function validateCsrf(req, session, token) {
  if (!session || !token) return false;
  const origin = req.headers.origin;
  const host = req.headers.host;
  if (origin && host) {
    try {
      if (new URL(origin).host !== host) return false;
    } catch {
      return false;
    }
  }
  return safeEqual(token, session.csrf);
}

export class SlidingWindowRateLimiter {
  constructor({ limit, windowMs }) {
    this.limit = limit;
    this.windowMs = windowMs;
    this.entries = new Map();
  }

  consume(key) {
    const now = Date.now();
    const existing = this.entries.get(key) || [];
    const fresh = existing.filter((timestamp) => now - timestamp < this.windowMs);
    if (fresh.length >= this.limit) {
      this.entries.set(key, fresh);
      return false;
    }
    fresh.push(now);
    this.entries.set(key, fresh);
    if (this.entries.size > 10000) this.prune(now);
    return true;
  }

  prune(now = Date.now()) {
    for (const [key, values] of this.entries.entries()) {
      if (!values.some((timestamp) => now - timestamp < this.windowMs)) this.entries.delete(key);
    }
  }
}
