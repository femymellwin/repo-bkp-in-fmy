import { readRequestBody } from './utils.mjs';

function parseHeaders(buffer) {
  const headers = {};
  for (const line of buffer.toString('utf8').split('\r\n')) {
    const index = line.indexOf(':');
    if (index < 0) continue;
    headers[line.slice(0, index).trim().toLowerCase()] = line.slice(index + 1).trim();
  }
  return headers;
}

function dispositionParameter(disposition, name) {
  const expression = new RegExp(`${name}="([^"]*)"`, 'i');
  const match = disposition.match(expression);
  return match ? match[1] : null;
}

export async function parseMultipartRequest(req, maxBytes) {
  const contentType = req.headers['content-type'] || '';
  const boundaryMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!boundaryMatch) {
    const error = new Error('Missing multipart boundary');
    error.statusCode = 400;
    throw error;
  }
  const boundary = boundaryMatch[1] || boundaryMatch[2];
  const body = await readRequestBody(req, maxBytes);
  const delimiter = Buffer.from(`--${boundary}`);
  const nextDelimiter = Buffer.from(`\r\n--${boundary}`);
  const fields = {};
  const files = {};

  let cursor = body.indexOf(delimiter);
  if (cursor < 0) {
    const error = new Error('Invalid multipart body');
    error.statusCode = 400;
    throw error;
  }

  while (cursor >= 0) {
    cursor += delimiter.length;
    if (body.subarray(cursor, cursor + 2).toString() === '--') break;
    if (body.subarray(cursor, cursor + 2).toString() === '\r\n') cursor += 2;

    const headerEnd = body.indexOf(Buffer.from('\r\n\r\n'), cursor);
    if (headerEnd < 0) break;
    const headers = parseHeaders(body.subarray(cursor, headerEnd));
    const dataStart = headerEnd + 4;
    const dataEnd = body.indexOf(nextDelimiter, dataStart);
    if (dataEnd < 0) break;

    const disposition = headers['content-disposition'] || '';
    const name = dispositionParameter(disposition, 'name');
    const filename = dispositionParameter(disposition, 'filename');
    const data = body.subarray(dataStart, dataEnd);

    if (name && filename !== null) {
      files[name] = {
        filename,
        contentType: headers['content-type'] || 'application/octet-stream',
        data: Buffer.from(data)
      };
    } else if (name) {
      fields[name] = data.toString('utf8');
    }

    cursor = dataEnd + 2;
  }

  return { fields, files };
}
