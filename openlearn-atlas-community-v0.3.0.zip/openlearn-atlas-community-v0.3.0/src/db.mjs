import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { nowIso } from './utils.mjs';

const USER_ROLES = new Set(['super_admin', 'admin', 'publisher', 'moderator', 'member']);
const USER_STATUSES = new Set(['active', 'disabled']);
const SUBSCRIPTION_STATUSES = new Set(['free', 'premium']);
const ACCESS_LEVELS = new Set(['public', 'login', 'premium']);
const COMMENT_TYPES = new Set(['general', 'error', 'suggestion', 'question']);
const COMMENT_STATUSES = new Set(['open', 'resolved', 'hidden']);

function parseJson(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function contentRow(row) {
  if (!row) return null;
  return {
    ...row,
    featured: Boolean(row.featured),
    verification_enabled: Boolean(row.verification_enabled),
    tags: parseJson(row.tags_json, []),
    tags_json: undefined
  };
}

function versionRow(row) {
  if (!row) return null;
  return {
    ...row,
    metadata: parseJson(row.metadata_snapshot_json, {}),
    metadata_snapshot_json: undefined
  };
}

function commentRow(row) {
  if (!row) return null;
  return {
    ...row,
    is_staff: ['super_admin', 'admin', 'publisher', 'moderator'].includes(row.author_role)
  };
}

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase().slice(0, 320);
}

function metadataSnapshot(content) {
  return {
    title: content.title,
    summary: content.summary,
    description: content.description,
    category: content.category,
    contentType: content.content_type,
    tags: content.tags || [],
    icon: content.icon,
    accessLevel: content.access_level,
    verificationEnabled: Boolean(content.verification_enabled)
  };
}

export class PortalDatabase {
  constructor(databasePath) {
    this.databasePath = databasePath;
    fs.mkdirSync(path.dirname(databasePath), { recursive: true });
    this.db = new DatabaseSync(databasePath);
    this.db.exec('PRAGMA journal_mode=WAL;');
    this.db.exec('PRAGMA synchronous=NORMAL;');
    this.db.exec('PRAGMA foreign_keys=ON;');
    this.db.exec('PRAGMA busy_timeout=5000;');
    this.migrate();
  }

  migrate() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        applied_at TEXT NOT NULL
      );
    `);
    const current = this.db.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations').get().version;

    if (current < 1) {
      this.db.exec('BEGIN IMMEDIATE;');
      try {
        this.db.exec(`
          CREATE TABLE contents (
            id TEXT PRIMARY KEY,
            slug TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            content_type TEXT NOT NULL,
            tags_json TEXT NOT NULL DEFAULT '[]',
            icon TEXT NOT NULL DEFAULT '&#9672;',
            version TEXT NOT NULL DEFAULT '1.0',
            status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft', 'published', 'archived')),
            featured INTEGER NOT NULL DEFAULT 0,
            package_key TEXT NOT NULL,
            package_filename TEXT NOT NULL,
            package_size INTEGER NOT NULL DEFAULT 0,
            preview_entry TEXT NOT NULL,
            thumbnail_key TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
          );

          CREATE TABLE events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            content_id TEXT,
            visitor_hash TEXT NOT NULL,
            session_hash TEXT,
            referrer TEXT,
            user_agent TEXT,
            metadata_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL,
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE SET NULL
          );

          CREATE TABLE likes (
            content_id TEXT NOT NULL,
            visitor_hash TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(content_id, visitor_hash),
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE
          );

          CREATE TABLE content_revisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content_id TEXT NOT NULL,
            snapshot_json TEXT NOT NULL,
            changed_by TEXT NOT NULL,
            reason TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE
          );

          CREATE TABLE audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT,
            metadata_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL
          );

          CREATE INDEX idx_contents_status_updated ON contents(status, updated_at DESC);
          CREATE INDEX idx_contents_category ON contents(category);
          CREATE INDEX idx_events_type_created ON events(event_type, created_at DESC);
          CREATE INDEX idx_events_content_created ON events(content_id, created_at DESC);
          CREATE INDEX idx_events_visitor_created ON events(visitor_hash, created_at DESC);
          CREATE INDEX idx_likes_content_active ON likes(content_id, active);
        `);
        this.db.prepare('INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)').run(1, nowIso());
        this.db.exec('COMMIT;');
      } catch (error) {
        this.db.exec('ROLLBACK;');
        throw error;
      }
    }

    const afterV1 = this.db.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations').get().version;
    if (afterV1 < 2) {
      this.db.exec('BEGIN IMMEDIATE;');
      try {
        this.db.exec(`
          ALTER TABLE contents ADD COLUMN access_level TEXT NOT NULL DEFAULT 'public';
          ALTER TABLE contents ADD COLUMN verification_enabled INTEGER NOT NULL DEFAULT 1;
          ALTER TABLE contents ADD COLUMN current_version_id TEXT;

          CREATE TABLE users (
            id TEXT PRIMARY KEY,
            email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            name TEXT NOT NULL,
            password_hash TEXT,
            role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('super_admin', 'admin', 'publisher', 'moderator', 'member')),
            status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'disabled')),
            subscription_status TEXT NOT NULL DEFAULT 'free' CHECK(subscription_status IN ('free', 'premium')),
            provider TEXT NOT NULL DEFAULT 'local',
            provider_subject TEXT,
            avatar_url TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_login_at TEXT,
            UNIQUE(provider, provider_subject)
          );

          CREATE TABLE content_versions (
            id TEXT PRIMARY KEY,
            content_id TEXT NOT NULL,
            version_label TEXT NOT NULL,
            version_number INTEGER NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('draft', 'published', 'archived')),
            package_key TEXT NOT NULL,
            package_filename TEXT NOT NULL,
            package_size INTEGER NOT NULL DEFAULT 0,
            preview_entry TEXT NOT NULL,
            thumbnail_key TEXT,
            change_notes TEXT NOT NULL DEFAULT '',
            metadata_snapshot_json TEXT NOT NULL DEFAULT '{}',
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL,
            published_at TEXT,
            archived_at TEXT,
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE,
            UNIQUE(content_id, version_number),
            UNIQUE(content_id, version_label)
          );

          CREATE TABLE install_votes (
            content_id TEXT NOT NULL,
            version_id TEXT NOT NULL,
            voter_key TEXT NOT NULL,
            user_id TEXT,
            visitor_hash TEXT,
            vote TEXT NOT NULL CHECK(vote IN ('able', 'unable')),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(content_id, version_id, voter_key),
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE,
            FOREIGN KEY(version_id) REFERENCES content_versions(id) ON DELETE CASCADE,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
          );

          CREATE TABLE comments (
            id TEXT PRIMARY KEY,
            content_id TEXT NOT NULL,
            version_id TEXT,
            parent_id TEXT,
            user_id TEXT,
            author_name TEXT NOT NULL,
            comment_type TEXT NOT NULL DEFAULT 'general' CHECK(comment_type IN ('general', 'error', 'suggestion', 'question')),
            body TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open', 'resolved', 'hidden')),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            resolved_by TEXT,
            resolved_at TEXT,
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE,
            FOREIGN KEY(version_id) REFERENCES content_versions(id) ON DELETE SET NULL,
            FOREIGN KEY(parent_id) REFERENCES comments(id) ON DELETE CASCADE,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
          );

          CREATE TABLE favorites (
            user_id TEXT NOT NULL,
            content_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY(user_id, content_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE
          );

          CREATE TABLE follows (
            user_id TEXT NOT NULL,
            content_id TEXT NOT NULL,
            followed_version_id TEXT,
            last_seen_version_id TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(user_id, content_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(content_id) REFERENCES contents(id) ON DELETE CASCADE,
            FOREIGN KEY(followed_version_id) REFERENCES content_versions(id) ON DELETE SET NULL,
            FOREIGN KEY(last_seen_version_id) REFERENCES content_versions(id) ON DELETE SET NULL
          );

          CREATE TABLE portal_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_by TEXT NOT NULL,
            updated_at TEXT NOT NULL
          );

          CREATE INDEX idx_users_role_status ON users(role, status);
          CREATE INDEX idx_versions_content_status ON content_versions(content_id, status, version_number DESC);
          CREATE INDEX idx_votes_content_version ON install_votes(content_id, version_id, vote);
          CREATE INDEX idx_comments_content_created ON comments(content_id, created_at);
          CREATE INDEX idx_comments_status_created ON comments(status, created_at DESC);
          CREATE INDEX idx_comments_parent ON comments(parent_id);
          CREATE INDEX idx_favorites_user ON favorites(user_id, created_at DESC);
          CREATE INDEX idx_follows_user ON follows(user_id, updated_at DESC);

          INSERT INTO content_versions (
            id, content_id, version_label, version_number, status, package_key, package_filename,
            package_size, preview_entry, thumbnail_key, change_notes, metadata_snapshot_json,
            created_by, created_at, published_at, archived_at
          )
          SELECT
            'legacy-' || id, id, version, 1, status, package_key, package_filename,
            package_size, preview_entry, thumbnail_key, 'Imported during the v0.2 schema upgrade', '{}',
            'schema-migration', created_at,
            CASE WHEN status = 'published' THEN updated_at ELSE NULL END,
            CASE WHEN status = 'archived' THEN updated_at ELSE NULL END
          FROM contents;

          UPDATE contents SET current_version_id = 'legacy-' || id WHERE current_version_id IS NULL;
        `);
        this.db.prepare('INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)').run(2, nowIso());
        this.db.exec('COMMIT;');
      } catch (error) {
        this.db.exec('ROLLBACK;');
        throw error;
      }
    }

    const afterV2 = this.db.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations').get().version;
    if (afterV2 < 3) {
      this.db.exec('BEGIN IMMEDIATE;');
      try {
        this.db.exec(`
          ALTER TABLE contents ADD COLUMN media_kind TEXT NOT NULL DEFAULT 'interactive';
          ALTER TABLE content_versions ADD COLUMN media_kind TEXT NOT NULL DEFAULT 'interactive';

          CREATE TABLE custom_icons (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            svg TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'uploaded' CHECK(source IN ('uploaded', 'ai')),
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL
          );

          CREATE INDEX idx_custom_icons_created ON custom_icons(created_at DESC);
          CREATE INDEX idx_contents_media_kind ON contents(media_kind);
        `);
        this.db.prepare('INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)').run(3, nowIso());
        this.db.exec('COMMIT;');
      } catch (error) {
        this.db.exec('ROLLBACK;');
        throw error;
      }
    }
  }

  // ---- Generic JSON settings (AI providers, integrations) ----

  getJsonSetting(key, fallback = null) {
    const row = this.db.prepare('SELECT value FROM portal_settings WHERE key = ?').get(key);
    if (!row) return fallback;
    return parseJson(row.value, fallback);
  }

  setJsonSetting(key, value, actor = 'system') {
    this.db.prepare(`
      INSERT INTO portal_settings(key, value, updated_by, updated_at)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_by = excluded.updated_by, updated_at = excluded.updated_at
    `).run(key, JSON.stringify(value ?? null), actor, nowIso());
    this.recordAudit(actor, 'settings.update', 'portal', key, {}, false);
  }

  // ---- Custom icon library ----

  listCustomIcons() {
    return this.db.prepare('SELECT * FROM custom_icons ORDER BY created_at DESC').all();
  }

  getCustomIcon(id) {
    return this.db.prepare('SELECT * FROM custom_icons WHERE id = ?').get(id) || null;
  }

  createCustomIcon({ id, name, svg, source }, actor) {
    this.db.prepare(`
      INSERT INTO custom_icons(id, name, svg, source, created_by, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, String(name).slice(0, 80), svg, source === 'ai' ? 'ai' : 'uploaded', actor, nowIso());
    this.recordAudit(actor, 'icon.create', 'custom_icon', id, { name, source }, false);
    return this.getCustomIcon(id);
  }

  deleteCustomIcon(id, actor) {
    const icon = this.getCustomIcon(id);
    if (!icon) return false;
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.db.prepare("UPDATE contents SET icon = 'cube' WHERE icon = ?").run(`custom:${id}`);
      this.db.prepare('DELETE FROM custom_icons WHERE id = ?').run(id);
      this.recordAudit(actor, 'icon.delete', 'custom_icon', id, { name: icon.name }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return true;
  }

  close() {
    this.db.close();
  }

  health() {
    return this.db.prepare('SELECT 1 AS ok').get().ok === 1;
  }

  countContents() {
    return this.db.prepare('SELECT COUNT(*) AS count FROM contents').get().count;
  }

  countUsers() {
    return this.db.prepare("SELECT COUNT(*) AS count FROM users WHERE status = 'active'").get().count;
  }

  ensureBootstrapAdmin({ email, name, passwordHash }) {
    const normalized = normalizeEmail(email);
    const existing = this.getUserByEmail(normalized);
    if (existing) return existing;
    return this.createUser({
      id: randomUUID(),
      email: normalized,
      name: String(name || 'Portal Owner').slice(0, 120),
      passwordHash,
      role: 'super_admin',
      status: 'active',
      subscriptionStatus: 'premium',
      provider: 'local'
    }, 'system-bootstrap');
  }

  getUserByEmail(email) {
    return this.db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').get(normalizeEmail(email)) || null;
  }

  getUserById(id) {
    return this.db.prepare('SELECT * FROM users WHERE id = ?').get(id) || null;
  }

  createUser(user, actor = 'self-registration') {
    const role = USER_ROLES.has(user.role) ? user.role : 'member';
    const status = USER_STATUSES.has(user.status) ? user.status : 'active';
    const subscriptionStatus = SUBSCRIPTION_STATUSES.has(user.subscriptionStatus) ? user.subscriptionStatus : 'free';
    const timestamp = nowIso();
    const id = user.id || randomUUID();
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.db.prepare(`
        INSERT INTO users (
          id, email, name, password_hash, role, status, subscription_status,
          provider, provider_subject, avatar_url, created_at, updated_at, last_login_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        id,
        normalizeEmail(user.email),
        String(user.name || user.email || 'Member').trim().slice(0, 120),
        user.passwordHash || null,
        role,
        status,
        subscriptionStatus,
        String(user.provider || 'local').slice(0, 30),
        user.providerSubject || null,
        user.avatarUrl || null,
        timestamp,
        timestamp,
        null
      );
      this.recordAudit(actor, 'user.create', 'user', id, { email: normalizeEmail(user.email), role }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      if (String(error.message).includes('UNIQUE constraint failed: users.email')) throw new Error('An account already exists for this email address');
      throw error;
    }
    return this.getUserById(id);
  }

  upsertGoogleUser(profile) {
    const email = normalizeEmail(profile.email);
    const timestamp = nowIso();
    let user = this.db.prepare("SELECT * FROM users WHERE provider = 'google' AND provider_subject = ?").get(profile.subject);
    if (!user) user = this.getUserByEmail(email);
    if (user) {
      this.db.prepare(`
        UPDATE users SET name = ?, avatar_url = ?, provider = 'google', provider_subject = ?, updated_at = ?
        WHERE id = ?
      `).run(String(profile.name || email).slice(0, 120), String(profile.picture || '').slice(0, 1000) || null, profile.subject, timestamp, user.id);
      return this.getUserById(user.id);
    }
    return this.createUser({
      email,
      name: profile.name,
      role: 'member',
      status: 'active',
      subscriptionStatus: 'free',
      provider: 'google',
      providerSubject: profile.subject,
      avatarUrl: profile.picture
    }, 'google-oauth');
  }

  touchUserLogin(id) {
    const timestamp = nowIso();
    this.db.prepare('UPDATE users SET last_login_at = ?, updated_at = ? WHERE id = ?').run(timestamp, timestamp, id);
    return this.getUserById(id);
  }

  listUsers() {
    return this.db.prepare(`
      SELECT u.*,
        (SELECT COUNT(*) FROM favorites f WHERE f.user_id = u.id) AS favorite_count,
        (SELECT COUNT(*) FROM follows fo WHERE fo.user_id = u.id) AS follow_count,
        (SELECT COUNT(*) FROM comments c WHERE c.user_id = u.id) AS comment_count
      FROM users u ORDER BY
        CASE u.role WHEN 'super_admin' THEN 1 WHEN 'admin' THEN 2 WHEN 'publisher' THEN 3 WHEN 'moderator' THEN 4 ELSE 5 END,
        u.created_at DESC
    `).all();
  }

  updateUserAdministration(id, changes, actor) {
    const user = this.getUserById(id);
    if (!user) return null;
    const role = USER_ROLES.has(changes.role) ? changes.role : user.role;
    const status = USER_STATUSES.has(changes.status) ? changes.status : user.status;
    const subscriptionStatus = SUBSCRIPTION_STATUSES.has(changes.subscriptionStatus) ? changes.subscriptionStatus : user.subscription_status;
    if (user.role === 'super_admin' && user.status === 'active' && (status === 'disabled' || role !== 'super_admin')) {
      const activeSuperAdmins = this.db.prepare("SELECT COUNT(*) AS count FROM users WHERE role = 'super_admin' AND status = 'active'").get().count;
      if (activeSuperAdmins <= 1) throw new Error('The last active super administrator cannot be disabled or assigned another role');
    }
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.db.prepare('UPDATE users SET role = ?, status = ?, subscription_status = ?, updated_at = ? WHERE id = ?')
        .run(role, status, subscriptionStatus, nowIso(), id);
      this.recordAudit(actor, 'user.update', 'user', id, { role, status, subscriptionStatus }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getUserById(id);
  }

  ensureBrandingDefaults(defaults) {
    const entries = {
      portal_name: defaults.portalName,
      portal_tagline: defaults.portalTagline,
      organization_name: defaults.organizationName,
      product_tagline: defaults.productTagline,
      logo_key: ''
    };
    const statement = this.db.prepare(`
      INSERT INTO portal_settings(key, value, updated_by, updated_at)
      VALUES (?, ?, 'system-default', ?)
      ON CONFLICT(key) DO NOTHING
    `);
    const timestamp = nowIso();
    for (const [key, value] of Object.entries(entries)) statement.run(key, String(value || ''), timestamp);
  }

  getBranding(defaults = {}) {
    const rows = this.db.prepare('SELECT key, value FROM portal_settings').all();
    const values = Object.fromEntries(rows.map((row) => [row.key, row.value]));
    return {
      portalName: values.portal_name || defaults.portalName || 'OpenLearn Atlas',
      portalTagline: values.portal_tagline || defaults.portalTagline || '',
      organizationName: values.organization_name || defaults.organizationName || '',
      productTagline: values.product_tagline || defaults.productTagline || '',
      logoKey: values.logo_key || ''
    };
  }

  updateBranding(changes, actor) {
    const mapping = {
      portalName: 'portal_name',
      portalTagline: 'portal_tagline',
      organizationName: 'organization_name',
      productTagline: 'product_tagline',
      logoKey: 'logo_key'
    };
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      const statement = this.db.prepare(`
        INSERT INTO portal_settings(key, value, updated_by, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_by = excluded.updated_by, updated_at = excluded.updated_at
      `);
      const fields = [];
      for (const [property, key] of Object.entries(mapping)) {
        if (changes[property] === undefined) continue;
        const limit = property === 'logoKey' ? 500 : property === 'portalName' || property === 'organizationName' ? 120 : 300;
        statement.run(key, String(changes[property] || '').trim().slice(0, limit), actor, nowIso());
        fields.push(property);
      }
      this.recordAudit(actor, 'branding.update', 'portal', 'branding', { fields }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getBranding();
  }

  slugExists(slug) {
    return Boolean(this.db.prepare('SELECT 1 AS found FROM contents WHERE slug = ?').get(slug));
  }

  createContent(item, actor = 'system') {
    const timestamp = nowIso();
    const versionId = item.versionId || randomUUID();
    const status = ['draft', 'published', 'archived'].includes(item.status) ? item.status : 'draft';
    const accessLevel = ACCESS_LEVELS.has(item.accessLevel) ? item.accessLevel : 'public';
    const snapshot = {
      title: item.title,
      summary: item.summary,
      description: item.description,
      category: item.category,
      contentType: item.contentType,
      tags: item.tags || [],
      icon: item.icon || 'cube',
      accessLevel,
      verificationEnabled: item.verificationEnabled !== false
    };
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.db.prepare(`
        INSERT INTO contents (
          id, slug, title, summary, description, category, content_type, tags_json,
          icon, version, status, featured, package_key, package_filename, package_size,
          preview_entry, thumbnail_key, created_at, updated_at, access_level,
          verification_enabled, current_version_id, media_kind
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        item.id,
        item.slug,
        item.title,
        item.summary,
        item.description,
        item.category,
        item.contentType,
        JSON.stringify(item.tags || []),
        item.icon || 'cube',
        item.version || '1.0',
        status,
        item.featured ? 1 : 0,
        item.packageKey,
        item.packageFilename,
        item.packageSize || 0,
        item.previewEntry,
        item.thumbnailKey || null,
        timestamp,
        timestamp,
        accessLevel,
        item.verificationEnabled === false ? 0 : 1,
        versionId,
        item.mediaKind || 'interactive'
      );
      this.db.prepare(`
        INSERT INTO content_versions (
          id, content_id, version_label, version_number, status, package_key, package_filename,
          package_size, preview_entry, thumbnail_key, change_notes, metadata_snapshot_json,
          created_by, created_at, published_at, archived_at, media_kind
        ) VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        versionId,
        item.id,
        item.version || '1.0',
        status,
        item.packageKey,
        item.packageFilename,
        item.packageSize || 0,
        item.previewEntry,
        item.thumbnailKey || null,
        item.changeNotes || 'Initial release',
        JSON.stringify(snapshot),
        actor,
        timestamp,
        status === 'published' ? timestamp : null,
        status === 'archived' ? timestamp : null,
        item.mediaKind || 'interactive'
      );
      this.recordAudit(actor, 'content.create', 'content', item.id, { title: item.title, status, versionId }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getContentById(item.id);
  }

  listPublished({ q = '', category = '', contentType = '', accessLevel = '' } = {}) {
    const where = ["status = 'published'"];
    const params = [];
    if (q) {
      where.push('(title LIKE ? OR summary LIKE ? OR description LIKE ? OR tags_json LIKE ?)');
      const term = `%${q}%`;
      params.push(term, term, term, term);
    }
    if (category) {
      where.push('category = ?');
      params.push(category);
    }
    if (contentType) {
      where.push('content_type = ?');
      params.push(contentType);
    }
    if (ACCESS_LEVELS.has(accessLevel)) {
      where.push('access_level = ?');
      params.push(accessLevel);
    }
    return this.db.prepare(`
      SELECT * FROM contents
      WHERE ${where.join(' AND ')}
      ORDER BY featured DESC, updated_at DESC
    `).all(...params).map(contentRow);
  }

  listAdminContents() {
    return this.db.prepare(`
      SELECT c.*,
        (SELECT COUNT(*) FROM comments cm WHERE cm.content_id = c.id AND cm.parent_id IS NULL AND cm.status = 'open') AS open_comment_count,
        (SELECT COUNT(*) FROM content_versions cv WHERE cv.content_id = c.id) AS revision_count
      FROM contents c ORDER BY c.updated_at DESC
    `).all().map(contentRow);
  }

  getContentBySlug(slug, includeUnpublished = false) {
    const sql = includeUnpublished
      ? 'SELECT * FROM contents WHERE slug = ?'
      : "SELECT * FROM contents WHERE slug = ? AND status = 'published'";
    return contentRow(this.db.prepare(sql).get(slug));
  }

  getContentById(id, includeUnpublished = true) {
    const sql = includeUnpublished
      ? 'SELECT * FROM contents WHERE id = ?'
      : "SELECT * FROM contents WHERE id = ? AND status = 'published'";
    return contentRow(this.db.prepare(sql).get(id));
  }

  categories() {
    return this.db.prepare("SELECT category, COUNT(*) AS count FROM contents WHERE status = 'published' GROUP BY category ORDER BY category").all();
  }

  contentTypes() {
    return this.db.prepare("SELECT content_type, COUNT(*) AS count FROM contents WHERE status = 'published' GROUP BY content_type ORDER BY content_type").all();
  }

  saveRevision(content, actor, reason) {
    this.db.prepare(`
      INSERT INTO content_revisions(content_id, snapshot_json, changed_by, reason, created_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(content.id, JSON.stringify(content), actor, reason, nowIso());
  }

  listMetadataRevisions(contentId) {
    return this.db.prepare(`
      SELECT id, content_id, snapshot_json, changed_by, reason, created_at
      FROM content_revisions WHERE content_id = ? ORDER BY id DESC LIMIT 100
    `).all(contentId).map((row) => ({ ...row, snapshot: parseJson(row.snapshot_json, {}), snapshot_json: undefined }));
  }

  setContentStatus(id, status, actor) {
    if (!['draft', 'published', 'archived'].includes(status)) throw new Error('Invalid status');
    const content = this.getContentById(id);
    if (!content) return null;
    if (status === 'published' && content.current_version_id) {
      return this.publishContentVersion(id, content.current_version_id, actor);
    }
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.saveRevision(content, actor, `status:${status}`);
      this.db.prepare('UPDATE contents SET status = ?, updated_at = ? WHERE id = ?').run(status, nowIso(), id);
      if (content.current_version_id) {
        this.db.prepare(`
          UPDATE content_versions SET status = ?, archived_at = CASE WHEN ? = 'archived' THEN ? ELSE archived_at END
          WHERE id = ?
        `).run(status, status, nowIso(), content.current_version_id);
      }
      this.recordAudit(actor, 'content.status', 'content', id, { from: content.status, to: status }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getContentById(id);
  }

  toggleFeatured(id, actor) {
    const content = this.getContentById(id);
    if (!content) return null;
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.saveRevision(content, actor, 'toggle-featured');
      const featured = content.featured ? 0 : 1;
      this.db.prepare('UPDATE contents SET featured = ?, updated_at = ? WHERE id = ?').run(featured, nowIso(), id);
      this.recordAudit(actor, 'content.featured', 'content', id, { featured: Boolean(featured) }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getContentById(id);
  }

  updateContentMetadata(id, changes, actor) {
    const content = this.getContentById(id);
    if (!content) return null;
    const next = {
      title: String(changes.title || content.title).slice(0, 180),
      summary: String(changes.summary ?? content.summary).slice(0, 500),
      description: String(changes.description ?? content.description).slice(0, 10000),
      category: String(changes.category || content.category).slice(0, 100),
      contentType: String(changes.contentType || content.content_type).slice(0, 80),
      tags: Array.isArray(changes.tags) ? changes.tags.slice(0, 30) : content.tags,
      icon: String(changes.icon || content.icon).slice(0, 80),
      accessLevel: ACCESS_LEVELS.has(changes.accessLevel) ? changes.accessLevel : content.access_level,
      verificationEnabled: changes.verificationEnabled === undefined ? content.verification_enabled : Boolean(changes.verificationEnabled)
    };
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.saveRevision(content, actor, 'metadata-update');
      this.db.prepare(`
        UPDATE contents SET title = ?, summary = ?, description = ?, category = ?, content_type = ?,
          tags_json = ?, icon = ?, access_level = ?, verification_enabled = ?, updated_at = ? WHERE id = ?
      `).run(
        next.title,
        next.summary,
        next.description,
        next.category,
        next.contentType,
        JSON.stringify(next.tags),
        next.icon,
        next.accessLevel,
        next.verificationEnabled ? 1 : 0,
        nowIso(),
        id
      );
      this.recordAudit(actor, 'content.update', 'content', id, { fields: Object.keys(changes) }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getContentById(id);
  }

  versionLabelExists(contentId, versionLabel) {
    return Boolean(this.db.prepare('SELECT 1 AS found FROM content_versions WHERE content_id = ? AND version_label = ?').get(contentId, versionLabel));
  }

  getContentVersion(versionId) {
    return versionRow(this.db.prepare('SELECT * FROM content_versions WHERE id = ?').get(versionId));
  }

  listContentVersions(contentId) {
    return this.db.prepare(`
      SELECT cv.*,
        SUM(CASE WHEN iv.vote = 'able' THEN 1 ELSE 0 END) AS able_votes,
        SUM(CASE WHEN iv.vote = 'unable' THEN 1 ELSE 0 END) AS unable_votes,
        (SELECT COUNT(*) FROM comments c WHERE c.version_id = cv.id AND c.parent_id IS NULL) AS comment_count
      FROM content_versions cv
      LEFT JOIN install_votes iv ON iv.version_id = cv.id
      WHERE cv.content_id = ?
      GROUP BY cv.id
      ORDER BY cv.version_number DESC
    `).all(contentId).map(versionRow);
  }

  createContentVersion(contentId, item, actor, publish = false) {
    const content = this.getContentById(contentId);
    if (!content) return null;
    const versionLabel = String(item.versionLabel || '').trim().slice(0, 30);
    if (!versionLabel) throw new Error('Revision version is required');
    if (this.versionLabelExists(contentId, versionLabel)) throw new Error(`Revision ${versionLabel} already exists`);
    const versionId = item.id || randomUUID();
    const timestamp = nowIso();
    const nextNumber = this.db.prepare('SELECT COALESCE(MAX(version_number), 0) + 1 AS value FROM content_versions WHERE content_id = ?').get(contentId).value;
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.saveRevision(content, actor, `package-revision:${versionLabel}`);
      this.db.prepare(`
        INSERT INTO content_versions (
          id, content_id, version_label, version_number, status, package_key, package_filename,
          package_size, preview_entry, thumbnail_key, change_notes, metadata_snapshot_json,
          created_by, created_at, published_at, archived_at, media_kind
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        versionId,
        contentId,
        versionLabel,
        nextNumber,
        publish ? 'published' : 'draft',
        item.packageKey,
        item.packageFilename,
        item.packageSize || 0,
        item.previewEntry,
        item.thumbnailKey || content.thumbnail_key || null,
        String(item.changeNotes || '').slice(0, 3000),
        JSON.stringify(metadataSnapshot(content)),
        actor,
        timestamp,
        publish ? timestamp : null,
        null,
        item.mediaKind || content.media_kind || 'interactive'
      );
      if (publish) this.publishVersionInsideTransaction(content, versionId, actor, timestamp);
      this.recordAudit(actor, 'content.version.create', 'content_version', versionId, { contentId, versionLabel, publish }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getContentVersion(versionId);
  }

  publishVersionInsideTransaction(content, versionId, actor, timestamp = nowIso()) {
    const version = this.db.prepare('SELECT * FROM content_versions WHERE id = ? AND content_id = ?').get(versionId, content.id);
    if (!version) throw new Error('Revision not found');
    this.db.prepare(`
      UPDATE content_versions
      SET status = 'archived', archived_at = COALESCE(archived_at, ?)
      WHERE content_id = ? AND id <> ? AND status <> 'archived'
    `).run(timestamp, content.id, versionId);
    this.db.prepare(`
      UPDATE content_versions SET status = 'published', published_at = COALESCE(published_at, ?), archived_at = NULL
      WHERE id = ?
    `).run(timestamp, versionId);
    this.db.prepare(`
      UPDATE contents SET version = ?, status = 'published', package_key = ?, package_filename = ?,
        package_size = ?, preview_entry = ?, thumbnail_key = ?, current_version_id = ?, updated_at = ?,
        media_kind = ?
      WHERE id = ?
    `).run(
      version.version_label,
      version.package_key,
      version.package_filename,
      version.package_size,
      version.preview_entry,
      version.thumbnail_key,
      versionId,
      timestamp,
      version.media_kind || 'interactive',
      content.id
    );
    this.recordAudit(actor, 'content.version.publish', 'content_version', versionId, { contentId: content.id, version: version.version_label }, false);
  }

  publishContentVersion(contentId, versionId, actor) {
    const content = this.getContentById(contentId);
    if (!content) return null;
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.saveRevision(content, actor, `publish-version:${versionId}`);
      this.publishVersionInsideTransaction(content, versionId, actor);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getContentById(contentId);
  }

  recordEvent(event) {
    const metadata = JSON.stringify(event.metadata || {}).slice(0, 10000);
    this.db.prepare(`
      INSERT INTO events(event_type, content_id, visitor_hash, session_hash, referrer, user_agent, metadata_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      event.eventType,
      event.contentId || null,
      event.visitorHash,
      event.sessionHash || null,
      String(event.referrer || '').slice(0, 1000),
      String(event.userAgent || '').slice(0, 1000),
      metadata,
      nowIso()
    );
  }

  toggleLike(contentId, visitorHash) {
    const content = this.getContentById(contentId, false);
    if (!content) return null;
    const existing = this.db.prepare('SELECT active FROM likes WHERE content_id = ? AND visitor_hash = ?').get(contentId, visitorHash);
    const active = existing ? !Boolean(existing.active) : true;
    this.db.prepare(`
      INSERT INTO likes(content_id, visitor_hash, active, updated_at)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(content_id, visitor_hash) DO UPDATE SET active = excluded.active, updated_at = excluded.updated_at
    `).run(contentId, visitorHash, active ? 1 : 0, nowIso());
    return { active, count: this.likeCount(contentId) };
  }

  likeCount(contentId) {
    return this.db.prepare('SELECT COUNT(*) AS count FROM likes WHERE content_id = ? AND active = 1').get(contentId).count;
  }

  isLiked(contentId, visitorHash) {
    return Boolean(this.db.prepare('SELECT active FROM likes WHERE content_id = ? AND visitor_hash = ?').get(contentId, visitorHash)?.active);
  }

  installVoteStats(contentId, versionId) {
    if (!versionId) return { able: 0, unable: 0, total: 0, ablePercent: 0 };
    const rows = this.db.prepare(`
      SELECT vote, COUNT(*) AS count FROM install_votes
      WHERE content_id = ? AND version_id = ? GROUP BY vote
    `).all(contentId, versionId);
    const map = Object.fromEntries(rows.map((row) => [row.vote, row.count]));
    const able = Number(map.able || 0);
    const unable = Number(map.unable || 0);
    const total = able + unable;
    return { able, unable, total, ablePercent: total ? Math.round((able / total) * 100) : 0 };
  }

  getInstallVote(contentId, versionId, voterKey) {
    return this.db.prepare(`
      SELECT vote FROM install_votes WHERE content_id = ? AND version_id = ? AND voter_key = ?
    `).get(contentId, versionId, voterKey)?.vote || null;
  }

  voteInstall({ contentId, versionId, voterKey, userId = null, visitorHash, vote }) {
    if (!['able', 'unable'].includes(vote)) throw new Error('Invalid verification vote');
    const content = this.getContentById(contentId, false);
    if (!content || !content.verification_enabled || content.current_version_id !== versionId) return null;
    const timestamp = nowIso();
    this.db.prepare(`
      INSERT INTO install_votes(content_id, version_id, voter_key, user_id, visitor_hash, vote, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(content_id, version_id, voter_key)
      DO UPDATE SET user_id = excluded.user_id, visitor_hash = excluded.visitor_hash, vote = excluded.vote, updated_at = excluded.updated_at
    `).run(contentId, versionId, voterKey, userId, visitorHash || null, vote, timestamp, timestamp);
    return { vote, ...this.installVoteStats(contentId, versionId) };
  }

  createComment(comment) {
    const content = this.getContentById(comment.contentId, true);
    if (!content) throw new Error('Content not found');
    const commentType = COMMENT_TYPES.has(comment.commentType) ? comment.commentType : 'general';
    let versionId = comment.versionId || content.current_version_id || null;
    if (versionId && !this.db.prepare('SELECT 1 AS found FROM content_versions WHERE id = ? AND content_id = ?').get(versionId, content.id)) {
      throw new Error('Revision not found');
    }
    if (comment.parentId) {
      const parent = this.getComment(comment.parentId);
      if (!parent || parent.content_id !== content.id) throw new Error('Parent comment not found');
      versionId = parent.version_id || versionId;
    }
    const timestamp = nowIso();
    const id = comment.id || randomUUID();
    this.db.prepare(`
      INSERT INTO comments (
        id, content_id, version_id, parent_id, user_id, author_name, comment_type,
        body, status, created_at, updated_at, resolved_by, resolved_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, NULL, NULL)
    `).run(
      id,
      content.id,
      versionId,
      comment.parentId || null,
      comment.userId || null,
      String(comment.authorName || 'Community member').trim().slice(0, 120),
      commentType,
      String(comment.body || '').trim().slice(0, 10000),
      timestamp,
      timestamp
    );
    return this.getComment(id);
  }

  getComment(id) {
    return commentRow(this.db.prepare(`
      SELECT c.*, u.role AS author_role, u.avatar_url AS author_avatar, cv.version_label
      FROM comments c
      LEFT JOIN users u ON u.id = c.user_id
      LEFT JOIN content_versions cv ON cv.id = c.version_id
      WHERE c.id = ?
    `).get(id));
  }

  listCommentsForContent(contentId, includeHidden = false) {
    const where = includeHidden ? '' : "AND c.status <> 'hidden'";
    return this.db.prepare(`
      SELECT c.*, u.role AS author_role, u.avatar_url AS author_avatar, cv.version_label
      FROM comments c
      LEFT JOIN users u ON u.id = c.user_id
      LEFT JOIN content_versions cv ON cv.id = c.version_id
      WHERE c.content_id = ? ${where}
      ORDER BY c.created_at ASC
    `).all(contentId).map(commentRow);
  }

  listCommentInbox(status = 'open') {
    const params = [];
    let filter = '';
    if (COMMENT_STATUSES.has(status)) {
      filter = 'AND c.status = ?';
      params.push(status);
    }
    return this.db.prepare(`
      SELECT c.*, u.role AS author_role, u.avatar_url AS author_avatar, cv.version_label,
        co.title AS content_title, co.slug AS content_slug,
        (SELECT COUNT(*) FROM comments r WHERE r.parent_id = c.id AND r.status <> 'hidden') AS reply_count
      FROM comments c
      JOIN contents co ON co.id = c.content_id
      LEFT JOIN users u ON u.id = c.user_id
      LEFT JOIN content_versions cv ON cv.id = c.version_id
      WHERE c.parent_id IS NULL ${filter}
      ORDER BY CASE c.status WHEN 'open' THEN 1 WHEN 'resolved' THEN 2 ELSE 3 END, c.updated_at DESC
      LIMIT 500
    `).all(...params).map(commentRow);
  }

  setCommentStatus(id, status, actor) {
    if (!COMMENT_STATUSES.has(status)) throw new Error('Invalid comment status');
    const comment = this.getComment(id);
    if (!comment) return null;
    const timestamp = nowIso();
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      this.db.prepare(`
        UPDATE comments SET status = ?, updated_at = ?, resolved_by = ?, resolved_at = ? WHERE id = ?
      `).run(status, timestamp, status === 'resolved' ? actor : null, status === 'resolved' ? timestamp : null, id);
      this.recordAudit(actor, 'comment.status', 'comment', id, { from: comment.status, to: status }, false);
      this.db.exec('COMMIT;');
    } catch (error) {
      this.db.exec('ROLLBACK;');
      throw error;
    }
    return this.getComment(id);
  }

  commentSummary() {
    const rows = this.db.prepare('SELECT status, COUNT(*) AS count FROM comments WHERE parent_id IS NULL GROUP BY status').all();
    const map = Object.fromEntries(rows.map((row) => [row.status, row.count]));
    return { open: map.open || 0, resolved: map.resolved || 0, hidden: map.hidden || 0, total: rows.reduce((sum, row) => sum + row.count, 0) };
  }

  toggleFavorite(userId, contentId) {
    if (!this.getContentById(contentId, false)) return null;
    const existing = this.db.prepare('SELECT 1 AS found FROM favorites WHERE user_id = ? AND content_id = ?').get(userId, contentId);
    if (existing) {
      this.db.prepare('DELETE FROM favorites WHERE user_id = ? AND content_id = ?').run(userId, contentId);
      return { active: false };
    }
    this.db.prepare('INSERT INTO favorites(user_id, content_id, created_at) VALUES (?, ?, ?)').run(userId, contentId, nowIso());
    return { active: true };
  }

  toggleFollow(userId, contentId) {
    const content = this.getContentById(contentId, false);
    if (!content) return null;
    const existing = this.db.prepare('SELECT 1 AS found FROM follows WHERE user_id = ? AND content_id = ?').get(userId, contentId);
    if (existing) {
      this.db.prepare('DELETE FROM follows WHERE user_id = ? AND content_id = ?').run(userId, contentId);
      return { active: false };
    }
    const timestamp = nowIso();
    this.db.prepare(`
      INSERT INTO follows(user_id, content_id, followed_version_id, last_seen_version_id, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, contentId, content.current_version_id, content.current_version_id, timestamp, timestamp);
    return { active: true };
  }

  userContentState(userId, contentId) {
    if (!userId) return { favorite: false, following: false };
    return {
      favorite: Boolean(this.db.prepare('SELECT 1 AS found FROM favorites WHERE user_id = ? AND content_id = ?').get(userId, contentId)),
      following: Boolean(this.db.prepare('SELECT 1 AS found FROM follows WHERE user_id = ? AND content_id = ?').get(userId, contentId))
    };
  }

  markFollowSeen(userId, contentId, versionId) {
    if (!userId || !versionId) return;
    this.db.prepare(`
      UPDATE follows SET last_seen_version_id = ?, updated_at = ? WHERE user_id = ? AND content_id = ?
    `).run(versionId, nowIso(), userId, contentId);
  }

  listUserLibrary(userId) {
    const select = `
      SELECT c.*, cv.version_label AS current_version_label,
        CASE WHEN fo.last_seen_version_id IS NOT NULL AND fo.last_seen_version_id <> c.current_version_id THEN 1 ELSE 0 END AS has_update
      FROM contents c
      LEFT JOIN content_versions cv ON cv.id = c.current_version_id
      LEFT JOIN follows fo ON fo.content_id = c.id AND fo.user_id = ?
    `;
    const favorites = this.db.prepare(`${select}
      JOIN favorites f ON f.content_id = c.id AND f.user_id = ?
      WHERE c.status = 'published' ORDER BY f.created_at DESC
    `).all(userId, userId).map(contentRow);
    const following = this.db.prepare(`${select}
      JOIN follows f2 ON f2.content_id = c.id AND f2.user_id = ?
      WHERE c.status = 'published' ORDER BY f2.updated_at DESC
    `).all(userId, userId).map(contentRow);
    return { favorites, following };
  }

  contentStats(contentId) {
    const content = this.getContentById(contentId, true);
    const eventRows = this.db.prepare(`
      SELECT event_type, COUNT(*) AS count FROM events WHERE content_id = ? GROUP BY event_type
    `).all(contentId);
    const map = Object.fromEntries(eventRows.map((row) => [row.event_type, row.count]));
    const verification = this.installVoteStats(contentId, content?.current_version_id);
    const comments = this.db.prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'open' AND parent_id IS NULL THEN 1 ELSE 0 END) AS open FROM comments WHERE content_id = ? AND status <> 'hidden'").get(contentId);
    return {
      views: map.content_view || 0,
      previews: map.preview_open || 0,
      downloads: map.download || 0,
      shares: map.share || 0,
      likes: this.likeCount(contentId),
      comments: Number(comments.total || 0),
      openComments: Number(comments.open || 0),
      verification
    };
  }

  analytics(days = 30) {
    const since = new Date(Date.now() - days * 86400000).toISOString();
    const count = (type) => this.db.prepare('SELECT COUNT(*) AS count FROM events WHERE event_type = ? AND created_at >= ?').get(type, since).count;
    const uniqueVisitors = this.db.prepare('SELECT COUNT(DISTINCT visitor_hash) AS count FROM events WHERE created_at >= ?').get(since).count;
    const comments = this.commentSummary();
    const voteTotals = this.db.prepare(`
      SELECT
        SUM(CASE WHEN vote = 'able' THEN 1 ELSE 0 END) AS able,
        SUM(CASE WHEN vote = 'unable' THEN 1 ELSE 0 END) AS unable
      FROM install_votes WHERE created_at >= ?
    `).get(since);
    const totals = {
      uniqueVisitors,
      views: count('content_view'),
      previewOpens: count('preview_open'),
      downloads: count('download'),
      shares: count('share'),
      activeLikes: this.db.prepare('SELECT COUNT(*) AS count FROM likes WHERE active = 1').get().count,
      users: this.countUsers(),
      openComments: comments.open,
      ableVotes: Number(voteTotals.able || 0),
      unableVotes: Number(voteTotals.unable || 0)
    };

    const topContent = this.db.prepare(`
      SELECT c.id, c.title, c.slug,
        SUM(CASE WHEN e.event_type = 'content_view' THEN 1 ELSE 0 END) AS views,
        SUM(CASE WHEN e.event_type = 'download' THEN 1 ELSE 0 END) AS downloads,
        SUM(CASE WHEN e.event_type = 'share' THEN 1 ELSE 0 END) AS shares,
        (SELECT COUNT(*) FROM comments cm WHERE cm.content_id = c.id AND cm.parent_id IS NULL) AS comments
      FROM contents c
      LEFT JOIN events e ON e.content_id = c.id AND e.created_at >= ?
      GROUP BY c.id
      ORDER BY views DESC, downloads DESC
      LIMIT 10
    `).all(since);

    const dailyRows = this.db.prepare(`
      SELECT substr(created_at, 1, 10) AS day,
        SUM(CASE WHEN event_type = 'content_view' THEN 1 ELSE 0 END) AS views,
        SUM(CASE WHEN event_type = 'download' THEN 1 ELSE 0 END) AS downloads,
        SUM(CASE WHEN event_type = 'share' THEN 1 ELSE 0 END) AS shares
      FROM events
      WHERE created_at >= ?
      GROUP BY substr(created_at, 1, 10)
      ORDER BY day
    `).all(since);

    const dailyByDate = new Map(dailyRows.map((row) => [row.day, row]));
    const daily = [];
    for (let offset = days - 1; offset >= 0; offset -= 1) {
      const day = new Date(Date.now() - offset * 86400000).toISOString().slice(0, 10);
      daily.push(dailyByDate.get(day) || { day, views: 0, downloads: 0, shares: 0 });
    }

    const recentSearchRows = this.db.prepare(`
      SELECT metadata_json FROM events WHERE event_type = 'search' AND created_at >= ? ORDER BY created_at DESC LIMIT 1000
    `).all(since);
    const searchMap = new Map();
    for (const row of recentSearchRows) {
      const query = String(parseJson(row.metadata_json, {}).query || '').trim().toLowerCase();
      if (query) searchMap.set(query, (searchMap.get(query) || 0) + 1);
    }
    const topSearches = [...searchMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10).map(([query, countValue]) => ({ query, count: countValue }));

    const breakdownRows = this.db.prepare(`
      SELECT event_type, user_agent, referrer, metadata_json
      FROM events WHERE created_at >= ? ORDER BY id DESC LIMIT 20000
    `).all(since);
    const shareMap = new Map();
    const deviceMap = new Map();
    const referrerMap = new Map();
    for (const row of breakdownRows) {
      const userAgent = String(row.user_agent || '').toLowerCase();
      const device = /bot|crawler|spider|slurp/.test(userAgent)
        ? 'Automated'
        : /ipad|tablet|kindle/.test(userAgent)
          ? 'Tablet'
          : /mobile|iphone|android/.test(userAgent)
            ? 'Mobile'
            : 'Desktop';
      deviceMap.set(device, (deviceMap.get(device) || 0) + 1);

      if (row.event_type === 'share') {
        const channel = String(parseJson(row.metadata_json, {}).channel || 'unknown').trim().toLowerCase();
        shareMap.set(channel, (shareMap.get(channel) || 0) + 1);
      }

      const referrer = String(row.referrer || '').trim();
      if (referrer) {
        let label = referrer.slice(0, 120);
        try { label = new URL(referrer).hostname || label; } catch {}
        referrerMap.set(label, (referrerMap.get(label) || 0) + 1);
      }
    }
    const ranked = (map, limit = 8) => [...map.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, limit)
      .map(([label, countValue]) => ({ label, count: countValue }));

    const recentEvents = this.db.prepare(`
      SELECT e.event_type, e.created_at, c.title, e.metadata_json
      FROM events e LEFT JOIN contents c ON c.id = e.content_id
      ORDER BY e.id DESC LIMIT 20
    `).all().map((row) => ({ ...row, metadata: parseJson(row.metadata_json, {}), metadata_json: undefined }));

    return {
      days,
      since,
      totals,
      topContent,
      daily,
      topSearches,
      topShareChannels: ranked(shareMap),
      deviceMix: ranked(deviceMap),
      topReferrers: ranked(referrerMap),
      recentEvents,
      comments
    };
  }

  recordAudit(actor, action, entityType, entityId, metadata = {}, standalone = true) {
    const statement = this.db.prepare(`
      INSERT INTO audit_log(actor, action, entity_type, entity_id, metadata_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    statement.run(actor, action, entityType, entityId || null, JSON.stringify(metadata), nowIso());
    return standalone;
  }

  exportEvents() {
    return this.db.prepare(`
      SELECT e.id, e.event_type, e.content_id, c.title AS content_title, e.visitor_hash,
        e.session_hash, e.referrer, e.user_agent, e.metadata_json, e.created_at
      FROM events e LEFT JOIN contents c ON c.id = e.content_id ORDER BY e.id
    `).all();
  }

  exportContents() {
    return this.db.prepare('SELECT * FROM contents ORDER BY created_at').all();
  }

  backupTo(targetPath) {
    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    if (fs.existsSync(targetPath)) fs.unlinkSync(targetPath);
    const escaped = targetPath.replaceAll("'", "''");
    this.db.exec(`VACUUM INTO '${escaped}';`);
  }
}
