import { randomInt } from 'node:crypto';
import { createSignedToken, verifySignedToken } from './auth.mjs';

export function createHumanChallenge(config, action = 'form') {
  if (config.turnstileEnabled) {
    return { mode: 'turnstile', siteKey: config.turnstileSiteKey, action };
  }
  const left = randomInt(2, 10);
  const right = randomInt(1, 10);
  const token = createSignedToken({ answer: left + right, action, exp: Math.floor(Date.now() / 1000) + 15 * 60 }, config.sessionSecret);
  return { mode: 'local', question: `${left} + ${right}`, token, action };
}

function requestIp(req) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || req.socket.remoteAddress || '';
}

export async function verifyHumanChallenge({ config, fields, req, action = 'form' }) {
  if (config.captchaBypass) return { success: true, mode: 'bypass' };

  if (config.turnstileEnabled) {
    const responseToken = String(fields['cf-turnstile-response'] || '');
    if (!responseToken || responseToken.length > 2048) return { success: false, reason: 'Complete the human verification challenge.' };
    const body = new URLSearchParams({
      secret: config.turnstileSecretKey,
      response: responseToken,
      remoteip: requestIp(req)
    });
    let response;
    try {
      response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
        signal: AbortSignal.timeout(10000)
      });
    } catch {
      return { success: false, reason: 'Human verification is temporarily unavailable. Please try again.' };
    }
    if (!response.ok) return { success: false, reason: 'Human verification could not be completed.' };
    const result = await response.json();
    if (!result.success) return { success: false, reason: 'Human verification failed. Please retry the challenge.' };
    if (result.action && result.action !== action) return { success: false, reason: 'Human verification action did not match.' };
    return { success: true, mode: 'turnstile' };
  }

  const payload = verifySignedToken(String(fields.captchaToken || ''), config.sessionSecret);
  const answer = Number.parseInt(String(fields.captchaAnswer || ''), 10);
  if (!payload || payload.action !== action || !Number.isInteger(answer) || answer !== payload.answer) {
    return { success: false, reason: 'The verification answer is incorrect. Please try again.' };
  }
  return { success: true, mode: 'local' };
}
