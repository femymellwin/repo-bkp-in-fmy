import { createHash, createHmac } from 'node:crypto';


let cachedRoleCredentials = null;

async function fetchJson(url, options = {}) {
  const response = await fetch(url, { ...options, signal: AbortSignal.timeout(2000) });
  if (!response.ok) throw new Error(`Credential endpoint returned ${response.status}`);
  return response.json();
}

async function resolveRoleCredentials() {
  if (cachedRoleCredentials && cachedRoleCredentials.expiresAt - Date.now() > 5 * 60 * 1000) return cachedRoleCredentials;

  if (process.env.AWS_CONTAINER_CREDENTIALS_RELATIVE_URI) {
    const value = await fetchJson(`http://169.254.170.2${process.env.AWS_CONTAINER_CREDENTIALS_RELATIVE_URI}`);
    cachedRoleCredentials = {
      accessKeyId: value.AccessKeyId,
      secretAccessKey: value.SecretAccessKey,
      sessionToken: value.Token,
      expiresAt: new Date(value.Expiration).getTime()
    };
    return cachedRoleCredentials;
  }

  const tokenResponse = await fetch('http://169.254.169.254/latest/api/token', {
    method: 'PUT',
    headers: { 'X-aws-ec2-metadata-token-ttl-seconds': '21600' },
    signal: AbortSignal.timeout(2000)
  });
  if (!tokenResponse.ok) throw new Error(`IMDS token request returned ${tokenResponse.status}`);
  const token = await tokenResponse.text();
  const roleResponse = await fetch('http://169.254.169.254/latest/meta-data/iam/security-credentials/', {
    headers: { 'X-aws-ec2-metadata-token': token },
    signal: AbortSignal.timeout(2000)
  });
  if (!roleResponse.ok) throw new Error(`IMDS role request returned ${roleResponse.status}`);
  const roleName = (await roleResponse.text()).trim();
  if (!roleName) throw new Error('No IAM instance role is attached');
  const value = await fetchJson(`http://169.254.169.254/latest/meta-data/iam/security-credentials/${encodeURIComponent(roleName)}`, {
    headers: { 'X-aws-ec2-metadata-token': token }
  });
  cachedRoleCredentials = {
    accessKeyId: value.AccessKeyId,
    secretAccessKey: value.SecretAccessKey,
    sessionToken: value.Token,
    expiresAt: new Date(value.Expiration).getTime()
  };
  return cachedRoleCredentials;
}

async function resolveCredentials(accessKeyId, secretAccessKey, sessionToken) {
  if (accessKeyId && secretAccessKey) return { accessKeyId, secretAccessKey, sessionToken };
  try {
    return await resolveRoleCredentials();
  } catch (error) {
    throw new Error(`AWS credentials are unavailable. Set environment credentials or attach an IAM role. ${error.message}`);
  }
}

function hashHex(value) {
  return createHash('sha256').update(value).digest('hex');
}

function hmac(key, value, encoding) {
  return createHmac('sha256', key).update(value).digest(encoding);
}

function encodeRfc3986(value) {
  return encodeURIComponent(value).replace(/[!'()*]/g, (character) => `%${character.charCodeAt(0).toString(16).toUpperCase()}`);
}

function canonicalPath(key) {
  return `/${String(key).split('/').map(encodeRfc3986).join('/')}`;
}

function amzDate(date = new Date()) {
  return date.toISOString().replace(/[:-]|\.\d{3}/g, '');
}

function signingKey(secret, dateStamp, region, service) {
  const dateKey = hmac(`AWS4${secret}`, dateStamp);
  const regionKey = hmac(dateKey, region);
  const serviceKey = hmac(regionKey, service);
  return hmac(serviceKey, 'aws4_request');
}

export async function putS3Object({
  bucket,
  key,
  body,
  region,
  accessKeyId,
  secretAccessKey,
  sessionToken,
  contentType = 'application/octet-stream',
  cacheControl = 'private, max-age=0',
  storageClass,
  contentDisposition
}) {
  if (!bucket || !region) throw new Error('S3 bucket or region is missing');
  const credentials = await resolveCredentials(accessKeyId, secretAccessKey, sessionToken);
  accessKeyId = credentials.accessKeyId;
  secretAccessKey = credentials.secretAccessKey;
  sessionToken = credentials.sessionToken;

  const payload = Buffer.isBuffer(body) ? body : Buffer.from(body);
  const host = `${bucket}.s3.${region}.amazonaws.com`;
  const requestPath = canonicalPath(key);
  const timestamp = amzDate();
  const dateStamp = timestamp.slice(0, 8);
  const payloadHash = hashHex(payload);

  const headerMap = {
    'content-type': contentType,
    host,
    'x-amz-content-sha256': payloadHash,
    'x-amz-date': timestamp
  };
  if (cacheControl) headerMap['cache-control'] = cacheControl;
  if (contentDisposition) headerMap['content-disposition'] = contentDisposition;
  if (sessionToken) headerMap['x-amz-security-token'] = sessionToken;
  if (storageClass) headerMap['x-amz-storage-class'] = storageClass;

  const headerNames = Object.keys(headerMap).sort();
  const canonicalHeaders = headerNames.map((name) => `${name}:${String(headerMap[name]).trim()}\n`).join('');
  const signedHeaders = headerNames.join(';');
  const canonicalRequest = ['PUT', requestPath, '', canonicalHeaders, signedHeaders, payloadHash].join('\n');
  const scope = `${dateStamp}/${region}/s3/aws4_request`;
  const stringToSign = ['AWS4-HMAC-SHA256', timestamp, scope, hashHex(canonicalRequest)].join('\n');
  const signature = hmac(signingKey(secretAccessKey, dateStamp, region, 's3'), stringToSign, 'hex');
  const authorization = `AWS4-HMAC-SHA256 Credential=${accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

  const headers = {
    'Content-Type': contentType,
    'x-amz-content-sha256': payloadHash,
    'x-amz-date': timestamp,
    Authorization: authorization
  };
  if (cacheControl) headers['Cache-Control'] = cacheControl;
  if (contentDisposition) headers['Content-Disposition'] = contentDisposition;
  if (sessionToken) headers['x-amz-security-token'] = sessionToken;
  if (storageClass) headers['x-amz-storage-class'] = storageClass;

  let lastError;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      const response = await fetch(`https://${host}${requestPath}`, {
        method: 'PUT',
        headers,
        body: payload,
        signal: AbortSignal.timeout(120000)
      });
      if (!response.ok) {
        const message = await response.text();
        throw new Error(`S3 PUT failed (${response.status}): ${message.slice(0, 500)}`);
      }
      return { etag: response.headers.get('etag'), key };
    } catch (error) {
      lastError = error;
      if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, 300 * attempt));
    }
  }
  throw lastError;
}
