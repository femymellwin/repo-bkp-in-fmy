import { initializePortal } from './app.mjs';

const portal = await initializePortal();
const server = portal.createHttpServer();

server.listen(portal.config.port, portal.config.host, () => {
  const displayHost = portal.config.host === '0.0.0.0' ? 'localhost' : portal.config.host;
  console.log('');
  console.log('OpenLearn Atlas is running');
  console.log(`Public portal: http://${displayHost}:${portal.config.port}`);
  console.log(`Publisher login: http://${displayHost}:${portal.config.port}/admin/login`);
  if (portal.config.defaultCredentials) console.log('Demo login: admin@example.com / ChangeMe123!');
  console.log(`Storage driver: ${portal.config.storageDriver}`);
  console.log('Press Ctrl+C to stop.');
  console.log('');
});

function shutdown(signal) {
  console.log(`Received ${signal}; shutting down.`);
  server.close(() => {
    portal.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
