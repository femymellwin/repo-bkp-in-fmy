(function () {
  'use strict';

  const toast = document.getElementById('toast');
  const numberFormat = new Intl.NumberFormat('en-US');

  function showToast(message) {
    if (!toast || !message) return;
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 2800);
  }

  function contentContext() {
    const root = document.querySelector('[data-content-id]');
    if (!root) return null;
    return {
      id: root.dataset.contentId,
      title: root.dataset.contentTitle,
      url: root.dataset.contentUrl
    };
  }

  function csrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.content || '';
  }

  async function readJson(response) {
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      const text = await response.text();
      throw new Error(text || `Request failed (${response.status})`);
    }
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || `Request failed (${response.status})`);
    return result;
  }

  async function track(eventType, metadata) {
    const context = contentContext();
    const payload = JSON.stringify({
      eventType,
      contentId: context ? context.id : null,
      metadata: metadata || {}
    });
    try {
      if (navigator.sendBeacon && document.visibilityState === 'hidden') {
        navigator.sendBeacon('/api/events', new Blob([payload], { type: 'application/json' }));
      } else {
        await fetch('/api/events', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: payload,
          keepalive: true
        });
      }
    } catch (_) {
      // Measurement must never interrupt the learning experience.
    }
  }

  const context = contentContext();
  if (context) track('content_view', { path: window.location.pathname });

  document.querySelectorAll('[data-event]').forEach((element) => {
    element.addEventListener('click', () => track(element.dataset.event, {
      label: element.textContent.trim().slice(0, 120)
    }));
  });

  document.querySelectorAll('[data-preview-open]').forEach((button) => {
    button.addEventListener('click', () => {
      const frame = document.querySelector('[data-preview-frame]');
      const shell = document.querySelector('[data-preview-shell]');
      const placeholder = document.querySelector('[data-preview-placeholder]');
      if (!frame || !shell) return;
      if (!frame.getAttribute('src')) {
        frame.setAttribute('src', button.dataset.previewUrl);
        track('preview_open', { mode: 'embedded' });
      }
      shell.classList.add('loaded');
      if (placeholder) placeholder.hidden = true;
      shell.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });

  const previewFrame = document.querySelector('[data-preview-frame]');
  if (previewFrame) previewFrame.addEventListener('load', () => track('preview_loaded', {}));

  const likeButton = document.querySelector('[data-like]');
  if (likeButton && context) {
    likeButton.addEventListener('click', async () => {
      likeButton.disabled = true;
      try {
        const response = await fetch(`/api/content/${encodeURIComponent(context.id)}/like`, { method: 'POST' });
        const result = await readJson(response);
        likeButton.classList.toggle('active', result.active);
        likeButton.setAttribute('aria-pressed', result.active ? 'true' : 'false');
        const icon = likeButton.querySelector('span:first-child');
        if (icon) icon.innerHTML = result.active ? '&#9829;' : '&#9825;';
        const label = likeButton.querySelector('[data-like-label]');
        if (label) label.textContent = result.active ? 'Liked' : 'Like';
        const count = document.querySelector('[data-stat="likes"]');
        if (count) count.textContent = numberFormat.format(result.count || 0);
        showToast(result.active ? 'Like recorded' : 'Like removed');
      } catch (error) {
        showToast(error.message);
      } finally {
        likeButton.disabled = false;
      }
    });
  }

  function configureAccountToggle(selector, endpoint, labelSelector, onText, offText, iconHtml) {
    const button = document.querySelector(selector);
    if (!button || !context) return;
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        const response = await fetch(`/api/content/${encodeURIComponent(context.id)}/${endpoint}`, {
          method: 'POST',
          headers: { 'X-CSRF-Token': csrfToken() }
        });
        if (response.status === 401) {
          window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`;
          return;
        }
        const result = await readJson(response);
        button.classList.toggle('active', result.active);
        button.setAttribute('aria-pressed', result.active ? 'true' : 'false');
        const label = button.querySelector(labelSelector);
        if (label) label.textContent = result.active ? onText : offText;
        const icon = button.querySelector('span:first-child');
        if (icon && iconHtml) icon.innerHTML = result.active ? iconHtml.on : iconHtml.off;
        showToast(result.active ? onText : `${offText} removed`);
      } catch (error) {
        showToast(error.message);
      } finally {
        button.disabled = false;
      }
    });
  }

  configureAccountToggle(
    '[data-favorite]',
    'favorite',
    '[data-favorite-label]',
    'Favorited',
    'Favorite',
    { on: '&#9733;', off: '&#9734;' }
  );
  configureAccountToggle(
    '[data-follow]',
    'follow',
    '[data-follow-label]',
    'Following',
    'Follow updates',
    null
  );

  const verificationPanel = document.querySelector('[data-verification]');
  if (verificationPanel && context) {
    const voteButtons = [...verificationPanel.querySelectorAll('[data-install-vote]')];
    voteButtons.forEach((button) => {
      button.addEventListener('click', async () => {
        voteButtons.forEach((item) => { item.disabled = true; });
        try {
          const response = await fetch(`/api/content/${encodeURIComponent(context.id)}/install-vote`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ vote: button.dataset.installVote })
          });
          const result = await readJson(response);
          voteButtons.forEach((item) => item.classList.toggle('selected', item.dataset.installVote === result.vote));
          const ableCount = verificationPanel.querySelector('[data-able-count]');
          const unableCount = verificationPanel.querySelector('[data-unable-count]');
          const bar = verificationPanel.querySelector('[data-verification-bar]');
          const label = verificationPanel.querySelector('[data-verification-label]');
          if (ableCount) ableCount.textContent = numberFormat.format(result.able || 0);
          if (unableCount) unableCount.textContent = numberFormat.format(result.unable || 0);
          if (bar) bar.style.width = `${Math.max(0, Math.min(100, result.ablePercent || 0))}%`;
          if (label) label.textContent = result.status?.label || 'Vote saved';
          showToast(result.vote === 'able' ? 'Marked able to install' : 'Marked unable to install');
        } catch (error) {
          showToast(error.message);
        } finally {
          voteButtons.forEach((item) => { item.disabled = false; });
        }
      });
    });
  }

  async function share(channel) {
    if (!context) return;
    const text = `${context.title} - ${context.url}`;
    await track('share', { channel });
    if (channel === 'native' && navigator.share) {
      try {
        await navigator.share({ title: context.title, text: context.title, url: context.url });
      } catch (_) {
        // User cancellation is not an error.
      }
      return;
    }
    if (channel === 'whatsapp') {
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
    } else if (channel === 'linkedin') {
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(context.url)}`, '_blank', 'noopener');
    } else if (channel === 'email') {
      window.location.href = `mailto:?subject=${encodeURIComponent(context.title)}&body=${encodeURIComponent(text)}`;
    } else if (channel === 'copy' || channel === 'native') {
      try {
        await navigator.clipboard.writeText(context.url);
        showToast('Link copied');
      } catch (_) {
        window.prompt('Copy this link:', context.url);
      }
    }
  }

  document.querySelectorAll('[data-share]').forEach((button) => {
    button.addEventListener('click', () => share(button.dataset.share));
  });

  const searchForm = document.querySelector('[data-search-form]');
  if (searchForm) {
    searchForm.addEventListener('submit', () => {
      const query = new FormData(searchForm).get('q');
      if (query && String(query).trim()) track('search', { query: String(query).trim().slice(0, 200) });
    });
  }

  document.querySelectorAll('[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });

  // ---- Video lessons: one tracked play event per page view ----
  const videoPlayer = document.querySelector('[data-video-player]');
  if (videoPlayer) {
    let tracked = false;
    videoPlayer.addEventListener('play', () => {
      if (tracked) return;
      tracked = true;
      track('video_play', {});
    });
  }

  async function postJson(url, payload) {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'X-CSRF-Token': csrfToken() },
      body: JSON.stringify(payload || {})
    });
    return readJson(response);
  }

  function setResult(element, message, ok) {
    if (!element) return;
    element.textContent = message;
    element.classList.toggle('ok', Boolean(ok));
    element.classList.toggle('fail', !ok);
  }

  // ---- AI studio: provider connection tests ----
  document.querySelectorAll('[data-ai-test]').forEach((button) => {
    button.addEventListener('click', async () => {
      const provider = button.dataset.aiTest;
      const result = document.querySelector(`[data-ai-result="${provider}"]`);
      button.disabled = true;
      setResult(result, 'Testing...', true);
      try {
        const payload = await postJson('/admin/ai/test', { provider });
        setResult(result, `Connected in ${payload.latencyMs} ms`, true);
      } catch (error) {
        setResult(result, error.message, false);
      } finally {
        button.disabled = false;
      }
    });
  });

  // ---- Integrations: SharePoint connectivity test ----
  const sharePointTest = document.querySelector('[data-sharepoint-test]');
  if (sharePointTest) {
    sharePointTest.addEventListener('click', async () => {
      const result = document.querySelector('[data-sharepoint-result]');
      sharePointTest.disabled = true;
      setResult(result, 'Testing connection...', true);
      try {
        const payload = await postJson('/admin/integrations/test', {});
        setResult(result, `Connected to ${payload.siteName || payload.siteId} in ${payload.latencyMs} ms`, true);
      } catch (error) {
        setResult(result, error.message, false);
      } finally {
        sharePointTest.disabled = false;
      }
    });
  }

  // ---- Icon library: AI icon generation ----
  const iconGenerator = document.querySelector('[data-icon-generator]');
  if (iconGenerator) {
    const generateButton = iconGenerator.querySelector('[data-icon-generate]');
    generateButton.addEventListener('click', async () => {
      const name = iconGenerator.querySelector('[data-icon-name]')?.value?.trim();
      const description = iconGenerator.querySelector('[data-icon-description]')?.value?.trim();
      const result = iconGenerator.querySelector('[data-icon-result]');
      const preview = iconGenerator.querySelector('[data-icon-preview]');
      if (!name || !description) {
        setResult(result, 'Enter a name and a description first', false);
        return;
      }
      generateButton.disabled = true;
      setResult(result, 'Generating icon...', true);
      try {
        const payload = await postJson('/admin/icons/generate', { name, description });
        setResult(result, `Saved "${payload.name}" to the library`, true);
        if (preview) preview.innerHTML = payload.svg;
        showToast('Icon generated and saved. Reload upload forms to select it.');
        window.setTimeout(() => window.location.reload(), 1400);
      } catch (error) {
        setResult(result, error.message, false);
      } finally {
        generateButton.disabled = false;
      }
    });
  }
})();
