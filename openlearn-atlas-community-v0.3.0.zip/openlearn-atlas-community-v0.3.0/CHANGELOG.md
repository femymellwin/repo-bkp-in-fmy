# Changelog

## 0.3.0

### Added
- Multi-format learning packages: video (MP4/M4V/WebM/MOV), PDF, PPTX/PPT, DOCX/DOC, XLSX/CSV, Markdown/TXT, SVG, PNG/JPG/WebP, animated GIF, alongside interactive HTML/ZIP (`src/formats.mjs`).
- Format-specific viewers on the resource page: HTML5 video player with poster, PDF frame, full-size image viewer, rendered article view, and a download panel for Office formats.
- `/view/<contentId>` inline delivery route with HTTP range streaming (local) or CDN redirect (S3), gated by the resource access level.
- Dependency-free, escaped Markdown renderer; articles are pre-rendered to static HTML at upload time (`src/markdown.mjs`).
- AI studio (`/admin/ai`): runtime configuration for Anthropic Claude, OpenAI, Azure OpenAI, Google Gemini, Ollama, OpenRouter, Groq, and custom OpenAI-compatible endpoints, with masked keys and connection tests (`src/ai.mjs`).
- Icon library (`/admin/icons`): 16 built-in SVG icons, generic fallback, sanitized SVG icon uploads, AI icon generation, and safe deletion (`custom_icons` table).
- Integrations page (`/admin/integrations`): SharePoint configuration and Microsoft Graph connectivity test; import primitives prepared for stage two (`src/sharepoint.mjs`).
- Schema migration v3: `media_kind` on contents and versions, `custom_icons` table, JSON settings storage.
- `video_play` analytics event; media-kind badges and play overlays in the gallery.
- Test suite additions covering formats, sanitization, the media pipeline, icon lifecycle, and settings (`test/media-and-ai.test.mjs`).

### Changed
- Refreshed professional light UI: sticky translucent header, elevated cards, inline SVG icon system, new viewer shells.
- Upload and revision forms accept every supported format; content types and icon pickers are format-aware.
- SVG packages and icons are sanitized on upload (scripts, event handlers, and external references removed).

### Fixed
- Icon values longer than 30 characters were truncated on metadata edits, which broke custom icon assignment.


All notable changes to this project are documented here. Release tags use semantic versioning.

## [0.2.0] - 2026-08-30

### Added

- Per-revision SPIN verification with able-to-install and unable-to-install votes.
- Community document comments classified as errors, suggestions, questions, or general feedback.
- Publisher message inbox with threaded staff replies, resolution, reopening, and hiding.
- Immutable content-version records and explicit draft, published, and archived revision states.
- Atomic publication that makes the selected revision current and archives prior active revisions.
- Database-backed users with super administrator, administrator, publisher, moderator, and member roles.
- Optional member registration, local CAPTCHA, Cloudflare Turnstile integration, and Google sign-in hooks.
- Signed-in favorites, revision following, and new-revision indication.
- Public, account-required, and premium content access levels.
- Administrator-managed premium entitlement placeholder for future payment integration.
- Publisher branding settings for logo, organization, product name, product tagline, and description.
- Compact gallery-first landing page and redesigned document/community interface.
- Schema migration from version 0.1 that preserves existing content, events, likes, audit data, and storage references.
- End-to-end tests for access controls, revisions, comments, voting, accounts, roles, branding, migration, OAuth/PKCE, CAPTCHA, and backup integrity.

### Changed

- Authentication now uses database-backed account sessions rather than a single environment-only publisher identity.
- Package files are stored under immutable content and version identifiers.
- Direct local package/preview media paths are blocked; access-controlled routes mediate delivery.
- Backups now include users, comments, install votes, favorites, follows, portal settings, and package revisions.
- Restore now copies and verifies the selected source archive before retention cleanup, creates a mandatory safety backup, and atomically replaces the database and local package store while preserving pre-restore copies.

### Security

- Added server-side CAPTCHA validation hooks, Google OAuth state and PKCE, per-action role authorization, disabled-user session revocation, last-super-administrator protection, version-aware access checks, anonymous-comment throttling, and server-side entitlement enforcement for previews, downloads, SPIN votes, and feedback submission.

### Known production gaps

- Local accounts do not yet include email verification, self-service password reset, or MFA.
- Premium entitlement is administrative; payment collection and webhook reconciliation are not included.
- Restricted objects need CloudFront signed URLs/cookies in production S3 mode.
- SQLite and in-memory rate limiting remain single-node components.
- Uploads are validated structurally but are not yet processed through an antivirus/quarantine service.

## [0.1.0] - 2026-08-28

### Added

- Public no-login catalog, search, filters, resource details, preview, download, likes, and social sharing.
- Publisher login, upload workflow, status controls, featured resources, analytics dashboard, CSV export, metadata revisions, and audit history.
- HTML and ZIP package validation with sandboxed previews.
- SQLite migrations and local or S3/CloudFront storage modes.
- Checksum-verified backup, restore, retention, and optional S3 backup upload.
- Docker and macOS startup paths.
- AWS CloudFormation template for private versioned S3 buckets and CloudFront Origin Access Control.
- GitHub CI and tagged release packaging.
