# 15. Media formats and video

Version 0.3.0 turns the portal from an HTML/ZIP library into a full multi-format learning platform.

## Supported upload formats

| Kind | Extensions | In-browser experience |
| --- | --- | --- |
| Interactive | `.html`, `.htm`, `.zip` | Sandboxed iframe preview (unchanged) |
| Video | `.mp4`, `.m4v`, `.webm`, `.mov` | HTML5 player with poster thumbnail and seek support |
| Document | `.pdf` | Native browser PDF viewer in a restricted frame |
| Document | `.docx`, `.doc` | Download card (opens in Word) |
| Presentation | `.pptx`, `.ppt` | Download card (opens in PowerPoint) |
| Dataset | `.xlsx`, `.csv` | Download card |
| Article | `.md`, `.markdown`, `.txt` | Rendered article view (server-side, escaped) |
| Visual | `.svg` (sanitized), `.png`, `.jpg`, `.jpeg`, `.webp` | Full-size image viewer |
| Animated flow | `.gif` | Full-size animated viewer |

Unsupported extensions are rejected at upload with a clear message. ZIP and PDF uploads are additionally verified by magic bytes.

## How each format is stored

- Every package is stored immutably under `content/<id>/versions/<versionId>/package/`.
- Interactive HTML/ZIP still extracts to a static `preview/` tree.
- Markdown/TXT is rendered **once at upload time** into `preview/index.html` (styled, fully escaped), so both local and S3/CloudFront modes serve articles statically.
- SVG packages are sanitized on upload: scripts, event handlers, `foreignObject`, and external references are stripped.
- Image resources reuse themselves as the gallery thumbnail when no thumbnail is uploaded (up to 8 MB).

## Video delivery

- **Local mode:** the new `/view/<contentId>` route streams the current published package inline with HTTP `Range` support (206 partial responses), so seeking works in every browser. Access-level checks (open / sign-in / premium) apply before any byte is served.
- **S3 + CloudFront mode:** `/view/<contentId>` issues a 302 to the CDN URL; CloudFront handles range requests and caching natively, which keeps the AWS bill on the affordable plan described in `08-COST-PLAN.md` (S3 storage + CloudFront egress, no transcoding services).
- Upload a **poster thumbnail** with each video; it is used on the gallery card (with a play overlay) and as the player poster.
- A `video_play` analytics event is recorded once per page view when playback starts.

## Recommendations for free-tier friendly video

- Encode to H.264 MP4 (or WebM) at 720p before upload; the platform intentionally does not transcode.
- Keep `MAX_UPLOAD_MB` aligned with your S3 budget (default 100 MB).
- CloudFront's always-free tier (1 TB egress/month at the time of writing) comfortably covers a small community's video traffic; verify current AWS free-tier terms before launch.
