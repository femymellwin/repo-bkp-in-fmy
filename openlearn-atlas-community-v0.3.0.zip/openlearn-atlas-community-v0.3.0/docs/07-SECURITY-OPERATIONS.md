# 7. Security, privacy, and operations

## Controls included in version 0.2.0

### Identity and authorization

- Anonymous browsing remains available for published catalog metadata.
- Document preview/download access is enforced as open, sign-in, or premium in local-storage mode.
- Local passwords are stored with scrypt hashes.
- Optional Google sign-in uses an authorization-code flow with signed state and PKCE.
- Signed `HttpOnly`, `SameSite=Lax` session cookies are marked `Secure` when `NODE_ENV=production`.
- Every request reloads the account's current status, role, and premium entitlement from the database, so disabling an account or changing its role takes effect without waiting for the signed session to expire.
- Roles separate super-administrator, administrator, publisher, moderator, and member responsibilities.
- The last active super administrator cannot be disabled or downgraded.
- CSRF tokens protect signed-in state-changing forms and APIs.
- Registration and anonymous comments use Turnstile when configured, otherwise a signed arithmetic challenge for local evaluation.

### Community and data integrity

- SPIN votes use one account/anonymous-browser vote per revision and update rather than duplicate that vote.
- Comments and publisher replies are escaped as text and remain linked to the exact package revision.
- Publishing a package revision occurs transactionally and archives older non-archived package revisions.
- Package keys include immutable version identifiers.
- Administrative changes produce audit records.
- Ordinary content management archives rather than permanently deletes documents or revisions.
- SQLite foreign keys, schema migrations, write-ahead logging, and a busy timeout are enabled.

### HTTP and uploaded content

- Security response headers include content-type sniffing prevention, a permissions policy, referrer controls, frame restrictions, and page Content Security Policy.
- Uploaded interactive HTML runs in a sandboxed iframe.
- ZIP validation rejects parent traversal, absolute paths, symbolic links, encrypted archives, ZIP64, unsupported compression, duplicate names including case-only duplicates, excessive file counts, excessive expanded size, and checksum mismatch.
- Local `/media` routes refuse direct package and preview paths so viewers cannot bypass local access checks.
- S3 content buckets are intended to remain private behind CloudFront Origin Access Control.
- Application IAM examples do not grant ordinary content-delete permission.

### Abuse and privacy controls

- Login, registration, analytics, like, SPIN-vote, and comment operations have process-local rate limits.
- Anonymous analytics and reactions use salted hashes of random first-party browser identifiers.
- The application does not intentionally persist raw visitor IP addresses. Network addresses can still be processed transiently for rate limiting and Turnstile validation.
- Content-view and preview-loaded events are deduplicated for short intervals.
- Backups include database state, local package data where applicable, a SHA-256 manifest, and an outer checksum sidecar.

## Known production limitations

Treat these as launch gates, not minor future enhancements:

1. SQLite and the in-memory rate limiters are single-node components. They are unsuitable for active-active application instances.
2. Local accounts do not yet include verified-email activation, self-service password reset/change, account recovery, or MFA.
3. Google OAuth is implemented and unit-tested with mocked provider responses but has not been validated against the user's live Google project in this build environment.
4. Uploaded packages are structurally validated but not scanned by antivirus, detonation, or a content-analysis service.
5. Public comments are displayed immediately. A high-scale launch needs spam scoring, moderation queues, abuse reporting, and policy tools.
6. S3/CloudFront mode currently returns permanent CDN object URLs. Those URLs can bypass later portal analytics, unpublish actions, and sign-in/premium checks. Do not deploy restricted S3-hosted packages until signed URL/cookie delivery is implemented.
7. The built-in premium status is an administrator-controlled entitlement; there is no payment processor, webhook ledger, reconciliation, refund, or billing workflow.
8. Favorites and follows provide an in-portal revision indicator only; no email or push notification worker is included.
9. The database is protected at the file/volume and backup layers, not with field-level encryption.
10. Analytics uniqueness is approximate. Visitors can clear cookies, block JavaScript, or use another browser.
11. A share event records selection of a channel, not confirmation that a private message was sent or received.
12. Raw analytics events remain until an operator defines and implements retention/deletion rules.
13. There is no formal availability SLA, multi-Region failover, or automatic disaster-recovery orchestration in this release.

## Before any Internet-facing test

### Accounts and secrets

- Replace demonstration credentials before exposing the application.
- Generate the initial administrator password hash before the first production database start.
- Generate independent high-entropy values for `SESSION_SECRET` and `PRIVACY_SALT`.
- Keep `.env` outside Git and restrict its filesystem permissions.
- Configure Google and Turnstile secrets through protected deployment configuration.
- Require MFA/passkeys for AWS, Git hosting, the domain registrar, and Google Cloud administrators.
- Use separate named staff accounts; do not share one administrator login.
- Keep a documented, tested path for recovering control if one administrator account is unavailable.

Generate secrets locally:

```bash
openssl rand -base64 48
openssl rand -base64 48
```

Generate a local-password hash:

```bash
npm run password-hash -- "a-long-unique-password"
```

### Network and hosting

- Use HTTPS only.
- Restrict SSH to known addresses where practical.
- Open only required inbound ports.
- Keep S3 Block Public Access enabled.
- Use CloudFront Origin Access Control for S3 origins.
- Serve interactive packages from a dedicated content host, separate from the authenticated portal host.
- Apply content-origin response headers and test iframe behavior.
- Add WAF/rate controls before broad promotion.
- Use CloudFront signed delivery for every sign-in or premium S3 object.

### Application acceptance

Run against the exact release artifact:

```bash
npm test
```

Then verify:

```text
[ ] Anonymous open-resource preview and download
[ ] Sign-in and premium denial/allow paths
[ ] Account registration challenge
[ ] Google sign-in in staging
[ ] Favorite and follow state
[ ] One-vote-per-revision SPIN behavior
[ ] Anonymous and member comments
[ ] Publisher reply and resolve/reopen
[ ] Staff role boundaries
[ ] Last-super-administrator guard
[ ] Revision upload, draft, publish, and archive
[ ] Historical feedback retained after publication
[ ] Branding upload and safe rendering
[ ] Backup creation, verification, and restore rehearsal
[ ] Draft/archived documents absent from public search
[ ] Restricted direct media paths rejected in local mode
```

### Data protection

- Create a verified application backup.
- Store a copy outside the application server.
- Confirm S3 Versioning and lifecycle policies where applicable.
- Enable encrypted server/disk snapshots.
- Retain a manual recovery point independently of automatic snapshot deletion behavior.
- Record DNS, certificate, OAuth, Turnstile, Git, AWS, and domain recovery ownership.
- Complete a restore exercise before publishing irreplaceable content.
- Define RPO and RTO before the portal becomes operationally important.

## Uploaded-content policy

Treat every HTML or ZIP upload as executable third-party code.

Minimum editorial procedure:

```text
1. Confirm ownership, license, and authorization to publish.
2. Record source, author, reviewer, and revision label.
3. Inspect JavaScript and external network destinations.
4. Remove credentials, private endpoints, trackers, and personal data.
5. Test in an isolated staging portal.
6. Confirm archive limits and relative asset paths.
7. Confirm preview behavior in the iframe sandbox.
8. Validate download filename and package checksum.
9. Obtain approval from a different person where the risk justifies it.
10. Publish as a new immutable revision.
```

The final architecture should upload to a quarantine bucket/prefix, scan asynchronously, and copy an approved immutable object into the published prefix. See `docs/13-PRODUCTION-TARGET-ARCHITECTURE.md`.

## Community moderation policy

Before public comments are promoted broadly, publish rules covering:

- Technical relevance.
- Personal data and confidential information.
- Harassment and abusive language.
- Malicious links or code.
- Copyright and takedown handling.
- Vulnerability disclosure.
- Moderator actions, appeals, and retention.

Moderators should hide policy-violating content rather than alter its meaning. Corrections to a learning package should result in a new package revision; do not rewrite old feedback to make it appear that it concerned a newer revision.

## Privacy and analytics

The privacy notice should explain:

- First-party visitor and analytics-session cookies.
- Account data and optional Google identity data.
- Favorites, follows, SPIN votes, comments, and replies.
- Event types such as views, preview opens, downloads, searches, likes, and share-channel selections.
- Referrer and browser user-agent collection.
- CAPTCHA processing.
- Purpose, lawful basis where applicable, retention, deletion, and contact process.
- Any future payment, email, or external analytics providers.

Do not describe browser identifiers as impossible to re-identify. Pseudonymous data is still data that requires controlled use and retention.

## Operational schedule

### Daily

- Check public and authenticated health paths.
- Confirm the latest backup job and off-server copy.
- Review application errors, authentication spikes, comment abuse, and failed uploads.
- Check database/server free space.

### Weekly

- Review open community messages and unresolved failed-step reports.
- Apply tested operating-system and runtime security updates.
- Review S3/CloudFront growth and unusual traffic.
- Inspect staff/user changes and publication audit activity.
- Verify at least one current revision can preview and download.

### Monthly

- Retain a manual server/database recovery point according to policy.
- Download a verified encrypted backup to an independent location.
- Review AWS IAM, Google Cloud administrators, Git collaborators, deploy keys, and OAuth credentials.
- Review disabled/departed staff.
- Confirm the deployed release tag and checksum.
- Review domain expiry and recovery settings.

### Quarterly

- Restore the portal into an isolated environment and execute the acceptance workflow.
- Rotate long-lived credentials that cannot yet be replaced by roles/OIDC.
- Review privacy and analytics retention.
- Test account and domain recovery.
- Reassess whether the single-server deployment remains acceptable.
- Review SPIN-vote and comment abuse patterns.

## Logging

The application writes operational errors to standard output; Docker captures them.

```bash
docker compose logs --since=24h portal
docker compose logs -f portal
sudo journalctl -u caddy --since "24 hours ago"
```

Configure host log rotation. Do not log:

```text
Passwords or password hashes
Session or OAuth cookies
Authorization codes or access tokens
AWS/Google/Turnstile secrets
Full uploaded package contents
CAPTCHA responses
Private recovery data
Unnecessary raw personal data
```

The target architecture should use structured logs with request/correlation IDs, centrally defined retention, security alerts, and separate audit-log protection.

## Health monitoring

Endpoint:

```text
GET /health
```

Expected form:

```json
{"ok":true,"storage":"s3","version":"0.2.0","users":2}
```

The user count depends on the installation. A successful health response proves that the process and a basic database query respond. It does not validate Google, Turnstile, every S3 object, CloudFront signed delivery, backups, or the complete public workflow.

Use synthetic checks for:

- Public gallery and resource detail.
- Preview launch.
- A controlled downloadable test object.
- Member sign-in in staging.
- Publisher console in staging.
- Backup age and restore-test age.

## Incident response

### Suspected session or local-account compromise

1. Disable the affected user from a separate super-administrator account.
2. Rotate `SESSION_SECRET` when all existing sessions must be invalidated.
3. Restart every application instance.
4. Review login and administrative audit history.
5. Inspect content, revision, user, branding, and entitlement changes.
6. Preserve relevant logs and database backups.
7. Create a replacement staff account when necessary; version 0.2.0 has no built-in password-reset interface.

Changing bootstrap password variables after the account already exists does not replace that account's stored database password.

### Suspected AWS or provider credential exposure

1. Disable or revoke the credential immediately.
2. Contain access before creating a replacement.
3. Update the protected secret store/environment.
4. Restart or redeploy affected services.
5. Review CloudTrail, S3 object versions, Google Cloud/OAuth activity, or Turnstile configuration as applicable.
6. Verify backup and published-object integrity.
7. Record the incident and corrective action.

### Unsafe uploaded package

1. Archive or unpublish the document.
2. Deny/remove the published object when immediate revocation is required.
3. Invalidate affected CloudFront paths where necessary.
4. Preserve a restricted forensic copy only when policy permits.
5. Review publisher access and audit history.
6. Restore or republish a known-good immutable revision.
7. Inform affected users through the portal when needed.

### Database corruption or accidental change

1. Stop writes.
2. Preserve the current database and logs.
3. Identify the latest verified recovery point before the incident.
4. Restore into an isolated environment first.
5. Validate users, current revisions, historical feedback, access flags, and analytics.
6. Restore production in a controlled window.
7. Preserve the damaged state for investigation.

## Priority production upgrades

1. Managed PostgreSQL with automated backup and point-in-time recovery.
2. Managed member/staff identity, verified email, recovery, and MFA.
3. Direct multipart upload into quarantine storage.
4. Malware/content scanning and approval workflow.
5. Signed CloudFront delivery for restricted packages.
6. Distributed rate limiting and abuse controls.
7. Queue-based notifications and analytics ingestion.
8. Central logs, metrics, alerts, and protected audit retention.
9. Separate staging and production environments/accounts.
10. Automated, measured restore testing.
