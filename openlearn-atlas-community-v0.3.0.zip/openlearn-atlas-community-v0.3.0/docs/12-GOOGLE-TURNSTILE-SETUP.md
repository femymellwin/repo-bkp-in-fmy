# 12. Google sign-in and CAPTCHA setup

## What is optional in the Mac build

Version 0.2.0 works without external identity or CAPTCHA services:

- Anonymous visitors can browse open documents.
- Local users can register with a signed arithmetic challenge.
- The bootstrap administrator can sign in with the configured local password.

For a public deployment, configure Google sign-in and Cloudflare Turnstile. Google reduces account friction; Turnstile protects self-registration and anonymous comments. Neither service should be allowed to block anonymous browsing of open catalog content.

## A. Configure Google sign-in

The application uses Google's OpenID Connect authorization-code flow with:

- `openid email profile` scopes.
- A signed state value.
- PKCE using `S256`.
- A short-lived, `HttpOnly` OAuth transaction cookie.
- A verified-email requirement.

Official references:

- Google OpenID Connect: <https://developers.google.com/identity/openid-connect/openid-connect>
- OAuth 2.0 for web server applications: <https://developers.google.com/identity/protocols/oauth2/web-server>
- Google OpenID Connect API reference: <https://developers.google.com/identity/openid-connect/openid-connect#obtainuserinfo>

### 1. Create or select a Google Cloud project

1. Sign in to Google Cloud Console.
2. Create a dedicated project for the learning portal, or select an appropriately governed existing project.
3. Record the project owner and recovery contacts.
4. Restrict project administration to named staff accounts with multifactor authentication.

### 2. Configure the OAuth consent screen

In Google Cloud Console, open the authentication or OAuth consent configuration and provide:

```text
Application name:      Your public portal name
User-support email:    A monitored organization address
Application homepage: https://learn.example.com
Privacy-policy URL:   https://learn.example.com/privacy
Terms URL:            https://learn.example.com/terms
Developer contact:    A monitored technical address
```

Use the smallest scopes required. This build asks only for basic OpenID identity, email, and profile information. It does not request access to Gmail messages, Google Drive, contacts, or calendars.

Depending on Google's current console workflow and whether the application is internal or external, you may need to add test users during development and complete publishing or verification steps before broad public use.

### 3. Create an OAuth client

Create credentials of type:

```text
OAuth client ID -> Web application
```

Use a clear name such as:

```text
OpenLearn Atlas production web
```

Add the exact redirect URI for each environment.

For Mac testing:

```text
http://localhost:3000/auth/google/callback
```

For production:

```text
https://learn.example.com/auth/google/callback
```

The scheme, host, port, path, and trailing-slash behavior must match the application setting exactly. Do not use wildcard redirect URIs.

### 4. Configure `.env`

Copy the generated client ID and client secret into the environment file:

```dotenv
GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-generated-client-secret
GOOGLE_REDIRECT_URI=http://localhost:3000/auth/google/callback
```

For production:

```dotenv
PUBLIC_BASE_URL=https://learn.example.com
GOOGLE_REDIRECT_URI=https://learn.example.com/auth/google/callback
```

Restart the application after changing environment variables.

### 5. Test the account flow

1. Open `/login`.
2. Select **Continue with Google**.
3. Choose a Google account with a verified email address.
4. Complete consent.
5. Confirm that you return to the portal and can open **My Library**.
6. Favorite and follow a resource.
7. Sign out and sign in again; confirm the same account and library are reused.

The database associates the Google subject identifier with a durable portal user. When a local account already has the same normalized email, test the merge behavior in staging before enabling both methods broadly. Maintain a documented support process for identity disputes.

### 6. Production secret handling

Do not commit Google credentials to Git. Store them in one of these locations:

- AWS Secrets Manager or Systems Manager Parameter Store for AWS deployment.
- Encrypted deployment secrets in the selected hosting platform.
- A root-readable production environment file only for the earliest single-server deployment.

Restrict access, audit retrieval, and rotate the secret after suspected exposure. Keep development and production OAuth clients separate.

## B. Configure Cloudflare Turnstile

Turnstile can be used even when the website is not hosted behind Cloudflare's CDN. The visible widget produces a short-lived token, and the application must validate that token server-side before accepting the protected operation.

Official references:

- Turnstile overview: <https://developers.cloudflare.com/turnstile/>
- Server-side validation: <https://developers.cloudflare.com/turnstile/get-started/server-side-validation/>
- Use Turnstile without the Cloudflare CDN: <https://developers.cloudflare.com/turnstile/get-started/>

### 1. Create a Turnstile widget

1. Sign in to the Cloudflare dashboard.
2. Open **Turnstile**.
3. Create a widget for the learning portal.
4. Add the production hostname, such as `learn.example.com`.
5. Add any staging hostname separately.
6. Choose Cloudflare's recommended managed widget mode unless your accessibility or security testing establishes a different requirement.
7. Copy the site key and secret key.

Use Cloudflare's published test keys for automated or non-production testing when appropriate; do not put production secret keys into test fixtures.

### 2. Configure `.env`

```dotenv
TURNSTILE_SITE_KEY=your-public-site-key
TURNSTILE_SECRET_KEY=your-private-secret-key
```

Both values must be present before the application enables Turnstile. The site key is intentionally sent to the browser. The secret key must remain server-side.

Restart the portal, then verify that the Turnstile widget appears on:

- New-account registration.
- Anonymous document comments.

Signed-in comments use the account session and CSRF token instead of asking the member to solve a new challenge for every message.

### 3. Server-side validation in this build

The portal sends the browser token to Cloudflare's `siteverify` endpoint together with the visitor address when available. It rejects:

- Missing or oversized response tokens.
- Network or non-success HTTP responses.
- Tokens that Cloudflare reports as invalid.
- An action value that does not match the protected operation.

Do not remove server-side verification. A browser-only widget is not an authorization decision.

### 4. Failure behavior

When Turnstile is unavailable or fails, registration or anonymous comment submission is rejected with a retry message. Public browsing, previews, downloads allowed by the document's access level, signed-in account use, and administrative operations remain independent.

Decide operationally whether a prolonged Turnstile outage should:

- Keep anonymous submissions closed while browsing remains open; or
- Temporarily switch to another controlled challenge after an administrator changes configuration.

Do not automatically fail open in production.

## C. Local arithmetic challenge

When Turnstile keys are absent, the application creates a signed arithmetic challenge. It is appropriate for Mac acceptance testing, not equivalent to a managed anti-abuse service.

The challenge token:

- Contains the expected answer and action.
- Is signed with `SESSION_SECRET`.
- Expires after 15 minutes.
- Is checked only by the server.

Use a long, random `SESSION_SECRET` even in staging:

```bash
openssl rand -base64 48
```

## D. Launch checklist

Before enabling public registration:

```text
[ ] Production Google redirect URI exactly matches the portal URL
[ ] OAuth consent information and privacy links are complete
[ ] Google client secret is in a secret store, not Git
[ ] Turnstile production hostname is registered
[ ] Turnstile server validation succeeds in staging
[ ] Registration and anonymous-comment rate limits are tested
[ ] Account-disable and premium-entitlement controls are tested
[ ] Last-super-administrator protection is verified
[ ] Security and support contacts are documented
[ ] Privacy notice explains account, anonymous analytics, and comment data
```
