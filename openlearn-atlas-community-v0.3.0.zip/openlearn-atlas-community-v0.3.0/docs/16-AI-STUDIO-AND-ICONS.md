# 16. AI studio and the icon library

## AI studio (`/admin/ai`)

Administrators can configure any of the following providers at runtime; no environment variables or redeploys are needed:

- **Anthropic Claude** (API key + model)
- **OpenAI ChatGPT** (API key + model, optional base-URL override)
- **Azure OpenAI** (API key + resource endpoint + deployment + API version)
- **Google Gemini** (API key + model)
- **Ollama** — free local models (server URL + model)
- **OpenRouter** — free model tier (API key + `:free` model)
- **Groq** — free tier (API key + model)
- **Custom OpenAI-compatible endpoint** (base URL + model, optional key)

Behavior and safety:

- Keys are stored server-side in `portal_settings` and are never rendered back to the browser; the form shows only a masked fingerprint (`sk-a...3456`). Leave a key field blank to keep the saved value.
- **Test connection** performs a real one-prompt round trip and reports latency.
- One provider is marked **default**; it powers AI icon generation and is the hook for future assistant features (summaries, Q&A on resources).
- All calls run from the server with timeouts; nothing is proxied through the visitor's browser.
- Database backups include these settings, so protect backup archives accordingly.

## Icon library (`/admin/icons`)

- **16 built-in icons** now cover the new media kinds (video, document, presentation, dataset, image, diagram, animated flow, and more), drawn as crisp inline SVGs.
- **Generic fallback:** any resource whose icon value no longer resolves automatically shows the generic icon — nothing ever renders broken.
- **Upload SVG icons:** files are sanitized (scripts/handlers/external refs removed) and become selectable on every upload and edit form.
- **Create with AI:** describe the icon, and the default AI provider generates a monochrome 24x24 stroke SVG, which is sanitized, saved to the library, and immediately selectable.
- Deleting a custom icon safely reassigns affected resources to a built-in icon.
