# 1. Mac quick start and acceptance workflow

## What you need

Use either:

- Recommended: Node.js 22.13 or later.
- Alternative: Docker Desktop for Mac.

No separate database installation and no `npm install` are required. The acceptance build uses Node.js built-in SQLite and has no third-party runtime package dependencies.

## Option A: run with Node.js

### Install Node.js

With Homebrew:

```bash
brew install node@22
brew link --overwrite --force node@22
node --version
```

The displayed major version must be 22 or later.

### Verify the release archive

Download the ZIP and matching checksum file into the same folder, then run:

```bash
cd ~/Downloads
shasum -a 256 -c openlearn-atlas-community-v0.2.0.sha256
```

The ZIP line should report `OK`. A missing-file warning is expected for the TGZ line when only the ZIP was downloaded.

### Extract and start

```bash
cd ~/Downloads
unzip openlearn-atlas-community-v0.2.0.zip
cd openlearn-atlas-community-v0.2.0
cp .env.example .env
npm test
npm start
```

Open:

```text
Public portal:   http://localhost:3000
Member sign-in:  http://localhost:3000/login
Publisher login: http://localhost:3000/admin/login
Health check:    http://localhost:3000/health
```

Initial evaluation administrator:

```text
Email:    admin@example.com
Password: ChangeMe123!
```

The first start creates the database and a sample turbofan exploded-view learning package. It can be browsed, previewed, downloaded, verified, commented on, revised, and analyzed immediately.

### Double-click start

Finder can run `start-mac.command`.

1. Double-click `start-mac.command`.
2. When macOS blocks an unnotarized script, right-click it, choose **Open**, then confirm.
3. The script creates `.env` when needed, opens the browser, and starts the portal.
4. Keep the Terminal window open while testing.

Stop with `Control+C`.

## Option B: run with Docker Desktop

1. Install and start Docker Desktop.
2. Extract the release and open Terminal in the folder.
3. Copy the environment template:

```bash
cp .env.example .env
```

4. Start the container:

```bash
docker compose up --build
```

5. Open `http://localhost:3000`.

The `data/` and `backups/` directories are bind-mounted from the Mac. Rebuilding the container does not delete them.

Stop with:

```bash
docker compose down
```

Do not add `-v` during ordinary operation.

## Secure the evaluation administrator

Generate a one-way password hash:

```bash
npm run password-hash -- "Use-a-long-unique-password-here"
```

Put it in `.env` and remove the plaintext value:

```dotenv
ADMIN_NAME=Your Name
ADMIN_EMAIL=your-email@example.com
ADMIN_PASSWORD=
ADMIN_PASSWORD_HASH=scrypt$the-generated-value
```

Generate two independent random secrets:

```bash
openssl rand -base64 48
openssl rand -base64 48
```

Configure:

```dotenv
SESSION_SECRET=first-random-value
PRIVACY_SALT=second-random-value
```

Set these before the first start of a new database. Never commit `.env`.

## Complete acceptance test

### 1. Test public discovery and the compact gallery

1. Open the home page without signing in.
2. Confirm the compact branded banner leaves most of the screen for the gallery.
3. Test keyword search.
4. Filter by category, format, and access level.
5. Open the turbofan resource.

### 2. Test preview, download, share, and analytics

1. Launch the interactive preview.
2. Open it in a new window.
3. Download the package.
4. Like it.
5. Test WhatsApp, LinkedIn, email, device share, and copy-link actions.
6. Later confirm the events in the publisher dashboard.

A share count means that the visitor selected a share method. A public website cannot normally confirm that a private WhatsApp or email message was sent.

### 3. Test SPIN verified

1. On the resource page, choose **I am able to install**.
2. Change the vote to **I am not able to install** and confirm that the existing vote changes instead of adding a second vote.
3. Open the page in another browser profile to create independent evidence.
4. Confirm that the displayed result uses only the current package revision.

Defaults are:

```dotenv
SPIN_VERIFIED_MIN_VOTES=3
SPIN_VERIFIED_THRESHOLD_PERCENT=75
```

### 4. Test anonymous feedback

1. Select **A step is not working**.
2. Enter an anonymous display name and a specific failed-step comment.
3. Complete the arithmetic challenge.
4. Submit the comment.
5. Confirm it appears publicly with the current revision label.

### 5. Test a member account

1. Open `/register`.
2. Create a local account.
3. Sign in.
4. Favorite the turbofan resource.
5. Follow it.
6. Open **My Library** and confirm both states.

Google sign-in appears only after its OAuth credentials are configured. Turnstile replaces the local arithmetic challenge only after both Turnstile keys are configured.

### 6. Test the publisher message box

1. Sign in through `/admin/login`.
2. Open **Messages**.
3. Locate the anonymous failed-step report.
4. Reply as publisher.
5. Mark it resolved.
6. Return to the public document and confirm the thread and status.

### 7. Test immutable revisions

1. Open **Content**, then **Edit / revisions** for the turbofan resource.
2. Upload a corrected HTML file or ZIP as revision `1.1`.
3. Keep it draft and inspect the revision history.
4. Publish revision `1.1`.
5. Confirm `1.1` is current and the former package revision is archived.
6. Confirm the old SPIN votes and comment still identify revision `1.0`.
7. Confirm revision `1.1` starts with an independent SPIN result.
8. Open the member library and confirm the followed resource shows an update.

Do not overwrite an old revision label. Every corrected package should receive a new revision.

### 8. Test access levels

Edit the resource and test:

```text
Open       Anonymous preview and download
Sign-in    Metadata public; package requires a member account
Premium    Metadata public; package requires a premium entitlement
```

Under **Users**, grant the test member premium entitlement and confirm access changes. This release does not charge money or connect to a payment gateway.

### 9. Test multiple staff and user management

1. Open **Users**.
2. Create another named administrator or publisher.
3. Change a member's role, status, or premium entitlement.
4. Confirm a disabled account cannot sign in.
5. Confirm the last active super administrator cannot be disabled or downgraded.

### 10. Test branding

Open **Branding** and change:

- Product name.
- Organization name.
- Product tagline.
- Portal description/tagline.
- Logo image.

Return to the public gallery and sign-in page to confirm the changes.

### 11. Test backup and restore readiness

Create a backup:

```bash
npm run backup
```

Verify the new archive:

```bash
npm run verify-backup -- /full/path/to/backups/learning-portal-YYYYMMDDTHHMMSSZ.tgz
```

Do not perform a restore while the server is running. For a restore rehearsal, make a copy of the entire evaluation folder, stop the copied portal, and run:

```bash
npm run restore -- /full/path/to/backup.tgz --yes
```

## Upload package rules

Supported:

```text
.html
.htm
.zip containing index.html or index.htm
```

Use relative asset links so CSS, JavaScript, images, 3D models, and subfolders resolve under the preview path.

Default evaluation limits:

```dotenv
MAX_UPLOAD_MB=100
MAX_EXTRACTED_MB=300
MAX_ZIP_FILES=3000
```

The ZIP validator rejects encrypted archives, ZIP64, symbolic links, absolute paths, parent-directory traversal, duplicate filenames including case-only duplicates, invalid CRC values, excessive file counts, and excessive expanded size.

## Local data and safe upgrades

Runtime state is deliberately separated from source:

```text
data/portal.sqlite      Users, documents, revisions, comments, votes, analytics, settings
data/storage/           Local packages, previews, thumbnails, and uploaded logo
backups/                Verified backup archives
.env                    Passwords, keys, and deployment configuration
```

Before every upgrade:

```bash
npm run backup
npm run verify-backup -- /full/path/to/new-backup.tgz
npm test
```

Upgrade into a separate source folder. Retain the old installation and verified backup until the new release passes acceptance. See `docs/14-UPGRADE-FROM-V0.1.md` for the version 0.1.0 migration.

## Common issues

### Port 3000 is already in use

Change `.env`:

```dotenv
PORT=3100
PUBLIC_BASE_URL=http://localhost:3100
GOOGLE_REDIRECT_URI=http://localhost:3100/auth/google/callback
```

### The browser shows an old page

Use `Command+Shift+R` for a hard refresh.

### A ZIP is rejected

Confirm that it:

- Contains `index.html` or `index.htm`.
- Is not encrypted or ZIP64.
- Has no symbolic links, absolute paths, or `../` paths.
- Has no duplicate filenames when case is ignored.
- Remains within the configured limits.

### Google sign-in is not visible

Both `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` must be configured, and the redirect URI must exactly match the Google Cloud OAuth client.

### Turnstile is not visible

Both `TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY` must be configured. With neither, local testing intentionally uses the arithmetic challenge.

### Premium content still appears in search

This is expected. Catalog metadata remains discoverable; preview and download are gated. Change the entire document to draft or archived when it should not be discoverable.

### Preview JavaScript behaves differently

Uploaded HTML runs in an iframe sandbox. It cannot access publisher cookies or the parent page. A package that depends on unrestricted top-level navigation, third-party cookies, browser extensions, or unsafe same-origin access must be adapted.
