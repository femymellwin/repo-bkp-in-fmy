# 3. Affordable AWS deployment

## Recommended first production topology

```text
Visitors
   |
   +--> https://learn.example.com
   |        |
   |        +--> Caddy HTTPS reverse proxy
   |                  |
   |                  +--> Docker container: Node.js portal + SQLite
   |                              |
   |                              +--> S3 content bucket
   |                              +--> S3 backup bucket
   |
   +--> https://content.example.com
            |
            +--> CloudFront
                    |
                    +--> private S3 content bucket through OAC
```

This is the economical single-server launch topology. It is economical and easy to recover, but it is not multi-instance high availability. CloudFront and S3 remain distributed services; the portal application itself is one persistent server.

## Which server option to choose

### Option 1: Lightsail - lowest cost and easiest

Choose this for the initial public launch when predictable price is the highest priority.

- Select a Linux plan with at least 1 GB RAM. The smallest plan can be tight during Docker image builds and large ZIP extraction.
- Mumbai `ap-south-1` is a practical nearby Lightsail Region for UAE-based administration and global CloudFront delivery.
- Enable daily automatic snapshots.
- Use the restricted IAM application key described in the AWS account guide.

### Option 2: EC2 in the UAE Region - better credential security and data locality

Choose this when UAE data residency or temporary IAM role credentials are more important than the simplest bill.

- Region: Middle East (UAE), `me-central-1`.
- Use a small burstable instance, an encrypted EBS volume, and an EC2 IAM role.
- Attach the CloudFormation-generated S3 policies to the instance role.
- Configure EBS snapshots with Data Lifecycle Manager.
- Use the AWS Pricing Calculator before launch because EC2, EBS, and public IPv4 are billed separately.

The supplied Docker deployment is the same on either server.

## A. Put the source in a private GitHub repository

Complete the GitHub guide first. The server should clone from a private repository using a read-only deploy key.

On the server, generate a deploy key:

```bash
ssh-keygen -t ed25519 -C "openlearn-atlas-production" -f ~/.ssh/openlearn_atlas_deploy -N ""
cat ~/.ssh/openlearn_atlas_deploy.pub
```

In GitHub:

1. Open the repository.
2. Choose **Settings** > **Deploy keys** > **Add deploy key**.
3. Paste the public key.
4. Name it `production-server-read-only`.
5. Do not enable write access.

Create an SSH config entry on the server:

```bash
cat >> ~/.ssh/config <<'CONFIG'
Host github-openlearn
  HostName github.com
  User git
  IdentityFile ~/.ssh/openlearn_atlas_deploy
  IdentitiesOnly yes
CONFIG
chmod 600 ~/.ssh/config
ssh-keyscan github.com >> ~/.ssh/known_hosts
```

Clone using the repository's SSH path, replacing the owner and repository name:

```bash
sudo mkdir -p /opt/openlearn-atlas
sudo chown "$USER":"$USER" /opt/openlearn-atlas
git clone git@github-openlearn:OWNER/REPOSITORY.git /opt/openlearn-atlas
cd /opt/openlearn-atlas
```

Verify the GitHub host key fingerprint independently before relying on `ssh-keyscan` in a high-security environment.

## B. Create a Lightsail instance

1. Open `https://lightsail.aws.amazon.com/` using your AWS administrator identity.
2. Choose **Create instance**.
3. Select a supported Region close to your users, for example Mumbai.
4. Platform: **Linux/Unix**.
5. Blueprint: **OS Only**, then the latest Ubuntu LTS offered.
6. Select a plan with at least 1 GB RAM.
7. Name: `openlearn-atlas-production`.
8. Create the instance.
9. Open the instance's **Networking** tab.
10. Create and attach a **Static IP**.
11. Firewall rules:

```text
TCP 22   Your own current public IP only, where possible
TCP 80   Anywhere
TCP 443  Anywhere
```

12. Open the **Snapshots** tab and enable **Automatic snapshots**.
13. Select a daily snapshot time that does not overlap the application backup.

Lightsail retains the latest seven automatic snapshots. Copy one automatic snapshot to a manual snapshot monthly if you need longer retention; automatic snapshots are deleted when the source resource is deleted.

## C. Install Docker and Caddy

Connect with the browser-based SSH terminal or your own SSH client.

Update the operating system:

```bash
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install -y ca-certificates curl git ufw
```

Install Docker Engine:

```bash
curl -fsSL https://get.docker.com -o /tmp/get-docker.sh
sudo sh /tmp/get-docker.sh
rm /tmp/get-docker.sh
sudo usermod -aG docker "$USER"
```

Sign out and sign back in, then verify:

```bash
docker version
docker compose version
```

Install Caddy from its official Ubuntu repository, or use the instructions at `https://caddyserver.com/docs/install#debian-ubuntu-raspbian`.

The build includes:

```text
infra/aws/caddy/Caddyfile.example
```

Copy it:

```bash
sudo cp infra/aws/caddy/Caddyfile.example /etc/caddy/Caddyfile
sudo sed -i 's/learn.example.com/learn.your-real-domain.com/g' /etc/caddy/Caddyfile
sudo caddy validate --config /etc/caddy/Caddyfile
sudo systemctl restart caddy
sudo systemctl enable caddy
```

Caddy obtains and renews the HTTPS certificate after DNS points to the server and ports 80 and 443 are open.

## D. Configure DNS for the portal server

Create a DNS record for `learn.example.com`:

```text
Type: A
Name: learn
Value: Lightsail static IPv4 address
TTL: 300 during setup
```

If using Route 53, create this in the domain's public hosted zone. If using an external registrar, create it there.

Check propagation from your Mac:

```bash
dig +short learn.example.com
```

The output must match the static IP.

## E. Create the production environment file

On the server:

```bash
cd /opt/openlearn-atlas
cp .env.example .env
docker compose build portal
docker compose run --rm --no-deps portal npm run password-hash -- "replace-this-with-a-long-unique-password"
openssl rand -base64 48
openssl rand -base64 48
```

Edit `.env`:

```dotenv
PORT=3000
HOST=0.0.0.0
PUBLIC_BASE_URL=https://learn.example.com
NODE_ENV=production

PORTAL_NAME=OpenLearn Atlas
PORTAL_TAGLINE=Interactive knowledge, open to everyone.

ADMIN_EMAIL=your-private-admin-email@example.com
ADMIN_PASSWORD=
ADMIN_PASSWORD_HASH=scrypt$paste-generated-value
SESSION_SECRET=paste-first-random-value
PRIVACY_SALT=paste-second-random-value

MAX_UPLOAD_MB=100
MAX_EXTRACTED_MB=300
MAX_ZIP_FILES=3000

STORAGE_DRIVER=s3
DATA_DIR=./data
BACKUP_DIR=./backups
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=paste-only-for-lightsail
AWS_SECRET_ACCESS_KEY=paste-only-for-lightsail
AWS_SESSION_TOKEN=
CONTENT_S3_BUCKET=paste-CloudFormation-output
BACKUP_S3_BUCKET=paste-CloudFormation-output
CDN_BASE_URL=https://content.example.com
S3_PREFIX=portal

BACKUP_RETENTION_COUNT=30
AUTO_BACKUP=true
AUTO_BACKUP_HOUR_UTC=2
```

For EC2 with an instance role, leave the three AWS credential variables empty.

Protect the file:

```bash
chmod 600 .env
```

Never copy the production `.env` back to your Mac source folder or Git repository.

## F. Start the portal

```bash
cd /opt/openlearn-atlas
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 portal
curl -fsS http://127.0.0.1:3000/health
```

The health response should report `ok: true` and `storage: s3`.

Then open:

```text
https://learn.example.com
https://learn.example.com/admin/login
```

Create a small test upload before moving production material.

## G. Validate backups before launch

Create and verify a backup:

```bash
cd /opt/openlearn-atlas
docker compose exec -T portal npm run backup
ls -lh backups
docker compose exec -T portal sh -lc 'LATEST=$(ls -1t /app/backups/*.tgz | head -n 1); npm run verify-backup -- "$LATEST"'
```

Confirm in the S3 console that both the `.tgz` file and `.sha256` file exist under the backup bucket's `portal/backups/` prefix.

Enable and verify Lightsail automatic snapshots separately. An application backup and an instance snapshot protect different failure modes; use both.

## H. Production update procedure

Never deploy directly from an unreviewed branch. Deploy a signed or reviewed release tag.

```bash
cd /opt/openlearn-atlas
git fetch --tags --prune
git status --short
docker compose exec -T portal npm run backup
git checkout v0.2.0
docker compose build --pull
docker compose up -d
docker compose ps
curl -fsS http://127.0.0.1:3000/health
```

After the health check:

1. Open the public catalog.
2. Open an interactive preview.
3. Download a package.
4. Sign in to the publisher dashboard.
5. Confirm that users, revisions, comments, SPIN votes, favorites/follows, branding, analytics, and existing content remain present.

The `data/`, `backups/`, and `.env` paths are not part of the Git checkout and are bind-mounted into the container. Replacing the application image does not replace those paths.

## I. Rollback procedure

For a code-only problem, check out the previous tag and rebuild:

```bash
cd /opt/openlearn-atlas
git checkout v0.1.0
docker compose up -d --build
curl -fsS http://127.0.0.1:3000/health
```

For a database migration problem:

1. Stop the portal.
2. Restore the backup created immediately before deployment.
3. Check out the previous application tag.
4. Start the portal and validate it.

Do not assume that older application code can safely read a database after a future one-way migration.

## J. Basic server hardening

1. Keep Ubuntu, Docker, and Caddy patched.
2. Restrict SSH to your IP or use the Lightsail browser terminal.
3. Use an SSH key; disable password authentication.
4. Keep `.env` mode `600`.
5. Do not run the application container as root; the supplied Dockerfile uses the `node` user.
6. Keep S3 Block Public Access enabled.
7. Keep root-user MFA and GitHub MFA enabled.
8. Review IAM access keys every month and rotate the Lightsail application key periodically.
9. Review AWS costs and security notifications every month.
10. Test a restore quarterly.

## K. Initial monthly cost expectation

The exact amount depends on Region, storage, snapshots, DNS, and traffic. A small initial deployment generally consists of:

```text
Lightsail Linux server           About USD 7/month for a 1 GB public-IPv4 bundle; Region pricing can vary
CloudFront flat-rate Free plan   USD 0/month if the account/distribution is eligible
CloudFront flat-rate Pro plan    USD 15/month when its features/allowances are needed
S3 content and backup storage    Usage based, partly offset by plan credits where applicable
Lightsail snapshots              USD 0.05 per stored GB-month
Route 53                         May be covered when associated with a flat-rate plan; otherwise usage based
Domain registration              Annual, varies by TLD
```

A realistic first target is roughly USD 7 to 20 per month plus the domain, storage, and snapshots. Select the CloudFront Free flat-rate plan when eligible; otherwise use pay-as-you-go and keep a strict budget. Check the first two invoices carefully.

## L. When to move beyond one server

Move metadata and analytics from SQLite to managed PostgreSQL before any of the following:

- Multiple application instances.
- Frequent concurrent publisher uploads.
- A large editorial team.
- Millions of monthly analytics events.
- Strict high-availability requirements.
- Zero-downtime schema migrations.

At that point, use ECS/Fargate or EC2 Auto Scaling for the application, RDS PostgreSQL for data, S3 direct multipart uploads, and an identity provider with MFA.
