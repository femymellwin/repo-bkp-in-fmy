# 11. Community, access, and revision workflow

## Purpose

OpenLearn Atlas treats each learning resource as a long-lived document with immutable package revisions. Community feedback is never detached from the exact package a visitor tested.

The core relationship is:

```text
Document
  |
  +-- Revision 1.0 (archived after replacement)
  |      +-- SPIN votes for 1.0
  |      +-- comments and publisher replies for 1.0
  |
  +-- Revision 1.1 (current published revision)
         +-- independent SPIN votes for 1.1
         +-- comments and publisher replies for 1.1
```

Metadata such as the title, summary, category, tags, access level, and branding belongs to the stable document. The HTML or ZIP package, package filename, preview entry point, publication date, and verification result belong to a revision.

## SPIN verified behavior

A published resource can expose two choices:

```text
I am able to install
I am not able to install
```

The result is calculated only from votes on the current revision. The default status rules are controlled in `.env`:

```dotenv
SPIN_VERIFIED_MIN_VOTES=3
SPIN_VERIFIED_THRESHOLD_PERCENT=75
```

With those defaults:

- Fewer than three votes shows that more community evidence is needed.
- Three or more votes and at least 75 percent successful votes marks the revision as SPIN verified.
- Three or more votes below the threshold shows that the revision needs attention.

A signed-in member has one vote per revision. An anonymous browser also has one vote per revision through its first-party anonymous visitor identifier. Voting again changes that visitor's existing choice rather than creating an additional vote.

Publishing revision 1.1 does not copy the result from revision 1.0. This is intentional: community verification must evaluate the revised package, not inherit confidence from an older package.

## Public comments and the publisher message box

Visitors can submit one of four feedback types:

- A step is not working.
- Suggested improvement.
- Question.
- General comment.

Signed-in members post under their account name. Anonymous visitors provide a display name and complete the configured human-verification challenge.

Every top-level message records:

```text
Document ID
Revision ID and revision label
Author identity or anonymous display name
Feedback type
Body
Open/resolved status
Creation and update timestamps
```

Staff open **Publisher console > Messages** to see the document inbox. A publisher, moderator, administrator, or super administrator can:

- Filter open or resolved conversations.
- Read the exact document and revision involved.
- Reply in a public thread.
- Mark the top-level issue resolved.
- Reopen a resolved issue.

A publisher reply remains attached to the same revision as the original message. Publishing a replacement does not rewrite old conversations.

## Recommended editorial resolution process

Use this sequence for a reported problem:

1. Confirm the feedback and reproduce the issue against the revision shown in the message.
2. Reply with acknowledgement or a workaround when useful.
3. Prepare a corrected HTML or ZIP package outside the portal.
4. Open **Publisher console > Edit / revisions** for the document.
5. Upload a new, unique revision label such as `1.1` or `2026.09`.
6. Leave it as draft while another staff member tests it, or publish it immediately when your governance permits.
7. Publish the approved revision.
8. Confirm the new revision is current and the former published revision is archived.
9. Reply to the original message with the new revision number.
10. Mark the conversation resolved.
11. Monitor the new revision's independent SPIN result.

Do not replace files underneath an existing revision label. A correction should always create a new immutable revision so that downloads, analytics, votes, comments, and audit records remain interpretable.

## Revision states

Package revisions use these states:

```text
Draft       Uploaded but not public
Published   The one current package for the document
Archived    Retained historical package
```

Publishing is transactional. The application:

1. Verifies that the selected revision belongs to the document.
2. Archives older non-archived revisions.
3. Marks the selected revision published.
4. Updates the document's current revision pointer and visible version label.
5. Marks followers as having a newer revision available.
6. Writes an audit record.

The stable document has its own lifecycle:

```text
Draft       Not in the public catalog
Published   Listed in the public catalog
Archived    Removed from ordinary public discovery but retained
```

A published document must have a current published package revision before its preview or download can be used.

## Access levels

Each document has one of three access levels:

| Access flag | Catalog/detail page | Preview and download |
|---|---|---|
| Open | Anonymous | Anonymous |
| Sign-in | Anonymous metadata | Signed-in account |
| Premium | Anonymous metadata | Signed-in account with premium entitlement |

Administrators and publishing staff can inspect restricted resources while performing their duties.

The premium flag in version 0.2.0 is an entitlement control, not a billing system. An administrator can grant or remove premium entitlement under **Users**. Before charging money, integrate a payment provider through signed webhooks, use an idempotent subscription ledger, and reconcile provider status instead of trusting browser callbacks.

## Favorites and follows

Signed-in members can:

- **Favorite** a resource to keep it in **My Library**.
- **Follow** a resource to see whether a newer revision has been published since they last opened it.

Following is document-level. A member does not need to follow each revision separately. Opening the document updates the member's last-seen revision.

Version 0.2.0 shows revision-change state in the member library. It does not send email notifications. Email or push delivery can be added later through an outbox/queue so publication is never blocked by a notification provider.

## Roles and permissions

The available roles are:

| Role | Intended responsibility |
|---|---|
| Super administrator | Ownership, user administration, branding, publication, moderation, backups |
| Administrator | Branding, publication, moderation, and backups |
| Publisher | Create/edit documents and upload/publish revisions |
| Moderator | Review, reply to, resolve, and reopen community messages |
| Member | Favorites, follows, account-bound voting, and ordinary participation |

The application prevents the final active super administrator from being disabled or downgraded. Use separate named staff accounts; do not share one administrator password.

## Branding workflow

Authorized administrators can change:

- Product or portal name.
- Organization name.
- Product tagline.
- Portal description/tagline.
- Logo image.

Branding is stored in the database and local/S3 storage, not compiled into page templates. The current green and amber visual system remains the default; a future release can add controlled theme tokens without allowing arbitrary untrusted CSS.

## Audit and retention expectations

Administrative changes produce audit records. Historical revisions, comments, votes, and package keys are retained rather than silently overwritten.

Before adding permanent deletion controls, define:

- Who may approve deletion.
- Minimum archive and backup retention.
- Legal-hold and privacy handling.
- S3 object-version retention.
- CloudFront invalidation and signed-link expiry.
- Recovery window and audit evidence.

For ordinary editorial work, archive rather than delete.
