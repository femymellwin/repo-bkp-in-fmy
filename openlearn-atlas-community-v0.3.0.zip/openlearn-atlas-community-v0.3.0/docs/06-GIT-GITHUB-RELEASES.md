# 6. GitHub security, code backup, and releases

## Repository policy

Use a **private GitHub repository** for this project. The repository should contain application code, documentation, tests, infrastructure templates, and release workflows. It must not contain runtime data or secrets.

The supplied `.gitignore` excludes:

```text
.env and other local environment files
data/ runtime database and local uploads
backups/ backup archives
release/ generated packages
log and operating-system files
```

Check before every first push:

```bash
git status --ignored
```

Confirm that `.env`, `portal.sqlite`, uploads, and backup archives are shown as ignored and are not staged.

## A. Create the private repository

### GitHub web interface

1. Sign in to GitHub.
2. Enable two-factor authentication or a passkey.
3. Store GitHub recovery codes in a password manager.
4. Choose **New repository**.
5. Name it, for example `openlearn-atlas`.
6. Select **Private**.
7. Do not initialize it with another README, license, or `.gitignore` because the build already contains them.
8. Create the repository.

### Push this build from the Mac

In the project folder:

```bash
git init -b main
git add .
git status
git commit -m "Initial OpenLearn Atlas community platform"
git remote add origin git@github.com:OWNER/REPOSITORY.git
git push -u origin main
```

Before `git add .`, delete the local `.env` if it contains anything beyond demonstration values. `.gitignore` protects it, but it is still better not to keep production secrets in the source working folder.

## B. Secure the repository

Configure these controls:

1. Require MFA for every collaborator.
2. Give access only to people who need it.
3. Use the least privileged repository role.
4. Enable GitHub secret scanning and push protection where available.
5. Enable Dependabot security updates for GitHub Actions.
6. Review installed GitHub Apps and OAuth applications.
7. Do not use a personal access token on the production server when a read-only deploy key is sufficient.
8. Never paste production `.env` values into issues, pull requests, Actions logs, or screenshots.

The repository includes `.github/dependabot.yml` to monitor workflow action versions.

## C. Protect the `main` branch

In **Settings** > **Branches** or **Rules**:

1. Create a rule for `main`.
2. Require a pull request before merging.
3. Require at least one approval when another trusted reviewer is available.
4. Dismiss stale approvals when new commits are pushed.
5. Require the `test` status check.
6. Require conversations to be resolved.
7. Block force pushes.
8. Block branch deletion.
9. Require signed commits if your workflow supports them.
10. Restrict direct pushes to repository administrators or, preferably, to nobody.

Some private-repository protection features depend on the selected GitHub plan. Use every available control and retain the pull-request discipline even if a specific enforcement option is unavailable.

## D. Continuous integration

The supplied workflow is:

```text
.github/workflows/ci.yml
```

It runs on pull requests and pushes to `main` and performs:

```text
Node.js version setup
JavaScript syntax checks
Automated portal workflow tests
A check that forbidden runtime files are not tracked
```

Do not merge a change while CI is failing.

## E. Versioning policy

Use semantic version tags:

```text
v0.1.0   Initial catalog and analytics release
v0.2.0   Community, accounts, access, revisions, and branding
v0.2.1   Backward-compatible bug or security fix
v0.3.0   Backward-compatible feature release
v1.0.0   First production-stable contract
v2.0.0   Intentional breaking change
```

Maintain `CHANGELOG.md` with:

```text
Added
Changed
Fixed
Security
Database migration notes
Backup or restore notes
Known limitations
```

Every release that changes the database must state whether rollback requires restoring a pre-upgrade backup.

## F. Create a release

1. Update `package.json` version and `CHANGELOG.md`.
2. Run locally:

```bash
npm test
npm run backup
```

3. Open a pull request and let CI pass.
4. Merge to `main`.
5. Create an annotated tag:

```bash
git checkout main
git pull --ff-only
git tag -a v0.2.0 -m "OpenLearn Atlas v0.2.0"
git push origin v0.2.0
```

6. The supplied release workflow packages the Git-tracked source, writes a SHA-256 checksum, and creates a GitHub Release.
7. Download and verify the release package before deploying it.

## G. Deployment environments

For future automatic deployment, create GitHub environments:

```text
staging
production
```

For `production`:

- Restrict deployment to release tags or the `main` branch.
- Require an approval where the GitHub plan supports it.
- Prevent the person who initiated the deployment from self-approving where possible.
- Store deployment-only secrets in the environment, not in repository variables.
- Prefer OpenID Connect and temporary cloud credentials over static AWS keys.

The supplied release intentionally does not auto-deploy to your production server. Manual tag deployment is safer while you are learning the operating process.

## H. Safe upgrade sequence

Use this exact order:

```text
1. Review release notes and migration notes.
2. Create and verify an application backup.
3. Confirm an off-site copy exists.
4. Confirm a recent server snapshot exists.
5. Deploy a tagged release, never an arbitrary working tree.
6. Run the health check.
7. Test catalog, preview, download, admin, analytics, and backup.
8. Record the deployed tag and operator.
9. Keep the previous release package available.
```

Do not delete old S3 objects or old database fields as part of the same release that introduces replacements. Use staged migrations:

```text
Release A: add new structure and write both old and new formats
Release B: migrate and verify historical data
Release C: stop using old structure
Later release: remove old structure after retention and rollback windows expire
```

## I. Code backup outside GitHub

GitHub is the collaboration system, not the only backup.

Create a mirror periodically:

```bash
git clone --mirror git@github.com:OWNER/REPOSITORY.git openlearn-atlas.git
cd openlearn-atlas.git
git fsck --full
cd ..
tar -czf openlearn-atlas-git-mirror-$(date +%Y%m%d).tgz openlearn-atlas.git
shasum -a 256 openlearn-atlas-git-mirror-*.tgz > openlearn-atlas-git-mirror.sha256
```

Store the encrypted mirror in a second location. A Git mirror still does not contain the production database, S3 content, GitHub issue attachments, or production secrets.

## J. Secret exposure response

If a secret is committed, adding it to `.gitignore` or deleting the visible line is not enough.

Immediately:

1. Revoke or rotate the secret at its provider.
2. Stop affected deployment processes if necessary.
3. Review access logs and CloudTrail.
4. Remove the secret from the current code.
5. Purge it from Git history using an appropriate history-rewrite tool.
6. Force-update only after coordinating with every clone owner.
7. Record the incident and corrective actions.
8. Add a prevention check.

Treat every committed secret as compromised, even in a private repository.

## K. Release record template

```text
Release tag:
Commit SHA:
Release date:
Approved by:
Backup filename and checksum:
Server snapshot:
Database migration version:
Deployment start/end:
Health check:
Public workflow test:
Admin workflow test:
Rollback required:
Issues:
Operator:
```

## Official references

- GitHub branch protection: `https://docs.github.com/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches`
- GitHub deployments and environments: `https://docs.github.com/actions/reference/deployments-and-environments`
- GitHub encrypted secrets: `https://docs.github.com/actions/security-guides/using-secrets-in-github-actions`
