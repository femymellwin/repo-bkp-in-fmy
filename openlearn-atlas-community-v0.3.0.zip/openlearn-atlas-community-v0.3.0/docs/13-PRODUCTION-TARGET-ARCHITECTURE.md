# 13. Large-scale production target architecture

## Executive decision

Version 0.2.0 is the Mac acceptance build and a valid single-server reference implementation. For a large public platform, preserve its product model but replace single-node infrastructure with managed AWS services.

The production product model to preserve is:

```text
Anonymous public discovery
Optional member accounts
Open / sign-in / premium access
Stable documents with immutable revisions
Revision-specific SPIN votes and comments
Publisher replies and resolution
Favorites and follows
Multiple staff roles
First-party analytics
Audited administration
```

Do not rebuild these concepts differently in every deployment tier. Change the storage, identity, delivery, queueing, and operational components behind stable application interfaces.

## Recommended AWS target

```text
                                      Internet
                                         |
                                   Route 53 DNS
                                         |
                              CloudFront + AWS WAF
                       +-----------------+-----------------+
                       |                                   |
                 Application behavior                Content behavior
                       |                                   |
                Application Load Balancer              Private S3
                       |                            published packages
              ECS/Fargate service (2+ tasks)            via OAC
                       |
          +------------+------------+----------------+
          |                         |                |
     RDS PostgreSQL             SQS/EventBridge   ElastiCache/Valkey
     Multi-AZ/PITR              background work   rate/cache controls
          |                         |
          |                    worker service
          |                 validation/scanning
          |
     durable application data

Supporting services:
  Cognito + Google federation
  S3 quarantine, published, backup, and analytics buckets
  Secrets Manager / Parameter Store
  ECR container registry
  CloudWatch logs, metrics, alarms, and audit dashboards
  CloudTrail and AWS Config
  GitHub Actions OIDC -> AWS deployment role
  Payment provider webhook -> entitlement ledger (future)
```

This design removes the single application server and SQLite write constraint while retaining inexpensive S3/CloudFront delivery for large HTML, ZIP, image, and model assets.

## Request and content-delivery paths

### Public application pages and API

```text
Browser -> CloudFront -> ALB -> healthy ECS task -> PostgreSQL
```

CloudFront can cache safe anonymous GET responses selectively. Do not cache authenticated HTML or mutation responses unless the cache key and headers are explicitly designed for it.

### Open package delivery

```text
Browser -> CloudFront -> private published S3 bucket through Origin Access Control
```

The S3 bucket should block public access. CloudFront is the public delivery surface.

### Sign-in and premium package delivery

```text
Browser -> application entitlement check -> short-lived CloudFront signed URL/cookie
        -> CloudFront -> private S3 object
```

A normal permanent CDN URL is insufficient for restricted packages because it can be copied around the application. The application must check account and entitlement status before creating a short-lived signed delivery grant.

Official AWS references:

- Private content and Origin Access Control: <https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-overview.html>
- CloudFront signed URLs: <https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-signed-urls.html>

### Interactive HTML isolation

Use a dedicated host such as:

```text
content.example.com
```

Keep publisher/admin sessions on:

```text
learn.example.com
```

Interactive content should load inside a sandboxed iframe. Apply a content-specific response-header policy and Content Security Policy. Never give uploaded package JavaScript access to application cookies, staff credentials, or same-origin administrative APIs.

## Data model in PostgreSQL

Migrate the SQLite tables into PostgreSQL while preserving identifiers and timestamps. Core tables should include:

```text
users
external_identities
roles / user_roles
subscriptions / entitlements
content_documents
content_versions
install_votes
comments
favorites
follows
analytics_events
analytics_daily_aggregates
portal_settings
asset_objects
outbox_messages
schema_migrations
audit_log
```

Production refinements:

- Use database constraints for exactly one current published revision per document.
- Use foreign keys without broad cascade deletion on historical evidence.
- Store timestamps in UTC.
- Use optimistic concurrency or row versions for editorial updates.
- Use an append-only audit design for security-sensitive changes.
- Use an idempotency key for payment webhooks, uploads, and publication commands.
- Partition or archive raw analytics events as volume grows.
- Keep access entitlement history instead of only the current premium flag.

PostgreSQL full-text search is sufficient initially. Add a managed search service only after measured relevance, indexing, language, or scale requirements justify the additional cost.

## Managed identity

For the large-scale AWS target, use Amazon Cognito user pools or another managed identity provider rather than maintaining all credential lifecycle functions inside the application.

Recommended split:

```text
Anonymous visitors  No account required for open content
Members             Google or verified-email account
Publishers           Managed account + MFA
Administrators       Managed account + MFA + least privilege
Super administrators Separate named accounts + stronger recovery controls
```

Amazon Cognito can federate with Google and other OIDC/SAML identity providers. Keep application roles and entitlements in the application database even when authentication is delegated, because publishing authority and premium access are product rules rather than merely identity-provider groups.

Official AWS reference:

- Cognito identity providers: <https://docs.aws.amazon.com/cognito/latest/developerguide/cognito-user-pools-identity-provider.html>

## Upload and publication pipeline

Do not stream very large untrusted packages through the public web task in the final architecture.

Use this sequence:

```text
Publisher requests an upload session
  |
  +-- application checks publisher permission
  +-- creates draft revision and presigned multipart upload
  v
Browser uploads directly to S3 quarantine prefix
  |
  +-- S3 event -> SQS
  v
Worker validates package
  +-- archive traversal and decompression limits
  +-- file-type and extension policy
  +-- malware scan
  +-- static inspection of HTML/JavaScript and external endpoints
  +-- preview entrypoint detection
  +-- checksums and asset inventory
  v
Review status
  +-- rejected -> quarantine with reason
  +-- approved -> immutable copy to published prefix
  v
Publisher publishes revision
  +-- one database transaction changes current revision
  +-- audit record
  +-- cache invalidation only where necessary
  +-- follower notification placed in outbox
```

Use object keys that include immutable version identifiers, for example:

```text
published/documents/<document-id>/versions/<version-id>/package.zip
published/documents/<document-id>/versions/<version-id>/preview/index.html
```

Do not overwrite published objects in place. A new package gets a new version ID and object prefix.

## Community workflow at scale

### SPIN votes

Enforce one vote per account or anonymous identity per revision with a unique database constraint. Keep anonymous-identification data pseudonymous and rotate or retain it according to the privacy policy.

Add defenses based on measured abuse:

- WAF/rate rules.
- Distributed rate limits.
- Suspicious-volume detection.
- Bot and duplicate-pattern reporting.
- Staff exclusion from public trust calculations when appropriate.

Do not silently remove negative votes to improve a score. Moderation should address abusive identities or invalid traffic with an auditable action.

### Comments

Use a moderation state machine such as:

```text
open -> under_review -> resolved
  |          |
  +------> hidden (policy action)
```

Keep edit history when public comment editing is later added. Sanitize rendered content and continue treating messages as plain text unless a rigorously sanitized markup format is introduced.

### Notifications

Version 0.2.0 shows follow state in the portal. At scale, publish domain events to an outbox and queue:

```text
revision_published
comment_replied
comment_resolved
premium_entitlement_changed
```

A worker can then send optional email, web push, or in-app notifications. The publication transaction should succeed even when the notification provider is temporarily unavailable.

## Premium and payments

Keep document access and payment processing separate.

```text
Payment provider -> signed webhook -> idempotent event ledger
                 -> entitlement projection -> application access check
```

Required controls before accepting payment:

- Provider signature verification.
- Idempotency and replay protection.
- Subscription and refund history.
- Grace-period and cancellation rules.
- Reconciliation job.
- Tax, invoice, refund, privacy, and consumer-law review.
- Customer-support tools.

Never grant premium access solely because a browser redirects to a success page.

## Analytics architecture

### Economical initial production

Store first-party events in PostgreSQL with daily aggregate jobs. Apply retention to raw IP-derived or visitor-level data.

### Higher event volume

Move ingestion off the request path:

```text
Application/API -> queue or stream -> object storage data lake
                              +----> aggregate worker -> reporting database
```

Possible AWS implementation:

```text
API -> Kinesis Data Firehose or SQS -> S3 partitioned events
                                    -> Glue/Athena or warehouse
                                    -> dashboard
```

Keep operational counters in PostgreSQL for fast document pages. Treat detailed analytics as eventually consistent. Continue distinguishing a share-button click from a confirmed private-message send.

## Backup and disaster recovery

### Database

Use RDS automated backups with point-in-time recovery and retain manual snapshots for release and long-term recovery requirements. Test restore into a separate database instance rather than assuming a snapshot is usable.

Official AWS reference:

- RDS automated backups and point-in-time recovery: <https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_WorkingWithAutomatedBackups.html>

### S3 assets

Enable:

- Versioning.
- Server-side encryption.
- Lifecycle policies.
- Separate quarantine, published, and backup responsibilities.
- Cross-account or cross-Region replication when the recovery objective requires it.
- Object Lock on a deliberately created backup bucket when immutable retention is required.

The production database remains the authoritative mapping between documents, immutable revisions, and S3 object checksums. S3 object existence alone is not a complete application backup.

### Configuration and source

Protect:

- Infrastructure as code in a private repository.
- Container images in ECR with immutable release tags/digests.
- Secrets in a managed secret store.
- DNS and certificate recovery procedures.
- Database migrations and rollback notes.
- A release inventory tying code commit, container digest, migration version, and backup identifier together.

### Recovery objectives

Before launch, choose explicit values:

```text
RPO: Maximum acceptable amount of recent data loss
RTO: Maximum acceptable recovery time
```

Then prove them through scheduled exercises. A backup policy without measured restoration is incomplete.

## Secure delivery and release management

Use separate AWS accounts or strongly isolated environments for development, staging, and production.

Recommended release path:

```text
Pull request
  -> tests, linting, security checks
  -> build container once
  -> sign/record image digest
  -> deploy same image to staging
  -> database migration rehearsal
  -> acceptance tests
  -> production approval
  -> pre-deployment snapshot/backup
  -> rolling or blue/green deployment
  -> smoke tests and metrics gate
  -> post-deployment recovery marker
```

Use GitHub Actions OpenID Connect to assume a narrowly scoped AWS deployment role instead of storing long-lived AWS access keys in GitHub secrets.

Official GitHub reference:

- GitHub Actions OIDC for AWS: <https://docs.github.com/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-aws>

Database migration rules:

1. Use append-only numbered migrations.
2. Rehearse against a restored production-sized copy.
3. Prefer expand-and-contract changes.
4. Do not combine irreversible deletion with the first release that stops using a field.
5. Keep application versions compatible during rolling deployment.
6. Record row counts and business invariants before and after migration.
7. Define restoration or forward-fix procedure before approval.

## Observability and security operations

Collect structured logs with request and correlation IDs, but do not place passwords, tokens, comment CAPTCHA responses, Google authorization codes, or raw sensitive personal data in logs.

Minimum dashboards and alarms:

```text
Application availability and latency
5xx and authentication failure rates
Database connections, storage, CPU, and replica health
Queue age and failed jobs
Upload scan failures
CloudFront 4xx/5xx rates and cache behavior
WAF blocks and rate-rule activity
Backup completion and restore-test age
Publication and administrator audit anomalies
Premium webhook failures and entitlement mismatch
```

Use CloudTrail for AWS administrative activity and retain security logs separately from ordinary application logs.

## Cost-aware implementation phases

### Phase 1: Mac acceptance

Use this release unchanged to validate workflows and design. Do not treat the Mac database as the eventual production database.

### Phase 2: controlled low-cost launch

Use one persistent application server, S3/CloudFront, versioned backups, and strict monitoring while traffic and editorial processes remain modest. Keep the same immutable revision model.

### Phase 3: managed data and identity

Move to PostgreSQL and managed identity before introducing multiple application instances, paid subscriptions, or a large publishing team.

### Phase 4: resilient public platform

Deploy at least two application tasks across availability zones, managed database redundancy, queues/workers, signed restricted delivery, centralized observability, and tested disaster recovery.

### Phase 5: evidence-driven scaling

Scale the database, search, analytics, media processing, and CDN only when measurements show the bottleneck. Avoid introducing OpenSearch, a data warehouse, or complex event streaming before the simpler managed architecture reaches a documented limit.

## Migration from version 0.2.0

The application should gain a storage/database adapter layer before the production migration. Then:

1. Freeze publication and account-administration writes.
2. Create and verify the built-in application backup.
3. Export SQLite tables with counts and checksums.
4. Copy local package objects to immutable S3 version prefixes.
5. Create the PostgreSQL schema with the same stable IDs.
6. Import users, documents, revisions, comments, votes, favorites, follows, settings, events, and audit records.
7. Recalculate and compare document-level invariants.
8. Map Google identities or migrate to Cognito subject identifiers.
9. Run a staging application against the imported copy.
10. Test open, sign-in, premium, revision, moderation, and backup workflows.
11. Take the final delta or repeat the short write freeze.
12. Switch DNS only after smoke tests and monitoring are green.
13. Retain the old system and verified backups for the rollback window.

Key invariants to verify:

```text
Every published document has exactly one current published revision
Every vote/comment references a valid document and revision
Every published revision maps to immutable object checksums
Every staff account has an allowed role and status
The final active super administrator remains recoverable
Premium access is derived from valid entitlement state
Historical revisions and discussions remain queryable
```

## Vercel alternative

A Vercel deployment is viable after replacing the persistent Node/SQLite assumptions with:

- A serverless-compatible application layer.
- Managed PostgreSQL.
- S3 or another durable object store.
- Managed identity.
- External queues/scheduled jobs.
- An independent backup and restore process.

Vercel may simplify front-end deployment, but it does not remove the need for durable database, object-storage, entitlement, backup, moderation, and release architecture. Because the current acceptance build already maps naturally to S3 and CloudFront and the user has an AWS account, AWS is the primary target documented here.
