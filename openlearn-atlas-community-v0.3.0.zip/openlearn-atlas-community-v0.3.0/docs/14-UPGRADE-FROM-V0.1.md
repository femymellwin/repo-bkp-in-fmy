# 14. Upgrade from version 0.1.0 to 0.2.0

## What the upgrade changes

Version 0.2.0 adds database-backed users, roles, Google identity links, access levels, immutable package revisions, SPIN votes, comments and replies, favorites, follows, branding settings, and richer analytics.

The migration is designed to retain version 0.1.0 data. Each old content item receives a generated immutable package revision whose storage references point to the existing package and preview files.

The migration does not intentionally delete:

```text
Content documents
Stored package references
Preview references
Thumbnails
Analytics events
Anonymous likes
Metadata revision history
Audit records
```

## Critical rule

Do not extract the new release directly over the only copy of the old installation. Upgrade in a separate directory and keep the verified old application, data, environment file, and backup until acceptance is complete.

## 1. Record the existing installation

From the version 0.1.0 directory:

```bash
pwd
node --version
npm test
```

Record:

```text
Current application folder
Current Git commit or release tag
Current data directory
Current backup directory
Current `.env` location
Current storage driver
Current S3 content and backup bucket names, if applicable
Current public URL and port
```

## 2. Create and verify a backup

While version 0.1.0 is still healthy:

```bash
npm run backup
```

Locate the newly created archive and verify it:

```bash
npm run verify-backup -- /full/path/to/backups/learning-portal-YYYYMMDDTHHMMSSZ.tgz
```

Copy the archive and its `.sha256` file to a second storage location before continuing.

For S3 mode, also confirm that the backup object exists in the backup bucket and that S3 Versioning is enabled.

## 3. Stop the old server

When running in Terminal, press:

```text
Control+C
```

For Docker:

```bash
docker compose down
```

For a service manager, stop the service and verify no process still has the SQLite database open.

## 4. Extract version 0.2.0 separately

Example:

```bash
cd ~/Applications
unzip ~/Downloads/openlearn-atlas-community-v0.2.0.zip
cd openlearn-atlas-community-v0.2.0
```

Do not start it yet.

## 5. Bring forward configuration and runtime data

Copy the old environment file:

```bash
cp /path/to/old-installation/.env ./.env
```

Compare it with `.env.example` and add the version 0.2.0 settings. At minimum, verify:

```dotenv
ALLOW_REGISTRATION=true
MAX_COMMENT_LENGTH=3000
SPIN_VERIFIED_MIN_VOTES=3
SPIN_VERIFIED_THRESHOLD_PERCENT=75
```

Before the first version 0.2.0 start, set the bootstrap super-administrator values because version 0.1.0 did not store a general user account table:

```dotenv
ADMIN_NAME=Portal Owner
ADMIN_EMAIL=your-real-admin@example.com
ADMIN_PASSWORD=
ADMIN_PASSWORD_HASH=scrypt$your-generated-hash
```

Generate the hash from the new release:

```bash
npm run password-hash -- "a-long-unique-password"
```

Use the existing strong `SESSION_SECRET` and `PRIVACY_SALT` if they were already properly generated. Do not replace them casually during the upgrade because changing identity-related secrets can sign out sessions and change anonymous-visitor continuity.

### Local storage mode

Copy the entire runtime data directory without merging individual SQLite files:

```bash
rm -rf ./data
cp -a /path/to/old-installation/data ./data
```

Optionally copy the local backup history:

```bash
rm -rf ./backups
cp -a /path/to/old-installation/backups ./backups
```

### S3 storage mode

Retain the existing `DATA_DIR` because SQLite is still local in version 0.2.0. Keep the same S3 content bucket, prefix, Region, CDN URL, and backup bucket settings. Do not rename or move old S3 objects before the migration has run and been tested.

## 6. Test source integrity before migration

Run:

```bash
npm test
```

This test suite uses temporary data and does not migrate the copied production/evaluation database.

## 7. Start version 0.2.0 and allow the migration

```bash
npm start
```

The migration runs in a transaction during startup. Open:

```text
http://localhost:3000/health
```

Expected version:

```json
{"ok":true,"storage":"local","version":"0.2.0"}
```

The storage value can be `s3` when configured.

## 8. Acceptance checks

Complete these checks before deleting or modifying the old installation:

```text
[ ] Old resources appear in the public catalog
[ ] Old thumbnails load
[ ] Old interactive previews load
[ ] Old downloads work
[ ] Old view/download/like analytics remain visible
[ ] Administrator can sign in with the new bootstrap account
[ ] Each old resource has a legacy immutable revision
[ ] A SPIN vote can be submitted to the current revision
[ ] An anonymous comment can be submitted
[ ] The comment appears in Publisher console > Messages
[ ] Publisher can reply and resolve the message
[ ] Member registration works
[ ] Favorite and follow work in My Library
[ ] Open, sign-in, and premium access gates work
[ ] A new draft package revision can be uploaded
[ ] Publishing it archives the old revision and makes the new one current
[ ] Old comments still display their original revision
[ ] A second administrator can be created
[ ] Branding can be updated
[ ] A new version 0.2.0 backup can be created and verified
```

## 9. Post-upgrade backup

After acceptance:

```bash
npm run backup
npm run verify-backup -- /full/path/to/the-new-v0.2.0-backup.tgz
```

Keep both the last verified version 0.1.0 backup and the first verified version 0.2.0 backup for the defined rollback/retention period.

## Rollback

Because version 0.2.0 changes the database schema, do not point version 0.1.0 code at the migrated database.

To roll back:

1. Stop version 0.2.0.
2. Preserve a copy of the failed migrated state for diagnosis.
3. Return to the untouched version 0.1.0 source directory.
4. Restore the verified pre-upgrade version 0.1.0 backup.
5. Start version 0.1.0.
6. Verify preview, download, login, analytics, and backups.
7. Record the reason for rollback before attempting another migration.

Any community data created after the version 0.2.0 cutover will not exist in the pre-upgrade backup. Export or reconcile it deliberately before rollback when it must be retained.

## Upgrade limitations

- The migration creates a legacy package revision from each old resource's current storage references; it cannot reconstruct historical package binaries that were overwritten outside the application.
- Version 0.2.0 still uses SQLite for Mac and single-server operation.
- Google sign-in needs external credentials before it appears.
- Turnstile needs site and secret keys; otherwise the local arithmetic challenge is used.
- Premium access is an administrator-managed entitlement, not a payment subscription.
- Restricted S3/CloudFront content requires signed delivery in the final production architecture; a permanent direct CDN URL can bypass application entitlement checks.
