# 5. Backup, restore, and disaster recovery

## Backup objectives

A reliable portal needs independent protection for four kinds of information:

```text
1. Source code and release history
2. SQLite users, roles, resources, immutable revisions, SPIN votes, comments, favorites, follows, analytics, entitlements, branding, and audit records
3. Uploaded learning packages and thumbnails
4. Secrets, domain ownership, and recovery instructions
```

No single backup mechanism protects all four.

## Recommended protection layers

### Layer 1: application backup

The portal creates a consistent SQLite snapshot with `VACUUM INTO`, generates a file manifest, creates a compressed archive, and writes a SHA-256 checksum.

In local-storage mode, the archive contains:

```text
portal.sqlite
storage/
manifest.json
```

In S3-storage mode, the archive contains:

```text
portal.sqlite
manifest.json
```

S3 objects are protected separately by S3 Versioning.

The backup intentionally does not include `.env`. Keep secrets in a password manager or secret-management system, not inside the same data backup.

### Layer 2: off-site S3 backup bucket

When `BACKUP_S3_BUCKET` is configured, every application backup and checksum is uploaded to the separate backup bucket. The supplied CloudFormation template enables:

- Server-side encryption.
- S3 Versioning.
- Block Public Access.
- Lifecycle transition to archival storage.
- Retention of the bucket if the CloudFormation stack is deleted.
- An application policy that can write and read backups but cannot delete them.

### Layer 3: server snapshot

For Lightsail, enable automatic daily instance snapshots. The latest seven are retained. Copy a chosen automatic snapshot to a manual snapshot monthly so it remains after the source instance is deleted.

For EC2, use encrypted EBS snapshots with AWS Data Lifecycle Manager.

A server snapshot is convenient for full-machine recovery, but it is not a replacement for a verified application backup.

### Layer 4: offline recovery copy

At least monthly, download one verified application backup to an encrypted external drive or encrypted local archive. Keep it separate from the AWS account. This protects against account-wide loss or administrative error.

### Layer 5: Git repository backup

GitHub holds the primary private code repository. Maintain a periodic mirror clone on another protected device or storage service. Git release tags and GitHub deployment history do not contain your SQLite database or S3 content.

## Recovery targets

A reasonable initial policy is:

```text
Database backup frequency        Daily, or every 6 hours for lower data loss
Target recovery point            Up to the backup interval
Target service recovery          Same business day for the initial single-server launch
Local backup retention           30 archives
Lightsail automatic snapshots    Latest 7 daily snapshots
Manual server snapshots          12 monthly copies
S3 backup retention              7 years in the supplied lifecycle rule
Restore exercise                 Quarterly
```

These are operating targets, not contractual guarantees.

## Configure automatic application backup

In `.env`:

```dotenv
AUTO_BACKUP=true
AUTO_BACKUP_HOUR_UTC=2
BACKUP_RETENTION_COUNT=30
BACKUP_S3_BUCKET=your-backup-bucket
```

The built-in scheduler runs while the application process is active. For an additional host-level schedule, use cron on the production server:

```bash
sudo crontab -e
```

Example every six hours:

```cron
17 */6 * * * cd /opt/openlearn-atlas && /usr/bin/docker compose exec -T portal npm run backup >> /var/log/openlearn-atlas-backup.log 2>&1
```

Avoid scheduling the built-in and host-level backup at exactly the same minute.

## Create a backup manually

### Mac or direct Node.js

```bash
npm run backup
```

### Docker deployment

```bash
docker compose exec -T portal npm run backup
```

Expected files:

```text
backups/learning-portal-YYYYMMDDTHHMMSSZ.tgz
backups/learning-portal-YYYYMMDDTHHMMSSZ.tgz.sha256
```

## Verify a backup

Verification checks that:

- The `.sha256` sidecar matches the archive when the sidecar is present.
- The archive can be read.
- Archive paths are not absolute or parent-traversing.
- Links and unsupported archive entry types are rejected.
- `manifest.json` exists.
- Every manifest file exists.
- Every file size matches.
- Every SHA-256 file hash matches.

Run:

```bash
npm run verify-backup -- /full/path/to/learning-portal-YYYYMMDDTHHMMSSZ.tgz
```

Also verify the outer checksum on macOS:

```bash
cd /folder/containing/the/backup
shasum -a 256 -c learning-portal-YYYYMMDDTHHMMSSZ.tgz.sha256
```

Only restore backups created by this portal and held in your trusted backup locations.

## Restore on a Mac

1. Stop the portal with `Control+C`.
2. Copy the backup into a safe working directory.
3. Verify it.
4. Run:

```bash
npm run restore -- /full/path/to/backup.tgz --yes
```

5. Start the portal.
6. Check the public catalog, publisher dashboard, analytics totals, previews, and downloads.

The restore process first creates a safety backup of the current state. It also preserves the previous database and storage directory with a `pre-restore` name.

Before creating that safety backup, the restore command copies the selected source archive and its checksum to an isolated temporary location and verifies them there. This prevents backup-retention cleanup, filename collisions, or an operator-selected archive inside the active backup directory from changing the restore source during the operation.

The restored database and local package directory are prepared outside the live paths and then moved into place. Existing live data is retained under timestamped `pre-restore` names so an operator can reverse the replacement if post-restore checks fail. Stale SQLite write-ahead-log and shared-memory files are removed before the portal is restarted.

## Restore on a Docker server

1. Put the site into a maintenance window.
2. Stop the application container:

```bash
cd /opt/openlearn-atlas
docker compose stop portal
```

3. Start a one-off restore container using the same mounted data and backup directories:

```bash
docker compose run --rm portal npm run restore -- /app/backups/backup-file.tgz --yes
```

4. Start the portal:

```bash
docker compose up -d
```

5. Validate:

```bash
curl -fsS http://127.0.0.1:3000/health
docker compose logs --tail=100 portal
```

6. Complete the functional checks listed below.

## Restore a backup downloaded from S3

1. Open the AWS S3 console.
2. Open the backup bucket.
3. Browse to `portal/backups/` or the configured prefix.
4. Download the `.tgz` file and matching `.sha256` file.
5. Verify the checksum locally.
6. Copy the archive to the production server through an encrypted channel.
7. Follow the Docker restore procedure.

If the current object was overwritten or deleted, enable **Show versions** in the S3 console and restore or download a previous version.

## Recover an S3 learning package version

S3 Versioning stores prior complete object versions. To recover an accidentally overwritten package:

1. Open the content bucket in S3.
2. Enable **Show versions**.
3. Locate the object's key under the configured prefix.
4. Identify the required version by time and version ID.
5. Download and inspect it, or copy it back to the same key to create a new current version.
6. If CloudFront cached a bad object, create an invalidation for that exact path.
7. Verify the preview and download through the public portal.

Do not permanently delete individual versions until the retention policy permits it.

## Recover a deleted Lightsail server

If a manual snapshot exists:

1. Open Lightsail.
2. Open **Snapshots**.
3. Create a new instance from the required manual snapshot.
4. Select the appropriate Region, Availability Zone, and plan.
5. Attach a static IP or update DNS.
6. Confirm the `.env` and application data.
7. Start the Docker stack.
8. Validate S3/CloudFront access and backups.

Automatic snapshots associated with a source resource are deleted when that source resource is deleted. This is why monthly manual copies are part of the policy.

## Quarterly restore exercise

Use a separate Mac folder or temporary test server. Do not test by overwriting the only production system.

Record:

```text
Date
Backup filename
Checksum result
Restore destination
Database opened successfully
Number of published resources
Preview test result
Download test result
Publisher login result
Analytics dashboard result
S3 object recovery result
Issues and corrective actions
Operator
```

A backup that has never been restored is an unproven backup.

The automated release suite performs an actual isolated restore rehearsal. It verifies that the selected source remains available, that a pre-restore safety backup is created, and that both the SQLite database and local package files are restored. Continue the quarterly operational exercise because automated tests cannot prove cloud credentials, DNS, human access, or production infrastructure recovery.

## Post-restore functional checklist

- `/health` returns `ok: true`.
- Public home page loads.
- Search and category filters work.
- At least three published resources open.
- An interactive preview loads its dependent assets.
- A download completes and records an event.
- Anonymous like toggling works.
- WhatsApp share opens with the correct public URL.
- Publisher login works.
- Existing analytics totals are present.
- A new test upload can be published.
- A fresh backup can be created and verified.

## Disaster-recovery inventory

Store this inventory outside the production server:

```text
AWS account ID and root email
IAM Identity Center recovery method
AWS root MFA recovery information
GitHub owner and repository name
GitHub recovery codes
Domain registrar and recovery method
Route 53 hosted zone or external DNS provider
CloudFormation stack name and Region
Content bucket name
Backup bucket name
CloudFront distribution ID and domain
Production server Region, name, static IP, and plan
Application release tag
Location of protected production secrets
Latest verified backup filename
Latest manual server snapshot name
Recovery operator instructions
```

Do not put actual passwords, access-key secrets, or MFA seeds in a plain-text inventory.

## Optional stronger controls

Add these only when the operational need justifies the cost and complexity:

- S3 Object Lock in a new backup bucket for immutable retention.
- Cross-Region Replication to a second AWS Region.
- Cross-account backup replication to a separate AWS account.
- AWS Backup policies for EC2/EBS/RDS.
- Managed PostgreSQL point-in-time recovery.
- Automated restore testing in a non-production account.
