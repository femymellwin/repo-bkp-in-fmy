# 8. Affordable and reliable cost plan

Pricing changes over time and varies by Region. Treat the figures below as planning values and confirm them in the provider consoles before purchasing.

## Recommended starting choice

For this exact build, use:

```text
Small AWS Lightsail Linux server
Private S3 content bucket
CloudFront distribution
Separate S3 backup bucket
Route 53 only if you want AWS-managed DNS
Private GitHub repository
Built-in first-party analytics
```

This avoids a paid database, paid analytics platform, load balancer, Kubernetes, and multiple application servers at the beginning.

## Expected small-deployment components

| Component | Planning amount | Notes |
|---|---:|---|
| Lightsail Linux server | About USD 7/month | Current public-IPv4 1 GB bundle planning value; confirm the selected Region. |
| Lightsail snapshots | USD 0.05/GB-month | Billed for snapshot storage used. |
| CloudFront flat-rate Free | USD 0/month | 1 million requests and 100 GB transfer monthly; eligibility and supported configuration apply. |
| CloudFront flat-rate Pro | USD 15/month | 10 million requests and 50 TB transfer monthly, plus logging and larger feature allowances. |
| Route 53 / TLS / WAF | Included features in flat-rate plans | Associate the relevant resources to the plan; domain registration remains separate. |
| S3 storage and requests | Usage based | Flat-rate plans include monthly S3 storage credits; old object versions still consume storage. |
| Pay-as-you-go CloudFront | Usage based | Keep as the alternative when a flat-rate plan is unavailable or unsuitable. |
| TLS certificates | No additional ACM charge | The supplied standard distribution uses an ACM certificate in `us-east-1`. |
| GitHub private repository | Often USD 0 for one owner | Paid plan may be needed for some advanced private-repository controls. |
| Domain | Annual, TLD dependent | Registrar price varies. |

A small low-traffic portal can target roughly **USD 7 to 20 per month** plus annual domain registration, storage, and snapshots. The lower end assumes a 1 GB Lightsail server and an eligible CloudFront Free flat-rate plan. This is an estimate, not a quote; taxes, Region differences, storage growth, account eligibility, and plan selection can change it.

## Why CloudFront plus S3 is cost-effective here

Interactive packages and downloads are static objects. Serving them through CloudFront allows edge caching and avoids sending every byte through the Node.js server. The application server handles metadata, publisher actions, and tracked redirect events, while S3 stores the durable objects.

Keep these cost controls:

- Subscribe the distribution to the CloudFront Free flat-rate plan when the console confirms eligibility; move to Pro only when required.
- If using pay-as-you-go, retain `PriceClass_100` initially, as supplied.
- Upload immutable/versioned content paths.
- Compress text assets inside packages where practical.
- Avoid giant unoptimized video or 3D files.
- Use S3 lifecycle rules for noncurrent object versions.
- Review CloudFront cache-hit ratio before changing cache policy.
- Do not enable expensive real-time logs or WAF rules until the need is clear.

## Built-in analytics versus a paid platform

The current release already records:

```text
Content views
Preview opens and loads
Downloads
SPIN verification votes
Comments and staff replies
Likes, favorites, and follows
Share-channel clicks
Searches
Referrers
User agents
Anonymous visitor and session hashes
```

It includes a publisher dashboard and CSV export. This is sufficient for an initial self-funded portal and has no separate analytics subscription.

Add PostHog, Matomo, or another platform only when you need funnels, cohorts, retention analysis, session replay, or organization-wide reporting. Review privacy and cost before enabling session replay.

## AWS cost guardrails

Before launch:

1. Create a monthly AWS cost budget.
2. Set actual alerts at 50, 80, and 100 percent.
3. Set a forecasted alert at 100 percent.
4. Create a second emergency threshold.
5. Enable Cost Anomaly Detection.
6. Tag resources with:

```text
Project=openlearn-atlas
Environment=production
Owner=your-name-or-organization
```

7. Review the bill weekly during the first month.
8. Review S3 current and noncurrent version storage.
9. Review snapshot storage.
10. Do not assume a budget alert is immediate; billing data has delay.

## Do not buy initially

Avoid these at the initial launch stage unless a documented requirement exists:

- Kubernetes or Amazon EKS.
- Multi-AZ RDS.
- An application load balancer.
- NAT Gateway.
- Elasticsearch/OpenSearch.
- Dedicated Redis.
- Paid enterprise analytics.
- Paid AWS Support.
- Multi-Region active-active deployment.
- CloudFront real-time logs.
- Always-on malware-analysis infrastructure.

The cost of some of these components can exceed the portal server itself.

## When managed PostgreSQL becomes worth the cost

Move from SQLite when reliability or concurrency requires it, not merely because PostgreSQL is more fashionable.

The additional cost becomes justified when you need:

- More than one application instance.
- Multiple concurrent publishers.
- Point-in-time database recovery.
- Read replicas or analytics replicas.
- Larger event volumes.
- Zero-downtime deployment patterns.
- Managed database monitoring and maintenance.

At that point, compare RDS PostgreSQL, Supabase, and Neon using the same backup, Region, storage, and egress requirements.

## Vercel cost comparison

Vercel currently lists the Pro plan at USD 20/month with included usage credit. A production portal still needs external durable database and file storage. Therefore the Vercel architecture generally starts above the single-server AWS design, although it offers excellent Git-driven preview and production deployments.

Use Vercel when developer workflow and managed scaling are worth the additional recurring cost. Do not choose it merely because the first static deployment is easy.

## EC2 in UAE cost comparison

Use EC2 in `me-central-1` when UAE data residency or instance-role credentials are required. Build a complete estimate including:

```text
EC2 instance hours
EBS volume
EBS snapshots
Public IPv4
S3 storage and requests
CloudFront usage
Route 53
CloudWatch logs and alarms
Data transfer not covered by CloudFront behavior
```

Lightsail is not currently listed as available in the UAE Region, so it cannot satisfy UAE-region compute residency.

## Growth cost model

Track these measurements monthly:

```text
Published resource count
Total S3 current-version GB
Total S3 noncurrent-version GB
Backup bucket GB
Average package size
CloudFront requests
CloudFront transfer GB
Application requests
SQLite database size
Analytics events per month
Snapshot GB
```

Forecast with:

```text
Monthly content growth = new resources x average package size
Monthly backup growth = database size x backup frequency before lifecycle transition
Download transfer = downloads x average package size
Preview transfer = previews x average preview bytes not served from browser cache
```

Large downloadable videos, high-resolution models, and repeated package versions will dominate cost before text metadata does.

## Official pricing references

- Lightsail: `https://aws.amazon.com/lightsail/pricing/`
- CloudFront pricing and flat-rate plans: `https://aws.amazon.com/cloudfront/pricing/`
- CloudFront flat-rate plan guide: `https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/flat-rate-pricing-plan.html`
- S3: `https://aws.amazon.com/s3/pricing/`
- Route 53: `https://aws.amazon.com/route53/pricing/`
- Vercel: `https://vercel.com/pricing`
- AWS Pricing Calculator: `https://calculator.aws/`
