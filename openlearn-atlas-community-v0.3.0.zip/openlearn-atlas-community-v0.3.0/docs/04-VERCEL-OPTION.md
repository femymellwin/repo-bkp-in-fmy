# 4. Vercel deployment option and conversion requirements

## Compatibility statement

Version 0.2.0 is a persistent Node.js HTTP application with SQLite and an optional local package store. That design is deliberate for Mac acceptance testing and for an economical single-server launch.

Do not deploy this exact build unchanged to ordinary Vercel Functions and expect the SQLite database, local uploads, process-local sessions, rate limits, or scheduled backups to be durable. A production Vercel deployment requires a serverless-compatible data and identity conversion first.

The converted topology should be:

```text
Vercel-hosted web application
   |
   +--> managed PostgreSQL for users, roles, resources, immutable revisions,
   |    SPIN votes, comments, favorites, follows, analytics, and audit history
   |
   +--> Amazon S3 for original packages, previews, thumbnails, and exports
   |
   +--> CloudFront for public delivery and signed restricted delivery
   |
   +--> managed identity for Google federation, MFA, recovery, and staff access
   |
   +--> shared rate limiting, queue workers, and externally scheduled backups
```

Vercel can be a strong front-end and deployment platform after this conversion. It is not a drop-in host for the supplied SQLite acceptance build.

## Product behavior that must be preserved

A conversion must preserve the v0.2.0 domain model rather than simplifying it to a file gallery:

- Anonymous access to documents marked `open`.
- Account-required and premium entitlement gates.
- Durable users and the `super_admin`, `admin`, `publisher`, `moderator`, and `member` roles.
- Favorites and follows.
- Immutable document revisions.
- Exactly one current published revision per document.
- Retention of archived revisions and their exact SPIN votes and comments.
- Threaded comments, staff replies, moderation state, and resolution state.
- Audit records for publishing, access, moderation, user administration, and branding changes.
- Tenant-level branding settings.
- Download and preview authorization before a restricted object is issued.

## Required engineering changes

### 1. Web runtime

Move the routes to a framework and execution model supported by Vercel, such as Next.js. Keep authorization checks in server-side route handlers rather than relying on hidden buttons in the browser.

An illustrative route layout is:

```text
app/page.tsx                              Public catalog
app/learn/[slug]/page.tsx                 Document and current revision
app/api/events/route.ts                   Analytics events
app/api/documents/[id]/spin/route.ts       Revision-scoped SPIN vote
app/api/documents/[id]/comments/route.ts   Comment and reply workflow
app/api/download/[versionId]/route.ts      Authorized tracked delivery
app/admin/...                              Staff administration
```

### 2. Database

Replace `node:sqlite` with managed PostgreSQL. The production database should provide:

- Automated backups.
- Point-in-time recovery on the selected production service tier.
- Transactional publication of a new current revision.
- Connection pooling appropriate for serverless functions.
- A migration tool that records every applied schema change.
- A production database isolated from preview deployments.
- Tested logical exports to a separate recovery location.

Do not allow branch-preview deployments to run destructive migrations against production.

### 3. Identity and sessions

The supplied build already has database-backed users, roles, local accounts, Google identities, premium entitlement, and session revalidation. For public production, replace or adapt the local identity implementation to a managed provider that supports:

- Google federation.
- Staff MFA.
- Password recovery and verified-email workflows.
- Account disablement and token revocation.
- Audit events.
- Stable subject identifiers mapped to the portal user record.

Amazon Cognito is the natural fit when AWS is the primary platform. Other managed identity providers can also work, provided the portal role and entitlement model remains authoritative.

### 4. Object delivery

Keep HTML, ZIP, image, and 3D packages outside Vercel deployment bundles.

Use:

```text
Browser -> authorized upload session -> S3 quarantine prefix
       -> validation/malware scan -> immutable published prefix
       -> CloudFront
```

Open content can use cacheable public object paths. Sign-in and premium content must use short-lived CloudFront signed URLs or signed cookies after the portal verifies the account and entitlement. A permanent public CDN URL is not an access-control mechanism.

### 5. Shared controls and background work

Replace process-local features with shared services:

- Distributed rate limiting for login, registration, comments, votes, and uploads.
- A queue for archive extraction, validation, malware scanning, thumbnails, indexing, notifications, and analytics aggregation.
- An external scheduler for backups and maintenance.
- Idempotency keys for payment webhooks and long-running administrative actions.

### 6. Premium billing

Version 0.2.0 contains access flags and manually assignable premium entitlement; it does not charge money. A production subscription launch additionally requires:

- A payment provider.
- A server-side subscription and entitlement ledger.
- Verified and idempotent webhook handling.
- Grace periods, cancellation, refunds, and dispute handling.
- Tax, invoicing, privacy, and terms review for the operating jurisdiction.

Do not grant premium access solely because the browser returned from a payment page.

## Vercel project setup after conversion

1. Create the Vercel organization and secure every owner account with MFA.
2. Import the private GitHub repository.
3. Set `main` as the production branch and use protected pull requests.
4. Configure separate Production, Preview, and Development environment variables.
5. Connect the managed PostgreSQL service without giving previews production credentials.
6. Configure the S3 and CloudFront integration with narrowly scoped, short-lived credentials where supported.
7. Add the custom domain and verify DNS ownership.
8. Configure observability, usage alerts, and spending controls.
9. Deploy a staging environment using production-like services.
10. Run migration, access-control, revision, backup, and restore acceptance tests.
11. Promote a tagged release only after the release gate succeeds.

Vercel deployment history protects application deployments; it is not a backup of PostgreSQL, S3 objects, identity-provider state, or DNS.

## Backup model for a Vercel deployment

```text
Application code       Private Git repository, protected tags, and an offline mirror
Database               Provider backups, point-in-time recovery, and logical exports
Learning packages      S3 Versioning, lifecycle retention, and replicated/off-site copies
Configuration          Infrastructure as code and a secure recovery inventory
Identity configuration Exported/documented provider settings and break-glass ownership
Domains and DNS         Registrar recovery controls and documented records
```

Run scheduled restore exercises. A backup that has never been restored is not a demonstrated recovery capability.

## When Vercel is the better choice

Choose the converted Vercel architecture when Git-driven preview environments, managed front-end scaling, and a multi-developer workflow justify the additional services and engineering conversion.

Choose the AWS-first architecture described in `13-PRODUCTION-TARGET-ARCHITECTURE.md` when S3 and CloudFront are already preferred, AWS governance is available, and a single cloud control plane is operationally simpler.

For the current Mac acceptance cycle, use this build locally. Do not attempt the Vercel conversion until the community, revision, access, and branding workflows have been accepted, because those workflows define the schema and authorization behavior that the production implementation must preserve.

## Official references

- Git deployments: <https://vercel.com/docs/git>
- Environment variables: <https://vercel.com/docs/environment-variables>
- Functions: <https://vercel.com/docs/functions>
- Storage integrations: <https://vercel.com/docs/storage>
- Amazon CloudFront private content: <https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/PrivateContent.html>
