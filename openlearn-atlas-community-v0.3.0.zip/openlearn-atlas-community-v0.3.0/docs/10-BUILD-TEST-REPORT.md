# 10. Build and test report

## Release identity

```text
Application: OpenLearn Atlas Community Learning Platform
Version: 0.2.0
Build date: 2026-08-30
Source runtime requirement: Node.js 22.13.0 or later
```

This release is a runnable source distribution for macOS evaluation and controlled single-server deployment. It is not a signed macOS application bundle, a DMG, or the final horizontally scaled production topology.

## Verification environment

The release was built and verified in:

```text
Operating system: Linux x86_64
Node.js: v22.16.0
npm: 10.9.2
```

The application has no third-party runtime packages. Its local evaluation path uses Node.js built-in HTTP, cryptography, test runner, archive utilities, and SQLite modules.

## Automated test result

```text
Tests:      7
Passed:     7
Failed:     0
Cancelled:  0
Skipped:    0
```

Run the same suite with:

```bash
npm test
```

The tests cover the following workflows.

### Data migration and preservation

- Creates a representative version 0.1 database.
- Migrates it to schema version 2.
- Preserves the existing document, analytics event, anonymous like, package key, thumbnail key, metadata, and publication state.
- Creates an immutable legacy revision and points the stable document record to it.

### Human verification and Google authentication foundation

- Generates and validates the signed local arithmetic challenge used during Mac testing.
- Rejects an incorrect challenge answer.
- Builds a Google authorization request with signed state and PKCE S256.
- Exchanges the mocked authorization code and requires a verified Google email profile.

### Backup and actual restore rehearsal

- Creates a consistent SQLite snapshot.
- Includes the local package store when local storage is active.
- Generates and validates the internal manifest, file sizes, SHA-256 file hashes, outer archive checksum, and safe archive paths.
- Copies and verifies the operator-selected restore source before retention cleanup.
- Creates a mandatory pre-restore safety backup.
- Restores both the SQLite database and local learning-package files.
- Preserves recoverable pre-restore copies.
- Deliberately corrupts checksum evidence and confirms verification fails.

### Public and community workflow

- Loads the anonymous public catalog and document page.
- Records analytics activity.
- Accepts a per-revision “I am able to install” SPIN vote.
- Accepts anonymous document feedback after successful CAPTCHA.
- Creates a member account.
- Supports favorites and revision following.
- Shows followed content in the member library.

### Access control and premium foundation

- Creates an open resource and a premium resource.
- Allows anonymous exploration of open content.
- Exposes catalog metadata for restricted content without granting package access.
- Rejects anonymous and free-member preview access to premium content.
- Rejects unauthorized SPIN votes and feedback submissions on restricted content at the server route, not only in the interface.
- Grants premium entitlement through administrator user management and then permits entitled access.

### Revision and publisher workflow

- Uploads a new immutable revision.
- Publishes the selected revision atomically.
- Makes the new revision current.
- Archives the prior published revision.
- Retains old SPIN votes and comments against their original revision.
- Shows a new-revision indication to followers.
- Lets staff reply to a community message and mark it resolved.

### Multi-user administration and branding

- Verifies valid and invalid login behavior.
- Rejects a forged CSRF submission.
- Creates additional staff accounts and role assignments.
- Protects the last active super administrator from removal or demotion.
- Updates organization name, product name, product tagline, portal tagline, and logo configuration.
- Loads the publisher dashboard, inbox, revision controls, user management, and branding pages.

### Package validation

- Extracts a valid deflated HTML package and identifies its entry point.
- Rejects parent-directory traversal.
- Rejects case-insensitive duplicate filenames.
- Rejects encrypted ZIP entries.
- Rejects symbolic links.
- Rejects packages exceeding the configured expanded-size limit.

## Static and infrastructure checks

The following checks passed:

- JavaScript syntax validation for every `.mjs` and `.js` file under `src/`, `scripts/`, `test/`, and `public/`.
- Shell syntax validation for `start-mac.command`.
- Custom-tag-aware YAML parsing of `infra/aws/cloudformation-storage-cdn.yaml`.
- Inspection of all eight CloudFormation resources.
- Confirmation that both S3 buckets use `DeletionPolicy: Retain` and `UpdateReplacePolicy: Retain`.
- Confirmation that both S3 buckets enable Versioning and all Block Public Access controls.
- Confirmation that CloudFront Origin Access Control signs origin requests with `SigningBehavior: always`.
- Source-tree scan confirming no `.env`, SQLite runtime database, WAL/SHM file, upload archive, or generated backup archive was included before packaging.

## Browser and responsive visual verification

Eleven rendered views were checked with Chromium automation:

```text
Public home — desktop
Document detail — desktop
Sign-in — desktop
Public home — 390 px mobile
Document detail — 390 px mobile
Sign-in — 390 px mobile
Publisher dashboard
Publisher message inbox
User management
Branding settings
Revision history and publishing
```

The checks found no page-level JavaScript errors and no horizontal viewport overflow. The rendered pages were also visually inspected for hierarchy, readability, gallery density, mobile stacking, access notices, SPIN controls, comment forms, and administration navigation.

## Packaging acceptance checks

The final release procedure includes these checks against a newly extracted copy of the ZIP rather than only against the working source directory:

- JavaScript syntax validation.
- Mac launcher shell validation.
- The complete seven-test automated suite.
- A fresh first-run server launch using temporary data and backup directories.
- Successful `/health`, public home, document detail, sign-in, and publisher-login requests.
- Sample-content creation on an empty database.
- Archive-content inspection for secrets and runtime data.
- SHA-256 generation for both ZIP and TGZ artifacts.

The release checksums are supplied in `openlearn-atlas-community-v0.2.0.sha256`.

## Items not live-validated in this build environment

The following require credentials, infrastructure, hardware, or services that were not available during packaging:

- Execution on a physical Mac. The launcher was shell-checked and the application is platform-independent Node.js source, but the packaged release must still be accepted on the user’s Mac.
- Live Google OAuth consent, redirect, token exchange, and account sign-in. The protocol foundation was tested with controlled HTTP responses, but production client credentials were not used.
- Live Cloudflare Turnstile rendering and Siteverify calls. The local CAPTCHA path was tested; Turnstile requires configured site and secret keys.
- A live AWS CloudFormation deployment, S3 upload, CloudFront distribution, ACM certificate, Route 53 record, Cognito user pool, RDS cluster, Lightsail instance, or EC2 environment.
- A Docker image build; Docker was unavailable in the build environment.
- A live Vercel deployment. This SQLite/process-server build is intentionally not represented as directly deployable to Vercel’s serverless topology.
- `cfn-lint`, CloudFormation change-set execution, and AWS policy simulation.
- High-load, soak, failover, penetration, malware-scanning, formal accessibility-conformance, and full multi-browser testing.
- Payment collection, subscription checkout, invoice management, refunds, or payment-webhook reconciliation.
- Local-account email verification, forgotten-password delivery, and MFA.

## Production boundary

Version 0.2.0 is designed for Mac feature evaluation and can support a controlled single-application-server launch. Its domain model is deliberately production-oriented: stable documents, immutable revisions, retained community evidence, durable users and roles, audit records, access levels, verified backups, and explicit schema migrations.

For a well-known, high-volume public platform, replace or extend the single-node runtime with:

- Managed PostgreSQL with automated backups and point-in-time recovery.
- Managed identity with email verification, recovery, MFA, and Google federation.
- Direct-to-object-storage multipart uploads through short-lived credentials.
- Quarantine and malware scanning before publication.
- CloudFront signed URLs or signed cookies for login-required and premium packages.
- Distributed sessions, rate limiting, queues, cache, and analytics ingestion.
- Payment-provider checkout and idempotent signed webhook processing.
- Centralized logs, metrics, alerting, tracing, and tested infrastructure-as-code promotion.
- Blue/green or rolling release procedures with backward-compatible database migrations.

The detailed target is documented in `13-PRODUCTION-TARGET-ARCHITECTURE.md`.
