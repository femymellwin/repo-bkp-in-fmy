# 9. Production upgrade roadmap

## Current build level

Version 0.2.0 is a functional acceptance and single-server reference build for:

- Public anonymous discovery.
- Open, sign-in, and premium access flags.
- Local and optional Google member accounts.
- Multiple administrators, publishers, moderators, and members.
- SPIN verification and revision-specific community feedback.
- Immutable package revisions and archived history.
- Favorites and document follows.
- First-party analytics.
- Local or S3/CloudFront package storage.
- Verified backup and release-controlled schema upgrades.

Its product and data model are production-oriented. Its Node/SQLite process, in-memory limits, local credential lifecycle, and direct application uploads are not the final high-availability infrastructure for a very large public platform.

The detailed target is in `docs/13-PRODUCTION-TARGET-ARCHITECTURE.md`.

## Phase A: Mac product acceptance

Acceptance conditions:

```text
[ ] Compact gallery-first interface works on desktop and mobile widths
[ ] Public search and filters work without an account
[ ] Open preview and download work
[ ] Sign-in and premium gates work
[ ] Local registration and CAPTCHA work
[ ] Google OAuth can be enabled in a test project
[ ] Favorite and follow work
[ ] SPIN votes are independent per revision
[ ] Anonymous and member comments reach the publisher inbox
[ ] Staff replies and resolve/reopen work
[ ] A revised package can be drafted and published
[ ] The former revision is archived and its feedback retained
[ ] Multiple staff accounts and roles work
[ ] Branding changes appear publicly
[ ] Analytics and CSV export work
[ ] Backup creation, verification, and restore rehearsal work
[ ] Automated tests pass
```

Do not use the Mac acceptance database as the eventual large-scale production database.

## Phase B: controlled low-cost public launch

A controlled launch can use:

```text
One persistent Lightsail or EC2 application server
SQLite on encrypted persistent storage
Private S3 content and backup buckets
CloudFront with Origin Access Control
Custom domains and HTTPS
Private Git repository
Release-tag deployment
Frequent verified application backups
Daily server snapshots
External uptime monitoring
```

This phase is appropriate only while one-server downtime and a restore-based recovery procedure remain acceptable.

Before launch:

- Replace evaluation credentials and secrets.
- Require MFA for AWS, Git hosting, and staff accounts where supported.
- Configure Google OAuth production credentials and Turnstile.
- Establish privacy, moderation, acceptable-use, takedown, and retention policies.
- Restrict S3 bucket access and define object lifecycle rules.
- Use signed CloudFront delivery before marking S3-hosted packages sign-in or premium.
- Test domain, certificate, DNS, account, database, content, and backup recovery.
- Add alerting for health, storage, backup failure, authentication abuse, and upload errors.

## Phase C: managed database and identity

Complete this phase before multiple application instances, paid subscriptions, or a large publishing team.

Move:

```text
SQLite                    -> managed PostgreSQL
Local credential lifecycle -> Cognito or another managed identity provider
In-memory rate limits     -> distributed control such as Valkey/Redis or database-backed limits
Large app-proxied uploads -> direct multipart upload to S3 quarantine
Manual-only review        -> queued validation, malware scanning, and approval
Permanent restricted URLs -> short-lived CloudFront signed URLs/cookies
```

Preserve all stable document, revision, user, vote, comment, favorite, follow, setting, event, and audit identifiers during migration.

## Phase D: resilient multi-instance application

Deploy:

- At least two healthy application tasks across availability zones.
- An application load balancer.
- Managed PostgreSQL redundancy and point-in-time recovery.
- Stateless application containers.
- Shared caches/rate limits where needed.
- Queues and workers for uploads, notifications, analytics, and maintenance.
- Central logs, metrics, traces, dashboards, and alarms.
- Separate staging and production environments.
- Rolling or blue/green release deployment.

At this phase, an application task or filesystem must be replaceable without data loss.

## Phase E: premium billing

The current premium flag is an administrator-managed entitlement only.

Before payment launch, implement:

```text
Signed payment-provider webhooks
Idempotent event ledger
Subscription and entitlement history
Refund/cancellation/grace-period rules
Daily reconciliation
Customer-support controls
Tax, invoice, privacy, and consumer-law review
```

Never grant premium access solely from a browser success redirect.

## Phase F: evidence-driven search and analytics scaling

Start with PostgreSQL full-text search and aggregated first-party events. Add separate services only when measured requirements justify them.

Possible later additions:

- Multilingual stemming and relevance tuning.
- Completion events from packages through a controlled `postMessage` protocol.
- Country and campaign reporting.
- Retention and cohort analysis.
- Bot-quality scoring.
- Queue or stream-based event ingestion.
- Object-storage analytics lake and dashboard service.
- Search index service for very large catalogs.

Keep public counters fast and approximate when necessary; retain auditable raw data according to the privacy and retention policy.

## Safe schema and data migration rules

Every production release must use numbered, append-only migrations.

1. Create and verify a backup before migration.
2. Rehearse against a restored production-sized copy.
3. Prefer expand-and-contract changes.
4. Keep rolling application versions compatible during deployment.
5. Do not drop an old field in the first release that stops writing it.
6. Record the schema version and migration result in the release record.
7. Compare row counts and product invariants before and after migration.
8. Define rollback or forward-fix before approval.
9. Never make unaudited direct production-data changes.
10. Retain pre- and post-deployment recovery points for the defined window.

Key product invariants include:

```text
Exactly one current published revision per published document
Historical votes/comments keep valid revision references
Published package objects are immutable and checksum-addressable
The last active super administrator remains recoverable
Access checks use current identity and entitlement state
Archived revisions remain available to authorized staff and recovery procedures
```

## Release gates

A production release is accepted only when:

```text
CI and security checks passed
Release artifact is immutable and identified by commit/image digest
Migration was rehearsed
Backup or snapshot was created and verified
Staging workflow passed
Production approval was recorded
Health, catalog, preview, download, login, access, SPIN, comment, and revision smoke tests passed
Monitoring remained healthy through the observation gate
Post-deployment recovery point succeeded
Release record was completed
```

## High-availability trigger

Move beyond one server when any of these becomes true:

- Same-day or manual restore is not an acceptable outage response.
- The portal supports mandatory or contractual learning operations.
- Publishing must continue during maintenance.
- Paid access is introduced.
- Multiple application processes are needed for traffic or background work.
- SQLite write contention or database growth is material.
- More than a small named team administers the system.
- Availability, recovery, security, or residency obligations become contractual.

For the intended large public platform, plan the managed-data and resilient-application phases before broad promotion rather than waiting for a failure.

## Deletion and archive policy

Ordinary publishers should archive rather than permanently delete.

A future deletion lifecycle should be explicit:

```text
Published -> Draft -> Archived -> Retention hold -> Approved purge -> Verified purge
```

Require:

- Authorized approval and audit record.
- Comment/vote/history retention decision.
- Legal-hold and privacy review.
- S3 version and backup review.
- CloudFront revocation/invalidation.
- Search and analytics removal rules.
- Defined recovery window.

## Immediate technical milestone after feature acceptance

The first major production engineering milestone should be:

```text
PostgreSQL adapter + managed identity + direct quarantine uploads + signed restricted delivery
```

That preserves the version 0.2.0 user experience while removing the principal single-node and restricted-content limitations.
