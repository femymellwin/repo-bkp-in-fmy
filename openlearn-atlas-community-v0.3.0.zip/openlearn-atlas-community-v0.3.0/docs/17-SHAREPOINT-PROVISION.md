# 17. SharePoint provision (stage two)

Version 0.3.0 ships the configuration and connectivity layer for SharePoint; the catalog import job arrives in the next stage.

## What works today (`/admin/integrations`)

1. Store tenant ID, client ID, client secret (masked after save), site hostname, and site path.
2. **Test connection**: acquires a Microsoft Graph token via the client-credentials flow and resolves the configured site, reporting the site name and latency.
3. An **enabled** flag marks the connection ready for the import feature.

## Entra ID app registration

1. Register an application in Microsoft Entra ID and create a client secret.
2. Grant Microsoft Graph **application** permission `Sites.Read.All` and give admin consent.
3. Enter the values in the Integrations page and test.

## Planned for the next stage

- Browse the site's default document library from the publisher console (`listDriveChildren` in `src/sharepoint.mjs` already implements the Graph call).
- Select files/folders and import them as draft catalog entries, mapped through the same format registry used for uploads (PDF, Office, video, images, Markdown).
- Scheduled re-sync with change detection.
