# 2. AWS account, S3, and CloudFront setup

This guide assumes you have never used AWS. CloudFront does not have a separate account or login. You create one AWS account, sign in to the AWS Management Console, and open CloudFront from that console.

The recommended domain layout is:

```text
https://learn.example.com    Public portal and publisher dashboard
https://content.example.com  Sandboxed HTML packages and downloads through CloudFront
```

## A. Create and secure the AWS account

### 1. Create the account

1. Go to `https://aws.amazon.com/`.
2. Choose **Create an AWS Account**.
3. Use an email address that you will keep for the long term. Do not use a temporary personal or employee address that may be lost later.
4. Verify the email address.
5. Set a unique root-user password and store it in a password manager.
6. Enter the requested contact and payment information.
7. Select the free Basic Support plan unless you specifically need paid support.
8. Wait for the account-activation email.

AWS requires a payment method even when your usage remains inside free allowances.

### 2. Secure the root user immediately

Sign in once as **Root user**, then:

1. Open the account menu in the upper-right corner.
2. Choose **Security credentials**.
3. Under **Multi-factor authentication**, register at least one MFA device. A passkey or hardware security key is preferable; a reputable authenticator app is also acceptable.
4. Store recovery information securely.
5. Confirm that the root user has no access keys. Never create root access keys.
6. Do not use the root user for daily AWS work.

### 3. Create day-to-day administrator access

Preferred approach:

1. Search the console for **IAM Identity Center**.
2. Enable IAM Identity Center for this AWS account.
3. Create a user for yourself.
4. Create or select a permission set with `AdministratorAccess` during initial setup.
5. Assign the user to the AWS account.
6. Sign out from the root user.
7. Use the IAM Identity Center sign-in portal from then onward.

For a one-person account, an MFA-protected IAM administrator user is an acceptable temporary alternative, but Identity Center avoids long-lived console credentials and is the better long-term arrangement.

### 4. Protect the billing account

1. Open **Billing and Cost Management**.
2. Open **Budgets**.
3. Create a monthly cost budget. A practical starting budget is USD 15 or USD 20.
4. Add actual-cost alerts at 50 percent, 80 percent, and 100 percent.
5. Add a forecasted-cost alert at 100 percent.
6. Send notifications to an email address that you check.
7. Optionally create a second emergency budget at USD 40.
8. Open **Cost Anomaly Detection** and create a monitor for AWS services.

Budget information is not instantaneous, so it is an alerting control rather than a hard real-time spending cap.

## B. Choose the AWS Region

CloudFront is a global service, but S3 and the application server are regional.

For the lowest-complexity Lightsail deployment, select **Asia Pacific (Mumbai), `ap-south-1`**, or another Lightsail-supported Region close to your expected users. At the time this guide was prepared, Lightsail was not available in the Middle East (UAE) `me-central-1` Region.

If UAE data residency is mandatory, use Amazon EC2 and S3 in `me-central-1` instead of Lightsail. The application supports EC2 instance-role credentials.

Keep the application and its primary S3 buckets in the same Region. CloudFront will distribute the content globally.

## C. Deploy the supplied S3 and CloudFront stack

The build contains:

```text
infra/aws/cloudformation-storage-cdn.yaml
```

This template creates:

- A private, encrypted S3 content bucket.
- S3 Versioning and lifecycle retention for content.
- A private, encrypted S3 backup bucket.
- S3 Versioning and archival lifecycle rules for backups.
- A CloudFront distribution.
- CloudFront Origin Access Control, so the S3 bucket is not public.
- Browser-isolation response headers for uploaded HTML.
- Least-privilege IAM managed policies for the portal application.
- Retain policies to reduce the risk of data deletion when the stack is changed or removed.

### 1. First deployment without a custom content domain

1. Sign in with your day-to-day administrator identity.
2. Select the Region that will contain your S3 buckets, for example **Mumbai**.
3. Search for **CloudFormation**.
4. Choose **Create stack** and then **With new resources (standard)**.
5. Choose **Upload a template file**.
6. Upload `infra/aws/cloudformation-storage-cdn.yaml`.
7. Choose **Next**.
8. Stack name: `openlearn-atlas-production-storage`.
9. Set:

```text
ProjectName: openlearn-atlas
EnvironmentName: production
AllowedAppOrigin: https://learn.example.com
CustomDomainName: leave blank for now
AcmCertificateArn: leave blank for now
```

For initial testing before you own a domain, set `AllowedAppOrigin` to the exact temporary portal URL you will use. It can be updated later.

10. Choose **Next**.
11. Leave the default stack options unless your organization requires tags.
12. On the review page, acknowledge that CloudFormation will create IAM resources.
13. Choose **Submit**.
14. Wait until the stack status is `CREATE_COMPLETE`.
15. Open the **Outputs** tab and record all values:

```text
ContentBucketName
BackupBucketName
CloudFrontDistributionId
CloudFrontDomainName
ContentUploaderPolicyArn
BackupWriterPolicyArn
```

The CloudFront address will resemble:

```text
https://d111111abcdef8.cloudfront.net
```

Use that as `CDN_BASE_URL` until the custom `content.` domain is ready.

### 2. Confirm that S3 is private

1. Open **S3**.
2. Open the content bucket from the CloudFormation output.
3. Open **Permissions**.
4. Confirm that **Block all public access** is enabled.
5. Confirm that the bucket policy allows reads only from your CloudFront distribution.
6. Open **Properties** and confirm that **Bucket Versioning** is enabled.
7. Repeat the versioning check for the backup bucket.

Do not turn the bucket into an S3 static website. The portal uses the private S3 REST origin with CloudFront Origin Access Control.

### 3. Select the CloudFront pricing model

CloudFront supports both pay-as-you-go billing and flat-rate plans. For a self-funded first release, review the flat-rate plan immediately after the distribution is created:

1. Open **CloudFront** in the AWS console.
2. Choose **Distributions**.
3. Select the distribution ID from the CloudFormation output.
4. Choose **Manage plan** or the pricing-plan action shown by the current console.
5. Select **Free** when AWS confirms that the account and distribution are eligible. The published allowance is 1 million requests and 100 GB transfer per month at USD 0, with no overage charges.
6. Select **Pro** only when you need its larger allowance or logging/features. Its published price is USD 15 per distribution per month, with 10 million requests and 50 TB transfer.
7. Review every resource that the console proposes to associate, including WAF, Route 53, logging, and S3 credits.
8. Complete the subscription and confirm the plan name on the distribution page.
9. Keep the AWS Budget configured even when using a flat-rate plan because S3 object operations, snapshots, the server, domain registration, and unrelated AWS services can still be billed.

AWS applies eligibility and configuration rules. If the console says the distribution is not eligible, leave it on pay-as-you-go, keep `PriceClass_100`, and monitor the bill. Flat-rate plans have no monetary overage charge, but AWS documents that sustained usage materially above the allowance can result in performance adjustments until you upgrade.

## D. Add a custom CloudFront domain

This section configures `content.example.com`.

### 1. Own a domain

You can:

- Register a domain in Route 53.
- Transfer an existing domain to Route 53.
- Keep your current registrar and only add the DNS records there.

The application does not require the registrar and hosting provider to be the same company.

### 2. Request the CloudFront certificate

CloudFront certificates must be requested or imported in **US East (N. Virginia), `us-east-1`**.

1. In the AWS console Region selector, choose **US East (N. Virginia)**.
2. Search for **Certificate Manager**.
3. Choose **Request** and then **Request a public certificate**.
4. Enter `content.example.com`.
5. Select **DNS validation**.
6. Choose **Request**.
7. If Route 53 hosts the domain, choose **Create records in Route 53**.
8. Otherwise copy the displayed CNAME validation record into your external DNS provider.
9. Wait until the certificate status is **Issued**.
10. Copy the certificate ARN.

### 3. Update the CloudFormation stack

1. Return to the Region where you created the stack, for example Mumbai.
2. Open **CloudFormation**.
3. Select `openlearn-atlas-production-storage`.
4. Choose **Update**.
5. Choose **Use current template**.
6. Set:

```text
AllowedAppOrigin: https://learn.example.com
CustomDomainName: content.example.com
AcmCertificateArn: paste the certificate ARN from us-east-1
```

7. Complete the update and wait for `UPDATE_COMPLETE`.

### 4. Point DNS to CloudFront

If using Route 53:

1. Open **Route 53**.
2. Open the hosted zone for the domain.
3. Choose **Create record**.
4. Record name: `content`.
5. Enable **Alias**.
6. Route traffic to **Alias to CloudFront distribution**.
7. Select the distribution created by the stack.
8. Create the record.

If using another DNS provider, create:

```text
Type: CNAME
Name: content
Target: the CloudFrontDomainName output
```

After DNS propagates, test a known object through `https://content.example.com/...`.

## E. Create the application identity

### Preferred for EC2: instance role

When using EC2, create an IAM role for EC2 and attach both managed policies output by the CloudFormation stack. Attach the role to the EC2 instance. Leave these values empty in `.env`:

```dotenv
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_SESSION_TOKEN=
```

The application retrieves temporary credentials from the EC2 instance metadata service.

### Required for the supplied Lightsail path: restricted IAM access key

Lightsail does not provide the same EC2 instance-profile workflow. Use a dedicated IAM user with only the two generated managed policies:

1. Open **IAM**.
2. Choose **Users**, then **Create user**.
3. Name: `openlearn-atlas-production-app`.
4. Do not enable console access.
5. Finish creating the user.
6. Open the user and choose **Add permissions**.
7. Attach the two policy ARNs from the CloudFormation outputs.
8. Open **Security credentials**.
9. Create one access key for the application.
10. Copy the access-key ID and secret once into the server's protected `.env` file.
11. Never place the key in GitHub, a ZIP release, a Docker image, or a screenshot.
12. Rotate it periodically and immediately if exposure is suspected.

The application identity cannot delete content or backup objects. It can upload and read the objects required by the portal.

## F. Configure the application for S3 and CloudFront

In the production `.env` file:

```dotenv
NODE_ENV=production
PUBLIC_BASE_URL=https://learn.example.com

STORAGE_DRIVER=s3
AWS_REGION=ap-south-1
CONTENT_S3_BUCKET=the-ContentBucketName-output
BACKUP_S3_BUCKET=the-BackupBucketName-output
CDN_BASE_URL=https://content.example.com
S3_PREFIX=portal

AUTO_BACKUP=true
AUTO_BACKUP_HOUR_UTC=2
BACKUP_RETENTION_COUNT=30
```

For EC2 with an attached IAM role, omit access keys. For Lightsail, add the dedicated restricted key:

```dotenv
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
```

Protect the file on Linux:

```bash
sudo chown root:root .env
sudo chmod 600 .env
```

If the portal is run by a non-root deployment account, make that account the owner instead of root and retain mode `600`.

## G. CloudFront operational notes

- A view or download registered by the portal means the portal endpoint was used. A person can retain a direct CloudFront URL and bypass later portal analytics.
- In version 0.2.0 S3 mode, a direct permanent CloudFront URL also bypasses the application's sign-in and premium entitlement check. Keep production S3-hosted resources open-only until short-lived CloudFront signed URLs or signed cookies are implemented.
- An archived or unpublished resource disappears from the catalog, but a previously known CloudFront URL may remain accessible until the object is denied or removed and cached copies expire or are invalidated.
- For strict revocation and restricted access, add an application entitlement check that issues short-lived CloudFront signed URLs/cookies, plus an operational invalidation/removal workflow.
- Keep content paths versioned and immutable. Upload every package revision under a new version ID to avoid stale cache and evidence-mapping problems.
- Do not disable S3 Versioning merely to reduce cost. Use lifecycle rules to control old-version retention.

## Official references

- AWS account getting started: `https://docs.aws.amazon.com/accounts/latest/reference/getting-started.html`
- CloudFront S3/OAC getting started: `https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/GettingStarted.SimpleDistribution.html`
- Restrict S3 origins with OAC: `https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-restricting-access-to-s3.html`
- S3 Versioning: `https://docs.aws.amazon.com/AmazonS3/latest/userguide/Versioning.html`
- CloudFront custom domains: `https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/CreatingCNAME.html`
- AWS Budgets: `https://docs.aws.amazon.com/cost-management/latest/userguide/budgets-managing-costs.html`
- CloudFront flat-rate plans: `https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/flat-rate-pricing-plan.html`
