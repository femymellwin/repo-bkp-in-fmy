# OpenLearn Atlas Community Learning Platform

Version **0.3.0** is a runnable Mac acceptance build of a public learning library with immutable document revisions, community verification, threaded feedback, optional accounts, access tiers, publisher roles, analytics, and verified backups.

It uses only Node.js built-in modules, including SQLite, so there is no dependency installation step. The application can later use S3 and CloudFront for package delivery while its production data and identity layers are migrated to managed services.

## What is included

### New in 0.3.0

- **All-format library.** Upload video (MP4/WebM/MOV/M4V), PDF, PowerPoint, Word, Excel/CSV, Markdown/TXT articles, SVG diagrams (sanitized), PNG/JPG/WebP images, animated GIF flows, and the existing interactive HTML/ZIP packages. Each format gets a purpose-built in-browser experience: video player with poster and seeking, PDF reader, article view, image viewer, or a clean download card for Office formats.
- **Video pipeline.** Poster thumbnails on cards and player, play-overlay gallery cards, range-request streaming locally, CDN delivery in S3 mode, and a `video_play` analytics event.
- **AI studio.** Configure Claude, ChatGPT, Azure OpenAI, Gemini, Ollama, OpenRouter/Groq free tiers, or any OpenAI-compatible endpoint at runtime, with masked keys and one-click connection tests.
- **Icon library.** 16 built-in SVG icons, a generic fallback when no icon matches, uploaded SVG icons (sanitized), and AI-generated icons via the default provider.
- **Integrations (stage two provision).** SharePoint configuration and Microsoft Graph connectivity testing, ready for the upcoming document-library import.
- **Refreshed professional UI.** Sticky translucent header, elevated cards, media-kind badges, and dedicated viewer layouts, all on the light theme.

See `docs/15-MEDIA-FORMATS-AND-VIDEO.md`, `docs/16-AI-STUDIO-AND-ICONS.md`, and `docs/17-SHAREPOINT-PROVISION.md`.


### Public learning portal

- Gallery-first responsive interface with compact branding, search, category, format, and access filters.
- Anonymous browsing for all published catalog metadata.
- Open, account-required, and premium access flags per learning resource.
- Sandboxed preview of standalone HTML or ZIP packages.
- Tracked downloads, anonymous likes, WhatsApp/LinkedIn/email/device sharing, and related resources.

### SPIN verification and community improvement

- Per-revision **SPIN verified** voting:
  - **I am able to install**
  - **I am not able to install**
- Configurable minimum-vote and success-percentage thresholds.
- Anonymous or signed-in comments for errors, suggestions, questions, and general discussion.
- Publisher message inbox with threaded replies, resolve/reopen, and moderation controls.
- Every vote and comment remains attached to the exact revision it evaluated.

### Revisions and publishing

- Stable document records with immutable package revisions below them.
- Upload a revised HTML/ZIP package as a draft or publish it immediately.
- Publishing a revision atomically makes it current and archives every older non-archived revision.
- Previous package files, SPIN votes, comments, and audit history are retained.
- Metadata edits and package-revision publication are separate operations.
- Followers can see that a new revision has been published.

### Accounts, roles, and branding

- Public exploration remains available without an account.
- Local account registration protected by CAPTCHA.
- Optional Google sign-in using authorization code flow, state, and PKCE.
- Favorites and revision follows for signed-in members.
- Premium entitlement flag managed by administrators. A payment gateway is not included in this release.
- Roles: super administrator, administrator, publisher, moderator, and member.
- Multiple staff accounts, disable/enable controls, and premium entitlement management.
- Runtime branding for product name, organization name, product tagline, portal description, and logo.

### Operations

- First-party event analytics, SPIN totals, open-message counts, top resources, and CSV export.
- SQLite schema migrations and write-ahead logging.
- Verified backups using `VACUUM INTO`, SHA-256 file manifests, archive checksum sidecars, retention, and optional S3 upload.
- Local storage for Mac testing or S3/CloudFront storage mode.
- Docker, GitHub Actions CI, tagged release packaging, and AWS CloudFormation infrastructure.

## Run on a Mac

Requirements: Node.js 22.13 or later.

```bash
cp .env.example .env
npm test
npm start
```

Open:

```text
Public portal:   http://localhost:3000
Sign in:         http://localhost:3000/login
Publisher login: http://localhost:3000/admin/login
Health check:    http://localhost:3000/health
```

Initial evaluation account:

```text
Email:    admin@example.com
Password: ChangeMe123!
```

You can also double-click `start-mac.command` in Finder.

## Test the requested workflow

1. Open the included turbofan resource without signing in.
2. Vote in **SPIN verified** and post an anonymous failed-step comment.
3. Create a member account, then favorite and follow the document.
4. Sign in to the publisher console.
5. Open **Messages**, reply to the comment, and mark it resolved.
6. Open **Edit / revisions**, upload revision `1.1`, and publish it.
7. Confirm revision `1.0` is archived, revision `1.1` is current, and the old comment still says revision `1.0`.
8. Create another administrator under **Users**.
9. Change a resource to open, sign-in, or premium access.
10. Change product/company branding under **Branding**.
11. Create and verify a backup.

## Upgrade from version 0.1.0

Do not copy the old database into the release archive. Keep the existing runtime directories and replace only application source files.

Before upgrading:

```bash
npm run backup
npm run verify-backup -- /full/path/to/the/new-backup.tgz
```

Then stop the old server, deploy version 0.2.0 over a copy of the source tree, retain `data/`, `backups/`, and `.env`, and start the new release. The migration:

- preserves every existing content item, event, like, metadata revision, audit record, and storage key;
- creates a legacy immutable package revision for each existing document;
- adds user, comment, SPIN vote, favorite, follow, branding, and content-version tables;
- records schema version `2`.

Set the desired bootstrap administrator credentials in `.env` **before the first version 0.2.0 start**, because the prior release did not have database-backed users. After creation, staff accounts are managed in the publisher console.

## Data locations

```text
data/portal.sqlite     Users, content metadata, revisions, comments, votes, analytics, settings
data/storage/          Local package revisions, previews, thumbnails, and logo
backups/               Checksum-verified application backup archives
.env                   Secrets and deployment configuration
```

These paths are excluded from Git. Updating or rolling back source code does not overwrite them.

## Backup commands

```bash
npm run backup
npm run verify-backup -- /full/path/to/backups/learning-portal-YYYYMMDDTHHMMSSZ.tgz
```

Restore only while the portal is stopped:

```bash
npm run restore -- /full/path/to/backup.tgz --yes
```

The restore workflow first creates a safety backup of the current state.

## Documentation

- [Mac quick start and acceptance workflow](docs/01-MAC-QUICKSTART.md)
- [AWS account and CloudFront setup](docs/02-AWS-ACCOUNT-CLOUDFRONT.md)
- [Affordable AWS deployment](docs/03-AWS-DEPLOYMENT.md)
- [Vercel option and limitations](docs/04-VERCEL-OPTION.md)
- [Backup and restore](docs/05-BACKUP-RESTORE.md)
- [GitHub security and releases](docs/06-GIT-GITHUB-RELEASES.md)
- [Security and operations](docs/07-SECURITY-OPERATIONS.md)
- [Cost plan](docs/08-COST-PLAN.md)
- [Production upgrade roadmap](docs/09-PRODUCTION-UPGRADE.md)
- [Build and test report](docs/10-BUILD-TEST-REPORT.md)
- [Community, access, and revision workflow](docs/11-COMMUNITY-REVISION-WORKFLOW.md)
- [Google sign-in and CAPTCHA setup](docs/12-GOOGLE-TURNSTILE-SETUP.md)
- [Large-scale production target architecture](docs/13-PRODUCTION-TARGET-ARCHITECTURE.md)
- [Upgrade from version 0.1.0](docs/14-UPGRADE-FROM-V0.1.md)

## Production boundary

This release is deliberately optimized for feature acceptance on one Mac or one persistent application server. Its data model, immutable revision keys, audit records, access controls, backup format, and S3 object layout are production-oriented. It is **not yet the final multi-node architecture** for a globally significant platform.

Before high-scale public launch, implement managed PostgreSQL, managed identity/MFA for staff, email verification or Google-only self-registration, direct multipart uploads to a quarantine S3 prefix, malware scanning, distributed rate limiting, centralized logs, payment-provider webhooks for premium entitlement, and CloudFront signed delivery for restricted packages. The target architecture document maps the current code to those services without changing the public browsing model.
