import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { loadConfig } from '../src/config.mjs';
import { PortalDatabase } from '../src/db.mjs';
import { PortalStorage } from '../src/storage.mjs';
import { createBackup, extractVerifiedBackup, verifyBackupArchive } from '../src/backup.mjs';

const archiveArg = process.argv[2];
const confirmed = process.argv.includes('--yes');
if (!archiveArg || !confirmed) {
  console.error('Stop the portal first, then run: npm run restore -- /full/path/to/backup.tgz --yes');
  process.exit(1);
}

const config = loadConfig();
const archivePath = path.resolve(archiveArg);
const workRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'learning-portal-restore-'));
const preservedArchive = path.join(workRoot, 'source-backup.tgz');
const preservedChecksum = `${preservedArchive}.sha256`;
const extractionRoot = path.join(workRoot, 'snapshot');

function replaceFileAtomically(source, target) {
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const token = `${Date.now()}-${process.pid}`;
  const incoming = `${target}.restore-incoming-${token}`;
  const previous = `${target}.pre-restore-${token}`;
  fs.copyFileSync(source, incoming);
  try {
    if (fs.existsSync(target)) fs.renameSync(target, previous);
    fs.renameSync(incoming, target);
  } catch (error) {
    fs.rmSync(incoming, { force: true });
    if (!fs.existsSync(target) && fs.existsSync(previous)) fs.renameSync(previous, target);
    throw error;
  }
  return previous;
}

function replaceDirectoryAtomically(source, target) {
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const token = `${Date.now()}-${process.pid}`;
  const incoming = `${target}.restore-incoming-${token}`;
  const previous = `${target}.pre-restore-${token}`;
  fs.rmSync(incoming, { recursive: true, force: true });
  fs.cpSync(source, incoming, { recursive: true });
  try {
    if (fs.existsSync(target)) fs.renameSync(target, previous);
    fs.renameSync(incoming, target);
  } catch (error) {
    fs.rmSync(incoming, { recursive: true, force: true });
    if (!fs.existsSync(target) && fs.existsSync(previous)) fs.renameSync(previous, target);
    throw error;
  }
  return previous;
}

try {
  // Preserve and verify the requested source before creating the safety backup.
  // The safety-backup retention pass may otherwise prune an old source archive,
  // and second-resolution backup names may otherwise overwrite it.
  fs.copyFileSync(archivePath, preservedArchive);
  if (fs.existsSync(`${archivePath}.sha256`)) fs.copyFileSync(`${archivePath}.sha256`, preservedChecksum);
  verifyBackupArchive(preservedArchive);

  const db = new PortalDatabase(config.databasePath);
  const storage = new PortalStorage(config);
  try {
    console.log('Creating a safety backup before restore...');
    await createBackup({ db, storage, config });
  } finally {
    db.close();
  }

  extractVerifiedBackup(preservedArchive, extractionRoot);
  const restoredDb = path.join(extractionRoot, 'portal.sqlite');
  if (!fs.existsSync(restoredDb)) throw new Error('Backup does not contain portal.sqlite');

  replaceFileAtomically(restoredDb, config.databasePath);
  fs.rmSync(`${config.databasePath}-wal`, { force: true });
  fs.rmSync(`${config.databasePath}-shm`, { force: true });

  const restoredStorage = path.join(extractionRoot, 'storage');
  if (fs.existsSync(restoredStorage) && storage.driver === 'local') {
    replaceDirectoryAtomically(restoredStorage, path.join(config.dataDir, 'storage'));
  }

  console.log('Restore completed. Start the portal and verify users, content, revisions, comments, analytics, previews, downloads, and the backup dashboard.');
} finally {
  fs.rmSync(workRoot, { recursive: true, force: true });
}
