import { loadConfig } from '../src/config.mjs';
import { PortalDatabase } from '../src/db.mjs';
import { PortalStorage } from '../src/storage.mjs';
import { createBackup } from '../src/backup.mjs';

const config = loadConfig();
const db = new PortalDatabase(config.databasePath);
const storage = new PortalStorage(config);
try {
  const result = await createBackup({ db, storage, config });
  console.log(`Backup created: ${result.archivePath}`);
  console.log(`SHA-256: ${result.checksum}`);
  console.log(`Uploaded to S3: ${result.uploadedToS3 ? 'yes' : 'no'}`);
} finally {
  db.close();
}
