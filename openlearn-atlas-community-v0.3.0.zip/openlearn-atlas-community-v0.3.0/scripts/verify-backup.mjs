import path from 'node:path';
import { verifyBackupArchive } from '../src/backup.mjs';

const archive = process.argv[2];
if (!archive) {
  console.error('Usage: npm run verify-backup -- /full/path/to/backup.tgz');
  process.exit(1);
}
const result = verifyBackupArchive(path.resolve(archive));
console.log(`Backup is valid. Created: ${result.manifest.createdAt}`);
console.log(`Archive checksum sidecar verified: ${result.archiveChecksumVerified ? 'yes' : 'no (internal file checksums only)'}`);
console.log(`Files checked: ${result.manifest.files.length}`);
