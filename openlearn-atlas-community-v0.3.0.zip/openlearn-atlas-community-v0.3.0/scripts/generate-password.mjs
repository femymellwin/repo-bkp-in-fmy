import { createPasswordHash } from '../src/auth.mjs';

const password = process.argv[2];
if (!password || password.length < 12) {
  console.error('Usage: npm run password-hash -- "a-password-with-at-least-12-characters"');
  process.exit(1);
}
console.log(createPasswordHash(password));
