import fs from 'node:fs';
import path from 'node:path';
import { loadConfig } from '../src/config.mjs';
import { PortalDatabase } from '../src/db.mjs';
import { csvCell } from '../src/utils.mjs';

const config = loadConfig();
const db = new PortalDatabase(config.databasePath);
const exportDir = path.join(config.projectRoot, 'exports');
fs.mkdirSync(exportDir, { recursive: true });
try {
  const events = db.exportEvents();
  const headers = ['id', 'event_type', 'content_id', 'content_title', 'visitor_hash', 'session_hash', 'referrer', 'user_agent', 'metadata_json', 'created_at'];
  const lines = [headers.map(csvCell).join(',')];
  for (const event of events) lines.push(headers.map((header) => csvCell(event[header])).join(','));
  const target = path.join(exportDir, `events-${new Date().toISOString().slice(0, 10)}.csv`);
  fs.writeFileSync(target, `${lines.join('\n')}\n`);
  console.log(`Exported ${events.length} events to ${target}`);
} finally {
  db.close();
}
