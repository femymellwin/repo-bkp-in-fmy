# Security policy

## Reporting a vulnerability

Do not open a public GitHub issue for a suspected vulnerability, exposed secret, unsafe uploaded package, authentication bypass, or premium-content disclosure.

Use a private GitHub security advisory for the repository, or contact the repository owner through a previously verified private channel. Include the affected release, reproduction steps, impact, and relevant logs with secrets and personal data removed.

## Supported versions

Until version 1.0.0, only the latest tagged release is supported. Apply fixes through a reviewed release tag and follow the backup, migration, and rollback procedure in `docs/06-GIT-GITHUB-RELEASES.md`.

## Secrets

Never commit production environment files, databases, uploaded packages, backup archives, AWS access keys, OAuth client secrets, Turnstile secret keys, passwords, session cookies, signing keys, or MFA recovery material.

## Uploaded HTML

Interactive HTML is executable code. Version 0.2 performs archive-structure checks and browser sandboxing, but high-scale production must add quarantine storage, malware scanning, content-security review, and an explicit approval/publish pipeline.

## Restricted content

Application access checks protect local preview/download routes. In production S3/CloudFront mode, account-required and premium packages must use a private delivery mechanism such as short-lived CloudFront signed URLs or signed cookies. A hard-to-guess object path is not authorization.

## Account security

- Enable Google sign-in or verified-email registration before open public account creation.
- Use Turnstile or another server-validated anti-abuse control.
- Staff identities should move to managed SSO with MFA before large-scale production.
- Retain at least one active super administrator.
- Disable departing staff immediately and rotate affected secrets.
