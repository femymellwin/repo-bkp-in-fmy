#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env from .env.example. The demo admin password is ChangeMe123!"
fi

if command -v node >/dev/null 2>&1; then
  if ! node -e "const [major,minor]=process.versions.node.split('.').map(Number);process.exit(major>22||(major===22&&minor>=13)?0:1)"; then
    echo "Node.js 22.13 or later is required. Install it from https://nodejs.org/ or with Homebrew: brew install node@22"
    exit 1
  fi
  (sleep 2; open http://localhost:3000) >/dev/null 2>&1 &
  npm start
elif command -v docker >/dev/null 2>&1; then
  docker compose up --build
else
  echo "Install Node.js 22 or Docker Desktop, then run this file again."
  exit 1
fi
