from __future__ import annotations

import re
from dataclasses import dataclass


DEFAULT_PATTERNS = [
    (re.compile(r"(?i)(authorization:\s*bearer\s+)[A-Za-z0-9._\-+/=]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(api[-_ ]?key\s*[:=]\s*)[^\s,;]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(password\s*[:=]\s*)[^\s,;]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(token\s*[:=]\s*)[^\s,;]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(secret\s*[:=]\s*)[^\s,;]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(connection\s*string\s*[:=]\s*)[^\n]+"), r"\1[REDACTED]"),
    (re.compile(r"eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+"), "[REDACTED_JWT]"),
    (re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"), "[REDACTED_EMAIL]"),
]


@dataclass(frozen=True)
class RedactionResult:
    text: str
    redacted: bool


def redact_text(text: str | None, custom_patterns: list[str] | None = None) -> RedactionResult:
    if not text:
        return RedactionResult(text="", redacted=False)
    redacted_text = text
    changed = False
    for pattern, repl in DEFAULT_PATTERNS:
        new_value = pattern.sub(repl, redacted_text)
        changed = changed or new_value != redacted_text
        redacted_text = new_value
    for pattern_text in custom_patterns or []:
        try:
            pattern = re.compile(pattern_text)
        except re.error:
            continue
        new_value = pattern.sub("[REDACTED]", redacted_text)
        changed = changed or new_value != redacted_text
        redacted_text = new_value
    return RedactionResult(text=redacted_text, redacted=changed)
