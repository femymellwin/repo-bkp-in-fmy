from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import decrypt_value, encrypt_value
from app.models import AppConfig

SECRET_KEYS = {"azure_openai_api_key"}
BOOL_KEYS = {"ai_enabled", "demo_mode", "kube_allow_secret_metadata"}
INT_KEYS = {
    "monitoring_interval_seconds",
    "restart_threshold",
    "pending_minutes_threshold",
    "cpu_warning_percent",
    "memory_warning_percent",
    "log_line_limit",
    "retention_days",
    "anomaly_resolution_cycles",
}


def default_config() -> dict[str, Any]:
    settings = get_settings()
    return {
        "app_name": settings.app_name,
        "app_tagline": settings.app_tagline,
        "logo_path": "",
        "demo_mode": settings.demo_mode,
        "kubeconfig_path": settings.kubeconfig_path,
        "kube_context": settings.kube_context or "",
        "kube_allow_secret_metadata": settings.kube_allow_secret_metadata,
        "monitoring_interval_seconds": settings.monitoring_interval_seconds,
        "anomaly_resolution_cycles": settings.anomaly_resolution_cycles,
        "restart_threshold": 5,
        "pending_minutes_threshold": 10,
        "cpu_warning_percent": 85,
        "memory_warning_percent": 85,
        "log_line_limit": 250,
        "retention_days": 30,
        "azure_openai_endpoint": settings.azure_openai_endpoint or "",
        "azure_openai_api_key": settings.azure_openai_api_key or "",
        "azure_openai_api_version": settings.azure_openai_api_version or "2024-12-01-preview",
        "azure_openai_deployment": settings.azure_openai_deployment or "",
        "azure_openai_model_name": settings.azure_openai_model_name or "",
        "ai_enabled": settings.ai_enabled,
        "redaction_patterns": "",
        "suppression_rules": "",
    }


def coerce_value(key: str, value: Any) -> Any:
    if key in BOOL_KEYS:
        if isinstance(value, bool):
            return value
        return str(value).lower() in {"1", "true", "yes", "y", "on"}
    if key in INT_KEYS:
        try:
            return int(value)
        except (TypeError, ValueError):
            return default_config().get(key)
    return "" if value is None else value


def init_config(db: Session) -> None:
    defaults = default_config()
    for key, value in defaults.items():
        existing = db.get(AppConfig, key)
        if existing is None:
            is_secret = key in SECRET_KEYS
            raw = encrypt_value(str(value)) if is_secret and value else str(value)
            db.add(AppConfig(key=key, value=raw, is_secret=is_secret))
    db.commit()


def get_config_map(db: Session, include_secrets: bool = False) -> dict[str, Any]:
    init_config(db)
    records = db.query(AppConfig).all()
    values: dict[str, Any] = {}
    for item in records:
        if item.is_secret:
            if include_secrets:
                values[item.key] = decrypt_value(item.value)
            else:
                values[item.key] = ""
        else:
            values[item.key] = coerce_value(item.key, item.value)
    for key, value in default_config().items():
        values.setdefault(key, "" if key in SECRET_KEYS else value)
    return values


def public_config(db: Session) -> dict[str, Any]:
    init_config(db)
    values: dict[str, Any] = {}
    secrets: dict[str, bool] = {}
    for item in db.query(AppConfig).all():
        if item.is_secret:
            values[item.key] = ""
            secrets[item.key] = bool(item.value)
        else:
            values[item.key] = coerce_value(item.key, item.value)
    for key, value in default_config().items():
        if key in SECRET_KEYS:
            values.setdefault(key, "")
            secrets.setdefault(key, False)
        else:
            values.setdefault(key, value)
    return {"values": values, "secrets_configured": secrets}


def update_config(db: Session, values: dict[str, Any], actor: str = "system") -> None:
    init_config(db)
    allowed = set(default_config().keys())
    now = datetime.now(timezone.utc)
    for key, value in values.items():
        if key not in allowed:
            continue
        existing = db.get(AppConfig, key)
        is_secret = key in SECRET_KEYS
        if is_secret and (value is None or value == ""):
            continue
        coerced = coerce_value(key, value)
        raw = encrypt_value(str(coerced)) if is_secret else str(coerced)
        if existing:
            existing.value = raw
            existing.is_secret = is_secret
            existing.updated_at = now
            existing.updated_by = actor
        else:
            db.add(AppConfig(key=key, value=raw, is_secret=is_secret, updated_at=now, updated_by=actor))
    db.commit()
