from __future__ import annotations

import json
from sqlalchemy.orm import Session

from app.models import AuditLog


def write_audit(db: Session, actor: str, role: str, action: str, target: str | None = None, details: dict | None = None) -> None:
    db.add(AuditLog(actor=actor, role=role, action=action, target=target, details=json.dumps(details or {})))
    db.commit()
