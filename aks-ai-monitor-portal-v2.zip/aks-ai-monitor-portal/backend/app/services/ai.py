from __future__ import annotations

import json
from typing import Any

try:
    from openai import AzureOpenAI
except Exception:  # pragma: no cover
    AzureOpenAI = None

SYSTEM_PROMPT = """You are a Kubernetes and AKS incident-analysis assistant.
Analyze only the sanitized evidence supplied in the request.
The anomaly has already been detected by deterministic monitoring rules.
Never invent resource names, namespaces, events, metrics, logs, or commands.
Separate confirmed evidence from probable causes.
Use read-only investigation commands by default.
Return valid JSON with summary, confirmed_findings, probable_causes, investigation_steps, recommended_remediation, and missing_information.
"""


def ai_configured(config: dict) -> bool:
    return bool(
        config.get("ai_enabled")
        and config.get("azure_openai_endpoint")
        and config.get("azure_openai_api_key")
        and config.get("azure_openai_api_version")
        and config.get("azure_openai_deployment")
    )


def _client(config: dict):
    if AzureOpenAI is None:
        raise RuntimeError("openai package is not available")
    return AzureOpenAI(
        api_key=config.get("azure_openai_api_key"),
        api_version=config.get("azure_openai_api_version"),
        azure_endpoint=config.get("azure_openai_endpoint"),
    )


def test_azure_openai(config: dict) -> dict:
    if not config.get("azure_openai_endpoint"):
        return {"ok": False, "message": "Azure OpenAI endpoint is required.", "details": {}}
    if not config.get("azure_openai_api_key"):
        return {"ok": False, "message": "Azure OpenAI API key is required.", "details": {}}
    if not config.get("azure_openai_api_version"):
        return {"ok": False, "message": "Azure OpenAI API version is required.", "details": {}}
    if not config.get("azure_openai_deployment"):
        return {"ok": False, "message": "Azure OpenAI deployment name is required.", "details": {}}
    try:
        client = _client(config)
        response = client.chat.completions.create(
            model=config.get("azure_openai_deployment"),
            messages=[
                {"role": "system", "content": "You are a health check endpoint. Reply with JSON."},
                {"role": "user", "content": "Return {\"ok\": true, \"message\": \"connected\"}."},
            ],
            temperature=0,
            max_tokens=80,
        )
        content = response.choices[0].message.content if response.choices else ""
        return {
            "ok": True,
            "message": "Azure OpenAI connection test succeeded.",
            "details": {
                "deployment": config.get("azure_openai_deployment"),
                "model_name": config.get("azure_openai_model_name") or "",
                "response_preview": content[:300],
            },
        }
    except Exception as exc:
        return {"ok": False, "message": "Azure OpenAI connection test failed.", "details": {"error": str(exc)}}


def analyze_anomaly(config: dict, anomaly_payload: dict[str, Any]) -> dict | None:
    if not ai_configured(config):
        return None
    try:
        client = _client(config)
        sanitized_payload = {
            "rule_id": anomaly_payload.get("rule_id"),
            "category": anomaly_payload.get("category"),
            "severity": anomaly_payload.get("severity"),
            "summary": anomaly_payload.get("summary"),
            "technical_details": anomaly_payload.get("technical_details"),
            "resource": {
                "namespace": anomaly_payload.get("namespace"),
                "kind": anomaly_payload.get("resource_kind"),
                "name": anomaly_payload.get("resource_name"),
                "container": anomaly_payload.get("container_name"),
            },
            "evidence": anomaly_payload.get("evidence"),
            "events": anomaly_payload.get("events"),
            "redacted_log_excerpt": anomaly_payload.get("log_excerpt"),
        }
        response = client.chat.completions.create(
            model=config.get("azure_openai_deployment"),
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps(sanitized_payload, default=str)},
            ],
            temperature=0.1,
            max_tokens=900,
        )
        content = response.choices[0].message.content if response.choices else "{}"
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return {"summary": content, "parse_warning": "Model response was not valid JSON."}
    except Exception as exc:
        return {"ai_error": str(exc)}
