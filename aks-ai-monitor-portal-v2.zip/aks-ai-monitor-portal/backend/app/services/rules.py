from __future__ import annotations

import hashlib
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any


BAD_CONTAINER_REASONS = {
    "CrashLoopBackOff",
    "ImagePullBackOff",
    "ErrImagePull",
    "CreateContainerConfigError",
    "CreateContainerError",
    "RunContainerError",
}


@dataclass
class AnomalyCandidate:
    fingerprint: str
    rule_id: str
    category: str
    severity: str
    summary: str
    technical_details: str
    namespace: str | None = None
    resource_kind: str | None = None
    resource_name: str | None = None
    container_name: str | None = None
    evidence: dict | list | None = None
    events: list | dict | None = None
    log_excerpt: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def _fingerprint(*parts: Any) -> str:
    raw = "|".join(str(p or "") for p in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _candidate(rule_id: str, category: str, severity: str, summary: str, technical_details: str, namespace: str | None = None, resource_kind: str | None = None, resource_name: str | None = None, container_name: str | None = None, evidence: dict | list | None = None, events: list | dict | None = None) -> AnomalyCandidate:
    return AnomalyCandidate(
        fingerprint=_fingerprint(rule_id, namespace, resource_kind, resource_name, container_name),
        rule_id=rule_id,
        category=category,
        severity=severity,
        summary=summary,
        technical_details=technical_details,
        namespace=namespace,
        resource_kind=resource_kind,
        resource_name=resource_name,
        container_name=container_name,
        evidence=evidence,
        events=events,
    )


def evaluate_rules(cluster: dict, config: dict) -> list[AnomalyCandidate]:
    restart_threshold = int(config.get("restart_threshold") or 5)
    pending_minutes_threshold = int(config.get("pending_minutes_threshold") or 10)
    candidates: list[AnomalyCandidate] = []

    if not cluster.get("connected"):
        candidates.append(_candidate(
            "KUBE_API_DISCONNECTED",
            "Cluster",
            "Critical",
            "Kubernetes API is not reachable from the monitoring portal.",
            "The collector could not connect using the configured kubeconfig path or context.",
            resource_kind="Cluster",
            resource_name=cluster.get("context") or "unknown",
            evidence={"failures": cluster.get("failures", [])},
        ))
        return candidates

    for failure in cluster.get("failures", []):
        candidates.append(_candidate(
            "PARTIAL_COLLECTION_FAILURE",
            "Collector",
            "Warning",
            f"Collector could not read {failure.get('scope')} data.",
            failure.get("message", "A collector query failed."),
            resource_kind="Collector",
            resource_name=failure.get("scope"),
            evidence=failure,
        ))

    for node in cluster.get("nodes", []):
        if not node.get("ready"):
            candidates.append(_candidate(
                "NODE_NOT_READY",
                "Cluster",
                "Critical",
                f"Node {node.get('name')} is not Ready.",
                "The node Ready condition is not True.",
                resource_kind="Node",
                resource_name=node.get("name"),
                evidence=node,
            ))
        for condition in node.get("conditions", []):
            if condition.get("type") in {"MemoryPressure", "DiskPressure", "PIDPressure", "NetworkUnavailable"} and condition.get("status") == "True":
                candidates.append(_candidate(
                    "NODE_PRESSURE_CONDITION",
                    "Cluster",
                    "Critical",
                    f"Node {node.get('name')} reports {condition.get('type')}.",
                    condition.get("message") or condition.get("reason") or "Node pressure condition is active.",
                    resource_kind="Node",
                    resource_name=node.get("name"),
                    evidence={"node": node.get("name"), "condition": condition},
                ))

    events_by_resource = _events_by_resource(cluster.get("events", []))

    for pod in cluster.get("pods", []):
        namespace = pod.get("namespace")
        pod_name = pod.get("name")
        phase = pod.get("phase")
        if phase in {"Failed", "Unknown"}:
            candidates.append(_candidate(
                "POD_BAD_PHASE",
                "Pods",
                "Critical" if phase == "Failed" else "Warning",
                f"Pod {namespace}/{pod_name} is in {phase} phase.",
                "The pod phase indicates a failed or unknown runtime state.",
                namespace=namespace,
                resource_kind="Pod",
                resource_name=pod_name,
                evidence=pod,
                events=events_by_resource.get((namespace, "Pod", pod_name), []),
            ))
        if phase == "Pending" and int(pod.get("age_minutes") or 0) >= pending_minutes_threshold:
            candidates.append(_candidate(
                "POD_PENDING_TOO_LONG",
                "Pods",
                "Warning",
                f"Pod {namespace}/{pod_name} has been Pending for {pod.get('age_minutes')} minutes.",
                "The pod has exceeded the configured Pending duration threshold.",
                namespace=namespace,
                resource_kind="Pod",
                resource_name=pod_name,
                evidence={"age_minutes": pod.get("age_minutes"), "threshold_minutes": pending_minutes_threshold, "pod": pod},
                events=events_by_resource.get((namespace, "Pod", pod_name), []),
            ))
        for container in (pod.get("init_containers") or []) + (pod.get("containers") or []):
            cname = container.get("name")
            reason = container.get("reason") or ""
            if reason in BAD_CONTAINER_REASONS:
                severity = "Critical" if reason in {"CrashLoopBackOff", "CreateContainerConfigError"} else "Warning"
                candidates.append(_candidate(
                    "CONTAINER_BAD_WAITING_REASON",
                    "Pods",
                    severity,
                    f"Container {namespace}/{pod_name}/{cname} is waiting with {reason}.",
                    container.get("message") or "Container is in a known abnormal waiting state.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"pod": pod_name, "container": container},
                    events=events_by_resource.get((namespace, "Pod", pod_name), []),
                ))
            if int(container.get("restart_count") or 0) >= restart_threshold:
                candidates.append(_candidate(
                    "CONTAINER_RESTART_THRESHOLD",
                    "Pods",
                    "Warning",
                    f"Container {namespace}/{pod_name}/{cname} restarted {container.get('restart_count')} times.",
                    "Restart count exceeded the configured threshold.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"restart_count": container.get("restart_count"), "threshold": restart_threshold, "container": container},
                    events=events_by_resource.get((namespace, "Pod", pod_name), []),
                ))
            if container.get("last_reason") == "OOMKilled" or reason == "OOMKilled":
                candidates.append(_candidate(
                    "CONTAINER_OOMKILLED",
                    "Resources",
                    "Critical",
                    f"Container {namespace}/{pod_name}/{cname} was OOMKilled.",
                    "The last container termination reason indicates out-of-memory termination.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"container": container},
                    events=events_by_resource.get((namespace, "Pod", pod_name), []),
                ))
            resources = container.get("resources") or {}
            requests = resources.get("requests") or {}
            limits = resources.get("limits") or {}
            if not requests or "cpu" not in requests or "memory" not in requests:
                candidates.append(_candidate(
                    "CONTAINER_MISSING_REQUESTS",
                    "Resources",
                    "Warning",
                    f"Container {namespace}/{pod_name}/{cname} is missing CPU or memory requests.",
                    "Resource requests are recommended for scheduling reliability and capacity planning.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"resources": resources},
                ))
            if not limits or "cpu" not in limits or "memory" not in limits:
                candidates.append(_candidate(
                    "CONTAINER_MISSING_LIMITS",
                    "Resources",
                    "Warning",
                    f"Container {namespace}/{pod_name}/{cname} is missing CPU or memory limits.",
                    "Resource limits are recommended for runaway resource protection.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"resources": resources},
                ))
            probes = container.get("probes") or {}
            if not probes.get("readiness"):
                candidates.append(_candidate(
                    "CONTAINER_MISSING_READINESS_PROBE",
                    "Probes",
                    "Warning",
                    f"Container {namespace}/{pod_name}/{cname} has no readiness probe.",
                    "Readiness probes help Kubernetes route traffic only to ready containers.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"probes": probes},
                ))
            if not probes.get("liveness"):
                candidates.append(_candidate(
                    "CONTAINER_MISSING_LIVENESS_PROBE",
                    "Probes",
                    "Warning",
                    f"Container {namespace}/{pod_name}/{cname} has no liveness probe.",
                    "Liveness probes help Kubernetes recover unhealthy containers.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"probes": probes},
                ))
            if str(container.get("image", "")).endswith(":latest"):
                candidates.append(_candidate(
                    "IMAGE_LATEST_TAG",
                    "Manifests",
                    "Warning",
                    f"Container {namespace}/{pod_name}/{cname} uses the latest image tag.",
                    "The latest tag is mutable and makes rollback and traceability harder.",
                    namespace=namespace,
                    resource_kind="Pod",
                    resource_name=pod_name,
                    container_name=cname,
                    evidence={"image": container.get("image")},
                ))

    for deploy in cluster.get("deployments", []):
        desired = int(deploy.get("desired") or 0)
        available = int(deploy.get("available") or 0)
        if desired > available:
            candidates.append(_candidate(
                "DEPLOYMENT_UNAVAILABLE_REPLICAS",
                "Workloads",
                "Critical" if available == 0 else "Warning",
                f"Deployment {deploy.get('namespace')}/{deploy.get('name')} has {available}/{desired} replicas available.",
                "Available replicas are below desired replicas.",
                namespace=deploy.get("namespace"),
                resource_kind="Deployment",
                resource_name=deploy.get("name"),
                evidence=deploy,
                events=events_by_resource.get((deploy.get("namespace"), "Deployment", deploy.get("name")), []),
            ))

    for sts in cluster.get("statefulsets", []):
        desired = int(sts.get("desired") or 0)
        ready = int(sts.get("ready") or 0)
        if desired > ready:
            candidates.append(_candidate("STATEFULSET_REPLICAS_NOT_READY", "Workloads", "Warning", f"StatefulSet {sts.get('namespace')}/{sts.get('name')} has {ready}/{desired} replicas ready.", "Ready replicas are below desired replicas.", sts.get("namespace"), "StatefulSet", sts.get("name"), evidence=sts))

    for ds in cluster.get("daemonsets", []):
        desired = int(ds.get("desired") or 0)
        available = int(ds.get("available") or 0)
        if desired > available:
            candidates.append(_candidate("DAEMONSET_UNAVAILABLE", "Workloads", "Warning", f"DaemonSet {ds.get('namespace')}/{ds.get('name')} has {available}/{desired} pods available.", "DaemonSet pods are unavailable on expected nodes.", ds.get("namespace"), "DaemonSet", ds.get("name"), evidence=ds))

    for job in cluster.get("jobs", []):
        if int(job.get("failed") or 0) > 0:
            candidates.append(_candidate("JOB_FAILED", "Workloads", "Warning", f"Job {job.get('namespace')}/{job.get('name')} has failed pods.", "The Job status reports one or more failed pods.", job.get("namespace"), "Job", job.get("name"), evidence=job))

    for service in cluster.get("services", []):
        if service.get("selector") and int(service.get("endpoint_count") or 0) == 0:
            candidates.append(_candidate(
                "SERVICE_WITHOUT_ENDPOINTS",
                "Networking",
                "Warning",
                f"Service {service.get('namespace')}/{service.get('name')} has no endpoints.",
                "The Service selector currently does not resolve to ready backing endpoints.",
                namespace=service.get("namespace"),
                resource_kind="Service",
                resource_name=service.get("name"),
                evidence=service,
                events=events_by_resource.get((service.get("namespace"), "Service", service.get("name")), []),
            ))
        if service.get("type") == "LoadBalancer" and not service.get("load_balancer"):
            candidates.append(_candidate(
                "LOADBALANCER_PENDING",
                "Networking",
                "Warning",
                f"LoadBalancer Service {service.get('namespace')}/{service.get('name')} has no external IP or hostname.",
                "The Service status does not contain a load balancer ingress entry.",
                namespace=service.get("namespace"),
                resource_kind="Service",
                resource_name=service.get("name"),
                evidence=service,
            ))

    for pvc in cluster.get("pvcs", []):
        if pvc.get("status") in {"Pending", "Lost"}:
            candidates.append(_candidate(
                "PVC_ABNORMAL_STATUS",
                "Storage",
                "Critical" if pvc.get("status") == "Lost" else "Warning",
                f"PVC {pvc.get('namespace')}/{pvc.get('name')} is {pvc.get('status')}.",
                "PersistentVolumeClaim binding status is abnormal.",
                namespace=pvc.get("namespace"),
                resource_kind="PersistentVolumeClaim",
                resource_name=pvc.get("name"),
                evidence=pvc,
                events=events_by_resource.get((pvc.get("namespace"), "PersistentVolumeClaim", pvc.get("name")), []),
            ))

    for policy in cluster.get("network_policies", []):
        if int(policy.get("selected_pods_count") or 0) == 0:
            candidates.append(_candidate(
                "NETWORK_POLICY_SELECTS_NO_PODS",
                "NetworkPolicy",
                "Warning",
                f"NetworkPolicy {policy.get('namespace')}/{policy.get('name')} selects no pods.",
                "The policy pod selector does not currently match any pod in its namespace.",
                namespace=policy.get("namespace"),
                resource_kind="NetworkPolicy",
                resource_name=policy.get("name"),
                evidence=policy,
            ))

    for event in cluster.get("events", []):
        if event.get("type") == "Warning":
            involved_kind = event.get("involved_kind") or "Event"
            involved_name = event.get("involved_name") or event.get("reason")
            candidates.append(_candidate(
                "KUBERNETES_WARNING_EVENT",
                "Events",
                "Warning",
                f"Warning event {event.get('reason')} on {involved_kind} {event.get('namespace')}/{involved_name}.",
                event.get("message") or "Kubernetes reported a warning event.",
                namespace=event.get("namespace"),
                resource_kind=involved_kind,
                resource_name=involved_name,
                evidence=event,
                events=[event],
            ))

    if not cluster.get("metrics_available"):
        candidates.append(_candidate(
            "METRICS_UNAVAILABLE",
            "Resources",
            "Warning",
            "Kubernetes Metrics Server data is unavailable.",
            "CPU and memory utilization cannot be evaluated until metrics.k8s.io is available to the portal identity.",
            resource_kind="Metrics",
            resource_name="metrics.k8s.io",
            evidence={"metrics_available": cluster.get("metrics_available"), "collected_at": cluster.get("collected_at")},
        ))

    return candidates


def _events_by_resource(events: list[dict]) -> dict[tuple[str, str, str], list[dict]]:
    result: dict[tuple[str, str, str], list[dict]] = {}
    for event in events:
        key = (event.get("namespace") or "", event.get("involved_kind") or "", event.get("involved_name") or "")
        result.setdefault(key, []).append(event)
    return result


def compute_health(cluster: dict, active_anomalies: list[dict]) -> str:
    if not cluster.get("connected"):
        return "Disconnected"
    if cluster.get("failures"):
        return "Unknown"
    severities = {a.get("severity") for a in active_anomalies if a.get("status") in {"Active", "Acknowledged"}}
    if "Critical" in severities:
        return "Critical"
    if "Warning" in severities:
        return "Warning"
    return "Healthy"
