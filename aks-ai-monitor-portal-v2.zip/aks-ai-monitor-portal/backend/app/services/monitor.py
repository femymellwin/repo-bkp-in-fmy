from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from typing import Iterable

try:
    from apscheduler.schedulers.background import BackgroundScheduler
except Exception:  # pragma: no cover
    class BackgroundScheduler:  # minimal no-op fallback for environments without APScheduler
        def __init__(self, timezone: str = "UTC") -> None:
            self.running = False
        def add_job(self, *args, **kwargs) -> None:
            return None
        def start(self) -> None:
            self.running = True
        def shutdown(self, wait: bool = False) -> None:
            self.running = False
from sqlalchemy.orm import Session

from app.models import Anomaly, ResourceSnapshot
from app.services.ai import analyze_anomaly
from app.services.config_service import get_config_map
from app.services.kube_client import KubeCollector
from app.services.rules import AnomalyCandidate, compute_health, evaluate_rules

RESOURCE_COLLECTION_KEYS = {
    "nodes": "Node",
    "namespaces": "Namespace",
    "pods": "Pod",
    "deployments": "Deployment",
    "statefulsets": "StatefulSet",
    "daemonsets": "DaemonSet",
    "jobs": "Job",
    "cronjobs": "CronJob",
    "services": "Service",
    "ingresses": "Ingress",
    "pvcs": "PersistentVolumeClaim",
    "pvs": "PersistentVolume",
    "storageclasses": "StorageClass",
    "network_policies": "NetworkPolicy",
    "configmaps": "ConfigMap",
    "secret_metadata": "Secret",
    "events": "Event",
}


class MonitorEngine:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.scheduler: BackgroundScheduler | None = None

    def start(self, db_factory) -> None:
        from app.services.config_service import get_config_map

        db = db_factory()
        try:
            cfg = get_config_map(db, include_secrets=True)
            interval = int(cfg.get("monitoring_interval_seconds") or 30)
        finally:
            db.close()

        if self.scheduler and self.scheduler.running:
            return
        self.scheduler = BackgroundScheduler(timezone="UTC")
        self.scheduler.add_job(lambda: self.run_once_with_factory(db_factory), "interval", seconds=max(10, interval), id="monitor-cycle", max_instances=1, coalesce=True)
        self.scheduler.start()

    def shutdown(self) -> None:
        if self.scheduler and self.scheduler.running:
            self.scheduler.shutdown(wait=False)

    def run_once_with_factory(self, db_factory) -> dict:
        db = db_factory()
        try:
            return self.run_once(db)
        finally:
            db.close()

    def run_once(self, db: Session) -> dict:
        if not self._lock.acquire(blocking=False):
            return {"ok": False, "message": "Monitoring cycle already running."}
        try:
            cfg = get_config_map(db, include_secrets=True)
            collector = KubeCollector(
                kubeconfig_path=str(cfg.get("kubeconfig_path") or ""),
                kube_context=str(cfg.get("kube_context") or "") or None,
                demo_mode=bool(cfg.get("demo_mode")),
                allow_secret_metadata=bool(cfg.get("kube_allow_secret_metadata")),
            )
            cluster = collector.collect()
            candidates = evaluate_rules(cluster, cfg)
            self._store_snapshots(db, cluster)
            self._upsert_anomalies(db, cluster, candidates, cfg)
            active = [a for a in self._active_anomaly_dicts(db)]
            summary = self._summary(cluster, active)
            summary["health"] = compute_health(cluster, active)
            self._upsert_snapshot(db, "ClusterSummary", "", "current", summary, cluster.get("collected_at"))
            db.commit()
            return {"ok": True, "message": "Monitoring cycle completed.", "summary": summary}
        finally:
            self._lock.release()

    def _store_snapshots(self, db: Session, cluster: dict) -> None:
        collected = cluster.get("collected_at")
        self._upsert_snapshot(db, "ClusterRaw", "", "current", cluster, collected)
        for key, kind in RESOURCE_COLLECTION_KEYS.items():
            for item in cluster.get(key, []) or []:
                namespace = item.get("namespace") or ""
                name = item.get("name") or f"{kind.lower()}-{uuid.uuid4().hex[:8]}"
                self._upsert_snapshot(db, kind, namespace, name, item, collected)

    @staticmethod
    def _upsert_snapshot(db: Session, kind: str, namespace: str, name: str, data: dict, collected: str | None = None) -> None:
        existing = db.query(ResourceSnapshot).filter_by(kind=kind, namespace=namespace or "", name=name).one_or_none()
        dt = _parse_dt(collected) or datetime.now(timezone.utc)
        raw = json.dumps(data, default=str)
        if existing:
            existing.data_json = raw
            existing.collected_at = dt
        else:
            db.add(ResourceSnapshot(kind=kind, namespace=namespace or "", name=name, data_json=raw, collected_at=dt))

    def _upsert_anomalies(self, db: Session, cluster: dict, candidates: list[AnomalyCandidate], cfg: dict) -> None:
        now = datetime.now(timezone.utc)
        source_dt = _parse_dt(cluster.get("collected_at")) or now
        seen = {c.fingerprint for c in candidates}
        for candidate in candidates:
            existing = db.query(Anomaly).filter_by(fingerprint=candidate.fingerprint).one_or_none()
            payload = candidate.to_dict()
            if existing:
                existing.last_detected = now
                existing.source_collection_ts = source_dt
                existing.occurrence_count += 1
                existing.clear_count = 0
                if existing.status == "Resolved":
                    existing.status = "Active"
                    existing.resolved_at = None
                if existing.status not in {"Suppressed", "Acknowledged"}:
                    existing.status = "Active"
                existing.severity = candidate.severity
                existing.summary = candidate.summary
                existing.technical_details = candidate.technical_details
                existing.evidence_json = json.dumps(candidate.evidence, default=str)
                existing.events_json = json.dumps(candidate.events, default=str)
                if not existing.ai_json:
                    ai = analyze_anomaly(cfg, {**payload, "cluster_name": cluster.get("cluster_name"), "kube_context": cluster.get("context")})
                    existing.ai_json = json.dumps(ai, default=str) if ai else None
            else:
                ai = analyze_anomaly(cfg, {**payload, "cluster_name": cluster.get("cluster_name"), "kube_context": cluster.get("context")})
                db.add(Anomaly(
                    id=uuid.uuid4().hex,
                    fingerprint=candidate.fingerprint,
                    rule_id=candidate.rule_id,
                    cluster_name=cluster.get("cluster_name"),
                    kube_context=cluster.get("context"),
                    namespace=candidate.namespace,
                    resource_kind=candidate.resource_kind,
                    resource_name=candidate.resource_name,
                    container_name=candidate.container_name,
                    category=candidate.category,
                    severity=candidate.severity,
                    status="Active",
                    first_detected=now,
                    last_detected=now,
                    occurrence_count=1,
                    clear_count=0,
                    summary=candidate.summary,
                    technical_details=candidate.technical_details,
                    evidence_json=json.dumps(candidate.evidence, default=str),
                    events_json=json.dumps(candidate.events, default=str),
                    log_excerpt=candidate.log_excerpt,
                    ai_json=json.dumps(ai, default=str) if ai else None,
                    source_collection_ts=source_dt,
                ))

        resolution_cycles = int(cfg.get("anomaly_resolution_cycles") or 2)
        for anomaly in db.query(Anomaly).filter(Anomaly.status.in_(["Active", "Acknowledged"])).all():
            if anomaly.fingerprint not in seen:
                anomaly.clear_count += 1
                if anomaly.clear_count >= resolution_cycles:
                    anomaly.status = "Resolved"
                    anomaly.resolved_at = now

    def _active_anomaly_dicts(self, db: Session) -> Iterable[dict]:
        for anomaly in db.query(Anomaly).filter(Anomaly.status.in_(["Active", "Acknowledged"])).all():
            yield {"severity": anomaly.severity, "status": anomaly.status}

    @staticmethod
    def _summary(cluster: dict, active_anomalies: list[dict]) -> dict:
        counts = {
            "nodes": len(cluster.get("nodes", []) or []),
            "namespaces": len(cluster.get("namespaces", []) or []),
            "pods": len(cluster.get("pods", []) or []),
            "deployments": len(cluster.get("deployments", []) or []),
            "services": len(cluster.get("services", []) or []),
            "pvcs": len(cluster.get("pvcs", []) or []),
            "events": len(cluster.get("events", []) or []),
        }
        severity_counts: dict[str, int] = {"Critical": 0, "Warning": 0, "Info": 0}
        for item in active_anomalies:
            severity_counts[item.get("severity", "Info")] = severity_counts.get(item.get("severity", "Info"), 0) + 1
        return {
            "connected": bool(cluster.get("connected")),
            "health": "Unknown",
            "cluster_name": cluster.get("cluster_name"),
            "context": cluster.get("context"),
            "version": cluster.get("version"),
            "last_collection": cluster.get("collected_at"),
            "counts": counts,
            "active_anomalies": severity_counts,
            "failures": cluster.get("failures", []),
            "metrics_available": cluster.get("metrics_available"),
        }


def _parse_dt(value: str | None):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


monitor_engine = MonitorEngine()
