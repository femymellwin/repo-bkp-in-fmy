from __future__ import annotations

from datetime import datetime, timedelta, timezone


def demo_cluster_data() -> dict:
    now = datetime.now(timezone.utc)
    return {
        "connected": True,
        "cluster_name": "demo-aks-local",
        "context": "demo-admin@demo-aks-local",
        "version": "v1.30.5",
        "collected_at": now.isoformat(),
        "failures": [],
        "metrics_available": False,
        "nodes": [
            {
                "name": "aks-nodepool1-000001",
                "ready": True,
                "conditions": [{"type": "Ready", "status": "True", "reason": "KubeletReady"}],
                "capacity": {"cpu": "4", "memory": "16Gi"},
                "allocatable": {"cpu": "3900m", "memory": "14500Mi"},
            },
            {
                "name": "aks-nodepool1-000002",
                "ready": False,
                "conditions": [
                    {"type": "Ready", "status": "False", "reason": "KubeletNotReady", "message": "container runtime network not ready"},
                    {"type": "MemoryPressure", "status": "False"},
                    {"type": "DiskPressure", "status": "False"},
                ],
                "capacity": {"cpu": "4", "memory": "16Gi"},
                "allocatable": {"cpu": "3900m", "memory": "14500Mi"},
            },
        ],
        "namespaces": [
            {"name": "default", "status": "Active"},
            {"name": "payments", "status": "Active"},
            {"name": "platform", "status": "Active"},
        ],
        "pods": [
            {
                "namespace": "payments",
                "name": "payments-api-7c9f7d8f9b-k2j8p",
                "phase": "Running",
                "age_minutes": 42,
                "node_name": "aks-nodepool1-000001",
                "pod_ip": "10.244.1.18",
                "labels": {"app": "payments-api", "tier": "api"},
                "containers": [
                    {
                        "name": "api",
                        "image": "contoso.azurecr.io/payments-api:latest",
                        "ready": False,
                        "restart_count": 8,
                        "state": "waiting",
                        "reason": "CrashLoopBackOff",
                        "message": "back-off restarting failed container",
                        "last_state": "terminated",
                        "last_reason": "Error",
                        "resources": {"requests": {"cpu": "250m"}, "limits": {}},
                        "probes": {"liveness": True, "readiness": False, "startup": False},
                    }
                ],
                "volumes": [{"name": "config", "config_map": "payments-api-config"}],
                "secret_refs": ["payments-api-secret"],
                "config_map_refs": ["payments-api-config"],
            },
            {
                "namespace": "platform",
                "name": "worker-55cfd7f8b7-xd8p9",
                "phase": "Pending",
                "age_minutes": 19,
                "node_name": "",
                "pod_ip": "",
                "labels": {"app": "worker"},
                "containers": [
                    {
                        "name": "worker",
                        "image": "contoso.azurecr.io/worker:1.4.2",
                        "ready": False,
                        "restart_count": 0,
                        "state": "waiting",
                        "reason": "Unschedulable",
                        "message": "0/2 nodes are available: insufficient memory",
                        "last_state": "",
                        "last_reason": "",
                        "resources": {"requests": {"cpu": "2", "memory": "10Gi"}, "limits": {"cpu": "2", "memory": "10Gi"}},
                        "probes": {"liveness": False, "readiness": False, "startup": False},
                    }
                ],
                "volumes": [],
                "secret_refs": [],
                "config_map_refs": [],
            },
        ],
        "deployments": [
            {"namespace": "payments", "name": "payments-api", "desired": 3, "available": 1, "ready": 1, "updated": 3, "labels": {"app": "payments-api"}, "selector": {"app": "payments-api"}},
            {"namespace": "platform", "name": "worker", "desired": 1, "available": 0, "ready": 0, "updated": 1, "labels": {"app": "worker"}, "selector": {"app": "worker"}},
        ],
        "statefulsets": [],
        "daemonsets": [],
        "jobs": [],
        "cronjobs": [],
        "services": [
            {"namespace": "payments", "name": "payments-api", "type": "ClusterIP", "cluster_ip": "10.0.38.20", "selector": {"app": "payments-api"}, "ports": [{"port": 80, "target_port": "http"}], "endpoint_count": 1},
            {"namespace": "platform", "name": "worker-api", "type": "ClusterIP", "cluster_ip": "10.0.44.10", "selector": {"app": "worker-api"}, "ports": [{"port": 8080, "target_port": 8080}], "endpoint_count": 0},
            {"namespace": "platform", "name": "public-gateway", "type": "LoadBalancer", "cluster_ip": "10.0.12.44", "selector": {"app": "gateway"}, "ports": [{"port": 443, "target_port": 8443}], "endpoint_count": 2, "load_balancer": []},
        ],
        "pvcs": [
            {"namespace": "platform", "name": "reports-data", "status": "Pending", "storage_class": "managed-premium", "volume_name": "", "access_modes": ["ReadWriteOnce"]}
        ],
        "pvs": [],
        "storageclasses": [{"name": "managed-premium", "provisioner": "disk.csi.azure.com"}],
        "network_policies": [
            {"namespace": "payments", "name": "allow-api", "pod_selector": {"app": "missing-app"}, "policy_types": ["Ingress"], "selected_pods_count": 0}
        ],
        "configmaps": [{"namespace": "payments", "name": "payments-api-config", "keys": ["APP_MODE", "LOG_LEVEL"]}],
        "secret_metadata": [],
        "events": [
            {"namespace": "payments", "type": "Warning", "reason": "BackOff", "involved_kind": "Pod", "involved_name": "payments-api-7c9f7d8f9b-k2j8p", "message": "Back-off restarting failed container api", "last_timestamp": (now - timedelta(minutes=2)).isoformat(), "count": 8},
            {"namespace": "platform", "type": "Warning", "reason": "FailedScheduling", "involved_kind": "Pod", "involved_name": "worker-55cfd7f8b7-xd8p9", "message": "0/2 nodes are available: insufficient memory", "last_timestamp": (now - timedelta(minutes=4)).isoformat(), "count": 4},
            {"namespace": "platform", "type": "Warning", "reason": "ProvisioningFailed", "involved_kind": "PersistentVolumeClaim", "involved_name": "reports-data", "message": "failed to provision volume with StorageClass managed-premium", "last_timestamp": (now - timedelta(minutes=8)).isoformat(), "count": 2},
        ],
    }
