from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any, Callable

from app.services.demo_data import demo_cluster_data

try:
    from kubernetes import client, config
    from kubernetes.client import ApiException
except Exception:  # pragma: no cover
    client = None
    config = None
    ApiException = Exception


class KubeCollector:
    def __init__(self, kubeconfig_path: str, kube_context: str | None, demo_mode: bool = False, allow_secret_metadata: bool = False):
        self.kubeconfig_path = kubeconfig_path
        self.kube_context = kube_context or None
        self.demo_mode = demo_mode
        self.allow_secret_metadata = allow_secret_metadata
        self.failures: list[dict] = []

    def test_connection(self) -> dict:
        if self.demo_mode:
            data = demo_cluster_data()
            return {"ok": True, "message": "Demo mode is active. No kubeconfig was used.", "details": {"context": data["context"], "version": data["version"]}}
        self._load_config()
        version_api = client.VersionApi()
        version = version_api.get_code()
        contexts, active = config.list_kube_config_contexts(config_file=self.kubeconfig_path)
        return {
            "ok": True,
            "message": "Kubernetes API connection succeeded.",
            "details": {
                "context": self.kube_context or (active or {}).get("name"),
                "version": getattr(version, "git_version", None),
                "available_contexts": [c.get("name") for c in contexts or []],
            },
        }

    def collect(self) -> dict:
        if self.demo_mode:
            return demo_cluster_data()
        now = datetime.now(timezone.utc)
        self.failures = []
        try:
            self._load_config()
            version_api = client.VersionApi()
            version = version_api.get_code()
            contexts, active_context = config.list_kube_config_contexts(config_file=self.kubeconfig_path)
            active_name = self.kube_context or (active_context or {}).get("name")
        except Exception as exc:
            return {
                "connected": False,
                "cluster_name": None,
                "context": self.kube_context,
                "version": None,
                "collected_at": now.isoformat(),
                "failures": [{"scope": "connection", "message": str(exc)}],
                "nodes": [],
                "namespaces": [],
                "pods": [],
                "deployments": [],
                "statefulsets": [],
                "daemonsets": [],
                "jobs": [],
                "cronjobs": [],
                "services": [],
                "pvcs": [],
                "pvs": [],
                "storageclasses": [],
                "network_policies": [],
                "configmaps": [],
                "secret_metadata": [],
                "events": [],
                "metrics_available": False,
            }

        v1 = client.CoreV1Api()
        apps = client.AppsV1Api()
        batch = client.BatchV1Api()
        networking = client.NetworkingV1Api()
        storage = client.StorageV1Api()
        custom = client.CustomObjectsApi()

        namespaces = self._safe("namespaces", lambda: [self._namespace(x) for x in v1.list_namespace(timeout_seconds=15).items], [])
        pods = self._safe("pods", lambda: [self._pod(x) for x in v1.list_pod_for_all_namespaces(timeout_seconds=30).items], [])
        nodes = self._safe("nodes", lambda: [self._node(x) for x in v1.list_node(timeout_seconds=15).items], [])
        deployments = self._safe("deployments", lambda: [self._deployment(x) for x in apps.list_deployment_for_all_namespaces(timeout_seconds=20).items], [])
        statefulsets = self._safe("statefulsets", lambda: [self._statefulset(x) for x in apps.list_stateful_set_for_all_namespaces(timeout_seconds=20).items], [])
        daemonsets = self._safe("daemonsets", lambda: [self._daemonset(x) for x in apps.list_daemon_set_for_all_namespaces(timeout_seconds=20).items], [])
        jobs = self._safe("jobs", lambda: [self._job(x) for x in batch.list_job_for_all_namespaces(timeout_seconds=20).items], [])
        cronjobs = self._safe("cronjobs", lambda: [self._cronjob(x) for x in batch.list_cron_job_for_all_namespaces(timeout_seconds=20).items], [])
        services = self._safe("services", lambda: [self._service(x) for x in v1.list_service_for_all_namespaces(timeout_seconds=20).items], [])
        endpoints = self._safe("endpoints", lambda: [self._endpoint(x) for x in v1.list_endpoints_for_all_namespaces(timeout_seconds=20).items], [])
        endpoint_count = {(e["namespace"], e["name"]): e["endpoint_count"] for e in endpoints}
        for svc in services:
            svc["endpoint_count"] = endpoint_count.get((svc["namespace"], svc["name"]), 0)
        pvcs = self._safe("pvcs", lambda: [self._pvc(x) for x in v1.list_persistent_volume_claim_for_all_namespaces(timeout_seconds=20).items], [])
        pvs = self._safe("pvs", lambda: [self._pv(x) for x in v1.list_persistent_volume(timeout_seconds=20).items], [])
        storageclasses = self._safe("storageclasses", lambda: [self._storageclass(x) for x in storage.list_storage_class(timeout_seconds=20).items], [])
        network_policies = self._safe("network_policies", lambda: [self._network_policy(x, pods) for x in networking.list_network_policy_for_all_namespaces(timeout_seconds=20).items], [])
        ingresses = self._safe("ingresses", lambda: [self._ingress(x) for x in networking.list_ingress_for_all_namespaces(timeout_seconds=20).items], [])
        configmaps = self._safe("configmaps", lambda: [self._configmap(x) for x in v1.list_config_map_for_all_namespaces(timeout_seconds=20).items], [])
        secret_metadata = []
        if self.allow_secret_metadata:
            secret_metadata = self._safe("secret_metadata", lambda: [self._secret_meta(x) for x in v1.list_secret_for_all_namespaces(timeout_seconds=20).items], [])
        events = self._safe("events", lambda: [self._event(x) for x in v1.list_event_for_all_namespaces(timeout_seconds=20).items], [])
        metrics_available = bool(self._safe("metrics", lambda: custom.list_cluster_custom_object("metrics.k8s.io", "v1beta1", "nodes"), None))

        cluster_name = None
        if active_name:
            cluster_name = active_name.split("@")[1] if "@" in active_name else active_name

        return {
            "connected": True,
            "cluster_name": cluster_name,
            "context": active_name,
            "version": getattr(version, "git_version", None),
            "collected_at": now.isoformat(),
            "failures": self.failures,
            "metrics_available": metrics_available,
            "nodes": nodes,
            "namespaces": namespaces,
            "pods": pods,
            "deployments": deployments,
            "statefulsets": statefulsets,
            "daemonsets": daemonsets,
            "jobs": jobs,
            "cronjobs": cronjobs,
            "services": services,
            "ingresses": ingresses,
            "pvcs": pvcs,
            "pvs": pvs,
            "storageclasses": storageclasses,
            "network_policies": network_policies,
            "configmaps": configmaps,
            "secret_metadata": secret_metadata,
            "events": events,
        }

    def read_logs(self, namespace: str, pod: str, container_name: str | None = None, lines: int = 250, previous: bool = False) -> str:
        if self.demo_mode:
            return "2026-08-01T08:00:00Z ERROR failed to connect to database password=[REDACTED]\n2026-08-01T08:00:03Z WARNING retrying connection"
        self._load_config()
        v1 = client.CoreV1Api()
        return v1.read_namespaced_pod_log(
            name=pod,
            namespace=namespace,
            container=container_name,
            tail_lines=lines,
            previous=previous,
            timestamps=True,
        )

    def _load_config(self) -> None:
        if client is None or config is None:
            raise RuntimeError("The kubernetes Python package is not available.")
        if not self.kubeconfig_path:
            raise RuntimeError("Kubeconfig path is empty.")
        if not os.path.exists(self.kubeconfig_path):
            raise RuntimeError(f"Kubeconfig path does not exist: {self.kubeconfig_path}")
        config.load_kube_config(config_file=self.kubeconfig_path, context=self.kube_context)

    def _safe(self, scope: str, fn: Callable[[], Any], default: Any) -> Any:
        try:
            return fn()
        except Exception as exc:
            self.failures.append({"scope": scope, "message": str(exc)})
            return default

    @staticmethod
    def _namespace(obj) -> dict:
        return {"name": obj.metadata.name, "status": obj.status.phase, "labels": obj.metadata.labels or {}}

    @staticmethod
    def _node(obj) -> dict:
        conditions = [{"type": c.type, "status": c.status, "reason": c.reason, "message": c.message} for c in obj.status.conditions or []]
        ready = any(c["type"] == "Ready" and c["status"] == "True" for c in conditions)
        return {"name": obj.metadata.name, "ready": ready, "conditions": conditions, "capacity": dict(obj.status.capacity or {}), "allocatable": dict(obj.status.allocatable or {}), "labels": obj.metadata.labels or {}}

    @staticmethod
    def _container(container, status_by_name: dict) -> dict:
        status = status_by_name.get(container.name)
        state = "unknown"
        reason = ""
        message = ""
        last_state = ""
        last_reason = ""
        ready = False
        restart_count = 0
        if status:
            ready = bool(status.ready)
            restart_count = status.restart_count or 0
            if status.state.waiting:
                state = "waiting"
                reason = status.state.waiting.reason or ""
                message = status.state.waiting.message or ""
            elif status.state.terminated:
                state = "terminated"
                reason = status.state.terminated.reason or ""
                message = status.state.terminated.message or ""
            elif status.state.running:
                state = "running"
            if status.last_state and status.last_state.terminated:
                last_state = "terminated"
                last_reason = status.last_state.terminated.reason or ""
        resources = {
            "requests": dict((container.resources.requests or {}) if container.resources else {}),
            "limits": dict((container.resources.limits or {}) if container.resources else {}),
        }
        probes = {
            "liveness": container.liveness_probe is not None,
            "readiness": container.readiness_probe is not None,
            "startup": container.startup_probe is not None,
        }
        return {
            "name": container.name,
            "image": container.image,
            "ready": ready,
            "restart_count": restart_count,
            "state": state,
            "reason": reason,
            "message": message,
            "last_state": last_state,
            "last_reason": last_reason,
            "resources": resources,
            "probes": probes,
        }

    @classmethod
    def _pod(cls, obj) -> dict:
        statuses = {s.name: s for s in (obj.status.container_statuses or [])}
        init_statuses = {s.name: s for s in (obj.status.init_container_statuses or [])}
        start = obj.status.start_time
        age_minutes = 0
        if start:
            age_minutes = int((datetime.now(timezone.utc) - start).total_seconds() / 60)
        config_map_refs: set[str] = set()
        secret_refs: set[str] = set()
        volumes = []
        for volume in obj.spec.volumes or []:
            v = {"name": volume.name}
            if volume.config_map:
                v["config_map"] = volume.config_map.name
                config_map_refs.add(volume.config_map.name)
            if volume.secret:
                v["secret"] = volume.secret.secret_name
                secret_refs.add(volume.secret.secret_name)
            if volume.persistent_volume_claim:
                v["pvc"] = volume.persistent_volume_claim.claim_name
            volumes.append(v)
        for container in obj.spec.containers or []:
            for env_from in container.env_from or []:
                if env_from.config_map_ref and env_from.config_map_ref.name:
                    config_map_refs.add(env_from.config_map_ref.name)
                if env_from.secret_ref and env_from.secret_ref.name:
                    secret_refs.add(env_from.secret_ref.name)
            for env in container.env or []:
                if env.value_from and env.value_from.config_map_key_ref:
                    config_map_refs.add(env.value_from.config_map_key_ref.name)
                if env.value_from and env.value_from.secret_key_ref:
                    secret_refs.add(env.value_from.secret_key_ref.name)
        return {
            "namespace": obj.metadata.namespace,
            "name": obj.metadata.name,
            "phase": obj.status.phase,
            "age_minutes": age_minutes,
            "node_name": obj.spec.node_name or "",
            "pod_ip": obj.status.pod_ip or "",
            "labels": obj.metadata.labels or {},
            "containers": [cls._container(c, statuses) for c in obj.spec.containers or []],
            "init_containers": [cls._container(c, init_statuses) for c in obj.spec.init_containers or []],
            "volumes": volumes,
            "secret_refs": sorted(secret_refs),
            "config_map_refs": sorted(config_map_refs),
        }

    @staticmethod
    def _deployment(obj) -> dict:
        desired = obj.spec.replicas or 0
        available = obj.status.available_replicas or 0
        ready = obj.status.ready_replicas or 0
        updated = obj.status.updated_replicas or 0
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "desired": desired, "available": available, "ready": ready, "updated": updated, "labels": obj.metadata.labels or {}, "selector": obj.spec.selector.match_labels or {}}

    @staticmethod
    def _statefulset(obj) -> dict:
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "desired": obj.spec.replicas or 0, "ready": obj.status.ready_replicas or 0, "current": obj.status.current_replicas or 0, "updated": obj.status.updated_replicas or 0, "labels": obj.metadata.labels or {}, "selector": obj.spec.selector.match_labels or {}}

    @staticmethod
    def _daemonset(obj) -> dict:
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "desired": obj.status.desired_number_scheduled or 0, "available": obj.status.number_available or 0, "ready": obj.status.number_ready or 0, "unavailable": obj.status.number_unavailable or 0, "labels": obj.metadata.labels or {}, "selector": obj.spec.selector.match_labels or {}}

    @staticmethod
    def _job(obj) -> dict:
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "succeeded": obj.status.succeeded or 0, "failed": obj.status.failed or 0, "active": obj.status.active or 0, "labels": obj.metadata.labels or {}}

    @staticmethod
    def _cronjob(obj) -> dict:
        active = len(obj.status.active or []) if obj.status else 0
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "suspend": bool(obj.spec.suspend), "active": active, "last_schedule_time": str(obj.status.last_schedule_time) if obj.status and obj.status.last_schedule_time else "", "labels": obj.metadata.labels or {}}

    @staticmethod
    def _service(obj) -> dict:
        lb = []
        if obj.status and obj.status.load_balancer and obj.status.load_balancer.ingress:
            lb = [{"ip": i.ip, "hostname": i.hostname} for i in obj.status.load_balancer.ingress]
        return {
            "namespace": obj.metadata.namespace,
            "name": obj.metadata.name,
            "type": obj.spec.type,
            "cluster_ip": obj.spec.cluster_ip,
            "selector": obj.spec.selector or {},
            "ports": [{"name": p.name, "port": p.port, "target_port": str(p.target_port), "node_port": p.node_port, "protocol": p.protocol} for p in obj.spec.ports or []],
            "load_balancer": lb,
            "endpoint_count": 0,
        }

    @staticmethod
    def _endpoint(obj) -> dict:
        count = 0
        for subset in obj.subsets or []:
            count += len(subset.addresses or [])
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "endpoint_count": count}

    @staticmethod
    def _pvc(obj) -> dict:
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "status": obj.status.phase, "storage_class": obj.spec.storage_class_name, "volume_name": obj.spec.volume_name or "", "access_modes": list(obj.spec.access_modes or [])}

    @staticmethod
    def _pv(obj) -> dict:
        return {"name": obj.metadata.name, "status": obj.status.phase, "storage_class": obj.spec.storage_class_name, "capacity": dict(obj.spec.capacity or {}), "access_modes": list(obj.spec.access_modes or [])}

    @staticmethod
    def _storageclass(obj) -> dict:
        return {"name": obj.metadata.name, "provisioner": obj.provisioner, "reclaim_policy": obj.reclaim_policy, "volume_binding_mode": obj.volume_binding_mode}

    @staticmethod
    def _labels_match(selector: dict, labels: dict) -> bool:
        return all(labels.get(k) == v for k, v in (selector or {}).items())

    @classmethod
    def _network_policy(cls, obj, pods: list[dict]) -> dict:
        selector = obj.spec.pod_selector.match_labels or {}
        selected = [p for p in pods if p.get("namespace") == obj.metadata.namespace and cls._labels_match(selector, p.get("labels") or {})]
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "pod_selector": selector, "policy_types": list(obj.spec.policy_types or []), "selected_pods_count": len(selected)}

    @staticmethod
    def _ingress(obj) -> dict:
        backends = []
        for rule in obj.spec.rules or []:
            if rule.http:
                for path in rule.http.paths or []:
                    svc = path.backend.service
                    if svc:
                        backends.append({"service": svc.name, "port": svc.port.number or svc.port.name})
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "class_name": obj.spec.ingress_class_name, "backends": backends, "labels": obj.metadata.labels or {}}

    @staticmethod
    def _configmap(obj) -> dict:
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "keys": sorted(list((obj.data or {}).keys()))}

    @staticmethod
    def _secret_meta(obj) -> dict:
        return {"namespace": obj.metadata.namespace, "name": obj.metadata.name, "type": obj.type, "keys": sorted(list((obj.data or {}).keys()))}

    @staticmethod
    def _event(obj) -> dict:
        return {
            "namespace": obj.metadata.namespace or "",
            "type": obj.type or "",
            "reason": obj.reason or "",
            "involved_kind": obj.involved_object.kind if obj.involved_object else "",
            "involved_name": obj.involved_object.name if obj.involved_object else "",
            "message": obj.message or "",
            "last_timestamp": str(obj.last_timestamp or obj.event_time or obj.metadata.creation_timestamp or ""),
            "count": obj.count or 1,
        }
