from __future__ import annotations

from fastapi import APIRouter

router = APIRouter(prefix="/health", tags=["health"])


@router.get("/live")
def live():
    return {"ok": True, "status": "live"}


@router.get("/ready")
def ready():
    return {"ok": True, "status": "ready"}
