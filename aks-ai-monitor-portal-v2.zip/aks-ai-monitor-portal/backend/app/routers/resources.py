from __future__ import annotations

import json
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.security import get_current_user, require_admin
from app.db import SessionLocal, get_db
from app.models import ResourceSnapshot
from app.schemas import ClusterSummary, ResourceOut
from app.services.monitor import monitor_engine

router = APIRouter(tags=["monitoring"])


def _snapshot_to_resource(row: ResourceSnapshot) -> ResourceOut:
    return ResourceOut(kind=row.kind, namespace=row.namespace, name=row.name, data=json.loads(row.data_json), collected_at=row.collected_at)


@router.get("/cluster/summary", response_model=ClusterSummary)
def cluster_summary(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    row = db.query(ResourceSnapshot).filter_by(kind="ClusterSummary", namespace="", name="current").one_or_none()
    if not row:
        return ClusterSummary(connected=False, health="Unknown", counts={}, active_anomalies={}, failures=[{"scope": "summary", "message": "No monitoring cycle has completed yet."}])
    data = json.loads(row.data_json)
    return ClusterSummary(**data)


@router.post("/refresh")
def manual_refresh(db: Session = Depends(get_db), user: dict = Depends(require_admin)):
    return monitor_engine.run_once(db)


@router.get("/resources/{kind}", response_model=list[ResourceOut])
def resources_by_kind(kind: str, namespace: str | None = Query(default=None), db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    query = db.query(ResourceSnapshot).filter(ResourceSnapshot.kind == kind)
    if namespace is not None:
        query = query.filter(ResourceSnapshot.namespace == namespace)
    return [_snapshot_to_resource(row) for row in query.order_by(ResourceSnapshot.namespace, ResourceSnapshot.name).all()]


@router.get("/nodes", response_model=list[ResourceOut])
def nodes(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return resources_by_kind("Node", None, db, user)


@router.get("/namespaces", response_model=list[ResourceOut])
def namespaces(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return resources_by_kind("Namespace", None, db, user)


@router.get("/pods", response_model=list[ResourceOut])
def pods(namespace: str | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return resources_by_kind("Pod", namespace, db, user)


@router.get("/workloads", response_model=list[ResourceOut])
def workloads(namespace: str | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    kinds = ["Deployment", "StatefulSet", "DaemonSet", "Job", "CronJob"]
    query = db.query(ResourceSnapshot).filter(ResourceSnapshot.kind.in_(kinds))
    if namespace is not None:
        query = query.filter(ResourceSnapshot.namespace == namespace)
    return [_snapshot_to_resource(row) for row in query.order_by(ResourceSnapshot.kind, ResourceSnapshot.namespace, ResourceSnapshot.name).all()]


@router.get("/services", response_model=list[ResourceOut])
def services(namespace: str | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return resources_by_kind("Service", namespace, db, user)


@router.get("/storage", response_model=list[ResourceOut])
def storage(namespace: str | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    kinds = ["PersistentVolumeClaim", "PersistentVolume", "StorageClass"]
    query = db.query(ResourceSnapshot).filter(ResourceSnapshot.kind.in_(kinds))
    if namespace is not None:
        query = query.filter(ResourceSnapshot.namespace == namespace)
    return [_snapshot_to_resource(row) for row in query.order_by(ResourceSnapshot.kind, ResourceSnapshot.namespace, ResourceSnapshot.name).all()]


@router.get("/network-policies", response_model=list[ResourceOut])
def network_policies(namespace: str | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return resources_by_kind("NetworkPolicy", namespace, db, user)


@router.get("/events", response_model=list[ResourceOut])
def events(namespace: str | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return resources_by_kind("Event", namespace, db, user)
