from __future__ import annotations

import os
from pathlib import Path
from fastapi import APIRouter, Depends, File, UploadFile
from sqlalchemy.orm import Session

from app.core.security import get_current_user, require_admin
from app.db import get_db
from app.schemas import AzureAIConfigPayload, ConfigUpdate, KubeConfigPayload, PublicConfig, TestResult
from app.services.ai import test_azure_openai
from app.services.audit import write_audit
from app.services.config_service import get_config_map, public_config, update_config
from app.services.kube_client import KubeCollector

router = APIRouter(tags=["configuration"])


@router.get("/config", response_model=PublicConfig)
def get_config(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return public_config(db)


@router.put("/admin/config")
def put_config(payload: ConfigUpdate, db: Session = Depends(get_db), user: dict = Depends(require_admin)):
    update_config(db, payload.values, actor=user["username"])
    write_audit(db, user["username"], user["role"], "config.update", details={"keys": sorted(payload.values.keys())})
    return {"ok": True, "message": "Configuration updated."}


@router.post("/admin/ai/test", response_model=TestResult)
def test_ai(payload: AzureAIConfigPayload, db: Session = Depends(get_db), user: dict = Depends(require_admin)):
    cfg = get_config_map(db, include_secrets=True)
    overrides = payload.model_dump(exclude_none=True)
    # Preserve existing key when UI sends a blank masked secret field.
    if not overrides.get("azure_openai_api_key"):
        overrides.pop("azure_openai_api_key", None)
    cfg.update(overrides)
    result = test_azure_openai(cfg)
    write_audit(db, user["username"], user["role"], "ai.test", details={"ok": result["ok"], "deployment": cfg.get("azure_openai_deployment")})
    return result


@router.post("/admin/kubeconfig/test", response_model=TestResult)
def test_kube(payload: KubeConfigPayload, db: Session = Depends(get_db), user: dict = Depends(require_admin)):
    cfg = get_config_map(db, include_secrets=True)
    collector = KubeCollector(payload.kubeconfig_path, payload.kube_context, demo_mode=bool(cfg.get("demo_mode")), allow_secret_metadata=bool(cfg.get("kube_allow_secret_metadata")))
    try:
        result = collector.test_connection()
    except Exception as exc:
        result = {"ok": False, "message": "Kubernetes connection test failed.", "details": {"error": str(exc)}}
    write_audit(db, user["username"], user["role"], "kubeconfig.test", details={"ok": result["ok"], "path": payload.kubeconfig_path, "context": payload.kube_context})
    return result


@router.post("/admin/branding/logo")
async def upload_logo(file: UploadFile = File(...), db: Session = Depends(get_db), user: dict = Depends(require_admin)):
    allowed = {"image/png": ".png", "image/jpeg": ".jpg", "image/svg+xml": ".svg", "image/webp": ".webp"}
    suffix = allowed.get(file.content_type or "")
    if suffix is None:
        return {"ok": False, "message": "Unsupported logo type. Use PNG, JPG, SVG, or WEBP."}
    upload_dir = Path("uploads")
    upload_dir.mkdir(exist_ok=True)
    path = upload_dir / f"logo{suffix}"
    content = await file.read()
    if len(content) > 2_000_000:
        return {"ok": False, "message": "Logo must be 2 MB or smaller."}
    path.write_bytes(content)
    update_config(db, {"logo_path": f"/{path.as_posix()}"}, actor=user["username"])
    write_audit(db, user["username"], user["role"], "branding.logo_upload", target=str(path))
    return {"ok": True, "message": "Logo uploaded.", "logo_path": f"/{path.as_posix()}"}
