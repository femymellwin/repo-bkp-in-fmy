from __future__ import annotations

import json
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.security import get_current_user, require_admin
from app.db import get_db
from app.models import Anomaly
from app.schemas import AnomalyOut
from app.services.audit import write_audit

router = APIRouter(prefix="/anomalies", tags=["anomalies"])


def _to_out(a: Anomaly) -> AnomalyOut:
    def loads(value):
        if not value:
            return None
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    return AnomalyOut(
        id=a.id,
        fingerprint=a.fingerprint,
        rule_id=a.rule_id,
        cluster_name=a.cluster_name,
        kube_context=a.kube_context,
        namespace=a.namespace,
        resource_kind=a.resource_kind,
        resource_name=a.resource_name,
        container_name=a.container_name,
        category=a.category,
        severity=a.severity,
        status=a.status,
        first_detected=a.first_detected,
        last_detected=a.last_detected,
        resolved_at=a.resolved_at,
        occurrence_count=a.occurrence_count,
        summary=a.summary,
        technical_details=a.technical_details,
        evidence=loads(a.evidence_json),
        events=loads(a.events_json),
        log_excerpt=a.log_excerpt,
        ai=loads(a.ai_json),
        source_collection_ts=a.source_collection_ts,
    )


@router.get("", response_model=list[AnomalyOut])
def list_anomalies(
    status: str | None = Query(default=None),
    severity: str | None = Query(default=None),
    namespace: str | None = Query(default=None),
    category: str | None = Query(default=None),
    q: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    query = db.query(Anomaly)
    if status:
        query = query.filter(Anomaly.status == status)
    if severity:
        query = query.filter(Anomaly.severity == severity)
    if namespace:
        query = query.filter(Anomaly.namespace == namespace)
    if category:
        query = query.filter(Anomaly.category == category)
    if q:
        like = f"%{q}%"
        query = query.filter((Anomaly.summary.ilike(like)) | (Anomaly.resource_name.ilike(like)) | (Anomaly.rule_id.ilike(like)))
    return [_to_out(a) for a in query.order_by(Anomaly.last_detected.desc()).limit(limit).all()]


@router.get("/{anomaly_id}", response_model=AnomalyOut)
def get_anomaly(anomaly_id: str, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    item = db.get(Anomaly, anomaly_id)
    if not item:
        raise HTTPException(status_code=404, detail="Anomaly not found")
    return _to_out(item)


@router.post("/{anomaly_id}/acknowledge")
def acknowledge(anomaly_id: str, db: Session = Depends(get_db), user: dict = Depends(require_admin)):
    item = db.get(Anomaly, anomaly_id)
    if not item:
        raise HTTPException(status_code=404, detail="Anomaly not found")
    if item.status == "Active":
        item.status = "Acknowledged"
    db.commit()
    write_audit(db, user["username"], user["role"], "anomaly.acknowledge", target=anomaly_id)
    return {"ok": True, "message": "Anomaly acknowledged."}


@router.post("/{anomaly_id}/suppress")
def suppress(anomaly_id: str, db: Session = Depends(get_db), user: dict = Depends(require_admin)):
    item = db.get(Anomaly, anomaly_id)
    if not item:
        raise HTTPException(status_code=404, detail="Anomaly not found")
    item.status = "Suppressed"
    db.commit()
    write_audit(db, user["username"], user["role"], "anomaly.suppress", target=anomaly_id)
    return {"ok": True, "message": "Anomaly suppressed."}
