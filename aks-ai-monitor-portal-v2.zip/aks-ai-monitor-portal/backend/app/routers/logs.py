from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.security import get_current_user
from app.db import get_db
from app.services.config_service import get_config_map
from app.services.kube_client import KubeCollector
from app.services.redaction import redact_text

router = APIRouter(prefix="/logs", tags=["logs"])


@router.get("")
def get_logs(
    namespace: str = Query(..., min_length=1),
    pod: str = Query(..., min_length=1),
    container: str | None = Query(default=None),
    lines: int = Query(default=250, ge=1, le=2000),
    previous: bool = False,
    search: str | None = None,
    db: Session = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    cfg = get_config_map(db, include_secrets=True)
    max_lines = min(lines, int(cfg.get("log_line_limit") or 250))
    collector = KubeCollector(str(cfg.get("kubeconfig_path") or ""), str(cfg.get("kube_context") or "") or None, demo_mode=bool(cfg.get("demo_mode")), allow_secret_metadata=bool(cfg.get("kube_allow_secret_metadata")))
    try:
        raw = collector.read_logs(namespace, pod, container_name=container, lines=max_lines, previous=previous)
        custom = [p for p in str(cfg.get("redaction_patterns") or "").splitlines() if p.strip()]
        redacted = redact_text(raw, custom)
        lines_out = redacted.text.splitlines()
        if search:
            needle = search.lower()
            lines_out = [line for line in lines_out if needle in line.lower()]
        return {"ok": True, "namespace": namespace, "pod": pod, "container": container, "previous": previous, "redacted": redacted.redacted, "lines": lines_out[-max_lines:]}
    except Exception as exc:
        return {"ok": False, "message": "Log retrieval failed.", "details": {"error": str(exc)}, "lines": []}
