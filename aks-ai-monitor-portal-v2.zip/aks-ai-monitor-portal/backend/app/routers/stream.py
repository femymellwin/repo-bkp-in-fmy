from __future__ import annotations

import asyncio
import json
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.security import get_current_user
from app.db import SessionLocal
from app.models import ResourceSnapshot

router = APIRouter(tags=["stream"])


@router.get("/stream")
async def stream(user: dict = Depends(get_current_user)):
    async def generator():
        while True:
            db = SessionLocal()
            try:
                row = db.query(ResourceSnapshot).filter_by(kind="ClusterSummary", namespace="", name="current").one_or_none()
                payload = json.loads(row.data_json) if row else {"health": "Unknown"}
            finally:
                db.close()
            yield f"event: status\ndata: {json.dumps(payload, default=str)}\n\n"
            await asyncio.sleep(5)
    return StreamingResponse(generator(), media_type="text/event-stream")
