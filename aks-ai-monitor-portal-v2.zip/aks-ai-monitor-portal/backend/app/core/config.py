from __future__ import annotations

from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "AKS Insight Portal"
    app_tagline: str = "AI-assisted Kubernetes operations"
    app_env: str = "local"
    demo_mode: bool = True
    database_url: str = "sqlite:///./data/aks_monitor.db"
    frontend_origin: str = "http://localhost:5173"

    jwt_secret: str = Field(default="change-this-local-jwt-secret-please-replace-32-plus-chars")
    app_secret: str = Field(default="change-this-local-config-secret-please-replace-32-plus-chars")
    access_token_expire_minutes: int = 720

    admin_username: str = "admin"
    admin_password: str = "admin123"
    user_username: str = "viewer"
    user_password: str = "viewer123"

    kubeconfig_path: str = "/kube/config"
    kube_context: str | None = None
    kube_allow_secret_metadata: bool = False
    monitoring_interval_seconds: int = 30
    anomaly_resolution_cycles: int = 2

    azure_openai_endpoint: str | None = None
    azure_openai_api_key: str | None = None
    azure_openai_api_version: str | None = "2024-12-01-preview"
    azure_openai_deployment: str | None = None
    azure_openai_model_name: str | None = None
    ai_enabled: bool = False

    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)


@lru_cache
def get_settings() -> Settings:
    return Settings()
