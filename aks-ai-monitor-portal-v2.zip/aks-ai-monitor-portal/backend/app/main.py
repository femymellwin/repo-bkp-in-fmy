from __future__ import annotations

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.core.config import get_settings
from app.db import SessionLocal, init_db
from app.routers import anomalies, auth, config, health, logs, resources, stream
from app.services.config_service import init_config
from app.services.monitor import monitor_engine

settings = get_settings()

app = FastAPI(
    title="AKS AI Monitor Portal API",
    description="Local AKS monitoring portal with deterministic anomaly detection and optional Azure OpenAI analysis.",
    version="1.0.0",
    openapi_url="/api/v1/openapi.json",
    docs_url="/api/v1/docs",
)

origins = [settings.frontend_origin, "http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:5173", "http://127.0.0.1:5173"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs("uploads", exist_ok=True)
os.makedirs("data", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

app.include_router(health.router, prefix="/api/v1")
app.include_router(auth.router, prefix="/api/v1")
app.include_router(config.router, prefix="/api/v1")
app.include_router(resources.router, prefix="/api/v1")
app.include_router(anomalies.router, prefix="/api/v1")
app.include_router(logs.router, prefix="/api/v1")
app.include_router(stream.router, prefix="/api/v1")


@app.on_event("startup")
def startup() -> None:
    init_db()
    db = SessionLocal()
    try:
        init_config(db)
    finally:
        db.close()
    # Run one cycle immediately so the UI is useful after startup.
    monitor_engine.run_once_with_factory(SessionLocal)
    monitor_engine.start(SessionLocal)


@app.on_event("shutdown")
def shutdown() -> None:
    monitor_engine.shutdown()
