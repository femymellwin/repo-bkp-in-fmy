from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    username: str


class UserOut(BaseModel):
    username: str
    role: str


class ConfigItem(BaseModel):
    key: str
    value: str | int | bool | None = None
    is_secret: bool = False


class ConfigUpdate(BaseModel):
    values: dict[str, str | int | bool | None]


class PublicConfig(BaseModel):
    values: dict[str, str | int | bool | None]
    secrets_configured: dict[str, bool]


class AzureAIConfigPayload(BaseModel):
    azure_openai_endpoint: str | None = None
    azure_openai_api_version: str | None = None
    azure_openai_api_key: str | None = None
    azure_openai_deployment: str | None = None
    azure_openai_model_name: str | None = None
    ai_enabled: bool | None = None


class KubeConfigPayload(BaseModel):
    kubeconfig_path: str
    kube_context: str | None = None


class TestResult(BaseModel):
    ok: bool
    message: str
    details: dict | None = None


class ClusterSummary(BaseModel):
    connected: bool
    health: str
    cluster_name: str | None = None
    context: str | None = None
    version: str | None = None
    last_collection: datetime | None = None
    counts: dict = Field(default_factory=dict)
    active_anomalies: dict = Field(default_factory=dict)
    failures: list[dict] = Field(default_factory=list)


class AnomalyOut(BaseModel):
    id: str
    fingerprint: str
    rule_id: str
    cluster_name: str | None = None
    kube_context: str | None = None
    namespace: str | None = None
    resource_kind: str | None = None
    resource_name: str | None = None
    container_name: str | None = None
    category: str
    severity: str
    status: str
    first_detected: datetime
    last_detected: datetime
    resolved_at: datetime | None = None
    occurrence_count: int
    summary: str
    technical_details: str | None = None
    evidence: dict | list | None = None
    events: list | dict | None = None
    log_excerpt: str | None = None
    ai: dict | list | None = None
    source_collection_ts: datetime


class ResourceOut(BaseModel):
    kind: str
    namespace: str
    name: str
    data: dict
    collected_at: datetime
