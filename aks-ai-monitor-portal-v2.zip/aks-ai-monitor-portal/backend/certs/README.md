# Optional corporate CA

Do not place private keys here.

For a TLS-inspecting corporate proxy, run from the repository root:

```bash
./scripts/configure-docker-ca.sh /absolute/path/company-root-ca.pem
docker compose build --no-cache
docker compose up
```

The generated `corporate-ca.crt` file is ignored by Git.
