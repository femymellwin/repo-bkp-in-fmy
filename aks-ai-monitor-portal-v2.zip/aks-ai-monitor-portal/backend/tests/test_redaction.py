from app.services.redaction import redact_text


def test_redacts_password_and_jwt():
    text = "password=supersecret token=abc eyJabc.def.ghi user@example.com"
    result = redact_text(text)
    assert result.redacted is True
    assert "supersecret" not in result.text
    assert "user@example.com" not in result.text
    assert "[REDACTED" in result.text
