from app.services.demo_data import demo_cluster_data
from app.services.rules import evaluate_rules


def test_demo_data_produces_core_anomalies():
    rules = evaluate_rules(demo_cluster_data(), {"restart_threshold": 5, "pending_minutes_threshold": 10})
    rule_ids = {r.rule_id for r in rules}
    assert "NODE_NOT_READY" in rule_ids
    assert "CONTAINER_BAD_WAITING_REASON" in rule_ids
    assert "DEPLOYMENT_UNAVAILABLE_REPLICAS" in rule_ids
    assert "SERVICE_WITHOUT_ENDPOINTS" in rule_ids
    assert "PVC_ABNORMAL_STATUS" in rule_ids


def test_disconnected_short_circuits():
    rules = evaluate_rules({"connected": False, "failures": [{"scope": "connection", "message": "x"}]}, {})
    assert len(rules) == 1
    assert rules[0].rule_id == "KUBE_API_DISCONNECTED"
    assert rules[0].severity == "Critical"
