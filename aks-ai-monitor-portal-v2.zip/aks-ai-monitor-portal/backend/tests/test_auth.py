from app.core.security import authenticate_user, create_access_token, decode_token


def test_authenticate_default_admin():
    user = authenticate_user("admin", "admin123")
    assert user is not None
    assert user["role"] == "admin"


def test_token_roundtrip():
    token = create_access_token("admin", "admin")
    payload = decode_token(token)
    assert payload["sub"] == "admin"
    assert payload["role"] == "admin"
