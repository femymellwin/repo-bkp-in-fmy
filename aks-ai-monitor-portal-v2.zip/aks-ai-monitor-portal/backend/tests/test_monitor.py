from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db import Base
from app.models import Anomaly
from app.services.monitor import monitor_engine
from app.services.config_service import init_config, update_config


def test_monitor_cycle_deduplicates_anomalies(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path}/test.db", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    db = Session()
    init_config(db)
    update_config(db, {"demo_mode": True, "ai_enabled": False}, actor="test")
    monitor_engine.run_once(db)
    first_count = db.query(Anomaly).count()
    monitor_engine.run_once(db)
    second_count = db.query(Anomaly).count()
    assert first_count == second_count
    assert first_count > 0
    assert db.query(Anomaly).first().occurrence_count >= 2
    db.close()
