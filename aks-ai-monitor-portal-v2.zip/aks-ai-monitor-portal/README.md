# AKS Insight Portal

A local white-theme AKS monitoring portal with deterministic Kubernetes anomaly detection and optional Azure OpenAI analysis. It supports administrator and viewer roles, a local kubeconfig path, Azure OpenAI connection settings and test actions, branding, and configurable monitoring thresholds.

## Fastest local start: Python virtual environment + Vite

Prerequisites: Python 3.12, Node.js 20 or newer, and npm.

```bash
cp .env.example .env
chmod +x scripts/*.sh
./scripts/run-local.sh
```

Open `http://localhost:5173`.

Default development accounts:

```text
Admin:  admin / admin123
Viewer: viewer / viewer123
```

Change these values in `.env` before sharing the portal.

### Enterprise/corporate TLS inspection

When pip or npm reports `CERTIFICATE_VERIFY_FAILED`, obtain the enterprise CA certificate in PEM format and run:

```bash
./scripts/run-local.sh --ca-cert /absolute/path/company-root-ca.pem
```

This keeps TLS verification enabled and extends trust with the supplied CA.

Detailed native setup: [`docs/LOCAL_SETUP.md`](docs/LOCAL_SETUP.md)

## Separate local commands

Install both dependency sets:

```bash
./scripts/install-local.sh
```

Backend terminal:

```bash
./scripts/start-backend.sh
```

Frontend terminal:

```bash
./scripts/start-frontend.sh
```

## Docker Compose

```bash
cp .env.example .env
docker compose up --build
```

If Docker is behind a TLS-inspecting proxy:

```bash
./scripts/configure-docker-ca.sh /absolute/path/company-root-ca.pem
docker compose build --no-cache
docker compose up
```

Docker frontend: `http://localhost:3000`.

## Real AKS cluster

### Native local mode

Set an absolute path in `.env`:

```dotenv
DEMO_MODE=false
KUBECONFIG_PATH=/Users/your-user/.kube/config
KUBE_CONTEXT=
```

Then run:

```bash
./scripts/run-local.sh --skip-install
```

### Docker mode

```dotenv
DEMO_MODE=false
KUBECONFIG_HOST_PATH=/Users/your-user/.kube/config
KUBECONFIG_PATH=/kube/config
```

The Docker volume mapping is read-only.

## Admin configuration

The Admin page supports:

- Azure OpenAI endpoint.
- API version.
- API key.
- Deployment name.
- Model name.
- Azure OpenAI connection test.
- Kubeconfig path and optional context.
- Kubernetes connection test.
- Logo upload.
- Application name and tag line.
- Monitoring interval and rule thresholds.

## Architecture

```text
Browser
  -> React/TypeScript UI
  -> FastAPI REST + SSE
       -> Kubernetes collector -> local read-only kubeconfig -> AKS API
       -> deterministic rule engine -> anomaly lifecycle
       -> Azure OpenAI advisory analysis
       -> SQLite persistence
```

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for component details and trust boundaries.

## API documentation

`http://localhost:8000/api/v1/docs`

## Security boundaries

- Monitoring and advisory only; no automatic remediation.
- No arbitrary `kubectl` or shell execution.
- Kubernetes Secret values are never decoded or displayed.
- Kubeconfig contents are never returned to the browser or sent to the AI service.
- Logs and anomaly evidence are redacted before AI processing.
- The Azure OpenAI API key is encrypted in SQLite using `APP_SECRET`.

## Repository layout

```text
backend/   FastAPI backend, collectors, rules, AI integration, tests
frontend/  React TypeScript frontend
scripts/   Native installation, start, stop, diagnostics, and CA setup
k8s/       Read-only RBAC manifest
docs/      Architecture, setup, security, and troubleshooting
data/      Docker data and placeholder kubeconfig
uploads/   Docker logo upload target
```
