# Optional corporate CA

This directory is populated by `scripts/configure-docker-ca.sh` when Docker must trust an enterprise TLS inspection certificate.
