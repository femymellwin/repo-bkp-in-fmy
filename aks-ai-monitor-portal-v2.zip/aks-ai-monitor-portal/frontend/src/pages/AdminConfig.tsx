import { ChangeEvent, useEffect, useState } from 'react'
import { apiFetch } from '../api'
import PageHeader from '../components/PageHeader'

type ConfigResponse = { values: Record<string, any>; secrets_configured: Record<string, boolean> }

export default function AdminConfig() {
  const [values, setValues] = useState<Record<string, any>>({})
  const [secrets, setSecrets] = useState<Record<string, boolean>>({})
  const [message, setMessage] = useState('')
  const [aiTest, setAiTest] = useState('')
  const [kubeTest, setKubeTest] = useState('')

  async function load() {
    const data = await apiFetch<ConfigResponse>('/config')
    setValues(data.values)
    setSecrets(data.secrets_configured)
  }
  useEffect(() => { load() }, [])

  function set(key: string, value: any) {
    setValues(prev => ({ ...prev, [key]: value }))
  }

  async function save(keys?: string[]) {
    const payload: Record<string, any> = {}
    for (const key of keys || Object.keys(values)) payload[key] = values[key]
    await apiFetch('/admin/config', { method: 'PUT', body: JSON.stringify({ values: payload }) })
    setMessage('Configuration saved.')
    await load()
  }

  async function testAI() {
    setAiTest('Testing...')
    const result = await apiFetch<{ ok: boolean; message: string; details?: any }>('/admin/ai/test', {
      method: 'POST',
      body: JSON.stringify({
        azure_openai_endpoint: values.azure_openai_endpoint,
        azure_openai_api_version: values.azure_openai_api_version,
        azure_openai_api_key: values.azure_openai_api_key,
        azure_openai_deployment: values.azure_openai_deployment,
        azure_openai_model_name: values.azure_openai_model_name,
        ai_enabled: values.ai_enabled
      })
    })
    setAiTest(`${result.ok ? 'SUCCESS' : 'FAILED'}: ${result.message}`)
  }

  async function testKube() {
    setKubeTest('Testing...')
    const result = await apiFetch<{ ok: boolean; message: string; details?: any }>('/admin/kubeconfig/test', {
      method: 'POST',
      body: JSON.stringify({ kubeconfig_path: values.kubeconfig_path, kube_context: values.kube_context })
    })
    setKubeTest(`${result.ok ? 'SUCCESS' : 'FAILED'}: ${result.message}`)
  }

  async function uploadLogo(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    const form = new FormData()
    form.append('file', file)
    const result = await apiFetch<{ ok: boolean; message: string; logo_path?: string }>('/admin/branding/logo', { method: 'POST', body: form })
    setMessage(result.message)
    await load()
  }

  return (
    <>
      <PageHeader title="Admin Configuration" subtitle="Admin-only platform settings, AI connection, kubeconfig mapping, branding, and thresholds." actions={<button className="primary-button" onClick={() => save()}>SAVE ALL</button>} />
      {message && <div className="alert success">{message}</div>}

      <section className="panel form-section">
        <h2>Branding</h2>
        <div className="form-grid">
          <label>APPLICATION NAME<input value={values.app_name || ''} onChange={e => set('app_name', e.target.value)} /></label>
          <label>APPLICATION TAG NAME<input value={values.app_tagline || ''} onChange={e => set('app_tagline', e.target.value)} /></label>
          <label>LOGO UPLOAD<input type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp" onChange={uploadLogo} /></label>
        </div>
        {values.logo_path && <div className="logo-preview"><img src={values.logo_path} alt="Application logo" /><span>{values.logo_path}</span></div>}
        <button className="secondary-button" onClick={() => save(['app_name', 'app_tagline'])}>SAVE BRANDING</button>
      </section>

      <section className="panel form-section">
        <h2>Kubeconfig Mapping</h2>
        <p className="section-note">The browser cannot grant backend access to arbitrary local files. Map the kubeconfig into the backend container as read-only, then set the in-container path here. For local Python mode, use the absolute local path.</p>
        <div className="form-grid">
          <label>KUBECONFIG PATH<input value={values.kubeconfig_path || ''} onChange={e => set('kubeconfig_path', e.target.value)} placeholder="/kube/config" /></label>
          <label>KUBE CONTEXT<input value={values.kube_context || ''} onChange={e => set('kube_context', e.target.value)} placeholder="optional" /></label>
          <label className="check-row"><input type="checkbox" checked={!!values.demo_mode} onChange={e => set('demo_mode', e.target.checked)} /> DEMO MODE</label>
          <label className="check-row"><input type="checkbox" checked={!!values.kube_allow_secret_metadata} onChange={e => set('kube_allow_secret_metadata', e.target.checked)} /> ALLOW SECRET METADATA QUERY</label>
        </div>
        <div className="button-row"><button className="secondary-button" onClick={testKube}>TEST KUBERNETES</button><button className="secondary-button" onClick={() => save(['kubeconfig_path', 'kube_context', 'demo_mode', 'kube_allow_secret_metadata'])}>SAVE KUBECONFIG</button></div>
        {kubeTest && <div className="alert neutral">{kubeTest}</div>}
      </section>

      <section className="panel form-section">
        <h2>Azure OpenAI</h2>
        <div className="form-grid">
          <label>AZURE OPENAI ENDPOINT<input value={values.azure_openai_endpoint || ''} onChange={e => set('azure_openai_endpoint', e.target.value)} placeholder="https://resource.openai.azure.com" /></label>
          <label>API VERSION<input value={values.azure_openai_api_version || ''} onChange={e => set('azure_openai_api_version', e.target.value)} /></label>
          <label>DEPLOYMENT NAME<input value={values.azure_openai_deployment || ''} onChange={e => set('azure_openai_deployment', e.target.value)} /></label>
          <label>MODEL NAME<input value={values.azure_openai_model_name || ''} onChange={e => set('azure_openai_model_name', e.target.value)} placeholder="for display and audit" /></label>
          <label>API KEY<input type="password" value={values.azure_openai_api_key || ''} onChange={e => set('azure_openai_api_key', e.target.value)} placeholder={secrets.azure_openai_api_key ? 'Existing key configured' : 'Enter API key'} /></label>
          <label className="check-row"><input type="checkbox" checked={!!values.ai_enabled} onChange={e => set('ai_enabled', e.target.checked)} /> ENABLE AI ANALYSIS</label>
        </div>
        <div className="button-row"><button className="secondary-button" onClick={testAI}>TEST AZURE OPENAI</button><button className="secondary-button" onClick={() => save(['azure_openai_endpoint', 'azure_openai_api_version', 'azure_openai_api_key', 'azure_openai_deployment', 'azure_openai_model_name', 'ai_enabled'])}>SAVE AI SETTINGS</button></div>
        {aiTest && <div className="alert neutral">{aiTest}</div>}
      </section>

      <section className="panel form-section">
        <h2>Monitoring Thresholds</h2>
        <div className="form-grid">
          <label>MONITORING INTERVAL SECONDS<input type="number" value={values.monitoring_interval_seconds || 30} onChange={e => set('monitoring_interval_seconds', Number(e.target.value))} /></label>
          <label>RESTART THRESHOLD<input type="number" value={values.restart_threshold || 5} onChange={e => set('restart_threshold', Number(e.target.value))} /></label>
          <label>PENDING MINUTES<input type="number" value={values.pending_minutes_threshold || 10} onChange={e => set('pending_minutes_threshold', Number(e.target.value))} /></label>
          <label>CPU WARNING PERCENT<input type="number" value={values.cpu_warning_percent || 85} onChange={e => set('cpu_warning_percent', Number(e.target.value))} /></label>
          <label>MEMORY WARNING PERCENT<input type="number" value={values.memory_warning_percent || 85} onChange={e => set('memory_warning_percent', Number(e.target.value))} /></label>
          <label>LOG LINE LIMIT<input type="number" value={values.log_line_limit || 250} onChange={e => set('log_line_limit', Number(e.target.value))} /></label>
        </div>
        <button className="secondary-button" onClick={() => save(['monitoring_interval_seconds', 'restart_threshold', 'pending_minutes_threshold', 'cpu_warning_percent', 'memory_warning_percent', 'log_line_limit'])}>SAVE THRESHOLDS</button>
      </section>
    </>
  )
}
