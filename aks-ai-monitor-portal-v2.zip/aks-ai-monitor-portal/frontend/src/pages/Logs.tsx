import { FormEvent, useState } from 'react'
import { apiFetch } from '../api'
import PageHeader from '../components/PageHeader'

export default function Logs() {
  const [namespace, setNamespace] = useState('payments')
  const [pod, setPod] = useState('payments-api-7c9f7d8f9b-k2j8p')
  const [container, setContainer] = useState('api')
  const [search, setSearch] = useState('')
  const [lines, setLines] = useState<string[]>([])
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event: FormEvent) {
    event.preventDefault()
    setLoading(true)
    setMessage('')
    const params = new URLSearchParams({ namespace, pod, lines: '250' })
    if (container) params.set('container', container)
    if (search) params.set('search', search)
    try {
      const result = await apiFetch<{ ok: boolean; message?: string; lines: string[]; redacted?: boolean }>(`/logs?${params.toString()}`)
      setLines(result.lines || [])
      setMessage(result.ok ? (result.redacted ? 'Logs loaded. Sensitive patterns were redacted.' : 'Logs loaded.') : result.message || 'Failed')
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Log request failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <PageHeader title="Logs" subtitle="Controlled read-only log viewer with redaction before display." />
      <section className="panel">
        <form onSubmit={submit} className="filter-bar">
          <label>NAMESPACE<input value={namespace} onChange={e => setNamespace(e.target.value)} /></label>
          <label>POD<input value={pod} onChange={e => setPod(e.target.value)} /></label>
          <label>CONTAINER<input value={container} onChange={e => setContainer(e.target.value)} /></label>
          <label>SEARCH<input value={search} onChange={e => setSearch(e.target.value)} placeholder="ERROR, WARN, text" /></label>
          <button className="primary-button" disabled={loading}>{loading ? 'LOADING...' : 'VIEW LOGS'}</button>
        </form>
        {message && <div className="alert neutral">{message}</div>}
      </section>
      <section className="panel">
        <h2>Output</h2>
        <pre className="log-block">{lines.join('\n') || 'No log lines loaded.'}</pre>
      </section>
    </>
  )
}
