import { FormEvent, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login } from '../api'

export default function Login() {
  const navigate = useNavigate()
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('admin123')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event: FormEvent) {
    event.preventDefault()
    setLoading(true)
    setError('')
    try {
      await login(username, password)
      navigate('/')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-shell">
      <section className="login-card">
        <div className="brand-mark large">AKS</div>
        <h1>AKS Insight Portal</h1>
        <p>Local AI-assisted monitoring for AKS clusters.</p>
        <form onSubmit={submit} className="form-stack">
          <label>USERNAME<input value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" /></label>
          <label>PASSWORD<input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" /></label>
          {error && <div className="alert danger">{error}</div>}
          <button className="primary-button" disabled={loading}>{loading ? 'SIGNING IN...' : 'SIGN IN'}</button>
        </form>
        <div className="hint">Default local accounts are configured in .env. Change them before sharing access.</div>
      </section>
    </div>
  )
}
