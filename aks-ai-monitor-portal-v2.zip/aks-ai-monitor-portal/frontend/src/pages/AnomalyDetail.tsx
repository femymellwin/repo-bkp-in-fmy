import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { apiFetch } from '../api'
import PageHeader from '../components/PageHeader'
import StatusBadge from '../components/StatusBadge'

type Anomaly = {
  id: string
  rule_id: string
  category: string
  severity: string
  status: string
  summary: string
  technical_details?: string
  namespace?: string
  resource_kind?: string
  resource_name?: string
  container_name?: string
  first_detected: string
  last_detected: string
  occurrence_count: number
  evidence?: unknown
  events?: unknown
  ai?: any
}

export default function AnomalyDetail() {
  const { id } = useParams()
  const [item, setItem] = useState<Anomaly | null>(null)
  async function load() { if (id) setItem(await apiFetch<Anomaly>(`/anomalies/${id}`)) }
  async function act(action: 'acknowledge' | 'suppress') {
    if (!id) return
    await apiFetch(`/anomalies/${id}/${action}`, { method: 'POST', body: '{}' })
    await load()
  }
  useEffect(() => { load() }, [id])
  if (!item) return <div className="center-screen">Loading...</div>
  return (
    <>
      <PageHeader title="Anomaly Detail" subtitle={item.summary} actions={<div className="button-row"><button className="secondary-button" onClick={() => act('acknowledge')}>ACKNOWLEDGE</button><button className="ghost-button" onClick={() => act('suppress')}>SUPPRESS</button></div>} />
      <section className="panel two-column">
        <div>
          <h2>Finding</h2>
          <dl className="detail-list">
            <dt>Severity</dt><dd><StatusBadge value={item.severity} /></dd>
            <dt>Status</dt><dd><StatusBadge value={item.status} /></dd>
            <dt>Rule</dt><dd><code>{item.rule_id}</code></dd>
            <dt>Category</dt><dd>{item.category}</dd>
            <dt>Occurrences</dt><dd>{item.occurrence_count}</dd>
          </dl>
        </div>
        <div>
          <h2>Resource</h2>
          <dl className="detail-list">
            <dt>Namespace</dt><dd>{item.namespace || '-'}</dd>
            <dt>Kind</dt><dd>{item.resource_kind || '-'}</dd>
            <dt>Name</dt><dd>{item.resource_name || '-'}</dd>
            <dt>Container</dt><dd>{item.container_name || '-'}</dd>
            <dt>First Seen</dt><dd>{new Date(item.first_detected).toLocaleString()}</dd>
            <dt>Last Seen</dt><dd>{new Date(item.last_detected).toLocaleString()}</dd>
          </dl>
        </div>
      </section>
      <section className="panel"><h2>Technical Details</h2><p>{item.technical_details || '-'}</p></section>
      {item.ai && <section className="panel"><h2>AI Explanation</h2><pre className="json-block">{JSON.stringify(item.ai, null, 2)}</pre></section>}
      <section className="panel"><h2>Evidence</h2><pre className="json-block">{JSON.stringify(item.evidence, null, 2)}</pre></section>
      <section className="panel"><h2>Related Events</h2><pre className="json-block">{JSON.stringify(item.events, null, 2)}</pre></section>
      <Link className="text-link" to="/anomalies">BACK TO ANOMALIES</Link>
    </>
  )
}
