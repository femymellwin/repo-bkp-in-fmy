import { useEffect, useState } from 'react'
import { apiFetch } from '../api'
import DataTable from '../components/DataTable'
import PageHeader from '../components/PageHeader'

type Resource = { kind: string; namespace: string; name: string; data: any; collected_at: string }
const kinds = ['Node', 'Namespace', 'Pod', 'Deployment', 'StatefulSet', 'DaemonSet', 'Job', 'CronJob', 'Service', 'NetworkPolicy', 'ConfigMap', 'Secret', 'PersistentVolumeClaim', 'PersistentVolume', 'StorageClass', 'Event']

export default function Resources() {
  const [kind, setKind] = useState('Pod')
  const [items, setItems] = useState<Resource[]>([])
  async function load(selected = kind) {
    setItems(await apiFetch<Resource[]>(`/resources/${encodeURIComponent(selected)}`))
  }
  useEffect(() => { load(kind) }, [kind])
  return (
    <>
      <PageHeader title="Resources" subtitle="Read-only Kubernetes resource inventory captured by the latest monitoring cycle." />
      <section className="tabs">
        {kinds.map(k => <button key={k} className={k === kind ? 'tab active' : 'tab'} onClick={() => setKind(k)}>{k.toUpperCase()}</button>)}
      </section>
      <section className="panel">
        <DataTable rows={items} columns={[
          { key: 'kind', title: 'KIND', render: r => r.kind },
          { key: 'namespace', title: 'NAMESPACE', render: r => r.namespace || '-' },
          { key: 'name', title: 'NAME', render: r => r.name },
          { key: 'status', title: 'STATUS', render: r => r.data.status || r.data.phase || (r.data.ready === true ? 'Ready' : r.data.ready === false ? 'Not Ready' : '-') },
          { key: 'collected', title: 'COLLECTED', render: r => new Date(r.collected_at).toLocaleString() }
        ]} />
      </section>
      <section className="panel"><h2>Selected Raw Data</h2><pre className="json-block">{JSON.stringify(items.slice(0, 20).map(i => i.data), null, 2)}</pre></section>
    </>
  )
}
