import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { apiFetch } from '../api'
import PageHeader from '../components/PageHeader'
import StatusBadge from '../components/StatusBadge'
import DataTable from '../components/DataTable'

type Summary = {
  connected: boolean
  health: string
  cluster_name?: string
  context?: string
  version?: string
  last_collection?: string
  counts: Record<string, number>
  active_anomalies: Record<string, number>
  failures: Array<{ scope: string; message: string }>
}

type Anomaly = { id: string; severity: string; status: string; summary: string; namespace?: string; resource_kind?: string; resource_name?: string; last_detected: string }

export default function Dashboard() {
  const [summary, setSummary] = useState<Summary | null>(null)
  const [anomalies, setAnomalies] = useState<Anomaly[]>([])
  const [loading, setLoading] = useState(false)

  async function load() {
    const [s, a] = await Promise.all([
      apiFetch<Summary>('/cluster/summary'),
      apiFetch<Anomaly[]>('/anomalies?limit=8')
    ])
    setSummary(s)
    setAnomalies(a)
  }

  async function refresh() {
    setLoading(true)
    try {
      await apiFetch('/refresh', { method: 'POST', body: '{}' })
      await load()
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const counts = summary?.counts || {}
  const active = summary?.active_anomalies || {}

  return (
    <>
      <PageHeader title="Dashboard" subtitle="Live health summary for the configured AKS context." actions={<button className="primary-button" onClick={refresh} disabled={loading}>{loading ? 'REFRESHING...' : 'MANUAL REFRESH'}</button>} />
      <section className="summary-grid">
        <div className="metric-card"><div className="metric-label">HEALTH</div><StatusBadge value={summary?.health || 'Unknown'} /></div>
        <div className="metric-card"><div className="metric-label">CONNECTION</div><StatusBadge value={summary?.connected || false} /></div>
        <div className="metric-card"><div className="metric-label">CRITICAL</div><div className="metric-value danger-text">{active.Critical || 0}</div></div>
        <div className="metric-card"><div className="metric-label">WARNINGS</div><div className="metric-value warning-text">{active.Warning || 0}</div></div>
      </section>

      <section className="panel two-column">
        <div>
          <h2>Cluster</h2>
          <dl className="detail-list">
            <dt>Cluster</dt><dd>{summary?.cluster_name || '-'}</dd>
            <dt>Context</dt><dd>{summary?.context || '-'}</dd>
            <dt>Version</dt><dd>{summary?.version || '-'}</dd>
            <dt>Last Refresh</dt><dd>{summary?.last_collection ? new Date(summary.last_collection).toLocaleString() : '-'}</dd>
          </dl>
        </div>
        <div>
          <h2>Inventory</h2>
          <div className="compact-grid">
            {Object.entries(counts).map(([key, value]) => <div key={key} className="compact-stat"><span>{key.toUpperCase()}</span><strong>{value}</strong></div>)}
          </div>
        </div>
      </section>

      {summary?.failures?.length ? <div className="alert warning">Partial collection failures detected. Open Admin or API logs for details.</div> : null}

      <section className="panel">
        <div className="section-heading"><h2>Recent Anomalies</h2><Link to="/anomalies">VIEW ALL</Link></div>
        <DataTable rows={anomalies} columns={[
          { key: 'severity', title: 'SEVERITY', render: a => <StatusBadge value={a.severity} /> },
          { key: 'summary', title: 'SUMMARY', render: a => <Link to={`/anomalies/${a.id}`}>{a.summary}</Link> },
          { key: 'resource', title: 'RESOURCE', render: a => `${a.namespace || '-'} / ${a.resource_kind || '-'} / ${a.resource_name || '-'}` },
          { key: 'time', title: 'LAST SEEN', render: a => new Date(a.last_detected).toLocaleString() }
        ]} />
      </section>
    </>
  )
}
