import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { apiFetch } from '../api'
import PageHeader from '../components/PageHeader'
import StatusBadge from '../components/StatusBadge'
import DataTable from '../components/DataTable'

type Anomaly = {
  id: string
  rule_id: string
  category: string
  severity: string
  status: string
  summary: string
  namespace?: string
  resource_kind?: string
  resource_name?: string
  last_detected: string
  occurrence_count: number
}

export default function Anomalies() {
  const [items, setItems] = useState<Anomaly[]>([])
  const [severity, setSeverity] = useState('')
  const [status, setStatus] = useState('')
  const [query, setQuery] = useState('')

  async function load() {
    const params = new URLSearchParams()
    if (severity) params.set('severity', severity)
    if (status) params.set('status', status)
    if (query) params.set('q', query)
    params.set('limit', '250')
    setItems(await apiFetch<Anomaly[]>(`/anomalies?${params.toString()}`))
  }
  useEffect(() => { load() }, [severity, status])

  return (
    <>
      <PageHeader title="Anomalies" subtitle="Deterministic findings with optional AI explanations." actions={<button className="primary-button" onClick={load}>APPLY FILTERS</button>} />
      <section className="panel filter-bar">
        <label>SEARCH<input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') load() }} placeholder="Rule, resource, summary" /></label>
        <label>SEVERITY<select value={severity} onChange={e => setSeverity(e.target.value)}><option value="">All</option><option>Critical</option><option>Warning</option><option>Info</option></select></label>
        <label>STATUS<select value={status} onChange={e => setStatus(e.target.value)}><option value="">All</option><option>Active</option><option>Acknowledged</option><option>Resolved</option><option>Suppressed</option></select></label>
      </section>
      <section className="panel">
        <DataTable rows={items} columns={[
          { key: 'severity', title: 'SEVERITY', render: a => <StatusBadge value={a.severity} /> },
          { key: 'status', title: 'STATUS', render: a => <StatusBadge value={a.status} /> },
          { key: 'summary', title: 'SUMMARY', render: a => <Link to={`/anomalies/${a.id}`}>{a.summary}</Link> },
          { key: 'rule', title: 'RULE', render: a => <code>{a.rule_id}</code> },
          { key: 'resource', title: 'RESOURCE', render: a => `${a.namespace || '-'} / ${a.resource_kind || '-'} / ${a.resource_name || '-'}` },
          { key: 'count', title: 'COUNT', render: a => a.occurrence_count },
          { key: 'last', title: 'LAST SEEN', render: a => new Date(a.last_detected).toLocaleString() }
        ]} />
      </section>
    </>
  )
}
