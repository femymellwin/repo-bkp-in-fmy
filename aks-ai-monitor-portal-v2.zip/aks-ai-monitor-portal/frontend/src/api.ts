export const API_BASE = import.meta.env.VITE_API_BASE || '/api/v1'

export type User = { username: string; role: 'admin' | 'viewer' | string }
export type ApiResult<T> = T & { ok?: boolean; message?: string; details?: Record<string, unknown> }

export function getToken(): string | null {
  return localStorage.getItem('access_token')
}

export function setToken(token: string) {
  localStorage.setItem('access_token', token)
}

export function clearToken() {
  localStorage.removeItem('access_token')
}

export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {})
  const token = getToken()
  if (token) headers.set('Authorization', `Bearer ${token}`)
  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers })
  if (response.status === 401) {
    clearToken()
    window.location.href = '/login'
    throw new Error('Unauthorized')
  }
  const contentType = response.headers.get('content-type') || ''
  const data = contentType.includes('application/json') ? await response.json() : await response.text()
  if (!response.ok) {
    const message = typeof data === 'object' && data.detail ? data.detail : `Request failed with ${response.status}`
    throw new Error(message)
  }
  return data as T
}

export async function login(username: string, password: string) {
  const data = await apiFetch<{ access_token: string; role: string; username: string }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password })
  })
  setToken(data.access_token)
  return data
}
