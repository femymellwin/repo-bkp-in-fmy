import type React from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { apiFetch, getToken, User } from './api'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Anomalies from './pages/Anomalies'
import AnomalyDetail from './pages/AnomalyDetail'
import Resources from './pages/Resources'
import Logs from './pages/Logs'
import AdminConfig from './pages/AdminConfig'

function RequireAuth({ children }: { children: React.ReactElement }) {
  const [user, setUser] = useState<User | null | undefined>(undefined)
  useEffect(() => {
    if (!getToken()) {
      setUser(null)
      return
    }
    apiFetch<User>('/auth/me').then(setUser).catch(() => setUser(null))
  }, [])
  if (user === undefined) return <div className="center-screen">Loading...</div>
  if (!user) return <Navigate to="/login" replace />
  return <Layout user={user}>{children}</Layout>
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<RequireAuth><Dashboard /></RequireAuth>} />
      <Route path="/anomalies" element={<RequireAuth><Anomalies /></RequireAuth>} />
      <Route path="/anomalies/:id" element={<RequireAuth><AnomalyDetail /></RequireAuth>} />
      <Route path="/resources" element={<RequireAuth><Resources /></RequireAuth>} />
      <Route path="/logs" element={<RequireAuth><Logs /></RequireAuth>} />
      <Route path="/admin" element={<RequireAuth><AdminConfig /></RequireAuth>} />
    </Routes>
  )
}
