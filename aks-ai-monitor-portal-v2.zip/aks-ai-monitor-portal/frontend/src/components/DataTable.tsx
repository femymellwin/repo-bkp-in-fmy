import type React from 'react'
export type Column<T> = {
  key: string
  title: string
  render: (row: T) => React.ReactNode
}

export default function DataTable<T>({ columns, rows, empty = 'No data available.' }: { columns: Column<T>[]; rows: T[]; empty?: string }) {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>{columns.map(col => <th key={col.key}>{col.title}</th>)}</tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={columns.length} className="empty-cell">{empty}</td></tr>
          ) : rows.map((row, index) => (
            <tr key={index}>{columns.map(col => <td key={col.key}>{col.render(row)}</td>)}</tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
