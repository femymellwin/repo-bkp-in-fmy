import type React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { clearToken, User } from '../api'

export default function Layout({ user, children }: { user: User; children: React.ReactNode }) {
  const navigate = useNavigate()
  const nav = [
    ['/', 'DASHBOARD'],
    ['/anomalies', 'ANOMALIES'],
    ['/resources', 'RESOURCES'],
    ['/logs', 'LOGS'],
  ]
  if (user.role === 'admin') nav.push(['/admin', 'ADMIN'])
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-lockup">
          <div className="brand-mark">AKS</div>
          <div>
            <div className="brand-title">Insight Portal</div>
            <div className="brand-subtitle">Cluster Operations</div>
          </div>
        </div>
        <nav className="nav-list">
          {nav.map(([to, label]) => (
            <NavLink key={to} to={to} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="small-label">SIGNED IN</div>
          <div className="user-line">{user.username}</div>
          <div className="role-pill">{user.role.toUpperCase()}</div>
          <button className="ghost-button full" onClick={() => { clearToken(); navigate('/login') }}>SIGN OUT</button>
        </div>
      </aside>
      <main className="main-panel">{children}</main>
    </div>
  )
}
