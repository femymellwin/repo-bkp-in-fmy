export default function StatusBadge({ value }: { value?: string | boolean }) {
  const text = typeof value === 'boolean' ? (value ? 'CONNECTED' : 'DISCONNECTED') : (value || 'UNKNOWN')
  const normalized = text.toLowerCase()
  let tone = 'neutral'
  if (['healthy', 'connected', 'ready', 'active'].includes(normalized)) tone = 'success'
  if (['warning', 'acknowledged', 'unknown'].includes(normalized)) tone = 'warning'
  if (['critical', 'disconnected', 'failed'].includes(normalized)) tone = 'danger'
  if (['resolved'].includes(normalized)) tone = 'muted'
  return <span className={`status-badge ${tone}`}>{text.toUpperCase()}</span>
}
