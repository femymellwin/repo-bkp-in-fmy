#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

SKIP_INSTALL=false
FORCE_INSTALL=false
CA_FILE=""

usage() {
  cat <<'TXT'
Usage: ./scripts/run-local.sh [options]

Creates the Python virtual environment, installs backend and frontend dependencies,
and starts both development servers.

Options:
  --skip-install        Start without checking/installing dependencies.
  --force-install       Reinstall Python and Node dependencies first.
  --ca-cert PATH        Use a PEM corporate CA certificate for pip, npm, and runtime HTTPS.
  -h, --help            Show this help.

Examples:
  ./scripts/run-local.sh
  ./scripts/run-local.sh --ca-cert /absolute/path/company-root-ca.pem
TXT
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-install)
      SKIP_INSTALL=true
      shift
      ;;
    --force-install)
      FORCE_INSTALL=true
      shift
      ;;
    --ca-cert)
      [[ $# -ge 2 ]] || fail "--ca-cert requires a file path."
      CA_FILE="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      fail "Unknown argument: $1"
      ;;
  esac
done

ensure_env_file
load_env_file
configure_ca_environment "$CA_FILE"
ensure_runtime_directories

if [[ "$SKIP_INSTALL" == false ]]; then
  INSTALL_ARGS=()
  [[ -n "$CA_FILE" ]] && INSTALL_ARGS+=(--ca-cert "$CA_FILE")
  [[ "$FORCE_INSTALL" == true ]] && INSTALL_ARGS+=(--force)
  "$SCRIPT_DIR/install-local.sh" "${INSTALL_ARGS[@]}"
fi

[[ -x "$VENV_DIR/bin/python" ]] || fail "Virtual environment is missing."
[[ -x "$ROOT_DIR/frontend/node_modules/.bin/vite" ]] || fail "Frontend dependencies are missing."

BACKEND_PORT="${BACKEND_PORT:-8000}"
FRONTEND_PORT="${FRONTEND_PORT:-5173}"

cleanup() {
  local exit_code=$?
  trap - INT TERM EXIT
  log "Stopping local services"
  [[ -n "${BACKEND_PID:-}" ]] && kill "$BACKEND_PID" 2>/dev/null || true
  [[ -n "${FRONTEND_PID:-}" ]] && kill "$FRONTEND_PID" 2>/dev/null || true
  wait "${BACKEND_PID:-}" 2>/dev/null || true
  wait "${FRONTEND_PID:-}" 2>/dev/null || true
  rm -f "$RUN_DIR/backend.pid" "$RUN_DIR/frontend.pid"
  exit "$exit_code"
}
trap cleanup INT TERM EXIT

log "Starting backend and frontend"
(
  cd "$ROOT_DIR/backend"
  exec "$VENV_DIR/bin/python" -m uvicorn app.main:app --reload --host 0.0.0.0 --port "$BACKEND_PORT"
) &
BACKEND_PID=$!
printf '%s\n' "$BACKEND_PID" > "$RUN_DIR/backend.pid"

(
  cd "$ROOT_DIR/frontend"
  exec npm run dev -- --host 0.0.0.0 --port "$FRONTEND_PORT"
) &
FRONTEND_PID=$!
printf '%s\n' "$FRONTEND_PID" > "$RUN_DIR/frontend.pid"

cat <<TXT

AKS Insight Portal is starting.

Frontend:  http://localhost:$FRONTEND_PORT
Backend:   http://localhost:$BACKEND_PORT
API docs:  http://localhost:$BACKEND_PORT/api/v1/docs

Default development users (change them in .env):
  Admin:   ${ADMIN_USERNAME:-admin}
  Viewer:  ${USER_USERNAME:-viewer}

Press Ctrl+C to stop both services.
TXT

while kill -0 "$BACKEND_PID" 2>/dev/null && kill -0 "$FRONTEND_PID" 2>/dev/null; do
  sleep 2
done

if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
  wait "$BACKEND_PID" || fail "Backend stopped unexpectedly."
fi
if ! kill -0 "$FRONTEND_PID" 2>/dev/null; then
  wait "$FRONTEND_PID" || fail "Frontend stopped unexpectedly."
fi
