#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENV_DIR="${VENV_DIR:-$ROOT_DIR/.venv}"
ENV_FILE="${ENV_FILE:-$ROOT_DIR/.env}"
RUN_DIR="$ROOT_DIR/.run"

log() {
  printf '[aks-portal] %s\n' "$*"
}

fail() {
  printf '[aks-portal] ERROR: %s\n' "$*" >&2
  exit 1
}

load_env_file() {
  local file="${1:-$ENV_FILE}"
  [[ -f "$file" ]] || return 0

  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%$'\r'}"
    [[ "$line" =~ ^[[:space:]]*$ ]] && continue
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ "$line" == *=* ]] || continue

    local key="${line%%=*}"
    local value="${line#*=}"
    key="$(printf '%s' "$key" | tr -d '[:space:]')"
    [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue

    if [[ "$value" == \"*\" && "$value" == *\" ]]; then
      value="${value:1:${#value}-2}"
    elif [[ "$value" == \'*\' && "$value" == *\' ]]; then
      value="${value:1:${#value}-2}"
    fi
    export "$key=$value"
  done < "$file"
}

find_python() {
  if [[ -n "${PYTHON_BIN:-}" ]]; then
    command -v "$PYTHON_BIN" >/dev/null 2>&1 || fail "PYTHON_BIN '$PYTHON_BIN' was not found."
    printf '%s\n' "$PYTHON_BIN"
    return
  fi

  local candidate
  for candidate in python3.12 python3 python; do
    if command -v "$candidate" >/dev/null 2>&1; then
      printf '%s\n' "$candidate"
      return
    fi
  done
  fail "Python was not found. Install Python 3.12 and retry."
}

check_python_version() {
  local python_bin="$1"
  "$python_bin" - <<'PY'
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Python 3.11 or newer is required; Python 3.12 is recommended.")
print(f"Python {sys.version.split()[0]}")
PY
}

check_node_version() {
  command -v node >/dev/null 2>&1 || fail "Node.js was not found. Install Node.js 20 or newer."
  command -v npm >/dev/null 2>&1 || fail "npm was not found. Install Node.js 20 or newer."
  node - <<'JS'
const major = Number(process.versions.node.split('.')[0]);
if (major < 20) {
  console.error(`Node.js 20 or newer is required; found ${process.versions.node}.`);
  process.exit(1);
}
console.log(`Node.js ${process.versions.node}`);
JS
}

configure_ca_environment() {
  local ca_file="${1:-${LOCAL_CA_CERT:-}}"
  [[ -n "$ca_file" ]] || return 0

  if [[ "$ca_file" != /* ]]; then
    ca_file="$ROOT_DIR/$ca_file"
  fi
  [[ -f "$ca_file" ]] || fail "CA certificate file does not exist: $ca_file"
  grep -q "BEGIN CERTIFICATE" "$ca_file" || fail "CA file must be PEM encoded: $ca_file"

  export LOCAL_CA_CERT="$ca_file"
  export PIP_CERT="$ca_file"
  export REQUESTS_CA_BUNDLE="$ca_file"
  export SSL_CERT_FILE="$ca_file"
  export NODE_EXTRA_CA_CERTS="$ca_file"
  export npm_config_cafile="$ca_file"
  log "Using custom CA certificate: $ca_file"
}

ensure_env_file() {
  if [[ ! -f "$ENV_FILE" ]]; then
    cp "$ROOT_DIR/.env.example" "$ENV_FILE"
    log "Created $ENV_FILE from .env.example"
  fi
}

ensure_runtime_directories() {
  mkdir -p "$ROOT_DIR/backend/data" "$ROOT_DIR/backend/uploads" "$ROOT_DIR/uploads" "$ROOT_DIR/data" "$RUN_DIR"
}
