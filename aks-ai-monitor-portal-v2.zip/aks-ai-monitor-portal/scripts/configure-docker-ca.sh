#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

[[ $# -eq 1 ]] || fail "Usage: ./scripts/configure-docker-ca.sh /absolute/path/company-root-ca.pem"
CA_FILE="$1"
[[ -f "$CA_FILE" ]] || fail "Certificate file does not exist: $CA_FILE"
grep -q "BEGIN CERTIFICATE" "$CA_FILE" || fail "Certificate must be PEM encoded."
cp "$CA_FILE" "$ROOT_DIR/backend/certs/corporate-ca.crt"
cp "$CA_FILE" "$ROOT_DIR/frontend/certs/corporate-ca.crt"
log "Copied the CA certificate into both Docker build contexts."
log "Run: docker compose build --no-cache && docker compose up"
