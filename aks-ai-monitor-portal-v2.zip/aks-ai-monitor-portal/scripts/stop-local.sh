#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

stopped=false
for service in backend frontend; do
  pid_file="$RUN_DIR/$service.pid"
  if [[ -f "$pid_file" ]]; then
    pid="$(cat "$pid_file")"
    if kill -0 "$pid" 2>/dev/null; then
      kill "$pid"
      log "Stopped $service process $pid"
      stopped=true
    fi
    rm -f "$pid_file"
  fi
done

if [[ "$stopped" == false ]]; then
  log "No tracked local services were running."
fi
