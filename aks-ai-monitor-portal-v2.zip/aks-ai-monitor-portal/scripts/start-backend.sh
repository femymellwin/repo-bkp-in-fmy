#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

CA_FILE=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --ca-cert)
      [[ $# -ge 2 ]] || fail "--ca-cert requires a file path."
      CA_FILE="$2"
      shift 2
      ;;
    *)
      fail "Unknown argument: $1"
      ;;
  esac
done

ensure_env_file
load_env_file
configure_ca_environment "$CA_FILE"
ensure_runtime_directories
[[ -x "$VENV_DIR/bin/python" ]] || fail "Virtual environment is missing. Run ./scripts/install-local.sh --backend-only"

BACKEND_HOST="${BACKEND_HOST:-0.0.0.0}"
BACKEND_PORT="${BACKEND_PORT:-8000}"
log "Starting backend on http://localhost:$BACKEND_PORT"
cd "$ROOT_DIR/backend"
exec "$VENV_DIR/bin/python" -m uvicorn app.main:app --reload --host "$BACKEND_HOST" --port "$BACKEND_PORT"
