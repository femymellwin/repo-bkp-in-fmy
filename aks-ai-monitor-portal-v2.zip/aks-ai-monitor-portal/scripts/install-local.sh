#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

INSTALL_BACKEND=true
INSTALL_FRONTEND=true
FORCE=false
CA_FILE=""

usage() {
  cat <<'TXT'
Usage: ./scripts/install-local.sh [options]

Options:
  --backend-only        Install only Python/backend dependencies.
  --frontend-only       Install only Node/frontend dependencies.
  --ca-cert PATH        Use a PEM corporate CA certificate for pip and npm.
  --force               Reinstall dependencies even when already present.
  -h, --help            Show this help.
TXT
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --backend-only)
      INSTALL_BACKEND=true
      INSTALL_FRONTEND=false
      shift
      ;;
    --frontend-only)
      INSTALL_BACKEND=false
      INSTALL_FRONTEND=true
      shift
      ;;
    --ca-cert)
      [[ $# -ge 2 ]] || fail "--ca-cert requires a file path."
      CA_FILE="$2"
      shift 2
      ;;
    --force)
      FORCE=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      fail "Unknown argument: $1"
      ;;
  esac
done

ensure_env_file
load_env_file
configure_ca_environment "$CA_FILE"
ensure_runtime_directories

if [[ "$INSTALL_BACKEND" == true ]]; then
  PYTHON_CMD="$(find_python)"
  check_python_version "$PYTHON_CMD"

  if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    log "Creating virtual environment at $VENV_DIR"
    "$PYTHON_CMD" -m venv "$VENV_DIR"
  else
    log "Using existing virtual environment at $VENV_DIR"
  fi

  if [[ "$FORCE" == true || ! -f "$VENV_DIR/.backend-installed" ]]; then
    log "Installing backend dependencies"
    "$VENV_DIR/bin/python" -m pip install --upgrade pip setuptools wheel
    "$VENV_DIR/bin/python" -m pip install -r "$ROOT_DIR/backend/requirements.txt"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$VENV_DIR/.backend-installed"
  else
    log "Backend dependencies are already installed; use --force to reinstall."
  fi
fi

if [[ "$INSTALL_FRONTEND" == true ]]; then
  check_node_version
  if [[ "$FORCE" == true || ! -x "$ROOT_DIR/frontend/node_modules/.bin/vite" ]]; then
    log "Installing frontend dependencies"
    (
      cd "$ROOT_DIR/frontend"
      npm install
    )
  else
    log "Frontend dependencies are already installed; use --force to reinstall."
  fi
fi

log "Installation completed successfully."
