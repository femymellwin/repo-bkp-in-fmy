#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

CA_FILE=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --ca-cert)
      [[ $# -ge 2 ]] || fail "--ca-cert requires a file path."
      CA_FILE="$2"
      shift 2
      ;;
    *)
      fail "Unknown argument: $1"
      ;;
  esac
done

ensure_env_file
load_env_file
configure_ca_environment "$CA_FILE"
check_node_version
[[ -x "$ROOT_DIR/frontend/node_modules/.bin/vite" ]] || fail "Frontend dependencies are missing. Run ./scripts/install-local.sh --frontend-only"

FRONTEND_HOST="${FRONTEND_HOST:-0.0.0.0}"
FRONTEND_PORT="${FRONTEND_PORT:-5173}"
log "Starting frontend on http://localhost:$FRONTEND_PORT"
cd "$ROOT_DIR/frontend"
exec npm run dev -- --host "$FRONTEND_HOST" --port "$FRONTEND_PORT"
