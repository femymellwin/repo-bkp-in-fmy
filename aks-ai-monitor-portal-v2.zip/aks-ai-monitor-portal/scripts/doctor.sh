#!/usr/bin/env bash
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

status=0
ensure_env_file
load_env_file

printf '\nAKS Insight Portal local environment check\n\n'

if PYTHON_CMD="$(find_python 2>/dev/null)"; then
  if check_python_version "$PYTHON_CMD"; then :; else status=1; fi
else
  printf 'Python: MISSING\n'
  status=1
fi

if command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1; then
  if check_node_version; then :; else status=1; fi
else
  printf 'Node/npm: MISSING\n'
  status=1
fi

printf 'Environment file: %s\n' "$ENV_FILE"
printf 'Virtual environment: %s\n' "$([[ -x "$VENV_DIR/bin/python" ]] && echo READY || echo NOT INSTALLED)"
printf 'Frontend packages: %s\n' "$([[ -x "$ROOT_DIR/frontend/node_modules/.bin/vite" ]] && echo READY || echo NOT INSTALLED)"
printf 'Demo mode: %s\n' "${DEMO_MODE:-true}"
printf 'Kubeconfig: %s\n' "${KUBECONFIG_PATH:-not configured}"

if [[ "${DEMO_MODE:-true}" == "false" ]]; then
  if [[ -f "${KUBECONFIG_PATH:-}" ]]; then
    printf 'Kubeconfig file: FOUND\n'
  else
    printf 'Kubeconfig file: MISSING (set an absolute KUBECONFIG_PATH in .env)\n'
    status=1
  fi
fi

if [[ -n "${LOCAL_CA_CERT:-}" ]]; then
  printf 'Custom CA: %s\n' "$LOCAL_CA_CERT"
fi

printf '\n'
exit "$status"
