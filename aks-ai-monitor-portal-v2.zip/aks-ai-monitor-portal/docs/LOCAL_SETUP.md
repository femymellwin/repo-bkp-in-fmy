# Local virtual-environment setup

These steps run the backend in a Python virtual environment and the frontend with the local Node.js toolchain. Docker is not required.

## Prerequisites

- macOS or Linux.
- Python 3.12 recommended; Python 3.11 or newer is accepted.
- Node.js 20 or newer and npm.
- A locally readable kubeconfig when `DEMO_MODE=false`.
- A PEM-formatted enterprise root CA when the network performs TLS inspection.

## One-command installation and startup

From the repository root:

```bash
chmod +x scripts/*.sh
./scripts/run-local.sh
```

The script performs all of the following:

1. Creates `.env` from `.env.example` when needed.
2. Creates the `.venv` Python virtual environment.
3. Installs backend Python dependencies.
4. Installs frontend npm dependencies.
5. Starts FastAPI on port 8000.
6. Starts Vite on port 5173.
7. Stops both processes when Ctrl+C is pressed.

Open:

- Portal: `http://localhost:5173`
- API docs: `http://localhost:8000/api/v1/docs`

## Corporate TLS certificate

The reported `CERTIFICATE_VERIFY_FAILED` error means that the package registry certificate chain is not trusted in the execution environment. It is not a FastAPI version error.

Obtain the organization root/intermediate CA certificate from the IT/security team in PEM format, then run:

```bash
./scripts/run-local.sh --ca-cert /absolute/path/company-root-ca.pem
```

The script applies the certificate to pip, Python HTTPS clients, Node.js, and npm through standard certificate environment variables. It does not disable TLS verification.

## Install only

```bash
./scripts/install-local.sh
```

With an enterprise CA:

```bash
./scripts/install-local.sh --ca-cert /absolute/path/company-root-ca.pem
```

## Start backend and frontend separately

Terminal 1:

```bash
./scripts/start-backend.sh
```

Terminal 2:

```bash
./scripts/start-frontend.sh
```

If a custom CA is required at runtime, pass the same `--ca-cert` option to both scripts.

## Manual backend commands

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r backend/requirements.txt

set -a
# Do not source .env directly because unquoted values may contain spaces.
# Use scripts/start-backend.sh, which loads it safely.
set +a

cd backend
../.venv/bin/python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Manual frontend commands

```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0 --port 5173
```

## Real AKS mode

Edit `.env` and use an absolute host path:

```dotenv
DEMO_MODE=false
KUBECONFIG_PATH=/Users/your-user/.kube/config
KUBE_CONTEXT=optional-context-name
```

Then run:

```bash
./scripts/run-local.sh --skip-install
```

The native virtual-environment mode reads the host kubeconfig directly; no Docker volume mapping is involved.

## Diagnostics

```bash
./scripts/doctor.sh
```

To force a clean dependency reinstall:

```bash
./scripts/run-local.sh --force-install
```
