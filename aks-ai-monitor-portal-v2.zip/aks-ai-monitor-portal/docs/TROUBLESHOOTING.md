# Troubleshooting

## `CERTIFICATE_VERIFY_FAILED` during pip or npm install

Cause: an enterprise proxy is presenting a certificate signed by an internal CA that Python, Node.js, or the container does not trust.

Preferred local fix:

```bash
./scripts/run-local.sh --ca-cert /absolute/path/company-root-ca.pem
```

Preferred Docker fix:

```bash
./scripts/configure-docker-ca.sh /absolute/path/company-root-ca.pem
docker compose build --no-cache
docker compose up
```

Do not use `PIP_NO_VERIFY`, disable TLS, or permanently add broad `--trusted-host` options. Those approaches remove registry identity verification.

## Backend cannot find kubeconfig

For native mode, `KUBECONFIG_PATH` must be an absolute host path:

```dotenv
KUBECONFIG_PATH=/Users/your-user/.kube/config
```

For Docker mode, use:

```dotenv
KUBECONFIG_HOST_PATH=/Users/your-user/.kube/config
KUBECONFIG_PATH=/kube/config
```

## Azure OpenAI test fails

Verify endpoint, API version, API key, and deployment name. The deployment name is used in the request URL. The model name is display/audit metadata.

## Port already in use

Override ports for local mode:

```bash
BACKEND_PORT=8100 FRONTEND_PORT=5174 ./scripts/run-local.sh
```

## Reset local application data

Stop the portal and remove the SQLite file:

```bash
rm -f backend/data/aks_monitor.db
```

The database is recreated on the next start.
