# Architecture

## Runtime topology

```text
Browser
  |
  | HTTP / SSE
  v
React + TypeScript frontend (Vite in local development, Nginx in Docker)
  |
  | REST /api/v1 and /uploads
  v
FastAPI backend
  |-- Authentication and role authorization (admin / viewer)
  |-- Configuration and branding API
  |-- Kubernetes collector and log reader
  |-- Deterministic anomaly rule engine
  |-- Scheduler and anomaly lifecycle manager
  |-- Azure OpenAI advisory analysis
  |-- SSE status stream
  |
  +--> SQLite database
  +--> Read-only local kubeconfig --> AKS Kubernetes API
  +--> Azure OpenAI / Azure AI Foundry endpoint
```

## Components

1. **Frontend**
   - React TypeScript single-page application.
   - White professional theme.
   - Viewer pages: Dashboard, Anomalies, Resources, and Logs.
   - Admin page: kubeconfig mapping, Azure OpenAI settings and connection tests, branding, and monitoring thresholds.

2. **Backend API**
   - FastAPI under `/api/v1`.
   - JWT-based local authentication and role checks.
   - REST endpoints for cluster state, resources, logs, anomalies, configuration, and manual refresh.
   - SSE endpoint for status updates.

3. **Collector**
   - Uses the official Kubernetes Python client.
   - Reads an absolute kubeconfig path and optional context.
   - Supports demo mode when no AKS access is available.
   - Records partial collection failures without aborting the entire cycle.

4. **Rule engine**
   - Deterministic rules are authoritative for health and severity.
   - Stable fingerprints deduplicate repeated findings.
   - AI output is advisory and cannot replace raw evidence.

5. **Persistence**
   - SQLite through SQLAlchemy.
   - Stores settings, snapshots, anomaly lifecycle data, and audit records.
   - The Azure OpenAI API key is encrypted locally using `APP_SECRET`.

6. **AI layer**
   - Calls Azure OpenAI chat completions using the configured deployment.
   - Sends minimal, sanitized evidence only.
   - Does not send kubeconfig contents or Kubernetes Secret values.

## Access model

- **Admin**: configuration, test connections, branding, anomaly actions, and all viewer capabilities.
- **Viewer**: dashboard, anomalies, resources, and sanitized logs.

## Health model

- **Healthy**: API reachable, latest collection completed, and no active warning or critical anomalies.
- **Warning**: one or more active warnings.
- **Critical**: one or more active critical anomalies.
- **Unknown**: partial collection failures or required data unavailable.
- **Disconnected**: Kubernetes API connection failed.

## Anomaly lifecycle

- Active on first detection.
- Acknowledged or suppressed by an authorized user.
- Resolved after the condition disappears for the configured number of successful cycles.
