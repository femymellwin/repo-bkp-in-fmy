# Security and Operational Limitations

## Local auth

The portal includes simple local admin and viewer accounts for the first local build. Replace default credentials in `.env` before use.

## Kubeconfig

The kubeconfig path is stored as configuration, but kubeconfig contents are never copied into the database, sent to the frontend, logged, or sent to Azure OpenAI.

For Docker, mount the kubeconfig read-only:

```bash
KUBECONFIG_HOST_PATH=/absolute/path/to/config
KUBECONFIG_PATH=/kube/config
```

## Secrets

Kubernetes Secret values are not decoded or displayed. By default, the collector does not list Secret resources because Kubernetes RBAC cannot grant clean metadata-only access through the normal core Secret API. If `kube_allow_secret_metadata` is enabled, the collector immediately strips data and stringData fields and stores only metadata and key names.

## ConfigMaps

ConfigMap values may contain sensitive material. The collector stores only names and keys, not values.

## Logs

Logs are redacted before display and before any future AI analysis. Redaction covers tokens, passwords, API keys, bearer authorization headers, JWT-like strings, emails, and custom configured regex patterns.

## AI

The AI layer is optional. Deterministic monitoring continues when Azure OpenAI is disabled or unavailable. AI explanations are advisory and based only on sanitized anomaly evidence.

## Version 1 boundaries

Not implemented:

- Automatic pod restarts.
- Scaling.
- Patching.
- Deleting Kubernetes resources.
- Arbitrary kubectl execution.
- Secret modification.
- Manifest mutation.
