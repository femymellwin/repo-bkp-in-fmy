#!/usr/bin/env python3
"""Create a one-sheet GHES repository migration inventory workbook."""

from __future__ import annotations

import argparse
import base64
import csv
import json
import logging
import os
import re
import shutil
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator, Optional

from openpyxl import Workbook
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo

VERSION = "1.1.0"

MANDATORY_HEADERS = [
    "Source Organization",
    "Source Repo URL",
    "Last Commit Author Name",
    "Last Commit Author Email",
    "Last Commit Date",
    "Last Commit SHA",
    "Has Pipeline",
    "Has Large File",
    "Is Empty Repository",
    "Status",
]

ADDITIONAL_HEADERS = [
    "Repository Name",
    "Default Branch",
    "Visibility",
    "Archived",
    "Fork",
    "Pipeline Evidence",
    "Large File Threshold MB",
    "Large File Count",
    "Largest Blob MB",
    "Largest Blob Path",
    "Large File Scan Scope",
    "Repository Size KB (API)",
    "Repository Pushed At",
    "Notes",
    "Collected At UTC",
]

HEADERS = MANDATORY_HEADERS + ADDITIONAL_HEADERS

PIPELINE_PATHS = [
    ".github/workflows",
    "azure-pipelines.yml",
    "azure-pipelines.yaml",
    ".azure-pipelines",
    "Jenkinsfile",
    ".gitlab-ci.yml",
    ".circleci/config.yml",
    ".circleci/config.yaml",
    "bitbucket-pipelines.yml",
    ".travis.yml",
    "buildspec.yml",
    "buildspec.yaml",
    ".teamcity",
    "teamcity-settings.kts",
]


class InventoryError(RuntimeError):
    pass


class APIError(InventoryError):
    def __init__(self, status: int, url: str, body: str, headers: Any = None):
        self.status = status
        self.url = url
        self.body = body
        self.headers = headers
        super().__init__(f"GitHub API HTTP {status} for {url}: {body[:500]}")


@dataclass
class Config:
    root_dir: Path
    ghes_web_url: str
    ghes_api_url: str
    token: str
    api_version: str
    org_discovery_mode: str
    source_orgs: list[str]
    include_archived: bool
    include_forks: bool
    repository_filter: str
    max_repositories: int
    detect_pipelines: bool
    large_file_scan_mode: str
    large_file_threshold_mb: float
    keep_mirror_cache: bool
    mirror_cache_dir: Path
    verify_ssl: bool
    ca_bundle: Optional[Path]
    output_xlsx: Path
    output_csv: Path
    log_file: Path
    status_default: str

    @property
    def large_file_threshold_bytes(self) -> int:
        return int(self.large_file_threshold_mb * 1024 * 1024)


@dataclass
class CommitInfo:
    empty: str
    author_name: str = ""
    author_email: str = ""
    committed_at: str = ""
    sha: str = ""
    note: str = ""


@dataclass
class PipelineInfo:
    value: str
    evidence: str = ""
    note: str = ""


@dataclass
class LargeFileInfo:
    value: str
    count: Optional[int]
    largest_bytes: Optional[int]
    largest_path: str
    scope: str
    note: str = ""


def load_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        raise InventoryError(f"Environment file not found: {path}")
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        values[key] = value
    return values


def parse_bool(value: str, default: bool = False) -> bool:
    if value is None or value == "":
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "y", "on"}:
        return True
    if normalized in {"0", "false", "no", "n", "off"}:
        return False
    raise InventoryError(f"Invalid boolean value: {value!r}")


def resolve_path(root: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else root / path


def build_config(env_path: Path) -> Config:
    values = load_env_file(env_path)
    root = env_path.resolve().parent

    def get(name: str, default: str = "") -> str:
        return os.environ.get(name, values.get(name, default)).strip()

    token = get("GHES_TOKEN")
    if not token:
        raise InventoryError("GHES_TOKEN is blank in .env")

    mode = get("ORG_DISCOVERY_MODE", "all").lower()
    if mode not in {"all", "union", "user", "visible", "explicit"}:
        raise InventoryError("ORG_DISCOVERY_MODE must be all, union, user, visible, or explicit")

    scan_mode = get("LARGE_FILE_SCAN_MODE", "history").lower()
    if scan_mode not in {"history", "default-branch", "off"}:
        raise InventoryError("LARGE_FILE_SCAN_MODE must be history, default-branch, or off")

    source_orgs = [part.strip() for part in get("SOURCE_ORGS").split(",") if part.strip()]
    if mode == "explicit" and not source_orgs:
        raise InventoryError("SOURCE_ORGS is required when ORG_DISCOVERY_MODE=explicit")

    ca_bundle_value = get("CA_BUNDLE")
    ca_bundle = resolve_path(root, ca_bundle_value) if ca_bundle_value else None
    if ca_bundle and not ca_bundle.exists():
        raise InventoryError(f"CA_BUNDLE does not exist: {ca_bundle}")

    return Config(
        root_dir=root,
        ghes_web_url=get("GHES_WEB_URL", "https://github.int.inceptionai.ai").rstrip("/"),
        ghes_api_url=get("GHES_API_URL", "https://github.int.inceptionai.ai/api/v3").rstrip("/"),
        token=token,
        api_version=get("GITHUB_API_VERSION", "2022-11-28"),
        org_discovery_mode=mode,
        source_orgs=source_orgs,
        include_archived=parse_bool(get("INCLUDE_ARCHIVED", "true"), True),
        include_forks=parse_bool(get("INCLUDE_FORKS", "true"), True),
        repository_filter=get("REPOSITORY_FILTER"),
        max_repositories=int(get("MAX_REPOSITORIES", "0") or "0"),
        detect_pipelines=parse_bool(get("DETECT_PIPELINES", "true"), True),
        large_file_scan_mode=scan_mode,
        large_file_threshold_mb=float(get("LARGE_FILE_THRESHOLD_MB", "100") or "100"),
        keep_mirror_cache=parse_bool(get("KEEP_MIRROR_CACHE", "false"), False),
        mirror_cache_dir=resolve_path(root, get("MIRROR_CACHE_DIR", ".cache/mirrors")),
        verify_ssl=parse_bool(get("VERIFY_SSL", "true"), True),
        ca_bundle=ca_bundle,
        output_xlsx=resolve_path(root, get("OUTPUT_XLSX", "output/ghes-repository-inventory.xlsx")),
        output_csv=resolve_path(root, get("OUTPUT_CSV", "output/ghes-repository-inventory.csv")),
        log_file=resolve_path(root, get("LOG_FILE", "output/ghes-repository-inventory.log")),
        status_default=get("STATUS_DEFAULT", "Has not started") or "Has not started",
    )


class GitHubClient:
    def __init__(self, config: Config):
        self.config = config
        if config.verify_ssl:
            self.ssl_context = ssl.create_default_context(cafile=str(config.ca_bundle) if config.ca_bundle else None)
        else:
            self.ssl_context = ssl._create_unverified_context()  # noqa: SLF001

    def request_json(self, path_or_url: str, params: Optional[dict[str, Any]] = None) -> tuple[Any, Any]:
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            url = path_or_url
        else:
            url = f"{self.config.ghes_api_url}/{path_or_url.lstrip('/')}"
        if params:
            query = urllib.parse.urlencode(params)
            url = f"{url}{'&' if '?' in url else '?'}{query}"

        headers = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self.config.token}",
            "X-GitHub-Api-Version": self.config.api_version,
            "User-Agent": f"ghes-repository-inventory/{VERSION}",
        }
        request = urllib.request.Request(url, headers=headers, method="GET")
        last_error: Optional[Exception] = None
        for attempt in range(1, 5):
            try:
                with urllib.request.urlopen(request, context=self.ssl_context, timeout=90) as response:
                    body = response.read().decode("utf-8")
                    return (json.loads(body) if body else None), response.headers
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                if exc.code in {429, 502, 503, 504} and attempt < 4:
                    wait = min(30, 2**attempt)
                    logging.warning("API HTTP %s; retrying in %ss: %s", exc.code, wait, url)
                    time.sleep(wait)
                    continue
                if exc.code == 403 and attempt < 4:
                    remaining = exc.headers.get("X-RateLimit-Remaining", "")
                    reset = exc.headers.get("X-RateLimit-Reset", "")
                    if remaining == "0" and reset.isdigit():
                        wait = max(1, int(reset) - int(time.time()) + 1)
                        logging.warning("Rate limit reached; waiting %ss", wait)
                        time.sleep(min(wait, 300))
                        continue
                raise APIError(exc.code, url, body, exc.headers) from exc
            except (urllib.error.URLError, TimeoutError) as exc:
                last_error = exc
                if attempt < 4:
                    wait = min(30, 2**attempt)
                    logging.warning("Network error; retrying in %ss: %s", wait, exc)
                    time.sleep(wait)
                    continue
                break
        raise InventoryError(f"GitHub API request failed for {url}: {last_error}")

    def paginated(self, path: str, params: Optional[dict[str, Any]] = None) -> Iterator[Any]:
        """Paginate endpoints that use the conventional page/per_page scheme."""
        base = dict(params or {})
        per_page = int(base.pop("per_page", 100))
        page = 1
        while True:
            data, _headers = self.request_json(path, {**base, "per_page": per_page, "page": page})
            if not isinstance(data, list):
                raise InventoryError(f"Expected a list from {path}, received {type(data).__name__}")
            for item in data:
                yield item
            if len(data) < per_page:
                break
            page += 1

    def all_organizations(self) -> Iterator[dict[str, Any]]:
        """List every GHES organization using the endpoint's required since cursor."""
        per_page = 100
        since = 0
        seen_ids: set[int] = set()
        while True:
            data, _headers = self.request_json(
                "/organizations", {"per_page": per_page, "since": since}
            )
            if not isinstance(data, list):
                raise InventoryError(
                    f"Expected a list from /organizations, received {type(data).__name__}"
                )
            if not data:
                break
            for item in data:
                if isinstance(item, dict):
                    yield item
            last_id_raw = data[-1].get("id") if isinstance(data[-1], dict) else None
            try:
                last_id = int(last_id_raw)
            except (TypeError, ValueError) as exc:
                raise InventoryError(
                    "Organization pagination could not read the final organization ID"
                ) from exc
            if last_id <= since or last_id in seen_ids:
                raise InventoryError(
                    "Organization pagination did not advance; stopping to prevent a loop"
                )
            seen_ids.add(last_id)
            since = last_id
            if len(data) < per_page:
                break


def discover_organizations(client: GitHubClient, config: Config) -> list[str]:
    discovered: dict[str, str] = {}

    def add(items: Iterable[dict[str, Any]]) -> None:
        for item in items:
            login = str(item.get("login", "")).strip()
            if login:
                discovered[login.lower()] = login

    if config.org_discovery_mode in {"all", "union", "visible"}:
        try:
            add(client.all_organizations())
        except Exception as exc:  # continue with user memberships for union mode
            logging.warning("All-organization discovery failed: %s", exc)
            if config.org_discovery_mode in {"all", "visible"}:
                raise

    if config.org_discovery_mode in {"union", "user"}:
        try:
            add(client.paginated("/user/orgs"))
        except Exception as exc:
            logging.warning("User-membership organization discovery failed: %s", exc)

    for org in config.source_orgs:
        discovered[org.lower()] = org

    orgs = sorted(discovered.values(), key=str.lower)
    if not orgs:
        raise InventoryError(
            "No organizations were discovered. Set SOURCE_ORGS explicitly or use a token with organization access."
        )
    return orgs


def list_repositories(client: GitHubClient, org: str) -> list[dict[str, Any]]:
    return list(
        client.paginated(
            f"/orgs/{urllib.parse.quote(org, safe='')}/repos",
            {"type": "all", "sort": "full_name", "direction": "asc"},
        )
    )


def latest_commit(client: GitHubClient, owner: str, repo: str, default_branch: str) -> CommitInfo:
    if not default_branch:
        return CommitInfo(empty="Yes", note="Repository has no default branch")
    try:
        data, _ = client.request_json(
            f"/repos/{urllib.parse.quote(owner, safe='')}/{urllib.parse.quote(repo, safe='')}/commits",
            {"sha": default_branch, "per_page": 1},
        )
        if not isinstance(data, list) or not data:
            return CommitInfo(empty="Yes", note="No commits returned for the default branch")
        item = data[0]
        commit = item.get("commit") or {}
        author = commit.get("author") or {}
        committer = commit.get("committer") or {}
        return CommitInfo(
            empty="No",
            author_name=str(author.get("name") or ""),
            author_email=str(author.get("email") or ""),
            committed_at=str(committer.get("date") or author.get("date") or ""),
            sha=str(item.get("sha") or ""),
        )
    except APIError as exc:
        if exc.status == 409:
            return CommitInfo(empty="Yes", note="GitHub reported an empty repository")
        if exc.status == 404:
            return CommitInfo(empty="Unknown", note="Default branch or commit endpoint was not accessible")
        return CommitInfo(empty="Unknown", note=f"Commit lookup failed: HTTP {exc.status}")
    except Exception as exc:
        return CommitInfo(empty="Unknown", note=f"Commit lookup failed: {exc}")


def detect_pipeline(client: GitHubClient, owner: str, repo: str, default_branch: str, empty: str) -> PipelineInfo:
    if empty == "Yes":
        return PipelineInfo(value="No", evidence="", note="Empty repository")
    if not default_branch:
        return PipelineInfo(value="Unknown", note="No default branch")

    endpoint = f"/repos/{urllib.parse.quote(owner, safe='')}/{urllib.parse.quote(repo, safe='')}/actions/workflows"
    try:
        data, _ = client.request_json(endpoint, {"per_page": 100})
        workflows = data.get("workflows", []) if isinstance(data, dict) else []
        if workflows:
            names = [str(item.get("path") or item.get("name") or "workflow") for item in workflows]
            return PipelineInfo(value="Yes", evidence="GitHub Actions: " + "; ".join(names[:10]))
    except APIError as exc:
        if exc.status not in {403, 404}:
            logging.debug("Actions workflow lookup failed for %s/%s: %s", owner, repo, exc)
    except Exception as exc:
        logging.debug("Actions workflow lookup failed for %s/%s: %s", owner, repo, exc)

    inaccessible = 0
    for path in PIPELINE_PATHS:
        encoded_path = urllib.parse.quote(path, safe="/")
        try:
            _data, _ = client.request_json(
                f"/repos/{urllib.parse.quote(owner, safe='')}/{urllib.parse.quote(repo, safe='')}/contents/{encoded_path}",
                {"ref": default_branch},
            )
            return PipelineInfo(value="Yes", evidence=path)
        except APIError as exc:
            if exc.status == 404:
                continue
            if exc.status in {403, 451}:
                inaccessible += 1
                continue
        except Exception:
            inaccessible += 1

    if inaccessible == len(PIPELINE_PATHS):
        return PipelineInfo(value="Unknown", note="Pipeline files could not be inspected")
    return PipelineInfo(value="No")


def scan_large_files_default_branch(
    client: GitHubClient,
    owner: str,
    repo: str,
    default_branch: str,
    threshold_bytes: int,
) -> LargeFileInfo:
    if not default_branch:
        return LargeFileInfo("No", 0, 0, "", "default branch", "No default branch")
    try:
        data, _ = client.request_json(
            f"/repos/{urllib.parse.quote(owner, safe='')}/{urllib.parse.quote(repo, safe='')}/git/trees/"
            f"{urllib.parse.quote(default_branch, safe='')}",
            {"recursive": 1},
        )
        tree = data.get("tree", []) if isinstance(data, dict) else []
        truncated = bool(data.get("truncated")) if isinstance(data, dict) else False
        large = [
            item
            for item in tree
            if item.get("type") == "blob" and isinstance(item.get("size"), int) and item["size"] > threshold_bytes
        ]
        if large:
            largest = max(large, key=lambda item: item["size"])
            return LargeFileInfo(
                "Yes", len(large), int(largest["size"]), str(largest.get("path") or ""), "default branch"
            )
        if truncated:
            return LargeFileInfo(
                "Unknown", None, None, "", "default branch", "Recursive tree response was truncated"
            )
        return LargeFileInfo("No", 0, 0, "", "default branch")
    except APIError as exc:
        return LargeFileInfo("Unknown", None, None, "", "default branch", f"Tree scan failed: HTTP {exc.status}")
    except Exception as exc:
        return LargeFileInfo("Unknown", None, None, "", "default branch", f"Tree scan failed: {exc}")


def _write_askpass_script(directory: Path) -> Path:
    script = directory / "git-askpass.sh"
    script.write_text(
        "#!/bin/sh\n"
        "case \"$1\" in\n"
        "  *Username*) printf '%s\\n' 'x-access-token' ;;\n"
        "  *Password*) printf '%s\\n' \"$GHES_TOKEN_FOR_GIT\" ;;\n"
        "  *) printf '%s\\n' \"$GHES_TOKEN_FOR_GIT\" ;;\n"
        "esac\n",
        encoding="utf-8",
    )
    script.chmod(0o700)
    return script


def _git_environment(config: Config, askpass: Path) -> dict[str, str]:
    env = os.environ.copy()
    env.update(
        {
            "GIT_ASKPASS": str(askpass),
            "GIT_TERMINAL_PROMPT": "0",
            "GHES_TOKEN_FOR_GIT": config.token,
        }
    )
    if not config.verify_ssl:
        env["GIT_SSL_NO_VERIFY"] = "true"
    elif config.ca_bundle:
        env["GIT_SSL_CAINFO"] = str(config.ca_bundle)
    return env


def inspect_mirror_for_large_files(mirror_path: Path, threshold_bytes: int) -> tuple[int, int, str]:
    rev = subprocess.Popen(
        ["git", "-C", str(mirror_path), "rev-list", "--objects", "--all"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert rev.stdout is not None
    cat = subprocess.Popen(
        [
            "git",
            "-C",
            str(mirror_path),
            "cat-file",
            "--batch-check=%(objectname) %(objecttype) %(objectsize) %(rest)",
        ],
        stdin=rev.stdout,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    rev.stdout.close()
    assert cat.stdout is not None

    large_oids: set[str] = set()
    largest_bytes = 0
    largest_path = ""
    for raw in cat.stdout:
        line = raw.rstrip("\n")
        parts = line.split(" ", 3)
        if len(parts) < 3:
            continue
        oid, obj_type, size_text = parts[:3]
        path = parts[3] if len(parts) == 4 else ""
        if obj_type != "blob" or not size_text.isdigit():
            continue
        size = int(size_text)
        if size > threshold_bytes:
            large_oids.add(oid)
            if size > largest_bytes:
                largest_bytes = size
                largest_path = path

    cat_stderr = cat.stderr.read() if cat.stderr else ""
    cat_rc = cat.wait()
    rev_stderr = rev.stderr.read() if rev.stderr else ""
    rev_rc = rev.wait()
    if rev_rc != 0 or cat_rc != 0:
        details = (rev_stderr + "\n" + cat_stderr).strip()
        raise InventoryError(f"Git object scan failed: {details[:1000]}")
    return len(large_oids), largest_bytes, largest_path


def scan_large_files_history(
    config: Config,
    owner: str,
    repo: str,
    clone_url: str,
) -> LargeFileInfo:
    if shutil.which("git") is None:
        return LargeFileInfo("Unknown", None, None, "", "all reachable history", "git executable not found")
    if not clone_url:
        return LargeFileInfo("Unknown", None, None, "", "all reachable history", "HTTPS clone URL missing")

    config.mirror_cache_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{owner}__{repo}.git")

    with tempfile.TemporaryDirectory(prefix="ghes-inventory-auth-") as auth_dir_text:
        auth_dir = Path(auth_dir_text)
        askpass = _write_askpass_script(auth_dir)
        env = _git_environment(config, askpass)

        temp_ctx: Optional[tempfile.TemporaryDirectory[str]] = None
        if config.keep_mirror_cache:
            mirror_path = config.mirror_cache_dir / safe_name
        else:
            temp_ctx = tempfile.TemporaryDirectory(prefix="ghes-inventory-mirror-")
            mirror_path = Path(temp_ctx.name) / safe_name

        try:
            if mirror_path.exists():
                command = ["git", "-C", str(mirror_path), "remote", "update", "--prune"]
            else:
                command = ["git", "clone", "--mirror", "--quiet", clone_url, str(mirror_path)]
            result = subprocess.run(
                command,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=3600,
                check=False,
            )
            if result.returncode != 0:
                return LargeFileInfo(
                    "Unknown",
                    None,
                    None,
                    "",
                    "all reachable history",
                    f"Mirror clone/update failed: {result.stderr.strip()[:1000]}",
                )

            count, largest_bytes, largest_path = inspect_mirror_for_large_files(
                mirror_path, config.large_file_threshold_bytes
            )
            return LargeFileInfo(
                "Yes" if count > 0 else "No",
                count,
                largest_bytes,
                largest_path,
                "all reachable history",
            )
        except subprocess.TimeoutExpired:
            return LargeFileInfo("Unknown", None, None, "", "all reachable history", "Mirror clone timed out")
        except Exception as exc:
            return LargeFileInfo("Unknown", None, None, "", "all reachable history", str(exc))
        finally:
            if temp_ctx is not None:
                temp_ctx.cleanup()


def scan_large_files(
    client: GitHubClient,
    config: Config,
    repo_data: dict[str, Any],
    empty: str,
) -> LargeFileInfo:
    if empty == "Yes":
        return LargeFileInfo("No", 0, 0, "", "not applicable", "Empty repository")
    owner = str((repo_data.get("owner") or {}).get("login") or "")
    repo = str(repo_data.get("name") or "")
    default_branch = str(repo_data.get("default_branch") or "")

    if config.large_file_scan_mode == "off":
        return LargeFileInfo("Unknown", None, None, "", "not scanned", "Large-file scan disabled")
    if config.large_file_scan_mode == "default-branch":
        return scan_large_files_default_branch(
            client, owner, repo, default_branch, config.large_file_threshold_bytes
        )
    return scan_large_files_history(config, owner, repo, str(repo_data.get("clone_url") or ""))


def format_mb(value: Optional[int]) -> Optional[float]:
    if value is None:
        return None
    return round(value / (1024 * 1024), 2)


def repository_to_row(
    client: GitHubClient,
    config: Config,
    repo_data: dict[str, Any],
) -> dict[str, Any]:
    owner = str((repo_data.get("owner") or {}).get("login") or "")
    name = str(repo_data.get("name") or "")
    default_branch = str(repo_data.get("default_branch") or "")
    notes: list[str] = []

    commit = latest_commit(client, owner, name, default_branch)
    if commit.note:
        notes.append(commit.note)

    if config.detect_pipelines:
        pipeline = detect_pipeline(client, owner, name, default_branch, commit.empty)
    else:
        pipeline = PipelineInfo("Unknown", note="Pipeline detection disabled")
    if pipeline.note:
        notes.append(pipeline.note)

    large = scan_large_files(client, config, repo_data, commit.empty)
    if large.note:
        notes.append(large.note)

    visibility = str(repo_data.get("visibility") or "")
    if not visibility:
        visibility = "private" if repo_data.get("private") else "public"

    return {
        "Source Organization": owner,
        "Source Repo URL": str(repo_data.get("html_url") or ""),
        "Last Commit Author Name": commit.author_name,
        "Last Commit Author Email": commit.author_email,
        "Last Commit Date": commit.committed_at,
        "Last Commit SHA": commit.sha,
        "Has Pipeline": pipeline.value,
        "Has Large File": large.value,
        "Is Empty Repository": commit.empty,
        "Status": config.status_default,
        "Repository Name": name,
        "Default Branch": default_branch,
        "Visibility": visibility,
        "Archived": "Yes" if repo_data.get("archived") else "No",
        "Fork": "Yes" if repo_data.get("fork") else "No",
        "Pipeline Evidence": pipeline.evidence,
        "Large File Threshold MB": config.large_file_threshold_mb,
        "Large File Count": large.count,
        "Largest Blob MB": format_mb(large.largest_bytes),
        "Largest Blob Path": large.largest_path,
        "Large File Scan Scope": large.scope,
        "Repository Size KB (API)": repo_data.get("size"),
        "Repository Pushed At": str(repo_data.get("pushed_at") or ""),
        "Notes": " | ".join(dict.fromkeys(note for note in notes if note)),
        "Collected At UTC": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


def write_csv(rows: list[dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=HEADERS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_xlsx(rows: list[dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Repository Inventory"
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:Y{max(1, len(rows) + 1)}"

    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    thin_gray = Side(style="thin", color="D9E2F3")
    border = Border(bottom=thin_gray)

    for column_index, header in enumerate(HEADERS, start=1):
        cell = sheet.cell(row=1, column=column_index, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border

    for row_index, row in enumerate(rows, start=2):
        for column_index, header in enumerate(HEADERS, start=1):
            value = row.get(header)
            cell = sheet.cell(row=row_index, column=column_index, value=value)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if header == "Source Repo URL" and value:
                cell.hyperlink = str(value)
                cell.style = "Hyperlink"

    end_row = max(2, len(rows) + 1)
    table = Table(displayName="GHESRepositoryInventory", ref=f"A1:Y{end_row}")
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False
    )
    sheet.add_table(table)

    widths = {
        "A": 22,
        "B": 52,
        "C": 26,
        "D": 34,
        "E": 24,
        "F": 44,
        "G": 15,
        "H": 17,
        "I": 18,
        "J": 20,
        "K": 28,
        "L": 20,
        "M": 14,
        "N": 12,
        "O": 10,
        "P": 45,
        "Q": 22,
        "R": 18,
        "S": 18,
        "T": 45,
        "U": 25,
        "V": 23,
        "W": 24,
        "X": 58,
        "Y": 24,
    }
    for column, width in widths.items():
        sheet.column_dimensions[column].width = width
    sheet.row_dimensions[1].height = 36

    status_validation = DataValidation(
        type="list",
        formula1='"Has not started,In progress,Completed,Failed,Skipped"',
        allow_blank=False,
    )
    sheet.add_data_validation(status_validation)
    status_validation.add(f"J2:J{max(5000, end_row)}")

    green_fill = PatternFill("solid", fgColor="E2F0D9")
    red_fill = PatternFill("solid", fgColor="FCE4D6")
    yellow_fill = PatternFill("solid", fgColor="FFF2CC")
    for column in ["G", "H", "I", "N", "O"]:
        sheet.conditional_formatting.add(
            f"{column}2:{column}{end_row}", FormulaRule(formula=[f'{column}2="Yes"'], fill=green_fill)
        )
        sheet.conditional_formatting.add(
            f"{column}2:{column}{end_row}", FormulaRule(formula=[f'{column}2="No"'], fill=red_fill)
        )
        sheet.conditional_formatting.add(
            f"{column}2:{column}{end_row}", FormulaRule(formula=[f'{column}2="Unknown"'], fill=yellow_fill)
        )

    sheet.sheet_view.showGridLines = False
    workbook.save(path)


def configure_logging(log_file: Path, verbose: bool) -> None:
    log_file.parent.mkdir(parents=True, exist_ok=True)
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout), logging.FileHandler(log_file, encoding="utf-8")]
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=handlers,
        force=True,
    )


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env", default=".env", help="Path to the environment file")
    parser.add_argument("--verbose", action="store_true", help="Enable debug logging")
    parser.add_argument("--version", action="version", version=VERSION)
    args = parser.parse_args(argv)

    env_path = Path(args.env).expanduser().resolve()
    try:
        config = build_config(env_path)
        configure_logging(config.log_file, args.verbose)
        logging.info("GHES repository inventory v%s", VERSION)
        logging.info("Source API: %s", config.ghes_api_url)
        logging.info("Large-file scan mode: %s (> %.2f MiB)", config.large_file_scan_mode, config.large_file_threshold_mb)

        client = GitHubClient(config)
        user, _ = client.request_json("/user")
        logging.info("Authenticated as: %s", user.get("login", "unknown") if isinstance(user, dict) else "unknown")

        organizations = discover_organizations(client, config)
        logging.info("Organizations selected (%d): %s", len(organizations), ", ".join(organizations))

        repository_regex = re.compile(config.repository_filter, re.IGNORECASE) if config.repository_filter else None
        selected: list[dict[str, Any]] = []
        for org_index, org in enumerate(organizations, start=1):
            logging.info("Organization [%d/%d]: %s", org_index, len(organizations), org)
            try:
                repos = list_repositories(client, org)
                logging.info("%s: %d repositories returned", org, len(repos))
            except Exception as exc:
                logging.error("Could not list repositories for %s: %s", org, exc)
                continue
            for repo in repos:
                full_name = str(repo.get("full_name") or f"{org}/{repo.get('name', '')}")
                if not config.include_archived and repo.get("archived"):
                    continue
                if not config.include_forks and repo.get("fork"):
                    continue
                if repository_regex and not repository_regex.search(full_name):
                    continue
                selected.append(repo)
                if config.max_repositories > 0 and len(selected) >= config.max_repositories:
                    break
            if config.max_repositories > 0 and len(selected) >= config.max_repositories:
                break

        logging.info("Repositories selected: %d", len(selected))
        rows: list[dict[str, Any]] = []
        total = len(selected)
        for index, repo in enumerate(selected, start=1):
            full_name = str(repo.get("full_name") or repo.get("name") or "unknown")
            logging.info("[%d/%d] Scanning %s", index, total, full_name)
            try:
                rows.append(repository_to_row(client, config, repo))
            except Exception as exc:
                logging.exception("Unexpected repository scan failure for %s", full_name)
                owner = str((repo.get("owner") or {}).get("login") or "")
                rows.append(
                    {
                        "Source Organization": owner,
                        "Source Repo URL": str(repo.get("html_url") or ""),
                        "Has Pipeline": "Unknown",
                        "Has Large File": "Unknown",
                        "Is Empty Repository": "Unknown",
                        "Status": config.status_default,
                        "Repository Name": str(repo.get("name") or ""),
                        "Archived": "Yes" if repo.get("archived") else "No",
                        "Fork": "Yes" if repo.get("fork") else "No",
                        "Large File Threshold MB": config.large_file_threshold_mb,
                        "Large File Scan Scope": config.large_file_scan_mode,
                        "Notes": f"Unexpected scan failure: {exc}",
                        "Collected At UTC": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    }
                )

        write_csv(rows, config.output_csv)
        write_xlsx(rows, config.output_xlsx)
        logging.info("Excel workbook: %s", config.output_xlsx)
        logging.info("CSV copy: %s", config.output_csv)
        logging.info("Completed: %d repository rows", len(rows))
        return 0
    except InventoryError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
