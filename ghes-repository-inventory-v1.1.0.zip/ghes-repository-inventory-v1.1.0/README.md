# GHES Repository Inventory v1.1.0

Creates one Excel workbook containing repositories from all selected GitHub Enterprise Server organizations. Every repository is one row in the single worksheet `Repository Inventory`.

## Mandatory columns

The first columns are exactly:

1. Source Organization
2. Source Repo URL
3. Last Commit Author Name
4. Last Commit Author Email
5. Last Commit Date
6. Last Commit SHA
7. Has Pipeline
8. Has Large File
9. Is Empty Repository
10. Status

`Status` is initialized to `Has not started` for every row.

Additional diagnostic columns follow the mandatory columns, including pipeline evidence, large-file count, largest blob, default branch, visibility, archived/fork flags, API repository size, last pushed timestamp, and notes.

## Source already prefilled

The environment template contains:

```text
GHES_WEB_URL=https://github.int.inceptionai.ai
GHES_API_URL=https://github.int.inceptionai.ai/api/v3
```

Only the token is required for the default all-organization scan.

## Install and run

`run.sh` creates a private `.venv` under this folder. It does not install packages into Homebrew or the macOS system Python. Do not use `--break-system-packages`.

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

Set:

```env
GHES_TOKEN="YOUR_CLASSIC_PAT"
```

Then run:

```bash
./run.sh
```

Outputs:

```text
output/ghes-repository-inventory.xlsx
output/ghes-repository-inventory.csv
output/ghes-repository-inventory.log
```

The token is read from `.env`; it is never written to the workbook, CSV, or log.

## Organization discovery

Default:

```env
ORG_DISCOVERY_MODE="all"
SOURCE_ORGS=""
```

`all` walks `GET /organizations` using GitHub's required `since` cursor, so it continues beyond 100 organizations. Every discovered organization is placed into the same inventory scan. `SOURCE_ORGS` can still add named organizations.

Organization discovery and repository-content authorization are separate. The endpoint can enumerate organization names, but private repository details are returned only where the token has access. Organizations whose repositories cannot be listed are recorded in the log. For guaranteed coverage, specify every organization explicitly:

```env
ORG_DISCOVERY_MODE="explicit"
SOURCE_ORGS="EnergyAI,AnotherOrg,ThirdOrg"
```

## Meaning of the inventory fields

### Last commit

The script reads the newest commit on the repository's default branch. The date is the commit committer date (falling back to the author date), not the repository's `pushed_at` field. `Repository Pushed At` is included separately as an additional column.

### Has Pipeline

`Yes` when the script finds either:

- one or more GitHub Actions workflows, or
- a common CI/CD configuration such as `azure-pipelines.yml`, `Jenkinsfile`, `.gitlab-ci.yml`, `.circleci/config.yml`, `bitbucket-pipelines.yml`, `.travis.yml`, or `buildspec.yml`.

The detected file or workflow is recorded under `Pipeline Evidence`.

### Has Large File

Default:

```env
LARGE_FILE_SCAN_MODE="history"
LARGE_FILE_THRESHOLD_MB="100"
```

`history` performs a mirror clone and checks every reachable blob in every branch and tag. This is the accurate mode for migration readiness because a large file can exist only in historical commits.

This mode can require substantial time, network bandwidth, and temporary disk space when scanning many repositories. Mirrors are deleted after each repository unless this is enabled:

```env
KEEP_MIRROR_CACHE="true"
```

Faster current-state-only mode:

```env
LARGE_FILE_SCAN_MODE="default-branch"
```

That mode checks only the default branch's current recursive tree. If GitHub reports a truncated tree and no large blob was found, the value is `Unknown` instead of an unsafe `No`.

Disable the scan:

```env
LARGE_FILE_SCAN_MODE="off"
```

### Empty repository

`Yes` when the repository has no default branch or GitHub returns the empty-repository response for the commit endpoint.

## Initial test

Before scanning the entire instance, set:

```env
MAX_REPOSITORIES="3"
LARGE_FILE_SCAN_MODE="default-branch"
```

Run the script and inspect the workbook. Then restore:

```env
MAX_REPOSITORIES="0"
LARGE_FILE_SCAN_MODE="history"
```

## TLS

For an internal certificate authority, set:

```env
CA_BUNDLE="/absolute/path/to/internal-ca.pem"
```

Avoid disabling TLS verification. It is available only for controlled troubleshooting:

```env
VERIFY_SSL="false"
```

## Requirements

- Python 3.9+ with `venv` support; `run.sh` creates `.venv` automatically
- Git command-line client for full-history large-file detection
- A GHES token with read access to all organizations and private repositories that must be included
- `repo` scope for private repository data and workflow inspection

## Notes about values

`Unknown` is used when the token or API cannot safely establish `Yes` or `No`. This prevents inaccessible repositories or truncated trees from being incorrectly reported as clean.


## Upgrade from v1.0.0

Copy only your `.env` into the v1.1.0 directory, or create a new `.env` from the template. Do not copy the old `.venv` directory. Then run `./run.sh`.

## Rebuild the local environment

```bash
rm -rf .venv
./run.sh
```
