# Changelog

## 1.1.0

- Fixed macOS/Homebrew PEP 668 failures by installing dependencies only inside a local `.venv`.
- Changed the default organization discovery mode to `all`.
- Fixed `GET /organizations` pagination to use GitHub's required `since` cursor, including instances with more than 100 organizations.
- Added organization-level progress logging.
- Added tests for cursor pagination.
