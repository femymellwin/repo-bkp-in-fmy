#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

ENV_FILE="${ENV_FILE:-.env}"
VENV_DIR="${VENV_DIR:-.venv}"
PYTHON_BIN="${PYTHON_BIN:-python3}"

if [[ ! -f "$ENV_FILE" ]]; then
  cp .env.example "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  echo "Created $ENV_FILE from .env.example." >&2
  echo "Fill GHES_TOKEN, then rerun ./run.sh" >&2
  exit 2
fi

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: $PYTHON_BIN was not found. Install Python 3, then rerun." >&2
  exit 2
fi

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
  echo "Creating isolated Python environment: $VENV_DIR"
  if ! "$PYTHON_BIN" -m venv "$VENV_DIR"; then
    echo "ERROR: Python could not create a virtual environment." >&2
    echo "On macOS with Homebrew, reinstall Python with: brew install python" >&2
    exit 2
  fi
fi

VENV_PYTHON="$VENV_DIR/bin/python"
REQ_HASH_FILE="$VENV_DIR/.requirements.sha256"
CURRENT_REQ_HASH="$(shasum -a 256 requirements.txt | awk '{print $1}')"
INSTALLED_REQ_HASH="$(cat "$REQ_HASH_FILE" 2>/dev/null || true)"

if [[ "$CURRENT_REQ_HASH" != "$INSTALLED_REQ_HASH" ]]; then
  echo "Installing dependencies inside $VENV_DIR (system Python is not modified)..."
  if ! "$VENV_PYTHON" -m pip install --disable-pip-version-check --quiet -r requirements.txt; then
    echo "ERROR: Dependency installation inside $VENV_DIR failed." >&2
    echo "The system Python was not modified. Check Internet/proxy access to PyPI, then rerun." >&2
    echo "Manual equivalent: $VENV_PYTHON -m pip install -r requirements.txt" >&2
    exit 2
  fi
  printf '%s\n' "$CURRENT_REQ_HASH" > "$REQ_HASH_FILE"
fi

exec "$VENV_PYTHON" scripts/ghes_repository_inventory.py --env "$ENV_FILE" "$@"
