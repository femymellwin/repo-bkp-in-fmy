import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "scripts" / "ghes_repository_inventory.py"
spec = importlib.util.spec_from_file_location("inventory", MODULE_PATH)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
assert spec.loader is not None
spec.loader.exec_module(module)


def run(*args, cwd):
    subprocess.run(args, cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def test_parse_bool():
    assert module.parse_bool("true") is True
    assert module.parse_bool("No") is False


def test_history_blob_scan():
    with tempfile.TemporaryDirectory() as td:
        repo = Path(td) / "repo"
        repo.mkdir()
        run("git", "init", "-q", cwd=repo)
        run("git", "config", "user.name", "Test User", cwd=repo)
        run("git", "config", "user.email", "test@example.com", cwd=repo)
        (repo / "small.txt").write_text("small", encoding="utf-8")
        run("git", "add", "small.txt", cwd=repo)
        run("git", "commit", "-q", "-m", "small", cwd=repo)
        (repo / "large.bin").write_bytes(b"x" * 2048)
        run("git", "add", "large.bin", cwd=repo)
        run("git", "commit", "-q", "-m", "large", cwd=repo)
        count, largest, path = module.inspect_mirror_for_large_files(repo, 1024)
        assert count == 1
        assert largest == 2048
        assert path == "large.bin"


def test_xlsx_headers(tmp_path):
    output = tmp_path / "inventory.xlsx"
    module.write_xlsx([], output)
    assert output.exists()
    from openpyxl import load_workbook
    wb = load_workbook(output)
    ws = wb["Repository Inventory"]
    headers = [ws.cell(1, i).value for i in range(1, len(module.HEADERS) + 1)]
    assert headers == module.HEADERS


class FakeOrgClient:
    def __init__(self):
        self.calls = []

    def request_json(self, path, params=None):
        self.calls.append((path, dict(params or {})))
        since = int((params or {}).get("since", 0))
        if since == 0:
            return ([{"login": f"org-{i}", "id": i} for i in range(1, 101)], {})
        if since == 100:
            return ([{"login": "org-101", "id": 101}], {})
        return ([], {})


def test_all_organizations_uses_since_cursor():
    client = FakeOrgClient()
    organizations = list(module.GitHubClient.all_organizations(client))
    assert len(organizations) == 101
    assert client.calls[0][1] == {"per_page": 100, "since": 0}
    assert client.calls[1][1] == {"per_page": 100, "since": 100}
