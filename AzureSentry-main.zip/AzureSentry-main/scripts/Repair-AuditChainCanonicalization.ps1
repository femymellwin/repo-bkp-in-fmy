<#
.SYNOPSIS
    One-time migration: re-derive every audit event's id/prevHash/hash under the new,
    host-independent canonical JSON serializer (ConvertTo-CanonicalJsonValue,
    dashboard/api/AuditLog.ps1), without touching any other field.

.DESCRIPTION
    Fixes a confirmed bug: the old canonicalization used ConvertTo-Json, whose escaping
    (Windows PowerShell 5.1 escapes `'` as `'`; pwsh 7 does not) and hashtable key
    order are not guaranteed identical across PowerShell hosts. Verifying a chain on a
    different host than the one that wrote it could -- and, on this project's own local
    audit log, did -- report false "tampered" breaks. See dashboard/api/AuditLog.ps1's
    ConvertTo-CanonicalJsonValue for the fix.

    That fix is necessarily NOT retroactive: an event's hash is cryptographically bound
    to whichever algorithm computed it, so switching algorithms invalidates every
    existing hash in the file, even ones that previously verified correctly. This script
    is the one-time, explicit, backed-up migration that re-notarizes existing history
    under the new algorithm -- it does not touch seq, timestamp, agent, action, actor,
    runId, correlationId, ticketId, target, before, after, outcome, reason, detail,
    correctsEventId, or isWrite on any record; only id/prevHash/hash are recomputed.

    Every input file is backed up (untouched, alongside the original) before anything is
    rewritten, and this script is safe to re-run: recomputing an already-migrated chain
    reproduces the same hashes it already has (the canonicalizer is deterministic), so a
    second run is a no-op verification, not a further change.

.PARAMETER Path
    One or more audit log files to migrate. Defaults to the three this project ships:
    dashboard/api/audit-log.jsonl, audit-log-poller.jsonl, audit-log-reaper.jsonl.

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Repair-AuditChainCanonicalization.ps1
#>
[CmdletBinding()]
param(
    [string[]]$Path
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent
$apiRoot = Join-Path $repoRoot 'dashboard/api'

. (Join-Path $apiRoot 'AuditLog.ps1')

if (-not $Path -or $Path.Count -eq 0) {
    $Path = @(
        (Join-Path $apiRoot 'audit-log.jsonl')
        (Join-Path $apiRoot 'audit-log-poller.jsonl')
        (Join-Path $apiRoot 'audit-log-reaper.jsonl')
    )
}

$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddHHmmss')

foreach ($file in $Path) {
    if (-not (Test-Path -LiteralPath $file)) {
        Write-Host "[skip] $file does not exist." -ForegroundColor DarkGray
        continue
    }

    Write-Host "== $file ==" -ForegroundColor Cyan

    # -Encoding UTF8 explicitly -- reading this file with the wrong default encoding
    # (the exact bug this migration exists to fix the SYMPTOM of) would corrupt the very
    # content this script must migrate byte-for-byte faithfully.
    $lines = @(Get-Content -LiteralPath $file -Encoding UTF8)
    $records = [System.Collections.Generic.List[object]]::new()
    $parseFailures = 0
    foreach ($line in $lines) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try { $records.Add(($line | ConvertFrom-Json -ErrorAction Stop)) }
        catch { $parseFailures++ }
    }
    if ($parseFailures -gt 0) {
        Write-Host "  [warn] $parseFailures unparseable line(s) skipped -- investigate before trusting this file." -ForegroundColor Yellow
    }
    if ($records.Count -eq 0) {
        Write-Host '  Nothing to migrate.' -ForegroundColor DarkGray
        continue
    }

    # Sequence must already be contiguous from 1 -- a real gap is a different, more
    # serious problem this script must not paper over by silently renumbering.
    $expectedSeq = 1
    foreach ($r in $records) {
        if ([int]$r.seq -ne $expectedSeq) {
            throw "$file`: sequence gap at expected seq $expectedSeq (found $($r.seq)). Not migrating -- this is not the encoding/escaping bug this script fixes; investigate the file directly."
        }
        $expectedSeq++
    }

    $backupPath = "$file.pre-canonicalization-fix-$stamp.bak"
    Copy-Item -LiteralPath $file -Destination $backupPath
    Write-Host "  Backed up original to $backupPath"

    $prevHash = 'GENESIS'
    $newLines = [System.Collections.Generic.List[string]]::new()
    foreach ($r in $records) {
        # Get-AuditCanonicalBody reads every content field straight off the parsed
        # PSCustomObject unchanged -- only id/prevHash/hash below are ever replaced.
        $bodyJson = Get-AuditCanonicalBody -Source $r
        $hash = Get-AuditEventHash -PrevHash $prevHash -BodyJson $bodyJson

        $event = [ordered]@{}
        foreach ($field in $script:AuditBodyFields) { $event[$field] = $r.$field }
        $event['id'] = "$([int]$r.seq)-$($hash.Substring(0, 12))"
        $event['prevHash'] = $prevHash
        $event['hash'] = $hash

        $newLines.Add((ConvertTo-CanonicalJsonValue -Value $event))
        $prevHash = $hash
    }

    # UTF8 without BOM, matching Write-AuditEvent -- WriteAllLines with this exact
    # encoding overload never emits one, on either PS 5.1 or pwsh 7 (unlike
    # Set-Content -Encoding utf8, which does on PS 5.1 -- see DashboardHelpers.ps1's
    # Save-ProcessedTicket comment for the same trap elsewhere in this codebase).
    [System.IO.File]::WriteAllLines($file, [string[]]$newLines, [System.Text.UTF8Encoding]::new($false))

    $verify = Test-AuditChainIntegrity -Path $file
    if ($verify.ok) {
        Write-Host "  Migrated $($records.Count) record(s). Verify: OK ($($verify.reason))" -ForegroundColor Green
    }
    else {
        Write-Host "  Migrated $($records.Count) record(s). Verify: FAILED -- $($verify.reason). Restoring from backup." -ForegroundColor Red
        Copy-Item -LiteralPath $backupPath -Destination $file -Force
        throw "$file`: post-migration verification failed; original restored from $backupPath. This should not happen -- investigate before re-running."
    }
}
