<#
.SYNOPSIS
    Scheduler entry point (systemd timer): run exactly one reaper cycle and exit.

.DESCRIPTION
    Builds the real dependency context for Invoke-ReaperCycle and writes the result to
    reaper-status.json for the dashboard to read.

    Deliberately one cycle per invocation rather than a long-lived loop -- same reasoning
    as scripts/Invoke-TicketPollerCycle.ps1: the scheduler owns the cadence, a hung cycle
    cannot wedge the reaper forever, and each run gets a clean PowerShell session with
    fresh tokens.

    Ships inert. AZURESENTRY_REAPER_ENABLED must be exactly 'true' to do anything, and
    AZURESENTRY_REAPER_MODE must be exactly 'enforce' to write.
#>
[CmdletBinding()]
param(
    [switch]$VerboseOutput
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent
# Forward slashes throughout, not backslashes -- this runs under both Windows
# PowerShell 5.1 (local) and pwsh 7 on Ubuntu in production (see
# Invoke-TicketPollerCycle.ps1 for the identical reasoning).
$apiRoot = Join-Path $repoRoot 'dashboard/api'

# --- load .env exactly the way the dashboard API / poller do ---
$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            $name = $Matches[1]
            if (Test-Path "Env:\$name") { return }
            $val = $Matches[2].Trim()
            if (($val.StartsWith('"') -and $val.EndsWith('"')) -or ($val.StartsWith("'") -and $val.EndsWith("'"))) {
                $val = $val.Substring(1, $val.Length - 2)
            }
            [System.Environment]::SetEnvironmentVariable($name, $val, 'Process')
        }
    }
}

. (Join-Path $repoRoot 'src/Agents/AgentRuntime.ps1')
. (Join-Path $repoRoot 'src/Agents/ReaperAgent.ps1')
. (Join-Path $apiRoot 'ProcessedStore.ps1')
. (Join-Path $apiRoot 'AuditLog.ps1')
# Test-GrantRevocable / Get-RevokeFulfilmentMode: the revocability policy shared with the
# dashboard's /api/manageengine/revoke route. GrantRevocation.ps1 depends on these being
# in scope already -- see that file's header.
. (Join-Path $apiRoot 'DashboardHelpers.ps1')
. (Join-Path $apiRoot 'GrantRevocation.ps1')

# Real Graph/SPN client, prefix-imported so its function names cannot collide with
# anything else dot-sourced into this session -- same pattern as the poller entry script
# and Start-DashboardApi.ps1.
Import-Module (Join-Path $repoRoot 'src/PimClient/GraphPimClient.psm1') -Force -Prefix Real

Initialize-ProcessedStore -Path (Join-Path $apiRoot 'processed-tickets.json')
# A SEPARATE file from both the dashboard API's audit-log.jsonl and the poller's
# audit-log-poller.jsonl, deliberately: Write-AuditEvent derives seq/prevHash from state
# cached in THIS process, so two processes appending to the SAME file corrupt each
# other's chain (see Invoke-TicketPollerCycle.ps1's identical reasoning). Each writer
# owns one unbroken chain.
Initialize-AuditLog -Path (Join-Path $apiRoot 'audit-log-reaper.jsonl') | Out-Null

$stopFile = Join-Path $apiRoot 'reaper.stop'
# Sibling of $stopFile, same explicit apiRoot-relative path both here and in the
# dashboard's POST/DELETE /api/reaper/mode handlers (Start-DashboardApi.ps1) -- see the
# identical comment on $modeFile in scripts/Invoke-TicketPollerCycle.ps1.
$modeFile = Join-Path $apiRoot 'reaper.mode'
# Same reasoning and same explicit apiRoot-relative pattern as $modeFile, for the
# Automation control's two newer override files (POST /api/reaper/enabled,
# POST /api/reaper/caps in Start-DashboardApi.ps1).
$enabledFile = Join-Path $apiRoot 'reaper.enabled'
$capsOverrideFile = Join-Path $apiRoot 'reaper.caps.json'
$statusFile = Join-Path $apiRoot 'reaper-status.json'
$config = Get-ReaperConfig -StopFilePath $stopFile -ModeOverrideFilePath $modeFile `
    -EnabledOverrideFilePath $enabledFile -CapsOverrideFilePath $capsOverrideFile

# Fail fast and visibly if enforce was requested without the credentials to honour it,
# rather than silently revoking nothing and looking like a policy decision.
if ($config.Enabled -and $config.Mode -eq 'enforce') {
    if (-not ($env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET)) {
        throw 'Reaper is in enforce mode but AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET are not all set.'
    }
}

$runId = if (Get-Command -Name New-AgentRunId -ErrorAction SilentlyContinue) {
    New-AgentRunId -Agent 'reaper'
} else {
    "reap-$([guid]::NewGuid().ToString('N').Substring(0, 12))"
}

$revokeGrant = {
    param($TicketId, $Prior)

    # One real client per revoked ticket, not shared across the cycle -- mirrors the
    # poller's ExecuteGrant, which builds its own client per grant rather than caching
    # one for the whole run, so a single stale/expired token cannot silently fail every
    # remaining record in the cycle.
    $client = New-RealGraphPimClient -TenantId $env:AZURE_TENANT_ID `
        -ClientId $env:AZURE_CLIENT_ID -ClientSecret $env:AZURE_CLIENT_SECRET

    $revokeContext = @{
        ResolveUpnToObjectId = { param($Upn) Resolve-RealUpnToObjectId -Client $client -Upn $Upn }.GetNewClosure()
        RemoveGroupMember    = { param($GroupId, $UserId) Remove-RealEntraGroupMember -Client $client -GroupId $GroupId -UserId $UserId }.GetNewClosure()
        GetRoleDefinitionId  = { param($RoleName) Get-RealRoleDefinitionId -RoleName $RoleName }.GetNewClosure()
        RemoveAssignment     = {
            param($AssignmentId, $Scope, $UserId, $RoleDefinitionId, $AssignmentType)
            Remove-RealPimAssignment -Client $client -AssignmentId $AssignmentId -Scope $Scope `
                -UserId $UserId -RoleDefinitionId $RoleDefinitionId -AssignmentType $AssignmentType
        }.GetNewClosure()
    }

    $rev = Invoke-GrantRevocationAction -Prior $Prior -Context $revokeContext
    if (-not $rev.Ok) {
        return @{ ok = $false; error = $rev.Error }
    }

    # Merge onto the existing record rather than overwrite it -- preserves everything
    # ExecuteGrant originally wrote (assignmentId, fulfilment, groupId, environment, ...)
    # so the dashboard's assignments view still shows what was granted, now revoked.
    # Same merge pattern as the poller's RecordProcessed hook.
    $updated = [ordered]@{}
    if ($Prior -is [hashtable]) {
        $Prior.GetEnumerator() | ForEach-Object { $updated[$_.Key] = $_.Value }
    }
    else {
        $Prior.PSObject.Properties | ForEach-Object { $updated[$_.Name] = $_.Value }
    }
    $updated.revoked = $true
    $updated.revokedAt = (Get-Date).ToUniversalTime().ToString('o')
    $updated.revokeJustification = "Automatic revocation by the reaper agent: recorded expiry (tracked, not Azure-enforced for a Group grant) had passed."
    $updated.revokedBy = 'reaper'
    $updated.revokeRunId = $runId

    Save-ProcessedTicket -MeTicketId ([string]$TicketId) -Entry $updated
    return @{ ok = $true }
}.GetNewClosure()

$context = @{
    Config              = $config
    RunId               = $runId
    Now                 = [datetime]::UtcNow
    GetProcessedTickets = { Get-ProcessedTickets }
    RevokeGrant         = $revokeGrant
}

$result = Invoke-ReaperCycle -Context $context

# Audit every cycle, including shadow, so the unattended path is never a black box --
# same reasoning and outcome mapping as Invoke-TicketPollerCycle.ps1.
if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
    $auditOutcomeMap = @{
        Revoked     = 'Success'
        Failed      = 'Failed'
        WouldRevoke = 'DryRun'
        Deferred    = 'Blocked'
    }
    foreach ($entry in $result.Entries) {
        $outcomeRaw = [string]$entry.outcome
        $auditOutcome = if ($auditOutcomeMap.ContainsKey($outcomeRaw)) { $auditOutcomeMap[$outcomeRaw] } else { 'Blocked' }

        $detail = @{}
        $entry.PSObject.Properties | ForEach-Object { $detail[$_.Name] = $_.Value }

        Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'AutoRevoke' -Actor 'reaper' `
            -RunId $result.RunId -TicketId ([string]$entry.ticketId) `
            -Outcome $auditOutcome -Detail $detail -IsWrite:($outcomeRaw -eq 'Revoked')
    }
}

($result | ConvertTo-Json -Depth 8) | Set-Content -Path $statusFile -Encoding UTF8

$summary = "[reaper] run=$($result.RunId) mode=$($result.Mode) examined=$($result.Examined) wouldRevoke=$($result.WouldRevoke) revoked=$($result.Revoked) deferred=$($result.Deferred) failed=$($result.Failed)"
if ($result.Halted) { $summary += " HALTED: $($result.HaltReason)" }
if ($result.Stopped) { $summary += ' STOPPED (fail-closed)' }
Write-Output $summary

if ($VerboseOutput) { $result.Entries | Format-Table ticketId, outcome, reason -AutoSize | Out-String | Write-Output }

# Non-zero exit on a failed cycle so systemctl status / journalctl show the failure.
if ($result.Failed -gt 0) { exit 1 }
exit 0
