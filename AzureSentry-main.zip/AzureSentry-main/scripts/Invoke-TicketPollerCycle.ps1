<#
.SYNOPSIS
    Scheduler entry point (systemd timer): run exactly one unattended poll cycle and exit.

.DESCRIPTION
    Builds the real dependency context for Invoke-TicketPollerCycle and writes the result
    to poller-status.json for the dashboard to read.

    Deliberately one cycle per invocation rather than a long-lived loop: the scheduler owns
    the cadence, a hung cycle cannot wedge the poller forever, and each run gets a clean
    PowerShell session with fresh tokens.

    Ships inert. AZURESENTRY_POLLER_ENABLED must be exactly 'true' to do anything, and
    AZURESENTRY_POLLER_MODE must be exactly 'enforce' to write.
#>
[CmdletBinding()]
param(
    [switch]$VerboseOutput
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent
# Forward slashes throughout this file, not backslashes: this script runs under both
# Windows PowerShell 5.1 (local) and pwsh 7 on Ubuntu in production. Join-Path resolves
# '/' correctly on both platforms; a literal embedded '\' would be a no-op path separator
# on Linux and silently fail to find every dot-sourced file.
$apiRoot = Join-Path $repoRoot 'dashboard/api'

# --- load .env exactly the way the dashboard API does (Start-DashboardApi.ps1:24-36) ---
# The real .env lives at REPO ROOT, not dashboard/api/.env -- that path does not exist, so
# reading it here used to leave every credential unset with no error, and every cycle
# silently examined 0 tickets. Regex + paired-quote handling is copied verbatim from the
# API so a value that legitimately contains an unpaired quote, or is single-quoted, is
# handled the same way in both places; a second, drifted parser here would be its own bug.
#
# Existing keys are left untouched: on the VM, systemd's EnvironmentFile=/etc/azuresentry.env
# has already populated the process environment by the time this runs, and that file (not a
# developer's local .env, which does not even ship to the VM -- see Deploy-ToVm.ps1's
# robocopy exclusions) must win. Locally, where nothing pre-populates the environment, every
# key in .env is still set exactly as before.
$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            $name = $Matches[1]
            if (Test-Path "Env:\$name") { return }
            $val = $Matches[2].Trim()
            if (($val.StartsWith('"') -and $val.EndsWith('"')) -or ($val.StartsWith("'") -and $val.EndsWith("'"))) {
                $val = $val.Substring(1, $val.Length - 2)
            }
            [System.Environment]::SetEnvironmentVariable($name, $val, 'Process')
        }
    }
}

. (Join-Path $repoRoot 'src/Agents/MeTicketMapper.ps1')
. (Join-Path $repoRoot 'src/Agents/PollerGate.ps1')
. (Join-Path $repoRoot 'src/Agents/TicketPollerAgent.ps1')
. (Join-Path $repoRoot 'src/Agents/AgentRuntime.ps1')
. (Join-Path $apiRoot 'ProcessedStore.ps1')
. (Join-Path $apiRoot 'MeAccessFields.ps1')
. (Join-Path $apiRoot 'AuditLog.ps1')
# Get-ManageEngineNoteKind (DashboardHelpers.ps1) / Send-ManageEngineProcessNote +
# Set-ManageEngineTicketResolved (ManageEngineNotes.ps1): the requester-visible
# write-back for a successful or failed unattended grant. Same reason as every other
# dot-sourced file here -- Start-DashboardApi.ps1 cannot be dot-sourced at all.
. (Join-Path $apiRoot 'DashboardHelpers.ps1')
. (Join-Path $apiRoot 'ManageEngineNotes.ps1')
# Test-AccessPromotionLadder: shared with the dashboard API via AccessPromotion.ps1 so the
# unattended path enforces the identical Sandbox -> NonProd -> Production ladder the human
# path enforces. Sourcing Start-DashboardApi.ps1 itself is impossible (it starts an
# HttpListener at top level) -- same reason ProcessedStore.ps1 and MeAccessFields.ps1 were
# already extracted this way.
. (Join-Path $apiRoot 'AccessPromotion.ps1')
# Resolve-TemplateGrantAllowed: the same exact-schema template gate the dashboard's human
# grant path uses (final-review C2). TicketTemplates.ps1 has no top-level side effects --
# pure function definitions, dot-sourceable exactly like the two files above -- so a
# substring match here cannot silently drift more permissive than the dashboard's own
# gate, which would admit e.g. "Azure Subscription Deletion Request" to unattended
# privilege on nothing more than a shared substring.
. (Join-Path $apiRoot 'TicketTemplates.ps1')
# Get-EffectiveAllowlist / Get-AllowlistConfig / Resolve-ManagementGroupAllowlist: the
# SAME allowlist resolution the dashboard API uses (management-group-derived, fail-closed
# to the static subscriptionAllowlist array on any ARM error) -- this closes the gap that
# left the poller permanently inert on real traffic. It used to read only the static
# list (2 subscriptions) while the dashboard already derived ~18 from ARM, so a
# subscription a human could grant through the dashboard was refused here purely because
# of where the list came from, not any actual policy difference. See that file's own
# header for the full reasoning, including why there is deliberately no on-disk cache.
. (Join-Path $apiRoot 'SubscriptionAllowlist.ps1')

Import-Module (Join-Path $repoRoot 'src/RbacDecision/RbacDecision.psd1') -Force
# Real module is prefix-imported so its function names (New-RealGraphPimClient,
# Resolve-RealUpnToObjectId, Get-RealActiveAssignments, ...) cannot collide with anything
# else that might be dot-sourced into this session -- same pattern Start-DashboardApi.ps1
# uses for the same reason.
Import-Module (Join-Path $repoRoot 'src/PimClient/GraphPimClient.psm1') -Force -Prefix Real
. (Join-Path $repoRoot 'src/PimClient/GroupRbac.ps1')

Initialize-ProcessedStore -Path (Join-Path $apiRoot 'processed-tickets.json')
# A SEPARATE file from the dashboard API's audit-log.jsonl, deliberately. Write-AuditEvent
# serializes with an in-process lock and derives seq/prevHash from state cached in THIS
# process at Initialize-AuditLog -- two processes appending to the SAME file corrupt each
# other's chain (a permanent, false "Chain break at seq N" the moment both run in the same
# window, which the runbook has them doing routinely). Each writer now owns one unbroken
# chain; GET /api/audit/integrity verifies both independently (Test-AuditChainIntegrityMulti
# in AuditLog.ps1). See docs/ticket-poller-runbook.md.
Initialize-AuditLog -Path (Join-Path $apiRoot 'audit-log-poller.jsonl') | Out-Null

$stopFile = Join-Path $apiRoot 'poller.stop'
# Sibling of $stopFile, same explicit apiRoot-relative path both here and in the
# dashboard's POST/DELETE /api/poller/mode handlers (Start-DashboardApi.ps1) -- neither
# side relies on Get-PollerConfig's own internal default (which resolves inside
# dashboard/api/processed-tickets/ instead, a different directory) so a change to that
# default can never silently split the two processes onto different files.
$modeFile = Join-Path $apiRoot 'poller.mode'
# Same reasoning and same explicit apiRoot-relative pattern as $modeFile, for the
# Automation control's two newer override files (POST /api/poller/enabled,
# POST /api/poller/caps in Start-DashboardApi.ps1).
$enabledFile = Join-Path $apiRoot 'poller.enabled'
$capsOverrideFile = Join-Path $apiRoot 'poller.caps.json'
$statusFile = Join-Path $apiRoot 'poller-status.json'
$config = Get-PollerConfig -StopFilePath $stopFile -ModeOverrideFilePath $modeFile `
    -EnabledOverrideFilePath $enabledFile -CapsOverrideFilePath $capsOverrideFile

# Fail fast and visibly if enforce was requested without the credentials to honour it,
# rather than silently granting nothing and looking like a policy decision.
if ($config.Enabled -and $config.Mode -eq 'enforce') {
    if (-not ($env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET)) {
        throw 'Poller is in enforce mode but AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET are not all set.'
    }
}

# MANAGE_ENGINE_URL is the name .env.example actually documents; MANAGE_ENGINE_BASE_URL
# is an alternate the dashboard API also accepts (and prefers when both are set -- see
# Start-DashboardApi.ps1). Reading only one name here would silently read examined=0 for
# anyone whose .env follows the documented convention.
$meBase = ([string]$env:MANAGE_ENGINE_URL).TrimEnd('/')
if ($env:MANAGE_ENGINE_BASE_URL) { $meBase = ([string]$env:MANAGE_ENGINE_BASE_URL).TrimEnd('/') }
$meKey = [string]$env:MANAGE_ENGINE_API_KEY

$fetchTickets = {
    if (-not $meBase -or -not $meKey) { return @() }
    # udf_fields stays in fields_required here for cheap/incidental use only (e.g. it is
    # occasionally non-empty and harmless to have around) -- nothing in this cycle relies
    # on it being populated from THIS call. ManageEngine's LIST endpoint returns
    # udf_fields empty regardless of what fields_required names, even though the field is
    # accepted with no error; only GET /api/v3/requests/{id} (see $fetchTicketDetail
    # below) actually populates it. TicketPollerAgent.ps1 fetches detail per-ticket, after
    # the cheap filters, specifically because of this.
    $fields = '"id","subject","description","status","priority","requester","created_time","udf_fields","template"'
    $listInfo = '{"list_info":{"row_count":100,"start_index":1,"sort_field":"created_time","sort_order":"desc","fields_required":[' + $fields + ']}}'
    $uri = "$meBase/api/v3/requests?input_data=$([uri]::EscapeDataString($listInfo))"
    $resp = Invoke-RestMethod -Uri $uri -Method Get -Headers @{ authtoken = $meKey; Accept = 'application/vnd.manageengine.sdp.v3+json' }
    # Only open work: a Resolved or Closed ticket must never be re-granted.
    return @($resp.requests | Where-Object { [string]$_.status.name -notin @('Resolved', 'Closed', 'Cancelled') })
}

$getAccessFields = {
    param($MeTicket)
    # Shared with the dashboard API via MeAccessFields.ps1 -- these three fields decide
    # which subscription and role is being asked for, so a second copy could drift and
    # change what gets granted unattended. Key overrides come from config.json, the same
    # source the API reads.
    #
    # $MeTicket here is whatever TicketPollerAgent.ps1 resolved as "meForFields" -- the
    # DETAIL-endpoint ticket when $fetchTicketDetail below ran, or the plain LIST ticket
    # otherwise (no FetchTicketDetail hook fired, e.g. the template gate already refused
    # it). Either way this function only ever reads .udf_fields off whatever it is given.
    Get-MeTemplateAccessFields -UdfFields $MeTicket.udf_fields -UdfKeyOverrides $udfKeyOverrides
}

$fetchTicketDetail = {
    param($MeTicketId)
    if (-not $meBase -or -not $meKey) { return $null }
    # THE list-vs-detail trap: GET /api/v3/requests (the list endpoint $fetchTickets
    # calls above) returns udf_fields EMPTY on every ticket, even when udf_fields is
    # named in that call's own fields_required -- confirmed against live ManageEngine,
    # same ticket, both endpoints, same moment: list reported 0 populated udf keys,
    # detail reported 7. Only GET /api/v3/requests/{id} (this call) actually populates
    # udf_fields. This is why Get-ManageEngineRequestById in
    # dashboard/api/Start-DashboardApi.ps1 (which the dashboard UI's field display uses)
    # already fetches detail, and why the poller must too -- reading udf_fields off the
    # list response makes every ticket look like it has no Subscription/Role/Environment
    # set, which silently and permanently queues everything (wouldGrant stuck at 0). Do
    # not "simplify" this back to a list-only fetch.
    $uri = "$meBase/api/v3/requests/$MeTicketId"
    $resp = Invoke-RestMethod -Uri $uri -Method Get -Headers @{ authtoken = $meKey; Accept = 'application/vnd.manageengine.sdp.v3+json' }
    return $resp.request
}

$isTemplateAllowed = {
    param($MeTicket)
    # final-review C2: exact-schema lookup via Resolve-TemplateGrantAllowed, the same
    # gate the dashboard's human grant path uses -- not a substring match. A `-like
    # '*Azure Subscription*'` test admits any template whose name merely CONTAINS "Azure
    # Subscription" (e.g. "Azure Subscription Deletion Request", "Legacy Azure
    # Subscription Access") to the unattended privilege path; Get-TicketTemplateSchema
    # normalizes the name and only matches it exactly (plus the documented alias map).
    $name = if ($MeTicket.template) { [string]$MeTicket.template.name } else { '' }
    # A ticket with no template name at all is refused here, not passed on to
    # Resolve-TemplateGrantAllowed: that function's "no template identity -> Allowed"
    # branch exists for callers (the dashboard's simulator / legacy body shapes) that
    # never carry template data at all. Every real ME ticket always has a template, so a
    # blank name here means malformed data, and the poller must not treat malformed data
    # as a pass -- that would be strictly more permissive than the check it replaces.
    if ([string]::IsNullOrWhiteSpace($name)) { return $false }
    $gate = Resolve-TemplateGrantAllowed -Body ([pscustomobject]@{ templateName = $name })
    return [bool]$gate.Allowed
}

# Load config.json first (udfKeyOverrides, subscriptionLabels) -- the effective
# allowlist below needs $cfg for both the static-fallback list and the label overrides.
$udfKeyOverrides = $null
$cfg = $null
$configFile = Join-Path $apiRoot 'config.json'
if (Test-Path $configFile) {
    $cfg = Get-Content -Raw -Path $configFile | ConvertFrom-Json
    if ($cfg.manageEngine -and $cfg.manageEngine.PSObject.Properties.Name -contains 'udfFields') {
        $udfKeyOverrides = $cfg.manageEngine.udfFields
    }
}

# Effective allowlist -- same resolver the dashboard API uses (Get-EffectiveAllowlist,
# SubscriptionAllowlist.ps1): static config.json list, or live from
# allowlist.managementGroupId, fail-closed to the static list on any ARM error. A
# subscription absent from the resolved list can still never be granted --
# Resolve-AllowlistSubscriptionId (MeTicketMapper.ps1) is exact-match only regardless of
# how large the list gets; only the SOURCE of the list changed here, not the strictness
# of matching against it.
$eff = Get-EffectiveAllowlist -Config $cfg
$allowlistDetails = @(foreach ($id in @($eff.Subs)) {
        # Name resolution: a curated config.json label (trimmed of its "(...)" annotation,
        # e.g. "inception-internal-product (live)" -> "inception-internal-product") wins
        # when present, because that trimmed form is what actually appears in a ManageEngine
        # ticket's Subscription dropdown value; a management-group-derived displayName is the
        # fallback for every subscription that has no curated label (most of an MG-derived
        # list); the bare id is the last resort so a name-only ticket value simply fails the
        # exact-match rather than this loop throwing.
        $fromMg = @($eff.Details | Where-Object { [string]$_.id -eq [string]$id } | Select-Object -First 1)
        $name = if ($cfg -and $cfg.subscriptionLabels -and $cfg.subscriptionLabels.$id) {
            (([string]$cfg.subscriptionLabels.$id) -split '\s*\(')[0].Trim()
        } elseif ($fromMg.Count -gt 0 -and $fromMg[0].name) {
            [string]$fromMg[0].name
        } else { [string]$id }
        [pscustomobject]@{ id = [string]$id; name = $name }
    })

# I1 (2026-08-20 final review): derive the grant duration the same way the dashboard's
# human path does (Start-DashboardApi.ps1: durationHours -> Ceiling(hours/24), minimum 1
# day) instead of a hardcoded 7. Irrelevant to the poller's normal Group fulfilment (no
# expiry timer), but live on the PIM-fallback route -- which fires whenever the SPN lacks
# Group.ReadWrite.All -- where a hardcoded 7 would otherwise leave the unattended path
# granting a week of access against the dashboard's default of one day.
$pollerDurationDays = 7
if ($cfg -and $cfg.azure -and $cfg.azure.defaultDurationHours) {
    $pollerDurationDays = [Math]::Max(1, [Math]::Ceiling([double]$cfg.azure.defaultDurationHours / 24.0))
}

# Generated once, up front, and reused everywhere this cycle needs a run id -- including
# inside $executeGrant's own persisted record (C2) -- so the grant record's runId always
# matches the cycle's own reported RunId instead of drifting from a second id generated
# elsewhere. TicketPollerAgent.ps1 uses this same value (via $context.RunId below) rather
# than minting its own.
$runId = if (Get-Command -Name New-AgentRunId -ErrorAction SilentlyContinue) {
    New-AgentRunId -Agent 'poller'
} else {
    "poll-$([guid]::NewGuid().ToString('N').Substring(0, 12))"
}

# Enforces the same Sandbox -> NonProd -> Production ladder the dashboard's human grant
# path enforces (Test-AccessPromotionLadder, AccessPromotion.ps1), honouring the same
# config.json accessPromotion.enforceLadder flag. $cfg is $null when config.json is
# missing; Test-AccessPromotionLadder treats a falsy -Config as "enforce" (its safe
# default), so that failure mode is fail-closed, not fail-open.
$checkPromotionLadder = {
    param($Ticket, $Decision)
    Test-AccessPromotionLadder -TicketInput $Ticket -Decision $Decision -Config $cfg
}

# Requester-visible ManageEngine write-back for a granted or failed unattended cycle
# (Send-ManageEngineProcessNote / Set-ManageEngineTicketResolved, ManageEngineNotes.ps1).
# Config is layered: $cfg (config.json, read above -- for subscriptionLabels and
# manageEngine.closureFields) with baseUrl/apiKey overwritten by the SAME effective
# values $fetchTickets already resolved ($meBase/$meKey above). config.json's own
# manageEngine.baseUrl/apiKey are typically blank; the real values come from the .env /
# systemd EnvironmentFile overrides this script already applied at the top of the file.
$noteConfig = if ($cfg) { $cfg } else { [pscustomobject]@{} }
if ($noteConfig.PSObject.Properties.Name -notcontains 'manageEngine') {
    $noteConfig | Add-Member -NotePropertyName manageEngine -NotePropertyValue ([pscustomobject]@{}) -Force
}
$noteConfig.manageEngine | Add-Member -NotePropertyName baseUrl -NotePropertyValue $meBase -Force
$noteConfig.manageEngine | Add-Member -NotePropertyName apiKey -NotePropertyValue $meKey -Force

$postTicketNote = {
    param($MeTicketId, $Ticket, $Decision, $Execution)
    Send-ManageEngineProcessNote -MeTicketId $MeTicketId -TicketInput $Ticket -Decision $Decision `
        -Execution $Execution -Config $noteConfig
}.GetNewClosure()

$resolveTicket = {
    param($MeTicketId)
    Set-ManageEngineTicketResolved -MeTicketId $MeTicketId -Config $noteConfig
}.GetNewClosure()

$decide = {
    param($Ticket)
    Resolve-RbacDecision -Ticket $Ticket -SubscriptionAllowlist @($allowlistDetails | ForEach-Object { $_.id })
}

function Invoke-RealGroupOrPimGrant {
    <#
    .SYNOPSIS
      Wraps GroupRbac's Invoke-GroupOrPimGrant with the alias plumbing the real Graph
      client needs.
    .DESCRIPTION
      src/PimClient/GroupRbac.ps1 is dot-sourced (not a module) and calls unprefixed
      command names internally -- Get-RoleDefinitionId, Find-EntraRbacGroups, and so on.
      Those names only exist in this session under their 'Real' prefix (GraphPimClient.psm1
      was imported with -Prefix Real above, to avoid colliding with anything else that
      might get dot-sourced into this process). Without local aliases mapping the
      unprefixed names GroupRbac.ps1 calls onto their Real-prefixed implementations, every
      one of those internal calls would fail with "command not found" the moment enforce
      mode actually tries to grant. This mirrors Invoke-RealGroupOrPimGrant in
      dashboard/api/Start-DashboardApi.ps1 exactly, so the poller and the dashboard API
      exercise the identical grant path.
    #>
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleName,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [Parameter(Mandatory)][string]$ResourceScope,
        [Parameter(Mandatory)][int]$DurationDays,
        [Parameter(Mandatory)][string]$Justification,
        [ValidateSet('Active', 'Eligible')]
        [string]$PimFallbackAssignmentType = 'Active'
    )

    Set-Alias Get-RoleDefinitionId Get-RealRoleDefinitionId -Scope Local
    Set-Alias Get-SubscriptionDisplayName Get-RealSubscriptionDisplayName -Scope Local
    Set-Alias Find-EntraRbacGroups Find-RealEntraRbacGroups -Scope Local
    Set-Alias Test-GroupHasSubscriptionRole Test-RealGroupHasSubscriptionRole -Scope Local
    Set-Alias Add-EntraGroupMember Add-RealEntraGroupMember -Scope Local
    Set-Alias New-ActiveAssignment New-RealActiveAssignment -Scope Local
    Set-Alias New-EligibleAssignment New-RealEligibleAssignment -Scope Local
    Set-Alias New-EntraRbacGroup New-RealEntraRbacGroup -Scope Local
    Set-Alias New-GroupSubscriptionRoleAssignment New-RealGroupSubscriptionRoleAssignment -Scope Local
    Set-Alias Get-EntraGroupMembers Get-RealEntraGroupMembers -Scope Local

    Invoke-GroupOrPimGrant -Client $Client -UserId $UserId -RoleName $RoleName `
        -SubscriptionId $SubscriptionId -SubscriptionName $SubscriptionName `
        -ResourceScope $ResourceScope -DurationDays $DurationDays -Justification $Justification `
        -PimFallbackAssignmentType $PimFallbackAssignmentType
}

function Invoke-RealGroupDuplicateCheck {
    <#
    .SYNOPSIS
      Same alias plumbing as Invoke-RealGroupOrPimGrant above, for the pre-grant group
      duplicate check (final-review C1).
    .DESCRIPTION
      Get-RealActiveAssignments only sees direct user->role->scope assignments. Normal
      fulfilment for everything this poller may grant (Reader/Contributor) is via an
      Entra group -- Invoke-GroupOrPimGrant -> Add-EntraGroupMember -- which is
      invisible to that check. Without this, a requester already a member of the group
      from an earlier ticket reads as "no active assignment", Add-EntraGroupMember
      returns AlreadyMember=$true, and Invoke-GroupOrPimGrant reports Success=$true for
      a grant that changed nothing -- the processed store then holds two live records
      for one access, and revoking one leaves the other believing access is still live.
      Mirrors Invoke-RealGroupDuplicateCheck in dashboard/api/Start-DashboardApi.ps1
      exactly, so the poller and the dashboard API apply the identical duplicate check.
    #>
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleName,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [string]$ResourceScope
    )
    Set-Alias Find-EntraRbacGroups Find-RealEntraRbacGroups -Scope Local
    Set-Alias Get-EntraGroupMembers Get-RealEntraGroupMembers -Scope Local
    Set-Alias Test-EntraGroupMember Test-RealEntraGroupMember -Scope Local
    Set-Alias Get-SubscriptionDisplayName Get-RealSubscriptionDisplayName -Scope Local
    Test-GroupRbacDuplicateAccess -Client $Client -UserId $UserId -RoleName $RoleName `
        -SubscriptionId $SubscriptionId -SubscriptionName $SubscriptionName -ResourceScope $ResourceScope
}

$executeGrant = {
    param($Ticket)
    $ticketId = [string]$Ticket.TicketId

    # Claim atomically BEFORE any slow work (Azure calls, ME calls): Request-
    # ProcessedTicketClaim is a single atomic filesystem create, so exactly one caller --
    # this poller process or the dashboard API's own grant path -- can ever win a given
    # ticket id. Losing the race is a normal outcome (someone else is already handling
    # it), not an error, and nothing slow or external runs before this returns.
    $claimEntry = [pscustomobject]@{
        ticketId  = $ticketId
        actor     = 'poller'
        status    = 'claimed'
        claimedAt = [datetime]::UtcNow.ToString('o')
    }
    if (-not (Request-ProcessedTicketClaim -MeTicketId $ticketId -Entry $claimEntry)) {
        return @{ ok = $false; error = 'Another process already claimed this ticket; not granting.' }
    }

    # From here on, a failure does NOT release the claim. Deleting it on failure would
    # let the very next cycle retry the same ticket -- and re-attempting a grant that
    # failed for a transient reason (a token blip, a throttled Graph call) is exactly the
    # duplicate-grant risk this claim exists to prevent. Instead the same claimed record
    # is overwritten with the failure so an operator can see it happened and re-run by
    # hand once the underlying problem is understood.
    try {
        $client = New-RealGraphPimClient -TenantId $env:AZURE_TENANT_ID `
            -ClientId $env:AZURE_CLIENT_ID -ClientSecret $env:AZURE_CLIENT_SECRET
        $userId = Resolve-RealUpnToObjectId -Client $client -Upn ([string]$Ticket.RequesterUpn)

        # Re-check duplicates against Azure, not local state. Local dedup is an
        # optimization; Azure is truth, and another operator may have granted this
        # between cycles.
        $roleId = Get-RealRoleDefinitionId -RoleName ([string]$Ticket.Role)
        $existing = Get-RealActiveAssignments -Client $client -UserId $userId `
            -RoleDefinitionId $roleId -Scope ([string]$Ticket.ResourceScope)
        if (@($existing).Count -gt 0) {
            $err = 'Active assignment already exists in Azure for this user, role and scope.'
            Save-ProcessedTicket -MeTicketId $ticketId -Entry ([pscustomobject]@{
                    ticketId = $ticketId; actor = 'poller'; status = 'failed'; error = $err
                    claimedAt = $claimEntry.claimedAt; failedAt = [datetime]::UtcNow.ToString('o')
                })
            return @{ ok = $false; error = $err }
        }

        # C1: the check above only sees direct user->role->scope assignments. Normal
        # fulfilment for everything this poller may grant is via an Entra group, which
        # is invisible to it -- see Invoke-RealGroupDuplicateCheck above. Caught here,
        # not treated as a Failed/Stopped outcome: an existing group membership is not a
        # system error, and halting later tickets in this cycle over it would defeat the
        # point of catching it. 'duplicate' on the return tells the caller to queue this
        # ticket for a human instead.
        $groupDup = Invoke-RealGroupDuplicateCheck -Client $client -UserId $userId -RoleName ([string]$Ticket.Role) `
            -SubscriptionId ([string]$Ticket.SubscriptionId) -SubscriptionName ([string]$Ticket.SubscriptionName) `
            -ResourceScope ([string]$Ticket.ResourceScope)
        if ($groupDup.Duplicate) {
            $err = [string]$groupDup.Reason
            Save-ProcessedTicket -MeTicketId $ticketId -Entry ([pscustomobject]@{
                    ticketId = $ticketId; actor = 'poller'; status = 'duplicate'; error = $err
                    claimedAt = $claimEntry.claimedAt; failedAt = [datetime]::UtcNow.ToString('o')
                    groupId = $groupDup.GroupId; groupName = $groupDup.GroupName
                })
            return @{ ok = $false; duplicate = $true; error = $err }
        }

        $grant = Invoke-RealGroupOrPimGrant -Client $client -UserId $userId -RoleName ([string]$Ticket.Role) `
            -SubscriptionId ([string]$Ticket.SubscriptionId) -SubscriptionName ([string]$Ticket.SubscriptionName) `
            -ResourceScope ([string]$Ticket.ResourceScope) -DurationDays ([int]$Ticket.DurationDays) `
            -Justification ([string]$Ticket.Justification)

        if (-not $grant.Success) {
            $err = "Grant failed: $($grant.EngineerActionReason)"
            Save-ProcessedTicket -MeTicketId $ticketId -Entry ([pscustomobject]@{
                    ticketId = $ticketId; actor = 'poller'; status = 'failed'; error = $err
                    claimedAt = $claimEntry.claimedAt; failedAt = [datetime]::UtcNow.ToString('o')
                })
            return @{ ok = $false; error = $err }
        }

        # Write the COMPLETE record here, on success, exactly like the failure paths above
        # already do -- not a partial one left for a later step to fill in. Fulfilment
        # 'Group' (the normal path for Reader/Contributor, i.e. everything this poller is
        # permitted to grant) leaves AssignmentId $null; Test-GrantRevocable only accepts
        # that shape when groupId is ALSO present. Before this fix only assignmentId and
        # fulfilment made it into the store, so every poller-granted group access failed
        # Test-GrantRevocable and clicking Revoke in the dashboard 404'd -- the person kept
        # the Azure privilege with no rollback, for exactly the grants that had no human in
        # the loop. environment is included too: Test-AccessPromotionLadder (C3) filters
        # prior grants on it, so a poller-granted Sandbox record must carry it for a later
        # human NonProd request on the same requester+role to see it and pass the ladder.
        # Get-GrantExpiryTimestamp (DashboardHelpers.ps1): both fulfilment paths now
        # record an expiry. For PimFallback it is Azure-ENFORCED (the assignment itself
        # times out). For Group it is a TRACKED expiry only -- Entra group membership has
        # no native timer -- enforced solely by the reaper agent
        # (src/Agents/ReaperAgent.ps1 / scripts/Invoke-ReaperCycle.ps1), not by Azure.
        # Before this, the Group path recorded $null here and every unattended group
        # grant was permanent until a human noticed. See that function's own comment for
        # the full safety-case reasoning.
        $expiresAt = Get-GrantExpiryTimestamp -DurationDays ([int]$Ticket.DurationDays)
        Save-ProcessedTicket -MeTicketId $ticketId -Entry ([pscustomobject]@{
                ticketId       = $ticketId
                action         = 'Grant'
                role           = [string]$Ticket.Role
                environment    = [string]$Ticket.Environment
                subscriptionId = [string]$Ticket.SubscriptionId
                requesterUpn   = [string]$Ticket.RequesterUpn
                assignmentId   = [string]$grant.AssignmentId
                fulfilment     = [string]$grant.Fulfilment
                groupId        = $grant.GroupId
                groupName      = $grant.GroupName
                expiresAt      = $expiresAt
                runId          = $runId
                actor          = 'poller'
                claimedAt      = $claimEntry.claimedAt
                processedAt    = [datetime]::UtcNow.ToString('o')
                revoked        = $false
            })
        return @{
            ok           = $true
            assignmentId = [string]$grant.AssignmentId
            fulfilment   = [string]$grant.Fulfilment
            groupId      = $grant.GroupId
            # Surfaced up to the entry TicketPollerAgent.ps1 builds so the audit event
            # written below carries the SAME expiry that was just persisted, rather than
            # a value recomputed a moment later against a slightly different "now".
            expiresAt    = $expiresAt
        }
    }
    catch {
        $err = "Grant threw: $($_.Exception.Message)"
        Save-ProcessedTicket -MeTicketId $ticketId -Entry ([pscustomobject]@{
                ticketId = $ticketId; actor = 'poller'; status = 'failed'; error = $err
                claimedAt = $claimEntry.claimedAt; failedAt = [datetime]::UtcNow.ToString('o')
            })
        return @{ ok = $false; error = $err }
    }
}

# Read once per cycle, not once per ticket. Get-ProcessedTickets re-parses every file in
# the store directory, and a file transiently locked by a concurrent claim (the dashboard
# claiming a ticket at the same moment) emits its own Write-Warning -- multiplied across
# every ticket IsProcessed is asked about in a cycle, that is journal spam proportional to
# MaxTicketsPerCycle on a perfectly normal overlap, not an actual problem. Nothing in this
# process can add a new entry mid-cycle before ExecuteGrant runs (which checks Azure
# directly for duplicates, not this set), so one read up front is both correct and cheap.
$processedIds = [System.Collections.Generic.HashSet[string]]::new(
    [string[]]@((Get-ProcessedTickets).Keys), [System.StringComparer]::Ordinal)

$context = @{
    FetchTickets         = $fetchTickets
    GetAccessFields      = $getAccessFields
    FetchTicketDetail    = $fetchTicketDetail
    IsTemplateAllowed    = $isTemplateAllowed
    Decide               = $decide
    AllowlistDetails     = $allowlistDetails
    ExecuteGrant         = $executeGrant
    CheckPromotionLadder = $checkPromotionLadder
    PostTicketNote       = $postTicketNote
    ResolveTicket        = $resolveTicket
    IsProcessed          = { param($Id) $processedIds.Contains([string]$Id) }
    RecordProcessed      = {
        param($Id, $Entry)
        # ExecuteGrant already wrote the complete record on success (assignmentId,
        # fulfilment, groupId, environment, ...) directly via Save-ProcessedTicket, before
        # this ever runs (see the C2 fix above). This call supplies only the fields the
        # CYCLE itself knows (runId, actor, processedAt) via the sparse entry
        # TicketPollerAgent.ps1 builds -- merge those onto whatever ExecuteGrant already
        # persisted rather than overwrite it, or this call would silently discard exactly
        # the fields C2 exists to keep (groupId, fulfilment, environment, ...) with a
        # smaller, unrevocable record.
        $existing = $null
        try { $existing = (Get-ProcessedTickets)[[string]$Id] } catch { $existing = $null }
        $merged = [ordered]@{}
        if ($existing) {
            $existing.PSObject.Properties | ForEach-Object { $merged[$_.Name] = $_.Value }
        }
        if ($Entry) {
            $Entry.PSObject.Properties | ForEach-Object {
                if ($null -ne $_.Value -and "$($_.Value)" -ne '') { $merged[$_.Name] = $_.Value }
            }
        }
        Save-ProcessedTicket -MeTicketId ([string]$Id) -Entry $merged
    }
    Config               = $config
    RunId                = $runId
    # I1: derived from config.azure.defaultDurationHours, same as the dashboard's human
    # path, rather than a hardcoded value. See $pollerDurationDays above.
    DurationDays         = $pollerDurationDays
    Now                  = [datetime]::UtcNow
}

$result = Invoke-TicketPollerCycle -Context $context

# Audit every cycle, including shadow, so the unattended path is never a black box.
if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
    # Write-AuditEvent's -Outcome is a closed ValidateSet (Success/Failed/Blocked/DryRun/
    # Started) -- it does not include this cycle's own outcome vocabulary (Granted/
    # WouldGrant/Queued/Failed), and passing an unmapped value straight through would
    # throw at parameter binding, before the function's own "never throw" guarantee even
    # applies, taking the whole cycle down after the grant already happened. Map instead.
    $auditOutcomeMap = @{
        Granted    = 'Success'
        Failed     = 'Failed'
        WouldGrant = 'DryRun'
        Queued     = 'Blocked'
    }
    foreach ($entry in $result.Entries) {
        $outcomeRaw = [string]$entry.outcome
        $auditOutcome = if ($auditOutcomeMap.ContainsKey($outcomeRaw)) { $auditOutcomeMap[$outcomeRaw] } else { 'Blocked' }

        # -Detail is typed [hashtable]; $entry is the pscustomobject Invoke-TicketPollerCycle
        # built. A pscustomobject does not bind to [hashtable] -- passing it directly throws.
        $detail = @{}
        $entry.PSObject.Properties | ForEach-Object { $detail[$_.Name] = $_.Value }

        # Only a Granted entry carries a fulfilment (WouldGrant/Queued/Failed never
        # executed a grant). Get-GrantExpiryEnforcement (DashboardHelpers.ps1) names
        # which expiry kind this is -- Azure-enforced or tracked-only -- so an auditor
        # reading this event does not have to already know the PimFallback/Group mapping.
        if ($detail.ContainsKey('fulfilment') -and $detail.fulfilment) {
            $detail.expiryEnforcement = Get-GrantExpiryEnforcement -Fulfilment ([string]$detail.fulfilment)
        }

        Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'UnattendedGrant' -Actor 'poller' `
            -RunId $result.RunId -TicketId ([string]$entry.ticketId) `
            -Outcome $auditOutcome -Detail $detail -IsWrite:($outcomeRaw -eq 'Granted')
    }
}

($result | ConvertTo-Json -Depth 8) | Set-Content -Path $statusFile -Encoding UTF8

$summary = "[poller] run=$($result.RunId) mode=$($result.Mode) examined=$($result.Examined) wouldGrant=$($result.WouldGrant) granted=$($result.Granted) queued=$($result.Queued) failed=$($result.Failed)"
if ($result.Halted) { $summary += " HALTED: $($result.HaltReason)" }
if ($result.Stopped) { $summary += ' STOPPED (fail-closed)' }
Write-Output $summary

if ($VerboseOutput) { $result.Entries | Format-Table ticketId, outcome, reason -AutoSize | Out-String | Write-Output }

# Non-zero exit on a failed cycle so systemctl status / journalctl show the failure.
if ($result.Failed -gt 0) { exit 1 }
exit 0
