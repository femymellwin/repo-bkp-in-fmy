<#
.SYNOPSIS
  Dump ManageEngine "Azure Subscription" template fields from the live API:
  Subscription, Azure Role, Environment.

.DESCRIPTION
  Standalone probe (not the dashboard UI). Loads MANAGE_ENGINE_* from repo .env
  and prints the raw UDF payloads so you can see exact shapes (string vs {name,id}).

.PARAMETER RequestId
  Ticket id to fetch. If omitted, lists recent tickets and shows which have the fields.

.PARAMETER RowCount
  How many recent tickets to scan when RequestId is omitted (default 25).

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Get-MeAccessFields.ps1

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Get-MeAccessFields.ps1 -RequestId 4160
#>
[CmdletBinding()]
param(
    [string]$RequestId,
    [int]$RowCount = 25
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$repoRoot = Split-Path $PSScriptRoot -Parent
$envFile = Join-Path $repoRoot '.env'
$configPath = Join-Path $repoRoot 'dashboard\api\config.json'

function Import-DotEnv {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return }
    Get-Content $Path | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            $val = $Matches[2].Trim()
            if (($val.StartsWith('"') -and $val.EndsWith('"')) -or
                ($val.StartsWith("'") -and $val.EndsWith("'"))) {
                $val = $val.Substring(1, $val.Length - 2)
            }
            [Environment]::SetEnvironmentVariable($Matches[1], $val, 'Process')
        }
    }
}

function Get-UdfDisplay {
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [string] -or $Value -is [ValueType]) { return [string]$Value }
    $obj = [ordered]@{}
    foreach ($p in $Value.PSObject.Properties) {
        $obj[$p.Name] = $p.Value
    }
    return $obj
}

Import-DotEnv -Path $envFile

$meBase = $env:MANAGE_ENGINE_BASE_URL
if (-not $meBase) { $meBase = $env:MANAGE_ENGINE_URL }
$meKey = $env:MANAGE_ENGINE_API_KEY
if (-not $meBase -or -not $meKey) {
    throw 'Set MANAGE_ENGINE_BASE_URL (or MANAGE_ENGINE_URL) and MANAGE_ENGINE_API_KEY in .env'
}
$meBase = $meBase.TrimEnd('/')

# Field keys: config.json overrides, else known Azure Subscription template defaults.
$fieldKeys = [ordered]@{
    Subscription = 'udf_pick_3728'
    AzureRole    = 'udf_pick_3729'
    Environment  = 'udf_pick_3719'
}
if (Test-Path $configPath) {
    $cfg = Get-Content $configPath -Raw | ConvertFrom-Json
    $u = $cfg.manageEngine.udfFields
    if ($u) {
        if ($u.subscription) { $fieldKeys.Subscription = [string]$u.subscription }
        if ($u.azureRole) { $fieldKeys.AzureRole = [string]$u.azureRole }
        if ($u.environment) { $fieldKeys.Environment = [string]$u.environment }
    }
}

$headers = @{
    authtoken      = $meKey
    'Content-Type' = 'application/json'
}

Write-Host ''
Write-Host 'ManageEngine access-field probe' -ForegroundColor Cyan
Write-Host "  Base URL : $meBase"
Write-Host "  Field keys:"
foreach ($k in $fieldKeys.Keys) {
    Write-Host ("    {0,-22} {1}" -f $k, $fieldKeys[$k])
}
Write-Host ''

function Show-TicketAccessFields {
    param([Parameter(Mandatory)][string]$Id)

    $url = "$meBase/api/v3/requests/$Id"
    Write-Host "GET $url" -ForegroundColor DarkGray
    $resp = Invoke-RestMethod -Uri $url -Method Get -Headers $headers
    $req = $resp.request
    if (-not $req) { throw "No request object in response for id $Id" }

    $udf = $req.udf_fields
    $extracted = [ordered]@{}
    $raw = [ordered]@{}
    foreach ($label in $fieldKeys.Keys) {
        $key = $fieldKeys[$label]
        $val = $null
        if ($udf -and $udf.PSObject.Properties.Name -contains $key) {
            $val = $udf.$key
        }
        $raw[$label] = @{
            key   = $key
            value = (Get-UdfDisplay $val)
        }
        # Human-readable pick
        $display = ''
        if ($null -eq $val) { $display = '' }
        elseif ($val -is [string] -or $val -is [ValueType]) { $display = [string]$val }
        elseif ($val.PSObject.Properties.Name -contains 'name' -and $val.name) { $display = [string]$val.name }
        elseif ($val.PSObject.Properties.Name -contains 'value' -and $val.value) { $display = [string]$val.value }
        elseif ($val.PSObject.Properties.Name -contains 'display_value' -and $val.display_value) { $display = [string]$val.display_value }
        else { $display = ($val | ConvertTo-Json -Compress -Depth 5) }
        $extracted[$label] = $display
    }

    Write-Host ''
    Write-Host ("Ticket #{0}  subject: {1}" -f $req.id, $req.subject) -ForegroundColor Green
    if ($req.template) {
        Write-Host ("  template: {0}" -f ($(if ($req.template.name) { $req.template.name } else { $req.template | ConvertTo-Json -Compress })))
    }
    Write-Host ''
    Write-Host 'Extracted (what the app maps from):' -ForegroundColor Yellow
    $extracted.GetEnumerator() | ForEach-Object {
        $shown = if ([string]::IsNullOrWhiteSpace([string]$_.Value)) { '(empty)' } else { $_.Value }
        Write-Host ("  {0,-22} {1}" -f $_.Key, $shown)
    }

    Write-Host ''
    Write-Host 'Raw UDF payloads for the three keys:' -ForegroundColor Yellow
    $raw | ConvertTo-Json -Depth 8

    Write-Host ''
    Write-Host 'Full udf_fields (all keys on this ticket):' -ForegroundColor Yellow
    if ($udf) {
        $udf | ConvertTo-Json -Depth 8
    } else {
        Write-Host '  (udf_fields missing on this response)'
    }

    Write-Host ''
    Write-Host 'Full request JSON (truncated-friendly: write to file if huge):' -ForegroundColor DarkGray
    $outFile = Join-Path $env:TEMP "me-request-$Id.json"
    ($resp | ConvertTo-Json -Depth 12) | Set-Content -Path $outFile -Encoding UTF8
    Write-Host "  Saved full response → $outFile"
}

if ($RequestId) {
    Show-TicketAccessFields -Id $RequestId
    return
}

# List recent tickets and summarize the three fields from DETAIL (list often omits UDF values).
$fields = '"id","subject","status","group","created_time","template","udf_fields"'
$inputData = '{"list_info":{"row_count":' + $RowCount + ',"start_index":1,"sort_field":"created_time","sort_order":"desc","fields_required":[' + $fields + ']}}'
$listUrl = "$meBase/api/v3/requests?input_data=$([uri]::EscapeDataString($inputData))"
Write-Host "GET $meBase/api/v3/requests  (row_count=$RowCount, newest first)" -ForegroundColor DarkGray

try {
    $list = Invoke-RestMethod -Uri $listUrl -Method Get -Headers $headers
} catch {
    Write-Warning "List with sort failed ($($_.Exception.Message)); retrying without sort…"
    $inputData = '{"list_info":{"row_count":' + $RowCount + ',"start_index":1,"fields_required":[' + $fields + ']}}'
    $listUrl = "$meBase/api/v3/requests?input_data=$([uri]::EscapeDataString($inputData))"
    $list = Invoke-RestMethod -Uri $listUrl -Method Get -Headers $headers
}

$reqs = @($list.requests)
Write-Host ("List returned {0} ticket(s). Fetching detail for each to read UDF values…" -f $reqs.Count)
Write-Host ''

$rows = foreach ($r in $reqs) {
    $id = [string]$r.id
    Start-Sleep -Milliseconds 200  # light throttle — SDP rate-limits aggressively
    try {
        $detail = Invoke-RestMethod -Uri "$meBase/api/v3/requests/$id" -Method Get -Headers $headers
        $udf = $detail.request.udf_fields
        $get = {
            param($key)
            if (-not $udf -or $udf.PSObject.Properties.Name -notcontains $key) { return '' }
            $v = $udf.$key
            if ($null -eq $v) { return '' }
            if ($v -is [string] -or $v -is [ValueType]) { return [string]$v }
            if ($v.name) { return [string]$v.name }
            if ($v.value) { return [string]$v.value }
            if ($v.display_value) { return [string]$v.display_value }
            return ($v | ConvertTo-Json -Compress)
        }
        [pscustomobject]@{
            Id                     = $id
            Subject                = $detail.request.subject
            Template               = $(if ($detail.request.template.name) { $detail.request.template.name } else { '' })
            Subscription           = & $get $fieldKeys.Subscription
            AzureRole              = & $get $fieldKeys.AzureRole
            Environment            = & $get $fieldKeys.Environment
        }
    } catch {
        [pscustomobject]@{
            Id                     = $id
            Subject                = $r.subject
            Template               = ''
            Subscription           = "ERROR: $($_.Exception.Message)"
            AzureRole              = ''
            Environment            = ''
        }
    }
}

$rows | Format-Table -AutoSize Id, Subscription, AzureRole, Environment, Template, Subject

Write-Host ''
Write-Host 'Tip: dump one ticket in full with:' -ForegroundColor Cyan
Write-Host "  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Get-MeAccessFields.ps1 -RequestId <id>"
Write-Host ''
