$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent

$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            [System.Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], 'Process')
        }
    }
}

$subId     = if ($env:AZURE_SUBSCRIPTION_ID) { $env:AZURE_SUBSCRIPTION_ID } else { '5a23842e-609d-42d4-bae5-e48e00e5b28d' }
$meBaseUrl = if ($env:MANAGE_ENGINE_URL) { $env:MANAGE_ENGINE_URL } else { $env:MANAGE_ENGINE_BASE_URL }
$meApiKey  = $env:MANAGE_ENGINE_API_KEY

function Test-Endpoint {
    param([string]$Name, [string]$Method, [string]$Url, [hashtable]$Headers, [string]$Body, [string]$Scope)
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = $Method
        $req.Accept = 'application/json'
        foreach ($k in $Headers.Keys) {
            if ($k -eq 'Content-Type') { $req.ContentType = $Headers[$k]; continue }
            $req.Headers.Add($k, $Headers[$k])
        }
        if (-not $Headers.ContainsKey('Content-Type')) { $req.ContentType = 'application/json' }
        if ($Body) {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
            $req.ContentLength = $bytes.Length
            $s = $req.GetRequestStream(); $s.Write($bytes, 0, $bytes.Length); $s.Close()
        }
        $resp = $req.GetResponse()
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $null = $reader.ReadToEnd(); $resp.Close()
        return @{ Name=$Name; Ok=$true; Http=200; Error=$null; Scope=$Scope }
    }
    catch [System.Net.WebException] {
        $resp = $_.Exception.Response
        $http = [int]$resp.StatusCode
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $errBody = $reader.ReadToEnd(); $resp.Close()
        $msg = $null
        try {
            $p = $errBody | ConvertFrom-Json
            $msg = $p.error.message
            try { $inner = $msg | ConvertFrom-Json; if ($inner.message) { $msg = $inner.message } } catch {}
        } catch { $msg = $errBody.Substring(0, [math]::Min(200, $errBody.Length)) }
        $ok = ($http -eq 400 -or $http -eq 404) -and ($Name -like '*dry-run*')
        return @{ Name=$Name; Ok=$ok; Http=$http; Error=$msg; Scope=$Scope }
    }
}

Write-Host ''
Write-Host 'AzureSentry - API Access Check' -ForegroundColor Cyan
Write-Host '===============================' -ForegroundColor Cyan

$acct = az account show -o json 2>&1 | ConvertFrom-Json
Write-Host "Identity: $($acct.user.name)  |  Subscription: $($acct.name)  |  Tenant: $($acct.tenantId)"
$upn = $acct.user.name

$graphToken = az account get-access-token --resource https://graph.microsoft.com --query accessToken -o tsv 2>&1
$mgmtToken  = az account get-access-token --resource https://management.azure.com --query accessToken -o tsv 2>&1
$g = @{ Authorization = "Bearer $graphToken" }
$m = @{ Authorization = "Bearer $mgmtToken" }

$dryAssign = @{ action='adminAssign'; roleDefinitionId='acdd72a7-3385-48ef-bd42-f606fba81ae7'; principalId='00000000-0000-0000-0000-000000000000'; directoryScopeId='/'; scheduleInfo=@{ startDateTime=(Get-Date).ToUniversalTime().ToString('o'); expiration=@{ type='afterDuration'; duration='PT1H' } }; justification='diagnostic dry-run' } | ConvertTo-Json -Depth 5
$dryElig   = @{ action='adminAssign'; roleDefinitionId='acdd72a7-3385-48ef-bd42-f606fba81ae7'; principalId='00000000-0000-0000-0000-000000000000'; directoryScopeId='/'; scheduleInfo=@{ startDateTime=(Get-Date).ToUniversalTime().ToString('o'); expiration=@{ type='afterDuration'; duration='P7D' } }; justification='diagnostic dry-run' } | ConvertTo-Json -Depth 5

$tests = @(
    (Test-Endpoint -Name 'User.Read.All (resolve UPN)' -Method GET -Url "https://graph.microsoft.com/v1.0/users/${upn}?`$select=id,displayName" -Headers $g -Scope 'User.Read.All')
    (Test-Endpoint -Name 'PIM Read assignments' -Method GET -Url "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignmentScheduleInstances?`$top=1" -Headers $g -Scope 'RoleManagement.Read.Directory')
    (Test-Endpoint -Name 'PIM Read eligibility' -Method GET -Url "https://graph.microsoft.com/v1.0/roleManagement/directory/roleEligibilityScheduleInstances?`$top=1" -Headers $g -Scope 'RoleManagement.Read.Directory')
    (Test-Endpoint -Name 'PIM Write assignment (dry-run)' -Method POST -Url 'https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignmentScheduleRequests' -Headers $g -Body $dryAssign -Scope 'RoleManagement.ReadWrite.Directory')
    (Test-Endpoint -Name 'PIM Write eligibility (dry-run)' -Method POST -Url 'https://graph.microsoft.com/v1.0/roleManagement/directory/roleEligibilityScheduleRequests' -Headers $g -Body $dryElig -Scope 'RoleManagement.ReadWrite.Directory')
    (Test-Endpoint -Name 'Subscription Reader' -Method GET -Url "https://management.azure.com/subscriptions/${subId}?api-version=2022-12-01" -Headers $m -Scope 'Reader on subscription')
)

if ($meBaseUrl -and $meApiKey) {
    $meUrl = "$($meBaseUrl.TrimEnd('/'))/api/v3/requests?input_data=$([System.Uri]::EscapeDataString('{"list_info":{"row_count":1}}'))"
    $tests += (Test-Endpoint -Name 'ManageEngine Read tickets' -Method GET -Url $meUrl -Headers @{ authtoken=$meApiKey } -Scope 'ServiceDesk API token')
    $meNoteUrl = "$($meBaseUrl.TrimEnd('/'))/api/v3/requests/2858/notes"
    $noteJson = @{ note=@{ description='API diagnostic test'; show_to_requester=$false; notify_technician=$false } } | ConvertTo-Json -Depth 5 -Compress
    $formBody = "input_data=$([System.Uri]::EscapeDataString($noteJson))"
    $tests += (Test-Endpoint -Name 'ManageEngine Write notes' -Method POST -Url $meNoteUrl -Headers @{ authtoken=$meApiKey; 'Content-Type'='application/x-www-form-urlencoded' } -Body $formBody -Scope 'ServiceDesk API token')
}

Write-Host ''
$pass = 0; $fail = 0
foreach ($t in $tests) {
    if ($t.Ok) {
        $pass++
        Write-Host "  PASS    $($t.Name)" -ForegroundColor Green
    } else {
        $fail++
        Write-Host "  BLOCKED $($t.Name)" -ForegroundColor Red
        Write-Host "          Scope: $($t.Scope)  |  HTTP $($t.Http)" -ForegroundColor Yellow
        Write-Host "          $($t.Error)" -ForegroundColor DarkGray
    }
}

Write-Host ''
Write-Host "Result: $pass PASS / $fail BLOCKED" -ForegroundColor $(if ($fail -gt 0) { 'Yellow' } else { 'Green' })

if ($fail -gt 0) {
    Write-Host ''
    Write-Host 'ACTION REQUIRED - Global Admin must grant admin consent for:' -ForegroundColor Red
    Write-Host '  1. RoleManagement.ReadWrite.Directory' -ForegroundColor White
    Write-Host '  2. User.Read.All' -ForegroundColor White
    Write-Host ''
}
