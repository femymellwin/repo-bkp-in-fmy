<#
.SYNOPSIS
    Verifies whether the AzureSentry automation service principal (SPN) actually
    holds the Graph + ARM permissions required for REAL ticket processing.

.DESCRIPTION
    Authenticates AS THE SPN using the OAuth2 client-credentials flow (no Azure CLI,
    no Graph SDK - works on Windows PowerShell 5.1) and probes every endpoint the
    ticket-processing path calls. Read checks pass only on HTTP 200. Write checks are
    non-destructive "dry-runs": a dummy request that is expected to be rejected with
    400/404 (payload reached authorization and was validated) counts as PASS; 401/403
    counts as BLOCKED. UAA is verified by READING the SPN's own role assignments on the
    subscription - nothing is ever created.

    Reads credentials from the gitignored .env:
        AZURE_TENANT_ID, AZURE_CLIENT_ID, AZURE_CLIENT_SECRET, AZURE_SUBSCRIPTION_ID
#>
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$repoRoot = Split-Path $PSScriptRoot -Parent
$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            [System.Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], 'Process')
        }
    }
}

$tenantId = $env:AZURE_TENANT_ID
$clientId = $env:AZURE_CLIENT_ID
$secret   = $env:AZURE_CLIENT_SECRET
$subId    = if ($env:AZURE_SUBSCRIPTION_ID) { $env:AZURE_SUBSCRIPTION_ID } else { '5a23842e-609d-42d4-bae5-e48e00e5b28d' }

$missing = @()
if (-not $tenantId) { $missing += 'AZURE_TENANT_ID' }
if (-not $clientId) { $missing += 'AZURE_CLIENT_ID' }
if (-not $secret)   { $missing += 'AZURE_CLIENT_SECRET' }
if ($missing.Count -gt 0) {
    Write-Host ''
    Write-Host 'Missing SPN credentials in .env:' -ForegroundColor Red
    $missing | ForEach-Object { Write-Host "  - $_" -ForegroundColor White }
    Write-Host ''
    Write-Host 'Add these lines to .env (gitignored - never committed):' -ForegroundColor Yellow
    Write-Host '  AZURE_TENANT_ID=<tenant guid>' -ForegroundColor DarkGray
    Write-Host '  AZURE_CLIENT_ID=<app/client id>' -ForegroundColor DarkGray
    Write-Host '  AZURE_CLIENT_SECRET=<client secret value>' -ForegroundColor DarkGray
    Write-Host ''
    exit 1
}

function Get-SpnToken {
    param([string]$TenantId, [string]$ClientId, [string]$Secret, [string]$Resource)
    $body = @{
        grant_type    = 'client_credentials'
        client_id     = $ClientId
        client_secret = $Secret
        scope         = "$Resource/.default"
    }
    $uri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
    $resp = Invoke-RestMethod -Method Post -Uri $uri -Body $body -ContentType 'application/x-www-form-urlencoded'
    return $resp.access_token
}

function Get-JwtClaim {
    param([string]$Token, [string]$Claim)
    try {
        $payload = $Token.Split('.')[1].Replace('-', '+').Replace('_', '/')
        switch ($payload.Length % 4) { 2 { $payload += '==' } 3 { $payload += '=' } }
        $json = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($payload))
        return ($json | ConvertFrom-Json).$Claim
    } catch { return $null }
}

function Test-Endpoint {
    param([string]$Name, [string]$Method, [string]$Url, [hashtable]$Headers, [string]$Body, [string]$Perm)
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = $Method
        $req.Accept = 'application/json'
        foreach ($k in $Headers.Keys) {
            if ($k -eq 'Content-Type') { $req.ContentType = $Headers[$k]; continue }
            $req.Headers.Add($k, $Headers[$k])
        }
        if (-not $Headers.ContainsKey('Content-Type')) { $req.ContentType = 'application/json' }
        if ($Body) {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
            $req.ContentLength = $bytes.Length
            $s = $req.GetRequestStream(); $s.Write($bytes, 0, $bytes.Length); $s.Close()
        }
        $resp = $req.GetResponse()
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $null = $reader.ReadToEnd(); $resp.Close()
        return @{ Name=$Name; Ok=$true; Http=200; Error=$null; Perm=$Perm }
    }
    catch [System.Net.WebException] {
        $resp = $_.Exception.Response
        if (-not $resp) { return @{ Name=$Name; Ok=$false; Http=0; Error=$_.Exception.Message; Perm=$Perm } }
        $http = [int]$resp.StatusCode
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $errBody = $reader.ReadToEnd(); $resp.Close()
        $msg = $null
        try {
            $p = $errBody | ConvertFrom-Json
            $msg = $p.error.message
            try { $inner = $msg | ConvertFrom-Json; if ($inner.message) { $msg = $inner.message } } catch {}
        } catch { $msg = $errBody.Substring(0, [math]::Min(240, $errBody.Length)) }
        # Dry-run writes: reaching validation (400/404) means the permission IS present.
        $ok = ($http -eq 400 -or $http -eq 404) -and ($Name -like '*dry-run*')
        return @{ Name=$Name; Ok=$ok; Http=$http; Error=$msg; Perm=$Perm }
    }
}

Write-Host ''
Write-Host 'AzureSentry - SPN (application) Access Check' -ForegroundColor Cyan
Write-Host '============================================' -ForegroundColor Cyan
Write-Host "Client (app) id : $clientId"
Write-Host "Tenant          : $tenantId"
Write-Host "Subscription    : $subId"

# --- Acquire tokens as the SPN ---
try {
    $graphToken = Get-SpnToken -TenantId $tenantId -ClientId $clientId -Secret $secret -Resource 'https://graph.microsoft.com'
} catch {
    Write-Host ''
    Write-Host 'FAILED to acquire a Microsoft Graph token as the SPN.' -ForegroundColor Red
    Write-Host "  $($_.Exception.Message)" -ForegroundColor DarkGray
    Write-Host '  -> Check AZURE_CLIENT_ID / AZURE_CLIENT_SECRET / AZURE_TENANT_ID.' -ForegroundColor Yellow
    exit 1
}
try {
    $mgmtToken = Get-SpnToken -TenantId $tenantId -ClientId $clientId -Secret $secret -Resource 'https://management.azure.com'
} catch {
    $mgmtToken = $null
    Write-Host 'WARN: could not acquire an ARM token (subscription checks will be skipped).' -ForegroundColor Yellow
}

$spnOid = Get-JwtClaim -Token $graphToken -Claim 'oid'
if ($spnOid) { Write-Host "SPN object id   : $spnOid" }

$g = @{ Authorization = "Bearer $graphToken" }
$m = @{ Authorization = "Bearer $mgmtToken" }

$scope = "/subscriptions/$subId"
$dummyPrincipal = '00000000-0000-0000-0000-000000000000'
$contributorRoleId = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
$armVer = '2020-10-01'

# ARM PIM dry-run body: valid request but a non-existent principal. If the SPN is
# authorized, ARM validates and rejects with 400 SubjectNotFound (nothing created);
# 401/403 means the SPN lacks write. This is the REAL path used for subscription grants
# (Azure resource roles are ARM, not Microsoft Graph).
$dryArm = @{
    properties = @{
        principalId      = $dummyPrincipal
        roleDefinitionId = "$scope/providers/Microsoft.Authorization/roleDefinitions/$contributorRoleId"
        requestType      = 'AdminAssign'
        justification    = 'AzureSentry SPN diagnostic dry-run (invalid principal)'
        scheduleInfo     = @{ startDateTime=(Get-Date).ToUniversalTime().ToString('o'); expiration=@{ type='AfterDuration'; duration='P1D' } }
    }
} | ConvertTo-Json -Depth 8

$tests = @(
    (Test-Endpoint -Name 'User.Read.All (list users)' -Method GET `
        -Url 'https://graph.microsoft.com/v1.0/users?$top=1' -Headers $g -Perm 'User.Read.All (Graph app)')
)

if ($mgmtToken) {
    $tests += (Test-Endpoint -Name 'Subscription read (Reader)' -Method GET `
        -Url "https://management.azure.com/subscriptions/$subId`?api-version=2022-12-01" -Headers $m -Perm 'Reader on subscription')
    if ($spnOid) {
        $raUrl = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01&`$filter=" + [uri]::EscapeDataString("principalId eq '$spnOid'")
        $tests += (Test-Endpoint -Name 'Read SPN role assignments on subscription' -Method GET -Url $raUrl -Headers $m -Perm 'Microsoft.Authorization/roleAssignments/read')
    }
    $armPimUrl = "https://management.azure.com$scope/providers/Microsoft.Authorization/roleAssignmentScheduleRequests/$([guid]::NewGuid())?api-version=$armVer"
    $tests += (Test-Endpoint -Name 'ARM PIM write assignment (dry-run)' -Method PUT `
        -Url $armPimUrl -Headers $m -Body $dryArm -Perm 'User Access Administrator / Owner on subscription')
}

Write-Host ''
$pass = 0; $fail = 0
foreach ($t in $tests) {
    if ($t.Ok) {
        $pass++
        Write-Host "  PASS    $($t.Name)" -ForegroundColor Green
    } else {
        $fail++
        Write-Host "  BLOCKED $($t.Name)" -ForegroundColor Red
        Write-Host "          Perm: $($t.Perm)  |  HTTP $($t.Http)" -ForegroundColor Yellow
        Write-Host "          $($t.Error)" -ForegroundColor DarkGray
    }
}

# --- UAA determination from the SPN's own role assignments (informational) ---
if ($mgmtToken -and $spnOid) {
    try {
        $raUrl = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01&`$filter=" + [uri]::EscapeDataString("principalId eq '$spnOid'")
        $ra = Invoke-RestMethod -Method Get -Uri $raUrl -Headers $m
        $uaaId   = '18d7d88d-d35e-4fb5-a5c3-7773c20a72d9'
        $ownerId = '8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d'
        $roleIds = @($ra.value | ForEach-Object { ($_.properties.roleDefinitionId -split '/')[-1] })
        $hasUaa   = $roleIds -contains $uaaId
        $hasOwner = $roleIds -contains $ownerId
        Write-Host ''
        Write-Host 'Subscription RBAC held by the SPN:' -ForegroundColor Cyan
        if ($roleIds.Count -eq 0) { Write-Host '  (none found at this scope)' -ForegroundColor DarkGray }
        else { $roleIds | Select-Object -Unique | ForEach-Object { Write-Host "  - roleDefinitionId $_" -ForegroundColor DarkGray } }
        Write-Host ("  User Access Administrator: {0}" -f $(if ($hasUaa) { 'YES' } else { 'no' })) -ForegroundColor $(if ($hasUaa) { 'Green' } else { 'Yellow' })
        Write-Host ("  Owner:                     {0}" -f $(if ($hasOwner) { 'YES' } else { 'no' })) -ForegroundColor $(if ($hasOwner) { 'Green' } else { 'Yellow' })
    } catch {
        Write-Host ''
        Write-Host 'Could not read SPN role assignments (needs at least Reader on the subscription).' -ForegroundColor Yellow
    }
}

Write-Host ''
Write-Host "Result: $pass PASS / $fail BLOCKED" -ForegroundColor $(if ($fail -gt 0) { 'Yellow' } else { 'Green' })
Write-Host ''
if ($fail -eq 0) {
    Write-Host 'SPN has the access needed for real local ticket processing.' -ForegroundColor Green
    Write-Host 'Next: set AZURESENTRY_PIM_CLIENT=Graph and process a ticket.' -ForegroundColor Green
} else {
    Write-Host 'Blocked checks above are the exact permissions still missing on the SPN.' -ForegroundColor Yellow
    Write-Host 'Graph app permissions need Global Admin ADMIN CONSENT; UAA is an RBAC assignment on the subscription.' -ForegroundColor Yellow
}
Write-Host ''
