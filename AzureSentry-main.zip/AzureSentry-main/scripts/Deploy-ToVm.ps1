<#
.SYNOPSIS
  Deploy AzureSentry dashboard package to the existing Linux VM via Azure Run Command
  (no SSH / no storage account required — chunked base64 over the control plane).

.DESCRIPTION
  Target (from docs/vm-access-guide.md):
    vm-incp-uaen-001-sentry / rg-webapps-shared-incp-uaen-001 / inception-marketing

  Prerequisites:
    - az login with rights to start the VM and invoke Run Command
    - PIM Contributor activated on the marketing subscription if eligible-only
    - Local UI built: npm run build in dashboard/web (produces dist/)

.EXAMPLE
  ./scripts/Deploy-ToVm.ps1
#>
[CmdletBinding()]
param(
    [string]$SubscriptionId = 'b2a2ffcd-4eaf-4a65-ab9d-78cb17971147',
    [string]$ResourceGroup = 'rg-webapps-shared-incp-uaen-001',
    [string]$VmName = 'vm-incp-uaen-001-sentry',
    [int]$ChunkSize = 35000,
    [switch]$SkipBuild,
    [switch]$IncludeFonts
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent

function Invoke-VmScript {
    param([string]$ScriptPath, [string]$Expect = $null)
    $raw = az vm run-command invoke `
        -g $ResourceGroup -n $VmName --subscription $SubscriptionId `
        --command-id RunShellScript --scripts "@$ScriptPath" `
        --query 'value[0].message' -o tsv 2>$null
    $msg = if ($null -eq $raw) { '' } else { ($raw | Out-String).Trim() }
    if ($Expect -and ($msg -notlike "*${Expect}*")) {
        throw "Run Command failed expectation '$Expect'. Output: $msg"
    }
    return $msg
}

Write-Host "=== AzureSentry VM deploy ===" -ForegroundColor Cyan
az account set --subscription $SubscriptionId | Out-Null

$power = az vm get-instance-view -g $ResourceGroup -n $VmName --subscription $SubscriptionId `
    --query "instanceView.statuses[?starts_with(code, 'PowerState/')].displayStatus" -o tsv
Write-Host "VM power: $power"
if ($power -notmatch 'running') {
    Write-Host "Starting VM..." -ForegroundColor Yellow
    az vm start -g $ResourceGroup -n $VmName --subscription $SubscriptionId -o none
}

if (-not $SkipBuild) {
    Write-Host "Building UI..." -ForegroundColor Yellow
    Push-Location (Join-Path $repoRoot 'dashboard\web')
    try { npm run build } finally { Pop-Location }
}

$stage = Join-Path $env:TEMP 'azuresentry-slim'
$tar = Join-Path $env:TEMP 'azuresentry-slim.tar.gz'
Remove-Item $stage, $tar -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path @(
    "$stage\dashboard\api",
    "$stage\dashboard\web\dist\assets",
    "$stage\src",
    "$stage\scripts",
    "$stage\infra\systemd"
) | Out-Null

# Exclusions beyond the two runtime-state files: .env / llm.env are developer-local config
# (a developer's .env could silently flip AZURESENTRY_POLLER_ENABLED=true from a file no
# operator ever edited -- the VM's own /etc/azuresentry.env is the only config that should
# govern it); audit-log.jsonl is the VM's tamper-evident hash-chained trail, so shipping a
# developer's local chain over it would overwrite production audit history on every
# deploy; poller-status.json / poller.stop / poller.mode / processed-tickets.json.migrated-*
# are all runtime state the VM generates for itself, not something a deploy should ever
# ship. poller.mode specifically: it is the dashboard's Enforce Mode toggle
# (POST/DELETE /api/poller/mode) -- shipping over it (or worse, deleting it because it
# is absent from the workstation) would silently clear or overwrite an operator's live
# enforce/shadow override on every redeploy. The same applies to poller.enabled/reaper.enabled (the automation on/off override) and poller.caps.json/reaper.caps.json (the per-cycle-limit overrides) added in this feature -- all four are live operator state, never a deploy artifact.
robocopy (Join-Path $repoRoot 'dashboard\api') "$stage\dashboard\api" /E /NFL /NDL /NJH /NJS /nc /ns /np `
    /XF processed-tickets.json activity-log.json .env llm.env audit-log.jsonl audit-log-poller.jsonl `
        audit-log-reaper.jsonl poller-status.json poller.stop poller.mode poller.enabled poller.caps.json `
        reaper-status.json reaper.stop reaper.mode reaper.enabled reaper.caps.json processed-tickets.json.migrated-* `
    /XD processed-tickets | Out-Null
robocopy (Join-Path $repoRoot 'src') "$stage\src" /E /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
# The unattended poller runs from /opt/azuresentry/scripts via a systemd timer, so the
# entry script and its unit files have to land on the VM -- without these the timer has
# nothing to execute. Deploy-ToVm.ps1 itself is excluded: it drives deployment FROM a
# workstation and has no purpose on the target. /E (not just the default non-recursive
# copy) so a future subdirectory under scripts/ is not silently dropped from the package.
robocopy (Join-Path $repoRoot 'scripts') "$stage\scripts" /E /NFL /NDL /NJH /NJS /nc /ns /np `
    /XF Deploy-ToVm.ps1 | Out-Null
robocopy (Join-Path $repoRoot 'infra\systemd') "$stage\infra\systemd" /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
Copy-Item (Join-Path $repoRoot 'dashboard\web\dist\index.html') "$stage\dashboard\web\dist\"
Copy-Item (Join-Path $repoRoot 'dashboard\web\dist\assets\*.js') "$stage\dashboard\web\dist\assets\"
Copy-Item (Join-Path $repoRoot 'dashboard\web\dist\assets\*.css') "$stage\dashboard\web\dist\assets\"
if ($IncludeFonts) {
    Copy-Item (Join-Path $repoRoot 'dashboard\web\dist\assets\*.woff2') "$stage\dashboard\web\dist\assets\" -ErrorAction SilentlyContinue
}

Push-Location $stage
try { tar -czf $tar * } finally { Pop-Location }
if (-not (Test-Path $tar)) { throw "Failed to create $tar" }

$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($tar))
$total = $b64.Length
$n = [math]::Ceiling($total / $ChunkSize)
Write-Host ("Package: {0:N0} bytes → {1} base64 chunks" -f (Get-Item $tar).Length, $n) -ForegroundColor Cyan

$init = Join-Path $env:TEMP 'azuresentry-init.sh'
'rm -f /tmp/azuresentry.b64 /tmp/azuresentry-slim.tar.gz; echo INIT_OK' | Set-Content $init -Encoding ascii
$null = Invoke-VmScript -ScriptPath $init -Expect 'INIT_OK'

for ($i = 0; $i -lt $n; $i++) {
    $start = $i * $ChunkSize
    $len = [Math]::Min($ChunkSize, $total - $start)
    $chunk = $b64.Substring($start, $len)
    $script = Join-Path $env:TEMP "azuresentry-chunk-$i.sh"
    "printf '%s' '$chunk' >> /tmp/azuresentry.b64; echo CHUNK_${i}_$len" | Set-Content $script -Encoding ascii -NoNewline
    Write-Host "Uploading chunk $($i + 1)/$n..."
    $null = Invoke-VmScript -ScriptPath $script -Expect "CHUNK_$i"
}

$install = Join-Path $env:TEMP 'azuresentry-install.sh'
@'
set -e
echo "b64_bytes=$(wc -c < /tmp/azuresentry.b64)"
base64 -d /tmp/azuresentry.b64 > /tmp/azuresentry-slim.tar.gz
echo "tar_bytes=$(wc -c < /tmp/azuresentry-slim.tar.gz)"
# I4 (2026-08-20 final review): stop the poller timer too, not just the dashboard.
# Untarring over a live tree is not atomic -- a cycle that starts mid-extraction can
# dot-source a mix of old and new PollerGate.ps1 / TicketPollerAgent.ps1 /
# MeTicketMapper.ps1. In enforce mode that is a real Azure RBAC grant decided by an
# inconsistent policy set. poller_was_active remembers whether the timer was running so
# a fresh VM (timer never installed) or an operator who deliberately stopped it is not
# silently re-enabled by a deploy.
#
# Same reasoning applies to the reaper timer: a cycle starting mid-extraction could
# dot-source a mix of old and new ReaperAgent.ps1 / GrantRevocation.ps1 and, in enforce
# mode, revoke a real Azure/Graph grant on an inconsistent policy set.
poller_was_active=0
systemctl is-active --quiet azuresentry-poller.timer && poller_was_active=1
systemctl stop azuresentry-poller.timer || true
reaper_was_active=0
systemctl is-active --quiet azuresentry-reaper.timer && reaper_was_active=1
systemctl stop azuresentry-reaper.timer || true
systemctl stop azuresentry || true
ts=$(date +%Y%m%d%H%M%S)
cp -a /opt/azuresentry "/opt/azuresentry.bak.$ts"
tar -xzf /tmp/azuresentry-slim.tar.gz -C /opt/azuresentry
# Windows tar.exe (bsdtar) records mode 0666 in the archive it produced, and extracting as
# root (this whole install runs as root) preserves that archived permission verbatim. Left
# alone, Invoke-TicketPollerCycle.ps1 -- executed AS ROOT every 5 minutes with
# AZURE_CLIENT_SECRET in its environment and authority to grant Azure RBAC -- would be
# world-writable: any unprivileged local account on the VM could rewrite it. Strip group/
# other write from everything just unpacked; owner (root) keeps whatever it already had.
chmod -R go-w /opt/azuresentry
# Keep existing env; do not overwrite /etc/azuresentry.env
systemctl daemon-reload
systemctl start azuresentry
if [ "$poller_was_active" = "1" ]; then systemctl start azuresentry-poller.timer || true; fi
if [ "$reaper_was_active" = "1" ]; then systemctl start azuresentry-reaper.timer || true; fi
sleep 3
systemctl is-active azuresentry
curl -s -m 8 http://127.0.0.1:8787/api/health || echo HEALTH_FAIL
echo INSTALL_OK
'@ | Set-Content $install -Encoding ascii

Write-Host "Installing on VM..." -ForegroundColor Yellow
$out = Invoke-VmScript -ScriptPath $install -Expect 'INSTALL_OK'
Write-Host $out
Write-Host ""
Write-Host "Deploy complete. Dashboard (corp/VPN): http://172.20.191.4:8787" -ForegroundColor Green
Write-Host "Config left untouched: /etc/azuresentry.env"
