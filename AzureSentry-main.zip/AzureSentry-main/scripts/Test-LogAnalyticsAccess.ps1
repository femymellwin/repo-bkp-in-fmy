﻿<#
.SYNOPSIS
    FR6/NFR3/Deliverable #10 diagnostic — verifies the audit trail can actually reach
    Log Analytics once infra/main.bicep is deployed and AZURESENTRY_LA_* is set.

.DESCRIPTION
    Checks, in order:
      1. All four AZURESENTRY_LA_* settings are present.
      2. An OAuth token can be acquired for the configured app registration/SPN.
      3. A real test event round-trips to the DCR/table (send, then confirm no error —
         actual query-side visibility can take a few minutes to land in Log Analytics,
         so this does not poll for the row to appear).

.EXAMPLE
    .\scripts\Test-LogAnalyticsAccess.ps1
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent

$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            [System.Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], 'Process')
        }
    }
}

. (Join-Path $repoRoot 'dashboard\api\LogAnalyticsClient.ps1')

Write-Host 'AzureSentry — Log Analytics ingestion diagnostic' -ForegroundColor Cyan
Write-Host ''

$settings = Get-LogAnalyticsSettings
$checks = [System.Collections.Generic.List[object]]::new()

$checks.Add([pscustomobject]@{ Name = 'AZURESENTRY_LA_DCE_ENDPOINT set'; Ok = -not [string]::IsNullOrWhiteSpace($settings.Endpoint) })
$checks.Add([pscustomobject]@{ Name = 'AZURESENTRY_LA_DCR_IMMUTABLE_ID set'; Ok = -not [string]::IsNullOrWhiteSpace($settings.DcrImmutableId) })
$checks.Add([pscustomobject]@{ Name = 'AZURESENTRY_LA_TENANT_ID set'; Ok = -not [string]::IsNullOrWhiteSpace($settings.TenantId) })
$checks.Add([pscustomobject]@{ Name = 'AZURESENTRY_LA_CLIENT_ID set'; Ok = -not [string]::IsNullOrWhiteSpace($settings.ClientId) })
$checks.Add([pscustomobject]@{ Name = 'AZURESENTRY_LA_CLIENT_SECRET set'; Ok = -not [string]::IsNullOrWhiteSpace($settings.ClientSecret) })

foreach ($c in $checks) {
    $mark = if ($c.Ok) { '[PASS]' } else { '[FAIL]' }
    $color = if ($c.Ok) { 'Green' } else { 'Red' }
    Write-Host "$mark $($c.Name)" -ForegroundColor $color
}

if (-not $settings.Configured) {
    Write-Host ''
    Write-Host 'Not fully configured — stopping here. Set all five AZURESENTRY_LA_* variables' -ForegroundColor Yellow
    Write-Host '(see .env.example) using the outputs from infra/main.bicep once deployed.' -ForegroundColor Yellow
    exit 1
}

Write-Host ''
Write-Host 'Acquiring an access token...' -ForegroundColor Cyan
try {
    $token = Get-LogAnalyticsAccessToken -Settings $settings
    Write-Host "[PASS] Token acquired ($($token.Substring(0, [Math]::Min(12, $token.Length)))...)" -ForegroundColor Green
}
catch {
    Write-Host "[FAIL] Token acquisition failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ''
Write-Host 'Sending a test audit event...' -ForegroundColor Cyan
$testEvent = [pscustomobject]@{
    seq = 0
    timestamp = (Get-Date).ToUniversalTime().ToString('o')
    id = 'diagnostic-test'
    agent = 'DiagnosticScript'
    action = 'ConnectivityTest'
    actor = 'Test-LogAnalyticsAccess.ps1'
    runId = $null; correlationId = $null; ticketId = $null
    target = @{ purpose = 'connectivity check' }
    before = $null; after = $null
    outcome = 'Success'
    reason = 'Diagnostic connectivity test — safe to ignore in query results.'
    detail = $null
    correctsEventId = $null
    isWrite = $false
    hash = 'diagnostic'
    prevHash = 'diagnostic'
}
$result = Send-LogAnalyticsAuditEvent -Event $testEvent
if ($result.ok) {
    Write-Host '[PASS] Test event accepted by the Logs Ingestion API.' -ForegroundColor Green
    Write-Host "Query AzureSentryAudit_CL | where agent_s == 'DiagnosticScript' in a few minutes to confirm it landed." -ForegroundColor DarkGray
}
else {
    Write-Host "[FAIL] Send failed: $($result.error)" -ForegroundColor Red
    exit 1
}
