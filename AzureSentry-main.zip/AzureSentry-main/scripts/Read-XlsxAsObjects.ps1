﻿<#
.SYNOPSIS
    Minimal .xlsx reader (no Excel/COM, no external module) — extracts the first
    worksheet as an array of PSObjects keyed by the header row.

.DESCRIPTION
    An .xlsx is a zip of XML parts. This reads sharedStrings.xml (the string table)
    and sheet1.xml (cell values, which reference the string table by index for text
    cells), and reconstructs rows. Sufficient for a flat data export like our
    labeling CSVs opened and saved in Excel.
#>
param(
    [Parameter(Mandatory)][string]$Path
)

Add-Type -AssemblyName System.IO.Compression.FileSystem

$full = (Resolve-Path $Path).Path
$zip = [System.IO.Compression.ZipFile]::OpenRead($full)
try {
    function Get-ZipEntryXml {
        param($Zip, [string]$EntryName)
        $entry = $Zip.Entries | Where-Object { $_.FullName -eq $EntryName }
        if (-not $entry) { return $null }
        $reader = New-Object System.IO.StreamReader($entry.Open())
        try { return [xml]$reader.ReadToEnd() } finally { $reader.Dispose() }
    }

    # Shared strings table — text cells reference this by index (t="s").
    $sharedStrings = @()
    $sstXml = Get-ZipEntryXml -Zip $zip -EntryName 'xl/sharedStrings.xml'
    if ($sstXml) {
        $ns = @{ x = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' }
        $sharedStrings = @($sstXml.sst.si | ForEach-Object {
                if ($_.t -ne $null) { [string]$_.t }
                else { (($_.r | ForEach-Object { [string]$_.t }) -join '') }
            })
    }

    # Find the first worksheet's actual path via workbook.xml + rels (usually sheet1.xml).
    $sheetPath = 'xl/worksheets/sheet1.xml'
    $sheetXml = Get-ZipEntryXml -Zip $zip -EntryName $sheetPath
    if (-not $sheetXml) { throw "Could not find $sheetPath in $Path" }

    function Get-ColumnLetters {
        param([string]$CellRef)
        return ($CellRef -replace '[0-9]', '')
    }
    function ConvertFrom-ColumnLetters {
        param([string]$Letters)
        $col = 0
        foreach ($ch in $Letters.ToCharArray()) {
            $col = $col * 26 + ([int][char]$ch - [int][char]'A' + 1)
        }
        return $col
    }

    $rows = @()
    foreach ($rowNode in $sheetXml.worksheet.sheetData.row) {
        $cells = @{}
        $maxCol = 0
        foreach ($c in @($rowNode.c)) {
            if (-not $c.r) { continue }
            $colLetters = Get-ColumnLetters -CellRef $c.r
            $colIndex = ConvertFrom-ColumnLetters -Letters $colLetters
            if ($colIndex -gt $maxCol) { $maxCol = $colIndex }
            $raw = if ($c.v -ne $null) { [string]$c.v } else { '' }
            $value = if ($c.t -eq 's' -and $raw -ne '') { $sharedStrings[[int]$raw] } else { $raw }
            $cells[$colIndex] = $value
        }
        $rowArray = @()
        for ($i = 1; $i -le $maxCol; $i++) { $rowArray += , $(if ($cells.ContainsKey($i)) { $cells[$i] } else { '' }) }
        $rows += , $rowArray
    }

    if ($rows.Count -eq 0) { return @() }
    $headers = $rows[0]
    $objects = @()
    for ($r = 1; $r -lt $rows.Count; $r++) {
        $obj = [ordered]@{}
        for ($c = 0; $c -lt $headers.Count; $c++) {
            $key = if ($headers[$c]) { [string]$headers[$c] } else { "col$c" }
            $obj[$key] = if ($c -lt $rows[$r].Count) { [string]$rows[$r][$c] } else { '' }
        }
        $objects += [pscustomobject]$obj
    }
    return $objects
}
finally {
    $zip.Dispose()
}
