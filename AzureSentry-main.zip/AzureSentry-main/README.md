# AzureSentry

Agentic automation platform for **Azure RBAC and Privileged Identity Management (PIM)** access requests. AzureSentry replaces manual help-desk fulfilment with a deterministic decision pipeline: tickets are classified, routed, and fulfilled (or escalated) via time-bound PIM assignments with a full audit trail.

> **Status:** Code complete through Phase 4 authoring · **Phase 3 exit not met** (not deployed / no live Sandbox E2E) · See [progress.md](progress.md) and [BUILD_PLAN.md](docs/BUILD_PLAN.md).

---

## Table of contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Repository structure](#repository-structure)
- [Prerequisites](#prerequisites)
- [Getting started](#getting-started)
- [Testing](#testing)
- [Dashboard prototype](#dashboard-prototype)
- [Deploy](#deploy)
- [Documentation](#documentation)
- [Contributing](#contributing)
- [License](#license)

---

## Overview

| Capability | Description |
|------------|-------------|
| **Sandbox automation** | Reader/Contributor on approved sandbox subscriptions — active PIM grant in seconds, no human touch |
| **Extensible roles** | Storage Blob Data and AKS RBAC roles supported; new Azure roles added via `src/RbacDecision/Data/role-catalog.json` (tier + scope), no code change |
| **Production approval** | Eligible PIM assignments with approver notification and SLA tiers (P1–P4) |
| **Deterministic decisions** | 7-step decision tree in code — no LLM on access-control paths |
| **JIT access only** | All grants time-bound via PIM; no standing access |
| **Audit** | Structured records keyed on ticket ID (production target: Log Analytics) |

**Design principles:** fail closed, least privilege for platform identities, mock-capable PIM client for offline tests, Graph client for live tenant.

---

## Architecture

```
ManageEngine webhook
        │
        ▼
Logic App Standard (thin router) ──► Automation Runbooks
        │                                    │
        │                                    ├── Resolve-RbacDecision (PS module)
        │                                    └── IPimClient → Graph / Mock PIM
        ▼
Azure PIM (Entra ID) ──► Log Analytics (audit)
```

| Layer | Component | Responsibility |
|-------|-----------|----------------|
| Intake | ManageEngine webhook | Ticket payload to orchestrator |
| Orchestrate | Logic App Standard | Auth, routing, runbook dispatch only |
| Execute | Automation runbooks | Decision + PIM API calls |
| Govern | Azure PIM | Approval workflow, expiry, lifecycle |
| Observe | Log Analytics | Decision and PIM event audit |

Platform infrastructure (Bicep): Key Vault, Log Analytics, Automation Account, Logic App Standard, resource-scoped RBAC for managed identities.

---

## Repository structure

```
AzureSentry/
├── docs/                         # Scope, BUILD_PLAN (§13 milestones), progress
├── infra/                        # Bicep — subscription deployment + modules
├── logicapp/workflows/           # Logic App Standard workflow JSON
├── src/
│   ├── RbacDecision/             # Decision engine (Resolve-RbacDecision)
│   ├── PimClient/                # GraphPimClient + MockPimClient
│   └── Runbooks/                 # Automation runbook scripts
├── tests/                        # Pester unit + contract tests
├── dashboard/                    # Prototype UI + REST API demo
└── progress.md                   # Session progress and blockers
```

---

## Prerequisites

| Tool | Version / notes |
|------|-----------------|
| [PowerShell](https://learn.microsoft.com/powershell/) | 7.2+ recommended (runbooks); 5.1+ for local Pester |
| [Pester](https://pester.dev/) | 5.x — `Install-Module Pester -Scope CurrentUser` |
| [Azure CLI](https://learn.microsoft.com/cli/azure/) | `az login` against target subscription |
| [Bicep](https://learn.microsoft.com/azure/azure-resource-manager/bicep/) | Via `az bicep` |
| [Node.js](https://nodejs.org/) | 18+ — dashboard only |

**Azure context (dev):** subscription `github`, region `uaenorth`, target RG `rg-azuresentry-dev-incp-uaen-001` (created on deploy).

---

## Getting started

### 1. Clone the repository

```powershell
git clone https://github.int.inceptionai.ai/SANDBOX/AzureSentry.git
cd AzureSentry
```

### 2. Run the decision engine locally

```powershell
Import-Module .\src\RbacDecision\RbacDecision.psd1 -Force

$ticket = @{
  TicketId           = 'DEMO-001'
  RequesterUpn       = 'user@contoso.com'
  TargetUpn          = 'user@contoso.com'
  Role               = 'Reader'
  Environment        = 'Sandbox'
  SubscriptionId     = '00000000-0000-0000-0000-000000000001'
  DurationHours      = 8
  Priority           = 'P3'
  Justification      = 'Demo access'
}

Resolve-RbacDecision -Ticket $ticket -SubscriptionAllowlist @('00000000-0000-0000-0000-000000000001')
```

### 3. Try the dashboard (optional)

See [Dashboard prototype](#dashboard-prototype) for a visual simulator wired to the real decision module.

---

## Testing

```powershell
.\tests\Run-Pester.ps1
```

| Suite | Path | Coverage |
|-------|------|----------|
| Unit | `tests/unit/RbacDecision.Tests.ps1` | §2.2 eligibility matrix, reject paths, fail-closed |
| Contract | `tests/contract/PimClient.Tests.ps1` | `MockPimClient` / `GraphPimClient` interface |

Set `AZURESENTRY_PIM_CLIENT=Mock` to force mock PIM in runbooks during local runs.

---

## Dashboard prototype

React + MUI UI (G42 light theme) wired to the real decision module. Mock PIM by default — safe for demos.

```powershell
cd dashboard\web
npm install          # first time only
npm run dev          # PowerShell API + Vite UI
```

Open **http://localhost:5173**. One-command alternative (from a PowerShell prompt — bare `.ps1` often opens Notepad):

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\dashboard\Start-Local.ps1 -Mode Real
```

Details: [`dashboard/README.md`](dashboard/README.md) · [`docs/LOCAL_RUN.md`](docs/LOCAL_RUN.md) · live walkthrough: [`docs/DEMO_GUIDE.md`](docs/DEMO_GUIDE.md).

---

## Deploy

Azure changes follow the enforced workflow:

**`azure-prepare` → `azure-validate` → `azure-deploy`**

Follow `azure-prepare` → `azure-validate` → `azure-deploy`. Deploy commands, RBAC split (`deployRbac`), and validation proof: [`docs/BUILD_PLAN.md`](docs/BUILD_PLAN.md) §7 Phase 3 and §9.

**Current blockers:** Graph admin consent on automation SP; infra not deployed. See [`progress.md`](progress.md).

---

## Documentation

| Document | Purpose |
|----------|---------|
| [`docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md`](docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md) | Scope of work and specification (authority) |
| [`docs/BUILD_PLAN.md`](docs/BUILD_PLAN.md) | §13 milestones, dependencies, deploy reference, ordered checklists |
| [`progress.md`](progress.md) | Live phase status, blockers, verification commands |

---

## Contributing

1. Read `docs/BUILD_PLAN.md` and the scope document before changing decision logic or RBAC behaviour.
2. Add or update Pester tests for any change to `Resolve-RbacDecision` or `IPimClient`.
3. Do not skip **azure-validate** before infrastructure deploys.
4. Never commit secrets, `.env` files, or Key Vault values — use managed identity + Key Vault at runtime.

Governance sign-off is required for BUILD_PLAN deviations (e.g. D1 — decision tree in PowerShell vs Logic App conditions) and open spec gaps G1–G6.

---

## License

Internal use — Inception AI. See repository administrators for redistribution terms.
