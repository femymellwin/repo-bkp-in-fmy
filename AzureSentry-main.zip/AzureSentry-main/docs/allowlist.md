# Subscription Allowlist — static vs. dynamic (management group)

The **allowlist** is step 2 of the decision engine: the set of subscriptions the agent is
permitted to act on. Anything not on it is rejected `Allowlist-Reject` (fail-closed).

It can be sourced two ways, controlled by `dashboard/api/config.json` → `allowlist.source`:

| Source | Use | Behaviour |
|--------|-----|-----------|
| `static` (default) | Local / testing | Uses the `subscriptionAllowlist` array in `config.json` (hand-maintained). |
| `managementGroup` | Production | Derives the list **live from Azure** — every subscription under a management group — and **auto-expands** as subscriptions are added. No repo edit needed. |

## Why dynamic (production)

Hand-maintaining a list doesn't scale as subscriptions grow. In `managementGroup` mode the API
calls the ARM **management-group descendants** API (recursive) as the automation SPN and uses the
resulting subscriptions. Add a subscription under the management group in Azure → it becomes
eligible automatically (subject to the rules below).

## Configuration

```jsonc
"allowlist": {
  "source": "managementGroup",          // current default — live from Azure
  "managementGroupId": "mg-incep-sandbox",
  "cacheMinutes": 10,                    // resolved list is cached this long
  "enabledOnly": true,                   // drop subscriptions that aren't Enabled
  "exclusions": []                       // NEVER allowed, even if under the MG (empty = allow all children)
}
```

**Current policy (2026-07-09):** `source: managementGroup`, `exclusions: []` — every enabled
subscription under `mg-incep-sandbox` is allowed, including `ceo-sub-application`. Sensitive
subscriptions are not *excluded*; instead they are classified **Production (approval-gated)** by
the sensitivity map (below), so they can be requested but never auto-granted.

`subscriptionAllowlist` (the flat array) is still used when `source: static`, **and** as the
fail-closed fallback (see below).

## Safety properties

- **Fail closed.** If the Azure lookup fails (auth, network, bad MG id), the resolver falls back
  to the **static `subscriptionAllowlist`** and flags `degraded: true` — it never opens access up.
- **Exclusions always win.** A subscription listed in `exclusions` is refused even if it sits
  under the management group. Currently empty — the sensitivity map (not exclusion) governs
  sensitive subscriptions.
- **Enabled-only.** With `enabledOnly: true`, disabled/warned subscriptions are dropped.
- **Cached.** Results are cached for `cacheMinutes` so there is no Azure call per request.

## Requirements

- The automation SPN creds in `.env` (`AZURE_TENANT_ID` / `AZURE_CLIENT_ID` / `AZURE_CLIENT_SECRET`).
- The SPN needs read access to the management group (Reader/MG Reader). UAA on the child
  subscriptions already satisfies read.

## Inspect the effective allowlist

```
GET /api/allowlist            # current effective list (cached)
GET /api/allowlist?refresh=1  # force a live refresh
```

Returns `source`, `degraded`, `count`, `subscriptions`, and per-sub `details` (id/name/state).

## Companion: subscription → environment sensitivity map (implemented)

Being on the allowlist only decides *whether* the agent may act — **not** whether it auto-grants.
Auto-grant vs. approval is driven by the **Environment** classification (Sandbox = active
auto-grant; Production = eligible + approval), which otherwise comes from the requester's free
text — untrustworthy for a sensitive subscription.

The **sensitivity map** (`src/RbacDecision/Data/subscription-sensitivity.json`) fixes this inside
the decision engine (the security boundary), so it applies to every path (dashboard, CLI, runbooks):

- Maps `subscriptionId → environment` (`Sandbox` | `Production`).
- **Escalate-only:** the engine uses the *more restrictive* of the mapped value and the ticket's
  claimed environment (`Production > Sandbox`). So a sensitive sub is treated as **Production
  (approval-gated) even if the ticket says "sandbox"**, and an explicit Production request is never
  downgraded.
- `default`: `ticket` (trust the ticket for unmapped subs — current behaviour) or `Production`
  (fail-safe: unknown sub → approval required; recommended once the map is populated).
- The decision record carries `ClaimedEnvironment`, `EffectiveEnvironment`, and
  `EnvironmentOverridden` for auditability, and the reason notes the escalation.

Committed map: `inception-ai-Sandbox → Sandbox`; `inception-internal-product` and
`ceo-sub-application → Production`. Since `ceo-sub-application` is now **allowlisted** (via the MG,
no exclusion), this map is what protects it: a "sandbox"-labelled request on it is still
**Production/approval-gated**, not auto-granted. (`exclusions` remains available as the harder
control — refuse outright — if a subscription should never be touched at all.)

## Verified behaviour (2026-07-09)

- `static` → returns the configured subscriptions.
- `managementGroup` on `mg-incep-sandbox`, `exclusions: []` → 9 enabled subscriptions, **including
  `ceo-sub-application`**.
- Decision engine uses the dynamic list AND the sensitivity map: a "sandbox"-labelled Contributor
  request on `ceo-sub-application` → `Eligible/Production-Standard` (claimed=Sandbox →
  effective=Production, overridden), i.e. approval-gated, **not** auto-granted.
- Fail-closed: a bad MG id → `degraded: true`, falls back to the static list, access not widened.
