# Ticket template schemas — Design

**Date:** 2026-08-17  
**Source requirements:** `docs/ticket-templates.md`  
**Status:** Approved — implementation on `feat/ticket-template-schemas`

## Goal

Stop treating every Help Desk ticket as an Azure Subscription request. Resolve a field schema from the ManageEngine **template name**, show exactly the requester-supplied placeholders for that schema in the AzureSentry UI, and feed a structured `templatePayload` into agents. Only the Azure Subscription handler performs PIM/RBAC grants today; all other templates get structured intake + audit until their handlers exist.

## Non-goals

- Implementing fulfilment handlers for non–Azure Subscription templates (1Password, GitHub, Networking, SOC, etc.) in this change.
- Matching schemas by category/subcategory (template name only).
- Hard-coding ManageEngine UDF pick IDs for every new field (label-based extraction).
- Dumping raw `udf_fields` for unknown templates.
- Adding new UI copy that contains the word “template” except where it already exists (e.g. Ticket type helper “ManageEngine request template”).

## Decisions (locked)

| Topic | Choice |
|-------|--------|
| Scope | Full pipeline: UI + agents consume template payload |
| Non-Azure actions | Structured intake + audit; handler `pending` |
| Schema key | ManageEngine `template.name` only |
| Field values | Label-based extraction from `udf_fields` |
| Unknown template | Common fields + “Unknown template schema” warning |

## Architecture

**Approach:** Schema registry + dynamic field panel (single source of truth for UI and agents).

```
ME ticket (template.name + udf_fields)
        │
        ▼
 ticketTemplateSchemas  →  template name → field defs
        │
        ▼
 Label-based UDF extractor  →  match by display label (+ aliases)
        │
        ▼
 templatePayload { templateName, handler, common, fields }
        │
        ├─ azure-subscription-grant  → existing evaluate / process / PIM
        └─ pending                   → intake + audit only
```

| Layer | Responsibility |
|-------|----------------|
| `ticketTemplateSchemas` (web + mirrored PS or shared JSON) | Map template name → ordered field keys/labels; declare `handler` |
| Label extractor | Read `udf_fields`; match labels case-insensitively; apply alias map |
| Dashboard API | Attach `templatePayload` on ticket detail (and list when cheap); gate evaluate/process on handler |
| `TicketsView` | Common Ticket Details; dynamic Request fields panel; Azure-only grant controls |
| Agents / audit | Consume `templatePayload`; journal intake for `pending` handlers |

### Payload shape

```ts
interface TemplatePayload {
  templateName: string
  handler: 'azure-subscription-grant' | 'pending'
  knownSchema: boolean
  common: {
    requesterName?: string
    requesterEmail?: string
    category?: string
    subcategory?: string
    subject?: string
    description?: string
    status?: string
  }
  /** Schema field label → value (empty string if not supplied) */
  fields: Record<string, string>
  warnings: string[]
}
```

## Common fields (every ticket)

Always shown in Ticket Details; never repeated inside the template-specific panel:

- Requester (name + email)
- Category
- Subcategory
- Subject
- Description
- Status
- Ticket type (existing control; value = ME template name)

Priority, Technician, Created, Due remain as today.

## Schema registry

Match is exact trimmed template name (case-insensitive). Spec groupings (Service vs Incident) are documentation only; runtime key is the leaf template name.

### Service — Access Management

| Template name | Fields (beyond common) | Handler |
|---------------|------------------------|---------|
| 1Password | Item | pending |
| Cursor | *(none beyond common)* | pending |
| GitHub Enterprise | Environment, Item, Exception Request, Request Type | pending |
| Azure Subscription | Subscription, Azure Role, Environment | azure-subscription-grant |
| ADO | Request Type, Item, Exception Request, Environment | pending |
| General Access | Item, Business Justification | pending |

### Service — Azure

| Template name | Fields (beyond common) | Handler |
|---------------|------------------------|---------|
| Infrastructure | Item, Business Justification | pending |
| Networking | Request Type, Source IP, Destination IP, Port, Access Direction, Item, Source IP Description, Destination IP Description, Protocol (TCP/UDP), Access Type, Business Justification | pending |
| MLOps | Item | pending |
| Policy Exemptions | Item, Business Justification | pending |
| New Project | Item, Business Justification | pending |
| Cortex | Item, Environment, Request Type | pending |

### Service — Infosec

| Template name | Fields (beyond common) | Handler |
|---------------|------------------------|---------|
| Infosec | Item, Business Justification | pending |
| Security Assessment | *(none beyond common)* | pending |

### Service — DevOps Access

| Template name | Fields (beyond common) | Handler |
|---------------|------------------------|---------|
| DevOps Access | Item, Business Justification, Request Type | pending |

### Incident — Others

| Template name | Fields (beyond common) | Handler |
|---------------|------------------------|---------|
| Report and Issue | *(none beyond common)* | pending |
| Other Request | *(none beyond common)* | pending |
| SOC | *(none beyond common)* | pending |

Notes:

- Fields listed in the source doc that are already **common** (Category, Subcategory, Subject, Description) are omitted from the per-template panel so they are not duplicated.
- Spec spelling “Security Assesment” / “Report and Issue Template” / “Other Request Template” may appear as ME names; registry includes aliases that normalize to the canonical names above (and strip a trailing “ Template” when matching).
- Protocol label in ME may appear as `Protocol (TPC/UDP)`; alias → `Protocol (TCP/UDP)`.

## Label extraction

1. Flatten `udf_fields` into `{ label, value }` pairs (support string values and `{ name }` pick objects).
2. For each schema field, find a UDF whose label equals the field name (case-insensitive) or an alias.
3. Azure Subscription fast path: existing `config.json` `manageEngine.udfFields` keys for Subscription / Azure Role / Environment override label match when present (keeps current grant reliability).
4. Do not invent values from free text for non–Azure Subscription templates.
5. Missing → empty string; UI shows “Not supplied”.

## UI

**Ticket Details (left):** common fields + existing metadata. Description is a first-class labeled presentation (expandable request text acceptable).

**Request fields (right):** replaces the always-Azure Validation Checklist.

- Render only schema fields as read-only placeholders.
- Azure Subscription: keep role / environment / subscription validation and Evaluate / Process under those fields (existing grant UX).
- Other known templates: no grant buttons; show intake status (“Structured intake recorded — action handler pending”).
- Unknown / Unspecified template: common fields + warning; right panel has no schema fields.

**Copy rule:** Keep existing “Ticket type” and its current helper mentioning “template”. Do not introduce new strings containing “template”.

## Backend & agents

- Ticket detail API returns `templatePayload` (and accessFields for Azure Subscription compatibility).
- `POST` evaluate / process: if `handler !== azure-subscription-grant`, return a clear non-grant response (no PIM calls).
- On first successful ticket detail normalization for a `pending` handler, append one audit / governance journal entry per ticket id (idempotent; no spam on re-expand).
- Future handlers register a new `handler` id + executor without rewriting the schema registry or dynamic panel.

## Error handling

| Case | Behavior |
|------|----------|
| Unknown template name | `knownSchema: false`, warning, common fields only |
| Known template, empty optional fields | Empty placeholders; not hard errors |
| Azure Subscription missing role / subscription / environment | Existing hard validation before grant |
| Evaluate/process on non-grant handler | Reject / no-op with reason |

## Testing

- Unit: schema lookup (including aliases); label extraction; handler routing; evaluate/process gate.
- UI: Azure Subscription still shows grant fields; Networking shows IP/port/protocol fields; unknown shows warning; no new “template” strings in UI copy tests.

## Implementation sketch (for planning)

1. Add schema module + alias map from `docs/ticket-templates.md`.
2. Add shared label extractor (TS + PS mirror or API-only build of payload).
3. Extend API ticket detail with `templatePayload`; gate evaluate/process.
4. Refactor `TicketsView` Request fields panel to schema-driven rendering.
5. Wire audit intake for `pending` handlers.
6. Tests as above.
