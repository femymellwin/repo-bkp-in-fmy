# AzureSentry — Unattended ManageEngine Ticket Poller

**Date:** 2026-08-19
**Status:** Approved (design)
**Scope:** New agent (`src/Agents/`), new entry script (`scripts/`), extraction of the
processed-ticket store out of `dashboard/api/Start-DashboardApi.ps1`, new read-only
dashboard endpoint + panel. `Resolve-RbacDecision` is **not** modified.

## Goal

Make AzureSentry actually agentic: process access-request tickets end-to-end with no
human click, for the subset of requests where policy already says no human is needed.

Today every path is attended. The decision is unattended — `Resolve-RbacDecision` picks
grant/eligible/hold/reject, chooses group-vs-PIM fulfilment, sets duration, and posts back
to ManageEngine without a human choosing the outcome — but the *trigger* is always an
operator pressing a button. Verified absent: no runbook resources, no Logic App workflow
definitions, and no job schedules anywhere in `infra/`; the Automation Account and Logic
App are provisioned as empty shells, and `src/Runbooks/*.ps1` are never published or
invoked.

This closes that gap for the narrowest defensible slice and leaves everything else
attended.

## Decisions (locked)

| Decision | Choice |
|---|---|
| Auto-execute scope | `Grant` only, **excluding Production** |
| Runtime host | Windows Task Scheduler on `vm-incp-uaen-001-sentry`, separate PS 5.1 process |
| ME→ticket mapping | Structured ME dropdowns only; **no free-text parsing in the auto path** |
| First deployment | Shadow mode by default; writes require an explicit env flip |

### Why `Grant` only, excluding Production

Two facts from the existing policy contradict the obvious reading:

1. **`Grant` already includes Production Reader.** `prod-reader-standard` and
   `prod-reader-expedited` in `eligibility-matrix.json` are both `action: Grant` with no
   `approverTier`. "Auto-execute Grant" is therefore *not* the same as "never touch
   Production". Production Reader is read-only and carries no write risk, but it is still
   unattended Production access, so it is excluded from the auto path for now.

2. **`Eligible`'s approval gate is currently the operator's click.**
   `Start-DashboardApi.ps1` executes `Grant`, `BreakGlass` *and* `Eligible`, with the
   comment *"Eligible = operator clicked Provide Access (approval)"*. Auto-executing
   `Eligible` would silently delete the only approval step for prod Contributor / Owner /
   UAA. Not done. If it is ever wanted, PIM role settings must first be verified to
   independently require approval-on-activation.

Auto path therefore covers `sandbox-reader`, `sandbox-contributor`, `nonprod-reader`.

### Why structured fields only

The entire ME→ticket mapping (`Role`, `SubscriptionId`, `Environment`, `RequesterUpn` —
every field the decision engine keys on) exists only as client-side TypeScript:
`parseTicket` in `TicketsView.tsx` plus `resolveTicketRole.ts`,
`resolveSubscriptionId.ts`, `resolveTicketEnvironment.ts`, `extractMeAccessFields.ts`.
There is no PowerShell equivalent.

Porting the whole thing would create two implementations of privilege-determining logic
that drift; when they drift, the poller grants a different role than the UI would for the
same ticket. Instead, the poller handles **only** tickets whose ME template dropdowns are
fully populated and allowlisted. That collapses the required PowerShell to a small,
auditable dropdown→canonical lookup with no heuristics, and confines drift risk to a
table that can be tested exhaustively.

The free-text parser exists to help a human triage. It must not decide unattended
privilege. Anything it would be needed for queues for a human, where the UI's full parser
already handles it.

## Architecture

```
Task Scheduler (*/5 min)
  └─ scripts/Invoke-TicketPollerCycle.ps1        thin entry: load .env, one cycle, exit
       └─ src/Agents/TicketPollerAgent.ps1       the cycle
            ├─ Get-ManageEngineRequests          [existing]
            ├─ Resolve-TemplateGrantAllowed      [existing] handler = azure-subscription-grant
            ├─ src/Agents/MeTicketMapper.ps1     [NEW]  udf dropdowns → canonical ticket
            ├─ Resolve-RbacDecision              [existing, untouched]
            ├─ Test-PollerAutoEligible           [NEW]  the auto-execute gate
            ├─ Invoke-GroupOrPimGrant            [existing] real grant
            └─ ME note + resolve                 [existing path proven on ticket #2858]
```

`Start-DashboardApi.ps1` keeps running unchanged and reads the same state, so the UI
reflects what the poller did.

**Why a separate process, not an in-process timer:** the dashboard's `HttpListener` loop
is single-threaded, so an in-process poll would block the UI for its duration, and it
would die on every API restart.

## The auto-execute gate

Four conditions, **all** required. Any failure queues the ticket for a human; there is no
partial write.

| Gate | Rule |
|---|---|
| Template | handler is `azure-subscription-grant` (`Resolve-TemplateGrantAllowed`) |
| Mapping | Subscription, Azure Role and Environment dropdowns all populated; subscription on the effective allowlist; **zero mapper warnings** |
| Decision | `Action -eq 'Grant'` — never Eligible, Hold, Reject, BreakGlass |
| Environment | **effective** environment is Sandbox or NonProd |

Using the *effective* environment is load-bearing: `Resolve-RbacDecision` raises
environment from subscription sensitivity, so a ticket claiming "Sandbox" against a
sensitive subscription is raised to Production and correctly falls out of the auto path.
The gate must read the decision's effective environment, never the ticket's claim.

## Two defects this must fix first

### a) The dedup race (correctness-critical)

`Save-ProcessedTicket` / `Remove-ProcessedTicketEntry` in `Start-DashboardApi.ps1` are
unlocked read-modify-write cycles over `processed-tickets.json`. With a second process
writing that file concurrently, entries are lost — and a lost entry is a **duplicate
grant**.

Fix: extract to `dashboard/api/ProcessedStore.ps1`, guard every mutation with a named
cross-process mutex (`Global\AzureSentryProcessedStore`), and have both the API and the
poller consume that one module. The poller re-checks the store *inside* the lock
immediately before granting.

The real backstop remains the existing live duplicate check
(`Get-RealActiveAssignments` + `Invoke-RealGroupDuplicateCheck`), which queries Azure
rather than local state. Local dedup is an optimization; Azure is truth.

### b) Cold-start stampede

A first run against the open historical backlog (~2000 tickets) would attempt all of
them. Fix: `maxTicketAgeDays` (default 7) bounds what the poller will ever consider, plus
the per-cycle caps below.

## Safety envelope

| Setting | Default | Effect |
|---|---|---|
| `AZURESENTRY_POLLER_ENABLED` | `false` | Kill switch. Must be explicitly `true`; anything else is a no-op. |
| `AZURESENTRY_POLLER_MODE` | `shadow` | `shadow` = decide + record, write nothing. `enforce` = execute. |
| `maxTicketsPerCycle` | 25 | Cap on tickets examined per cycle. |
| `maxGrantsPerCycle` | 5 | Blast radius per 5-minute window. |
| `maxTicketAgeDays` | 7 | Ignore anything older; prevents backlog stampede. |

Plus:

- **`poller.stop` sentinel file** — presence halts the cycle immediately, no env edit or
  scheduler change needed.
- **Fail-closed** — the first execution error stops the cycle rather than continuing to
  the next ticket, mirroring `Invoke-EnvironmentBackfillBatch`'s `Stopped` behaviour.

### Shadow mode wording

Shadow records the full intended grant with `applied = false` and reports
`wouldGrant: N`. It deliberately avoids the word "skipped", which in the environment
backfill made a successful dry run read identically to a failure (`0 written · 0 failed ·
N skipped`) and cost real debugging time.

## Data flow, per ticket

1. Fetch recent ME requests (existing client), filter to the IDM queue group.
2. Drop anything already in the processed store, older than `maxTicketAgeDays`, or not
   status-open.
3. `Resolve-TemplateGrantAllowed` — non-grant templates are out of scope entirely.
4. `Resolve-MeTicketMapping` — returns the canonical ticket plus a completeness verdict
   and warnings. Incomplete or warning-carrying → queue.
5. `Resolve-RbacDecision` with the effective allowlist and the live duplicate check.
6. `Test-PollerAutoEligible` — the four gates above.
7. Shadow: journal the intended grant, stop. Enforce: acquire the store lock, re-check
   dedup, `Invoke-GroupOrPimGrant`, record, release.
8. On success, post the ME note and resolve the ticket with the closure fields proven on
   #2858 (`udf_pick_3713` Vendor Compliance, `udf_pick_3722` Account Status,
   `resolution.content`).

## Audit & visibility

Each cycle takes a RunId from `New-AgentRunId`. Every ticket produces a governance
journal entry and a `Write-AuditEvent` with actor `poller` — **including shadow
decisions**, marked `applied = false`. New `GET /api/poller/status` plus a dashboard panel
showing last cycle time, mode, wouldGrant vs granted, and what queued for a human, so the
automatic path is observable rather than a black box.

## Testing

Pester, mirroring the existing suites.

`tests/unit/MeTicketMapper.Tests.ps1`
- all dropdowns populated → complete mapping, no warnings
- each dropdown missing in turn → incomplete, warning names the missing field
- subscription not on the effective allowlist → warning, not a silent pass
- guest (`#EXT#`) requester resolves via mail/otherMails
- no free-text inference occurs even when the body clearly states an environment

`tests/unit/TicketPollerAgent.Tests.ps1`
- `sandbox-reader` / `sandbox-contributor` / `nonprod-reader` auto-execute
- **Production Reader queues** despite being `Grant` in the matrix
- `Eligible`, `Hold`, `Reject`, `BreakGlass` never execute
- sensitivity-raised environment (claims Sandbox, effective Production) queues
- mapper warning → queue, no grant attempted
- shadow mode performs zero writes and reports `wouldGrant`
- `maxGrantsPerCycle` / `maxTicketsPerCycle` enforced
- `AZURESENTRY_POLLER_ENABLED` unset/false → no-op
- `poller.stop` sentinel halts the cycle
- updater error → cycle stops (fail-closed), later tickets untouched
- dedup holds when the store is written concurrently

## Files

**New**
- `src/Agents/MeTicketMapper.ps1` — structured-field mapping + completeness verdict
- `src/Agents/TicketPollerAgent.ps1` — one cycle; select, map, decide, gate, execute, write back
- `scripts/Invoke-TicketPollerCycle.ps1` — Task Scheduler entry point
- `dashboard/api/ProcessedStore.ps1` — extracted, mutex-guarded processed-ticket store
- `tests/unit/MeTicketMapper.Tests.ps1`, `tests/unit/TicketPollerAgent.Tests.ps1`
- `docs/ticket-poller-runbook.md` — deploy, enable, flip to enforce, halt, verify

**Modified**
- `dashboard/api/Start-DashboardApi.ps1` — consume `ProcessedStore.ps1`; add
  `GET /api/poller/status`
- `dashboard/web/src/views/…` + `types.ts` — poller status panel

## Consequences for the two pages under review

**Environment Governance becomes load-bearing.** The poller only auto-processes tickets
whose ME `Environment` dropdown is populated; every untagged ticket queues for a human.
The backfill is therefore what raises the auto-processing rate — a far stronger
justification than the page currently makes for itself, and it should say so.

**Department Scope remains unjustified as a console page.** Nothing in this design touches
it. It grants nothing, decides nothing, and participates in no runtime path. It belongs in
a document, like Eligibility Matrix and Architecture before it.

## Out of scope

- Auto-executing `Eligible` (needs PIM approval-on-activation verified first)
- Production auto-grants of any role, Reader included
- Free-text inference in the auto path
- Migrating the host to the Automation Account / Logic App shells
- Porting the UI's full mapping to PowerShell

## As shipped -- deviations from this spec

Recorded here rather than edited into the sections above, so this document still reflects
what was designed and decided at the time, not what changed afterward.

1. **Runtime host.** Shipped as Ubuntu 22.04 + systemd (`azuresentry-poller.timer` /
   `.service`) running `pwsh` 7, not Windows Task Scheduler running a separate PS 5.1
   process as this document's "Decisions (locked)" table and architecture diagram say.
   Production is `vm-incp-uaen-001-sentry`. See `docs/ticket-poller-runbook.md` and
   `infra/systemd/`.
2. **No cross-process mutex.** The "Two defects this must fix first" section proposes
   guarding `dashboard/api/ProcessedStore.ps1` mutations with a named cross-process mutex
   (`Global\AzureSentryProcessedStore`). That approach was abandoned: a named mutex on
   Linux lives under `/tmp/.dotnet/shm`, and a systemd unit with `PrivateTmp=true` would
   silently partition it from another process's view of the same name. The store instead
   uses one small JSON file per ticket, with `Request-ProcessedTicketClaim` doing a single
   atomic `CreateNew` filesystem call as the claim -- no lock anywhere. See "How duplicate
   grants are prevented" in the runbook.
3. **No ME note, no resolve.** The architecture diagram's last step, "ME note + resolve
   [existing path proven on ticket #2858]", and step 8 of "Data flow, per ticket", were
   never built. The poller posts nothing back to ManageEngine and does not resolve the
   ticket -- an unattended grant leaves no trace in ME. See "Verify what it did" in the
   runbook, which documents this as a current limitation.
