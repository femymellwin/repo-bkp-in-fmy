# AzureSentry Dashboard — Material UI Migration + G42-Inspired Light Theme

**Date:** 2026-07-22
**Status:** Approved (design)
**Scope:** `dashboard/web` frontend only. No backend / API / PowerShell changes.

## Goal

Replace the dashboard's hand-rolled CSS design system (~950 lines in `index.css`, no
component library) with **Material UI (MUI)** components throughout, and recolor the app
from its current dark Azure theme to a **light, G42 / Inception-inspired "AI-forward"
palette**.

Two things must both be true when done:
1. The UI is genuinely built from MUI components (not custom CSS dressed up).
2. The color theme matches the chosen G42-inspired light palette.

## Decisions (locked)

- **Theme mode:** light.
- **Migration depth:** full — every view moves to MUI, the custom CSS system is retired.
- **Palette:** Teal / AI-forward (see below).
- **Layout:** permanent left `Drawer` + top `AppBar` shell.
- **Tables:** MUI `Table` family (MIT). **No** `@mui/x-data-grid` (avoids paid license + complexity).
- **Fonts:** Inter via `@fontsource/inter` (bundled, no external CDN/network calls).

## Palette

| Token | Hex | MUI mapping |
|---|---|---|
| Canvas | `#F5F9F9` | `background.default` |
| Surface | `#FFFFFF` | `background.paper` |
| Text primary | `#0C1B1B` | `text.primary` |
| Text secondary | `#556666` | `text.secondary` |
| Primary (deep teal) | `#0E4F52` | `palette.primary.main` |
| Accent (cyan) | `#17A2A8` | `palette.secondary.main` |
| Divider | `#E2ECEC` | `palette.divider` |
| Success | `#1FA971` | `palette.success.main` |
| Warning | `#C67A12` | `palette.warning.main` |
| Error | `#D14343` | `palette.error.main` |

**Decision-state colors** (used by `Chip`s and stat accents; carried as custom palette
keys via module augmentation so usage stays semantic):

| State | Meaning | Base color |
|---|---|---|
| `grant` | Auto-grant | `#1FA971` (success) |
| `eligible` | Eligible | `#17A2A8` (accent cyan) |
| `reject` | Rejected | `#D14343` (error) |
| `hold` | On hold | `#C67A12` (warning) |
| `breakglass` | Break-glass | `#E67E22` (amber-orange) |

## Architecture

### Theme foundation — new `dashboard/web/src/theme.ts`
- Single `createTheme({ palette: { mode: 'light', ... } })` carrying the palette above.
- Custom palette keys for the five decision states, added via TypeScript module
  augmentation of `@mui/material/styles` `Palette` / `PaletteOptions`.
- Typography: Inter; `MuiButton` default `textTransform: 'none'`; base `shape.borderRadius: 10`.
- Component defaults: flat/low-elevation `Card`/`Paper` with a `1px` `divider` border
  (replacing the old heavy dark drop-shadows); `AppBar` flat, light `color="inherit"`.
- Exported as the default theme; consumed in `main.tsx`.

### Entry wiring — `dashboard/web/src/main.tsx`
- Wrap `<App />` in `<ThemeProvider theme={theme}>` + `<CssBaseline />`.
- Import `@fontsource/inter` weights (400/500/600/700).

### CSS retirement — `dashboard/web/src/index.css`
- Shrinks to: font-family fallback, `#root` height, and any keyframes still needed by the
  activation stepper animation (`step-fill`, `step-pulse`) if not reproduced via MUI.
- All `.stat-card`, `.panel`, `.badge`, `.nav-*`, `.form-*`, table, gauge, etc. classes are
  removed as their views migrate. Target end state: no bespoke layout/color classes remain.

### App shell — `dashboard/web/src/App.tsx`
- **Left `Drawer`** (`variant="permanent"`, 240px): brand header block; grouped nav using
  `List` + `ListSubheader` (for the `Monitoring` / `ManageEngine` groups) + `ListItemButton`
  with `@mui/icons-material` icons and `selected` state; bottom area with a connection
  `Chip` (color reflects online/offline) + a `Button` to refresh.
- **Top `AppBar`** (flat, light): current page title + API status.
- **Content**: `Box` main region; page-level errors rendered as an MUI `Alert severity="error"`.
- Responsive: Drawer collapses to a temporary/toggle drawer under the existing ~1100px
  breakpoint (behavior parity with today's responsive collapse).

### Component mapping (applied across all files)

| Current (custom CSS) | Becomes (MUI) |
|---|---|
| `.stat-card` grid | `Grid`/`Box` of `Card` + `Typography`; value colored per decision state |
| `.panel` | `Card` with `CardHeader` + `CardContent` |
| Simulator form fields | `TextField`, `Select`/`MenuItem`, `Checkbox`, `FormControlLabel` |
| Action buttons | `Button` (`variant="contained"` primary, `"outlined"` secondary, `color="error"` danger) |
| `.preset-chip` | clickable `Chip` |
| `.badge` / `ActionBadge` | `Chip` colored by decision state |
| `DecisionTrace` steps | MUI `Stepper` (vertical) or `List` with pass/fail icons (`CheckCircle` / `Cancel`) |
| Live activation stepper | MUI `Stepper` + `LinearProgress`; keep the timed animation |
| Tables (matrix/activity/sla/expiry/breakglass) | `Table`, `TableHead`, `TableRow`, `TableCell`, `TableContainer` + `Chip` statuses |
| Activity list | `Stack` of `Paper` rows |
| SLA gauge (conic-gradient) | `CircularProgress variant="determinate"` with centered `Typography` label |
| SLA bars / tier stats | `LinearProgress` + `Chip` |
| Architecture flow | `Paper` nodes + arrow icons (`ArrowForward`) in a responsive `Stack` |

### Files touched
- `dashboard/web/package.json` — add `@mui/material`, `@emotion/react`, `@emotion/styled`,
  `@mui/icons-material`, `@fontsource/inter`.
- `dashboard/web/src/theme.ts` — **new**.
- `dashboard/web/src/main.tsx` — ThemeProvider + CssBaseline + font import.
- `dashboard/web/src/index.css` — reduce to minimal.
- `dashboard/web/src/App.tsx` — shell + Overview + Simulator + Matrix + Architecture views.
- `dashboard/web/src/components/ActionBadge.tsx`, `DecisionTrace.tsx` — MUI.
- `dashboard/web/src/views/ActivityView.tsx`, `BreakGlassView.tsx`, `ExpiryView.tsx`,
  `LivePimView.tsx`, `SlaView.tsx`, `TicketsView.tsx` — MUI.

## Out of scope (YAGNI)
- No `@mui/x-data-grid` (paid tiers / extra bundle).
- No backend, API, PowerShell, or infra changes.
- No new external network dependencies (fonts bundled locally).
- No dark-mode toggle — single light theme only.
- No new features or view additions; this is a visual/component migration at behavior parity.

## Data flow / behavior
Unchanged. `App.tsx` still owns all state and the `refresh()` / `runEvaluate()` logic against
`api/client.ts`; views remain presentational and keep their existing props. Only the rendered
markup and styling change.

## Error handling
- API-unavailable and evaluation errors keep their current messages, surfaced through MUI
  `Alert` instead of the `.error-banner` div.
- Connection status continues to reflect `api.health()` success/failure.

## Testing / verification
- No existing frontend tests.
- `cd dashboard/web && npm install && npm run build` (i.e. `tsc -b && vite build`) must pass
  with no TypeScript or build errors.
- Run the dev server and manually verify each of the 10 nav views renders correctly on the
  new theme, plus the responsive Drawer collapse.
- Confirm no external network requests for fonts/assets (CSP-friendly, offline-capable).
