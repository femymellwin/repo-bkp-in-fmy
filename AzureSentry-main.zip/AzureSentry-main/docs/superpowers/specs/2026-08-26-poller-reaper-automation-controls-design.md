# AzureSentry — Simplified Poller/Reaper Automation Controls

## Goal

Today, making the unattended poller/reaper "truly automatic" requires touching three
independent layers: install the systemd timer (one-time infra), flip
`AZURESENTRY_POLLER_ENABLED`/`AZURESENTRY_REAPER_ENABLED` in `/etc/azuresentry.env` (a kill
switch deliberately unreachable from the UI), and toggle Enforce Mode from the dashboard. The
per-cycle caps (`MAX_GRANTS`, `MAX_TICKETS`, `MAX_AGE_DAYS`, reaper's `MAX_REVOKES`) are
env-file-only with no UI path at all. For a single-operator deployment this is more friction
than the risk warrants.

This spec adds a single UI control per agent — **Off / Rehearse / Live** — and UI-editable
per-cycle caps, without touching the timer (still a one-time infra step) and without changing
anything about the env-var path for anyone who prefers editing files directly.

## Decisions (locked)

1. **Timer install stays out of scope.** It's one-time infra, not a day-to-day control; nothing
   here changes `infra/systemd/install-poller-timer.sh` or its reaper equivalent.
2. **The kill switch becomes UI-reachable**, via a new override file using the *exact same*
   mechanism `poller.mode` already implements — not a new mechanism, a second instance of the
   proven one. This deliberately removes the "a UI click alone can never fully arm real writes"
   property that motivated keeping it env-only originally; accepted as the right trade-off for
   a single-operator platform (confirmed with the platform owner during design).
3. **The 3-way UI control is a composition, not a new primitive.** "Off"/"Rehearse"/"Live" maps
   to two independent, already-existing-shaped override files (`*.enabled`, `*.mode`) set
   together by the UI. `poller.mode`'s file, route, and tests are **untouched** by this work.
4. **All four per-cycle caps become UI-editable** (poller: `MAX_GRANTS`, `MAX_TICKETS`,
   `MAX_AGE_DAYS`; reaper: `MAX_REVOKES`), via one new JSON override file per agent with
   per-field fallback to the env var for any key not present.
5. **Justification (≥4 chars) is required only on the escalating action**, mirroring the
   existing mode-override rule exactly: arming automation (`enabled:true`) needs it, disarming
   doesn't; raising `MaxGrantsPerCycle` / `MaxRevokesPerCycle` needs it (the actual blast-radius
   bounds), changing `MaxTicketsPerCycle` / `MaxTicketAgeDays` in either direction doesn't (they
   bound examination/eligibility, not writes — `MaxGrantsPerCycle` still caps real writes
   regardless of how large a batch becomes eligible).
6. **No changes to the env-var path.** With no override files present, behavior is byte-identical
   to today. This is purely additive.

## Architecture

```
Get-PollerConfig (unchanged mode/stop logic) + two new checks, same shape as mode's:

  poller.enabled  (plain text: "true" or anything-else-means-false)
       ↓ checked before AZURESENTRY_POLLER_ENABLED, fail-closed to false

  poller.caps.json  ({ maxGrants?, maxTickets?, maxAgeDays? })
       ↓ each key checked before its env var, per-field fallback,
         malformed JSON => whole file ignored, full env fallback

Dashboard UI "Off / Rehearse / Live" control
       ↓ composes two API calls
  POST /api/poller/enabled  +  POST /api/poller/mode   (existing, untouched)

Dashboard UI "Per-cycle limits" form
       ↓
  POST /api/poller/caps
```

Reaper gets the identical shape: `reaper.enabled`, `reaper.caps.json` (`{maxRevokes?}`),
`/api/reaper/enabled`, `/api/reaper/caps`.

## `Get-PollerConfig` / `Get-ReaperConfig` changes

New parameters, resolved the same three-step chain as `-ModeOverrideFilePath` (explicit arg →
env var naming the path → default next to the processed store):

- `-EnabledOverrideFilePath` (env var override: `AZURESENTRY_POLLER_ENABLED_FILE`, default
  filename `poller.enabled`)
- `-CapsOverrideFilePath` (env var override: `AZURESENTRY_POLLER_CAPS_FILE`, default filename
  `poller.caps.json`)

Reading logic:

- **Enabled override**: file absent → env var alone decides (today's behavior, unchanged).
  File present → trim + lowercase content; exactly `true` → enabled; anything else (blank,
  garbage, the literal word `false`) → disabled. This is the same fail-closed direction as mode
  (the override can only ever move the effective value toward MORE conservative when its
  content is ambiguous — never assume permissive).
- **Caps override**: file absent → all three fields read from their env vars (unchanged).
  File present and valid JSON → for each of `maxGrants`/`maxTickets`/`maxAgeDays`, if the key
  exists and parses as a positive integer, it wins; if the key is absent, that field still
  falls back to its own env var independently (not to the file's absence as a whole). File
  present but **not parseable as JSON at all** → the whole file is ignored, all three fields
  fall back to env — never attempt a partial/best-effort parse of broken JSON.

Return object (`Get-PollerConfig`'s pscustomobject) gains:

```
EnabledSource         'env' | 'override'
EnabledOverrideFilePath
MaxGrantsSource       'env' | 'override'
MaxTicketsSource      'env' | 'override'
MaxAgeDaysSource      'env' | 'override'
CapsOverrideFilePath
```

`Enabled`, `MaxGrantsPerCycle`, `MaxTicketsPerCycle`, `MaxTicketAgeDays` keep their existing
names/meaning — only their *source* changes, transparently.

`Get-ReaperConfig` gets the same four new fields, `MaxRevokesSource` instead of the three
poller ones.

## New API routes (`Start-DashboardApi.ps1`)

All four new routes follow the existing `/api/poller/mode` handler's structure line for line
(read body → validate → compute previous value for the audit record → write via
`[System.IO.File]::WriteAllBytes` with no BOM, matching the documented PS 5.1/pwsh 7 trap →
`Write-AuditEvent` → respond with the same "takes effect next cycle" note).

**`POST /api/poller/enabled`** — body `{ enabled: bool, justification?: string }`.
`enabled:true` requires `justification` ≥ 4 chars (same message/floor as mode's). `enabled:false`
requires nothing. Writes `poller.enabled` as the literal bytes `true` or `false`. Audited as
`SetEnabledOverride`, `Before`/`After` = `{ enabled: <bool-or-null> }`.

**`DELETE /api/poller/enabled`** — removes the file if present, falls back to env. Audited as
`ClearEnabledOverride`.

**`POST /api/poller/caps`** — body `{ maxGrants?, maxTickets?, maxAgeDays? }`, any subset.
Each provided value validated as a positive integer > 0 — a bad value is a **400 rejected at
write time**, not silently coerced to a default the way `Get-PollerConfig`'s own lenient
`$asInt` parser behaves for the env-var path (the API is the point where a mistake should be
caught loudly; the config reader's leniency exists for a hand-edited env file, a different
failure mode). Read-modify-write: merges into whatever `poller.caps.json` already holds, so
setting only `maxGrants` doesn't clobber a previously-set `maxTickets`. If the effective new
`maxGrants` is **greater than** the current effective value (override or env, whichever is
active), `justification` ≥ 4 chars is required, same floor as mode/enabled. Lowering `maxGrants`,
or touching `maxTickets`/`maxAgeDays` in either direction, needs no justification. Audited as
`SetCapsOverride`, `Before`/`After` = the full three-field effective object.

**`DELETE /api/poller/caps`** — removes the whole file, full fallback to env for all three
fields. Audited as `ClearCapsOverride`.

**`/api/reaper/enabled`, `/api/reaper/caps`** — identical shapes, single field `maxRevokes` for
caps, same "raising requires justification" rule.

**`GET /api/poller/status`** (and reaper's) response gains, alongside the existing
`modeOverride`:

```json
"enabledOverride": { "present": bool, "value": "true"|"false"|null, "filePath": "..." },
"caps": {
  "maxGrants":  { "value": 5,   "source": "env" },
  "maxTickets": { "value": 100, "source": "override" },
  "maxAgeDays": { "value": 7,   "source": "env" }
}
```

## Dashboard UI

**Automation control** (replaces the current Enforce Mode toggle on both the Poller and
Reaper panels): a three-option segmented control.

| Selection | Calls made | Justification |
|---|---|---|
| **Off** | `POST /api/poller/enabled {enabled:false}` | none |
| **Rehearse** | `POST /api/poller/enabled {enabled:true}` + `POST /api/poller/mode {mode:shadow}` | none — this is the no-write state |
| **Live** | Both calls above with `enabled:true` / `mode:enforce`, one shared justification prompt | required once, reused for both calls |

If the second call fails after the first succeeds (e.g. network blip mid-click), the UI shows
an explicit "partially applied — check Automation and Mode below" state rather than reporting
success; both facts are independently visible from `GET /api/poller/status`, so nothing is
actually hidden even if the UI's own composed view is temporarily wrong.

**Per-cycle limits** form, added below the automation control: three number inputs (poller) /
one (reaper), each showing its current effective value and an "override" or "default" badge
from the new `source` field. A "Save" action calls `POST /api/poller/caps`; raising the
grants/revokes field triggers the same justification prompt as Live.

The existing override-vs-last-reported-cycle distinction is unchanged — the panel still shows
what you told it to do (now: automation state, composed from `enabledOverride` + `modeOverride`)
separately from what the last actual cycle did.

## Compatibility

- No override files anywhere → behavior is byte-identical to pre-this-spec: pure env-var
  driven, exactly as documented in `docs/ticket-poller-runbook.md` today.
- `poller.mode`/`reaper.mode` file format, route, audit actions, and existing tests are
  **untouched**.
- `scripts/Deploy-ToVm.ps1` gains four more exclusions: `poller.enabled`, `poller.caps.json`,
  `reaper.enabled`, `reaper.caps.json` — same reasoning as the existing `poller.mode`/
  `poller.stop` exclusions (a redeploy must never clobber a live override).
- `.gitignore` gains the same four filenames.

## Testing

New `Describe` blocks in `tests/unit/TicketPollerAgent.Tests.ps1` (mirroring the existing
`Get-PollerConfig` mode-override tests exactly) and `tests/unit/ReaperAgent.Tests.ps1`:

- **Enabled override**: file absent → env decides; file `true` → enabled regardless of env;
  file `false`/blank/garbage → disabled regardless of env.
- **Caps override**: file absent → all fields from env; file overrides one field, the other two
  still read from env independently; malformed (non-JSON) file → full fallback to env, no throw;
  a present-but-non-positive-integer value for one key → that key falls back to env (same
  leniency `$asInt` already has for the env-var path).

Route handlers (`/api/poller/enabled`, `/api/poller/caps`, and the reaper equivalents) get the
same level of coverage the existing `/api/poller/mode` route has today: **none at the Pester
level** — that route isn't unit-tested either, only `Get-PollerConfig`'s reading logic is. This
spec doesn't introduce a new gap; it matches existing practice. Manual verification via the
dashboard UI and `curl`/`Invoke-RestMethod` remains the check for the HTTP layer, as it is
today for `/api/poller/mode`.

## Out of scope

- Automating the one-time systemd timer install/enable step.
- Any change to `PollerGate.ps1`'s four auto-grant gates, the promotion ladder, or the
  eligibility matrix — this spec only touches *whether/how much* the poller runs, never *what*
  it's allowed to decide.
- A combined single-file representation of automation state + caps (considered as "Approach C"
  during design and rejected in favor of reusing the proven single-fact-per-file pattern plus
  one small JSON file for the genuinely multi-value caps).
