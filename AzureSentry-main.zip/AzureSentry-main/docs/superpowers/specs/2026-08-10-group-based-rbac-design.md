# Group-based RBAC fulfilment — Design

**Date:** 2026-08-10  
**Source requirements:** `docs/Group-based-RBAC.md`  
**Status:** Approved (2026-08-10) — implementation planning next

## Goal

When fulfilling Reader or Contributor access to a subscription, prefer adding the requester to an Entra ID security group that holds that role on the subscription — instead of assigning RBAC/PIM directly to the user. Prefer an existing matching group; if none exists, create the canonical `sg-<subscription-slug>-contributors|readers` group, assign the role at subscription scope, and add the user. Only fall back to per-user PIM when matches are ambiguous.

## Non-goals

- Owner / UAA automation (remains with the platform team; existing reject/hold behavior).
- IAM-first group discovery (name convention only; create uses the canonical display name).
- Time-bound group membership (membership is permanent; revoke = remove from group).
- Replacing `RbacDecision` eligibility/approval matrix with a new matrix (group vs PIM is fulfilment only).

## Architecture

**Approach:** Extend `GraphPimClient` / `MockPimClient` and change Grant runbooks so fulfilment is group-first, then PIM fallback.

| Layer | Responsibility |
|-------|----------------|
| `RbacDecision` | Unchanged intent: schema, allowlist, role eligibility, environment sensitivity, Approve/Grant/Notify/Deny. |
| `GraphPimClient` | New APIs: resolve group by naming pattern, verify group has role on subscription (ARM), add/remove group member (Graph). Existing PIM APIs kept for fallback and non-group paths. |
| `MockPimClient` | Same surface for unit tests. |
| Grant runbooks (`Runbook-Sandbox-PIM`, `Runbook-Prod-PIM`, and any shared grant helper) | After decision allows fulfilment: try group path; on miss → PIM + engineer flag. |
| Help Desk / status updater | Persist `Fulfilment` mode and engineer flag into ticket notes / result objects. |

Group vs PIM is **not** a new decision-matrix row. It runs only when the decision already authorizes a grant (including post-approval fulfilment for gated Contributor requests).

## Roles in scope

| Role | Group path? |
|------|-------------|
| Reader | Yes |
| Contributor (including IDM Writer → Contributor) | Yes |
| Owner / UAA / Custom | No — existing decision behavior |

## Approval mapping (decision layer; unchanged intent)

| Case | Approval | Fulfilment after authorize |
|------|----------|----------------------------|
| Sandbox Reader or Contributor | None | Group add, else PIM + flag |
| Reader (any environment) | None | Group add, else PIM + flag |
| Non-prod / Production Contributor | Required | After approve → group add, else PIM + flag |

## Group naming and lookup

Inputs: subscription **display name** (required for naming). If the ticket only has subscription id, resolve display name via ARM before lookup. Requested role: `Reader` | `Contributor` (`Writer` uses Contributor suffix).

1. Normalize subscription name: lowercase; spaces/underscores → `-` (e.g. `Jira Conf Prod` → `jira-conf-prod`).
2. Detect an environment token as a `-`-separated segment when present (`prod`, `production`, `uat`, `qa`, `dev`, `staging`, `sandbox`, `preprod`, `nonprod`, …). Canonicalize `production` → `prod` for pattern building.
3. Build role suffix: `-contributors` or `-readers`.
4. **Pattern with environment** (only when an env segment is present in the subscription name): search Entra groups whose display name:
   - starts with `sg-` + normalized subscription name (which already includes the env segment), e.g. prefix `sg-jira-conf-prod`
   - ends with the role suffix  
   Example match: `sg-jira-conf-prod-uaen-contributors` (extra tokens like region `uaen` are allowed between prefix and suffix).
5. **If no env segment in the subscription name, or step 4 yields no match:** search with prefix `sg-` + full normalized subscription name (no env requirement) and the same role suffix. Do not invent an environment from the ticket for naming; ticket/effective environment remains for approval only.
6. Match rules:
   - Exactly one suitable group → candidate.
   - Zero → create canonical group `sg-<normalized-subscription-slug>-contributors|readers` (example: `sg-ceo-sub-application-contributors`).
   - Multiple → do not guess; treat as ambiguous (PIM fallback + flag). Include candidate display names in the flag message.

Lookup uses Microsoft Graph (group displayName filter / search). Portal path Entra ID → Groups is the human equivalent; automation uses Graph/CLI equivalents.

## Role-assignment verification

Before adding a member:

- At subscription scope, list Azure RBAC role assignments (ARM: Access control / IAM equivalent).
- Confirm the candidate group’s object id is assigned the matching built-in role (Contributor `b24988ac-…` or Reader `acdd72a7-…`).
- If the group exists (or was just created) but is **not** assigned that role on the subscription → create the subscription role assignment for the group, then add the member.

## Grant data flow

```
Ticket
  → Resolve-RbacDecision (allowlist, eligibility, approval rules)
  → Deny / Escalate / wait-for-approval: unchanged
  → Authorized to fulfil (Grant, or Eligible after Provide Access):
       Resolve subscription name from id/name on ticket
       Find Entra group by naming rules (Reader/Contributor only)
       If exactly one match → use it
       If none → create canonical sg-<slug>-contributors|readers
       If ambiguous → PIM fallback + engineer flag
       Ensure group has role on subscription (create IAM if missing)
       Add user to group (permanent, idempotent if already member)
       Result: Success, Fulfilment=Group, GroupId/GroupName, GroupCreated/RoleAssignmentCreated
```

Emergency / break-glass paths that today create active PIM for P1 Contributor remain PIM unless a later change explicitly opts them into group fulfilment; default for this design: **break-glass stays PIM** (incident access should not depend on group onboarding). Sandbox and standard Prod/NonProd Reader/Contributor fulfilment use group-first.

## Revoke

- If original fulfilment was `Group` → remove user from that group.
- If `PimFallback` (or legacy PIM grant) → existing PIM revoke.
- Result objects should store enough identity (`GroupId` or assignment id) to revoke correctly.

## Duration

- Group path: **permanent** membership; ticket `DurationDays` is not applied to the group.
- PIM fallback: existing duration behavior unchanged.

## Engineer flag (minimize silent failure)

When falling back to PIM because group matches are ambiguous:

- Set a structured field on the runbook result (e.g. `EngineerActionRequired = $true`, `EngineerActionReason = '…'`).
- Write a ManageEngine / ticket note stating that access was granted via PIM fallback and an engineer should resolve the ambiguous `sg-…` group names.
- Do not fail the requester’s access solely because of ambiguity — PIM fallback satisfies access; the flag drives follow-up.

## Permissions (implementation note)

Automation identity needs (in addition to existing PIM/ARM):

- Graph: create security groups, read groups, add/remove group members (`Group.ReadWrite.All` or equivalent least-privilege plus member write).
- ARM: read and write role assignments at subscription scope (group IAM ensure + PIM fallback).

Exact consent list to be confirmed during implementation against the existing SPN.

## Error handling

| Condition | Behavior |
|-----------|----------|
| Group found + IAM OK + add succeeds | Success, `Fulfilment=Group` |
| No group → create + IAM + add | Success, `Fulfilment=Group`, `GroupCreated=true` |
| Group found, IAM missing → assign + add | Success, `Fulfilment=Group`, `RoleAssignmentCreated=true` |
| User already in group | Success (idempotent), `Fulfilment=Group` |
| Ambiguous matches | PIM fallback + engineer flag |
| Graph/ARM auth or API failure mid-grant | Fail run with clear error; do not report Success |
| Owner requested | Existing decision reject/hold — no group path |

## Testing

- Unit tests via `MockPimClient`: name match with env; name match without env; zero match → PIM + flag; IAM miss → PIM + flag; happy-path group add; already-member idempotent.
- Naming helper tests (pure functions) for normalization and pattern building.
- No live tenant required for CI.
- Optional later: one manual/scripted check against a known subscription with `sg-…-contributors` in the tenant.

## Files likely touched

- `src/PimClient/GraphPimClient.psm1` — group resolve, IAM verify, add/remove member
- `src/PimClient/MockPimClient.psm1` — mock counterparts
- `src/Runbooks/Runbook-Sandbox-PIM.ps1` (and Prod grant path) — group-first fulfilment
- Shared helper if extracted (e.g. `Invoke-GroupOrPimGrant.ps1`) to avoid duplicating logic
- `tests/unit/` — new/updated Pester coverage
- Dashboard/API result typing only if needed to surface `Fulfilment` / engineer flag in UI

## Open implementation details (non-blocking)

- Exact Graph filter vs `$search` for displayName (depends on tenant search indexing); implementation may try filter first then broader search.
- Break-glass remains PIM by default (stated above); revisit only if product owners want group-first there too.
