# RBAC role expansion — Storage, AKS, and future Azure RBAC roles — Design

**Date:** 2026-08-19
**Status:** Approved (2026-08-19) — implementation planning next

## Goal

Extend `Resolve-RbacDecision` and the PIM clients to support additional Azure RBAC roles beyond the current fixed set (Reader, Contributor, Writer, Owner, UAA, Custom) — specifically Storage Blob Data roles and Azure Kubernetes Service (AKS) RBAC roles — and establish a pattern so further Azure RBAC roles can be added by data change alone, without touching decision-tree code.

## Problem with the current design

Role support is hardcoded and duplicated across four places:

- `Test-TicketSchema.ps1` — `$validRoles` literal array
- `Get-EligibilityMatch.ps1` / `Test-RoleEligibility.ps1` — `switch ($effectiveRole) { 'Reader' {...} 'Contributor' {...} 'Owner' {...} 'UAA' {...} }` per environment
- `eligibility-matrix.json` — one row per **role name** per environment/priority (`sandbox-reader`, `prod-owner-dual`, …)
- `GraphPimClient.psm1` and `MockPimClient.psm1` — each carries its own copy of `$RoleDefinitionIds` (role name → GUID), which can silently drift out of sync

Adding one role today means editing all four. This does not scale to the ~10 additional Azure built-in roles now in scope (Storage, AKS), or to whatever roles are added after.

## Non-goals

- Changing SLA tiers, approver mapping, or the environment promotion ladder (Sandbox → NonProd → Production) — unchanged.
- Group-based fulfilment (see `2026-08-10-group-based-rbac-design.md`) for the new roles — out of scope; new roles fulfil via direct PIM assignment only, same as Owner/UAA today.
- Custom role support — unchanged (`Hold` / Governance-Review path).

**Amendment (2026-08-19):** the `roleDefinitionId` GUIDs below were verified against the live tenant via `az role definition list` — all seven match. Rollout step 1 is satisfied.

## Roles in scope

Every role is classified into one of the three existing risk tiers. Tier behavior is unchanged from today's Reader/Contributor/Owner rules:

| Tier | Sandbox | NonProd | Production |
|------|---------|---------|------------|
| Reader | Auto-grant | Auto-grant | Auto-grant |
| Contributor | Auto-grant | Single-approver eligible | Single-approver eligible (dual + on-call if expedited) |
| Owner | **Blocked** (Policy-Block) | **Blocked** (Policy-Block) | Dual-approver eligible, MFA required |

New roles and their tier:

| Role | Tier | Scope type | Azure resource type |
|------|------|-----------|----------------------|
| Storage Blob Data Reader | Reader | Resource | `Microsoft.Storage/storageAccounts` |
| Storage Blob Data Contributor | Contributor | Resource | `Microsoft.Storage/storageAccounts` |
| Storage Blob Data Owner | Owner | Resource | `Microsoft.Storage/storageAccounts` |
| Azure Kubernetes Service RBAC Reader | Reader | Resource | `Microsoft.ContainerService/managedClusters` |
| Azure Kubernetes Service RBAC Writer | Contributor | Resource | `Microsoft.ContainerService/managedClusters` |
| Azure Kubernetes Service RBAC Admin | Contributor | Resource | `Microsoft.ContainerService/managedClusters` |
| Azure Kubernetes Service RBAC Cluster Admin | Owner | Resource | `Microsoft.ContainerService/managedClusters` |

Existing roles keep their current tier and scope type for continuity:

| Role | Tier | Scope type |
|------|------|-----------|
| Reader | Reader | Subscription |
| Contributor | Contributor | Subscription |
| Writer (alias of Contributor) | Contributor | Subscription |
| Owner | Owner | Subscription |
| UAA | Owner | Subscription |

## Architecture

**Approach:** introduce a single role catalog as the source of truth for role metadata; make the decision engine and both PIM clients read from it instead of hardcoding role names/GUIDs.

| Layer | Responsibility |
|-------|----------------|
| `role-catalog.json` (new) | One entry per supported role: tier, `roleDefinitionId`, scope type, resource type (for resource-scoped roles). |
| `Test-TicketSchema` | Validates `Ticket.Role` against catalog keys instead of a literal array. Validates `ResourceScope` shape against the role's scope type. |
| `Test-RoleEligibility` / `Get-EligibilityMatch` | Resolve the ticket's role to its **tier** via the catalog, then switch on tier (not role name) for environment/priority routing. |
| `eligibility-matrix.json` | Rows keyed by tier instead of role name (e.g. `sandbox-contributor-tier` replaces `sandbox-contributor`); `policyBlocks.sandboxBlockedRoles` / `nonProdBlockedRoles` become tier lists (`["Owner"]`). |
| `GraphPimClient` / `MockPimClient` | `Get-RoleDefinitionId` reads from the shared catalog instead of each carrying its own hashtable. |

No changes needed to ARM/Graph routing in `GraphPimClient` (`New-ArmPimRequest`, `Get-ActiveAssignments`, `Remove-PimAssignment`, etc.) — these already branch on `$Scope -match '^/subscriptions/'`, and all new roles' scopes (storage account, AKS cluster) live under `/subscriptions/.../resourceGroups/...`, so they already route through the existing ARM PIM path correctly.

## Role catalog schema

New file: `src/RbacDecision/Data/role-catalog.json`

```json
{
  "Reader":       { "tier": "Reader",      "roleDefinitionId": "acdd72a7-3385-48ef-bd42-f606fba81ae7", "scopeType": "subscription" },
  "Contributor":  { "tier": "Contributor", "roleDefinitionId": "b24988ac-6180-42a0-ab88-20f7382dd24c", "scopeType": "subscription" },
  "Writer":       { "tier": "Contributor", "roleDefinitionId": "b24988ac-6180-42a0-ab88-20f7382dd24c", "scopeType": "subscription", "aliasOf": "Contributor" },
  "Owner":        { "tier": "Owner",       "roleDefinitionId": "8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d", "scopeType": "subscription" },
  "UAA":          { "tier": "Owner",       "roleDefinitionId": "18d7d88d-d35e-4fb5-a5c3-7773c20a72d9", "scopeType": "subscription" },

  "Storage Blob Data Reader":                    { "tier": "Reader",      "roleDefinitionId": "2a2b9908-6ea1-4ae2-8e65-a410df84e7d1", "scopeType": "resource", "resourceType": "Microsoft.Storage/storageAccounts" },
  "Storage Blob Data Contributor":               { "tier": "Contributor", "roleDefinitionId": "ba92f5b4-2d11-453d-a403-e96b0029c9fe", "scopeType": "resource", "resourceType": "Microsoft.Storage/storageAccounts" },
  "Storage Blob Data Owner":                     { "tier": "Owner",       "roleDefinitionId": "b7e6dc6d-f1e8-4753-8033-0f276bb0955b", "scopeType": "resource", "resourceType": "Microsoft.Storage/storageAccounts" },

  "Azure Kubernetes Service RBAC Reader":        { "tier": "Reader",      "roleDefinitionId": "7f6c6a51-bcf8-42ba-9220-52d62157d7db", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },
  "Azure Kubernetes Service RBAC Writer":        { "tier": "Contributor", "roleDefinitionId": "a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },
  "Azure Kubernetes Service RBAC Admin":         { "tier": "Contributor", "roleDefinitionId": "3498e952-d568-435e-9b2c-8d77e338d7f7", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },
  "Azure Kubernetes Service RBAC Cluster Admin": { "tier": "Owner",       "roleDefinitionId": "b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },

  "Custom": { "tier": "Custom", "scopeType": "any" }
}
```

`Custom` keeps its existing special-cased behavior (`Hold` / Governance-Review) in `Test-RoleEligibility` — it is listed in the catalog for schema validation purposes only, not tier routing.

## Decision-engine changes

### `Test-TicketSchema`

- Replace `$validRoles = @('Reader', 'Contributor', 'Writer', 'Owner', 'UAA', 'Custom')` with role names loaded from `role-catalog.json` (passed in or loaded via a new `$RoleCatalogPath` parameter, mirroring the existing `$MatrixPath`/`$ApproverMappingPath`/`$SensitivityMapPath` pattern in `Resolve-RbacDecision`).
- Extend `ResourceScope` validation: the existing prefix check (`^/(subscriptions|resourceGroups)/`) stays for all roles. For a role whose catalog entry has `scopeType: "resource"`, additionally require the scope to contain a segment matching that role's `resourceType` (e.g. `.../providers/Microsoft.Storage/storageAccounts/<name>`). This catches a ticket requesting "Storage Blob Data Contributor" against a bare subscription or resource-group scope, which would otherwise be accepted but fail at the PIM API call.
- Error message updated to reflect catalog-driven role list instead of the static "Supported access roles: Reader, Contributor, Writer" string.

### `Test-RoleEligibility` / `Get-EligibilityMatch`

- Both resolve `Ticket.Role` → tier via the catalog first (`$tier = $RoleCatalog.$($Ticket.Role).tier`), then apply the same environment/priority logic that exists today, but switching on tier instead of role name.
- `Get-EligibilityMatch`'s existing `Writer` → `Contributor` aliasing logic generalizes: any catalog entry with `aliasOf` resolves to the aliased role's tier (Writer already models this pattern; the catalog makes it declarative instead of a one-off `if` check).
- `custom-role-hold` and `bulk-request-hold` special cases are unaffected — they run before tier resolution, same as today.

### `eligibility-matrix.json`

- Row `id`s and lookup keys change from role name to tier: `sandbox-reader` → `sandbox-reader-tier`, `prod-contributor-standard` → `prod-contributor-tier-standard`, `prod-owner-dual` → `prod-owner-tier-dual`, etc. (naming illustrative; exact IDs finalized during implementation.)
- `policyBlocks.sandboxBlockedRoles` and `policyBlocks.nonProdBlockedRoles` change from role-name lists (`["Owner", "UAA"]`) to a single tier list (`["Owner"]`) — any current or future Owner-tier role is blocked in Sandbox/NonProd automatically, with no matrix edit needed when a new Owner-tier role is added later.
- Row count does not grow with each new role — only with new tiers or new environment/priority combinations, which remain rare.

## Amendment (2026-08-19) — two gaps found during implementation recon

Both were discovered by reading the fulfilment path after the spec was approved, and both would break the new roles at runtime. Resolutions were agreed before implementation began.

### Gap 1 — approver resolution returns an empty list

`approver-mapping.json` is keyed by literal role name, and `Resolve-RbacDecision.ps1:150` looks up `$subMapping.roles.$role`. A Production `Storage Blob Data Contributor` request would classify as `Eligible` with `Approvers = @()` — an approval-gated grant with no approver to notify.

**Resolution — tier fallback.** Approver lookup tries the exact role name first, then falls back to the role's tier entry (`Reader` / `Contributor` / `Owner`) already present in the mapping. Existing per-role mappings continue to win, so current behavior is unchanged; future roles inherit their tier's approvers with no config edit. Owner-tier roles therefore inherit the existing dual-approval `Owner` approver entry.

### Gap 2 — sandbox runbook hard-throws on unknown roles

`Runbook-Sandbox-PIM.ps1:49` throws `"Granted role '<x>' is not supported by the sandbox group-first runbook."` for any role outside `Reader/Contributor/Writer`. The matrix routes **all** Reader-tier grants and Sandbox Contributor-tier grants to this runbook, so `Azure Kubernetes Service RBAC Reader` would classify correctly and then crash at fulfilment. `Invoke-GroupOrPimGrant` enforces the same restriction internally via `Get-RbacGroupRoleSuffix`.

**Resolution — gate the group path on `scopeType`.** The runbook consults the catalog: `scopeType: "subscription"` roles keep today's group-first fulfilment unchanged; `scopeType: "resource"` roles bypass the group path entirely and take a direct PIM active assignment at the resource scope. This is what the non-goal ("new roles fulfil via direct PIM assignment only") requires in code. `Get-RbacGroupRoleSuffix` and `Invoke-GroupOrPimGrant` are left untouched — the gate happens before they are called.

## PIM client changes

### `GraphPimClient.psm1` / `MockPimClient.psm1`

- Remove the duplicated `$script:RoleDefinitionIds` hashtable from both files.
- `Get-RoleDefinitionId -RoleName` becomes a shared lookup against the catalog (loaded once, passed to both clients — likely via a new small helper in `RbacDecision` exported for clients to consume, avoiding a second duplicated copy).
- Behavior unchanged: unknown role name still throws `"Unknown role: $RoleName"`.
- No changes to `New-ArmPimRequest`, `Get-ActiveAssignments`, `Get-EligibleAssignments`, `New-ActiveAssignment`, `New-EligibleAssignment`, or `Remove-PimAssignment` — all are scope-shape-driven (`^/subscriptions/`) already and handle the new roles' resource-level scopes correctly with no modification.

## Data flow (unchanged shape, tier-aware)

```
Ticket { Role: 'Storage Blob Data Contributor', ResourceScope: '/subscriptions/.../storageAccounts/mystorage', Environment: 'Production', ... }
  → Test-TicketSchema        (role known in catalog? scope shape matches resourceType?)
  → Test-RoleEligibility     (tier = Contributor; not blocked)
  → Get-EligibilityMatch     (tier = Contributor + Production + priority → same matrix row Contributor-tier already uses)
  → Eligible / Grant / Reject / Hold (unchanged decision record shape)
  → Runbook → GraphPimClient.Get-RoleDefinitionId('Storage Blob Data Contributor') → catalog lookup → ARM PIM request at the storage account scope
```

## Testing

- `tests/unit/RbacDecision.Tests.ps1`: add cases for each new role × environment (Sandbox/NonProd/Production), asserting the same action/path/SLA as the existing same-tier role today (e.g. Storage Blob Data Contributor in Production/P3 should produce an identical decision shape to Contributor in Production/P3, modulo role name). Add a schema-validation case for `ResourceScope` not matching the role's `resourceType`.
- `tests/contract/PimClient.Tests.ps1`: add a case asserting `Get-RoleDefinitionId` resolves every catalog entry for both `MockPimClient` and `GraphPimClient`, and that both clients resolve to the same GUID per role (regression guard against the hashtables drifting again).
- `tests/unit/*` for the catalog itself: a small test asserting `role-catalog.json` is valid JSON, every entry has a `tier` in `{Reader, Contributor, Owner, Custom}`, and every `scopeType: resource` entry has a `resourceType`.

## Rollout

1. ~~Confirm the seven new `roleDefinitionId` GUIDs against the live tenant.~~ **Done 2026-08-19** — all seven verified via `az role definition list --name "<role name>"`.
2. Ship catalog + decision-engine + PIM-client + runbook-gate changes together (they are not independently useful — the catalog is dead data without the code reading it, and the decision changes are unsafe without the runbook gate from Gap 2).
3. No changes to `infra/pim/rolesettings.*.json` are anticipated (those govern PIM policy settings like MFA/approval requirements per role, which are configured separately in Entra/Azure — confirm during implementation whether new roles need corresponding PIM role settings registered there).
4. Baseline before starting: `.\tests\Run-Pester.ps1` → 330 passed, 0 failed (2026-08-19). No existing test may regress.
