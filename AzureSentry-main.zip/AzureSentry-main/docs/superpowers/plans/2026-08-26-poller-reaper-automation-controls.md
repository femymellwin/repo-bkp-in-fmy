# Poller/Reaper Automation Controls Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the poller/reaper's three-layer automation gating (systemd timer + env-only kill switch + Enforce Mode toggle) with a single UI-reachable Off/Rehearse/Live control per agent, plus UI-editable per-cycle caps, while leaving the env-var path and the existing `poller.mode`/`reaper.mode` mechanism completely untouched.

**Architecture:** Two new override files per agent (`*.enabled`, `*.caps.json`), read by `Get-PollerConfig`/`Get-ReaperConfig` using the exact same checked-before-env, fail-closed pattern `*.mode` already implements. Four new API routes per agent-pair mirror the existing `/api/poller/mode` handler's structure line for line. The dashboard UI composes the enabled+mode calls into one 3-way control.

**Tech Stack:** PowerShell 5.1/7 (Pester 5.x tests), React + TypeScript + MUI (dashboard/web), Node/Vite.

**Spec:** `docs/superpowers/specs/2026-08-26-poller-reaper-automation-controls-design.md`

## Global Constraints

- Justification (≥4 chars) required only on the escalating action: arming automation (`enabled:true`), raising `maxGrants`/`maxRevokes`. Never required to disarm or lower a cap.
- All new override files use `[System.IO.File]::WriteAllBytes` with `[System.Text.Encoding]::UTF8.GetBytes(...)` — never `Set-Content -Encoding utf8` (emits a BOM on PS 5.1 but not pwsh 7; the poller reads with pwsh 7 in production, see the identical comment on the existing `/api/poller/mode` handler).
- Malformed/unparseable override content always fails closed to the least-permissive value (`false` for enabled, full env fallback for caps) — never guessed, never a silent fall-through.
- `poller.mode`/`reaper.mode` file format, routes, audit actions, and existing tests are **not modified** by this plan.
- Route handlers get no new Pester coverage (matches existing practice for `/api/poller/mode`); config-reading functions (`Get-PollerConfig`/`Get-ReaperConfig`) get full TDD coverage.

---

### Task 1: `Get-PollerConfig` — enabled + caps overrides

**Files:**
- Modify: `src/Agents/TicketPollerAgent.ps1:15-104` (the `Get-PollerConfig` function)
- Test: `tests/unit/TicketPollerAgent.Tests.ps1` (new `It` blocks inside the existing `Describe 'Get-PollerConfig'` block, added after the last existing test in that block — the one ending `It 'derives a default mode-override file path...'` around line 279)

**Interfaces:**
- Produces: `Get-PollerConfig` gains params `-EnabledOverrideFilePath [string]`, `-CapsOverrideFilePath [string]`. Return object gains `EnabledSource` (`'env'|'override'`), `EnabledOverrideFilePath` (`string`), `MaxGrantsSource`/`MaxTicketsSource`/`MaxAgeDaysSource` (`'env'|'override'`), `CapsOverrideFilePath` (`string`). Existing fields (`Enabled`, `MaxGrantsPerCycle`, `MaxTicketsPerCycle`, `MaxTicketAgeDays`, `Mode`, `ModeSource`, `ModeOverrideFilePath`, `StopFilePath`) keep their exact current names and meaning.

- [ ] **Step 1: Write the failing tests**

Add these `It` blocks inside the existing `Describe 'Get-PollerConfig'` block in `tests/unit/TicketPollerAgent.Tests.ps1`, immediately after the test `It 'derives a default mode-override file path next to the default stop file when neither is set'` and before that `Describe` block's closing `}`:

```powershell
    # POST/DELETE /api/poller/enabled (Start-DashboardApi.ps1, Task 3) write/remove
    # exactly this file. Mirrors the -ModeOverrideFilePath tests above exactly.
    It 'ignores an enabled-override file that does not exist and falls back to the env var' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'true'
        try {
            $missing = Join-Path $TestDrive 'no-such.enabled'
            $c = Get-PollerConfig -EnabledOverrideFilePath $missing
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing true wins over an env var of false' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'false'
        try {
            $enabledFile = Join-Path $TestDrive 'a.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'true' -NoNewline
            $c = Get-PollerConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing false wins over an env var of true (the toggle can always turn automation off)' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'b.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'false' -NoNewline
            $c = Get-PollerConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file with unrecognised content fails closed to false, even with an env var of true' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'c.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'TRUE-ish garbage' -NoNewline
            $c = Get-PollerConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'trims whitespace and ignores case in the enabled-override file content' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'false'
        try {
            $enabledFile = Join-Path $TestDrive 'd.enabled'
            Set-Content -LiteralPath $enabledFile -Value "  TRUE`r`n" -NoNewline
            (Get-PollerConfig -EnabledOverrideFilePath $enabledFile).Enabled | Should -BeTrue
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default enabled-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_POLLER_ENABLED_FILE
        Remove-Item Env:\AZURESENTRY_POLLER_ENABLED_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-PollerConfig).EnabledOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'poller\.enabled$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED_FILE = $old }
        }
    }

    # POST/DELETE /api/poller/caps (Start-DashboardApi.ps1, Task 3) write/remove this file.
    It 'ignores a caps-override file that does not exist and uses the env vars for all three fields' {
        $old = $env:AZURESENTRY_POLLER_MAX_GRANTS
        $env:AZURESENTRY_POLLER_MAX_GRANTS = '9'
        try {
            $missing = Join-Path $TestDrive 'no-such.caps.json'
            $c = Get-PollerConfig -CapsOverrideFilePath $missing
            $c.MaxGrantsPerCycle | Should -Be 9
            $c.MaxGrantsSource | Should -Be 'env'
            $c.MaxTicketsPerCycle | Should -Be 100
            $c.MaxTicketsSource | Should -Be 'env'
            $c.MaxTicketAgeDays | Should -Be 7
            $c.MaxAgeDaysSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MAX_GRANTS = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MAX_GRANTS -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file overriding only maxGrants leaves maxTickets and maxAgeDays reading from env, independently' {
        $capsFile = Join-Path $TestDrive 'partial.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{"maxGrants": 20}' -NoNewline
        $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
        $c.MaxGrantsPerCycle | Should -Be 20
        $c.MaxGrantsSource | Should -Be 'override'
        $c.MaxTicketsPerCycle | Should -Be 100
        $c.MaxTicketsSource | Should -Be 'env'
        $c.MaxTicketAgeDays | Should -Be 7
        $c.MaxAgeDaysSource | Should -Be 'env'
    }

    It 'a caps file overriding all three fields wins for all three, independently of env' {
        $old = $env:AZURESENTRY_POLLER_MAX_GRANTS
        $env:AZURESENTRY_POLLER_MAX_GRANTS = '5'
        try {
            $capsFile = Join-Path $TestDrive 'full.caps.json'
            Set-Content -LiteralPath $capsFile -Value '{"maxGrants": 12, "maxTickets": 50, "maxAgeDays": 3}' -NoNewline
            $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
            $c.MaxGrantsPerCycle | Should -Be 12
            $c.MaxTicketsPerCycle | Should -Be 50
            $c.MaxTicketAgeDays | Should -Be 3
            $c.MaxGrantsSource | Should -Be 'override'
            $c.MaxTicketsSource | Should -Be 'override'
            $c.MaxAgeDaysSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MAX_GRANTS = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MAX_GRANTS -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file that is not parseable JSON at all is ignored entirely -- full fallback to env, no throw' {
        $capsFile = Join-Path $TestDrive 'broken.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{not valid json' -NoNewline
        { Get-PollerConfig -CapsOverrideFilePath $capsFile } | Should -Not -Throw
        $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
        $c.MaxGrantsPerCycle | Should -Be 5
        $c.MaxGrantsSource | Should -Be 'env'
    }

    It 'a caps file with a non-positive-integer value for one key falls back to env for that key only' {
        $capsFile = Join-Path $TestDrive 'bad-value.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{"maxGrants": 0, "maxTickets": 30}' -NoNewline
        $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
        $c.MaxGrantsPerCycle | Should -Be 5
        $c.MaxGrantsSource | Should -Be 'env'
        $c.MaxTicketsPerCycle | Should -Be 30
        $c.MaxTicketsSource | Should -Be 'override'
    }

    It 'derives a default caps-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_POLLER_CAPS_FILE
        Remove-Item Env:\AZURESENTRY_POLLER_CAPS_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-PollerConfig).CapsOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'poller\.caps\.json$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_CAPS_FILE = $old }
        }
    }
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pwsh -NoProfile -Command "Invoke-Pester -Path .\tests\unit\TicketPollerAgent.Tests.ps1 -Output Detailed" 2>&1 | Select-String -Pattern 'enabled-override|caps-override|caps file|Failed:'`
Expected: every new test FAILs — `Get-PollerConfig` has no `-EnabledOverrideFilePath` or `-CapsOverrideFilePath` parameter yet, so PowerShell throws a parameter-binding error for each.

- [ ] **Step 3: Implement — edit `Get-PollerConfig`**

In `src/Agents/TicketPollerAgent.ps1`, find this exact block (the function's `param()` line):

```powershell
    param(
        [string]$StopFilePath = '',
        [string]$ModeOverrideFilePath = ''
    )
```

Replace it with:

```powershell
    param(
        [string]$StopFilePath = '',
        [string]$ModeOverrideFilePath = '',
        [string]$EnabledOverrideFilePath = '',
        [string]$CapsOverrideFilePath = ''
    )
```

Find this exact block (right after `$modeFile` is resolved, before `$modeSource = 'env'`):

```powershell
    $modeFile = ([string]$ModeOverrideFilePath).Trim()
    if (-not $modeFile) { $modeFile = ([string]$env:AZURESENTRY_POLLER_MODE_FILE).Trim() }
    if (-not $modeFile) { $modeFile = Join-Path (& $defaultDir) 'poller.mode' }

    $modeSource = 'env'
```

Replace it with:

```powershell
    $modeFile = ([string]$ModeOverrideFilePath).Trim()
    if (-not $modeFile) { $modeFile = ([string]$env:AZURESENTRY_POLLER_MODE_FILE).Trim() }
    if (-not $modeFile) { $modeFile = Join-Path (& $defaultDir) 'poller.mode' }

    $enabledFile = ([string]$EnabledOverrideFilePath).Trim()
    if (-not $enabledFile) { $enabledFile = ([string]$env:AZURESENTRY_POLLER_ENABLED_FILE).Trim() }
    if (-not $enabledFile) { $enabledFile = Join-Path (& $defaultDir) 'poller.enabled' }

    $capsFile = ([string]$CapsOverrideFilePath).Trim()
    if (-not $capsFile) { $capsFile = ([string]$env:AZURESENTRY_POLLER_CAPS_FILE).Trim() }
    if (-not $capsFile) { $capsFile = Join-Path (& $defaultDir) 'poller.caps.json' }

    $modeSource = 'env'
```

Find this exact block (the mode-override check, right before `return`):

```powershell
    $modeSource = 'override'
        $override = ''
        try { $override = (Get-Content -Raw -LiteralPath $modeFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $override = '' }
        $mode = if ($override -eq 'enforce') { 'enforce' } else { 'shadow' }
    }

    return [pscustomobject]@{
        Enabled               = $enabled
        Mode                  = $mode
        ModeSource            = $modeSource
        ModeOverrideFilePath  = $modeFile
```

Replace it with:

```powershell
    $modeSource = 'override'
        $override = ''
        try { $override = (Get-Content -Raw -LiteralPath $modeFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $override = '' }
        $mode = if ($override -eq 'enforce') { 'enforce' } else { 'shadow' }
    }

    $enabledSource = 'env'
    if (Test-Path -LiteralPath $enabledFile) {
        $enabledSource = 'override'
        $enabledOverride = ''
        try { $enabledOverride = (Get-Content -Raw -LiteralPath $enabledFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $enabledOverride = '' }
        $enabled = ($enabledOverride -eq 'true')
    }

    $maxTicketsSource = 'env'
    $maxGrantsSource = 'env'
    $maxAgeDaysSource = 'env'
    $maxTickets = (& $asInt $env:AZURESENTRY_POLLER_MAX_TICKETS 100)
    $maxGrants = (& $asInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5)
    $maxAgeDays = (& $asInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7)
    if (Test-Path -LiteralPath $capsFile) {
        $capsJson = $null
        try { $capsJson = Get-Content -Raw -LiteralPath $capsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { $capsJson = $null }
        if ($capsJson) {
            if ($capsJson.PSObject.Properties.Name -contains 'maxTickets') {
                $n = 0
                if ([int]::TryParse([string]$capsJson.maxTickets, [ref]$n) -and $n -gt 0) { $maxTickets = $n; $maxTicketsSource = 'override' }
            }
            if ($capsJson.PSObject.Properties.Name -contains 'maxGrants') {
                $n = 0
                if ([int]::TryParse([string]$capsJson.maxGrants, [ref]$n) -and $n -gt 0) { $maxGrants = $n; $maxGrantsSource = 'override' }
            }
            if ($capsJson.PSObject.Properties.Name -contains 'maxAgeDays') {
                $n = 0
                if ([int]::TryParse([string]$capsJson.maxAgeDays, [ref]$n) -and $n -gt 0) { $maxAgeDays = $n; $maxAgeDaysSource = 'override' }
            }
        }
    }

    return [pscustomobject]@{
        Enabled                  = $enabled
        EnabledSource            = $enabledSource
        EnabledOverrideFilePath  = $enabledFile
        Mode                     = $mode
        ModeSource               = $modeSource
        ModeOverrideFilePath     = $modeFile
```

Finally, find this exact block (the three cap fields plus `StopFilePath`, at the end of the return object):

```powershell
        MaxTicketsPerCycle    = (& $asInt $env:AZURESENTRY_POLLER_MAX_TICKETS 100)
        MaxGrantsPerCycle     = (& $asInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5)
        MaxTicketAgeDays      = (& $asInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7)
        StopFilePath          = $stopFile
    }
}
```

Replace it with:

```powershell
        MaxTicketsPerCycle    = $maxTickets
        MaxTicketsSource      = $maxTicketsSource
        MaxGrantsPerCycle     = $maxGrants
        MaxGrantsSource       = $maxGrantsSource
        MaxTicketAgeDays      = $maxAgeDays
        MaxAgeDaysSource      = $maxAgeDaysSource
        CapsOverrideFilePath  = $capsFile
        StopFilePath          = $stopFile
    }
}
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pwsh -NoProfile -Command "Invoke-Pester -Path .\tests\unit\TicketPollerAgent.Tests.ps1 -Output Detailed" 2>&1 | Select-String -Pattern 'Tests Passed|Failed:'`
Expected: `Failed: 0`, and the count of passed tests includes the ~11 new ones from Step 1.

- [ ] **Step 5: Commit**

```bash
git add src/Agents/TicketPollerAgent.ps1 tests/unit/TicketPollerAgent.Tests.ps1
git commit -m "feat(poller): add enabled + caps override files to Get-PollerConfig"
```

---

### Task 2: `Get-ReaperConfig` — enabled + caps override

**Files:**
- Modify: `src/Agents/ReaperAgent.ps1:134-210` (the `Get-ReaperConfig` function)
- Test: `tests/unit/ReaperAgent.Tests.ps1` (new `It` blocks — find the existing `Describe` block containing `Get-ReaperConfig`'s mode-override tests, which mirror the poller's exactly per `ReaperAgent.ps1`'s own docstring; add the new tests at the end of that block, same way as Task 1)

**Interfaces:**
- Consumes: nothing from Task 1 (parallel function, same file family, no shared code).
- Produces: `Get-ReaperConfig` gains `-EnabledOverrideFilePath`, `-CapsOverrideFilePath`. Return object gains `EnabledSource`, `EnabledOverrideFilePath`, `MaxRevokesSource`, `CapsOverrideFilePath`. Existing fields unchanged.

- [ ] **Step 1: Write the failing tests**

First, open `tests/unit/ReaperAgent.Tests.ps1` and locate the `Describe` block containing the reaper's mode-override tests (structurally identical to the poller's — look for `-ModeOverrideFilePath` and `AZURESENTRY_REAPER_MODE`). Add these `It` blocks at the end of that same `Describe` block:

```powershell
    It 'ignores an enabled-override file that does not exist and falls back to the env var' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'true'
        try {
            $missing = Join-Path $TestDrive 'no-such.enabled'
            $c = Get-ReaperConfig -EnabledOverrideFilePath $missing
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing true wins over an env var of false' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'false'
        try {
            $enabledFile = Join-Path $TestDrive 'a.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'true' -NoNewline
            $c = Get-ReaperConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing false wins over an env var of true' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'b.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'false' -NoNewline
            $c = Get-ReaperConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file with unrecognised content fails closed to false' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'c.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'TRUE-ish garbage' -NoNewline
            $c = Get-ReaperConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default enabled-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_REAPER_ENABLED_FILE
        Remove-Item Env:\AZURESENTRY_REAPER_ENABLED_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-ReaperConfig).EnabledOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'reaper\.enabled$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED_FILE = $old }
        }
    }

    It 'ignores a caps-override file that does not exist and uses the env var' {
        $old = $env:AZURESENTRY_REAPER_MAX_REVOKES
        $env:AZURESENTRY_REAPER_MAX_REVOKES = '9'
        try {
            $missing = Join-Path $TestDrive 'no-such.caps.json'
            $c = Get-ReaperConfig -CapsOverrideFilePath $missing
            $c.MaxRevokesPerCycle | Should -Be 9
            $c.MaxRevokesSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MAX_REVOKES = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MAX_REVOKES -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file overriding maxRevokes wins over the env var' {
        $old = $env:AZURESENTRY_REAPER_MAX_REVOKES
        $env:AZURESENTRY_REAPER_MAX_REVOKES = '25'
        try {
            $capsFile = Join-Path $TestDrive 'a.caps.json'
            Set-Content -LiteralPath $capsFile -Value '{"maxRevokes": 40}' -NoNewline
            $c = Get-ReaperConfig -CapsOverrideFilePath $capsFile
            $c.MaxRevokesPerCycle | Should -Be 40
            $c.MaxRevokesSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MAX_REVOKES = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MAX_REVOKES -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file that is not parseable JSON at all is ignored entirely -- full fallback to env, no throw' {
        $capsFile = Join-Path $TestDrive 'broken.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{not valid json' -NoNewline
        { Get-ReaperConfig -CapsOverrideFilePath $capsFile } | Should -Not -Throw
        (Get-ReaperConfig -CapsOverrideFilePath $capsFile).MaxRevokesSource | Should -Be 'env'
    }

    It 'derives a default caps-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_REAPER_CAPS_FILE
        Remove-Item Env:\AZURESENTRY_REAPER_CAPS_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-ReaperConfig).CapsOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'reaper\.caps\.json$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_CAPS_FILE = $old }
        }
    }
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pwsh -NoProfile -Command "Invoke-Pester -Path .\tests\unit\ReaperAgent.Tests.ps1 -Output Detailed" 2>&1 | Select-String -Pattern 'enabled-override|caps file|Failed:'`
Expected: every new test FAILs — unbound parameter errors.

- [ ] **Step 3: Implement — edit `Get-ReaperConfig`**

In `src/Agents/ReaperAgent.ps1`, find this exact block:

```powershell
    param(
        [string]$StopFilePath = '',
        [string]$ModeOverrideFilePath = ''
    )
```

Replace it with:

```powershell
    param(
        [string]$StopFilePath = '',
        [string]$ModeOverrideFilePath = '',
        [string]$EnabledOverrideFilePath = '',
        [string]$CapsOverrideFilePath = ''
    )
```

Find this exact block:

```powershell
    $modeFile = ([string]$ModeOverrideFilePath).Trim()
    if (-not $modeFile) { $modeFile = ([string]$env:AZURESENTRY_REAPER_MODE_FILE).Trim() }
    if (-not $modeFile) { $modeFile = Join-Path (& $defaultDir) 'reaper.mode' }

    $modeSource = 'env'
```

Replace it with:

```powershell
    $modeFile = ([string]$ModeOverrideFilePath).Trim()
    if (-not $modeFile) { $modeFile = ([string]$env:AZURESENTRY_REAPER_MODE_FILE).Trim() }
    if (-not $modeFile) { $modeFile = Join-Path (& $defaultDir) 'reaper.mode' }

    $enabledFile = ([string]$EnabledOverrideFilePath).Trim()
    if (-not $enabledFile) { $enabledFile = ([string]$env:AZURESENTRY_REAPER_ENABLED_FILE).Trim() }
    if (-not $enabledFile) { $enabledFile = Join-Path (& $defaultDir) 'reaper.enabled' }

    $capsFile = ([string]$CapsOverrideFilePath).Trim()
    if (-not $capsFile) { $capsFile = ([string]$env:AZURESENTRY_REAPER_CAPS_FILE).Trim() }
    if (-not $capsFile) { $capsFile = Join-Path (& $defaultDir) 'reaper.caps.json' }

    $modeSource = 'env'
```

Find this exact block:

```powershell
    $modeSource = 'override'
        $override = ''
        try { $override = (Get-Content -Raw -LiteralPath $modeFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $override = '' }
        $mode = if ($override -eq 'enforce') { 'enforce' } else { 'shadow' }
    }

    return [pscustomobject]@{
        Enabled               = $enabled
        Mode                  = $mode
        ModeSource            = $modeSource
        ModeOverrideFilePath  = $modeFile
```

Replace it with:

```powershell
    $modeSource = 'override'
        $override = ''
        try { $override = (Get-Content -Raw -LiteralPath $modeFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $override = '' }
        $mode = if ($override -eq 'enforce') { 'enforce' } else { 'shadow' }
    }

    $enabledSource = 'env'
    if (Test-Path -LiteralPath $enabledFile) {
        $enabledSource = 'override'
        $enabledOverride = ''
        try { $enabledOverride = (Get-Content -Raw -LiteralPath $enabledFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $enabledOverride = '' }
        $enabled = ($enabledOverride -eq 'true')
    }

    $maxRevokesSource = 'env'
    $maxRevokes = (& $asInt $env:AZURESENTRY_REAPER_MAX_REVOKES 25)
    if (Test-Path -LiteralPath $capsFile) {
        $capsJson = $null
        try { $capsJson = Get-Content -Raw -LiteralPath $capsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { $capsJson = $null }
        if ($capsJson -and ($capsJson.PSObject.Properties.Name -contains 'maxRevokes')) {
            $n = 0
            if ([int]::TryParse([string]$capsJson.maxRevokes, [ref]$n) -and $n -gt 0) { $maxRevokes = $n; $maxRevokesSource = 'override' }
        }
    }

    return [pscustomobject]@{
        Enabled                  = $enabled
        EnabledSource            = $enabledSource
        EnabledOverrideFilePath  = $enabledFile
        Mode                     = $mode
        ModeSource               = $modeSource
        ModeOverrideFilePath     = $modeFile
```

Find this exact block (end of the return object):

```powershell
        MaxRevokesPerCycle    = (& $asInt $env:AZURESENTRY_REAPER_MAX_REVOKES 25)
        StopFilePath          = $stopFile
```

Replace it with:

```powershell
        MaxRevokesPerCycle    = $maxRevokes
        MaxRevokesSource      = $maxRevokesSource
        CapsOverrideFilePath  = $capsFile
        StopFilePath          = $stopFile
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pwsh -NoProfile -Command "Invoke-Pester -Path .\tests\unit\ReaperAgent.Tests.ps1 -Output Detailed" 2>&1 | Select-String -Pattern 'Tests Passed|Failed:'`
Expected: `Failed: 0`.

- [ ] **Step 5: Commit**

```bash
git add src/Agents/ReaperAgent.ps1 tests/unit/ReaperAgent.Tests.ps1
git commit -m "feat(reaper): add enabled + caps override files to Get-ReaperConfig"
```

---

### Task 3: Poller API routes — `/api/poller/enabled`, `/api/poller/caps`, status extension

**Files:**
- Modify: `dashboard/api/Start-DashboardApi.ps1` — the `/api/poller/status` GET handler (currently ending `continue` around line 1629), and immediately after the existing `/api/poller/mode` DELETE handler (ending `continue` around line 1700, right before the `/api/reaper/status` GET handler begins around line 1703)

**Interfaces:**
- Consumes: nothing from Tasks 1–2 directly — this task deliberately does **not** call `Get-PollerConfig` (it is not dot-sourced into this process; only `PollerGate.ps1` is). It replicates the minimal env/file-fallback read logic locally, exactly as the existing `/api/poller/mode` handlers already do for `poller.mode`.
- Produces: `POST/DELETE /api/poller/enabled`, `POST/DELETE /api/poller/caps`; `GET /api/poller/status` response gains `enabledOverride` and `caps`.

- [ ] **Step 1: Extend the `/api/poller/status` GET response**

In `dashboard/api/Start-DashboardApi.ps1`, find this exact block:

```powershell
                $modeFile = Join-Path $apiRoot 'poller.mode'
                $modeOverridePresent = Test-Path -LiteralPath $modeFile
                $modeOverrideValue = $null
                if ($modeOverridePresent) {
                    try { $modeOverrideValue = (Get-Content -Raw -LiteralPath $modeFile).Trim().ToLowerInvariant() } catch { $modeOverrideValue = $null }
                }

                Write-JsonResponse -Response $response -Body @{
                    configured  = (Test-Path $statusPath)
                    enabled     = $view.Enabled
                    mode        = $view.Mode
                    stale       = $view.Stale
                    stopFilePresent = (Test-Path $stopPath)
                    lastCycle   = $last
                    modeOverride = @{
                        present  = $modeOverridePresent
                        value    = $modeOverrideValue
                        filePath = $modeFile
                    }
                }
                continue
            }
```

Replace it with:

```powershell
                $modeFile = Join-Path $apiRoot 'poller.mode'
                $modeOverridePresent = Test-Path -LiteralPath $modeFile
                $modeOverrideValue = $null
                if ($modeOverridePresent) {
                    try { $modeOverrideValue = (Get-Content -Raw -LiteralPath $modeFile).Trim().ToLowerInvariant() } catch { $modeOverrideValue = $null }
                }

                # Same hardcoded-path-not-guessed reasoning as $modeFile above. This
                # process does not dot-source TicketPollerAgent.ps1 (only PollerGate.ps1),
                # so it cannot call Get-PollerConfig -- it replicates the minimal
                # env/file-fallback read locally instead, same as $modeFile does today.
                $enabledFile = Join-Path $apiRoot 'poller.enabled'
                $enabledOverridePresent = Test-Path -LiteralPath $enabledFile
                $enabledOverrideValue = $null
                if ($enabledOverridePresent) {
                    try { $enabledOverrideValue = (Get-Content -Raw -LiteralPath $enabledFile).Trim().ToLowerInvariant() } catch { $enabledOverrideValue = $null }
                }

                $pollerEnvAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }
                $pollerCapsFile = Join-Path $apiRoot 'poller.caps.json'
                $pollerCapsValues = @{
                    maxGrants  = @{ value = (& $pollerEnvAsInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5); source = 'env' }
                    maxTickets = @{ value = (& $pollerEnvAsInt $env:AZURESENTRY_POLLER_MAX_TICKETS 100); source = 'env' }
                    maxAgeDays = @{ value = (& $pollerEnvAsInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7); source = 'env' }
                }
                if (Test-Path -LiteralPath $pollerCapsFile) {
                    try {
                        $pollerCapsJson = Get-Content -Raw -LiteralPath $pollerCapsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                        foreach ($key in @('maxGrants', 'maxTickets', 'maxAgeDays')) {
                            if ($pollerCapsJson.PSObject.Properties.Name -contains $key) {
                                $n = 0
                                if ([int]::TryParse([string]$pollerCapsJson.$key, [ref]$n) -and $n -gt 0) {
                                    $pollerCapsValues[$key] = @{ value = $n; source = 'override' }
                                }
                            }
                        }
                    } catch { }
                }

                Write-JsonResponse -Response $response -Body @{
                    configured  = (Test-Path $statusPath)
                    enabled     = $view.Enabled
                    mode        = $view.Mode
                    stale       = $view.Stale
                    stopFilePresent = (Test-Path $stopPath)
                    lastCycle   = $last
                    modeOverride = @{
                        present  = $modeOverridePresent
                        value    = $modeOverrideValue
                        filePath = $modeFile
                    }
                    enabledOverride = @{
                        present  = $enabledOverridePresent
                        value    = $enabledOverrideValue
                        filePath = $enabledFile
                    }
                    caps = $pollerCapsValues
                }
                continue
            }
```

- [ ] **Step 2: Add the four new poller routes**

Find this exact block (the end of the existing `/api/poller/mode` DELETE handler):

```powershell
                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $modeFile }
                continue
            }

            if ($path -eq '/api/reaper/status' -and $method -eq 'GET') {
```

Replace it with:

```powershell
                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $modeFile }
                continue
            }

            if ($path -eq '/api/poller/enabled' -and $method -eq 'POST') {
                # The dashboard's automation on/off control. Mirrors POST /api/poller/mode
                # exactly (see that handler's comments) -- writes an override file this
                # process's sibling process (the poller) checks before its own env var.
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                if ($null -eq $body.enabled) { throw 'enabled (bool) is required' }
                $requestedEnabled = [bool]$body.enabled
                $justification = ([string]$body.justification).Trim()
                if ($requestedEnabled -and $justification.Length -lt 4) {
                    throw 'A justification of at least 4 characters is required to enable automation.'
                }

                $enabledFile = Join-Path $apiRoot 'poller.enabled'
                $previous = if (Test-Path -LiteralPath $enabledFile) {
                    try { (Get-Content -Raw -LiteralPath $enabledFile).Trim().ToLowerInvariant() } catch { $null }
                } else { $null }

                $valueText = if ($requestedEnabled) { 'true' } else { 'false' }
                $enabledBytes = [System.Text.Encoding]::UTF8.GetBytes($valueText)
                [System.IO.File]::WriteAllBytes($enabledFile, $enabledBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'SetEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ enabled = $previous } -After @{ enabled = $valueText } `
                        -Reason $justification `
                        -Detail @{ enabledFile = $enabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    enabled  = $requestedEnabled
                    filePath = $enabledFile
                    note     = 'Takes effect on the poller''s next scheduled cycle, not immediately -- it is a separate process.'
                }
                continue
            }

            if ($path -eq '/api/poller/enabled' -and $method -eq 'DELETE') {
                $enabledFile = Join-Path $apiRoot 'poller.enabled'
                $existed = Test-Path -LiteralPath $enabledFile
                if ($existed) { Remove-Item -LiteralPath $enabledFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'ClearEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ enabledFile = $enabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $enabledFile }
                continue
            }

            if ($path -eq '/api/poller/caps' -and $method -eq 'POST') {
                # Per-cycle limits (MaxGrantsPerCycle, MaxTicketsPerCycle, MaxTicketAgeDays)
                # -- see Get-PollerConfig's .DESCRIPTION (TicketPollerAgent.ps1) and
                # docs/superpowers/specs/2026-08-26-poller-reaper-automation-controls-design.md.
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }

                $envAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }

                $capsFile = Join-Path $apiRoot 'poller.caps.json'
                $current = @{
                    maxGrants  = & $envAsInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5
                    maxTickets = & $envAsInt $env:AZURESENTRY_POLLER_MAX_TICKETS 100
                    maxAgeDays = & $envAsInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7
                }
                $existingJson = $null
                if (Test-Path -LiteralPath $capsFile) {
                    try { $existingJson = Get-Content -Raw -LiteralPath $capsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { $existingJson = $null }
                }
                if ($existingJson) {
                    foreach ($key in @('maxGrants', 'maxTickets', 'maxAgeDays')) {
                        if ($existingJson.PSObject.Properties.Name -contains $key) {
                            $n = 0
                            if ([int]::TryParse([string]$existingJson.$key, [ref]$n) -and $n -gt 0) { $current[$key] = $n }
                        }
                    }
                }

                $updated = @{ maxGrants = $current.maxGrants; maxTickets = $current.maxTickets; maxAgeDays = $current.maxAgeDays }
                $providedKeys = @()
                foreach ($key in @('maxGrants', 'maxTickets', 'maxAgeDays')) {
                    if ($body.PSObject.Properties.Name -contains $key -and $null -ne $body.$key) {
                        $n = 0
                        if (-not ([int]::TryParse([string]$body.$key, [ref]$n)) -or $n -le 0) {
                            throw "$key must be a positive integer, got '$($body.$key)'."
                        }
                        $updated[$key] = $n
                        $providedKeys += $key
                    }
                }
                if ($providedKeys.Count -eq 0) { throw 'At least one of maxGrants, maxTickets, maxAgeDays is required.' }

                $justification = ([string]$body.justification).Trim()
                if (($providedKeys -contains 'maxGrants') -and $updated.maxGrants -gt $current.maxGrants -and $justification.Length -lt 4) {
                    throw 'A justification of at least 4 characters is required to raise maxGrants.'
                }

                $capsBytes = [System.Text.Encoding]::UTF8.GetBytes(($updated | ConvertTo-Json -Compress))
                [System.IO.File]::WriteAllBytes($capsFile, $capsBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'SetCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before $current -After $updated -Reason $justification `
                        -Detail @{ capsFile = $capsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    caps     = $updated
                    filePath = $capsFile
                }
                continue
            }

            if ($path -eq '/api/poller/caps' -and $method -eq 'DELETE') {
                $capsFile = Join-Path $apiRoot 'poller.caps.json'
                $existed = Test-Path -LiteralPath $capsFile
                if ($existed) { Remove-Item -LiteralPath $capsFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'ClearCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ capsFile = $capsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $capsFile }
                continue
            }

            if ($path -eq '/api/reaper/status' -and $method -eq 'GET') {
```

- [ ] **Step 3: Verify by hand (no Pester coverage for routes, matching existing practice)**

Run: `pwsh -File .\dashboard\Start-Local.ps1` (Mock mode), then in another terminal:

```powershell
Invoke-RestMethod http://127.0.0.1:8787/api/poller/status | ConvertTo-Json -Depth 5
# Expect: enabledOverride.present = $false, caps.maxGrants.source = "env", etc.

Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8787/api/poller/enabled -Body (@{ enabled = $true; justification = 'testing' } | ConvertTo-Json) -ContentType 'application/json'
Invoke-RestMethod http://127.0.0.1:8787/api/poller/status | Select-Object -ExpandProperty enabledOverride
# Expect: present = $true, value = "true"

Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8787/api/poller/caps -Body (@{ maxGrants = 3 } | ConvertTo-Json) -ContentType 'application/json'
Invoke-RestMethod http://127.0.0.1:8787/api/poller/status | Select-Object -ExpandProperty caps
# Expect: maxGrants.value = 3, maxGrants.source = "override"; maxTickets/maxAgeDays still "env"

Invoke-RestMethod -Method Delete -Uri http://127.0.0.1:8787/api/poller/enabled
Invoke-RestMethod -Method Delete -Uri http://127.0.0.1:8787/api/poller/caps
# Expect: both return { ok: true, cleared: true, ... }; status reverts to env-sourced values
```

Stop the local server (Ctrl+C) when done.

- [ ] **Step 4: Commit**

```bash
git add dashboard/api/Start-DashboardApi.ps1
git commit -m "feat(poller): add /api/poller/enabled and /api/poller/caps routes"
```

---

### Task 4: Reaper API routes — `/api/reaper/enabled`, `/api/reaper/caps`, status extension

**Files:**
- Modify: `dashboard/api/Start-DashboardApi.ps1` — the `/api/reaper/status` GET handler, and immediately after the existing `/api/reaper/mode` DELETE handler (ending `continue` right before the `/api/breakglass` GET handler)

**Interfaces:**
- Consumes: nothing from earlier tasks directly (same reasoning as Task 3 — replicates minimal read logic rather than calling `Get-ReaperConfig`, for consistency with the poller route even though `ReaperAgent.ps1` happens to already be dot-sourced into this process).
- Produces: `POST/DELETE /api/reaper/enabled`, `POST/DELETE /api/reaper/caps`; `GET /api/reaper/status` response gains `enabledOverride` and `caps` (single field `maxRevokes`).

- [ ] **Step 1: Extend the `/api/reaper/status` GET response**

Find this exact block:

```powershell
                $reaperModeFile = Join-Path $apiRoot 'reaper.mode'
                $reaperModeOverridePresent = Test-Path -LiteralPath $reaperModeFile
                $reaperModeOverrideValue = $null
                if ($reaperModeOverridePresent) {
                    try { $reaperModeOverrideValue = (Get-Content -Raw -LiteralPath $reaperModeFile).Trim().ToLowerInvariant() } catch { $reaperModeOverrideValue = $null }
                }

                Write-JsonResponse -Response $response -Body @{
                    configured  = (Test-Path $reaperStatusPath)
                    enabled     = $reaperView.Enabled
                    mode        = $reaperView.Mode
                    stale       = $reaperView.Stale
                    stopFilePresent = (Test-Path $reaperStopPath)
                    lastCycle   = $lastReaper
                    # Pulled to the top level too (not just inside lastCycle), so the
                    # dashboard can render it even when lastCycle is stale/unparseable --
                    # this dangerous-state count must never be harder to reach than the
                    # rest of the status payload.
                    expiredUnrevoked = if ($lastReaper -and $null -ne $lastReaper.expiredUnrevoked) {
                        [int]$lastReaper.expiredUnrevoked
                    } else { $null }
                    modeOverride = @{
                        present  = $reaperModeOverridePresent
                        value    = $reaperModeOverrideValue
                        filePath = $reaperModeFile
                    }
                }
                continue
            }
```

Replace it with:

```powershell
                $reaperModeFile = Join-Path $apiRoot 'reaper.mode'
                $reaperModeOverridePresent = Test-Path -LiteralPath $reaperModeFile
                $reaperModeOverrideValue = $null
                if ($reaperModeOverridePresent) {
                    try { $reaperModeOverrideValue = (Get-Content -Raw -LiteralPath $reaperModeFile).Trim().ToLowerInvariant() } catch { $reaperModeOverrideValue = $null }
                }

                $reaperEnabledFile = Join-Path $apiRoot 'reaper.enabled'
                $reaperEnabledOverridePresent = Test-Path -LiteralPath $reaperEnabledFile
                $reaperEnabledOverrideValue = $null
                if ($reaperEnabledOverridePresent) {
                    try { $reaperEnabledOverrideValue = (Get-Content -Raw -LiteralPath $reaperEnabledFile).Trim().ToLowerInvariant() } catch { $reaperEnabledOverrideValue = $null }
                }

                $reaperEnvAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }
                $reaperCapsFile = Join-Path $apiRoot 'reaper.caps.json'
                $reaperCapsValues = @{
                    maxRevokes = @{ value = (& $reaperEnvAsInt $env:AZURESENTRY_REAPER_MAX_REVOKES 25); source = 'env' }
                }
                if (Test-Path -LiteralPath $reaperCapsFile) {
                    try {
                        $reaperCapsJson = Get-Content -Raw -LiteralPath $reaperCapsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                        if ($reaperCapsJson.PSObject.Properties.Name -contains 'maxRevokes') {
                            $n = 0
                            if ([int]::TryParse([string]$reaperCapsJson.maxRevokes, [ref]$n) -and $n -gt 0) {
                                $reaperCapsValues.maxRevokes = @{ value = $n; source = 'override' }
                            }
                        }
                    } catch { }
                }

                Write-JsonResponse -Response $response -Body @{
                    configured  = (Test-Path $reaperStatusPath)
                    enabled     = $reaperView.Enabled
                    mode        = $reaperView.Mode
                    stale       = $reaperView.Stale
                    stopFilePresent = (Test-Path $reaperStopPath)
                    lastCycle   = $lastReaper
                    expiredUnrevoked = if ($lastReaper -and $null -ne $lastReaper.expiredUnrevoked) {
                        [int]$lastReaper.expiredUnrevoked
                    } else { $null }
                    modeOverride = @{
                        present  = $reaperModeOverridePresent
                        value    = $reaperModeOverrideValue
                        filePath = $reaperModeFile
                    }
                    enabledOverride = @{
                        present  = $reaperEnabledOverridePresent
                        value    = $reaperEnabledOverrideValue
                        filePath = $reaperEnabledFile
                    }
                    caps = $reaperCapsValues
                }
                continue
            }
```

- [ ] **Step 2: Add the four new reaper routes**

Find this exact block (end of the existing `/api/reaper/mode` DELETE handler):

```powershell
                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $reaperModeFile }
                continue
            }

            if ($path -eq '/api/breakglass' -and $method -eq 'GET') {
```

Replace it with:

```powershell
                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $reaperModeFile }
                continue
            }

            if ($path -eq '/api/reaper/enabled' -and $method -eq 'POST') {
                # Mirrors POST /api/poller/enabled exactly.
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                if ($null -eq $body.enabled) { throw 'enabled (bool) is required' }
                $requestedEnabled = [bool]$body.enabled
                $justification = ([string]$body.justification).Trim()
                if ($requestedEnabled -and $justification.Length -lt 4) {
                    throw 'A justification of at least 4 characters is required to enable automation.'
                }

                $reaperEnabledFile = Join-Path $apiRoot 'reaper.enabled'
                $previous = if (Test-Path -LiteralPath $reaperEnabledFile) {
                    try { (Get-Content -Raw -LiteralPath $reaperEnabledFile).Trim().ToLowerInvariant() } catch { $null }
                } else { $null }

                $valueText = if ($requestedEnabled) { 'true' } else { 'false' }
                $reaperEnabledBytes = [System.Text.Encoding]::UTF8.GetBytes($valueText)
                [System.IO.File]::WriteAllBytes($reaperEnabledFile, $reaperEnabledBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'SetEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ enabled = $previous } -After @{ enabled = $valueText } `
                        -Reason $justification `
                        -Detail @{ enabledFile = $reaperEnabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    enabled  = $requestedEnabled
                    filePath = $reaperEnabledFile
                    note     = 'Takes effect on the reaper''s next scheduled cycle, not immediately -- it is a separate process.'
                }
                continue
            }

            if ($path -eq '/api/reaper/enabled' -and $method -eq 'DELETE') {
                $reaperEnabledFile = Join-Path $apiRoot 'reaper.enabled'
                $existed = Test-Path -LiteralPath $reaperEnabledFile
                if ($existed) { Remove-Item -LiteralPath $reaperEnabledFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'ClearEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ enabledFile = $reaperEnabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $reaperEnabledFile }
                continue
            }

            if ($path -eq '/api/reaper/caps' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }

                $envAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }

                $reaperCapsFile = Join-Path $apiRoot 'reaper.caps.json'
                $currentMaxRevokes = & $envAsInt $env:AZURESENTRY_REAPER_MAX_REVOKES 25
                if (Test-Path -LiteralPath $reaperCapsFile) {
                    try {
                        $existingJson = Get-Content -Raw -LiteralPath $reaperCapsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                        if ($existingJson.PSObject.Properties.Name -contains 'maxRevokes') {
                            $n = 0
                            if ([int]::TryParse([string]$existingJson.maxRevokes, [ref]$n) -and $n -gt 0) { $currentMaxRevokes = $n }
                        }
                    } catch { }
                }

                if ($null -eq $body.maxRevokes) { throw 'maxRevokes is required.' }
                $n = 0
                if (-not ([int]::TryParse([string]$body.maxRevokes, [ref]$n)) -or $n -le 0) {
                    throw "maxRevokes must be a positive integer, got '$($body.maxRevokes)'."
                }
                $updatedMaxRevokes = $n

                $justification = ([string]$body.justification).Trim()
                if ($updatedMaxRevokes -gt $currentMaxRevokes -and $justification.Length -lt 4) {
                    throw 'A justification of at least 4 characters is required to raise maxRevokes.'
                }

                $updated = @{ maxRevokes = $updatedMaxRevokes }
                $reaperCapsBytes = [System.Text.Encoding]::UTF8.GetBytes(($updated | ConvertTo-Json -Compress))
                [System.IO.File]::WriteAllBytes($reaperCapsFile, $reaperCapsBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'SetCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ maxRevokes = $currentMaxRevokes } -After $updated -Reason $justification `
                        -Detail @{ capsFile = $reaperCapsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    caps     = $updated
                    filePath = $reaperCapsFile
                }
                continue
            }

            if ($path -eq '/api/reaper/caps' -and $method -eq 'DELETE') {
                $reaperCapsFile = Join-Path $apiRoot 'reaper.caps.json'
                $existed = Test-Path -LiteralPath $reaperCapsFile
                if ($existed) { Remove-Item -LiteralPath $reaperCapsFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'ClearCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ capsFile = $reaperCapsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $reaperCapsFile }
                continue
            }

            if ($path -eq '/api/breakglass' -and $method -eq 'GET') {
```

- [ ] **Step 3: Verify by hand**

Same pattern as Task 3 Step 3, against `/api/reaper/status`, `/api/reaper/enabled`, `/api/reaper/caps`.

- [ ] **Step 4: Commit**

```bash
git add dashboard/api/Start-DashboardApi.ps1
git commit -m "feat(reaper): add /api/reaper/enabled and /api/reaper/caps routes"
```

---

### Task 5: Frontend types + API client

**Files:**
- Modify: `dashboard/web/src/types.ts:706-804` (the `PollerModeOverride`, `PollerStatus`, `ReaperStatus` interfaces)
- Modify: `dashboard/web/src/api/client.ts:67-88` (the `api.poller` and `api.reaper` objects)

**Interfaces:**
- Consumes: the exact JSON shapes Tasks 3–4 produce (`enabledOverride: {present, value, filePath}`, `caps: {maxGrants: {value, source}, ...}` for poller; `caps: {maxRevokes: {value, source}}` for reaper).
- Produces: `PollerEnabledOverride`, `PollerCapValue` types; `api.poller.setEnabled/clearEnabled/setCaps/clearCaps`, `api.reaper.setEnabled/clearEnabled/setCaps/clearCaps` — consumed by Tasks 6–7.

- [ ] **Step 1: Add the new types**

In `dashboard/web/src/types.ts`, find this exact block:

```typescript
export interface PollerModeOverride {
  /** Whether dashboard/api/poller.mode currently exists. */
  present: boolean
  /** Its trimmed, lowercased content, or `null` when absent/unreadable. */
  value: 'enforce' | 'shadow' | null
  filePath: string
}
```

Add immediately after it:

```typescript
export interface PollerEnabledOverride {
  /** Whether dashboard/api/poller.enabled (or reaper.enabled) currently exists. */
  present: boolean
  /** Its trimmed, lowercased content, or `null` when absent/unreadable. */
  value: 'true' | 'false' | null
  filePath: string
}

export interface PollerCapValue {
  value: number
  source: 'env' | 'override'
}
```

Find this exact block (inside `PollerStatus`):

```typescript
  modeOverride: PollerModeOverride
}
```

Replace it with:

```typescript
  modeOverride: PollerModeOverride
  /**
   * The dashboard's automation on/off control (POST/DELETE /api/poller/enabled). Same
   * "instruction for the next cycle, not a live state" caveat as modeOverride.
   */
  enabledOverride: PollerEnabledOverride
  /** Per-cycle limits, current effective value and whether it came from an override file. */
  caps: {
    maxGrants: PollerCapValue
    maxTickets: PollerCapValue
    maxAgeDays: PollerCapValue
  }
}
```

Find this exact block (inside `ReaperStatus`, at the end of the file):

```typescript
  modeOverride: PollerModeOverride
}
```

(This is the second occurrence of that exact text in the file — the one inside `ReaperStatus`, not the one just edited inside `PollerStatus`.) Replace it with:

```typescript
  modeOverride: PollerModeOverride
  /** Same shape and caveat as PollerStatus.enabledOverride. */
  enabledOverride: PollerEnabledOverride
  /** Single field, same shape as PollerStatus.caps otherwise. */
  caps: {
    maxRevokes: PollerCapValue
  }
}
```

- [ ] **Step 2: Add the new client methods**

In `dashboard/web/src/api/client.ts`, find this exact block:

```typescript
  poller: {
    status: () => fetchJson<PollerStatus>('/poller/status'),
    setMode: (mode: 'enforce' | 'shadow', justification?: string) =>
      fetchJson<{ ok: boolean; mode: string; filePath: string; note: string }>('/poller/mode', {
        method: 'POST',
        body: JSON.stringify({ mode, justification }),
      }),
    clearMode: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/poller/mode', {
        method: 'DELETE',
      }),
  },
  reaper: {
    status: () => fetchJson<ReaperStatus>('/reaper/status'),
    setMode: (mode: 'enforce' | 'shadow', justification?: string) =>
      fetchJson<{ ok: boolean; mode: string; filePath: string; note: string }>('/reaper/mode', {
        method: 'POST',
        body: JSON.stringify({ mode, justification }),
      }),
    clearMode: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/reaper/mode', {
```

Replace it with:

```typescript
  poller: {
    status: () => fetchJson<PollerStatus>('/poller/status'),
    setMode: (mode: 'enforce' | 'shadow', justification?: string) =>
      fetchJson<{ ok: boolean; mode: string; filePath: string; note: string }>('/poller/mode', {
        method: 'POST',
        body: JSON.stringify({ mode, justification }),
      }),
    clearMode: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/poller/mode', {
        method: 'DELETE',
      }),
    setEnabled: (enabled: boolean, justification?: string) =>
      fetchJson<{ ok: boolean; enabled: boolean; filePath: string; note: string }>(
        '/poller/enabled',
        { method: 'POST', body: JSON.stringify({ enabled, justification }) },
      ),
    clearEnabled: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/poller/enabled', {
        method: 'DELETE',
      }),
    setCaps: (
      caps: { maxGrants?: number; maxTickets?: number; maxAgeDays?: number },
      justification?: string,
    ) =>
      fetchJson<{
        ok: boolean
        caps: { maxGrants: number; maxTickets: number; maxAgeDays: number }
        filePath: string
      }>('/poller/caps', { method: 'POST', body: JSON.stringify({ ...caps, justification }) }),
    clearCaps: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/poller/caps', {
        method: 'DELETE',
      }),
  },
  reaper: {
    status: () => fetchJson<ReaperStatus>('/reaper/status'),
    setMode: (mode: 'enforce' | 'shadow', justification?: string) =>
      fetchJson<{ ok: boolean; mode: string; filePath: string; note: string }>('/reaper/mode', {
        method: 'POST',
        body: JSON.stringify({ mode, justification }),
      }),
    clearMode: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/reaper/mode', {
        method: 'DELETE',
      }),
    setEnabled: (enabled: boolean, justification?: string) =>
      fetchJson<{ ok: boolean; enabled: boolean; filePath: string; note: string }>(
        '/reaper/enabled',
        { method: 'POST', body: JSON.stringify({ enabled, justification }) },
      ),
    clearEnabled: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/reaper/enabled', {
        method: 'DELETE',
      }),
    setCaps: (caps: { maxRevokes?: number }, justification?: string) =>
      fetchJson<{ ok: boolean; caps: { maxRevokes: number }; filePath: string }>('/reaper/caps', {
        method: 'POST',
        body: JSON.stringify({ ...caps, justification }),
      }),
    clearCaps: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/reaper/caps', {
```

**Note for the executor:** this replacement's tail (`clearCaps: () => ... '/reaper/caps'`) intentionally overlaps with what follows it in the original file (the `method: 'DELETE',` line and closing braces come right after in the untouched original — do not duplicate them; the replace should end exactly where the original `clearMode` for reaper's closing continues into the file's existing structure). Read the surrounding 15 lines after your edit to confirm the object literal still closes correctly (matching braces) before moving on.

- [ ] **Step 3: Verify it builds**

Run: `cd dashboard/web && npx tsc --noEmit`
Expected: no type errors. (This only typechecks — Task 6/7 will exercise these calls from real components.)

- [ ] **Step 4: Commit**

```bash
git add dashboard/web/src/types.ts dashboard/web/src/api/client.ts
git commit -m "feat(dashboard-ui): add enabled/caps types and API client methods"
```

---

### Task 6: `PollerStatusPanel.tsx` — Off/Rehearse/Live control + per-cycle limits form

**Files:**
- Modify: `dashboard/web/src/views/PollerStatusPanel.tsx` (full-file replacement — the existing Enforce Mode `Paper` block is replaced by the new automation control, and a new "Per-cycle limits" `Paper` block is added after it; everything else in the file is unchanged from what's already there)

**Interfaces:**
- Consumes: `api.poller.status/setMode/clearMode/setEnabled/clearEnabled/setCaps/clearCaps` from Task 5; `PollerStatus` type from Task 5.
- Produces: nothing consumed elsewhere — this is a leaf UI component.

- [ ] **Step 1: Replace the whole file**

Write this complete content to `dashboard/web/src/views/PollerStatusPanel.tsx`:

```tsx
import { useCallback, useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import AlertTitle from '@mui/material/AlertTitle'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import ToggleButton from '@mui/material/ToggleButton'
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup'

import { api } from '../api/client'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import type { PollerStatus } from '../types'

const OUTCOME_TONE: Record<string, 'ok' | 'warn' | 'bad' | 'neutral'> = {
  Granted: 'ok',
  WouldGrant: 'neutral',
  Queued: 'warn',
  Failed: 'bad',
}

type Automation = 'off' | 'rehearse' | 'live'

/**
 * Mostly a read-only view of the unattended poller -- it runs as a separate scheduled
 * process, so this panel reports what it has already done. The two exceptions are the
 * Automation control and the Per-cycle limits form below: both write INSTRUCTION files
 * (dashboard/api/poller.enabled, poller.mode, poller.caps.json) the poller reads on its
 * next cycle, never a live setting -- see docs/superpowers/specs/
 * 2026-08-26-poller-reaper-automation-controls-design.md. The Automation control composes
 * two independent override files (enabled + mode) into one 3-way choice; each write is
 * still a separate, independently-auditable API call under the hood.
 */
export function PollerStatusPanel({ onModeChanged }: { onModeChanged?: () => void } = {}) {
  const [status, setStatus] = useState<PollerStatus | null>(null)
  const [pendingLive, setPendingLive] = useState(false)
  const [justification, setJustification] = useState('')
  const [busy, setBusy] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [actionNote, setActionNote] = useState<string | null>(null)

  const [capsInput, setCapsInput] = useState<{ maxGrants: string; maxTickets: string; maxAgeDays: string }>({
    maxGrants: '',
    maxTickets: '',
    maxAgeDays: '',
  })
  const [capsPendingConfirm, setCapsPendingConfirm] = useState(false)
  const [capsJustification, setCapsJustification] = useState('')
  const [capsError, setCapsError] = useState<string | null>(null)

  const load = useCallback(() => {
    return api.poller.status().then((s) => {
      setStatus(s)
      setCapsInput({
        maxGrants: String(s.caps.maxGrants.value),
        maxTickets: String(s.caps.maxTickets.value),
        maxAgeDays: String(s.caps.maxAgeDays.value),
      })
    }).catch(() => setStatus(null))
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const justificationTooShort = justification.trim().length < 4

  const currentAutomation = (): Automation | null => {
    if (!status) return null
    const e = status.enabledOverride.value
    const m = status.modeOverride.value
    if (e === 'false') return 'off'
    if (e === 'true' && m === 'enforce') return 'live'
    if (e === 'true') return 'rehearse'
    return null
  }

  const applyAutomation = async (target: Automation, withJustification?: string) => {
    setBusy(true)
    setActionError(null)
    try {
      if (target === 'off') {
        const res = await api.poller.setEnabled(false)
        setActionNote(res.note)
      } else if (target === 'rehearse') {
        await api.poller.setEnabled(true)
        const res = await api.poller.setMode('shadow')
        setActionNote(res.note)
      } else {
        await api.poller.setEnabled(true, withJustification)
        const res = await api.poller.setMode('enforce', withJustification)
        setActionNote(res.note)
      }
      setPendingLive(false)
      setJustification('')
      await load()
      // Lets EnforceModeMismatchBanner (rendered as a sibling in App.tsx, not a parent
      // of this self-fetching panel) know to re-check itself immediately rather than on
      // its own next poll -- see that component's .DESCRIPTION.
      onModeChanged?.()
    } catch (e) {
      setActionError(
        e instanceof Error
          ? `${e.message} (check Automation and Mode below -- one of the two writes may have already succeeded)`
          : 'Failed to set automation state.',
      )
    } finally {
      setBusy(false)
    }
  }

  const clearAllOverrides = async () => {
    setBusy(true)
    setActionError(null)
    try {
      await api.poller.clearEnabled()
      await api.poller.clearMode()
      setActionNote(null)
      await load()
      onModeChanged?.()
    } catch (e) {
      setActionError(e instanceof Error ? e.message : 'Failed to clear overrides.')
    } finally {
      setBusy(false)
    }
  }

  const saveCaps = async (withJustification?: string) => {
    setCapsError(null)
    setBusy(true)
    try {
      const payload: { maxGrants?: number; maxTickets?: number; maxAgeDays?: number } = {}
      const grants = Number(capsInput.maxGrants)
      const tickets = Number(capsInput.maxTickets)
      const ageDays = Number(capsInput.maxAgeDays)
      if (!Number.isInteger(grants) || grants <= 0) throw new Error('Max grants must be a positive integer.')
      if (!Number.isInteger(tickets) || tickets <= 0) throw new Error('Max tickets must be a positive integer.')
      if (!Number.isInteger(ageDays) || ageDays <= 0) throw new Error('Max ticket age must be a positive integer.')
      payload.maxGrants = grants
      payload.maxTickets = tickets
      payload.maxAgeDays = ageDays

      await api.poller.setCaps(payload, withJustification)
      setCapsPendingConfirm(false)
      setCapsJustification('')
      await load()
    } catch (e) {
      setCapsError(e instanceof Error ? e.message : 'Failed to save limits.')
    } finally {
      setBusy(false)
    }
  }

  const onSaveCapsClick = () => {
    if (!status) return
    const grants = Number(capsInput.maxGrants)
    if (Number.isInteger(grants) && grants > status.caps.maxGrants.value) {
      setCapsPendingConfirm(true)
      return
    }
    saveCaps()
  }

  if (!status) return null

  const cycle = status.lastCycle
  const modeOverride = status.modeOverride
  const automation = currentAutomation()

  return (
    <Card sx={{ mb: 2 }}>
      <CardHeader
        title="Unattended ticket poller"
        subheader={
          status.enabled === null
            ? 'Status unknown -- the poller has not reported recently'
            : status.enabled
              ? `Enabled · ${status.mode} mode (last reported)`
              : 'Disabled (poller last reported AZURESENTRY_POLLER_ENABLED is not true)'
        }
        action={
          <StatusPill
            tone={
              status.enabled === null
                ? 'neutral'
                : !status.enabled
                  ? 'neutral'
                  : status.mode === 'enforce'
                    ? 'ok'
                    : 'warn'
            }
            label={
              status.enabled === null
                ? 'Unknown'
                : !status.enabled
                  ? 'Off'
                  : status.mode === 'enforce'
                    ? 'Enforcing'
                    : 'Shadow'
            }
          />
        }
      />
      <CardContent>
        {status.stale && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <AlertTitle>Status unknown</AlertTitle>
            {status.configured
              ? "The poller's last reported status is missing or too old to trust. This does not mean it is off -- check the timer directly: "
              : 'The poller has never reported a status. Check the timer directly: '}
            <code>systemctl status azuresentry-poller.timer</code> on the VM.
          </Alert>
        )}

        {status.stopFilePresent && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <AlertTitle>Halted by stop sentinel</AlertTitle>
            <code>dashboard/api/poller.stop</code> exists, so cycles are halting. Delete it to
            resume.
          </Alert>
        )}

        {status.enabled === true && status.mode === 'shadow' && !modeOverride.present && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Shadow mode: the poller decides and records what it would grant, and writes
            nothing.
          </Alert>
        )}

        {/* Automation control. Composes poller.enabled + poller.mode into one 3-way
            choice; writes instruction files, never a live setting -- see the module
            .DESCRIPTION above. */}
        <Paper
          variant="outlined"
          sx={{
            p: 2,
            mb: 2,
            borderColor: automation === 'live' ? 'error.main' : 'divider',
          }}
        >
          <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center', flexWrap: 'wrap' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
              Automation
            </Typography>
            <StatusPill
              tone={automation === null ? 'neutral' : automation === 'live' ? 'bad' : automation === 'rehearse' ? 'ok' : 'neutral'}
              label={
                automation === null
                  ? 'No override -- follows env vars'
                  : automation === 'off'
                    ? 'Override: Off'
                    : automation === 'rehearse'
                      ? 'Override: Rehearse (shadow)'
                      : 'Override: Live (enforce)'
              }
            />
          </Stack>

          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
            Takes effect on the poller&apos;s <b>next scheduled cycle</b>, not immediately -- it
            is a separate process. This also does not start the poller from a stopped systemd
            timer -- see docs/ticket-poller-runbook.md's "Enable it" for that one-time step.
          </Typography>

          {actionError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>
              {actionError}
            </Alert>
          )}
          {actionNote && !actionError && (
            <Alert severity="info" sx={{ mt: 1.5 }} onClose={() => setActionNote(null)}>
              {actionNote}
            </Alert>
          )}

          {!pendingLive ? (
            <Stack direction="row" spacing={1} sx={{ mt: 1.5, flexWrap: 'wrap' }}>
              <ToggleButtonGroup
                size="small"
                exclusive
                value={automation}
                disabled={busy}
                onChange={(_e, value: Automation | null) => {
                  if (!value || value === automation) return
                  if (value === 'live') {
                    setPendingLive(true)
                  } else {
                    applyAutomation(value)
                  }
                }}
              >
                <ToggleButton value="off">Off</ToggleButton>
                <ToggleButton value="rehearse">Rehearse</ToggleButton>
                <ToggleButton value="live" color="error">
                  Live
                </ToggleButton>
              </ToggleButtonGroup>
              {(status.enabledOverride.present || modeOverride.present) && (
                <Button size="small" variant="text" disabled={busy} onClick={clearAllOverrides}>
                  Clear overrides
                </Button>
              )}
            </Stack>
          ) : (
            <Paper variant="outlined" sx={{ p: 2, mt: 1.5, borderColor: 'error.main' }}>
              <Typography variant="body2">
                This lets the unattended poller start performing <strong>real Azure grants</strong>{' '}
                with no human click, for tickets that already pass every gate (template, exact
                allowlist match, Sandbox/NonProd only, promotion ladder). Say why.
              </Typography>
              <TextField
                label="Justification (min 4 characters)"
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                fullWidth
                size="small"
                sx={{ mt: 1.5 }}
              />
              <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                <Button
                  color="error"
                  variant="contained"
                  disabled={busy || justificationTooShort}
                  onClick={() => applyAutomation('live', justification)}
                >
                  {busy ? 'Setting…' : 'Confirm: go Live'}
                </Button>
                <Button
                  variant="outlined"
                  disabled={busy}
                  onClick={() => {
                    setPendingLive(false)
                    setJustification('')
                  }}
                >
                  Cancel
                </Button>
              </Stack>
            </Paper>
          )}
        </Paper>

        {/* Per-cycle limits. Writes poller.caps.json, read per-field before its env var --
            see Get-PollerConfig's .DESCRIPTION (TicketPollerAgent.ps1). */}
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
            Per-cycle limits
          </Typography>
          <Stack direction="row" spacing={2} sx={{ flexWrap: 'wrap' }}>
            <TextField
              label="Max grants per cycle"
              helperText={`${status.caps.maxGrants.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput.maxGrants}
              onChange={(e) => setCapsInput((c) => ({ ...c, maxGrants: e.target.value }))}
            />
            <TextField
              label="Max tickets examined per cycle"
              helperText={`${status.caps.maxTickets.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput.maxTickets}
              onChange={(e) => setCapsInput((c) => ({ ...c, maxTickets: e.target.value }))}
            />
            <TextField
              label="Max ticket age (days)"
              helperText={`${status.caps.maxAgeDays.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput.maxAgeDays}
              onChange={(e) => setCapsInput((c) => ({ ...c, maxAgeDays: e.target.value }))}
            />
          </Stack>

          {capsError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>
              {capsError}
            </Alert>
          )}

          {!capsPendingConfirm ? (
            <Button size="small" variant="outlined" disabled={busy} onClick={onSaveCapsClick} sx={{ mt: 1.5 }}>
              Save limits
            </Button>
          ) : (
            <Paper variant="outlined" sx={{ p: 2, mt: 1.5, borderColor: 'error.main' }}>
              <Typography variant="body2">
                Raising the grants cap increases how many real Azure grants one cycle can
                perform. Say why.
              </Typography>
              <TextField
                label="Justification (min 4 characters)"
                value={capsJustification}
                onChange={(e) => setCapsJustification(e.target.value)}
                fullWidth
                size="small"
                sx={{ mt: 1.5 }}
              />
              <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                <Button
                  color="error"
                  variant="contained"
                  disabled={busy || capsJustification.trim().length < 4}
                  onClick={() => saveCaps(capsJustification)}
                >
                  Confirm: raise limit
                </Button>
                <Button
                  variant="outlined"
                  disabled={busy}
                  onClick={() => {
                    setCapsPendingConfirm(false)
                    setCapsJustification('')
                  }}
                >
                  Cancel
                </Button>
              </Stack>
            </Paper>
          )}
        </Paper>

        {!cycle ? (
          <Typography color="text.secondary">
            No cycle has run yet. Install and start the scheduled timer with{' '}
            <code>sudo bash /opt/azuresentry/infra/systemd/install-poller-timer.sh</code>,
            then <code>sudo systemctl start azuresentry-poller.timer</code> (see
            docs/ticket-poller-runbook.md).
          </Typography>
        ) : (
          <>
            {cycle.halted && (
              <Alert severity="info" sx={{ mb: 2 }}>
                Last cycle halted: {cycle.haltReason}
              </Alert>
            )}
            {cycle.stopped && (
              <Alert severity="error" sx={{ mb: 2 }}>
                <AlertTitle>Stopped at the first failure (fail-closed)</AlertTitle>
                Later tickets were deliberately not attempted. Fix the cause; the next cycle
                resumes.
              </Alert>
            )}

            {cycle.mode === 'enforce' && cycle.failed > 0 && (
              <Alert severity="warning" sx={{ mb: 2 }}>
                <AlertTitle>Failed grant -- requester notified</AlertTitle>
                For a ticket that reached the grant step and failed, AzureSentry posts a
                note back to the requester explaining that automated provisioning did not
                complete, and the ticket is awaiting human verification -- it is not
                resolved automatically. Check the <b>Note</b> column below to confirm it
                actually posted for each ticket; a note failure is possible too (for
                example ManageEngine being unreachable).
              </Alert>
            )}

            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(5, 1fr)' },
                gap: 1.5,
                mb: 2,
              }}
            >
              <StatCard label="Examined" value={cycle.examined} />
              <StatCard
                label={cycle.mode === 'enforce' ? 'Granted' : 'Would grant'}
                value={cycle.mode === 'enforce' ? cycle.granted : cycle.wouldGrant}
                color="success.main"
              />
              <StatCard label="Queued for a human" value={cycle.queued} color="warning.main" />
              <StatCard label="Failed" value={cycle.failed} color="error.main" />
              <StatCard label="Last run" value={new Date(cycle.ranAt).toLocaleTimeString()} />
            </Box>

            {cycle.entries.length > 0 && (
              <TableContainer sx={{ maxHeight: 300 }}>
                <Table stickyHeader size="small" aria-label="Poller cycle entries">
                  <TableHead>
                    <TableRow>
                      <TableCell>Ticket</TableCell>
                      <TableCell>Outcome</TableCell>
                      <TableCell>Role / Env</TableCell>
                      <TableCell>Note</TableCell>
                      <TableCell>Resolved</TableCell>
                      <TableCell>Why</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {cycle.entries.map((e) => {
                      // notePosted/ticketResolved are only ever set on Granted/Failed
                      // enforce entries -- Queued and WouldGrant post no note by design
                      // (see the .DESCRIPTION on Invoke-TicketPollerCycle), so they
                      // render as "-" here rather than a false negative.
                      const noteCell =
                        e.notePosted === undefined ? '—' : e.notePosted ? 'Posted' : 'Failed'
                      const resolvedCell =
                        e.ticketResolved === undefined ? '—' : e.ticketResolved ? 'Yes' : 'No'
                      return (
                        <TableRow hover key={`${e.ticketId}-${e.outcome}`}>
                          <TableCell sx={{ whiteSpace: 'nowrap' }}>#{e.ticketId}</TableCell>
                          <TableCell>
                            <StatusPill
                              tone={OUTCOME_TONE[e.outcome] ?? 'neutral'}
                              label={e.outcome === 'WouldGrant' ? 'Would grant' : e.outcome}
                            />
                          </TableCell>
                          <TableCell sx={{ whiteSpace: 'nowrap' }}>
                            {e.role ? `${e.role} / ${e.effectiveEnvironment ?? '—'}` : '—'}
                          </TableCell>
                          <TableCell
                            sx={{ whiteSpace: 'nowrap' }}
                            title={e.noteError || undefined}
                          >
                            {noteCell}
                          </TableCell>
                          <TableCell
                            sx={{ whiteSpace: 'nowrap' }}
                            title={e.resolveError || undefined}
                          >
                            {resolvedCell}
                          </TableCell>
                          <TableCell sx={{ minWidth: 280 }}>{e.reason}</TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
```

- [ ] **Step 2: Verify it builds and runs**

Run: `cd dashboard/web && npx tsc --noEmit && npm run build`
Expected: no type errors, build succeeds.

Manual check: `pwsh -File .\dashboard\Start-Local.ps1`, open `http://localhost:5173`, go to the Poller panel. Confirm: the Automation control shows three buttons (Off/Rehearse/Live), clicking Live prompts for justification, clicking Rehearse/Off applies immediately, "Save limits" on the per-cycle limits form round-trips through `GET /api/poller/status` after saving, and raising Max grants above its current value prompts for a justification before saving.

- [ ] **Step 3: Commit**

```bash
git add dashboard/web/src/views/PollerStatusPanel.tsx
git commit -m "feat(dashboard-ui): Off/Rehearse/Live automation control + per-cycle limits for poller"
```

---

### Task 7: `ReaperStatusPanel.tsx` — Off/Rehearse/Live control + max-revokes form

**Files:**
- Modify: `dashboard/web/src/views/ReaperStatusPanel.tsx` (full-file replacement, same pattern as Task 6)

**Interfaces:**
- Consumes: `api.reaper.status/setMode/clearMode/setEnabled/clearEnabled/setCaps/clearCaps` from Task 5; `ReaperStatus` type from Task 5.

- [ ] **Step 1: Read the current file in full**

Before writing the replacement, read `dashboard/web/src/views/ReaperStatusPanel.tsx` in its entirety — its structure mirrors `PollerStatusPanel.tsx` (pre-Task-6 version) closely but is not byte-identical (it has the `expiredUnrevoked` stat, reaper-specific copy, and a `ReaperEntry`/`ReaperCycle` table with different columns — `Role`, `Subscription`, `Overdue`, `Fulfilment` instead of the poller's `Role / Env`, `Note`, `Resolved`). Preserve every part of the file below the automation control unchanged except: (a) the Enforce Mode `Paper` block becomes the Automation control (identical structure to Task 6's, with `AZURESENTRY_REAPER_ENABLED` / `azuresentry-reaper.timer` / `install-reaper-timer.sh` / `dashboard/api/reaper.stop` copy substituted for the poller's), (b) a new "Max revokes per cycle" `Paper` block is added right after it, using `status.caps.maxRevokes` (a single field, not three).

- [ ] **Step 2: Apply the automation control changes**

In the file, find the block that currently renders the Enforce Mode control (structurally: a `Paper` containing a `Typography` "Enforce Mode", a `StatusPill`, the two/three `Button`s, and the `pendingConfirm` justification sub-`Paper`) and the `setMode`/`clearOverride` handlers above it. Replace that logic block-for-block with the poller's equivalent from Task 6 Step 1, adjusted:

- Replace every `api.poller.` call with `api.reaper.`
- Replace `AZURESENTRY_POLLER_ENABLED` copy with `AZURESENTRY_REAPER_ENABLED`
- Replace `azuresentry-poller.timer` / `install-poller-timer.sh` copy with `azuresentry-reaper.timer` / `install-reaper-timer.sh`
- Replace `dashboard/api/poller.stop` copy with `dashboard/api/reaper.stop`
- Keep the `pendingLive`/`justification`/`actionError`/`actionNote` state variables and the `currentAutomation`/`applyAutomation`/`clearAllOverrides` functions structurally identical to Task 6's (same logic, `api.reaper.*` calls)

- [ ] **Step 3: Add the max-revokes form**

Add this `Paper` block immediately after the Automation control's closing `</Paper>`, before whatever currently follows it (the `!cycle ? ... : ...` block):

```tsx
        {/* Max revokes per cycle. Writes reaper.caps.json, read before its env var -- see
            Get-ReaperConfig's .DESCRIPTION (ReaperAgent.ps1). */}
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
            Per-cycle limit
          </Typography>
          <Stack direction="row" spacing={2} sx={{ flexWrap: 'wrap' }}>
            <TextField
              label="Max revokes per cycle"
              helperText={`${status.caps.maxRevokes.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput}
              onChange={(e) => setCapsInput(e.target.value)}
            />
          </Stack>

          {capsError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>
              {capsError}
            </Alert>
          )}

          {!capsPendingConfirm ? (
            <Button size="small" variant="outlined" disabled={busy} onClick={onSaveCapsClick} sx={{ mt: 1.5 }}>
              Save limit
            </Button>
          ) : (
            <Paper variant="outlined" sx={{ p: 2, mt: 1.5, borderColor: 'error.main' }}>
              <Typography variant="body2">
                Raising the revokes cap increases how many real revocations one cycle can
                perform. Say why.
              </Typography>
              <TextField
                label="Justification (min 4 characters)"
                value={capsJustification}
                onChange={(e) => setCapsJustification(e.target.value)}
                fullWidth
                size="small"
                sx={{ mt: 1.5 }}
              />
              <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                <Button
                  color="error"
                  variant="contained"
                  disabled={busy || capsJustification.trim().length < 4}
                  onClick={() => saveCaps(capsJustification)}
                >
                  Confirm: raise limit
                </Button>
                <Button
                  variant="outlined"
                  disabled={busy}
                  onClick={() => {
                    setCapsPendingConfirm(false)
                    setCapsJustification('')
                  }}
                >
                  Cancel
                </Button>
              </Stack>
            </Paper>
          )}
        </Paper>
```

This uses a single-string `capsInput` (not the three-field object Task 6's poller panel uses) since the reaper has only one cap. Add these state declarations and handlers near the top of the component, alongside the automation state from Step 2:

```tsx
  const [capsInput, setCapsInput] = useState('')
  const [capsPendingConfirm, setCapsPendingConfirm] = useState(false)
  const [capsJustification, setCapsJustification] = useState('')
  const [capsError, setCapsError] = useState<string | null>(null)
```

In the `load` callback, after `setStatus(s)`, add: `setCapsInput(String(s.caps.maxRevokes.value))`.

Add these two functions alongside `applyAutomation`/`clearAllOverrides`:

```tsx
  const saveCaps = async (withJustification?: string) => {
    setCapsError(null)
    setBusy(true)
    try {
      const revokes = Number(capsInput)
      if (!Number.isInteger(revokes) || revokes <= 0) throw new Error('Max revokes must be a positive integer.')
      await api.reaper.setCaps({ maxRevokes: revokes }, withJustification)
      setCapsPendingConfirm(false)
      setCapsJustification('')
      await load()
    } catch (e) {
      setCapsError(e instanceof Error ? e.message : 'Failed to save limit.')
    } finally {
      setBusy(false)
    }
  }

  const onSaveCapsClick = () => {
    if (!status) return
    const revokes = Number(capsInput)
    if (Number.isInteger(revokes) && revokes > status.caps.maxRevokes.value) {
      setCapsPendingConfirm(true)
      return
    }
    saveCaps()
  }
```

- [ ] **Step 4: Verify it builds and runs**

Run: `cd dashboard/web && npx tsc --noEmit && npm run build`
Expected: no type errors, build succeeds.

Manual check: same as Task 6 Step 2, against the Reaper panel.

- [ ] **Step 5: Commit**

```bash
git add dashboard/web/src/views/ReaperStatusPanel.tsx
git commit -m "feat(dashboard-ui): Off/Rehearse/Live automation control + max-revokes limit for reaper"
```

---

### Task 8: Deploy exclusions, `.gitignore`, `.env.example`, full-suite verification

**Files:**
- Modify: `scripts/Deploy-ToVm.ps1:83-87`
- Modify: `.gitignore`
- Modify: `.env.example`

**Interfaces:**
- Consumes: nothing new — this is packaging/config hygiene for everything built in Tasks 1–7.

- [ ] **Step 1: Update `Deploy-ToVm.ps1`'s exclusion list**

Find this exact block:

```powershell
robocopy (Join-Path $repoRoot 'dashboard\api') "$stage\dashboard\api" /E /NFL /NDL /NJH /NJS /nc /ns /np `
    /XF processed-tickets.json activity-log.json .env llm.env audit-log.jsonl audit-log-poller.jsonl `
        audit-log-reaper.jsonl poller-status.json poller.stop poller.mode `
        reaper-status.json reaper.stop reaper.mode processed-tickets.json.migrated-* `
    /XD processed-tickets | Out-Null
```

Replace it with:

```powershell
robocopy (Join-Path $repoRoot 'dashboard\api') "$stage\dashboard\api" /E /NFL /NDL /NJH /NJS /nc /ns /np `
    /XF processed-tickets.json activity-log.json .env llm.env audit-log.jsonl audit-log-poller.jsonl `
        audit-log-reaper.jsonl poller-status.json poller.stop poller.mode poller.enabled poller.caps.json `
        reaper-status.json reaper.stop reaper.mode reaper.enabled reaper.caps.json processed-tickets.json.migrated-* `
    /XD processed-tickets | Out-Null
```

Also update the comment immediately above that block (currently ending `...enforce/shadow override on every redeploy.`) by appending one sentence: `The same applies to poller.enabled/reaper.enabled (the automation on/off override) and poller.caps.json/reaper.caps.json (the per-cycle-limit overrides) added in this feature -- all four are live operator state, never a deploy artifact.`

- [ ] **Step 2: Update `.gitignore`**

Find this exact block:

```
dashboard/api/poller-status.json
dashboard/api/poller.stop
dashboard/api/poller.mode
dashboard/api/reaper-status.json
dashboard/api/reaper.stop
dashboard/api/reaper.mode
```

Replace it with:

```
dashboard/api/poller-status.json
dashboard/api/poller.stop
dashboard/api/poller.mode
dashboard/api/poller.enabled
dashboard/api/poller.caps.json
dashboard/api/reaper-status.json
dashboard/api/reaper.stop
dashboard/api/reaper.mode
dashboard/api/reaper.enabled
dashboard/api/reaper.caps.json
```

- [ ] **Step 3: Document the new env var overrides in `.env.example`**

Find this exact block:

```
# Optional. Path to the mode-override file the dashboard's Enforce Mode toggle writes
# (POST /api/poller/mode). When it exists, its content -- not AZURESENTRY_POLLER_MODE
# above -- decides shadow vs enforce for the NEXT cycle: content 'enforce' means
# enforce, anything else (including 'shadow', blank, or garbage) means shadow. Default
# when unset: a file named poller.mode next to the processed-tickets store
# (dashboard/api/poller.mode). Delete it (or DELETE /api/poller/mode) to go back to
# this variable deciding.
# AZURESENTRY_POLLER_MODE_FILE=/opt/azuresentry/dashboard/api/poller.mode
```

Replace it with:

```
# Optional. Path to the mode-override file the dashboard's Enforce Mode toggle writes
# (POST /api/poller/mode). When it exists, its content -- not AZURESENTRY_POLLER_MODE
# above -- decides shadow vs enforce for the NEXT cycle: content 'enforce' means
# enforce, anything else (including 'shadow', blank, or garbage) means shadow. Default
# when unset: a file named poller.mode next to the processed-tickets store
# (dashboard/api/poller.mode). Delete it (or DELETE /api/poller/mode) to go back to
# this variable deciding.
# AZURESENTRY_POLLER_MODE_FILE=/opt/azuresentry/dashboard/api/poller.mode
# Optional. Path to the enabled-override file the dashboard's Automation control writes
# (POST /api/poller/enabled). Same fail-closed contract as the mode-override file above,
# but for the kill switch: content 'true' means enabled, anything else means disabled.
# Default when unset: poller.enabled next to the processed-tickets store.
# AZURESENTRY_POLLER_ENABLED_FILE=/opt/azuresentry/dashboard/api/poller.enabled
# Optional. Path to the per-cycle-limits override file the dashboard's Automation panel
# writes (POST /api/poller/caps): a small JSON object {maxGrants?, maxTickets?,
# maxAgeDays?}. Each field present overrides its own env var independently; a field
# absent, or the whole file unparseable/absent, falls back to the env var above. Default
# when unset: poller.caps.json next to the processed-tickets store.
# AZURESENTRY_POLLER_CAPS_FILE=/opt/azuresentry/dashboard/api/poller.caps.json
```

Find this exact block:

```
# Optional. Path to the mode-override file the dashboard's Enforce Mode toggle writes
# (POST /api/reaper/mode). When it exists, its content -- not AZURESENTRY_REAPER_MODE
# above -- decides shadow vs enforce for the NEXT cycle: content 'enforce' means
# enforce, anything else (including 'shadow', blank, or garbage) means shadow. Default
# when unset: a file named reaper.mode next to the processed-tickets store
# (dashboard/api/reaper.mode). Delete it (or DELETE /api/reaper/mode) to go back to
# this variable deciding.
# AZURESENTRY_REAPER_MODE_FILE=/opt/azuresentry/dashboard/api/reaper.mode
```

Replace it with:

```
# Optional. Path to the mode-override file the dashboard's Enforce Mode toggle writes
# (POST /api/reaper/mode). When it exists, its content -- not AZURESENTRY_REAPER_MODE
# above -- decides shadow vs enforce for the NEXT cycle: content 'enforce' means
# enforce, anything else (including 'shadow', blank, or garbage) means shadow. Default
# when unset: a file named reaper.mode next to the processed-tickets store
# (dashboard/api/reaper.mode). Delete it (or DELETE /api/reaper/mode) to go back to
# this variable deciding.
# AZURESENTRY_REAPER_MODE_FILE=/opt/azuresentry/dashboard/api/reaper.mode
# Optional. Enabled-override and caps-override files for the reaper -- same contract as
# the poller's equivalents above.
# AZURESENTRY_REAPER_ENABLED_FILE=/opt/azuresentry/dashboard/api/reaper.enabled
# AZURESENTRY_REAPER_CAPS_FILE=/opt/azuresentry/dashboard/api/reaper.caps.json
```

- [ ] **Step 4: Run the full test suite**

Run: `pwsh -NoProfile -Command "Invoke-Pester -Path .\tests\unit -Output Normal" 2>&1 | Select-String -Pattern 'Tests Passed|Failed:'`
Expected: `Failed: 0`, total passed count is the pre-existing 597 plus all new tests from Tasks 1–2 (roughly 620).

Run: `cd dashboard/web && npx tsc --noEmit && npm run build`
Expected: no errors, build succeeds.

- [ ] **Step 5: Commit**

```bash
git add scripts/Deploy-ToVm.ps1 .gitignore .env.example
git commit -m "chore: exclude poller/reaper enabled+caps overrides from deploy, document env vars"
```

---

## Self-Review

**Spec coverage:** Decision 1 (timer out of scope) — not touched by any task, confirmed. Decision 2 (kill switch UI-reachable) — Tasks 1/3 (poller), 2/4 (reaper). Decision 3 (composition, not new primitive; `poller.mode` untouched) — Task 6/7's `applyAutomation` calls the existing untouched `setMode`/`clearMode` client methods alongside the new `setEnabled`/`clearEnabled`; no task modifies the mode route or its tests. Decision 4 (all four caps UI-editable) — Tasks 1/2 (config), 3/4 (routes), 6/7 (UI). Decision 5 (justification only on escalation) — implemented identically in every route in Tasks 3/4 and every UI flow in Tasks 6/7. Decision 6 (no override files = unchanged behavior) — every `Get-PollerConfig`/`Get-ReaperConfig` test in Tasks 1/2 with a missing file asserts exactly this. Compatibility section (Deploy-ToVm.ps1, `.gitignore`) — Task 8. Testing section (route handlers get no new Pester coverage) — explicitly called out in Tasks 3/4's Interfaces and this plan's Global Constraints.

**Placeholder scan:** no TBD/TODO; every code step has literal, complete code; Task 7 references Task 6's code directly by name (`applyAutomation`, `currentAutomation`, etc.) with the exact substitutions needed, which is a description of a mechanical adaptation, not a "similar to Task N, figure it out" placeholder — the exact strings to substitute are listed.

**Type consistency:** `PollerCapValue { value, source }` used identically across Task 5 (types), Task 6 (poller UI), Task 7 (reaper UI). `EnabledSource`/`MaxGrantsSource`/`MaxTicketsSource`/`MaxAgeDaysSource` names match exactly between Task 1's implementation and its own tests. `caps.maxGrants`/`maxTickets`/`maxAgeDays` (poller) vs `caps.maxRevokes` (reaper) match between Tasks 3/4 (route response shape) and Task 5 (TS types) and Tasks 6/7 (UI reads).
