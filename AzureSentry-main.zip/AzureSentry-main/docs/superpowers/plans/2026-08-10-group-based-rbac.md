# Group-based RBAC Fulfilment Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fulfil Reader/Contributor access by adding the user to an existing `sg-…-readers|contributors` Entra group (after verifying subscription IAM), falling back to today’s per-user PIM grant with an engineer flag when group setup is missing.

**Architecture:** Pure naming helpers + shared `Invoke-GroupOrPimGrant` orchestrator; `GraphPimClient`/`MockPimClient` gain group find / IAM verify / member add-remove; Grant runbooks and the dashboard process path call the orchestrator; eligibility matrix updated so Reader (any env) and Sandbox need no approval, while NonProd/Prod Contributor stay approval-gated (group fulfil only after approve). Break-glass stays PIM-only.

**Tech Stack:** PowerShell 5.1+/7, Pester 5, Microsoft Graph REST + ARM REST (existing SPN client in `GraphPimClient.psm1`), existing ManageEngine status notes.

## Global Constraints

- Spec: `docs/superpowers/specs/2026-08-10-group-based-rbac-design.md` (and source `docs/Group-based-RBAC.md`).
- Roles on group path: **Reader** and **Contributor** only (`Writer` → Contributor). Owner/UAA unchanged.
- Group membership is **permanent**; `DurationDays` applies only on PIM fallback.
- Do **not** auto-create Entra groups or subscription role assignments when matches are **ambiguous** (still PIM fallback).
- **Do** create the canonical `sg-<slug>-contributors|readers` group and subscription IAM when no match exists.
- Name-convention lookup only (no IAM-first discovery).
- Break-glass / Emergency runbook: **PIM only** (no group-first).
- Prefer TDD: failing test → implement → pass → commit.
- Run tests via: `pwsh -File tests/Run-Pester.ps1` (or targeted `Invoke-Pester -Path tests/unit/...`).
- Do not commit secrets (`.env`, `llm.env`, client secrets).

---

## File Structure

**Create**
- `src/PimClient/GroupRbac.ps1` — pure naming + `Invoke-GroupOrPimGrant` (dot-sourced by clients/runbooks; no separate module manifest required).
- `tests/unit/GroupRbacNaming.Tests.ps1` — naming / pattern tests.
- `tests/unit/GroupOrPimGrant.Tests.ps1` — orchestrator tests against Mock.

**Modify**
- `src/PimClient/MockPimClient.psm1` — mock groups, role assignments, membership APIs; export new functions.
- `src/PimClient/GraphPimClient.psm1` — real Graph/ARM implementations; export new functions; widen Graph scopes comment/`Connect-MgGraph` scopes if needed.
- `src/RbacDecision/Data/eligibility-matrix.json` — approval rules aligned to spec.
- `tests/unit/RbacDecision.Tests.ps1` — expect new matrix actions.
- `src/Runbooks/Runbook-Sandbox-PIM.ps1` — Grant → `Invoke-GroupOrPimGrant`.
- `src/Runbooks/Runbook-Prod-PIM.ps1` — Contributor Eligible = pending approval (no user PIM); Owner keeps Eligible PIM; optional `-FulfilApproved` for post-approval group grant.
- `tests/unit/Runbook-Prod-PIM.Tests.ps1` — Prod Reader moves off Eligible; Contributor pending without RequestId from PIM.
- `dashboard/api/Start-DashboardApi.ps1` — process/simulate Grant uses group-first; Eligible Contributor/Reader pending then fulfil on approve path.
- `tests/Run-Pester.ps1` — include new test files.
- `progress.md` — one short note that group-based fulfilment is in progress/done (only if you already touch progress in this workstream; otherwise skip).

---

### Task 1: Pure group naming helpers (TDD)

**Files:**
- Create: `src/PimClient/GroupRbac.ps1`
- Create: `tests/unit/GroupRbacNaming.Tests.ps1`
- Modify: `tests/Run-Pester.ps1` (add the new test path)

**Interfaces:**
- Produces:
  - `Get-RbacGroupRoleSuffix -RoleName <string>` → `readers` | `contributors`
  - `Get-NormalizedSubscriptionSlug -SubscriptionName <string>` → lowercase hyphenated slug
  - `Get-EnvironmentTokenFromSlug -Slug <string>` → env token string or `$null` (`prod` canonical for `production`)
  - `Get-RbacGroupSearchPrefix -SubscriptionName <string> -IncludeEnvironment:<bool>` → e.g. `sg-jira-conf-prod`
  - `Test-RbacGroupNameMatch -GroupDisplayName <string> -Prefix <string> -Suffix <string>` → `[bool]` (starts with prefix, ends with `-suffix`, case-insensitive)
  - `Select-RbacGroupMatch -Groups <object[]> -SubscriptionName <string> -RoleName <string>` → `[PSCustomObject]@{ Status = 'Matched'|'None'|'Ambiguous'; Group = …; Candidates = …; PatternsTried = string[] }`

- [ ] **Step 1: Write the failing naming tests**

Create `tests/unit/GroupRbacNaming.Tests.ps1`:

```powershell
BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')
}

Describe 'Get-RbacGroupRoleSuffix' {
    It 'maps Reader to readers' {
        Get-RbacGroupRoleSuffix -RoleName 'Reader' | Should -Be 'readers'
    }
    It 'maps Contributor and Writer to contributors' {
        Get-RbacGroupRoleSuffix -RoleName 'Contributor' | Should -Be 'contributors'
        Get-RbacGroupRoleSuffix -RoleName 'Writer' | Should -Be 'contributors'
    }
}

Describe 'Get-NormalizedSubscriptionSlug' {
    It 'lowercases and hyphenates' {
        Get-NormalizedSubscriptionSlug -SubscriptionName 'Jira Conf Prod' | Should -Be 'jira-conf-prod'
    }
}

Describe 'Select-RbacGroupMatch' {
    It 'matches sg-jira-conf-prod-uaen-contributors when env present' {
        $groups = @(
            [pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }
        )
        $r = Select-RbacGroupMatch -Groups $groups -SubscriptionName 'jira-conf-prod' -RoleName 'Contributor'
        $r.Status | Should -Be 'Matched'
        $r.Group.id | Should -Be 'g1'
    }

    It 'falls back without inventing env when no env segment' {
        $groups = @(
            [pscustomobject]@{ id = 'g2'; displayName = 'sg-azure-labs-contributors' }
        )
        $r = Select-RbacGroupMatch -Groups $groups -SubscriptionName 'Azure-Labs' -RoleName 'Contributor'
        $r.Status | Should -Be 'Matched'
        $r.Group.id | Should -Be 'g2'
    }

    It 'returns None when no match' {
        $r = Select-RbacGroupMatch -Groups @() -SubscriptionName 'jira-conf-prod' -RoleName 'Reader'
        $r.Status | Should -Be 'None'
    }

    It 'returns Ambiguous when multiple match' {
        $groups = @(
            [pscustomobject]@{ id = 'a'; displayName = 'sg-jira-conf-prod-uaen-contributors' },
            [pscustomobject]@{ id = 'b'; displayName = 'sg-jira-conf-prod-eu-contributors' }
        )
        $r = Select-RbacGroupMatch -Groups $groups -SubscriptionName 'jira-conf-prod' -RoleName 'Contributor'
        $r.Status | Should -Be 'Ambiguous'
        $r.Candidates.Count | Should -Be 2
    }
}
```

- [ ] **Step 2: Run tests — expect fail**

```powershell
Invoke-Pester -Path tests/unit/GroupRbacNaming.Tests.ps1 -PassThru
```

Expected: FAIL (script / functions missing).

- [ ] **Step 3: Implement helpers in `src/PimClient/GroupRbac.ps1`**

```powershell
# Group-based RBAC helpers (naming + grant orchestration). Dot-source only.

function Get-RbacGroupRoleSuffix {
    param([Parameter(Mandatory)][string]$RoleName)
    switch -Regex ($RoleName) {
        '^(?i)reader$' { return 'readers' }
        '^(?i)contributor$|^(?i)writer$' { return 'contributors' }
        default { throw "Role '$RoleName' is not supported on the group RBAC path." }
    }
}

function Get-NormalizedSubscriptionSlug {
    param([Parameter(Mandatory)][string]$SubscriptionName)
    $s = $SubscriptionName.Trim().ToLowerInvariant() -replace '[_\s]+', '-'
    $s = $s -replace '-{2,}', '-'
    return $s.Trim('-')
}

function Get-EnvironmentTokenFromSlug {
    param([Parameter(Mandatory)][string]$Slug)
    $tokens = @{
        'production' = 'prod'; 'prod' = 'prod'; 'preprod' = 'preprod'
        'nonprod' = 'nonprod'; 'staging' = 'staging'; 'sandbox' = 'sandbox'
        'uat' = 'uat'; 'qa' = 'qa'; 'dev' = 'dev'
    }
    foreach ($part in ($Slug -split '-')) {
        if ($tokens.ContainsKey($part)) { return $tokens[$part] }
    }
    return $null
}

function Get-RbacGroupSearchPrefix {
    param(
        [Parameter(Mandatory)][string]$SubscriptionName,
        [bool]$IncludeEnvironment = $true
    )
    $slug = Get-NormalizedSubscriptionSlug -SubscriptionName $SubscriptionName
    if (-not $IncludeEnvironment) {
        return "sg-$slug"
    }
    $envTok = Get-EnvironmentTokenFromSlug -Slug $slug
    if (-not $envTok) { return "sg-$slug" }
    return "sg-$slug"
}

function Test-RbacGroupNameMatch {
    param(
        [Parameter(Mandatory)][string]$GroupDisplayName,
        [Parameter(Mandatory)][string]$Prefix,
        [Parameter(Mandatory)][string]$Suffix
    )
    $n = $GroupDisplayName.ToLowerInvariant()
    $p = $Prefix.ToLowerInvariant()
    $s = ('-' + $Suffix.TrimStart('-')).ToLowerInvariant()
    return ($n.StartsWith($p) -and $n.EndsWith($s))
}

function Select-RbacGroupMatch {
    param(
        [object[]]$Groups = @(),
        [Parameter(Mandatory)][string]$SubscriptionName,
        [Parameter(Mandatory)][string]$RoleName
    )
    $suffix = Get-RbacGroupRoleSuffix -RoleName $RoleName
    $patterns = New-Object System.Collections.Generic.List[string]
    $slug = Get-NormalizedSubscriptionSlug -SubscriptionName $SubscriptionName
    $envTok = Get-EnvironmentTokenFromSlug -Slug $slug

    $tryPrefixes = New-Object System.Collections.Generic.List[string]
    if ($envTok) { [void]$tryPrefixes.Add((Get-RbacGroupSearchPrefix -SubscriptionName $SubscriptionName -IncludeEnvironment:$true)) }
    $fallback = Get-RbacGroupSearchPrefix -SubscriptionName $SubscriptionName -IncludeEnvironment:$false
    if (-not $tryPrefixes.Contains($fallback)) { [void]$tryPrefixes.Add($fallback) }

    foreach ($prefix in $tryPrefixes) {
        $patterns.Add("$prefix-*-$suffix")
        $hits = @($Groups | Where-Object { Test-RbacGroupNameMatch -GroupDisplayName $_.displayName -Prefix $prefix -Suffix $suffix })
        if ($hits.Count -eq 1) {
            return [pscustomobject]@{ Status = 'Matched'; Group = $hits[0]; Candidates = $hits; PatternsTried = $patterns.ToArray() }
        }
        if ($hits.Count -gt 1) {
            return [pscustomobject]@{ Status = 'Ambiguous'; Group = $null; Candidates = $hits; PatternsTried = $patterns.ToArray() }
        }
    }
    return [pscustomobject]@{ Status = 'None'; Group = $null; Candidates = @(); PatternsTried = $patterns.ToArray() }
}
```

Note: both prefixes are `sg-$slug` when the slug already contains the env segment (e.g. `jira-conf-prod`). That matches the spec (“prefix `sg-jira-conf-prod`”). The env detection only controls whether we skip a redundant first pass — keep a single prefix list de-duped as above.

- [ ] **Step 4: Run naming tests — expect pass**

```powershell
Invoke-Pester -Path tests/unit/GroupRbacNaming.Tests.ps1 -PassThru
```

Expected: PASSED for all naming tests.

- [ ] **Step 5: Update `tests/Run-Pester.ps1` to include `tests\unit\GroupRbacNaming.Tests.ps1`**

- [ ] **Step 6: Commit**

```bash
git add src/PimClient/GroupRbac.ps1 tests/unit/GroupRbacNaming.Tests.ps1 tests/Run-Pester.ps1
git commit -m "$(cat <<'EOF'
feat: add group RBAC naming helpers for sg-* lookup

EOF
)"
```

---

### Task 2: MockPimClient group + IAM APIs (TDD)

**Files:**
- Modify: `src/PimClient/MockPimClient.psm1`
- Create: `tests/unit/GroupOrPimGrant.Tests.ps1` (start with client API describe blocks; orchestrator in Task 4)

**Interfaces:**
- Consumes: naming helpers from `GroupRbac.ps1` (dot-source inside module or tests)
- Produces (Mock + later Graph, same signatures):
  - `Get-SubscriptionDisplayName -Client -SubscriptionId` → `[string]`
  - `Find-EntraRbacGroups -Client -DisplayNamePrefix` → array of `{ id, displayName }`
  - `Test-GroupHasSubscriptionRole -Client -GroupId -SubscriptionId -RoleDefinitionId` → `[bool]`
  - `Add-EntraGroupMember -Client -GroupId -UserId` → `[PSCustomObject]@{ AlreadyMember = [bool] }`
  - `Remove-EntraGroupMember -Client -GroupId -UserId` → `[PSCustomObject]`
  - `Reset-MockPimState` also clears Groups / RoleAssignments / GroupMembers
  - `New-MockPimClient` accepts optional `-Groups`, `-RoleAssignments`, `-GroupMembers`, `-SubscriptionNames`

- [ ] **Step 1: Write failing Mock API tests** in `tests/unit/GroupOrPimGrant.Tests.ps1`:

```powershell
BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
    . (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')
}

Describe 'Mock group RBAC APIs' {
    BeforeEach { Reset-MockPimState }

    It 'Find-EntraRbacGroups returns groups by prefix' {
        $c = New-MockPimClient -Groups @(
            [pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }
        )
        $found = Find-EntraRbacGroups -Client $c -DisplayNamePrefix 'sg-jira-conf-prod'
        $found.Count | Should -Be 1
    }

    It 'Test-GroupHasSubscriptionRole reads mock IAM' {
        $sub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
        $contrib = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
        $c = New-MockPimClient -RoleAssignments @(
            [pscustomobject]@{ principalId = 'g1'; roleDefinitionId = $contrib; scope = "/subscriptions/$sub" }
        )
        Test-GroupHasSubscriptionRole -Client $c -GroupId 'g1' -SubscriptionId $sub -RoleDefinitionId $contrib | Should -Be $true
        Test-GroupHasSubscriptionRole -Client $c -GroupId 'g1' -SubscriptionId $sub -RoleDefinitionId 'acdd72a7-3385-48ef-bd42-f606fba81ae7' | Should -Be $false
    }

    It 'Add-EntraGroupMember is idempotent' {
        $c = New-MockPimClient
        $r1 = Add-EntraGroupMember -Client $c -GroupId 'g1' -UserId 'u1'
        $r2 = Add-EntraGroupMember -Client $c -GroupId 'g1' -UserId 'u1'
        $r1.AlreadyMember | Should -Be $false
        $r2.AlreadyMember | Should -Be $true
    }
}
```

- [ ] **Step 2: Run — expect fail** (commands not found).

- [ ] **Step 3: Implement Mock state + functions**

Extend `$script:MockState` with `Groups = @()`, `RoleAssignments = @()`, `GroupMembers = @{}`, `SubscriptionNames = @{}`.

In `New-MockPimClient`, accept and seed those collections.

Implement:

```powershell
function Get-SubscriptionDisplayName {
    param([object]$Client, [Parameter(Mandatory)][string]$SubscriptionId)
    if ($script:MockState.SubscriptionNames.ContainsKey($SubscriptionId)) {
        return $script:MockState.SubscriptionNames[$SubscriptionId]
    }
    return $SubscriptionId
}

function Find-EntraRbacGroups {
    param([object]$Client, [Parameter(Mandatory)][string]$DisplayNamePrefix)
    $p = $DisplayNamePrefix.ToLowerInvariant()
    return @($script:MockState.Groups | Where-Object { $_.displayName.ToLowerInvariant().StartsWith($p) })
}

function Test-GroupHasSubscriptionRole {
    param(
        [object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$SubscriptionId,
        [Parameter(Mandatory)][string]$RoleDefinitionId
    )
    $scope = "/subscriptions/$SubscriptionId"
    return [bool]@($script:MockState.RoleAssignments | Where-Object {
            $_.principalId -eq $GroupId -and $_.roleDefinitionId -eq $RoleDefinitionId -and $_.scope -eq $scope
        }).Count
}

function Add-EntraGroupMember {
    param([object]$Client, [Parameter(Mandatory)][string]$GroupId, [Parameter(Mandatory)][string]$UserId)
    if (-not $script:MockState.GroupMembers.ContainsKey($GroupId)) {
        $script:MockState.GroupMembers[$GroupId] = New-Object 'System.Collections.Generic.HashSet[string]'
    }
    $added = $script:MockState.GroupMembers[$GroupId].Add($UserId)
    return [pscustomobject]@{ AlreadyMember = (-not $added); GroupId = $GroupId; UserId = $UserId }
}

function Remove-EntraGroupMember {
    param([object]$Client, [Parameter(Mandatory)][string]$GroupId, [Parameter(Mandatory)][string]$UserId)
    if ($script:MockState.GroupMembers.ContainsKey($GroupId)) {
        [void]$script:MockState.GroupMembers[$GroupId].Remove($UserId)
    }
    return [pscustomobject]@{ GroupId = $GroupId; UserId = $UserId; Removed = $true }
}
```

Export the five new functions from `Export-ModuleMember`.

- [ ] **Step 4: Run Mock API tests — expect pass**

- [ ] **Step 5: Commit**

```bash
git add src/PimClient/MockPimClient.psm1 tests/unit/GroupOrPimGrant.Tests.ps1
git commit -m "$(cat <<'EOF'
feat: mock Entra group and subscription IAM APIs for group RBAC

EOF
)"
```

---

### Task 3: `Invoke-GroupOrPimGrant` orchestrator (TDD)

**Files:**
- Modify: `src/PimClient/GroupRbac.ps1` (add orchestrator)
- Modify: `tests/unit/GroupOrPimGrant.Tests.ps1`
- Modify: `tests/Run-Pester.ps1` (ensure this file is listed)

**Interfaces:**
- Consumes: Mock/Graph functions from Task 2; `Get-RoleDefinitionId`; `New-ActiveAssignment`; naming helpers
- Produces:
  - `Invoke-GroupOrPimGrant -Client -UserId -RoleName -SubscriptionId -SubscriptionName -ResourceScope -DurationDays -Justification` →

```powershell
[PSCustomObject]@{
  Success                 = [bool]
  Fulfilment              = 'Group' | 'PimFallback'  # or $null on hard fail
  GroupId                 = [string]
  GroupName               = [string]
  AssignmentId            = [string]   # PIM id when fallback
  EngineerActionRequired  = [bool]
  EngineerActionReason    = [string]
  PatternsTried           = [string[]]
  Message                 = [string]
}
```

Logic:
1. If role not Reader/Contributor/Writer → throw (caller should not use group path).
2. Resolve subscription display name: use `-SubscriptionName` if provided; else `Get-SubscriptionDisplayName`.
3. `$prefix = Get-RbacGroupSearchPrefix …`; `$groups = Find-EntraRbacGroups -DisplayNamePrefix $prefix` (if env path used and empty, also search fallback prefix — or fetch with shorter prefix `sg-` + first segment only if needed). Practical approach: call `Find-EntraRbacGroups` once with prefix `sg-` + normalized slug (full), then `Select-RbacGroupMatch` on that list. If None and slug has multiple segments, optionally broaden to `sg-<first-two-segments>` only if tests require — **YAGNI: search with full `sg-$slug` prefix; groups like `sg-jira-conf-prod-uaen-contributors` still match StartsWith `sg-jira-conf-prod`.**
4. `Select-RbacGroupMatch` → if not Matched → PIM fallback + engineer flag (reason includes Status + PatternsTried).
5. If Matched → `Test-GroupHasSubscriptionRole`; if false → PIM fallback + flag.
6. If IAM OK → `Add-EntraGroupMember` → Success Fulfilment=Group (EngineerActionRequired=$false).
7. PIM fallback: `New-ActiveAssignment` with DurationDays; Success Fulfilment=PimFallback; EngineerActionRequired=$true; Reason like `Group setup missing or ambiguous — engineer manual check required. Status=None.`

- [ ] **Step 1: Write orchestrator tests**

```powershell
Describe 'Invoke-GroupOrPimGrant' {
    $sub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    $contrib = 'b24988ac-6180-42a0-ab88-20f7382dd24c'

    It 'adds user to group when group+IAM exist' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }) `
            -RoleAssignments @([pscustomobject]@{ principalId = 'g1'; roleDefinitionId = $contrib; scope = "/subscriptions/$sub" }) `
            -SubscriptionNames @{ $sub = 'jira-conf-prod' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 7 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'Group'
        $r.EngineerActionRequired | Should -Be $false
        $r.GroupId | Should -Be 'g1'
    }

    It 'falls back to PIM and flags engineer when group missing' {
        $c = New-MockPimClient -SubscriptionNames @{ $sub = 'jira-conf-prod' } `
            -Users @{ 'test.user@contoso.com' = 'u1' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'PimFallback'
        $r.EngineerActionRequired | Should -Be $true
        $r.AssignmentId | Should -Not -BeNullOrEmpty
    }

    It 'falls back when IAM assignment missing' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }) `
            -SubscriptionNames @{ $sub = 'jira-conf-prod' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Fulfilment | Should -Be 'PimFallback'
        $r.EngineerActionRequired | Should -Be $true
    }
}
```

- [ ] **Step 2: Run — expect fail** (`Invoke-GroupOrPimGrant` missing).

- [ ] **Step 3: Implement `Invoke-GroupOrPimGrant` at bottom of `GroupRbac.ps1`** (full function body per logic above; extract subscription id from `ResourceScope` if `-SubscriptionId` omitted via regex `^/subscriptions/([^/]+)`).

- [ ] **Step 4: Run — expect pass**

- [ ] **Step 5: Commit**

```bash
git add src/PimClient/GroupRbac.ps1 tests/unit/GroupOrPimGrant.Tests.ps1 tests/Run-Pester.ps1
git commit -m "$(cat <<'EOF'
feat: add Invoke-GroupOrPimGrant with PIM fallback and engineer flag

EOF
)"
```

---

### Task 4: GraphPimClient real implementations

**Files:**
- Modify: `src/PimClient/GraphPimClient.psm1`
- Modify: `tests/contract/PimClient.Tests.ps1` only if contract enumerates exported commands — add new names to any export list assertions

**Interfaces:**
- Same five function names/signatures as Mock (Task 2).
- Graph: `GET https://graph.microsoft.com/v1.0/groups?$filter=startswith(displayName,'{prefix}')` (escape single quotes in prefix).
- ARM role assignments: `GET https://management.azure.com/subscriptions/{id}/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01&$filter=principalId eq '{groupId}'` then check `properties.roleDefinitionId` ends with the role def GUID.
- Add member: `POST https://graph.microsoft.com/v1.0/groups/{id}/members/$ref` with body `@{ '@odata.id' = "https://graph.microsoft.com/v1.0/directoryObjects/$UserId" }`. Treat HTTP 400 “already exist” as AlreadyMember=$true.
- Remove member: `DELETE …/groups/{id}/members/{userId}/$ref`.
- Subscription name: `GET https://management.azure.com/subscriptions/{id}?api-version=2022-12-01` → `displayName`.
- SDK `Connect-MgGraph` scopes: add `GroupMember.ReadWrite.All`, `Group.Read.All` (document in comment); SPN mode relies on app permissions already consented.

- [ ] **Step 1: Implement the five functions** using existing `Invoke-GraphApi` / `Invoke-ArmApi`.

- [ ] **Step 2: Export them** from `Export-ModuleMember`.

- [ ] **Step 3: Dot-source note** — runbooks will `. GroupRbac.ps1` themselves; Graph module does not need to embed orchestrator.

- [ ] **Step 4: Run full Pester suite** — expect existing contract tests still green:

```powershell
pwsh -File tests/Run-Pester.ps1
```

- [ ] **Step 5: Commit**

```bash
git add src/PimClient/GraphPimClient.psm1 tests/contract/PimClient.Tests.ps1
git commit -m "$(cat <<'EOF'
feat: Graph/ARM implementations for group RBAC lookup and membership

EOF
)"
```

---

### Task 5: Eligibility matrix — Reader auto / Contributor approval

**Files:**
- Modify: `src/RbacDecision/Data/eligibility-matrix.json`
- Modify: `tests/unit/RbacDecision.Tests.ps1`

**Spec alignment:**
| Row | Change |
|-----|--------|
| `prod-reader-standard`, `prod-reader-expedited` | `action`: `Grant`; `humanTouch`: `None`; `runbook`: `Runbook-Sandbox-PIM`; `assignmentType`: `Active`; `path`: e.g. `Production-Reader-FullAuto`; remove approver-only fields or leave sla unused |
| `nonprod-contributor` | `action`: `Eligible`; `humanTouch`: `Single Approver`; `runbook`: `Runbook-Prod-PIM`; `assignmentType`: `Eligible`; `path`: `NonProd-Contributor-Approval`; add `slaHours` 24, `escalateAtHours` 20, `approverTier` `Primary` |

Leave sandbox reader/contributor as Grant. Leave prod contributor Eligible. Leave Owner dual Eligible.

- [ ] **Step 1: Update failing tests first** in `RbacDecision.Tests.ps1`:

```powershell
It 'prod-reader-standard — Grant (no approval)' {
    $d = … # existing ticket helper for prod reader P3
    $d.Action | Should -Be 'Grant'
    $d.Runbook | Should -Be 'Runbook-Sandbox-PIM'
}

It 'nonprod-contributor — Eligible (approval required)' {
    $d = … # NonProd Contributor ticket
    $d.Action | Should -Be 'Eligible'
    $d.Runbook | Should -Be 'Runbook-Prod-PIM'
}
```

(Adjust existing `prod-reader-*` Eligible assertions accordingly. Add NonProd contributor coverage if missing.)

- [ ] **Step 2: Run RbacDecision tests — expect fail**

- [ ] **Step 3: Edit `eligibility-matrix.json`** as in the table above.

- [ ] **Step 4: Run — expect pass**

- [ ] **Step 5: Commit**

```bash
git add src/RbacDecision/Data/eligibility-matrix.json tests/unit/RbacDecision.Tests.ps1
git commit -m "$(cat <<'EOF'
fix: align eligibility matrix for group RBAC approval rules

EOF
)"
```

---

### Task 6: Wire `Runbook-Sandbox-PIM` to group-first grant

**Files:**
- Modify: `src/Runbooks/Runbook-Sandbox-PIM.ps1`
- Create or extend: `tests/unit/Runbook-Sandbox-PIM.Tests.ps1` (create if missing)

**Interfaces:**
- Consumes: `Invoke-GroupOrPimGrant`, Mock/Graph client
- After `$decision.Action -eq 'Grant'`, replace direct `New-ActiveAssignment` with:

```powershell
. (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')

$subId = if ($Ticket.SubscriptionId) { $Ticket.SubscriptionId } else {
    if ($Ticket.ResourceScope -match '^/subscriptions/([^/]+)') { $Matches[1] } else { $null }
}
$grant = Invoke-GroupOrPimGrant -Client $pimClient -UserId $userId -RoleName $Ticket.Role `
    -SubscriptionId $subId -SubscriptionName $Ticket.SubscriptionName `
    -ResourceScope $Ticket.ResourceScope -DurationDays ([int]$Ticket.DurationDays) `
    -Justification ([string]$Ticket.Justification)

return [PSCustomObject]@{
    Success                = $grant.Success
    Decision               = $decision
    Fulfilment             = $grant.Fulfilment
    GroupId                = $grant.GroupId
    GroupName              = $grant.GroupName
    AssignmentId           = $grant.AssignmentId
    UserId                 = $userId
    Role                   = $Ticket.Role
    Scope                  = $Ticket.ResourceScope
    EngineerActionRequired = $grant.EngineerActionRequired
    EngineerActionReason   = $grant.EngineerActionReason
    ExpiresAt              = if ($grant.Fulfilment -eq 'PimFallback') { (Get-Date).AddDays([int]$Ticket.DurationDays).ToUniversalTime() } else { $null }
    PimClient              = $PimClientImplementation
    Message                = $grant.Message
}
```

Only use group path when role is Reader/Contributor/Writer; if somehow Owner reached Grant (should not), keep old PIM call or throw.

- [ ] **Step 1: Add runbook tests** (Mock with group+IAM → Fulfilment Group; without → PimFallback + flag).

- [ ] **Step 2: Run — fail**

- [ ] **Step 3: Implement runbook change**

- [ ] **Step 4: Run — pass**; add file to `tests/Run-Pester.ps1`

- [ ] **Step 5: Commit**

```bash
git add src/Runbooks/Runbook-Sandbox-PIM.ps1 tests/unit/Runbook-Sandbox-PIM.Tests.ps1 tests/Run-Pester.ps1
git commit -m "$(cat <<'EOF'
feat: sandbox/grant runbook fulfils via group membership first

EOF
)"
```

---

### Task 7: Wire `Runbook-Prod-PIM` for approval-gated Contributor

**Files:**
- Modify: `src/Runbooks/Runbook-Prod-PIM.ps1`
- Modify: `tests/unit/Runbook-Prod-PIM.Tests.ps1`

**Behavior:**
- Add switch `-FulfilApproved` (default `$false`).
- When `$decision.Action -ne 'Eligible'` → unchanged failure return.
- When role is **Owner** or **UAA** (not group path): keep `New-EligibleAssignment` (existing).
- When role is **Reader/Contributor/Writer** and `-FulfilApproved:$false`: **do not** create PIM Eligible. Return:

```powershell
[PSCustomObject]@{
  Success              = $true
  Decision             = $decision
  RequiresApproval     = $true
  FulfilmentPending    = 'Group'
  AssignmentType       = 'PendingGroup'
  RequestId            = $null
  UserId               = $userId
  Role                 = $Ticket.Role
  Scope                = $Ticket.ResourceScope
  ApproverTier         = $decision.ApproverTier
  Approvers            = $decision.Approvers
  SlaHours             = $decision.SlaHours
  EscalateAt           = $decision.EscalateAt
  MfaRequired          = $decision.MfaRequired
  NotifyOnCall         = $decision.NotifyOnCall
  PimClient            = $PimClientImplementation
  Message              = 'Pending approval — on approve, user will be added to subscription RBAC group (or PIM fallback if group missing).'
}
```

- When `-FulfilApproved:$true` and role in group path: call `Invoke-GroupOrPimGrant` and return Success + Fulfilment fields (same shape as Sandbox grant result) + `RequiresApproval = $false`.

- [ ] **Step 1: Rewrite Prod tests**
  - Remove/replace prod-reader Eligible expectations (readers now Grant via Sandbox runbook — drop those Its or move to Sandbox tests).
  - Contributor Eligible → `FulfilmentPending = 'Group'`, `RequestId` null, `RequiresApproval` true.
  - Owner still gets `RequestId` / Eligible PIM.
  - New It: `-FulfilApproved` with mock group → `Fulfilment = 'Group'`.

- [ ] **Step 2: Run — fail**

- [ ] **Step 3: Implement runbook**

- [ ] **Step 4: Run — pass**

- [ ] **Step 5: Commit**

```bash
git add src/Runbooks/Runbook-Prod-PIM.ps1 tests/unit/Runbook-Prod-PIM.Tests.ps1
git commit -m "$(cat <<'EOF'
feat: prod contributor approval gates group fulfilment instead of user PIM

EOF
)"
```

---

### Task 8: Dashboard API process + status note for engineer flag

**Files:**
- Modify: `dashboard/api/Start-DashboardApi.ps1` (grant/eligible execution block ~1904 and simulate-grant ~1361; ME note builder ~1276)

**Behavior:**
- Dot-source `GroupRbac.ps1` near other imports.
- For `Grant` / `BreakGlass`: BreakGlass stays direct active PIM; **Grant** with Reader/Contributor/Writer → `Invoke-GroupOrPimGrant` (real or mock client). Include `Fulfilment`, `EngineerActionRequired`, `EngineerActionReason`, `GroupId` on `execution`.
- For `Eligible` + Reader/Contributor/Writer: do **not** call `New-EligibleAssignment`; set `execution` to pending group fulfilment (`AssignmentType = 'PendingGroup'`, `RequiresApproval = $true`). ME note: pending approval for group add.
- For `Eligible` + Owner/UAA: keep Eligible PIM.
- When processing an already-approved ticket (if code path exists for approve-and-fulfil), call `Invoke-GroupOrPimGrant`. If no such path exists, add a small branch: if request body contains `fulfilApproved: true` (or ticket status indicates approved) and decision would be Eligible for Contributor, run group grant.
- If `EngineerActionRequired`, append ME note text:  
  `Access granted via PIM fallback. Engineer action required: verify/create Entra group and subscription IAM role assignment. {EngineerActionReason}`

- [ ] **Step 1: Implement API branches** (no separate Pester for dashboard unless an existing pattern exists; smoke by loading script if feasible).

- [ ] **Step 2: Commit**

```bash
git add dashboard/api/Start-DashboardApi.ps1
git commit -m "$(cat <<'EOF'
feat: dashboard grants use group-first fulfilment and engineer fallback notes

EOF
)"
```

---

### Task 9: Full suite + spec checklist

- [ ] **Step 1: Run**

```powershell
pwsh -File tests/Run-Pester.ps1
```

Expected: all PASSED (count ≥ previous 69 + new tests).

- [ ] **Step 2: Spec coverage checklist**
  - [ ] Name convention lookup with/without env
  - [ ] IAM verify before add
  - [ ] Group add permanent / idempotent
  - [ ] PIM fallback + engineer flag
  - [ ] Reader + Sandbox no approval (matrix)
  - [ ] NonProd/Prod Contributor approval then group
  - [ ] Owner not on group path
  - [ ] Break-glass still PIM
  - [ ] No auto-create group/IAM

- [ ] **Step 3: Commit any leftover test harness fixes**

```bash
git add tests/Run-Pester.ps1
git commit -m "$(cat <<'EOF'
test: include group RBAC unit tests in Run-Pester harness

EOF
)"
```

---

## Self-review (plan vs spec)

| Spec requirement | Task |
|------------------|------|
| Find group by `sg-…` naming | 1, 3 |
| Verify group role on subscription | 2, 3, 4 |
| Add user to group, not direct RBAC | 3, 6, 8 |
| Missing setup → PIM + engineer flag | 3, 6, 8 |
| Reader + Contributor only; Owner team/matrix | 5, 6, 7 |
| Sandbox/Reader no approval; NonProd/Prod Contributor approval | 5, 7 |
| Permanent membership | 3 |
| Break-glass PIM | 6/8 (explicit skip) |
| Azure CLI/Graph not portal | 4 |

No intentional TBD placeholders remain. Function names are consistent across tasks (`Invoke-GroupOrPimGrant`, `Find-EntraRbacGroups`, `Test-GroupHasSubscriptionRole`, `Add-EntraGroupMember`).
