# RBAC Role Expansion Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Storage Blob Data and AKS RBAC role support to AzureSentry by replacing hardcoded role lists with a single data-driven role catalog, so future Azure RBAC roles can be added by editing one JSON file.

**Architecture:** A new `role-catalog.json` becomes the single source of truth mapping each role name to a risk tier (Reader/Contributor/Owner), an Azure `roleDefinitionId`, and a scope type (subscription vs resource). The decision engine switches from matching on role *name* to matching on *tier*, so the eligibility matrix stops growing per-role. Both PIM clients read role GUIDs from the catalog instead of carrying duplicate hashtables, and the sandbox runbook gates its group-first fulfilment on the catalog's scope type so resource-scoped roles take a direct PIM assignment.

**Tech Stack:** PowerShell 5.1+/7.2+, Pester 5.x, JSON data files. No new dependencies.

## Global Constraints

- **Spec authority:** `docs/superpowers/specs/2026-08-19-rbac-role-expansion-design.md`. Read it before starting; it contains the two amendments (approver tier fallback, runbook scope gate) agreed after initial approval.
- **Baseline:** `.\tests\Run-Pester.ps1` must report **330 passed, 0 failed** before Task 1 begins. No existing test may regress at any point — every task ends with the full suite green.
- **Run tests from a PowerShell prompt:** `.\tests\Run-Pester.ps1` (repo root: `C:\Users\abdulla.alfalasi\AzureSentry-repo`). Bare `.ps1` invocation may open Notepad; use `powershell -NoProfile -ExecutionPolicy Bypass -File .\tests\Run-Pester.ps1` if that happens.
- **Fail closed:** every unknown/unmatched role, tier, or scope must reject or hold — never silently grant. This is an access-control system.
- **No LLM on access-control paths** (existing project principle) — all logic in this plan is deterministic.
- **Verified role definition GUIDs** (confirmed against live tenant 2026-08-19 — copy verbatim, do not retype from memory):
  - Reader `acdd72a7-3385-48ef-bd42-f606fba81ae7`
  - Contributor `b24988ac-6180-42a0-ab88-20f7382dd24c`
  - Owner `8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d`
  - User Access Administrator (UAA) `18d7d88d-d35e-4fb5-a5c3-7773c20a72d9`
  - Storage Blob Data Reader `2a2b9908-6ea1-4ae2-8e65-a410df84e7d1`
  - Storage Blob Data Contributor `ba92f5b4-2d11-453d-a403-e96b0029c9fe`
  - Storage Blob Data Owner `b7e6dc6d-f1e8-4753-8033-0f276bb0955b`
  - Azure Kubernetes Service RBAC Reader `7f6c6a51-bcf8-42ba-9220-52d62157d7db`
  - Azure Kubernetes Service RBAC Writer `a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb`
  - Azure Kubernetes Service RBAC Admin `3498e952-d568-435e-9b2c-8d77e338d7f7`
  - Azure Kubernetes Service RBAC Cluster Admin `b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b`
- **Tier semantics** (unchanged from existing Reader/Contributor/Owner behavior):

  | Tier | Sandbox | NonProd | Production |
  |------|---------|---------|------------|
  | Reader | Grant (auto) | Grant (auto) | Grant (auto) |
  | Contributor | Grant (auto) | Eligible, single approver | Eligible, single approver (+ on-call if P1/P2) |
  | Owner | Reject (Policy-Block) | Reject (Policy-Block) | Eligible, dual approver, MFA |

- **Do not modify** `dashboard/deploy/staging/**` — it is a deployed snapshot, not source. Changes there are made by the deploy process.

## File Structure

| File | Change | Responsibility |
|------|--------|----------------|
| `src/RbacDecision/Data/role-catalog.json` | **Create** | Single source of truth: role name → tier, roleDefinitionId, scopeType, resourceType. |
| `src/RbacDecision/Private/Get-RoleCatalog.ps1` | **Create** | Loads + caches the catalog; resolves a role name (incl. `aliasOf`) to its entry. |
| `src/RbacDecision/Public/Get-RoleTier.ps1` | **Create** | Exported tier lookup used by the decision engine, PIM clients, and runbooks. |
| `src/RbacDecision/Private/Test-TicketSchema.ps1` | Modify | Validate role against catalog; validate `ResourceScope` shape against `resourceType`. |
| `src/RbacDecision/Private/Test-RoleEligibility.ps1` | Modify | Tier-based policy blocks instead of role-name lists. |
| `src/RbacDecision/Private/Get-EligibilityMatch.ps1` | Modify | Switch on tier instead of role name. |
| `src/RbacDecision/Data/eligibility-matrix.json` | Modify | Row ids keyed by tier; `policyBlocks.*BlockedRoles` become tier lists. |
| `src/RbacDecision/Public/Resolve-RbacDecision.ps1` | Modify | Pass catalog path through; approver lookup tier fallback (Gap 1). |
| `src/PimClient/GraphPimClient.psm1` | Modify | `Get-RoleDefinitionId` reads catalog; drop duplicate hashtable. |
| `src/PimClient/MockPimClient.psm1` | Modify | Same. |
| `src/Runbooks/Runbook-Sandbox-PIM.ps1` | Modify | Gate group-first path on `scopeType` (Gap 2). |
| `tests/unit/RoleCatalog.Tests.ps1` | **Create** | Catalog integrity + `Get-RoleTier` behavior. |
| `tests/unit/RbacDecision.Tests.ps1` | Modify | New-role × environment decision cases; scope-shape rejects; approver fallback. |
| `tests/unit/Runbook-Sandbox-PIM.Tests.ps1` | Modify | Resource-scoped role takes direct-PIM path, not group path. |
| `tests/contract/PimClient.Tests.ps1` | Modify | Both clients resolve every catalog role to the same GUID. |

Task order matters: Task 1 builds the catalog + lookup (everything depends on it), Tasks 2–4 migrate the decision engine, Task 5 the PIM clients, Task 6 the runbook gate, Task 7 the approver fallback.

---

### Task 1: Role catalog and tier lookup

Creates the data file and the two helpers everything else consumes. Nothing behavioral changes yet — existing code still uses its hardcoded lists, so the suite must stay green at 330.

**Files:**
- Create: `src/RbacDecision/Data/role-catalog.json`
- Create: `src/RbacDecision/Private/Get-RoleCatalog.ps1`
- Create: `src/RbacDecision/Public/Get-RoleTier.ps1`
- Test: `tests/unit/RoleCatalog.Tests.ps1`

**Interfaces:**
- Consumes: nothing (first task).
- Produces:
  - `Get-RoleCatalog [-Path <string>]` → `hashtable` keyed by role name (case-insensitive); each value is a `PSCustomObject` with `.tier`, `.roleDefinitionId` (absent for `Custom`), `.scopeType`, and optionally `.resourceType` / `.aliasOf`. Cached per-path in `$script:RoleCatalogCache`.
  - `Get-RoleTier -RoleName <string> [-Path <string>]` → `string` tier (`'Reader'|'Contributor'|'Owner'|'Custom'`), or `$null` if the role is unknown. Resolves `aliasOf` transitively (one hop).
  - `Get-RoleCatalogEntry -RoleName <string> [-Path <string>]` → the entry `PSCustomObject`, or `$null` if unknown. Resolves `aliasOf` for `tier` but preserves the requested role's own `scopeType`/`resourceType`.
  - Default catalog path: `src/RbacDecision/Data/role-catalog.json`, resolved relative to the calling script's `$PSScriptRoot`.

- [ ] **Step 1: Write the failing test**

Create `tests/unit/RoleCatalog.Tests.ps1`:

```powershell
BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
    $script:CatalogPath = Join-Path $repoRoot 'src\RbacDecision\Data\role-catalog.json'
}

Describe 'role-catalog.json integrity' {
    BeforeAll {
        $script:Catalog = Get-Content -Raw -Path $script:CatalogPath | ConvertFrom-Json
        $script:RoleNames = @($script:Catalog.PSObject.Properties.Name | Where-Object { -not $_.StartsWith('_') })
    }

    It 'is valid JSON with at least the 12 expected roles' {
        $script:RoleNames.Count | Should -BeGreaterOrEqual 12
    }

    It 'gives every role a known tier' {
        foreach ($name in $script:RoleNames) {
            $script:Catalog.$name.tier | Should -BeIn @('Reader', 'Contributor', 'Owner', 'Custom') -Because "role '$name' must have a known tier"
        }
    }

    It 'gives every role a known scopeType' {
        foreach ($name in $script:RoleNames) {
            $script:Catalog.$name.scopeType | Should -BeIn @('subscription', 'resource', 'any') -Because "role '$name' must have a known scopeType"
        }
    }

    It 'gives every resource-scoped role a resourceType' {
        $resourceScoped = @($script:RoleNames | Where-Object { $script:Catalog.$_.scopeType -eq 'resource' })
        $resourceScoped.Count | Should -BeGreaterThan 0
        foreach ($name in $resourceScoped) {
            $script:Catalog.$name.resourceType | Should -Not -BeNullOrEmpty -Because "resource-scoped role '$name' needs a resourceType"
        }
    }

    It 'gives every non-Custom role a roleDefinitionId GUID' {
        foreach ($name in ($script:RoleNames | Where-Object { $script:Catalog.$_.tier -ne 'Custom' })) {
            $script:Catalog.$name.roleDefinitionId | Should -Match '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' -Because "role '$name' needs a valid GUID"
        }
    }
}

Describe 'Get-RoleTier' {
    It 'resolves the existing subscription-scoped roles' {
        Get-RoleTier -RoleName 'Reader'      | Should -Be 'Reader'
        Get-RoleTier -RoleName 'Contributor' | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Owner'       | Should -Be 'Owner'
        Get-RoleTier -RoleName 'UAA'         | Should -Be 'Owner'
    }

    It 'resolves Writer to Contributor via aliasOf' {
        Get-RoleTier -RoleName 'Writer' | Should -Be 'Contributor'
    }

    It 'resolves the new Storage roles' {
        Get-RoleTier -RoleName 'Storage Blob Data Reader'      | Should -Be 'Reader'
        Get-RoleTier -RoleName 'Storage Blob Data Contributor' | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Storage Blob Data Owner'       | Should -Be 'Owner'
    }

    It 'resolves the new AKS roles' {
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Reader'        | Should -Be 'Reader'
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Writer'        | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Admin'         | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Cluster Admin' | Should -Be 'Owner'
    }

    It 'is case-insensitive on role name' {
        Get-RoleTier -RoleName 'storage blob data contributor' | Should -Be 'Contributor'
    }

    It 'returns $null for an unknown role (fail closed at the caller)' {
        Get-RoleTier -RoleName 'Totally Made Up Role' | Should -BeNullOrEmpty
    }
}

Describe 'Get-RoleCatalogEntry' {
    It 'returns scope metadata for a resource-scoped role' {
        $e = Get-RoleCatalogEntry -RoleName 'Storage Blob Data Contributor'
        $e.scopeType    | Should -Be 'resource'
        $e.resourceType | Should -Be 'Microsoft.Storage/storageAccounts'
        $e.roleDefinitionId | Should -Be 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
    }

    It 'returns subscription scopeType for classic roles' {
        (Get-RoleCatalogEntry -RoleName 'Contributor').scopeType | Should -Be 'subscription'
    }

    It 'returns $null for an unknown role' {
        Get-RoleCatalogEntry -RoleName 'Nope' | Should -BeNullOrEmpty
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RoleCatalog.Tests.ps1"`

Expected: FAIL — `Get-RoleTier` / `Get-RoleCatalogEntry` are not recognized commands, and `role-catalog.json` does not exist.

- [ ] **Step 3: Create the catalog data file**

Create `src/RbacDecision/Data/role-catalog.json`:

```json
{
  "_comment": "Single source of truth for supported Azure RBAC roles. tier drives the eligibility matrix (Reader/Contributor/Owner behave per spec §Tier semantics). roleDefinitionId values verified against the live tenant 2026-08-19 via 'az role definition list'. scopeType 'resource' roles must be requested at the resource's own scope, matching resourceType. Adding a role here is the ONLY change needed for it to become requestable.",
  "_source": "docs/superpowers/specs/2026-08-19-rbac-role-expansion-design.md",

  "Reader":      { "tier": "Reader",      "roleDefinitionId": "acdd72a7-3385-48ef-bd42-f606fba81ae7", "scopeType": "subscription" },
  "Contributor": { "tier": "Contributor", "roleDefinitionId": "b24988ac-6180-42a0-ab88-20f7382dd24c", "scopeType": "subscription" },
  "Writer":      { "tier": "Contributor", "roleDefinitionId": "b24988ac-6180-42a0-ab88-20f7382dd24c", "scopeType": "subscription", "aliasOf": "Contributor" },
  "Owner":       { "tier": "Owner",       "roleDefinitionId": "8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d", "scopeType": "subscription" },
  "UAA":         { "tier": "Owner",       "roleDefinitionId": "18d7d88d-d35e-4fb5-a5c3-7773c20a72d9", "scopeType": "subscription" },

  "Storage Blob Data Reader":      { "tier": "Reader",      "roleDefinitionId": "2a2b9908-6ea1-4ae2-8e65-a410df84e7d1", "scopeType": "resource", "resourceType": "Microsoft.Storage/storageAccounts" },
  "Storage Blob Data Contributor": { "tier": "Contributor", "roleDefinitionId": "ba92f5b4-2d11-453d-a403-e96b0029c9fe", "scopeType": "resource", "resourceType": "Microsoft.Storage/storageAccounts" },
  "Storage Blob Data Owner":       { "tier": "Owner",       "roleDefinitionId": "b7e6dc6d-f1e8-4753-8033-0f276bb0955b", "scopeType": "resource", "resourceType": "Microsoft.Storage/storageAccounts" },

  "Azure Kubernetes Service RBAC Reader":        { "tier": "Reader",      "roleDefinitionId": "7f6c6a51-bcf8-42ba-9220-52d62157d7db", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },
  "Azure Kubernetes Service RBAC Writer":        { "tier": "Contributor", "roleDefinitionId": "a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },
  "Azure Kubernetes Service RBAC Admin":         { "tier": "Contributor", "roleDefinitionId": "3498e952-d568-435e-9b2c-8d77e338d7f7", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },
  "Azure Kubernetes Service RBAC Cluster Admin": { "tier": "Owner",       "roleDefinitionId": "b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b", "scopeType": "resource", "resourceType": "Microsoft.ContainerService/managedClusters" },

  "Custom": { "tier": "Custom", "scopeType": "any" }
}
```

- [ ] **Step 4: Create the catalog loader**

Create `src/RbacDecision/Private/Get-RoleCatalog.ps1`:

```powershell
# Role catalog loader. The catalog is the single source of truth for which roles
# are requestable and how each is classified; see the 2026-08-19 role expansion spec.

$script:RoleCatalogCache = @{}

function Get-DefaultRoleCatalogPath {
    return (Join-Path $PSScriptRoot '../Data/role-catalog.json')
}

function Get-RoleCatalog {
    [CmdletBinding()]
    param(
        [string]$Path = (Get-DefaultRoleCatalogPath)
    )

    $key = try { (Resolve-Path -Path $Path -ErrorAction Stop).Path } catch { $Path }
    if ($script:RoleCatalogCache.ContainsKey($key)) {
        return $script:RoleCatalogCache[$key]
    }

    if (-not (Test-Path $Path)) {
        throw "Role catalog not found: $Path"
    }

    $json = Get-Content -Raw -Path $Path | ConvertFrom-Json

    # Case-insensitive lookup so ticket text like 'storage blob data reader' resolves.
    $catalog = New-Object 'System.Collections.Hashtable' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($prop in $json.PSObject.Properties) {
        if ($prop.Name.StartsWith('_')) { continue }   # _comment / _source metadata
        $catalog[$prop.Name] = $prop.Value
    }

    $script:RoleCatalogCache[$key] = $catalog
    return $catalog
}

function Get-RoleCatalogEntry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyString()][string]$RoleName,
        [string]$Path = (Get-DefaultRoleCatalogPath)
    )

    if ([string]::IsNullOrWhiteSpace($RoleName)) { return $null }

    $catalog = Get-RoleCatalog -Path $Path
    $name = $RoleName.Trim()
    if (-not $catalog.ContainsKey($name)) { return $null }

    $entry = $catalog[$name]

    # aliasOf supplies the tier from the aliased role (Writer -> Contributor) while the
    # requesting role keeps its own scope metadata.
    if ($entry.PSObject.Properties.Name -contains 'aliasOf' -and $entry.aliasOf) {
        if ($catalog.ContainsKey($entry.aliasOf)) {
            $target = $catalog[$entry.aliasOf]
            $merged = $entry.PSObject.Copy()
            $merged.tier = $target.tier
            return $merged
        }
    }

    return $entry
}

function Get-RoleCatalogNames {
    [CmdletBinding()]
    param([string]$Path = (Get-DefaultRoleCatalogPath))
    return @((Get-RoleCatalog -Path $Path).Keys)
}
```

- [ ] **Step 5: Create the public tier lookup**

Create `src/RbacDecision/Public/Get-RoleTier.ps1`:

```powershell
function Get-RoleTier {
    <#
    .SYNOPSIS
        Resolve an Azure RBAC role name to its AzureSentry risk tier.
    .DESCRIPTION
        Returns 'Reader', 'Contributor', 'Owner', or 'Custom' from role-catalog.json.
        Returns $null for an unknown role so callers fail closed rather than guessing.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyString()][string]$RoleName,
        [string]$Path
    )

    $entry = if ($PSBoundParameters.ContainsKey('Path') -and $Path) {
        Get-RoleCatalogEntry -RoleName $RoleName -Path $Path
    }
    else {
        Get-RoleCatalogEntry -RoleName $RoleName
    }

    if (-not $entry) { return $null }
    return [string]$entry.tier
}
```

`Get-RoleCatalogEntry` lives in `Private/` but must be callable from tests, the PIM clients, and the runbook. Two files gate exports and **both** must be updated:

**(a)** `src/RbacDecision/RbacDecision.psm1` — replace its `Export-ModuleMember` line with:

```powershell
$publicNames = @(Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' | ForEach-Object { [System.IO.Path]::GetFileNameWithoutExtension($_.Name) })
# Get-RoleCatalogEntry / Get-RoleCatalogNames are private helpers but are part of the
# catalog contract consumed by PIM clients, runbooks, and tests.
Export-ModuleMember -Function ($publicNames + @('Get-RoleCatalogEntry', 'Get-RoleCatalogNames'))
```

**(b)** `src/RbacDecision/RbacDecision.psd1` — `FunctionsToExport` is an explicit allowlist; a function missing from it is **not importable** even when `Export-ModuleMember` names it. Change:

```powershell
    FunctionsToExport = @('Resolve-RbacDecision', 'Get-EffectiveEnvironment', 'Get-TicketCriticality')
```

to:

```powershell
    FunctionsToExport = @('Resolve-RbacDecision', 'Get-EffectiveEnvironment', 'Get-TicketCriticality', 'Get-RoleTier', 'Get-RoleCatalogEntry', 'Get-RoleCatalogNames')
```

If Step 6 fails with `Get-RoleTier is not recognized`, this manifest edit is the cause.

- [ ] **Step 6: Run the new test to verify it passes**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RoleCatalog.Tests.ps1"`

Expected: PASS — all tests in `RoleCatalog.Tests.ps1` green.

- [ ] **Step 7: Run the full suite to confirm no regression**

Run: `.\tests\Run-Pester.ps1`

Expected: `FAILED=0`, and total climbs from 330 to roughly 348 (18 new assertions-worth of `It` blocks; exact count may differ slightly — only `FAILED=0` and "no previously-passing test now fails" matter).

- [ ] **Step 8: Commit**

```bash
git add src/RbacDecision/Data/role-catalog.json src/RbacDecision/Private/Get-RoleCatalog.ps1 src/RbacDecision/Public/Get-RoleTier.ps1 src/RbacDecision/RbacDecision.psm1 src/RbacDecision/RbacDecision.psd1 tests/unit/RoleCatalog.Tests.ps1
git commit -m "feat(rbac): add role catalog with tier and scope metadata"
```

---

### Task 2: Schema validation reads the catalog

Replaces the hardcoded `$validRoles` array with catalog-driven validation, and adds the resource-scope shape check so a resource-scoped role cannot be granted at bare subscription scope.

**Files:**
- Modify: `src/RbacDecision/Private/Test-TicketSchema.ps1:29-31` (role list), `:77-79` (scope check)
- Modify: `src/RbacDecision/Public/Resolve-RbacDecision.ps1` (add `$RoleCatalogPath` parameter, pass to schema check)
- Test: `tests/unit/RbacDecision.Tests.ps1`

**Interfaces:**
- Consumes: `Get-RoleCatalogEntry`, `Get-RoleCatalogNames` from Task 1.
- Produces: `Resolve-RbacDecision` gains `-RoleCatalogPath <string>` (default `Join-Path $PSScriptRoot '../Data/role-catalog.json'`), following the existing `-MatrixPath` / `-ApproverMappingPath` / `-SensitivityMapPath` convention. `Test-TicketSchema` gains a `-RoleCatalogPath` parameter (optional; defaults the same way).

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/RbacDecision.Tests.ps1` (inside the file, after the existing `Describe` blocks):

```powershell
Describe 'Resolve-RbacDecision — expanded role schema validation' {
    It 'accepts a resource-scoped Storage role at a storage account scope' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Reader' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Path | Should -Not -Be 'Schema-Invalid'
    }

    It 'accepts a resource-scoped AKS role at a managed cluster scope' {
        $t = New-TestTicket -Environment Sandbox -Role 'Azure Kubernetes Service RBAC Reader' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Path | Should -Not -Be 'Schema-Invalid'
    }

    It 'rejects a resource-scoped role requested at bare subscription scope' {
        # New-TestTicket defaults ResourceScope to /subscriptions/<id> only.
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor'
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        $d.Reason | Should -Match 'Microsoft.Storage/storageAccounts'
    }

    It 'rejects a resource-scoped role pointed at the wrong resource type' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    It 'still rejects a role absent from the catalog' {
        $t = New-TestTicket -Environment Sandbox -Role 'Totally Made Up Role'
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        $d.Reason | Should -Match 'Invalid role'
    }

    It 'still accepts subscription-scoped classic roles at subscription scope' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Role Reader) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
    }
}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: FAIL — the three accept/shape tests fail because `'Storage Blob Data Reader'` is not in the hardcoded `$validRoles`, so everything returns `Schema-Invalid` with reason `Invalid role`.

- [ ] **Step 3: Replace the hardcoded role list**

In `src/RbacDecision/Private/Test-TicketSchema.ps1`, add the parameter to the `param(...)` block (after `$Policy`):

```powershell
        [string]$RoleCatalogPath
```

Then replace lines 27–32 (the `# IDM-aligned roles:` comment through the closing brace of the role check) with:

```powershell
    # Supported roles come from role-catalog.json — the single source of truth. Adding a
    # role there makes it requestable with no code change here.
    $catalogArgs = @{ RoleName = [string]$Ticket.Role }
    if ($RoleCatalogPath) { $catalogArgs['Path'] = $RoleCatalogPath }
    $roleEntry = Get-RoleCatalogEntry @catalogArgs
    if (-not $roleEntry) {
        return @{ Valid = $false; Reason = "Invalid role: $($Ticket.Role). Role is not present in role-catalog.json." }
    }
```

- [ ] **Step 4: Add the resource-scope shape check**

In the same file, replace the existing scope check (lines 77–79):

```powershell
    if (-not ($Ticket.ResourceScope -match '^/(subscriptions|resourceGroups)/')) {
        return @{ Valid = $false; Reason = 'Resource scope must start with /subscriptions/ or /resourceGroups/' }
    }
```

with:

```powershell
    if (-not ($Ticket.ResourceScope -match '^/(subscriptions|resourceGroups)/')) {
        return @{ Valid = $false; Reason = 'Resource scope must start with /subscriptions/ or /resourceGroups/' }
    }

    # Resource-scoped roles (Storage data plane, AKS RBAC) are only meaningful on the
    # resource itself. Granting them at subscription scope would silently over-grant, so
    # require the scope to name the role's own resource type.
    if ($roleEntry.scopeType -eq 'resource') {
        $expected = [string]$roleEntry.resourceType
        if (-not $expected) {
            return @{ Valid = $false; Reason = "Role '$($Ticket.Role)' is resource-scoped but role-catalog.json defines no resourceType" }
        }
        $pattern = '/providers/' + [regex]::Escape($expected) + '/[^/]+'
        if (-not ([string]$Ticket.ResourceScope -match $pattern)) {
            return @{
                Valid  = $false
                Reason = "Role '$($Ticket.Role)' must be requested at a $expected scope (e.g. /subscriptions/<id>/resourceGroups/<rg>/providers/$expected/<name>), not '$($Ticket.ResourceScope)'"
            }
        }
    }
```

- [ ] **Step 5: Thread the catalog path through `Resolve-RbacDecision`**

In `src/RbacDecision/Public/Resolve-RbacDecision.ps1`, add to the `param(...)` block after `$SensitivityMapPath`:

```powershell
,

        [string]$RoleCatalogPath = (Join-Path $PSScriptRoot '../Data/role-catalog.json')
```

(Ensure the preceding parameter keeps its trailing comma and the block stays syntactically valid — the result should read `[string]$SensitivityMapPath = (...),` followed by the new `[string]$RoleCatalogPath = (...)`.)

Then change the Step 1 schema call from:

```powershell
    $schema = Test-TicketSchema -Ticket $Ticket -Policy $policy
```

to:

```powershell
    $schema = Test-TicketSchema -Ticket $Ticket -Policy $policy -RoleCatalogPath $RoleCatalogPath
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: PASS — including the pre-existing `rejects missing required fields` and `still rejects an invalid Environment value` tests.

- [ ] **Step 7: Run the full suite**

Run: `.\tests\Run-Pester.ps1`

Expected: `FAILED=0`.

- [ ] **Step 8: Commit**

```bash
git add src/RbacDecision/Private/Test-TicketSchema.ps1 src/RbacDecision/Public/Resolve-RbacDecision.ps1 tests/unit/RbacDecision.Tests.ps1
git commit -m "feat(rbac): validate roles and resource scopes from the catalog"
```

---

### Task 3: Tier-based policy blocks

Converts `Test-RoleEligibility`'s role-name blocklists into tier blocklists, so any Owner-tier role is blocked in Sandbox/NonProd automatically.

**Files:**
- Modify: `src/RbacDecision/Private/Test-RoleEligibility.ps1:32-51`
- Modify: `src/RbacDecision/Data/eligibility-matrix.json:236-237` (`sandboxBlockedRoles`, `nonProdBlockedRoles`)
- Test: `tests/unit/RbacDecision.Tests.ps1`

**Interfaces:**
- Consumes: `Get-RoleTier` (Task 1); `-RoleCatalogPath` on `Resolve-RbacDecision` (Task 2).
- Produces: `Test-RoleEligibility` gains `-RoleCatalogPath`. `policyBlocks.sandboxBlockedTiers` and `policyBlocks.nonProdBlockedTiers` replace the `*BlockedRoles` keys.

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/RbacDecision.Tests.ps1`:

```powershell
Describe 'Resolve-RbacDecision — Owner-tier roles blocked below Production' {
    It 'rejects Storage Blob Data Owner in Sandbox' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Owner' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }

    It 'rejects AKS RBAC Cluster Admin in Sandbox' {
        $t = New-TestTicket -Environment Sandbox -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }

    It 'rejects AKS RBAC Cluster Admin in NonProd' {
        $t = New-TestTicket -Environment NonProd -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Justification 'NonProd cluster admin for sprint work item 12345' -Extra @{
            ResourceScope = "/subscriptions/$script:ProdSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }
}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: FAIL — the new Owner-tier roles are not in `sandboxBlockedRoles`, so `Get-EligibilityMatch` returns `$null` and the decision is `Reject` / `Unclassified` rather than `Policy-Block`. (The assertion on `Action` may pass while `Path` fails — both must end green.)

- [ ] **Step 3: Convert the matrix policy blocks to tiers**

In `src/RbacDecision/Data/eligibility-matrix.json`, replace:

```json
    "sandboxBlockedRoles": ["Owner", "UAA"],
    "nonProdBlockedRoles": ["Owner", "UAA"],
```

with:

```json
    "sandboxBlockedTiers": ["Owner"],
    "nonProdBlockedTiers": ["Owner"],
```

- [ ] **Step 4: Make `Test-RoleEligibility` tier-based**

In `src/RbacDecision/Private/Test-RoleEligibility.ps1`, add to the `param(...)` block:

```powershell
        [string]$RoleCatalogPath
```

Then replace the two environment blocks (lines 32–51, from `if ($Ticket.Environment -eq 'Sandbox' ...` through the closing brace of the NonProd check) with:

```powershell
    $tierArgs = @{ RoleName = [string]$Ticket.Role }
    if ($RoleCatalogPath) { $tierArgs['Path'] = $RoleCatalogPath }
    $tier = Get-RoleTier @tierArgs
    if (-not $tier) {
        # Fail closed: an unknown role must never reach the matrix.
        return @{
            Valid  = $false
            Action = 'Reject'
            Reason = "Role '$($Ticket.Role)' is not present in role-catalog.json"
            Path   = 'Schema-Invalid'
        }
    }

    $sandboxBlockedTiers = if ($Policy.PSObject.Properties.Name -contains 'sandboxBlockedTiers') {
        @($Policy.sandboxBlockedTiers)
    } else { @('Owner') }
    if ($Ticket.Environment -eq 'Sandbox' -and $tier -in $sandboxBlockedTiers) {
        return @{
            Valid  = $false
            Action = 'Reject'
            Reason = "$($Ticket.Role) ($tier tier) blocked on Sandbox by Azure Policy"
            Path   = 'Policy-Block'
        }
    }

    $nonProdBlockedTiers = if ($Policy.PSObject.Properties.Name -contains 'nonProdBlockedTiers') {
        @($Policy.nonProdBlockedTiers)
    } else { @('Owner') }
    if ($Ticket.Environment -eq 'NonProd' -and $tier -in $nonProdBlockedTiers) {
        return @{
            Valid  = $false
            Action = 'Reject'
            Reason = "$($Ticket.Role) ($tier tier) blocked on NonProd - use Production dual-approval for privileged access"
            Path   = 'Policy-Block'
        }
    }
```

- [ ] **Step 5: Pass the catalog path from `Resolve-RbacDecision`**

In `src/RbacDecision/Public/Resolve-RbacDecision.ps1`, change the Step 3 call from:

```powershell
    $roleCheck = Test-RoleEligibility -Ticket $Ticket -Policy $policy
```

to:

```powershell
    $roleCheck = Test-RoleEligibility -Ticket $Ticket -Policy $policy -RoleCatalogPath $RoleCatalogPath
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: PASS — including the pre-existing `sandbox-owner — Policy Reject` and `rejects sandbox UAA` tests, which now route through tier lookup.

- [ ] **Step 7: Run the full suite**

Run: `.\tests\Run-Pester.ps1`

Expected: `FAILED=0`.

- [ ] **Step 8: Commit**

```bash
git add src/RbacDecision/Private/Test-RoleEligibility.ps1 src/RbacDecision/Data/eligibility-matrix.json src/RbacDecision/Public/Resolve-RbacDecision.ps1 tests/unit/RbacDecision.Tests.ps1
git commit -m "feat(rbac): block privileged access by tier instead of role name"
```

---

### Task 4: Tier-based eligibility matching

Rewrites `Get-EligibilityMatch` to switch on tier, so all roles of a tier share one matrix row and the matrix stops growing per-role.

**Files:**
- Modify: `src/RbacDecision/Private/Get-EligibilityMatch.ps1:30-80`
- Modify: `src/RbacDecision/Public/Resolve-RbacDecision.ps1` (pass catalog path; the `prod-*-expedited` id check at `:121-127`)
- Test: `tests/unit/RbacDecision.Tests.ps1`

**Interfaces:**
- Consumes: `Get-RoleTier` (Task 1), `-RoleCatalogPath` (Task 2).
- Produces: `Get-EligibilityMatch` gains `-RoleCatalogPath`. Matrix row `id` values are **unchanged** (`sandbox-reader`, `prod-contributor-standard`, …) — they are now interpreted as *tier* ids rather than role-name ids, which keeps `Resolve-RbacDecision`'s `$match.id -like 'prod-*-expedited'` check and all existing tests working. Only the lookup key changes, from role name to tier.

Keeping the ids stable is a deliberate simplification over the spec's illustrative `*-tier` renaming: the ids already read as tier names, and renaming them would churn the matrix, `Resolve-RbacDecision`, and every existing test for no behavioral gain.

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/RbacDecision.Tests.ps1`:

```powershell
Describe 'Resolve-RbacDecision — new roles route by tier' {
    BeforeAll {
        $script:StorageScope = "/subscriptions/$script:ProdSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        $script:AksScope     = "/subscriptions/$script:ProdSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        $script:SbxStorage   = "/subscriptions/$script:SandboxSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        $script:SbxAks       = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
    }

    It 'grants Reader-tier Storage role in Sandbox like Reader' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Reader' -Extra @{ ResourceScope = $script:SbxStorage }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
    }

    It 'grants Reader-tier AKS role in Production like Reader' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Reader' -Priority P4 -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Production-Reader-FullAuto'
    }

    It 'grants Contributor-tier Storage role in Sandbox (auto)' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{ ResourceScope = $script:SbxStorage }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
    }

    It 'gates Contributor-tier Storage role in Production P3 behind single approval' {
        $t = New-TestTicket -Environment Production -Role 'Storage Blob Data Contributor' -Priority P3 -Extra @{ ResourceScope = $script:StorageScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-Standard'
        $d.ApproverTier | Should -Be 'Primary'
    }

    It 'expedites Contributor-tier AKS Admin in Production P2 with on-call' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Admin' -Priority P2 -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-Expedited'
        $d.NotifyOnCall | Should -Be $true
        $d.SlaHours | Should -Be 8
    }

    It 'gates AKS RBAC Writer in NonProd behind single approval' {
        $t = New-TestTicket -Environment NonProd -Role 'Azure Kubernetes Service RBAC Writer' -Priority P3 -Justification 'NonProd AKS write access for sprint work item 12345' -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'NonProd-Contributor-Approval'
        $d.SlaHours | Should -Be 24
    }

    It 'grants Reader-tier AKS role in NonProd (auto)' {
        $t = New-TestTicket -Environment NonProd -Role 'Azure Kubernetes Service RBAC Reader' -Justification 'NonProd read access for sprint work item 12345' -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'NonProd-FullAuto'
    }

    It 'requires dual approval and MFA for Owner-tier Storage role in Production' {
        $t = New-TestTicket -Environment Production -Role 'Storage Blob Data Owner' -Priority P3 -Extra @{ ResourceScope = $script:StorageScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-DualApproval'
        $d.ApproverTier | Should -Be 'Dual'
        $d.MfaRequired | Should -Be $true
    }

    It 'requires dual approval for Owner-tier AKS Cluster Admin in Production' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Priority P4 -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-DualApproval'
        $d.ApproverTier | Should -Be 'Dual'
    }
}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: FAIL — `Get-EligibilityMatch`'s `switch ($effectiveRole)` has no branch for the new names, so Sandbox/NonProd fall through to `$null` (`Reject` / `Unclassified`) and Production builds a nonexistent id like `prod-storage blob data contributor-standard`.

- [ ] **Step 3: Rewrite the matcher to switch on tier**

In `src/RbacDecision/Private/Get-EligibilityMatch.ps1`, add to the `param(...)` block:

```powershell
        [string]$RoleCatalogPath,
```

(place it before the `[switch]` parameters). Then replace lines 30–80 — from the `# Writer is the IDM label...` comment through the `if ($Ticket.Environment -eq 'Production') { ... }` block — with:

```powershell
    # Routing is by risk tier, not role name: every role in a tier shares one matrix row,
    # so adding a role to role-catalog.json needs no new rows and no change here.
    $tierArgs = @{ RoleName = [string]$Ticket.Role }
    if ($RoleCatalogPath) { $tierArgs['Path'] = $RoleCatalogPath }
    $tier = Get-RoleTier @tierArgs
    if (-not $tier) { return $null }   # fail closed on an unknown role

    if ($IsBreakGlass -and $Ticket.Environment -eq 'Production' -and $Ticket.Priority -eq 'P1') {
        if ($tier -eq 'Owner') {
            return $MatrixRows | Where-Object { $_.id -eq 'emergency-owner-p1-reject' } | Select-Object -First 1
        }
        if ($tier -eq 'Contributor') {
            return $MatrixRows | Where-Object { $_.id -eq 'emergency-contributor-p1' } | Select-Object -First 1
        }
    }

    if ($Ticket.Environment -eq 'Sandbox') {
        $sandboxId = switch ($tier) {
            'Reader'      { 'sandbox-reader' }
            'Contributor' { 'sandbox-contributor' }
            'Owner'       { 'sandbox-owner-reject' }
            default       { $null }
        }
        if ($sandboxId) {
            return $MatrixRows | Where-Object { $_.id -eq $sandboxId } | Select-Object -First 1
        }
    }

    # NonProd sits between Sandbox and Production: auto-grant Reader tier, gate Contributor
    # tier behind approval, block Owner tier.
    if ($Ticket.Environment -eq 'NonProd') {
        $nonProdId = switch ($tier) {
            'Reader'      { 'nonprod-reader' }
            'Contributor' { 'nonprod-contributor' }
            'Owner'       { 'nonprod-owner-reject' }
            default       { $null }
        }
        if ($nonProdId) {
            return $MatrixRows | Where-Object { $_.id -eq $nonProdId } | Select-Object -First 1
        }
    }

    if ($Ticket.Environment -eq 'Production') {
        if ($tier -eq 'Owner') {
            # Owner and UAA have distinct rows for audit clarity; both are Owner tier.
            $dualId = if ($Ticket.Role -eq 'UAA') { 'prod-uaa-dual' } else { 'prod-owner-dual' }
            return $MatrixRows | Where-Object { $_.id -eq $dualId } | Select-Object -First 1
        }

        $isExpedited = $Ticket.Priority -in @('P1', 'P2')
        $suffix = if ($isExpedited) { 'expedited' } else { 'standard' }
        $matchId = "prod-$($tier.ToLowerInvariant())-$suffix"
        return $MatrixRows | Where-Object { $_.id -eq $matchId } | Select-Object -First 1
    }

    return $null
```

Note the `Custom` tier never reaches this code — the `custom-role-hold` early return at the top of the function (unchanged) catches it first.

- [ ] **Step 4: Pass the catalog path from `Resolve-RbacDecision`**

In `src/RbacDecision/Public/Resolve-RbacDecision.ps1`, change:

```powershell
    $match = Get-EligibilityMatch -Ticket $Ticket -MatrixRows $matrix.rows `
        -IsCrossSubscription:$isCrossSubscription -IsBreakGlass:$isBreakGlass
```

to:

```powershell
    $match = Get-EligibilityMatch -Ticket $Ticket -MatrixRows $matrix.rows `
        -RoleCatalogPath $RoleCatalogPath `
        -IsCrossSubscription:$isCrossSubscription -IsBreakGlass:$isBreakGlass
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: PASS — all new tier-routing tests plus every pre-existing matrix test (`sandbox-reader`, `prod-owner-dual`, `prod-uaa-dual`, `emergency-contributor-p1`, `custom-role — Hold`, `cross-subscription-prod`, …).

- [ ] **Step 6: Run the full suite**

Run: `.\tests\Run-Pester.ps1`

Expected: `FAILED=0`.

- [ ] **Step 7: Commit**

```bash
git add src/RbacDecision/Private/Get-EligibilityMatch.ps1 src/RbacDecision/Public/Resolve-RbacDecision.ps1 tests/unit/RbacDecision.Tests.ps1
git commit -m "feat(rbac): route eligibility by role tier instead of role name"
```

---

### Task 5: PIM clients resolve GUIDs from the catalog

Removes the duplicated `$RoleDefinitionIds` hashtables from both clients so they cannot drift, and makes all catalog roles resolvable for assignment.

**Files:**
- Modify: `src/PimClient/GraphPimClient.psm1:13-19` (hashtable), `:685-696` (`Get-RoleDefinitionId`)
- Modify: `src/PimClient/MockPimClient.psm1:174-185` (`Get-RoleDefinitionId`)
- Test: `tests/contract/PimClient.Tests.ps1`

**Interfaces:**
- Consumes: `Get-RoleCatalogEntry`, `Get-RoleCatalogNames` (Task 1).
- Produces: `Get-RoleDefinitionId -RoleName <string>` → GUID `string`; throws `"Unknown role: <name>"` for anything absent from the catalog (unchanged contract). Both modules keep exporting it. Each module imports `RbacDecision` if the catalog helpers are not already available, so the clients work standalone (as `PimClient.Tests.ps1` loads them directly).

- [ ] **Step 1: Write the failing tests**

In `tests/contract/PimClient.Tests.ps1`, replace the existing `It 'GetRoleDefinitionId maps known roles'` block (lines 53–56) with:

```powershell
    It 'GetRoleDefinitionId maps known roles' {
        Get-RoleDefinitionId -RoleName 'Reader' | Should -Be $script:ReaderRoleId
        Get-RoleDefinitionId -RoleName 'Contributor' | Should -Not -BeNullOrEmpty
    }

    It 'GetRoleDefinitionId maps the expanded Storage and AKS roles' {
        Get-RoleDefinitionId -RoleName 'Storage Blob Data Contributor' | Should -Be 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
        Get-RoleDefinitionId -RoleName 'Storage Blob Data Reader'      | Should -Be '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1'
        Get-RoleDefinitionId -RoleName 'Storage Blob Data Owner'       | Should -Be 'b7e6dc6d-f1e8-4753-8033-0f276bb0955b'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Reader'        | Should -Be '7f6c6a51-bcf8-42ba-9220-52d62157d7db'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Writer'        | Should -Be 'a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Admin'         | Should -Be '3498e952-d568-435e-9b2c-8d77e338d7f7'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Cluster Admin' | Should -Be 'b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b'
    }

    It 'GetRoleDefinitionId still maps the User Access Administrator alias' {
        Get-RoleDefinitionId -RoleName 'User Access Administrator' | Should -Be '18d7d88d-d35e-4fb5-a5c3-7773c20a72d9'
    }

    It 'GetRoleDefinitionId throws for a role absent from the catalog' {
        { Get-RoleDefinitionId -RoleName 'Totally Made Up Role' } | Should -Throw '*Unknown role*'
    }
```

Then add a new `Describe` at the end of the file, guaranteeing the two clients agree:

```powershell
Describe 'Role definition ids agree across both PIM clients' {
    It 'resolves every catalog role to the same GUID in Mock and Graph clients' {
        $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
        Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
        $roles = @(Get-RoleCatalogNames | Where-Object { $_ -ne 'Custom' })
        $roles.Count | Should -BeGreaterOrEqual 11

        Remove-Module MockPimClient, GraphPimClient -ErrorAction SilentlyContinue
        Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
        $mock = @{}
        foreach ($r in $roles) { $mock[$r] = Get-RoleDefinitionId -RoleName $r }

        Remove-Module MockPimClient -ErrorAction SilentlyContinue
        Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
        foreach ($r in $roles) {
            $mock[$r] | Should -Not -BeNullOrEmpty -Because "MockPimClient must resolve '$r'"
            Get-RoleDefinitionId -RoleName $r | Should -Be $mock[$r] -Because "both clients must agree on '$r'"
        }
    }
}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\contract\PimClient.Tests.ps1"`

Expected: FAIL — `MockPimClient`'s `Get-RoleDefinitionId` returns `$null` for the new roles (its hashtable lacks them, and it does not throw), and `GraphPimClient` throws `Unknown role`.

- [ ] **Step 3: Convert `GraphPimClient`**

In `src/PimClient/GraphPimClient.psm1`, delete the `$script:RoleDefinitionIds` hashtable (lines 13–19) and replace it with a catalog import:

```powershell
# Role GUIDs come from RbacDecision's role-catalog.json — the single source of truth.
# Imported here (rather than duplicated) so the clients cannot drift from the decision engine.
if (-not (Get-Command Get-RoleCatalogEntry -ErrorAction SilentlyContinue)) {
    Import-Module (Join-Path $PSScriptRoot '../RbacDecision/RbacDecision.psd1') -Force -Global
}
```

Then replace the `Get-RoleDefinitionId` function (lines 685–696) with:

```powershell
function Get-RoleDefinitionId {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$RoleName)

    # 'User Access Administrator' is the Azure display name; tickets use the short 'UAA'.
    $name = if ($RoleName -eq 'User Access Administrator') { 'UAA' } else { $RoleName }

    $entry = Get-RoleCatalogEntry -RoleName $name
    if (-not $entry -or -not $entry.roleDefinitionId) {
        throw "Unknown role: $RoleName"
    }
    return [string]$entry.roleDefinitionId
}
```

- [ ] **Step 4: Convert `MockPimClient`**

In `src/PimClient/MockPimClient.psm1`, add the same import near the top (after the `$script:MockState` block):

```powershell
if (-not (Get-Command Get-RoleCatalogEntry -ErrorAction SilentlyContinue)) {
    Import-Module (Join-Path $PSScriptRoot '../RbacDecision/RbacDecision.psd1') -Force -Global
}
```

Then replace `Get-RoleDefinitionId` (lines 174–185) with:

```powershell
function Get-RoleDefinitionId {
    param([Parameter(Mandatory)][string]$RoleName)

    # Mirrors GraphPimClient exactly — both read role-catalog.json so they cannot drift.
    $name = if ($RoleName -eq 'User Access Administrator') { 'UAA' } else { $RoleName }

    $entry = Get-RoleCatalogEntry -RoleName $name
    if (-not $entry -or -not $entry.roleDefinitionId) {
        throw "Unknown role: $RoleName"
    }
    return [string]$entry.roleDefinitionId
}
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\contract\PimClient.Tests.ps1"`

Expected: PASS.

- [ ] **Step 6: Run the full suite**

Run: `.\tests\Run-Pester.ps1`

Expected: `FAILED=0`. Watch the runbook suites here — they import both modules, so a bad import path surfaces as cascading failures in `Runbook-*.Tests.ps1`.

- [ ] **Step 7: Commit**

```bash
git add src/PimClient/GraphPimClient.psm1 src/PimClient/MockPimClient.psm1 tests/contract/PimClient.Tests.ps1
git commit -m "refactor(pim): resolve role definition ids from the shared catalog"
```

---

### Task 6: Gate group-first fulfilment on scope type (spec Gap 2)

Without this, a correctly-classified `Azure Kubernetes Service RBAC Reader` grant reaches `Runbook-Sandbox-PIM.ps1:49` and throws. Resource-scoped roles must take a direct PIM assignment instead.

**Files:**
- Modify: `src/Runbooks/Runbook-Sandbox-PIM.ps1:49-51` (the throw) and the grant call at `:63-66`
- Test: `tests/unit/Runbook-Sandbox-PIM.Tests.ps1`

**Interfaces:**
- Consumes: `Get-RoleCatalogEntry` (Task 1); `New-ActiveAssignment` from the PIM clients (existing).
- Produces: the runbook's returned object gains `Fulfilment = 'DirectPim'` for resource-scoped roles (alongside the existing `'Group'` and `'PimFallback'` values). `GroupId`/`GroupName` are `$null` and `GroupCreated`/`RoleAssignmentCreated` are `$false` on that path; `EngineerActionRequired` is `$false` (a direct assignment is the intended outcome, not a fallback needing follow-up).

- [ ] **Step 1: Write the failing test**

The existing file defines `$script:Runbook`, `$script:SandboxSub`, `$script:Allowlist`, `New-SandboxTicket` (no parameters, returns a Reader ticket), and `Invoke-SandboxRunbook` (no parameters). The new tests need a ticket with a different role and scope, so add an override-capable helper to the existing `BeforeAll` block — insert this immediately after the `New-SandboxTicket` function definition (around line 26):

```powershell
    function New-SandboxTicketWith {
        param([hashtable]$Override = @{})
        $ticket = New-SandboxTicket
        foreach ($k in $Override.Keys) { $ticket[$k] = $Override[$k] }
        return $ticket
    }

    function Invoke-SandboxRunbookWith {
        param([hashtable]$Override = @{})
        return & $script:Runbook -Ticket (New-SandboxTicketWith -Override $Override) `
            -SubscriptionAllowlist $script:Allowlist -PimClientImplementation 'Mock'
    }
```

Then append this `Describe` at the end of the file:

```powershell
Describe 'Runbook-Sandbox-PIM — resource-scoped roles bypass the group path' {
    BeforeEach {
        Reset-MockPimState
        Mock Import-Module {}
    }

    It 'fulfils a Storage data role via a direct PIM assignment' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $scope = "/subscriptions/$($script:SandboxSub)/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        $result = Invoke-SandboxRunbookWith -Override @{
            Role          = 'Storage Blob Data Reader'
            ResourceScope = $scope
            Justification = 'Sandbox blob read access'
        }

        $result.Success | Should -Be $true
        $result.Fulfilment | Should -Be 'DirectPim'
        $result.AssignmentType | Should -Be 'Active'
        $result.GroupId | Should -BeNullOrEmpty
        $result.GroupCreated | Should -Be $false
        $result.RoleAssignmentCreated | Should -Be $false
        $result.EngineerActionRequired | Should -Be $false
        $result.AssignmentId | Should -Not -BeNullOrEmpty
        $result.Scope | Should -Be $scope
        $result.ExpiresAt | Should -Not -BeNullOrEmpty

        # The grant must land at the resource scope, not the subscription.
        @(Get-ActiveAssignments -Client $global:SandboxRunbookSeededClient `
            -UserId '11111111-1111-1111-1111-111111111111' `
            -RoleDefinitionId '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1' `
            -Scope $scope).Count | Should -Be 1
    }

    It 'fulfils an AKS data-plane role via a direct PIM assignment' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $scope = "/subscriptions/$($script:SandboxSub)/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        $result = Invoke-SandboxRunbookWith -Override @{
            Role          = 'Azure Kubernetes Service RBAC Reader'
            ResourceScope = $scope
            Justification = 'Sandbox cluster read access'
        }

        $result.Success | Should -Be $true
        $result.Fulfilment | Should -Be 'DirectPim'
        $result.Scope | Should -Be $scope
    }

    It 'still uses the group path for subscription-scoped Contributor' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $result = Invoke-SandboxRunbookWith -Override @{ Role = 'Contributor' }

        $result.Fulfilment | Should -Be 'Group'
        $result.GroupName | Should -Be 'sg-platform-sandbox-contributors'
    }

    It 'throws for a role absent from the catalog' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        # Get-RoleDefinitionId throws first (line 33, before the gate) — either message is
        # an acceptable fail-closed outcome; the point is that it does not silently grant.
        { Invoke-SandboxRunbookWith -Override @{ Role = 'Totally Made Up Role' } } | Should -Throw
    }
}
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\Runbook-Sandbox-PIM.Tests.ps1"`

Expected: FAIL with `Granted role 'Storage Blob Data Reader' is not supported by the sandbox group-first runbook.`

- [ ] **Step 3: Replace the throw with a scope-type gate**

In `src/Runbooks/Runbook-Sandbox-PIM.ps1`, replace lines 49–51:

```powershell
if ($Ticket.Role -notin @('Reader', 'Contributor', 'Writer')) {
    throw "Granted role '$($Ticket.Role)' is not supported by the sandbox group-first runbook."
}
```

with:

```powershell
# Group-based fulfilment only makes sense for subscription-scoped roles: the RBAC groups
# hold a role at subscription scope. Resource-scoped roles (Storage data plane, AKS RBAC)
# take a direct time-bound PIM assignment at the resource itself instead.
$roleEntry = Get-RoleCatalogEntry -RoleName $Ticket.Role
if (-not $roleEntry) {
    throw "Granted role '$($Ticket.Role)' is not present in role-catalog.json."
}
$useGroupPath = ($roleEntry.scopeType -eq 'subscription')
```

- [ ] **Step 4: Branch the grant call**

Replace lines 63–66 (the `$grant = Invoke-GroupOrPimGrant ...` call) with:

```powershell
$grant = if ($useGroupPath) {
    Invoke-GroupOrPimGrant -Client $pimClient -UserId $userId -RoleName $Ticket.Role `
        -SubscriptionId $subId -SubscriptionName $Ticket.SubscriptionName `
        -ResourceScope $Ticket.ResourceScope -DurationDays ([int]$Ticket.DurationDays) `
        -Justification ([string]$Ticket.Justification)
}
else {
    $assignment = New-ActiveAssignment -Client $pimClient -UserId $userId `
        -RoleDefinitionId $roleDefId -Scope $Ticket.ResourceScope `
        -DurationDays ([int]$Ticket.DurationDays) `
        -Justification ([string]$Ticket.Justification)

    [pscustomobject]@{
        Success                = $true
        Fulfilment             = 'DirectPim'
        GroupId                = $null
        GroupName              = $null
        GroupCreated           = $false
        RoleAssignmentCreated  = $false
        AssignmentId           = $assignment.id
        EngineerActionRequired = $false
        EngineerActionReason   = $null
        Message                = "Granted $($Ticket.Role) at $($Ticket.ResourceScope) via direct PIM assignment (resource-scoped role)."
    }
}
```

- [ ] **Step 5: Make `ExpiresAt` cover the direct path**

The return block computes `ExpiresAt` only when `Fulfilment -eq 'PimFallback'`. A direct PIM assignment is also time-bound, so replace that conditional (lines 83–88 in the original file):

```powershell
    ExpiresAt              = if ($grant.Fulfilment -eq 'PimFallback') {
        (Get-Date).AddDays([int]$Ticket.DurationDays).ToUniversalTime()
    }
    else {
        $null
    }
```

with:

```powershell
    ExpiresAt              = if ($grant.Fulfilment -in @('PimFallback', 'DirectPim')) {
        (Get-Date).AddDays([int]$Ticket.DurationDays).ToUniversalTime()
    }
    else {
        $null
    }
```

Also update the `AssignmentType` line so the direct path reports `Active` (it already does — `if ($grant.Fulfilment -eq 'Group') { 'GroupMembership' } else { 'Active' }` — verify, do not change).

- [ ] **Step 6: Run the test to verify it passes**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\Runbook-Sandbox-PIM.Tests.ps1"`

Expected: PASS, both new tests and all pre-existing ones in the file.

- [ ] **Step 7: Run the full suite**

Run: `.\tests\Run-Pester.ps1`

Expected: `FAILED=0`.

- [ ] **Step 8: Commit**

```bash
git add src/Runbooks/Runbook-Sandbox-PIM.ps1 tests/unit/Runbook-Sandbox-PIM.Tests.ps1
git commit -m "fix(runbook): route resource-scoped roles to direct PIM instead of throwing"
```

---

### Task 7: Approver tier fallback (spec Gap 1)

Without this, a Production `Storage Blob Data Contributor` request returns `Eligible` with `Approvers = @()` — approval-gated with nobody to approve.

**Files:**
- Modify: `src/RbacDecision/Public/Resolve-RbacDecision.ps1:142-157` (approver resolution)
- Test: `tests/unit/RbacDecision.Tests.ps1`

**Interfaces:**
- Consumes: `Get-RoleTier` (Task 1).
- Produces: no signature change. Approver resolution now tries the exact role name first, then the role's tier name, against `approver-mapping.json`'s `roles` object.

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/RbacDecision.Tests.ps1`:

```powershell
Describe 'Resolve-RbacDecision — approver resolution for expanded roles' {
    BeforeAll {
        # This subscription has per-role approver entries in approver-mapping.json.
        $script:MappedProdSub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    }

    It 'falls back to the Contributor tier approvers for a Storage data role' {
        $t = New-TestTicket -Environment Production -Role 'Storage Blob Data Contributor' -Priority P3 -Extra @{
            ResourceScope = "/subscriptions/$script:MappedProdSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $t.SubscriptionId = $script:MappedProdSub
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist @($script:MappedProdSub)
        $d.Action | Should -Be 'Eligible'
        $d.Approvers | Should -Not -BeNullOrEmpty
        $d.Approvers | Should -Contain 'sangeetha.baskaran@inceptionai.ai'
    }

    It 'falls back to the Owner tier approvers for an AKS Cluster Admin role' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Priority P3 -Extra @{
            ResourceScope = "/subscriptions/$script:MappedProdSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $t.SubscriptionId = $script:MappedProdSub
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist @($script:MappedProdSub)
        $d.ApproverTier | Should -Be 'Dual'
        $d.Approvers | Should -Not -BeNullOrEmpty
    }

    It 'still prefers an exact role-name approver entry over the tier fallback' {
        $t = New-TestTicket -Environment Production -Role Contributor -Priority P3
        $t.SubscriptionId = $script:MappedProdSub
        $t.ResourceScope = "/subscriptions/$script:MappedProdSub"
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist @($script:MappedProdSub)
        $d.Approvers | Should -Contain 'sangeetha.baskaran@inceptionai.ai'
        $d.Approvers | Should -Contain 'sivasankar.pushpavan@inceptionai.ai'
    }
}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: FAIL — the first two tests get an empty `Approvers` array because `approver-mapping.json` has no `Storage Blob Data Contributor` / `Azure Kubernetes Service RBAC Cluster Admin` key. The third should already pass.

- [ ] **Step 3: Add the tier fallback**

In `src/RbacDecision/Public/Resolve-RbacDecision.ps1`, replace the approver resolution block (lines 142–157) with:

```powershell
    # Resolve approver emails from mapping (§6.3). Exact role name wins; otherwise fall
    # back to the role's tier entry, so a new catalog role inherits its tier's approvers
    # instead of returning an approver-less Eligible decision.
    $approvers = @()
    if ($approverTier -and (Test-Path $ApproverMappingPath)) {
        $approverMap = Get-Content -Raw -Path $ApproverMappingPath | ConvertFrom-Json
        $primarySubId = $subscriptionIds[0]
        if ($approverMap.subscriptions.PSObject.Properties.Name -contains $primarySubId) {
            $subMapping = $approverMap.subscriptions.$primarySubId
            $role = [string]$Ticket.Role
            $lookupKeys = @($role)
            $roleTier = Get-RoleTier -RoleName $role -Path $RoleCatalogPath
            if ($roleTier -and $roleTier -ne $role) { $lookupKeys += $roleTier }

            foreach ($key in $lookupKeys) {
                if ($subMapping.roles.PSObject.Properties.Name -contains $key) {
                    $roleMapping = $subMapping.roles.$key
                    $approvers = @($roleMapping.primary)
                    if ($roleMapping.backup) { $approvers += @($roleMapping.backup) }
                    $approvers = @($approvers | Select-Object -Unique)
                    break
                }
            }
        }
    }
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Pester .\tests\unit\RbacDecision.Tests.ps1"`

Expected: PASS.

- [ ] **Step 5: Run the full suite**

Run: `.\tests\Run-Pester.ps1`

Expected: `FAILED=0`.

- [ ] **Step 6: Document the catalog in the README role table**

In `README.md`, the Overview table describes `Reader/Contributor on approved sandbox subscriptions`. Add one row after the existing `Sandbox automation` row:

```markdown
| **Extensible roles** | Storage Blob Data and AKS RBAC roles supported; new Azure roles added via `src/RbacDecision/Data/role-catalog.json` (tier + scope), no code change |
```

- [ ] **Step 7: Commit**

```bash
git add src/RbacDecision/Public/Resolve-RbacDecision.ps1 tests/unit/RbacDecision.Tests.ps1 README.md
git commit -m "fix(rbac): fall back to tier approvers for catalog roles"
```

---

## Verification

After Task 7, confirm the whole feature end to end:

- [ ] **Full suite green:** `.\tests\Run-Pester.ps1` → `FAILED=0`, total ≥ 330 (baseline) plus the new tests.
- [ ] **Adding a role needs no code change:** temporarily add a throwaway entry to `role-catalog.json` (e.g. `"Key Vault Secrets User": { "tier": "Reader", "roleDefinitionId": "4633458b-17de-408a-b874-0445c86b69e6", "scopeType": "resource", "resourceType": "Microsoft.KeyVault/vaults" }`), confirm `Get-RoleTier -RoleName 'Key Vault Secrets User'` returns `Reader` and a Sandbox ticket for it at a vault scope returns `Grant` — then **revert the throwaway entry** (it is not in scope for this change).
- [ ] **No duplicated GUID tables remain:** `grep -rn "acdd72a7-3385-48ef-bd42-f606fba81ae7" src/` should match only `role-catalog.json` (tests may still reference it as an expected value).
- [ ] **Staging snapshot untouched:** `git status` shows no changes under `dashboard/deploy/staging/`.
- [ ] **PIM role settings gap recorded (spec Rollout item 3):** `infra/pim/rolesettings.sandbox.json` and `rolesettings.production.json` each carry a `"roles": [...]` list that `Set-PimRoleSettings.ps1` applies duration/MFA rules to; both currently list only `Reader`/`Contributor` (+ Owner/UAA in production). The new roles are **not** in those lists, so PIM policy rules will not be applied to them at deploy time. Infra is not yet deployed (README: Phase 3 exit not met), so this is not a live defect — but do not silently leave it: add a `_note` to both files naming the new roles as pending, and record the follow-up in `progress.md` under blockers. Extending the lists for real is a deploy-time change requiring PIM policy review, out of scope here.

## Out of scope (confirm with the requester before adding)

These reference role names but are deliberately not changed by this plan:

- `dashboard/` role dropdowns and demo fixtures — the dashboard is a prototype; new roles will not appear in its UI until separately updated.
- `src/Agents/TicketCategorizationAgent.ps1` and `EnvironmentInferenceAgent.ps1` — ticket-text classification heuristics. New roles arriving via free-text tickets may not be recognized by the categorizer; requests naming them explicitly still work.
- `src/PimClient/GroupRbac.ps1` — `Get-RbacGroupRoleSuffix` still supports only Reader/Contributor/Writer by design (Task 6 gates callers rather than extending it).
- `Runbook-Prod-PIM.ps1` / `Runbook-Emergency-PIM.ps1` — these call `Get-RoleDefinitionId` and assign at `$Ticket.ResourceScope`, so they already handle resource-scoped roles once Task 5 lands. Verify during Task 5's full-suite run; no edit anticipated.
