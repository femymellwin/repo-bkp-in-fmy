# Unattended ManageEngine Ticket Poller Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Auto-process ManageEngine access-request tickets end-to-end with no human click, for the narrow slice where policy already says no human is needed.

**Architecture:** A separate PowerShell process on `vm-incp-uaen-001-sentry` (Ubuntu 22.04), launched by a systemd timer every 5 minutes. It reuses the existing decision engine and grant path rather than reimplementing them: fetch recent ME tickets → map structured dropdown fields → `Resolve-RbacDecision` → a four-condition auto-eligibility gate → `Invoke-GroupOrPimGrant`. Ships in shadow mode (decides and records, writes nothing) until an env var flips it to enforce.

**Tech Stack:** Windows PowerShell 5.1 (no `pwsh`, no Az/Graph SDK modules — raw REST only), Pester 5 for tests, existing `RbacDecision` module, existing `GraphPimClient`/`GroupRbac`, React + MUI for the status panel.

## Global Constraints

- **Must run on BOTH Windows PowerShell 5.1 and `pwsh` 7 on Linux.** Local development and the whole test suite run on Windows PS 5.1; **production is `vm-incp-uaen-001-sentry`, Ubuntu 22.04 with systemd**, app at `/opt/azuresentry`, env at `/etc/azuresentry.env` (see `docs/vm-access-guide.md`, `scripts/Deploy-ToVm.ps1`). Use no Windows-only cmdlet or API — in particular no `*-ScheduledTask*`, no registry, and no `System.Threading.Mutex` for cross-process locking (on Linux that is backed by `/tmp/.dotnet/shm`, which a systemd unit setting `PrivateTmp=true` silently partitions). **There is no cross-process lock at all:** the processed-ticket store is one file per ticket, and mutual exclusion comes from a single atomic `[System.IO.File]::Open(..., CreateNew, ...)` via `Request-ProcessedTicketClaim`. Note the 3-argument `[System.IO.File]::Move(src,dst,overwrite)` overload is .NET Core 3.0+ only and does **not** exist on PS 5.1's .NET Framework 4.x, and `[System.IO.File]::Replace($tmp,$dst,$null)` is unreachable from PowerShell (it coerces `$null` to an empty string at binding time) — both were found the hard way.
- **No Az modules, no Microsoft.Graph SDK.** All HTTP via `Invoke-RestMethod`/`Invoke-WebRequest`.
- **Tests passing locally on Windows is not evidence the production path works.** Anything platform-sensitive needs a note in the runbook on how to verify it on the VM.
- **`Resolve-RbacDecision` must not be modified.** The poller consumes it; policy stays in `eligibility-matrix.json`.
- **Auto-execute scope is `Grant` only, excluding Production.** Never `Eligible`, `Hold`, `Reject`, or `BreakGlass`. `prod-reader-*` is `Grant` in the matrix and is still excluded.
- **No free-text inference in the auto path.** Only ME structured dropdown values. Subscription name matching must be **exact** (case-insensitive, trimmed) against the effective allowlist — no substring or fuzzy matching, unlike the UI's `matchSubscriptionNameToCatalog`.
- **Gate on the decision's *effective* environment**, never the ticket's claimed environment. `Resolve-RbacDecision` raises environment from subscription sensitivity.
- **Fail-closed.** Any execution error stops the cycle; it does not continue to the next ticket.
- **Default off.** `AZURESENTRY_POLLER_ENABLED` must be exactly `true` to do anything; `AZURESENTRY_POLLER_MODE` defaults to `shadow`.
- **Shadow mode must never say "skipped."** Use `wouldGrant`. The environment-backfill dry run reported `0 written · 0 failed · N skipped` and that wording cost real debugging time.
- Test files go in `tests/unit/`, named `<Subject>.Tests.ps1`, opening with a `BeforeAll` that computes `$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent` and dot-sources what it needs.
- Run tests with `powershell -NoProfile -Command "Invoke-Pester -Path <path> -Output Detailed"`.

---

### Task 1: Shared modules out of the API script — COMPLETE (as-built)

> **Status: done and reviewed.** The original plan text for this task specified a
> single-JSON-file store guarded by a `System.Threading.Mutex`. That approach was
> abandoned after two review rounds each found a new Critical defect in the hand-rolled
> lock. What shipped is recorded below; the superseded design is in git history
> (commits `ee5911c`, `67c3196`, `60dc5a9`) and is **not** what later tasks build on.

**Why the design changed:** storing a per-ticket yes/no in one shared document forces
read-modify-write, which forces a cross-process lock. That lock produced, in order: a
torn write that silently emptied the store; a concurrency test that passed 1-in-3 against
a broken lock; an unbounded 100%-CPU spin with no timeout; a `Move-Item -Force` that is
delete-then-rename rather than an atomic replace; and a POSIX `unlink` TOCTOU letting two
processes into the critical section on the Ubuntu production target. Changing the data
model removed the entire class.

**Files as built:**
- `dashboard/api/ProcessedStore.ps1` — one JSON file per ticket in a sibling directory
  (`processed-tickets/`). **No lock of any kind.**
- `dashboard/api/MeAccessFields.ps1` — `Get-MeUdfFieldValue`, `Get-MeTemplateAccessFields`
  (udf key overrides as a **parameter**, not a `$config` script-scope read), and
  `Get-MeConfiguredAccessFields -UdfFields -Config`.
- `dashboard/api/Start-DashboardApi.ps1` — dot-sources both; three
  `Get-MeConfiguredAccessFields` call sites.
- `tests/unit/ProcessedStore.Tests.ps1`, `tests/unit/MeAccessFields.Tests.ps1`.

**Public surface later tasks must use:**
- `Initialize-ProcessedStore -Path <legacy json path>` — derives the store directory,
  creates it, and migrates any legacy `processed-tickets.json` into per-ticket files
  (idempotent, concurrency-safe, preserves a corrupt legacy file rather than renaming it).
- `Get-ProcessedTickets` → `hashtable` keyed by the original ticket id (read from inside
  each file, never from the filename).
- `Save-ProcessedTicket -MeTicketId <string> -Entry <object>` — create or overwrite
  atomically; **throws** on genuine write failure.
- `Request-ProcessedTicketClaim -MeTicketId <string> -Entry <object>` → `$true` only if
  this caller atomically won the claim, `$false` if another process already holds it.
  **This is the primitive the poller must use** to guarantee it never grants twice.
  Losing the race is a normal outcome and does not throw.
- `Remove-ProcessedTicketEntry -MeTicketId <string>`.

**`Invoke-WithProcessedStoreLock` does not exist.** Any later task that would have taken a
lock around read-decide-write must instead claim the ticket with
`Request-ProcessedTicketClaim` and then do the slow work (the Azure grant, the ME calls)
**outside** any exclusive section — there is nothing to hold, and nothing to block the
dashboard's single-threaded `HttpListener` loop.

**Cross-platform notes learned here, binding on later tasks:**
- Filenames are the sanitised ticket id plus a **SHA1**-derived suffix. Do not use
  `GetHashCode()` — it is randomised per process on .NET Core.
- The 3-arg `[System.IO.File]::Move(src,dst,overwrite)` exists on pwsh 7 but **not** on
  PS 5.1; the store branches on `$PSVersionTable.PSEdition`.
- `[System.IO.File]::Replace($tmp,$dst,$null)` throws on both hosts — PowerShell coerces
  `$null` to an empty string at parameter binding, so the "no backup" overload is
  unreachable.
- `dashboard/api/processed-tickets/` is a **directory**: deploy exclusions (`/XD`) and
  `.gitignore` must name the directory, not the old file.

### Task 2: Structured-field ticket mapper

Map ME template dropdowns to a canonical ticket the decision engine accepts, and report whether the mapping is complete enough to act on unattended. No free-text inference: the UI's parser exists to help a human triage and must not decide unattended privilege. Subscription matching is **exact**, unlike the UI's substring matcher.

**Files:**
- Create: `src/Agents/MeTicketMapper.ps1`
- Test: `tests/unit/MeTicketMapper.Tests.ps1`

**Interfaces:**
- Consumes: nothing from earlier tasks.
- Produces:
  - `Get-CanonicalAzureRole -Raw <string>` → `string` (`'Reader'`/`'Contributor'`/`'Writer'`/`'Owner'`/`'UAA'`, or `''` when unrecognized)
  - `Get-CanonicalEnvironment -Raw <string>` → `string` (`'Sandbox'`/`'NonProd'`/`'Production'`, or `''`)
  - `Resolve-AllowlistSubscriptionId -Name <string> -AllowlistDetails <object[]>` → `string` (GUID, or `''`)
  - `Resolve-MeTicketMapping -AccessFields <object> -MeTicket <object> -AllowlistDetails <object[]> [-DurationDays <int>]` → `pscustomobject` with `Complete` (bool), `Warnings` (string[]), `Ticket` (pscustomobject or `$null`)

`Ticket`, when `Complete` is true, carries: `TicketId`, `Role`, `Environment`, `SubscriptionId`, `SubscriptionName`, `RequesterUpn`, `SubmitterUpn`, `Priority`, `DurationDays`, `ResourceScope`, `Justification`.

- [ ] **Step 1: Write the failing test**

Create `tests/unit/MeTicketMapper.Tests.ps1`:

```powershell
BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\MeTicketMapper.ps1')

    $script:Allowlist = @(
        [pscustomobject]@{ id = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'; name = 'inception-ai-Sandbox' }
        [pscustomobject]@{ id = '1251f2d0-787f-4063-8b74-178ad167c682'; name = 'ceo-sub-application' }
    )

    function New-MeAccess {
        param([string]$Subscription = 'inception-ai-Sandbox', [string]$AzureRole = 'Reader', [string]$Environment = 'Sandbox')
        [ordered]@{ Subscription = $Subscription; AzureRole = $AzureRole; Environment = $Environment }
    }

    function New-MeReq {
        param([string]$Id = '9001', [string]$Subject = 'Need access', [string]$Email = 'dev.user@contoso.com', [string]$Priority = 'P3')
        [pscustomobject]@{
            id = $Id; subject = $Subject
            requester = [pscustomobject]@{ email_id = $Email; name = 'Dev User' }
            priority  = [pscustomobject]@{ name = $Priority }
            description = 'Please grant access.'
        }
    }
}

Describe 'Get-CanonicalAzureRole' {
    It 'maps the ME dropdown labels to platform roles' {
        Get-CanonicalAzureRole -Raw 'Reader'              | Should -Be 'Reader'
        Get-CanonicalAzureRole -Raw 'Read Only'           | Should -Be 'Reader'
        Get-CanonicalAzureRole -Raw 'Contributor'         | Should -Be 'Contributor'
        Get-CanonicalAzureRole -Raw 'contrib'             | Should -Be 'Contributor'
        Get-CanonicalAzureRole -Raw 'Writer'              | Should -Be 'Writer'
        Get-CanonicalAzureRole -Raw 'Owner'               | Should -Be 'Owner'
        Get-CanonicalAzureRole -Raw 'User Access Admin'   | Should -Be 'UAA'
        Get-CanonicalAzureRole -Raw 'UAA'                 | Should -Be 'UAA'
    }

    It 'returns empty for anything it does not recognise rather than guessing' {
        Get-CanonicalAzureRole -Raw 'AKS Cluster Admin' | Should -Be ''
        Get-CanonicalAzureRole -Raw ''                  | Should -Be ''
    }
}

Describe 'Get-CanonicalEnvironment' {
    It 'checks non-prod terms before production so "non-prod" is not read as prod' {
        Get-CanonicalEnvironment -Raw 'Non-Prod'    | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'non prod'    | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'UAT'         | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'Sandbox'     | Should -Be 'Sandbox'
        Get-CanonicalEnvironment -Raw 'Production'  | Should -Be 'Production'
    }

    It 'returns empty for an unmappable value' {
        Get-CanonicalEnvironment -Raw 'Somewhere else' | Should -Be ''
        Get-CanonicalEnvironment -Raw ''               | Should -Be ''
    }
}

Describe 'Resolve-AllowlistSubscriptionId — exact matching only' {
    It 'matches an allowlisted name case-insensitively' {
        Resolve-AllowlistSubscriptionId -Name 'inception-ai-sandbox' -AllowlistDetails $script:Allowlist |
            Should -Be 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
    }

    It 'accepts a bare GUID that is on the allowlist' {
        Resolve-AllowlistSubscriptionId -Name '1251f2d0-787f-4063-8b74-178ad167c682' -AllowlistDetails $script:Allowlist |
            Should -Be '1251f2d0-787f-4063-8b74-178ad167c682'
    }

    It 'refuses a GUID that is NOT on the allowlist' {
        Resolve-AllowlistSubscriptionId -Name '00000000-0000-0000-0000-000000000000' -AllowlistDetails $script:Allowlist |
            Should -Be ''
    }

    It 'refuses a partial name — no substring matching in the unattended path' {
        # The UI deliberately fuzzy-matches to help an operator. Unattended granting
        # must not: "Sandbox" could match several subscriptions.
        Resolve-AllowlistSubscriptionId -Name 'Sandbox' -AllowlistDetails $script:Allowlist | Should -Be ''
        Resolve-AllowlistSubscriptionId -Name 'inception' -AllowlistDetails $script:Allowlist | Should -Be ''
    }
}

Describe 'Resolve-MeTicketMapping' {

    It 'produces a complete mapping when every dropdown is populated and allowlisted' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeTrue
        $m.Warnings.Count | Should -Be 0
        $m.Ticket.Role | Should -Be 'Reader'
        $m.Ticket.Environment | Should -Be 'Sandbox'
        $m.Ticket.SubscriptionId | Should -Be 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
        $m.Ticket.SubscriptionName | Should -Be 'inception-ai-Sandbox'
        $m.Ticket.RequesterUpn | Should -Be 'dev.user@contoso.com'
        $m.Ticket.ResourceScope | Should -Be '/subscriptions/efae0e0e-09ab-4c17-82db-d2d1f4382d66'
        $m.Ticket.TicketId | Should -Be '9001'
    }

    It 'is incomplete and names the field when the role dropdown is blank' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole '') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'Azure Role'
    }

    It 'is incomplete and names the field when the environment dropdown is blank' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -Environment '') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'Environment'
    }

    It 'is incomplete when the subscription is set but not allowlisted' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -Subscription 'some-other-sub') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'not on the allowlist'
    }

    It 'is incomplete when the role is an unrecognised ME label' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole 'AKS Cluster Admin') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'did not map'
    }

    It 'never infers from the ticket body even when it plainly states an environment' {
        # Free-text inference is the UI's job. Unattended, a blank dropdown means queue.
        $req = New-MeReq
        $req.description = 'This is definitely for the sandbox environment, Reader please.'
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -Environment '') -MeTicket $req -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
    }

    It 'is incomplete when the requester has no email to resolve' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket (New-MeReq -Email '') -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'requester'
    }

    It 'carries the ME priority through and defaults it when absent' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket (New-MeReq -Priority 'P2') -AllowlistDetails $script:Allowlist
        $m.Ticket.Priority | Should -Be 'P2'

        $noPri = New-MeReq
        $noPri.priority = $null
        $m2 = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket $noPri -AllowlistDetails $script:Allowlist
        $m2.Ticket.Priority | Should -Be 'P3'
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit/MeTicketMapper.Tests.ps1 -Output Detailed"`
Expected: FAIL — `The term 'Get-CanonicalAzureRole' is not recognized`.

- [ ] **Step 3: Write the implementation**

Create `src/Agents/MeTicketMapper.ps1`:

```powershell
<#
.SYNOPSIS
    Maps ManageEngine structured template fields to a canonical decision-engine ticket.

.DESCRIPTION
    The dashboard UI has a much richer mapper (parseTicket in TicketsView.tsx) that falls
    back to parsing free text when the ME dropdowns are blank. That fallback exists to help
    a human triage a vague ticket; it must not decide unattended privilege, and duplicating
    it here would create two implementations of privilege-determining logic that drift.

    So this mapper is deliberately narrow: structured dropdowns only, exact subscription
    matching, and an explicit Complete verdict. Anything it cannot resolve without guessing
    is reported incomplete and queues for a human, where the UI's full mapper applies.

    Role and environment canonicalisation intentionally mirrors mapMeAzureRole and
    mapMeEnvironment in dashboard/web/src/extractMeAccessFields.ts. Keep them in step.
#>

function Get-CanonicalAzureRole {
    <#
    .SYNOPSIS
      ME "Azure Role" dropdown label to platform role. Empty when unrecognised.
    .DESCRIPTION
      Returns '' rather than echoing the raw label (which the UI does, so an operator can
      see what was asked for). Unattended, an unrecognised role must not reach the decision
      engine at all.
    #>
    param([string]$Raw)

    $v = ([string]$Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($v)) { return '' }

    $n = ($v.ToLowerInvariant() -replace '[_-]+', ' ') -replace '\s+', ' '
    $n = $n.Trim()

    if ($n -match 'user access admin|\buaa\b') { return 'UAA' }
    if ($n -match '\bowner\b') { return 'Owner' }
    if ($n -match '\bwriter\b|write access') { return 'Writer' }
    if ($n -match '\bcontrib') { return 'Contributor' }
    if ($n -match '\breader\b|\bread only\b') { return 'Reader' }
    return ''
}

function Get-CanonicalEnvironment {
    <#
    .SYNOPSIS
      ME "Environment" dropdown label to Sandbox / NonProd / Production. Empty otherwise.
    #>
    param([string]$Raw)

    $n = ([string]$Raw).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($n)) { return '' }

    # Order matters: non-prod terms are tested before a bare 'prod' so "non-prod" is
    # never read as Production.
    if ($n -match '\bsandbox\b|\bsbx\b|\blab\b') { return 'Sandbox' }
    if ($n -match 'non[\s_-]?prod|\bstaging\b|\bstage\b|\buat\b|\bqa\b|\bdev(?:elopment)?\b|\btest(?:ing)?\b|pre[\s_-]?prod|\btraining\b') { return 'NonProd' }
    if ($n -match '\bproduction\b|\bprod\b|\bprd\b') { return 'Production' }
    return ''
}

function Resolve-AllowlistSubscriptionId {
    <#
    .SYNOPSIS
      Exact-match an ME subscription value against the effective allowlist.
    .DESCRIPTION
      Exact (case-insensitive, trimmed) only. The UI substring-matches to be forgiving for
      an operator who can see and correct the result; unattended that is unsafe, because a
      value like "Sandbox" can match several subscriptions and the wrong one would receive
      a real grant. A bare GUID is accepted only if it is itself on the allowlist.
    #>
    param(
        [string]$Name,
        [object[]]$AllowlistDetails = @()
    )

    $needle = ([string]$Name).Trim()
    if ([string]::IsNullOrWhiteSpace($needle)) { return '' }

    foreach ($entry in $AllowlistDetails) {
        $id = [string]$entry.id
        if ($id -and $id.Equals($needle, [System.StringComparison]::OrdinalIgnoreCase)) { return $id }
    }
    foreach ($entry in $AllowlistDetails) {
        $name = [string]$entry.name
        if ($name -and $name.Trim().Equals($needle, [System.StringComparison]::OrdinalIgnoreCase)) {
            return [string]$entry.id
        }
    }
    return ''
}

function Resolve-MeTicketMapping {
    <#
    .SYNOPSIS
      Build a canonical ticket from ME structured fields, with a Complete verdict.
    .OUTPUTS
      pscustomobject with Complete (bool), Warnings (string[]), Ticket (pscustomobject|$null).
    #>
    param(
        [Parameter(Mandatory)][object]$AccessFields,
        [Parameter(Mandatory)][object]$MeTicket,
        [object[]]$AllowlistDetails = @(),
        [int]$DurationDays = 7
    )

    $warnings = [System.Collections.Generic.List[string]]::new()

    $rawSub = [string]$AccessFields.Subscription
    $rawRole = [string]$AccessFields.AzureRole
    $rawEnv = [string]$AccessFields.Environment

    $role = Get-CanonicalAzureRole -Raw $rawRole
    if ([string]::IsNullOrWhiteSpace($rawRole)) {
        $warnings.Add('Azure Role dropdown is not set on the ManageEngine ticket.')
    }
    elseif (-not $role) {
        $warnings.Add("Azure Role '$rawRole' did not map to a platform role.")
    }

    $environment = Get-CanonicalEnvironment -Raw $rawEnv
    if ([string]::IsNullOrWhiteSpace($rawEnv)) {
        $warnings.Add('Environment dropdown is not set on the ManageEngine ticket.')
    }
    elseif (-not $environment) {
        $warnings.Add("Environment '$rawEnv' did not map to Sandbox / NonProd / Production.")
    }

    $subscriptionId = Resolve-AllowlistSubscriptionId -Name $rawSub -AllowlistDetails $AllowlistDetails
    if ([string]::IsNullOrWhiteSpace($rawSub)) {
        $warnings.Add('Subscription dropdown is not set on the ManageEngine ticket.')
    }
    elseif (-not $subscriptionId) {
        $warnings.Add("Subscription '$rawSub' is not on the allowlist by exact name.")
    }

    $requesterUpn = ''
    if ($MeTicket.requester) {
        $requesterUpn = [string]$MeTicket.requester.email_id
    }
    if ([string]::IsNullOrWhiteSpace($requesterUpn)) {
        $warnings.Add('ManageEngine ticket has no requester email to resolve to an object id.')
    }

    $priority = 'P3'
    if ($MeTicket.priority -and $MeTicket.priority.name) {
        $p = ([string]$MeTicket.priority.name).Trim().ToUpperInvariant()
        if ($p -match '^P[1-4]$') { $priority = $p }
    }

    $subscriptionName = ''
    if ($subscriptionId) {
        $hit = @($AllowlistDetails | Where-Object { [string]$_.id -eq $subscriptionId } | Select-Object -First 1)
        if ($hit.Count -gt 0 -and $hit[0].name) { $subscriptionName = [string]$hit[0].name }
    }

    $complete = ($warnings.Count -eq 0)
    $ticket = $null
    if ($complete) {
        $ticket = [pscustomobject]@{
            TicketId         = [string]$MeTicket.id
            Role             = $role
            Environment      = $environment
            SubscriptionId   = $subscriptionId
            SubscriptionName = $subscriptionName
            RequesterUpn     = $requesterUpn
            SubmitterUpn     = $requesterUpn
            Priority         = $priority
            DurationDays     = $DurationDays
            ResourceScope    = "/subscriptions/$subscriptionId"
            Justification    = "Unattended grant from ManageEngine ticket #$([string]$MeTicket.id): $([string]$MeTicket.subject)"
        }
    }

    return [pscustomobject]@{
        Complete = $complete
        Warnings = @($warnings)
        Ticket   = $ticket
    }
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit/MeTicketMapper.Tests.ps1 -Output Detailed"`
Expected: PASS, 15 tests.

- [ ] **Step 5: Commit**

```bash
git add src/Agents/MeTicketMapper.ps1 tests/unit/MeTicketMapper.Tests.ps1
git commit -m "Add structured-field ME ticket mapper for the unattended path

Maps ME template dropdowns to a canonical decision-engine ticket with an
explicit Complete verdict. Deliberately narrower than the UI's parseTicket: no
free-text fallback, and exact subscription matching rather than the UI's
substring match, because a value like 'Sandbox' can match several
subscriptions and unattended the wrong one would receive a real grant.
Anything unresolvable without guessing is reported incomplete and queues."
```

---

### Task 3: The auto-eligibility gate

The single place that decides whether a ticket may be granted with no human involved. Kept separate from the cycle so it can be tested exhaustively against the policy matrix without any ME or Azure I/O.

**Files:**
- Create: `src/Agents/PollerGate.ps1`
- Test: `tests/unit/PollerGate.Tests.ps1`

**Interfaces:**
- Consumes: nothing from earlier tasks.
- Produces:
  - `Test-PollerAutoEligible -Decision <object> -Mapping <object> -TemplateAllowed <bool>` → `pscustomobject` with `Eligible` (bool) and `Reason` (string)

`Decision` is a `Resolve-RbacDecision` record; the gate reads `.Action` and `.EffectiveEnvironment`. `Mapping` is a `Resolve-MeTicketMapping` result; the gate reads `.Complete` and `.Warnings`.

- [ ] **Step 1: Write the failing test**

Create `tests/unit/PollerGate.Tests.ps1`:

```powershell
BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\PollerGate.ps1')

    function New-Decision {
        param([string]$Action = 'Grant', [string]$EffectiveEnvironment = 'Sandbox')
        [pscustomobject]@{ Action = $Action; EffectiveEnvironment = $EffectiveEnvironment; Path = 'test' }
    }

    function New-Mapping {
        param([bool]$Complete = $true, [string[]]$Warnings = @())
        [pscustomobject]@{ Complete = $Complete; Warnings = $Warnings; Ticket = [pscustomobject]@{ Role = 'Reader' } }
    }
}

Describe 'Test-PollerAutoEligible — the unattended gate' {

    It 'allows Grant on Sandbox' {
        (Test-PollerAutoEligible -Decision (New-Decision) -Mapping (New-Mapping) -TemplateAllowed $true).Eligible |
            Should -BeTrue
    }

    It 'allows Grant on NonProd' {
        (Test-PollerAutoEligible -Decision (New-Decision -EffectiveEnvironment 'NonProd') -Mapping (New-Mapping) -TemplateAllowed $true).Eligible |
            Should -BeTrue
    }

    It 'refuses Grant on Production even though the matrix marks prod-reader as Grant' {
        # prod-reader-standard / prod-reader-expedited are action=Grant with no approver.
        # Read-only, but still unattended Production access -- excluded by decision.
        $r = Test-PollerAutoEligible -Decision (New-Decision -EffectiveEnvironment 'Production') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'Production'
    }

    It 'refuses Eligible — its approval gate is the operator click in the dashboard' {
        $r = Test-PollerAutoEligible -Decision (New-Decision -Action 'Eligible' -EffectiveEnvironment 'NonProd') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'Eligible'
    }

    It 'refuses Hold, Reject and BreakGlass' {
        foreach ($action in @('Hold', 'Reject', 'BreakGlass')) {
            $r = Test-PollerAutoEligible -Decision (New-Decision -Action $action) -Mapping (New-Mapping) -TemplateAllowed $true
            $r.Eligible | Should -BeFalse
        }
    }

    It 'refuses an incomplete mapping' {
        $r = Test-PollerAutoEligible -Decision (New-Decision) -Mapping (New-Mapping -Complete $false -Warnings @('Environment dropdown is not set.')) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'Environment dropdown'
    }

    It 'refuses a non-grant template' {
        $r = Test-PollerAutoEligible -Decision (New-Decision) -Mapping (New-Mapping) -TemplateAllowed $false
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'template'
    }

    It 'refuses when the effective environment is missing rather than assuming it is safe' {
        $r = Test-PollerAutoEligible -Decision (New-Decision -EffectiveEnvironment '') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
    }

    It 'gives a reason on every refusal' {
        $r = Test-PollerAutoEligible -Decision (New-Decision -Action 'Reject') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Reason | Should -Not -BeNullOrEmpty
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit/PollerGate.Tests.ps1 -Output Detailed"`
Expected: FAIL — `The term 'Test-PollerAutoEligible' is not recognized`.

- [ ] **Step 3: Write the implementation**

Create `src/Agents/PollerGate.ps1`:

```powershell
<#
.SYNOPSIS
    The one place that decides whether a ticket may be granted with no human involved.

.DESCRIPTION
    Kept free of ME and Azure I/O so the policy boundary can be tested exhaustively.
    Four conditions, all required; any failure queues the ticket for a human.
#>

# Actions the poller may execute unattended. Deliberately excludes:
#   Eligible   - its approval gate is currently the operator clicking Provide Access in
#                the dashboard. Auto-executing it would delete the only approval for
#                prod Contributor / Owner / UAA.
#   BreakGlass - P1 emergency access.
#   Hold/Reject- no write by definition.
$script:PollerAutoActions = @('Grant')

# Environments the poller may write to. Production is excluded even for Reader, which the
# eligibility matrix marks as Grant with no approver: read-only, but still unattended
# Production access.
$script:PollerAutoEnvironments = @('Sandbox', 'NonProd')

function Test-PollerAutoEligible {
    <#
    .OUTPUTS
      pscustomobject with Eligible (bool) and Reason (string).
    #>
    param(
        [Parameter(Mandatory)][object]$Decision,
        [Parameter(Mandatory)][object]$Mapping,
        [bool]$TemplateAllowed = $false
    )

    $deny = {
        param([string]$Reason)
        [pscustomobject]@{ Eligible = $false; Reason = $Reason }
    }

    if (-not $TemplateAllowed) {
        return & $deny 'ManageEngine template is not an azure-subscription-grant template.'
    }

    if (-not $Mapping.Complete) {
        $detail = if (@($Mapping.Warnings).Count -gt 0) { (@($Mapping.Warnings) -join ' ') } else { 'mapping incomplete' }
        return & $deny "Structured ME fields are incomplete: $detail"
    }

    $action = [string]$Decision.Action
    if ($script:PollerAutoActions -notcontains $action) {
        return & $deny "Decision action '$action' is not auto-executable; only $($script:PollerAutoActions -join '/') is."
    }

    # Read the EFFECTIVE environment, never the ticket's claim: Resolve-RbacDecision raises
    # environment from subscription sensitivity, so a ticket claiming Sandbox against a
    # sensitive subscription becomes Production and must fall out here.
    $effective = [string]$Decision.EffectiveEnvironment
    if ([string]::IsNullOrWhiteSpace($effective)) {
        return & $deny 'Decision carried no effective environment; refusing to assume it is safe.'
    }
    if ($script:PollerAutoEnvironments -notcontains $effective) {
        return & $deny "Effective environment '$effective' is excluded from unattended writes (allowed: $($script:PollerAutoEnvironments -join '/'))."
    }

    return [pscustomobject]@{
        Eligible = $true
        Reason   = "Action $action on $effective from complete structured ME fields."
    }
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit/PollerGate.Tests.ps1 -Output Detailed"`
Expected: PASS, 9 tests.

- [ ] **Step 5: Verify the gate's environment field name matches the real decision record**

`Test-PollerAutoEligible` reads `.EffectiveEnvironment`. Confirm that is the actual property name:

Run:
```bash
powershell -NoProfile -Command "Import-Module ./src/RbacDecision/RbacDecision.psd1 -Force; (Resolve-RbacDecision -Ticket ([pscustomobject]@{ TicketId='T1'; Role='Reader'; Environment='Sandbox'; SubscriptionId='efae0e0e-09ab-4c17-82db-d2d1f4382d66'; ResourceScope='/subscriptions/efae0e0e-09ab-4c17-82db-d2d1f4382d66'; RequesterUpn='a@b.com'; SubmitterUpn='a@b.com'; Priority='P3'; DurationDays=7 }) -SubscriptionAllowlist @('efae0e0e-09ab-4c17-82db-d2d1f4382d66')) | Format-List *"
```
Expected: a record with `Action = Grant`. Read the printed property list and confirm the effective-environment property is named `EffectiveEnvironment`. **If it differs, update `PollerGate.ps1` and its test to the real name before continuing** — a silently-missing property would make the gate read `''` and deny everything, which fails safe but breaks the feature.

- [ ] **Step 6: Commit**

```bash
git add src/Agents/PollerGate.ps1 tests/unit/PollerGate.Tests.ps1
git commit -m "Add the unattended auto-eligibility gate

Four conditions, all required: grant template, complete structured mapping,
action is Grant, and effective environment is Sandbox or NonProd. Excludes
Eligible because its approval gate is currently the operator's click in the
dashboard, and excludes Production even for Reader, which the matrix marks
Grant with no approver. Gates on the effective environment so a ticket claiming
Sandbox against a sensitive subscription falls out after sensitivity raises it."
```

---

### Task 4: Poller cycle in shadow mode

The cycle: select candidate tickets, map, decide, gate, and record what it *would* do. No writes at all in this task — enforce arrives in Task 5. This keeps the risky part isolated behind its own review.

**Files:**
- Create: `src/Agents/TicketPollerAgent.ps1`
- Test: `tests/unit/TicketPollerAgent.Tests.ps1`

**Interfaces:**
- Consumes: `Resolve-MeTicketMapping` (Task 2), `Test-PollerAutoEligible` (Task 3).
- Produces:
  - `Get-PollerConfig` → `pscustomobject` with `Enabled` (bool), `Mode` (`'shadow'`/`'enforce'`), `MaxTicketsPerCycle` (int), `MaxGrantsPerCycle` (int), `MaxTicketAgeDays` (int), `StopFilePath` (string)
  - `Test-PollerTicketInWindow -MeTicket <object> -MaxAgeDays <int> -Now <datetime>` → `bool`
  - `Invoke-TicketPollerCycle -Context <hashtable>` → `pscustomobject` with **camelCase** properties `runId`, `mode`, `examined`, `wouldGrant`, `granted`, `queued`, `failed`, `stopped`, `halted`, `haltReason`, `entries` (array), `ranAt`. camelCase because the object is serialized directly to `poller-status.json` for the dashboard; PowerShell member access is case-insensitive so `$r.WouldGrant` still works.

`Context` is a hashtable of injected dependencies so the cycle is testable with no I/O:
`FetchTickets` (scriptblock → ME ticket array), `GetAccessFields` (scriptblock, takes a ticket → access fields), `IsTemplateAllowed` (scriptblock, takes a ticket → bool), `Decide` (scriptblock, takes the canonical ticket → decision record), `AllowlistDetails` (object[]), `ExecuteGrant` (scriptblock, takes the canonical ticket → `@{ ok = $true; assignmentId = '...' }`), `IsProcessed` (scriptblock, takes a ticket id → bool), `RecordProcessed` (scriptblock, takes ticket id + entry), `Config` (from `Get-PollerConfig`), `Now` (datetime).

- [ ] **Step 1: Write the failing test**

Create `tests/unit/TicketPollerAgent.Tests.ps1`:

```powershell
BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\MeTicketMapper.ps1')
    . (Join-Path $repoRoot 'src\Agents\PollerGate.ps1')
    . (Join-Path $repoRoot 'src\Agents\TicketPollerAgent.ps1')

    $script:Allowlist = @(
        [pscustomobject]@{ id = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'; name = 'inception-ai-Sandbox' }
    )

    function New-PollTicket {
        param(
            [string]$Id = '9001',
            [string]$Role = 'Reader',
            [string]$Env = 'Sandbox',
            [string]$Sub = 'inception-ai-Sandbox',
            [string]$Created = '',
            [string]$Email = 'dev.user@contoso.com'
        )
        $createdMs = if ($Created) {
            [string][int64](([datetime]$Created).ToUniversalTime() - [datetime]'1970-01-01').TotalMilliseconds
        } else {
            [string][int64](([datetime]::UtcNow.AddDays(-1)) - [datetime]'1970-01-01').TotalMilliseconds
        }
        [pscustomobject]@{
            id = $Id; subject = "Access request $Id"
            requester = [pscustomobject]@{ email_id = $Email }
            priority = [pscustomobject]@{ name = 'P3' }
            created_time = [pscustomobject]@{ value = $createdMs }
            description = 'please grant'
            _role = $Role; _env = $Env; _sub = $Sub
        }
    }

    function New-PollContext {
        param(
            [object[]]$Tickets = @(),
            [string]$Mode = 'shadow',
            [bool]$Enabled = $true,
            [int]$MaxGrants = 5,
            [int]$MaxTickets = 25,
            [string]$DecisionAction = 'Grant',
            [string]$EffectiveEnv = 'Sandbox',
            [scriptblock]$ExecuteGrant = $null,
            [string]$StopFilePath = ''
        )
        $script:Granted = [System.Collections.Generic.List[string]]::new()
        $script:Recorded = [System.Collections.Generic.List[string]]::new()
        @{
            FetchTickets      = { param() $Tickets }
            GetAccessFields   = { param($t) [ordered]@{ Subscription = $t._sub; AzureRole = $t._role; Environment = $t._env } }
            IsTemplateAllowed = { param($t) $true }
            Decide            = { param($ticket) [pscustomobject]@{ Action = $DecisionAction; EffectiveEnvironment = $EffectiveEnv; Path = 'test'; Reason = 'test' } }
            AllowlistDetails  = $script:Allowlist
            ExecuteGrant      = if ($ExecuteGrant) { $ExecuteGrant } else {
                { param($ticket) $script:Granted.Add([string]$ticket.TicketId); @{ ok = $true; assignmentId = "a-$($ticket.TicketId)" } }
            }
            IsProcessed       = { param($id) $false }
            RecordProcessed   = { param($id, $entry) $script:Recorded.Add([string]$id) }
            Config            = [pscustomobject]@{
                Enabled = $Enabled; Mode = $Mode
                MaxTicketsPerCycle = $MaxTickets; MaxGrantsPerCycle = $MaxGrants
                MaxTicketAgeDays = 7; StopFilePath = $StopFilePath
            }
            Now               = [datetime]::UtcNow
        }
    }
}

Describe 'Get-PollerConfig' {
    It 'is disabled and in shadow mode unless explicitly told otherwise' {
        $old = @{ e = $env:AZURESENTRY_POLLER_ENABLED; m = $env:AZURESENTRY_POLLER_MODE }
        try {
            Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue
            Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue
            $c = Get-PollerConfig
            $c.Enabled | Should -BeFalse
            $c.Mode | Should -Be 'shadow'
        }
        finally {
            if ($old.e) { $env:AZURESENTRY_POLLER_ENABLED = $old.e }
            if ($old.m) { $env:AZURESENTRY_POLLER_MODE = $old.m }
        }
    }

    It 'only treats the exact string true as enabled' {
        $env:AZURESENTRY_POLLER_ENABLED = 'yes'
        try { (Get-PollerConfig).Enabled | Should -BeFalse }
        finally { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
    }

    It 'only treats the exact string enforce as enforce' {
        $env:AZURESENTRY_POLLER_MODE = 'ENFORCE'
        try { (Get-PollerConfig).Mode | Should -Be 'enforce' }
        finally { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
    }

    It 'falls back to shadow for an unrecognised mode' {
        $env:AZURESENTRY_POLLER_MODE = 'whatever'
        try { (Get-PollerConfig).Mode | Should -Be 'shadow' }
        finally { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
    }
}

Describe 'Test-PollerTicketInWindow' {
    It 'accepts a recent ticket' {
        $t = New-PollTicket -Created ([datetime]::UtcNow.AddDays(-2).ToString('o'))
        Test-PollerTicketInWindow -MeTicket $t -MaxAgeDays 7 -Now ([datetime]::UtcNow) | Should -BeTrue
    }

    It 'rejects a ticket older than the window so a first run cannot stampede the backlog' {
        $t = New-PollTicket -Created ([datetime]::UtcNow.AddDays(-40).ToString('o'))
        Test-PollerTicketInWindow -MeTicket $t -MaxAgeDays 7 -Now ([datetime]::UtcNow) | Should -BeFalse
    }

    It 'rejects a ticket with no parseable created_time rather than treating it as new' {
        $t = New-PollTicket
        $t.created_time = $null
        Test-PollerTicketInWindow -MeTicket $t -MaxAgeDays 7 -Now ([datetime]::UtcNow) | Should -BeFalse
    }
}

Describe 'Invoke-TicketPollerCycle — shadow mode' {

    It 'does nothing at all when the kill switch is off' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Enabled $false
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Halted | Should -BeTrue
        $r.Examined | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'halts when the stop sentinel file exists' {
        $stop = Join-Path $TestDrive 'poller.stop'
        Set-Content -Path $stop -Value 'halt' -Encoding UTF8
        $ctx = New-PollContext -Tickets @(New-PollTicket) -StopFilePath $stop
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Halted | Should -BeTrue
        $script:Granted.Count | Should -Be 0
    }

    It 'reports wouldGrant and writes nothing in shadow mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '1'), (New-PollTicket -Id '2')
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Mode | Should -Be 'shadow'
        $r.WouldGrant | Should -Be 2
        $r.Granted | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'never uses the word skipped in an entry outcome' {
        # The environment backfill reported a successful dry run as "N skipped", which read
        # as failure and cost real debugging time. Shadow says WouldGrant.
        $ctx = New-PollContext -Tickets @(New-PollTicket)
        $r = Invoke-TicketPollerCycle -Context $ctx
        ($r.Entries | ForEach-Object { $_.outcome }) -join ' ' | Should -Not -Match 'skip'
        $r.Entries[0].outcome | Should -Be 'WouldGrant'
    }

    It 'does not record a processed entry in shadow mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket)
        Invoke-TicketPollerCycle -Context $ctx | Out-Null
        $script:Recorded.Count | Should -Be 0
    }

    It 'queues a Production decision instead of granting' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -EffectiveEnv 'Production'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 0
        $r.Queued | Should -Be 1
        $r.Entries[0].outcome | Should -Be 'Queued'
        $r.Entries[0].reason | Should -Match 'Production'
    }

    It 'queues an Eligible decision instead of granting' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -DecisionAction 'Eligible'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 0
        $r.Queued | Should -Be 1
    }

    It 'queues a ticket whose environment dropdown is blank' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Env '')
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Queued | Should -Be 1
        $r.Entries[0].reason | Should -Match 'Environment'
    }

    It 'queues a ticket whose subscription is not allowlisted' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Sub 'not-allowlisted-sub')
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Queued | Should -Be 1
        $r.Entries[0].reason | Should -Match 'allowlist'
    }

    It 'skips a ticket already in the processed store' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '55')
        $ctx.IsProcessed = { param($id) $true }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 0
        $r.WouldGrant | Should -Be 0
    }

    It 'honours MaxTicketsPerCycle' {
        $many = 1..10 | ForEach-Object { New-PollTicket -Id "$_" }
        $ctx = New-PollContext -Tickets $many -MaxTickets 4
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 4
    }

    It 'stamps a run id on the cycle' {
        $r = Invoke-TicketPollerCycle -Context (New-PollContext -Tickets @(New-PollTicket))
        $r.RunId | Should -Not -BeNullOrEmpty
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit/TicketPollerAgent.Tests.ps1 -Output Detailed"`
Expected: FAIL — `The term 'Get-PollerConfig' is not recognized`.

- [ ] **Step 3: Write the implementation**

Create `src/Agents/TicketPollerAgent.ps1`:

```powershell
<#
.SYNOPSIS
    One unattended poll cycle: select ME tickets, decide, and (in enforce mode) grant.

.DESCRIPTION
    Every external dependency is injected through the -Context hashtable so the whole
    cycle is testable with no ManageEngine or Azure I/O. scripts/Invoke-TicketPollerCycle.ps1
    builds the real context.

    Default posture is off and shadow. Shadow records exactly what it would have granted
    and writes nothing -- deliberately reporting WouldGrant rather than "skipped", which in
    the environment backfill made a successful dry run read identically to a failure.
#>

function Get-PollerConfig {
    <#
    .SYNOPSIS
      Read the poller's operating envelope from the environment.
    .DESCRIPTION
      Both the kill switch and the mode require an exact string match. A typo in
      AZURESENTRY_POLLER_ENABLED must leave the poller off, and a typo in
      AZURESENTRY_POLLER_MODE must leave it in shadow -- never the other way round.
    #>
    param([string]$StopFilePath = '')

    $enabled = ([string]$env:AZURESENTRY_POLLER_ENABLED).Trim().ToLowerInvariant() -eq 'true'
    $mode = if (([string]$env:AZURESENTRY_POLLER_MODE).Trim().ToLowerInvariant() -eq 'enforce') { 'enforce' } else { 'shadow' }

    $asInt = {
        param([string]$Value, [int]$Default)
        $n = 0
        if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
        return $Default
    }

    return [pscustomobject]@{
        Enabled            = $enabled
        Mode               = $mode
        MaxTicketsPerCycle = (& $asInt $env:AZURESENTRY_POLLER_MAX_TICKETS 25)
        MaxGrantsPerCycle  = (& $asInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5)
        MaxTicketAgeDays   = (& $asInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7)
        StopFilePath       = $StopFilePath
    }
}

function Get-MeTicketCreatedUtc {
    <#
    .SYNOPSIS
      ME created_time to UTC datetime, or $null when unparseable.
    .DESCRIPTION
      SDP returns epoch milliseconds, usually wrapped as @{ value = '...' }.
    #>
    param([object]$MeTicket)

    $raw = $null
    if ($MeTicket.created_time) {
        $raw = if ($MeTicket.created_time.PSObject.Properties.Name -contains 'value') {
            [string]$MeTicket.created_time.value
        } else {
            [string]$MeTicket.created_time
        }
    }
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }

    $ms = 0L
    if ([int64]::TryParse($raw, [ref]$ms) -and $ms -gt 0) {
        return ([datetime]'1970-01-01').AddMilliseconds($ms)
    }
    $parsed = [datetime]::MinValue
    if ([datetime]::TryParse($raw, [ref]$parsed)) { return $parsed.ToUniversalTime() }
    return $null
}

function Test-PollerTicketInWindow {
    <#
    .SYNOPSIS
      True when the ticket is recent enough to consider.
    .DESCRIPTION
      Bounds the cold start: without this, a first run would attempt the entire open
      historical backlog. A ticket with no parseable created_time is refused rather than
      assumed new.
    #>
    param(
        [Parameter(Mandatory)][object]$MeTicket,
        [int]$MaxAgeDays = 7,
        [datetime]$Now = [datetime]::UtcNow
    )

    $created = Get-MeTicketCreatedUtc -MeTicket $MeTicket
    if ($null -eq $created) { return $false }
    return ($created -ge $Now.AddDays(-1 * [Math]::Abs($MaxAgeDays)))
}

function Invoke-TicketPollerCycle {
    <#
    .SYNOPSIS
      Run exactly one poll cycle.
    .OUTPUTS
      pscustomobject with RunId, Mode, Examined, WouldGrant, Granted, Queued, Failed,
      Stopped, Halted, Entries.
    #>
    param([Parameter(Mandatory)][hashtable]$Context)

    $config = $Context.Config
    $runId = if (Get-Command -Name New-AgentRunId -ErrorAction SilentlyContinue) {
        New-AgentRunId
    } else {
        "poll-$([guid]::NewGuid().ToString('N').Substring(0, 12))"
    }

    $entries = [System.Collections.Generic.List[object]]::new()
    $tally = @{ Examined = 0; WouldGrant = 0; Granted = 0; Queued = 0; Failed = 0; Stopped = $false }

    # Property names are camelCase because this object is serialized straight to
    # poller-status.json and read by the dashboard, and the rest of the API's JSON is
    # camelCase. PowerShell member access is case-insensitive, so callers and tests can
    # still write $result.WouldGrant.
    $result = {
        param([bool]$Halted, [string]$HaltReason)
        [pscustomobject]@{
            runId      = $runId
            mode       = [string]$config.Mode
            examined   = $tally.Examined
            wouldGrant = $tally.WouldGrant
            granted    = $tally.Granted
            queued     = $tally.Queued
            failed     = $tally.Failed
            stopped    = $tally.Stopped
            halted     = $Halted
            haltReason = $HaltReason
            entries    = @($entries)
            ranAt      = $Context.Now.ToString('o')
        }
    }

    if (-not $config.Enabled) {
        return & $result $true 'AZURESENTRY_POLLER_ENABLED is not true.'
    }
    if ($config.StopFilePath -and (Test-Path $config.StopFilePath)) {
        return & $result $true "Stop sentinel present at $($config.StopFilePath)."
    }

    $candidates = @(& $Context.FetchTickets)

    foreach ($me in $candidates) {
        if ($tally.Examined -ge [int]$config.MaxTicketsPerCycle) { break }
        if ($tally.Stopped) { break }

        $id = [string]$me.id
        if (& $Context.IsProcessed $id) { continue }
        if (-not (Test-PollerTicketInWindow -MeTicket $me -MaxAgeDays $config.MaxTicketAgeDays -Now $Context.Now)) { continue }

        $tally.Examined++

        $templateAllowed = [bool](& $Context.IsTemplateAllowed $me)
        $accessFields = & $Context.GetAccessFields $me
        $mapping = Resolve-MeTicketMapping -AccessFields $accessFields -MeTicket $me -AllowlistDetails $Context.AllowlistDetails

        # Only ask the decision engine about tickets that mapped cleanly. An incomplete
        # mapping has no trustworthy role/subscription to decide on.
        $decision = $null
        if ($mapping.Complete -and $templateAllowed) {
            $decision = & $Context.Decide $mapping.Ticket
        }

        if ($null -eq $decision) {
            $reason = if (-not $templateAllowed) {
                'ManageEngine template is not an azure-subscription-grant template.'
            } else {
                "Structured ME fields are incomplete: $((@($mapping.Warnings)) -join ' ')"
            }
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'; reason = $reason
                    action = $null; effectiveEnvironment = $null; applied = $false
                })
            continue
        }

        $gate = Test-PollerAutoEligible -Decision $decision -Mapping $mapping -TemplateAllowed $templateAllowed
        if (-not $gate.Eligible) {
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'; reason = $gate.Reason
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                })
            continue
        }

        if ($tally.Granted -ge [int]$config.MaxGrantsPerCycle) {
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'
                    reason = "Per-cycle grant cap of $($config.MaxGrantsPerCycle) reached; deferred to the next cycle."
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                })
            continue
        }

        if ($config.Mode -ne 'enforce') {
            $tally.WouldGrant++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'WouldGrant'; reason = $gate.Reason
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    role = [string]$mapping.Ticket.Role
                    subscriptionId = [string]$mapping.Ticket.SubscriptionId
                    requesterUpn = [string]$mapping.Ticket.RequesterUpn
                    applied = $false
                })
            continue
        }

        # --- enforce: the only branch that writes ---
        $errorText = $null
        $exec = $null
        try { $exec = & $Context.ExecuteGrant $mapping.Ticket }
        catch { $errorText = $_.Exception.Message }

        $ok = ($null -ne $exec) -and [bool]$exec.ok
        if (-not $ok -and -not $errorText) {
            $errorText = if ($exec -and $exec.error) { [string]$exec.error } else { 'Grant reported failure without a reason.' }
        }

        if ($ok) {
            $tally.Granted++
            & $Context.RecordProcessed $id ([pscustomobject]@{
                    ticketId = $id; action = [string]$decision.Action
                    role = [string]$mapping.Ticket.Role
                    subscriptionId = [string]$mapping.Ticket.SubscriptionId
                    requesterUpn = [string]$mapping.Ticket.RequesterUpn
                    assignmentId = [string]$exec.assignmentId
                    runId = $runId; actor = 'poller'
                    processedAt = $Context.Now.ToString('o')
                })
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Granted'; reason = $gate.Reason
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    role = [string]$mapping.Ticket.Role
                    subscriptionId = [string]$mapping.Ticket.SubscriptionId
                    requesterUpn = [string]$mapping.Ticket.RequesterUpn
                    assignmentId = [string]$exec.assignmentId
                    applied = $true
                })
        }
        else {
            # Fail closed: stop the cycle rather than walking into the next ticket with an
            # unexplained failure behind us.
            $tally.Failed++
            $tally.Stopped = $true
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Failed'; reason = $errorText
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                })
        }
    }

    return & $result $false ''
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit/TicketPollerAgent.Tests.ps1 -Output Detailed"`
Expected: PASS, 20 tests.

- [ ] **Step 5: Commit**

```bash
git add src/Agents/TicketPollerAgent.ps1 tests/unit/TicketPollerAgent.Tests.ps1
git commit -m "Add the unattended poll cycle, shadow mode only

Dependencies are injected through a context hashtable so the whole cycle is
testable with no ManageEngine or Azure I/O. Defaults to off and shadow: both
the kill switch and the mode require an exact string match, so a typo leaves
the poller off rather than writing. Shadow reports WouldGrant, never
'skipped' -- that wording made the backfill's successful dry run read as a
failure. Cold start is bounded by a ticket-age window so a first run cannot
stampede the open backlog."
```

---

### Task 5: Enforce mode wiring and fail-closed behaviour

Task 4 implemented the enforce branch but nothing exercises it end to end. This task tests the write path's guarantees — dedup re-check inside the lock, caps, fail-closed — against the real store from Task 1.

**Files:**
- Modify: `tests/unit/TicketPollerAgent.Tests.ps1` (append an enforce `Describe`)

**Interfaces:**
- Consumes: `Invoke-TicketPollerCycle` (Task 4), and from Task 1 as-built: `Initialize-ProcessedStore`, `Save-ProcessedTicket`, `Get-ProcessedTickets`, `Request-ProcessedTicketClaim`. NOTE: `Invoke-WithProcessedStoreLock` no longer exists -- the store was redesigned to one file per ticket with no lock. Use `Request-ProcessedTicketClaim` for the atomic claim.
- Produces: nothing new.

- [ ] **Step 1: Write the failing test**

Append to `tests/unit/TicketPollerAgent.Tests.ps1`:

```powershell
Describe 'Invoke-TicketPollerCycle — enforce mode' {

    BeforeAll {
        . (Join-Path $repoRoot 'dashboard\api\ProcessedStore.ps1')
    }

    BeforeEach {
        $script:EnforceStore = Join-Path $TestDrive "enforce-$([guid]::NewGuid().ToString('N')).json"
        Initialize-ProcessedStore -Path $script:EnforceStore
    }

    It 'executes the grant and records it' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '77') -Mode 'enforce'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
        $r.WouldGrant | Should -Be 0
        $script:Granted | Should -Contain '77'
        $r.Entries[0].outcome | Should -Be 'Granted'
        $r.Entries[0].applied | Should -BeTrue
    }

    It 'stops at the first failure instead of continuing to the next ticket' {
        $ctx = New-PollContext -Tickets @(
            (New-PollTicket -Id 'a'), (New-PollTicket -Id 'b'), (New-PollTicket -Id 'c')
        ) -Mode 'enforce' -ExecuteGrant { param($ticket) @{ ok = $false; error = 'ARM returned 403' } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Failed | Should -Be 1
        $r.Stopped | Should -BeTrue
        $r.Granted | Should -Be 0
        # b and c must not have been attempted.
        @($r.Entries).Count | Should -Be 1
    }

    It 'treats a thrown exception from the grant as a failure and stops' {
        $ctx = New-PollContext -Tickets @((New-PollTicket -Id 'x'), (New-PollTicket -Id 'y')) `
            -Mode 'enforce' -ExecuteGrant { param($ticket) throw 'token expired' }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Failed | Should -Be 1
        $r.Stopped | Should -BeTrue
        $r.Entries[0].reason | Should -Match 'token expired'
    }

    It 'stops granting once the per-cycle cap is hit and defers the rest' {
        $many = 1..6 | ForEach-Object { New-PollTicket -Id "cap$_" }
        $ctx = New-PollContext -Tickets $many -Mode 'enforce' -MaxGrants 2
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 2
        $r.Queued | Should -Be 4
        ($r.Entries | Where-Object { $_.outcome -eq 'Queued' })[0].reason | Should -Match 'cap'
    }

    It 'persists the grant to the real store so a later cycle will not repeat it' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '4242') -Mode 'enforce'
        $ctx.RecordProcessed = { param($id, $entry) Save-ProcessedTicket -MeTicketId $id -Entry $entry }
        Invoke-TicketPollerCycle -Context $ctx | Out-Null

        (Get-ProcessedTickets).ContainsKey('4242') | Should -BeTrue

        # Second cycle with a real dedup check must not grant again.
        $script:Granted.Clear()
        $ctx2 = New-PollContext -Tickets @(New-PollTicket -Id '4242') -Mode 'enforce'
        $ctx2.IsProcessed = { param($id) (Get-ProcessedTickets).ContainsKey($id) }
        $r2 = Invoke-TicketPollerCycle -Context $ctx2
        $r2.Granted | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'still refuses Production in enforce mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce' -EffectiveEnv 'Production'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 0
        $r.Queued | Should -Be 1
        $script:Granted.Count | Should -Be 0
    }

    It 'still refuses Eligible in enforce mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce' -DecisionAction 'Eligible'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'writes nothing when the kill switch is off even in enforce mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce' -Enabled $false
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Halted | Should -BeTrue
        $script:Granted.Count | Should -Be 0
    }
}
```

- [ ] **Step 2: Run the test**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit/TicketPollerAgent.Tests.ps1 -Output Detailed"`
Expected: PASS, 28 tests. The enforce branch was written in Task 4, so these should pass without new implementation. **If any fail, fix `TicketPollerAgent.ps1` — do not weaken the test.**

- [ ] **Step 3: Commit**

```bash
git add tests/unit/TicketPollerAgent.Tests.ps1
git commit -m "Test the enforce write path's guarantees

Covers fail-closed on both a returned failure and a thrown exception, the
per-cycle grant cap deferring rather than dropping, persistence to the real
claim-file store so a later cycle will not re-grant, and that Production,
Eligible and the kill switch are still refused when writes are enabled."
```

---

### Task 6: Real entry point, scheduler registration, and runbook

Wire the cycle to real ManageEngine, the real allowlist, the real decision engine, and the real grant path. This is the first task that touches live systems, and it ships defaulting to off and shadow.

**Files:**
- Create: `scripts/Invoke-TicketPollerCycle.ps1`
- Create: `infra/systemd/azuresentry-poller.service`, `infra/systemd/azuresentry-poller.timer`, `infra/systemd/install-poller-timer.sh`
- Create: `docs/ticket-poller-runbook.md`
- Modify: `.env.example`

**Interfaces:**
- Consumes: `Get-PollerConfig`, `Invoke-TicketPollerCycle` (Task 4), `Resolve-MeTicketMapping` (Task 2), `Test-PollerAutoEligible` (Task 3), `Initialize-ProcessedStore`/`Get-ProcessedTickets`/`Save-ProcessedTicket` (Task 1).
- Produces: `dashboard/api/poller-status.json` — the cycle result object, overwritten each run, read by Task 7.

- [ ] **Step 1: Write the entry script**

Create `scripts/Invoke-TicketPollerCycle.ps1`:

```powershell
<#
.SYNOPSIS
    Scheduler entry point (systemd timer): run exactly one unattended poll cycle and exit.

.DESCRIPTION
    Builds the real dependency context for Invoke-TicketPollerCycle and writes the result
    to poller-status.json for the dashboard to read.

    Deliberately one cycle per invocation rather than a long-lived loop: the scheduler owns
    the cadence, a hung cycle cannot wedge the poller forever, and each run gets a clean
    PowerShell session with fresh tokens.

    Ships inert. AZURESENTRY_POLLER_ENABLED must be exactly 'true' to do anything, and
    AZURESENTRY_POLLER_MODE must be exactly 'enforce' to write.
#>
[CmdletBinding()]
param(
    [switch]$VerboseOutput
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent
$apiRoot = Join-Path $repoRoot 'dashboard\api'

# --- load .env the same way the dashboard API does ---
$envFile = Join-Path $apiRoot '.env'
if (Test-Path $envFile) {
    foreach ($line in Get-Content $envFile) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith('#')) { continue }
        $idx = $trimmed.IndexOf('=')
        if ($idx -lt 1) { continue }
        $key = $trimmed.Substring(0, $idx).Trim()
        $val = $trimmed.Substring($idx + 1).Trim().Trim('"')
        Set-Item -Path "Env:\$key" -Value $val
    }
}

. (Join-Path $repoRoot 'src\Agents\MeTicketMapper.ps1')
. (Join-Path $repoRoot 'src\Agents\PollerGate.ps1')
. (Join-Path $repoRoot 'src\Agents\TicketPollerAgent.ps1')
. (Join-Path $repoRoot 'src\Agents\AgentRuntime.ps1')
. (Join-Path $apiRoot 'ProcessedStore.ps1')
. (Join-Path $apiRoot 'MeAccessFields.ps1')

Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force -Prefix Real
. (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')

Initialize-ProcessedStore -Path (Join-Path $apiRoot 'processed-tickets.json')

$stopFile = Join-Path $apiRoot 'poller.stop'
$statusFile = Join-Path $apiRoot 'poller-status.json'
$config = Get-PollerConfig -StopFilePath $stopFile

# Fail fast and visibly if enforce was requested without the credentials to honour it,
# rather than silently granting nothing and looking like a policy decision.
if ($config.Enabled -and $config.Mode -eq 'enforce') {
    if (-not ($env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET)) {
        throw 'Poller is in enforce mode but AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET are not all set.'
    }
}

$meBase = ([string]$env:MANAGE_ENGINE_BASE_URL).TrimEnd('/')
$meKey = [string]$env:MANAGE_ENGINE_API_KEY

$fetchTickets = {
    if (-not $meBase -or -not $meKey) { return @() }
    $fields = '"id","subject","description","status","priority","requester","created_time","udf_fields","template"'
    $listInfo = '{"list_info":{"row_count":100,"start_index":1,"sort_field":"created_time","sort_order":"desc","fields_required":[' + $fields + ']}}'
    $uri = "$meBase/api/v3/requests?input_data=$([uri]::EscapeDataString($listInfo))"
    $resp = Invoke-RestMethod -Uri $uri -Method Get -Headers @{ authtoken = $meKey; Accept = 'application/vnd.manageengine.sdp.v3+json' }
    # Only open work: a Resolved or Closed ticket must never be re-granted.
    return @($resp.requests | Where-Object { [string]$_.status.name -notin @('Resolved', 'Closed', 'Cancelled') })
}

$getAccessFields = {
    param($MeTicket)
    # Shared with the dashboard API via MeAccessFields.ps1 -- these three fields decide
    # which subscription and role is being asked for, so a second copy could drift and
    # change what gets granted unattended. Key overrides come from config.json, the same
    # source the API reads.
    Get-MeTemplateAccessFields -UdfFields $MeTicket.udf_fields -UdfKeyOverrides $udfKeyOverrides
}

$isTemplateAllowed = {
    param($MeTicket)
    # Only the Azure Subscription grant template is in scope for unattended processing.
    $name = if ($MeTicket.template) { [string]$MeTicket.template.name } else { '' }
    return ($name -like '*Azure Subscription*')
}

# Effective allowlist. Static from config here; the API derives it from the management
# group. A subscription absent from this list can never be granted (exact match only).
$allowlistDetails = @()
$udfKeyOverrides = $null
$configFile = Join-Path $apiRoot 'config.json'
if (Test-Path $configFile) {
    $cfg = Get-Content -Raw -Path $configFile | ConvertFrom-Json
    if ($cfg.manageEngine -and $cfg.manageEngine.PSObject.Properties.Name -contains 'udfFields') {
        $udfKeyOverrides = $cfg.manageEngine.udfFields
    }
    foreach ($id in @($cfg.subscriptionAllowlist)) {
        $label = if ($cfg.subscriptionLabels -and $cfg.subscriptionLabels.$id) {
            (([string]$cfg.subscriptionLabels.$id) -split '\s*\(')[0].Trim()
        } else { [string]$id }
        $allowlistDetails += [pscustomobject]@{ id = [string]$id; name = $label }
    }
}

$decide = {
    param($Ticket)
    Resolve-RbacDecision -Ticket $Ticket -SubscriptionAllowlist @($allowlistDetails | ForEach-Object { $_.id })
}

$executeGrant = {
    param($Ticket)
    $client = New-RealGraphPimClient -TenantId $env:AZURE_TENANT_ID `
        -ClientId $env:AZURE_CLIENT_ID -ClientSecret $env:AZURE_CLIENT_SECRET
    $userId = Resolve-RealUpnToObjectId -Client $client -Upn ([string]$Ticket.RequesterUpn)

    # Re-check duplicates against Azure, not local state. Local dedup is an optimization;
    # Azure is truth, and another operator may have granted this between cycles.
    $roleId = Get-RealRoleDefinitionId -RoleName ([string]$Ticket.Role)
    $existing = Get-RealActiveAssignments -Client $client -UserId $userId `
        -RoleDefinitionId $roleId -Scope ([string]$Ticket.ResourceScope)
    if (@($existing).Count -gt 0) {
        return @{ ok = $false; error = 'Active assignment already exists in Azure for this user, role and scope.' }
    }

    $grant = Invoke-GroupOrPimGrant -Client $client -UserId $userId -RoleName ([string]$Ticket.Role) `
        -SubscriptionId ([string]$Ticket.SubscriptionId) -SubscriptionName ([string]$Ticket.SubscriptionName) `
        -ResourceScope ([string]$Ticket.ResourceScope) -DurationDays ([int]$Ticket.DurationDays) `
        -Justification ([string]$Ticket.Justification)

    if (-not $grant.Success) {
        return @{ ok = $false; error = "Grant failed: $($grant.EngineerActionReason)" }
    }
    return @{ ok = $true; assignmentId = [string]$grant.AssignmentId; fulfilment = [string]$grant.Fulfilment }
}

$context = @{
    FetchTickets      = $fetchTickets
    GetAccessFields   = $getAccessFields
    IsTemplateAllowed = $isTemplateAllowed
    Decide            = $decide
    AllowlistDetails  = $allowlistDetails
    ExecuteGrant      = $executeGrant
    IsProcessed       = { param($Id) (Get-ProcessedTickets).ContainsKey([string]$Id) }
    RecordProcessed   = { param($Id, $Entry) Save-ProcessedTicket -MeTicketId ([string]$Id) -Entry $Entry }
    Config            = $config
    Now               = [datetime]::UtcNow
}

$result = Invoke-TicketPollerCycle -Context $context

# Audit every cycle, including shadow, so the unattended path is never a black box.
if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
    foreach ($entry in $result.Entries) {
        Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'UnattendedGrant' -Actor 'poller' `
            -RunId $result.RunId -TicketId ([string]$entry.ticketId) `
            -Outcome ([string]$entry.outcome) -Detail $entry
    }
}

($result | ConvertTo-Json -Depth 8) | Set-Content -Path $statusFile -Encoding UTF8

$summary = "[poller] run=$($result.RunId) mode=$($result.Mode) examined=$($result.Examined) wouldGrant=$($result.WouldGrant) granted=$($result.Granted) queued=$($result.Queued) failed=$($result.Failed)"
if ($result.Halted) { $summary += " HALTED: $($result.HaltReason)" }
if ($result.Stopped) { $summary += ' STOPPED (fail-closed)' }
Write-Output $summary

if ($VerboseOutput) { $result.Entries | Format-Table ticketId, outcome, reason -AutoSize | Out-String | Write-Output }

# Non-zero exit on a failed cycle so systemctl status / journalctl show the failure.
if ($result.Failed -gt 0) { exit 1 }
exit 0
```

- [ ] **Step 2: Verify the entry script parses and is inert by default**

Run:
```bash
powershell -NoProfile -Command "[void][System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path 'scripts/Invoke-TicketPollerCycle.ps1').Path, [ref]$null, [ref]$null); 'parsed ok'"
powershell -NoProfile -Command "Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue; ./scripts/Invoke-TicketPollerCycle.ps1"
```
Expected: `parsed ok`, then a line containing `mode=shadow` and `HALTED: AZURESENTRY_POLLER_ENABLED is not true.` — it must reach zero tickets and touch nothing.

- [ ] **Step 3: Do a real shadow run against live ManageEngine**

Run:
```bash
powershell -NoProfile -Command "$env:AZURESENTRY_POLLER_ENABLED='true'; ./scripts/Invoke-TicketPollerCycle.ps1 -VerboseOutput"
```
Expected: `mode=shadow granted=0`, a non-zero `examined`, and a table of per-ticket outcomes (`WouldGrant` / `Queued` with reasons). `granted` **must** be 0. Confirm `dashboard/api/poller-status.json` was written.

If `examined=0`, check `MANAGE_ENGINE_BASE_URL` / `MANAGE_ENGINE_API_KEY` (`dashboard/api/.env` locally, `/etc/azuresentry.env` on the VM) and that open Azure Subscription tickets exist inside the 7-day window.

- [ ] **Step 4: Write the systemd timer units**

Production is Ubuntu 22.04 with systemd, so the cadence is a `.timer`/`.service` pair, matching how `azuresentry.service` already runs. **Do not use `*-ScheduledTask*` cmdlets — they do not exist on Linux.**

Create `infra/systemd/azuresentry-poller.service`:

```ini
[Unit]
Description=AzureSentry unattended ticket poller (one cycle)
Documentation=file:///opt/azuresentry/docs/ticket-poller-runbook.md
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
WorkingDirectory=/opt/azuresentry
# Same env file the dashboard service reads, so the SPN credentials and the poller's
# own AZURESENTRY_POLLER_* switches live in exactly one place.
EnvironmentFile=/etc/azuresentry.env
ExecStart=/usr/bin/pwsh -NoProfile -NonInteractive -File /opt/azuresentry/scripts/Invoke-TicketPollerCycle.ps1
# A cycle that cannot finish in 15 min is wedged; kill it rather than let the timer stack.
TimeoutStartSec=900
# PrivateTmp is deliberately NOT set. The poller and the dashboard API coordinate through
# a lockfile beside processed-tickets.json, so /tmp isolation would not break correctness --
# but leaving it unset keeps the two processes' view of the filesystem identical and avoids
# surprising anyone who later adds /tmp-based coordination.
StandardOutput=journal
StandardError=journal
SyslogIdentifier=azuresentry-poller

[Install]
WantedBy=multi-user.target
```

Create `infra/systemd/azuresentry-poller.timer`:

```ini
[Unit]
Description=Run the AzureSentry ticket poller every 5 minutes
Documentation=file:///opt/azuresentry/docs/ticket-poller-runbook.md

[Timer]
# Wait for the box to settle before the first cycle.
OnBootSec=2min
# OnUnitActiveSec measures from the END of the last run, so a slow cycle delays the next
# one instead of overlapping it. This is what replaces Windows' MultipleInstances policy.
OnUnitActiveSec=5min
AccuracySec=30s
Unit=azuresentry-poller.service

[Install]
WantedBy=timers.target
```

Create `infra/systemd/install-poller-timer.sh`:

```bash
#!/usr/bin/env bash
# Install/refresh the poller timer on vm-incp-uaen-001-sentry. Run as root.
#
# Installing the timer does NOT enable the poller: AZURESENTRY_POLLER_ENABLED in
# /etc/azuresentry.env still gates every action, and it defaults to off. So it is safe
# to install this before you intend to write anything.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v pwsh >/dev/null 2>&1; then
  echo "pwsh not found on PATH; the poller unit needs it at /usr/bin/pwsh" >&2
  exit 1
fi

install -m 0644 "$SRC/azuresentry-poller.service" /etc/systemd/system/
install -m 0644 "$SRC/azuresentry-poller.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now azuresentry-poller.timer

echo "--- timer status ---"
systemctl list-timers azuresentry-poller.timer --no-pager || true
echo
echo "Installed. The poller stays inert until AZURESENTRY_POLLER_ENABLED=true in /etc/azuresentry.env."
echo "Run one cycle by hand with:  systemctl start azuresentry-poller.service && journalctl -u azuresentry-poller -n 50 --no-pager"
```

Make it executable and verify both units parse:

```bash
chmod +x infra/systemd/install-poller-timer.sh
# systemd-analyze verify is available on the VM; locally just confirm the files exist.
ls -l infra/systemd/
```

- [ ] **Step 5: Document the env vars**

Append to `.env.example`:

```
# --- Unattended ticket poller (scripts/Invoke-TicketPollerCycle.ps1) ---
# Kill switch. Must be exactly 'true'; anything else leaves the poller inert.
AZURESENTRY_POLLER_ENABLED=false
# 'shadow' decides and records but writes nothing. 'enforce' performs real grants.
AZURESENTRY_POLLER_MODE=shadow
# Blast radius and cold-start bounds.
AZURESENTRY_POLLER_MAX_TICKETS=25
AZURESENTRY_POLLER_MAX_GRANTS=5
AZURESENTRY_POLLER_MAX_AGE_DAYS=7
```

- [ ] **Step 6: Write the operations runbook**

Create `docs/ticket-poller-runbook.md`:

```markdown
# Unattended Ticket Poller — Operations Runbook

Auto-processes ManageEngine access requests with no human click, for the narrow slice
policy already allows. Design: `docs/superpowers/specs/2026-08-19-unattended-ticket-poller-design.md`.

## What it will and will not do

**Auto-grants** `Grant` decisions on **Sandbox** and **Non-Prod** only — in practice
`sandbox-reader`, `sandbox-contributor`, `nonprod-reader`.

**Always queues for a human:**
- Any `Eligible` decision (prod Contributor / Owner / UAA). Its approval gate is the
  operator clicking *Provide Access* in the dashboard.
- **All Production, including Reader** — `prod-reader-*` is `Grant` in the matrix with no
  approver, and is still excluded here.
- `Hold`, `Reject`, `BreakGlass`.
- Any ticket whose ME Subscription / Azure Role / Environment dropdown is blank,
  unmappable, or not on the allowlist by exact name.
- Any ticket whose effective environment is raised to Production by subscription
  sensitivity, even if it claimed Sandbox.

Production is `vm-incp-uaen-001-sentry` (Ubuntu 22.04, systemd). App at
`/opt/azuresentry`, env at `/etc/azuresentry.env`. All commands below run on the VM as root
unless noted.

## Enable it

1. Install the timer (safe — installing does not enable the poller):
   ```bash
   sudo ./infra/systemd/install-poller-timer.sh
   ```
2. Shadow-run one cycle by hand and read the output:
   ```bash
   sudo AZURESENTRY_POLLER_ENABLED=true pwsh -NoProfile \
     -File /opt/azuresentry/scripts/Invoke-TicketPollerCycle.ps1 -VerboseOutput
   ```
3. Set `AZURESENTRY_POLLER_ENABLED=true` in `/etc/azuresentry.env`, leaving
   `AZURESENTRY_POLLER_MODE=shadow`. Then `sudo systemctl restart azuresentry-poller.timer`
   and watch the dashboard's Poller panel.
4. When the `WouldGrant` rows look right, flip `AZURESENTRY_POLLER_MODE=enforce` in
   `/etc/azuresentry.env`.

`granted` stays 0 in shadow, always. If shadow reports `granted > 0`, stop and
investigate — that is a bug, not a configuration state.

Follow the cycles with:
```bash
journalctl -u azuresentry-poller -f
systemctl list-timers azuresentry-poller.timer --no-pager
```

## Halt it

Fastest first:

1. **Stop sentinel** — takes effect on the next cycle, no config edit, no restart:
   ```bash
   echo "halted <who> <why> <when>" | sudo tee /opt/azuresentry/dashboard/api/poller.stop
   ```
2. **Kill switch** — `AZURESENTRY_POLLER_ENABLED=false` in `/etc/azuresentry.env`.
3. **Stop the timer** — `sudo systemctl disable --now azuresentry-poller.timer`.

Delete `poller.stop` to resume.

## Verify the store's claim is actually exclusive on the VM

Superseded by the runbook. This plan's original probe (an `O_EXCL` lockfile beside the
store, verified with `rm -f /tmp/lock-probe.json.lock`) describes a coordination scheme
that was abandoned before shipping -- the store now uses one small per-ticket file with
`Request-ProcessedTicketClaim` doing a single atomic `CreateNew` filesystem call as the
claim, no lockfile involved. See "How duplicate grants are prevented" and its claim probe
in `docs/ticket-poller-runbook.md` for the current verification procedure.

## Verify what it did

- Dashboard → Poller panel, or `GET /api/poller/status`.
- `dashboard/api/poller-status.json` — the last cycle verbatim.
- The audit trail — every cycle writes `TicketPollerAgent` / `UnattendedGrant` events,
  including shadow decisions, marked `applied: false`.
- `dashboard/api/processed-tickets.json` — tickets it has acted on.

## Common outcomes

| Symptom | Cause |
|---|---|
| `HALTED: AZURESENTRY_POLLER_ENABLED is not true` | Kill switch off. Expected default. |
| `HALTED: Stop sentinel present` | `poller.stop` exists. Delete to resume. |
| `examined=0` | No open Azure Subscription tickets in the age window, or ME creds missing. |
| Everything `Queued` with "Structured ME fields are incomplete" | Requesters left dropdowns blank. Run Environment Governance to backfill, or fix the ME template. |
| `Queued` with "not on the allowlist by exact name" | ME subscription label does not exactly match an allowlist name. Fix the label or `subscriptionLabels` in config. |
| `STOPPED (fail-closed)` | A grant failed; the cycle stopped deliberately. Read `reason`, fix, next cycle resumes. |
| Enforce throws about `AZURE_*` | Enforce requested without SPN credentials. |

## Why the age window exists

`AZURESENTRY_POLLER_MAX_AGE_DAYS` (default 7) stops a first run attempting the whole open
historical backlog. Raising it on a cold system will queue or grant a large batch at once —
raise it deliberately, with `AZURESENTRY_POLLER_MAX_GRANTS` low.
```

- [ ] **Step 7: Run the full suite and commit**

Run: `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit -Output Normal"`
Expected: PASS, 414 tests (380 existing + 6 + 15 + 9 + 20 − overlap already counted; confirm zero failures rather than the exact total).

```bash
git add scripts/Invoke-TicketPollerCycle.ps1 infra/systemd/ docs/ticket-poller-runbook.md .env.example
git commit -m "Wire the poller to live ManageEngine, Azure and the scheduler

One cycle per invocation rather than a long-lived loop: the scheduler owns
cadence, a hung cycle cannot wedge the poller, and each run gets fresh tokens.
Enforce mode re-checks duplicates against Azure before granting because
another operator may have granted between cycles. Ships inert -- registering
the scheduled task does not enable anything. Adds the operations runbook
covering enable, halt, verify, and the common queued outcomes."
```

---

### Task 7: Poller status endpoint and dashboard panel

Make the unattended path observable. Without this the poller is a black box, which is the specific complaint that motivated the whole feature.

**Files:**
- Modify: `dashboard/api/Start-DashboardApi.ps1` (add `GET /api/poller/status` beside the other GET routes)
- Modify: `dashboard/web/src/types.ts`
- Modify: `dashboard/web/src/api/client.ts`
- Create: `dashboard/web/src/views/PollerStatusPanel.tsx`
- Modify: `dashboard/web/src/App.tsx` (render the panel on the Dashboard view)

**Interfaces:**
- Consumes: `dashboard/api/poller-status.json` written by Task 6.
- Produces: `api.poller.status()` → `PollerStatus`.

- [ ] **Step 1: Add the API route**

In `dashboard/api/Start-DashboardApi.ps1`, immediately before the `/api/breakglass` GET route, insert:

```powershell
            if ($path -eq '/api/poller/status' -and $method -eq 'GET') {
                # Read-only view of the last unattended cycle. The poller is a separate
                # process; this endpoint never triggers it.
                $statusPath = Join-Path $apiRoot 'poller-status.json'
                $stopPath = Join-Path $apiRoot 'poller.stop'
                $last = $null
                if (Test-Path $statusPath) {
                    try { $last = Get-Content -Raw -Path $statusPath | ConvertFrom-Json }
                    catch { $last = $null }
                }
                Write-JsonResponse -Response $response -Body @{
                    configured  = (Test-Path $statusPath)
                    enabled     = (([string]$env:AZURESENTRY_POLLER_ENABLED).Trim().ToLowerInvariant() -eq 'true')
                    mode        = $(if (([string]$env:AZURESENTRY_POLLER_MODE).Trim().ToLowerInvariant() -eq 'enforce') { 'enforce' } else { 'shadow' })
                    stopFilePresent = (Test-Path $stopPath)
                    lastCycle   = $last
                }
                continue
            }

```

- [ ] **Step 2: Verify the route**

Run:
```bash
powershell -NoProfile -Command "[void][System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path 'dashboard/api/Start-DashboardApi.ps1').Path, [ref]$null, [ref]$null); 'parsed ok'"
```
Expected: `parsed ok`. Then start the API and check:
```bash
curl -s http://localhost:8787/api/poller/status
```
Expected: JSON with `configured`, `enabled`, `mode`, `stopFilePresent`, `lastCycle`.

- [ ] **Step 3: Add the frontend types**

Append to `dashboard/web/src/types.ts`:

```typescript
// ---------------------------------------------------------------------------
// Unattended ticket poller
// ---------------------------------------------------------------------------

export interface PollerEntry {
  ticketId: string
  /** WouldGrant (shadow) | Granted (enforce) | Queued | Failed. Never "Skipped". */
  outcome: 'WouldGrant' | 'Granted' | 'Queued' | 'Failed'
  reason: string
  action?: string | null
  effectiveEnvironment?: string | null
  role?: string
  subscriptionId?: string
  requesterUpn?: string
  assignmentId?: string
  applied: boolean
}

export interface PollerCycle {
  runId: string
  mode: 'shadow' | 'enforce'
  examined: number
  wouldGrant: number
  granted: number
  queued: number
  failed: number
  stopped: boolean
  halted: boolean
  haltReason?: string
  ranAt: string
  entries: PollerEntry[]
}

export interface PollerStatus {
  configured: boolean
  enabled: boolean
  mode: 'shadow' | 'enforce'
  stopFilePresent: boolean
  lastCycle: PollerCycle | null
}
```

- [ ] **Step 4: Add the API client method**

In `dashboard/web/src/api/client.ts`, add `PollerStatus` to the type import list, then add this entry to the exported `api` object immediately after `breakglass`:

```typescript
  poller: {
    status: () => fetchJson<PollerStatus>('/poller/status'),
  },
```

- [ ] **Step 5: Create the panel**

Create `dashboard/web/src/views/PollerStatusPanel.tsx`:

```tsx
import { useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import AlertTitle from '@mui/material/AlertTitle'
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Typography from '@mui/material/Typography'

import { api } from '../api/client'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import type { PollerStatus } from '../types'

const OUTCOME_TONE: Record<string, 'ok' | 'warn' | 'bad' | 'neutral'> = {
  Granted: 'ok',
  WouldGrant: 'neutral',
  Queued: 'warn',
  Failed: 'bad',
}

/**
 * Read-only view of the unattended poller. It runs as a separate scheduled process, so
 * this panel reports; it never triggers a cycle.
 */
export function PollerStatusPanel() {
  const [status, setStatus] = useState<PollerStatus | null>(null)

  useEffect(() => {
    api.poller.status().then(setStatus).catch(() => setStatus(null))
  }, [])

  if (!status) return null

  const cycle = status.lastCycle

  return (
    <Card sx={{ mb: 2 }}>
      <CardHeader
        title="Unattended ticket poller"
        subheader={
          status.enabled
            ? `Enabled · ${status.mode} mode`
            : 'Disabled (AZURESENTRY_POLLER_ENABLED is not true)'
        }
        action={
          <StatusPill
            tone={!status.enabled ? 'neutral' : status.mode === 'enforce' ? 'ok' : 'warn'}
            label={!status.enabled ? 'Off' : status.mode === 'enforce' ? 'Enforcing' : 'Shadow'}
          />
        }
      />
      <CardContent>
        {status.stopFilePresent && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <AlertTitle>Halted by stop sentinel</AlertTitle>
            <code>dashboard/api/poller.stop</code> exists, so cycles are halting. Delete it to
            resume.
          </Alert>
        )}

        {status.enabled && status.mode === 'shadow' && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Shadow mode: the poller decides and records what it would grant, and writes
            nothing. Set <code>AZURESENTRY_POLLER_MODE=enforce</code> to let it act.
          </Alert>
        )}

        {!cycle ? (
          <Typography color="text.secondary">
            No cycle has run yet. Register the scheduled task with{' '}
            <code>infra/systemd/install-poller-timer.sh</code>.
          </Typography>
        ) : (
          <>
            {cycle.halted && (
              <Alert severity="info" sx={{ mb: 2 }}>
                Last cycle halted: {cycle.haltReason}
              </Alert>
            )}
            {cycle.stopped && (
              <Alert severity="error" sx={{ mb: 2 }}>
                <AlertTitle>Stopped at the first failure (fail-closed)</AlertTitle>
                Later tickets were deliberately not attempted. Fix the cause; the next cycle
                resumes.
              </Alert>
            )}

            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(5, 1fr)' },
                gap: 1.5,
                mb: 2,
              }}
            >
              <StatCard label="Examined" value={cycle.examined} />
              <StatCard
                label={cycle.mode === 'enforce' ? 'Granted' : 'Would grant'}
                value={cycle.mode === 'enforce' ? cycle.granted : cycle.wouldGrant}
                color="success.main"
              />
              <StatCard label="Queued for a human" value={cycle.queued} color="warning.main" />
              <StatCard label="Failed" value={cycle.failed} color="error.main" />
              <StatCard label="Last run" value={new Date(cycle.ranAt).toLocaleTimeString()} />
            </Box>

            {cycle.entries.length > 0 && (
              <TableContainer sx={{ maxHeight: 300 }}>
                <Table stickyHeader size="small" aria-label="Poller cycle entries">
                  <TableHead>
                    <TableRow>
                      <TableCell>Ticket</TableCell>
                      <TableCell>Outcome</TableCell>
                      <TableCell>Role / Env</TableCell>
                      <TableCell>Why</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {cycle.entries.map((e) => (
                      <TableRow hover key={`${e.ticketId}-${e.outcome}`}>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>#{e.ticketId}</TableCell>
                        <TableCell>
                          <StatusPill
                            tone={OUTCOME_TONE[e.outcome] ?? 'neutral'}
                            label={e.outcome === 'WouldGrant' ? 'Would grant' : e.outcome}
                          />
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {e.role ? `${e.role} / ${e.effectiveEnvironment ?? '—'}` : '—'}
                        </TableCell>
                        <TableCell sx={{ minWidth: 280 }}>{e.reason}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
```

- [ ] **Step 6: Render it on the Dashboard view**

In `dashboard/web/src/App.tsx`, add the import beside the other view imports:

```tsx
import { PollerStatusPanel } from './views/PollerStatusPanel'
```

Then render it as the first element inside the `{view === 'overview' && (` fragment, immediately after that fragment's `<PageHeader … />`:

```tsx
              <PollerStatusPanel />
```

- [ ] **Step 7: Typecheck and build**

Run:
```bash
cd dashboard/web && npx tsc --noEmit -p tsconfig.json
```
Expected: only the pre-existing `src/theme.ts(75,9)` error about `outlinedSuccess`. Any error in `PollerStatusPanel.tsx`, `types.ts`, `client.ts` or `App.tsx` must be fixed.

- [ ] **Step 8: Commit**

```bash
git add dashboard/api/Start-DashboardApi.ps1 dashboard/web/src/types.ts dashboard/web/src/api/client.ts dashboard/web/src/views/PollerStatusPanel.tsx dashboard/web/src/App.tsx
git commit -m "Surface the unattended poller in the dashboard

Adds a read-only GET /api/poller/status and a Dashboard panel showing mode,
kill-switch state, stop sentinel, and the last cycle's per-ticket outcomes with
reasons. Without this the unattended path is a black box, which is the specific
complaint that motivated the feature. Shadow rows read 'Would grant', never
'skipped'."
```

---

## Verification

After Task 7:

- [ ] `powershell -NoProfile -Command "Invoke-Pester -Path tests/unit -Output Normal"` — zero failures
- [ ] `cd dashboard/web && npx tsc --noEmit -p tsconfig.json` — only the pre-existing `theme.ts` error
- [ ] Shadow run reports `granted=0` and a non-zero `examined`
- [ ] `dashboard/api/poller.stop` halts the next cycle; deleting it resumes
- [ ] Dashboard Poller panel matches `poller-status.json`
- [ ] Confirm on a live shadow run that no Production or `Eligible` ticket appears as `WouldGrant`

## Deferred

Out of scope, recorded so it is not lost:

- Auto-executing `Eligible` — requires verifying PIM role settings independently enforce approval-on-activation
- Production auto-grants, Reader included
- Auto-resolving the ME ticket after a grant (closure picklist keys `udf_pick_3713` / `udf_pick_3722` are instance-specific and were discovered by hand; the poller posts no note and closes nothing in v1, so a human still closes the ticket)
- Migrating the host to the Automation Account / Logic App shells
- Porting the UI's full free-text mapper to PowerShell
