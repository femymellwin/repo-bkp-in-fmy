# Ticket Template Schemas Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Resolve a ManageEngine template-name schema for each Help Desk ticket, show exactly those requester fields in the UI, and feed a structured `templatePayload` into the API/agents — with Azure Subscription as the only live grant handler.

**Architecture:** A shared schema registry keyed by ME template name drives label-based UDF extraction into `templatePayload`. The web UI renders common + schema fields dynamically. The dashboard API attaches the payload on ticket detail, rejects evaluate/process when `handler !== azure-subscription-grant`, and records one idempotent audit intake event for `pending` handlers.

**Tech Stack:** TypeScript/React (Vite, MUI), Node test runner (`node --test`), PowerShell 5.1+/7, Pester 5, existing `AuditLog.ps1`.

## Global Constraints

- Spec: `docs/superpowers/specs/2026-08-17-ticket-templates-design.md` (source `docs/ticket-templates.md`).
- Schema key: ManageEngine **template name only** (case-insensitive; strip trailing ` Template`).
- Field values: **label-based** UDF extraction; Azure Subscription UDF keys remain a fast-path override for Subscription / Azure Role / Environment.
- Handlers: `azure-subscription-grant` | `pending` only in this change.
- Unknown template: common fields + warning; no raw UDF dump.
- Do **not** add new UI copy containing the word `template` except existing Ticket type helper (`ManageEngine request template`).
- Do not duplicate common fields (requester, category, subcategory, subject, description, status) inside the schema panel.
- Prefer TDD: failing test → implement → pass → commit.
- Frontend tests: `node --test dashboard/web/tests/*.test.mjs` (from `dashboard/web` or with paths).
- Backend tests: `pwsh -File tests/Run-Pester.ps1` (or targeted path).
- Do not commit secrets.

---

## File Structure

**Create**
- `dashboard/web/src/ticketTemplateSchemas.ts` — registry + normalize/lookup + handler
- `dashboard/web/src/buildTemplatePayload.ts` — label flatten/extract + payload builder
- `dashboard/web/tests/ticketTemplateSchemas.test.mjs`
- `dashboard/web/tests/buildTemplatePayload.test.mjs`
- `dashboard/api/TicketTemplates.ps1` — PS mirror: schema lookup, label extract, payload, handler gate helpers
- `tests/unit/TicketTemplates.Tests.ps1`

**Modify**
- `dashboard/web/src/types.ts` — add `TemplatePayload` (+ related types)
- `dashboard/web/src/api/client.ts` — surface `templatePayload` from ticket detail
- `dashboard/web/src/views/TicketsView.tsx` — common Description; schema-driven Request fields; grant UI only for Azure Subscription handler
- `dashboard/web/src/extractMeAccessFields.ts` — export `pickName` / blank helpers if needed by builder (or duplicate minimal helpers in builder to avoid churn)
- `dashboard/api/Start-DashboardApi.ps1` — dot-source `TicketTemplates.ps1`; attach `templatePayload` on GET request; gate evaluate/process; audit intake
- `tests/Run-Pester.ps1` — include `TicketTemplates.Tests.ps1`

---

### Task 1: Schema registry (TypeScript)

**Files:**
- Create: `dashboard/web/src/ticketTemplateSchemas.ts`
- Create: `dashboard/web/tests/ticketTemplateSchemas.test.mjs`

**Interfaces:**
- Produces:
  - `export type TemplateHandler = 'azure-subscription-grant' | 'pending'`
  - `export interface TemplateSchema { canonicalName: string; handler: TemplateHandler; fields: string[] }`
  - `export function normalizeTemplateName(raw: string): string` — trim; strip trailing ` Template` (case-insensitive)
  - `export function lookupTemplateSchema(templateName: string): TemplateSchema | null`
  - `export const TEMPLATE_NAME_ALIASES: Record<string, string>` — e.g. `security assesment` → `Security Assessment`

- [ ] **Step 1: Write failing tests**

```js
import assert from 'node:assert/strict'
import test from 'node:test'
import {
  lookupTemplateSchema,
  normalizeTemplateName,
} from '../src/ticketTemplateSchemas.ts'

test('normalizes trailing Template suffix', () => {
  assert.equal(normalizeTemplateName('Report and Issue Template'), 'Report and Issue')
  assert.equal(normalizeTemplateName('  Azure Subscription  '), 'Azure Subscription')
})

test('Azure Subscription schema has grant handler and expected fields', () => {
  const s = lookupTemplateSchema('Azure Subscription')
  assert.ok(s)
  assert.equal(s.handler, 'azure-subscription-grant')
  assert.deepEqual(s.fields, [
    'Subscription',
    'Azure Role',
    'Exception Request',
    'Environment',
    'Request Type',
  ])
})

test('Networking schema is pending with network fields', () => {
  const s = lookupTemplateSchema('Networking')
  assert.ok(s)
  assert.equal(s.handler, 'pending')
  assert.ok(s.fields.includes('Source IP'))
  assert.ok(s.fields.includes('Protocol (TCP/UDP)'))
})

test('alias Security Assesment → Security Assessment', () => {
  const s = lookupTemplateSchema('Security Assesment')
  assert.ok(s)
  assert.equal(s.canonicalName, 'Security Assessment')
})

test('unknown name returns null', () => {
  assert.equal(lookupTemplateSchema('Unspecified'), null)
  assert.equal(lookupTemplateSchema('Totally Fake'), null)
})
```

- [ ] **Step 2: Run tests — expect FAIL**

Run: `cd dashboard/web && node --test tests/ticketTemplateSchemas.test.mjs`  
Expected: FAIL (module missing)

- [ ] **Step 3: Implement registry**

Implement `ticketTemplateSchemas.ts` with all schemas from the design doc (common fields excluded from `fields` arrays). Include every leaf template: 1Password, Cursor, GitHub Enterprise, Azure Subscription, ADO, General Access, Infrastructure, Networking, MLOps, Policy Exemptions, New Project, Cortex, Infosec, Security Assessment, DevOps Access, Report and Issue, Other Request, SOC.

Aliases at minimum: `security assesment`, `github enterprise` spelling variants if needed, names with trailing ` Template` handled by normalize.

- [ ] **Step 4: Run tests — expect PASS**

- [ ] **Step 5: Commit**

```bash
git add dashboard/web/src/ticketTemplateSchemas.ts dashboard/web/tests/ticketTemplateSchemas.test.mjs
git commit -m "feat: add ManageEngine ticket template schema registry"
```

---

### Task 2: Label extraction + `buildTemplatePayload` (TypeScript)

**Files:**
- Create: `dashboard/web/src/buildTemplatePayload.ts`
- Create: `dashboard/web/tests/buildTemplatePayload.test.mjs`
- Modify: `dashboard/web/src/types.ts` (add `TemplatePayload` types)

**Interfaces:**
- Consumes: `lookupTemplateSchema`, `normalizeTemplateName`, `ticketTypeLabel` / raw template name; `MeAccessFields` optional override
- Produces:
  - `export interface TemplatePayloadCommon { requesterName: string; requesterEmail: string; category: string; subcategory: string; subject: string; description: string; status: string }`
  - `export interface TemplatePayload { templateName: string; handler: TemplateHandler | 'none'; knownSchema: boolean; common: TemplatePayloadCommon; fields: Record<string, string>; fieldOrder: string[]; warnings: string[] }`
  - `export function flattenUdfByLabel(udf: unknown): Map<string, string>` — key = lowercased label
  - `export function buildTemplatePayload(ticket: METicket, accessFields?: MeAccessFields | null): TemplatePayload`
  - Label aliases map: `'protocol (tpc/udp)'` → field `Protocol (TCP/UDP)`

UDF shapes to support:
- `{ udf_pick_1: { name: 'X' } }` with sibling label metadata if present
- Objects with `label` / `name` / `value` / `display_value`
- When ME returns only keyed picks without labels: also match by scanning object entries where nested `.label` exists; if a field label equals a known schema field, use it
- Practical approach used in tests: pass `udf_fields` as either:
  1. `Record<label, value>` for unit tests, or
  2. Objects like `{ some_key: { label: 'Source IP', name: '10.0.0.1' } }`

Azure Subscription override: if `accessFields.Subscription|AzureRole|Environment` or known UDF keys from `extractMeAccessFields` are set, prefer those for Subscription / Azure Role / Environment fields.

- [ ] **Step 1: Write failing tests**

```js
import assert from 'node:assert/strict'
import test from 'node:test'
import { buildTemplatePayload } from '../src/buildTemplatePayload.ts'

test('builds Networking fields from labeled UDFs', () => {
  const payload = buildTemplatePayload({
    id: 1,
    subject: 'Open firewall',
    description: 'Need access',
    status: { name: 'Open' },
    category: { name: 'Azure' },
    subcategory: { name: 'Networking' },
    requester: { name: 'Ada', email_id: 'ada@example.com' },
    template: { name: 'Networking' },
    udf_fields: {
      a: { label: 'Source IP', name: '10.1.1.1' },
      b: { label: 'Destination IP', name: '10.2.2.2' },
      c: { label: 'Port', name: '443' },
      d: { label: 'Protocol (TPC/UDP)', name: 'TCP' },
    },
  })
  assert.equal(payload.knownSchema, true)
  assert.equal(payload.handler, 'pending')
  assert.equal(payload.fields['Source IP'], '10.1.1.1')
  assert.equal(payload.fields['Protocol (TCP/UDP)'], 'TCP')
  assert.equal(payload.common.subject, 'Open firewall')
  assert.ok(!('Category' in payload.fields))
})

test('unknown template warns and has empty fieldOrder', () => {
  const payload = buildTemplatePayload({
    id: 2,
    subject: 'x',
    template: { name: 'Mystery' },
    udf_fields: { a: { label: 'Item', name: 'secret' } },
  })
  assert.equal(payload.knownSchema, false)
  assert.equal(payload.handler, 'none')
  assert.deepEqual(payload.fieldOrder, [])
  assert.ok(payload.warnings.some((w) => /unknown template schema/i.test(w)))
  assert.ok(!payload.fields.Item)
})

test('Azure Subscription prefers accessFields override', () => {
  const payload = buildTemplatePayload(
    {
      id: 3,
      subject: 'Access',
      template: { name: 'Azure Subscription' },
      udf_fields: {},
    },
    { Subscription: 'sub-a', AzureRole: 'Reader', Environment: 'Sandbox' },
  )
  assert.equal(payload.handler, 'azure-subscription-grant')
  assert.equal(payload.fields.Subscription, 'sub-a')
  assert.equal(payload.fields['Azure Role'], 'Reader')
  assert.equal(payload.fields.Environment, 'Sandbox')
})
```

- [ ] **Step 2: Run — expect FAIL**

- [ ] **Step 3: Implement `buildTemplatePayload.ts` + add types to `types.ts`**

- [ ] **Step 4: Run — expect PASS**

- [ ] **Step 5: Commit**

```bash
git add dashboard/web/src/buildTemplatePayload.ts dashboard/web/src/types.ts dashboard/web/tests/buildTemplatePayload.test.mjs
git commit -m "feat: build templatePayload from ME labels and schema"
```

---

### Task 3: PowerShell `TicketTemplates.ps1` + evaluate/process gate + detail payload

**Files:**
- Create: `dashboard/api/TicketTemplates.ps1`
- Create: `tests/unit/TicketTemplates.Tests.ps1`
- Modify: `dashboard/api/Start-DashboardApi.ps1`
- Modify: `tests/Run-Pester.ps1`

**Interfaces:**
- Produces (PowerShell):
  - `Get-NormalizedTemplateName -Name <string>`
  - `Get-TicketTemplateSchema -TemplateName <string>` → `$null` or `@{ CanonicalName; Handler; Fields = string[] }`
  - `New-TemplatePayload -Ticket <object> -AccessFields <hashtable|null>` → ordered hashtable matching TS shape (`handler` `none` when unknown)
  - `Test-TemplateAllowsGrant -Payload <hashtable>` → `$true` only when `handler -eq 'azure-subscription-grant'`

API changes in `Start-DashboardApi.ps1`:
1. Dot-source `TicketTemplates.ps1` near other helpers.
2. GET `/api/manageengine/requests/{id}`: after `accessFields`, compute `$templatePayload = New-TemplatePayload -Ticket $reqObj -AccessFields $accessFields` and include `templatePayload` in JSON body.
3. At start of evaluate and manageengine/process handlers (after reading body): if body contains `templatePayload` or `templateName` / ticket with template, build/check payload; if not grant-allowed, return 200 with blocked decision shape:

```powershell
@{
  decision = @{
    Action = 'Hold'
    Path   = 'Unsupported-Template'
    Reason = 'This request type does not have an Azure grant handler yet. Structured intake only.'
  }
  steps = @()
  processed = $false
  templateBlocked = $true
}
```

Prefer: if client sends `handler` on the body, trust it only after recomputing from ticket template name when ticket is present; otherwise require `templateName` and re-lookup.

4. After building payload on GET detail, if `handler -eq 'pending'`, call audit append once per ticket id (in-memory set `$script:TemplateIntakeRecorded` + optional durable check via audit search, or write with action `TemplateIntake` and skip if already recorded this process). Use `Write-AuditEvent` (or existing `Add-AuditEvent` name from `AuditLog.ps1`) with `agent = 'TicketIntake'`, `action = 'TemplateIntake'`, `outcome = 'Success'`, `detail = payload`.

- [ ] **Step 1: Write Pester tests for normalize/lookup/payload/grant gate**

```powershell
BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\TicketTemplates.ps1')
}

Describe 'Get-TicketTemplateSchema' {
    It 'returns grant handler for Azure Subscription' {
        $s = Get-TicketTemplateSchema -TemplateName 'Azure Subscription'
        $s.Handler | Should -Be 'azure-subscription-grant'
    }
    It 'returns pending for Networking' {
        (Get-TicketTemplateSchema -TemplateName 'Networking').Handler | Should -Be 'pending'
    }
    It 'returns null for unknown' {
        Get-TicketTemplateSchema -TemplateName 'Mystery' | Should -Be $null
    }
}

Describe 'Test-TemplateAllowsGrant' {
    It 'allows only azure-subscription-grant' {
        Test-TemplateAllowsGrant -Payload @{ handler = 'azure-subscription-grant' } | Should -Be $true
        Test-TemplateAllowsGrant -Payload @{ handler = 'pending' } | Should -Be $false
        Test-TemplateAllowsGrant -Payload @{ handler = 'none' } | Should -Be $false
    }
}
```

- [ ] **Step 2: Run Pester — expect FAIL**

Run: `pwsh -Command "Invoke-Pester -Path tests/unit/TicketTemplates.Tests.ps1 -Output Detailed"`

- [ ] **Step 3: Implement `TicketTemplates.ps1` (mirror TS schemas)**

- [ ] **Step 4: Wire API + Pester list; run tests PASS**

- [ ] **Step 5: Commit**

```bash
git add dashboard/api/TicketTemplates.ps1 dashboard/api/Start-DashboardApi.ps1 tests/unit/TicketTemplates.Tests.ps1 tests/Run-Pester.ps1
git commit -m "feat: API templatePayload, grant gate, and intake audit"
```

---

### Task 4: API client + TicketsView UI

**Files:**
- Modify: `dashboard/web/src/api/client.ts`
- Modify: `dashboard/web/src/views/TicketsView.tsx`
- Optional test: `dashboard/web/tests/ticketsViewCopy.test.mjs` — assert no new forbidden copy strings in a small exported helper if extracted; otherwise skip and rely on manual review of strings introduced in this task

**Interfaces:**
- Consumes: `buildTemplatePayload`, `TemplatePayload` from detail response
- Client: `getRequest(id)` return type includes `templatePayload?: TemplatePayload`
- On expand/detail fetch: prefer server `templatePayload`; else `buildTemplatePayload(detail, accessFields)` client-side fallback

UI behavior:
1. Ticket Details MetaList: ensure Description row (stripped HTML snippet or “—”); keep Subject, Requester, Status, Category, Subcategory, Ticket type.
2. Right panel title: `Request fields` (not “…template…”).
3. Always show Ticket type read-only field (existing helper text OK).
4. If `payload.knownSchema`: render `fieldOrder.map` → read-only TextFields; value or placeholder `Not supplied`.
5. If `!payload.knownSchema`: Alert warning from `payload.warnings`.
6. If `handler === 'azure-subscription-grant'`: keep existing Azure Role / Environment / Subscription / Priority / Duration / Requester UPN / Justification validation + Run Validation / Provide Access buttons (can keep using `mapping` derived as today).
7. If `handler === 'pending'`: show Alert info “Structured intake recorded — action handler pending.” Hide grant buttons and Azure-only validation fields (do not show empty Azure Role/Subscription checklist).
8. If `handler === 'none'`: warning only; no grant buttons.

- [ ] **Step 1: Update client types/return for `templatePayload`**

- [ ] **Step 2: Refactor TicketsView right panel as above; store `templatePayload` in expand state**

- [ ] **Step 3: Smoke — `cd dashboard/web && npx tsc -b --pretty false` (or project build) must typecheck

- [ ] **Step 4: Commit**

```bash
git add dashboard/web/src/api/client.ts dashboard/web/src/views/TicketsView.tsx dashboard/web/src/types.ts
git commit -m "feat: render schema-driven request fields on Help Desk tickets"
```

---

### Task 5: End-to-end verification

**Files:** none new (run existing suites)

- [ ] **Step 1: Run frontend unit tests**

```bash
cd dashboard/web
node --test tests/ticketTypeLabel.test.mjs tests/ticketTemplateSchemas.test.mjs tests/buildTemplatePayload.test.mjs
```

Expected: all PASS

- [ ] **Step 2: Run Pester TicketTemplates (+ smoke full suite if time)**

```bash
pwsh -File tests/Run-Pester.ps1
```

Expected: TicketTemplates tests PASS; no new failures from this change

- [ ] **Step 3: Spec checklist self-verify**

| Spec item | Task |
|-----------|------|
| Schema by template name | 1, 3 |
| Label extraction | 2, 3 |
| Common fields not duplicated | 2, 4 |
| Unknown → warning | 2, 4 |
| Azure grant only for Azure Subscription | 3, 4 |
| pending intake audit | 3 |
| No new “template” UI strings | 4 |

- [ ] **Step 4: Final commit only if stray fixes remain; otherwise done**

---

## Self-review (plan vs spec)

1. **Spec coverage:** Schema registry, label extract, payload, UI panel, grant gate, pending audit, unknown warning — all tasked. Non-goals (other handlers, subcategory matching, raw UDF dump) excluded.
2. **Placeholders:** None intentional; PS audit function name must be matched to actual export in `AuditLog.ps1` at implement time (`Write-AuditEvent` vs `Add-AuditLogEvent` — read file and use the real name).
3. **Type consistency:** `TemplatePayload.handler` is `azure-subscription-grant | pending | none`; `TemplateSchema.handler` omits `none`.
