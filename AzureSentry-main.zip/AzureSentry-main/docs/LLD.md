# AzureSentry — Low-Level Design

> **Why this document exists:** the governance review asked that the architecture diagram and
> the automation eligibility matrix move **out of the application** and into a low-level design
> document (`AzureSentry_Governance-Feedback.md` FR5). The corresponding dashboard views were
> removed; this file is now the single source of truth for that content.
>
> **Authority:** `docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md`
> **Review input:** `docs/AzureSentry_Governance-Feedback.md`
> **Status tracker:** `progress.md`

---

## 1. Agent architecture

The platform's value proposition is the number and independence of its agents, not a UI over the
Azure CLI. Every action is executed by a discrete agent with one job, its own runtime kind, its own
least-privilege identity surface, and its own audit record.

The runtime is `src/Agents/AgentRuntime.ps1`. `Invoke-Agent` wraps every action so that it:

- gets a **run id** that correlates every audit event the action produced,
- emits a `Started` event and a terminal event (`Success` / `Failed` / `Blocked` / `DryRun`),
- records **before/after** state so a rollback is mechanically derivable,
- records duration, and never silently swallows a failure.

### 1.1 Agent registry

| Agent | Kind | Job | Writes | Systems it calls |
|---|---|---|---|---|
| **TicketIngestionAgent** | Deterministic | Reads ManageEngine tickets and normalizes them into the platform ticket schema. | No | ME ServiceDesk Plus REST |
| **SummarizationAgent** | LLM | Reads ticket highlights and produces a business-facing access-request summary for operators. | No | Core42 / Azure OpenAI |
| **DecisionAgent** | Deterministic | Runs the 7-step validation tree and returns Grant / Eligible / Reject / Hold / BreakGlass. | No | `RbacDecision` module + its JSON data |
| **AccessProvisioningAgent** | Deterministic | Grants and revokes Azure access by calling ARM RBAC/PIM and Graph group APIs directly. **No CLI shell-out.** | **Yes** | ARM role assignment & PIM schedule APIs, Microsoft Graph groups |
| **SubscriptionResolverAgent** | Deterministic | Resolves a ticket's subscription reference to exactly one subscription, or hands off to a human. | No | ARM subscriptions / MG descendants |
| **SentryGovernanceAgent** | Hybrid | Owns the governance pillar: infers and backfills the Environment tag in validated batches with a rollback journal. | **Yes** | ME request update, Core42 / Azure OpenAI |
| **TicketCategorizationAgent** | Hybrid | Classifies tickets by agent-actionable work type so department scope expansion is measured. | No | ME (read), Core42 / Azure OpenAI |

### 1.2 Agent framework decision

The open question in the review ("tool-calling LLM loop, or deterministic job plus an LLM step?")
is answered **both**, and the registry makes which is which explicit:

- `Kind = Deterministic` — the agent only calls APIs. No model in the path. This is where every
  **write to Azure** lives, so a grant is never contingent on model output.
- `Kind = Llm` — the agent only reasons over text. It has an LLM key and nothing else: no Azure
  scope, no ManageEngine write scope.
- `Kind = Hybrid` — an LLM step proposes, a deterministic step acts, and the audit record shows
  which part did what (`source` = `Dropdown` | `Llm` | `Rules`, plus a confidence).

The shared LLM step is `src/Agents/LlmClient.ps1` (`Invoke-LlmJsonCompletion`), provider-agnostic
across Core42 (default), Azure OpenAI, and OpenAI.

### 1.3 Runtime pipeline

```
ManageEngine ticket
      │
      ▼
TicketIngestionAgent ────────────► normalized ticket
      │
      ├──► SummarizationAgent ───► operator-facing summary (LLM)
      │
      ├──► SubscriptionResolverAgent ──► exactly one subscription, or NeedsHumanChoice
      │
      ▼
DecisionAgent (7-step tree)
      │  Grant / Eligible / BreakGlass          Reject / Hold
      ▼                                              │
AccessProvisioningAgent                              │ no Azure call
  ├─ group-first: ensure sg-… group + subscription IAM + membership
  └─ fallback:    ARM PIM active or eligible schedule request
      │
      ▼
Audit trail (append-only, hash-chained)  ──►  Log Analytics (Deliverable #10, pending deploy)
```

Running in parallel, on the existing ticket backlog rather than on new requests:

```
SentryGovernanceAgent
  1. infer environment  (dropdown = deterministic; free text = LLM + confidence; rules = fallback)
  2. split report       → exported for stakeholder + Siva validation
  3. batched write      → 10 → 20 → 30 → 50 → bulk, checkpoint after each
  4. rollback journal   → every write holds its exact previous value
```

---

## 2. Automation eligibility matrix

Loaded at runtime from `src/RbacDecision/Data/eligibility-matrix.json` (scope §2.2). This table is
the design record; the JSON is the executable one, and they must be changed together.

| Request Type | Environment | Role | Priority | Action | Path | Human Touch | Runbook |
|---|---|---|---|---|---|---|---|
| Standard Access | Sandbox | Reader | Any | Grant | Sandbox-FullAuto | None | Runbook-Sandbox-PIM |
| Standard Access | Sandbox | Contributor | Any | Grant | Sandbox-FullAuto | None | Runbook-Sandbox-PIM |
| Standard Access | Sandbox | Owner | Any | Reject | Policy-Block | None | — |
| Standard Access | NonProd | Reader | Any | Grant | NonProd-FullAuto | None | Runbook-Sandbox-PIM |
| Standard Access | NonProd | Contributor | Any | Eligible | NonProd-Contributor-Approval | Single Approver | Runbook-Prod-PIM |
| Standard Access | NonProd | Owner | Any | Reject | Policy-Block | None | — |
| Standard Access | Production | Reader | P3/P4 | Grant | Production-Reader-FullAuto | None | Runbook-Sandbox-PIM |
| Standard Access | Production | Reader | P1/P2 | Grant | Production-Reader-FullAuto | None | Runbook-Sandbox-PIM |
| Standard Access | Production | Contributor | P3/P4 | Eligible | Production-Standard | Single Approver | Runbook-Prod-PIM |
| Standard Access | Production | Contributor | P1/P2 | Eligible | Production-Expedited | Single + On-Call | Runbook-Prod-PIM |
| Privileged Access | Production | Owner | Any | Eligible | Production-DualApproval | Two Approvers | Runbook-Prod-PIM |
| Privileged Access | Production | UAA | Any | Eligible | Production-DualApproval | Two Approvers | Runbook-Prod-PIM |
| Emergency Access | Production | Contributor | P1 | BreakGlass | Emergency-BreakGlass | Async Review | Runbook-Emergency-PIM |
| Emergency Access | Production | Owner | P1 | Reject | Emergency-Escalate | Incident Bridge | — |
| Custom Role | Either | Custom | Any | Hold | Governance-Review | Cloud Governance | — |
| Bulk Request | Either | Any | Any | Hold | Governance-Review | Cloud Governance | — |
| Cross-Subscription | Production | Any | Any | Eligible | Production-CrossSubscription | Senior Approver | Runbook-Prod-PIM |

### 2.1 Environment escalation before the matrix is consulted

`Get-EffectiveEnvironment` (backed by `subscription-sensitivity.json`) takes the **more restrictive**
of the mapped and claimed environment, so a request that claims "sandbox" against a sensitive
subscription is evaluated as Production. It never downgrades an explicit Production request. The
decision record carries `Claimed`, `Effective` and `Overridden`.

---

## 3. Prioritization model (FR1)

`Get-TicketCriticality` (`src/RbacDecision/Public/`) computes criticality with **environment as the
primary signal** and requester-declared priority as a tiebreaker only.

```
score = (environmentRank * 10) + priorityRank

environmentRank:  Production 0 │ NonProd 1 │ Sandbox 2 │ Unknown 3
priorityRank:     P0 0 │ P1 1 │ P2 2 │ P3 3 │ P4 4 (default)
```

The multiplier exceeds the maximum priority rank, so **no priority can cross an environment
boundary**. That is the stakeholder rule made structural: a P1 claimed on Non-Prod cannot outrank a
Production ticket. When a P0–P2 is claimed outside Production, the result carries
`PriorityDemoted = true` plus a reason, so the demotion is visible rather than silent.

| Band | Environment | Tier |
|---|---|---|
| 0 | Production | Critical |
| 1 | Non-Prod | High |
| 2 | Sandbox | Standard |
| 3 | Unknown | Unclassified |

**Unknown sorts last and is flagged `RequiresEnvironment`.** An untagged ticket cannot be
prioritized at all, so the set of unclassified tickets *is* the governance backfill queue rather
than a silently mis-ranked part of the queue.

### 3.1 Canonical key-field ranking

Enforced in the ManageEngine template and in the Execution Hub checklist, in this order:

1. **Subscription** — required. Resolved to exactly one subscription (§4).
2. **Project / Application** — required.
3. **Environment** — required. Dropdown preferred; the checklist blocks evaluation and grant when
   it is unresolved.
4. **Priority** — optional with a P4 default; captured when supplied, secondary signal only.

---

## 4. Multi-subscription disambiguation (FR3)

`Resolve-TicketSubscription` (`src/Agents/SubscriptionResolver.ps1`), in strict order:

| Step | Condition | Result |
|---|---|---|
| 1 | Exact subscription id (GUID) on the allowlist | `Resolved` / `ExactId` |
| 2 | Exact subscription name, case-insensitive | `Resolved` / `ExactName` |
| 3 | Exactly one fuzzy/slug candidate | `Resolved` / `UniqueKeyword` |
| 4 | Several candidates, exactly one in the requested environment | `Resolved` / `EnvironmentFilter` |
| 5 | Still several candidates | **`NeedsHumanChoice`** — full candidate list returned |
| 6 | No candidates | `NotFound` |

It **never returns more than one subscription as resolved**, so a keyword can never fan a grant out
across subscriptions. Environment classification of a subscription name is deliberately
conservative: anything unrecognised is `Unknown`, never `Production`, so the environment filter can
only narrow on positive evidence.

---

## 5. Environment backfill pipeline (FR2)

### 5.1 Inference precedence

| Source | When | Confidence | `inferred` |
|---|---|---|---|
| `Dropdown` | The ticket carries a ManageEngine Environment dropdown value | 1.0 | **false** |
| `Llm` | Free-text or untagged; a model returns a label + calibrated confidence + rationale | model-reported | **true** |
| `Rules` | Fallback when the LLM is unavailable | **capped at 0.55** | **true** |

The rules cap sits below the auto-apply threshold by construction, so a keyword match can never on
its own clear the write gate — this is the "do not rely on raw keyword search" requirement enforced
in code rather than by policy.

### 5.1.1 Structured-template routing

Four ManageEngine templates carry a **mandatory** Environment dropdown: **Azure Subscription,
GitHub Enterprise, ADO, Cortex**. The confirmed live options on that dropdown are:

| ME dropdown option | Canonical environment |
|---|---|
| Sandbox | Sandbox |
| Development | NonProd |
| Test | NonProd |
| Preproduction | NonProd |
| Production | Production |

If the dropdown value is present, it is used deterministically (source `Dropdown`) regardless of
template. If it is missing (a requester left a mandatory field blank), the four structured templates
split into two routing groups — **only Azure Subscription ever reaches the LLM**:

- **Azure Subscription (escalate-eligible)** — tries `Get-RuleBasedEnvironment` (keyword rules)
  first, and only *stays* on rules if a keyword is actually found. A rule miss is escalated to the
  LLM rather than recorded as an unresolved Rules result: "the mandatory field is blank" is not the
  same claim as "the ticket text has no environment signal," and an issue-report-style ticket (e.g.
  "I don't have git access") can still imply an environment even with no literal keyword.
- **GitHub Enterprise, ADO, Cortex (rules-only)** — **never** call the LLM, regardless of whether a
  keyword is found. A rule miss on **GitHub Enterprise defaults to Production** (its access requests
  are assumed production-facing — including project-specific repo/access requests — unless a
  non-production keyword says otherwise). A rule miss on **ADO or Cortex stays Unknown**, same as a
  plain rules-only miss.

Tickets from every other template (free text, no structured field at all — including "Report an
Issue") go straight to the LLM, which is instructed to judge from the ticket's **subject/title and
description/justification**, including inferring an implied access/environment need from an issue
report, not just an explicit request.

Across all templates, a text keyword match on **test, sandbox, QA, or Development never resolves to
Production** — sandbox keeps mapping to the distinct Sandbox environment and test/QA/Development map
to NonProd, but neither is ever read as Production regardless of which routing path produced it.

| Structured template, dropdown blank | Rules finds a keyword | Result |
|---|---|---|
| Azure Subscription | Yes | Stays on `Rules`, LLM never called |
| Azure Subscription | No | Escalated to `Llm`; falls back to `Rules`/`Unknown` only if the LLM call itself fails |
| GitHub Enterprise | Yes | Stays on `Rules`, LLM never called |
| GitHub Enterprise | No | `Rules`/**Production** (template default), LLM never called |
| ADO / Cortex | Yes | Stays on `Rules`, LLM never called |
| ADO / Cortex | No | `Rules`/`Unknown`, LLM never called |
| Any other template | n/a | Always `Llm` (batched) |

Dropdown values are normalized (lowercased, whitespace/underscores folded to hyphens) so `Non Prod`,
`non_prod`, `Non-Prod`, and the confirmed one-word `Preproduction` all resolve identically.

### 5.2 Write gates

Every one of these is enforced in code, not by convention:

- **Dry-run is the default.** A real write needs `-Apply` **and** `-ValidatedBy`.
- **`-ValidatedBy` is mandatory to apply** — the human go-ahead, recorded on every journal entry
  and audit event.
- **Production is hard-excluded**, twice: `New-EnvironmentBackfillPlan` filters it out of the
  allowed environments, and `Invoke-EnvironmentBackfillBatch` refuses it per ticket even if a plan
  somehow contains it. `Update-ManageEngineTicketEnvironment` refuses it a third time at the API
  boundary.
- **One batch per invocation**, sized 10 → 20 → 30 → 50 → bulk, with a checkpoint journalled after
  each. There is no code path that runs 2000 writes in one call.
- **Fail-closed** — the first failed write stops the batch unless `-ContinueOnError`.
- **Below-threshold and unresolved rows are excluded** from the plan entirely.

### 5.3 Rollback

Every applied write journals the **exact previous value read back from the system of record** (not
the report's snapshot). `Invoke-EnvironmentBackfillRollback` replays those values newest-first, so a
partially-applied batch unwinds in the opposite order it was applied. Rollback is itself journalled
and audited as a **compensating** entry (`correctsEventId`); nothing is ever erased. Re-running a
rollback is safe — already-restored tickets are skipped.

### 5.4 Inference accuracy evaluation

`Measure-EnvironmentInferenceAccuracy` scores inference output against a human-labelled sample and
reports:

- overall accuracy,
- **accuracy restricted to results at or above the confidence threshold** — the number that
  actually gates the write path,
- per-environment recall,
- the confusion pairs, so a systematic error (e.g. NonProd read as Production) is visible rather
  than averaged away.

**Still open:** the labelled sample itself, and the agreed accuracy threshold. The harness exists;
the numbers need a human-labelled set before the first bulk run.

---

## 6. Department scope (FR4)

`Invoke-TicketCategorizationAgent` buckets a department's queue by work type. Deterministic rules
run first (ordered most-specific first, so "a secret for app X" lands on `ClientSecret`, not
`AppRegistration`); an LLM step classifies only what the rules could not place.

| Work type | Agent-actionable | Human audit | Note |
|---|---|---|---|
| AccessGrant | Yes | No | The existing IDM path |
| GroupMembership | Yes | No | Existing group-based RBAC path |
| AppRegistration | Yes | **Yes** | Graph `Application.ReadWrite.OwnedBy` |
| ClientSecret | Yes | **Yes** | Mints a credential — always audited |
| ResourceProvisioning | Yes | Yes | Templated resource/RG creation |
| QuotaIncrease | Yes | Yes | Cost-bearing |
| KeyVaultAccess | Yes | Yes | Data-plane access |
| Troubleshooting | No | — | Needs an engineer |
| NetworkChange | No | — | Owned by another team |
| Advisory | No | — | No change to make |
| Unclassified | No | — | Needs a human read |

Scope bands live in `dashboard/api/config.json → departmentScope`:
**active** = IDM / IDAM Team · **expanding** = Infrastructure · **deferred** = SOC, Networking,
DevOps, DevSecOps.

---

## 7. Audit trail (FR6 / NFR3)

`dashboard/api/AuditLog.ps1`, one JSON object per line in `audit-log.jsonl`.

Each event carries `seq`, `timestamp`, `agent`, `action`, `actor`, `runId`, `correlationId`,
`ticketId`, `target`, `before`, `after`, `outcome`, `reason`, `detail`, `correctsEventId`, `isWrite`.

**Append-only:** lines are never rewritten or deleted. A correction or rollback is a **new**
compensating event referencing the original via `correctsEventId`.

**Tamper-evident:** each event stores `hash = SHA256(prevHash + canonical body)`, chained from
`GENESIS`. `Test-AuditChainIntegrity` recomputes the whole chain and reports the first break —
distinguishing an edited event (hash mismatch) from a removed one (sequence gap). Both the writer
and the verifier go through one canonicalizer (`Get-AuditCanonicalBody`) so they cannot drift; it
normalizes the timestamp because `ConvertFrom-Json` coerces ISO-8601 strings into `[datetime]`.

**A dry run is never recorded as a write**, even for a write-capable agent.

This is the local, always-on trail that works *before* infrastructure is deployed, and it remains
the system of record even after Log Analytics is wired — Log Analytics is a forwarder on top of it,
never a replacement.

### 7.1 Log Analytics ingestion (Deliverable #10)

`dashboard/api/LogAnalyticsClient.ps1` — every successful `Write-AuditEvent` call also forwards the
event to Log Analytics via the DCR-based **Logs Ingestion API**, outside the local file lock so a
slow or unreachable network call never serializes other audit writes behind it.

- **Optional by construction.** `Get-LogAnalyticsSettings.Configured` requires five environment
  variables (`AZURESENTRY_LA_DCE_ENDPOINT`, `AZURESENTRY_LA_DCR_IMMUTABLE_ID`, `AZURESENTRY_LA_TENANT_ID`,
  `AZURESENTRY_LA_CLIENT_ID`, `AZURESENTRY_LA_CLIENT_SECRET`). Until all five are set, every send is
  a silent no-op — the local trail is unaffected either way.
- **Fail-open, twice over.** `Send-LogAnalyticsAuditEvent` catches its own errors and returns
  `ok=false` instead of throwing; `Write-AuditEvent` wraps the call in a second, defensive try/catch
  in case that contract is ever violated. A Log Analytics outage can never break an agent action —
  the local append already succeeded before the forward is even attempted.
- **Infrastructure:** `infra/modules/loganalytics-audit-dcr.bicep` provisions the custom table
  (`AzureSentryAudit_CL`), a Data Collection Endpoint, and a Data Collection Rule mapping the
  `Custom-AzureSentryAuditLog_CL` stream onto that table. The automation SPN needs the
  **Monitoring Metrics Publisher** role on the DCR — wired automatically via
  `rbac-platform-identities.bicep` when `deployRbac=true`.
- **Diagnostic:** `scripts/Test-LogAnalyticsAccess.ps1` checks configuration, token acquisition, and
  a real send — mirrors `Test-SpnAccess.ps1`'s pattern.
- **KQL dashboard:** `kql/azuresentry-workbook.json` is deployed as an Azure Monitor Workbook by the
  same Bicep module (`Microsoft.Insights/workbooks`), covering agent activity, PIM provisioning
  events, environment governance activity, SLA/priority escalation, and a sequence-gap health check.
  The individual `.kql` files in `kql/` are the same queries, kept standalone for ad hoc use. The
  **tamper-evidence check itself** (`Test-AuditChainIntegrity`) only runs against the local JSONL
  file — KQL cannot recompute the SHA-256 hash chain, so the workbook's health tile is a proxy
  (sequence-gap detection on what actually arrived), not a replacement for it.

**Status:** code-complete and bicep-validated (`az bicep build`); **not yet deployed** — the
workspace, DCE, DCR, and workbook only come into existence once `infra/main.bicep` is applied (B2,
still blocked on infra deploy). Until then, `GET /api/health` and `GET /api/audit` both report
`logAnalytics.configured: false`, and the local trail remains the only audit record — verified
correct behavior, not a bug.

---

## 8. Least privilege (NFR4)

| Identity | Scope | Used by |
|---|---|---|
| Automation SPN `spn-automation-infra` (`e2455957-…`) | User Access Administrator on the managed subscriptions (PIM-eligible where available); Graph `User.Read.All` + `Group.ReadWrite.All` (application) | AccessProvisioningAgent |
| ManageEngine technician API key | Read requests; update the Environment UDF only | TicketIngestionAgent, SentryGovernanceAgent |
| LLM API key | Model inference only — no Azure or ME scope | SummarizationAgent, and the LLM step of the hybrid agents |
| Operator delegated ARM token (`az login`) | The Live PIM engineering tool only | not a production path |

The ManageEngine write is **injected into the governance agent as a scriptblock**, so the agent
itself never holds ME credentials — the API layer owns them.

---

## 9. Configuration reference

`dashboard/api/config.json`:

| Key | Purpose |
|---|---|
| `demoSeed.enabled` | **false.** Illustrative seed data is off; the dashboard shows real data only. |
| `audit.path` | Location of the append-only audit trail. |
| `governance.confidenceThreshold` | Auto-apply gate for inferred environments (default 0.85). |
| `governance.batchSizes` | Progressive rollout sizes; the remainder becomes the bulk batch. |
| `governance.allowedEnvironments` | `["Sandbox","NonProd"]`. Production is never permitted here. |
| `governance.environmentDropdownValues` | Canonical environment → ManageEngine dropdown option label. |
| `departmentScope` | Which departments agents provision, are being assessed, or are out of scope. |
| `allowlist.source` | `managementGroup` — the allowlist is derived live from Azure, fail-closed to the static list. |
| `accessPromotion.enforceLadder` | Sandbox → Non-Prod → Production promotion ladder for auto-grants. |

---

## 10. Information architecture (FR5)

Core menus: **Dashboard**, **Execution Hub**, **Audit Logs**.

The Execution Hub is where agents act on tickets, with three tabs: **Ticket Queue**,
**Environment Governance**, **Department Scope**.

| Removed / changed | Where it went |
|---|---|
| "Help Desk Tickets" | Renamed **Execution Hub** |
| Eligibility Matrix view | §2 of this document |
| Architecture view | §1 of this document |
| Access Audit view | Superseded by **Audit Logs** (real audit trail, not seed data) |
| SLA Compliance / Expiry Tracking / Break-Glass | Marked **Coming Soon** and disabled — they only ever had seed data, which Phase 0 removed. They return when Log Analytics is wired (roadmap D1–D3). |
| Request Simulator / Live PIM | Kept, grouped as **Engineering tools**. They run against the real decision engine and real ARM PIM, so labelling them "Coming Soon" would be untrue. |
