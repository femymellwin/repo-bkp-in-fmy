# Unattended Poller Eligibility Matrix

Every row the RBAC decision engine can return (`src/RbacDecision/Data/eligibility-matrix.json`),
with whether the **unattended ticket poller** (`src/Agents/PollerGate.ps1`) may act on it with
no human involved. `Reject` / `Hold` / `Eligible` are never auto-executable regardless of
environment — only `Grant` on `Sandbox` or `NonProd` is (`PollerGate.ps1`'s
`$PollerAutoActions` / `$PollerAutoEnvironments`). Production is excluded even for a `Grant`
Reader row.


| Environment | Role                                                                   | Priority       | Action                                             | AUTO                                           |
| ----------- | ---------------------------------------------------------------------- | -------------- | -------------------------------------------------- | ---------------------------------------------- |
| Sandbox     | Reader                                                                 | Any            | Grant                                              | **YES**                                        |
| Sandbox     | Contributor *(incl. Writer, AKS RBAC Writer/Admin by tier — see note)* | Any            | Grant                                              | **YES**¹                                       |
| Sandbox     | Owner                                                                  | Any            | Reject — Owner blocked on Sandbox by Azure Policy  | NO                                             |
| Sandbox     | UAA                                                                    | Any            | Reject — unclassified, no matrix row               | NO                                             |
| NonProd     | Reader                                                                 | Any            | Grant                                              | **YES**                                        |
| NonProd     | Contributor *(incl. Writer, AKS RBAC Writer/Admin)*                    | Any            | Grant                                              | **YES**¹                                       |
| NonProd     | Owner                                                                  | Any            | Reject — promote via Production dual-approval only | NO                                             |
| NonProd     | UAA                                                                    | Any            | Reject — unclassified, no matrix row               | NO                                             |
| Production  | Reader                                                                 | P1–P4          | Grant                                              | NO — Production excluded entirely, even Reader |
| Production  | Contributor                                                            | P3/P4          | Eligible — single approver                         | NO                                             |
| Production  | Contributor                                                            | P1/P2          | Eligible — single + on-call                        | NO                                             |
| Production  | Contributor                                                            | P1 (Emergency) | BreakGlass                                         | NO                                             |
| Production  | Owner                                                                  | Any            | Eligible — two approvers, MFA                      | NO                                             |
| Production  | Owner                                                                  | P1 (Emergency) | Reject — incident bridge only                      | NO                                             |
| Production  | UAA                                                                    | Any            | Eligible — two approvers, MFA                      | NO                                             |
| Either      | Custom role                                                            | Any            | Hold — governance review                           | NO                                             |
| Either      | Bulk (>5 users)                                                        | Any            | Hold — governance review                           | NO                                             |
| Production  | Cross-subscription                                                     | Any            | Eligible — senior approver                         | NO                                             |


¹ **Status as of 2026-08-25:** rows marked ¹ reach `Grant` for the plain roles
(`Contributor`, `Writer`) today. The AKS-specific roles
(`Azure Kubernetes Service RBAC Reader/Writer/Admin`, tier `Reader`/`Contributor`/`Contributor`
in `src/RbacDecision/Data/role-catalog.json`) still **queue for a human**, but for only one
remaining reason, not two:

1. ~~`Get-CanonicalAzureRole` discarded any ME role label it didn't recognize down to `''`~~ —
   **fixed**. It now passes an unrecognized-but-non-blank label through verbatim, mirroring
   its TypeScript twin (`mapMeAzureRole` in `dashboard/web/src/extractMeAccessFields.ts`), and
   `Resolve-MeTicketMapping` (`src/Agents/MeTicketMapper.ps1`) confirms it against
   `role-catalog.json` before treating it as mapped. Also implemented: when the resolved role
   is `scopeType: "resource"` (AKS RBAC, Storage data plane), the mapper reads a new
   `TargetResourceId` field and uses it as `Ticket.ResourceScope` instead of defaulting to the
   bare subscription — validated (non-blank, matches the role's `resourceType`) with a clear
   queued reason when it isn't. Covered by new unit tests in `MeTicketMapper.Tests.ps1` and
   `MeAccessFields.Tests.ps1`; full suite is 597/597 passing.
2. ~~That `TargetResourceId` field had nowhere to come from~~ — **resolved 2026-08-26.** The
   ME admin team added "Destination Resource ID" (single-line text, not marked mandatory on
   the ME side — deliberate, since `Resolve-MeTicketMapping` already enforces it conditionally,
   only when the resolved role is `scopeType: "resource"`) to the Azure Subscription template.
   Key confirmed as `udf_sline_3738` (structural diff between ticket #5023, created before the
   field existed, and #5127, created after — not a guess) and wired into
   `manageEngine.udfFields.targetResourceId` in `dashboard/api/config.json`. AKS-role tickets
   that supply a valid cluster resource id in that field should now reach `Grant` end to end;
   ones that don't (or name the wrong resource type) still correctly queue for a human via
   `Test-TicketSchema.ps1`'s fail-closed guard.

`Azure Kubernetes Service RBAC Cluster Admin` (tier `Owner`) is unaffected by either fix — it
stays `Reject` in Sandbox/NonProd on tier grounds alone, same as plain `Owner`.