# AzureSentry - Azure RBAC / PIM Access Automation Platform

## 1. Purpose and Vision

AzureSentry ingests ManageEngine help-desk tickets and lets autonomous agents action Azure RBAC/PIM access changes (starting with Contributor role grants at subscription scope), governed by environment-aware prioritization, human-in-the-loop validation, rollback, and full audit logging.

The central strategic requirement from the review: the platform must be genuinely agent-driven, not a UI wrapper over the Azure CLI. Every action (read ticket -> summarize -> provision access -> tag environment) should be executed by a discrete, independent agent that calls APIs/commands. The number and independence of these agents is the platform's value proposition.

## 2. Current State

- **Ticket Ingestion**: Reads approximately 2000 ManageEngine tickets, but should be framed as an agent action, not a raw API call.
- **Subscription Extraction**: Plain keyword/token parsing of ticket JSON, no LLM.
- **Access Provisioning**: UI over Azure CLI, executed on command front; Sandbox only, must be re-architected as an agent calling APIs; extend to non-prod/prod.
- **Access Summary**: Single LLM call produces an access-request summary, this is the only AI component today.
- **Accept/Reject**: Currently manual, acceptable for now, keep human-in-the-loop.
- **Front-end**: React + Material UI, localhost/Cloud, deploy to Azure in final implementation.
- **Environment Field**: Requester supplies an enviorment via drop-down in the Azure Subscription ticket template, mostly untagged (approx 1165 unknown). Coordinating with team to ensure that this is a mandatory field filled on the requester's end. Must eventually become mandatory + backfilled. This has been updated to become a mandatory field, so new tickets will have an enviorment supplied for Azure subscription tickets.
- **Priority**: All IDAM tickets default to P4. Keep non-mandatory on the requester's end with default in this platform to P4, but stop using it as the real signal.
- **Ticket type** — ME template name on Help Desk (chip/details/filter) and Overview
- **Environment field** — uses **Environment** (`udf_pick_3719`), not Environments Required
- **Azure Subscription template fields** — Subscription + Azure Role + Environment
- **Duplicate access (group path)** — same user already in matching group → warning + Provide Access blocked; different user on existing group still added
- **PrincipalNotFound harden** — dashed group GUID, `principalType=Group`, retries after create→IAM race (#4441)
- **Other Notes**: The app can successfully assign Contributor, Reader, and other access as long as the 7-step validation succeeds. It correctly maps the requester input fields from their ticket to the dashboard.

### Agents the Stakeholder Expects to See (Target Architecture)

1. **LLM Summarization/Serving Agents**: Reads ticket highlights, produces summary, exists partially.
2. **Access Provisioning Agents**: Grants Contributor access via API/CLI, exists as CLI wrapper - must become an agent.
3. **Sentry Governance Agents**: Auto-updates environment tags; owns the governance/control pillar (new).

## 3. Functional Requirements

### FR1 - Mandatory Environment and Prioritization Fields, and Prioritization Logic

- Make environment (Sandbox/Non-prod/Prod) a mandatory field on new tickets, ideally a dropdown (coordinate with Siva on the ManageEngine template).
- Keep priority (P0-P4) a non-mandatory field with a default (P4 today) but capture it when supplied.
- Prioritization must key off environment, not user-declared priority. Rule from stakeholder: a P1 claimed on non-prod must not outrank a prod ticket. Effective ordering: Prod -> Non-prod -> Sandbox, with priority as a secondary tiebreaker.
- Canonical key-field ranking to enforce in template + UI: Subscription -> Project/Application -> Environment -> Priority. None are optional.

### FR2 - Environment Backfill Pipeline (Existing ~2000 Tickets)

- For tickets where environment comes from a dropdown, map directly (deterministically).
- For free text environment/untagged tickets, use an LLM to infer environment from ticket details. Do not rely on raw keyword search alone; if inference is text-based, it must be explicitly flagged as inferred.
- Produce a drill-down report splitting IDM tickets into Sandbox/Non-prod/Prod (with per-ticket inferred label + confidence) for stakeholder + Siva review before any write.
- After Siva validates, an agent updates environment - Sandbox and Non-prod only; Prod excluded for now.
- Roll out batch-by-batch: 10 -> 20 -> 30 -> 50 -> bulk, with validation between batches.
- Every environment update must be reversible (rollback).

### FR3 - Agent-Driven Access Provisioning

- Re-architect Contributor access provisioning so an agent calls Azure APIs/commands (RBAC/PIM), not a hardcoded CLI invocation behind the UI.
- Support environment scoping: currently Sandbox works; enable Non-prod and Prod provisioning (Prod gated behind explicit go-ahead).
- Grant at subscription level, only for the specific subscription(s) ticket authorizes.
- Demonstrate one live end-to-end grant for stakeholder sign-off before expanding scope.
- Resolve the multi-subscription match problem: when a keyword resolves to >1 subscription, define disambiguation (prefer exact match -> environment filter -> surface for human choice, never silently grant all).

### FR4 - Department Scope Expansion

- Currently agent scope = IDAM/IDM only. Expand to Infrastructure next (both owned by DevOps team).
- Out of scope / deferred: SOC (Security team), Networking (minor, other team), DevOps/DevSecOps (assess later).
- Categorize the approx 480 Infrastructure tickets by agent-actionable type (e.g., app registration creation, client-secret creation, subscription/Contributor grants). Target: identify approx 300-400 of 480 that agents can action (with human audit where needed).
- Once IDM + Infrastructure are proven, enforce the same strategy across all departments.

### FR5 - Dashboard and Information Architecture

- Rename "Help Desk Tickets" -> "Execution Hub", this is where agents execute actions on tickets.
- Add an "Audit Logs" view, final core menu: Dashboard, Execution Hub, Audit Logs.
- Mark all unused/future menus as "Coming Soon".
- Move architecture/eligibility matrix content out of the app, into a low-level design (LLD) document.
- Dedupe department charts: left = percentage by department, right = volume by department (ensure click-to-filter drill-down). Avoid two charts showing the same thing.
- Fix the pie chart and make it a donut chart.
- Remove all dummy data before the next demo.
- Add "Inception42" logo next to "AzureSentry" on the platform.

### FR6 - Governance, Audit and Human-in-the-Loop

- Every agent activity (read, summarize, provision, tag-update) must be written to audit logs - who/what/when, target subscription, before/after state. 
- Bulk/automated changes require human validation (Siva) before commit and rollback capability after.
- No writes to production without explicit stakeholder go-ahead.
- 

  |                  |                                                                                                                                          |
  | ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
  | **Capability**   | **Description**                                                                                                                          |
  | Full Automation  | Sandbox requests for Reader/Contributor roles: ticket → active PIM assignment in under 60 seconds, zero human touch.                     |
  | Approval-Gated   | Production Contributor/Owner requests: agent creates PIM eligible assignment; designated reviewer approves in Azure Portal or My Access. |
  | Priority-Aware   | P1 (Critical) tickets in Production auto-escalate to the on-call engineer and trigger a shortened approval SLA.                          |
  | Risk-Aware       | Owner-role and custom-role requests always require dual-approval regardless of environment.                                              |
  | JIT & Time-Bound | No permanent assignments. PIM enforces expiry natively — no cleanup runbooks.                                                            |
  | Full Audit Trail | Every agent decision, PIM event, and ticket update is logged in Log Analytics with KQL dashboards.                                       |


## 4. Non-Functional Requirements

- **NFR1 - Deployment**: Move from localhost/cloudPC to Azure VM. Expected to resolve current latency. (This is final implementation step once all other requirements have been fulfilled)
- **NFR2 - Reproducibility/Safety**: Seed/log every agent run: batched writes with checkpoints; rollback tested before first bulk run.  
- **NFR3 - Immutable Append-Only Audit Trail**: For all agent actions.
- **NFR4 - Least Privilege**: Agents own Azure identity scoped to exactly the subscriptions/roles it must manage (PIM-eligible, not standing where available).

## 5. Open Questions / Decisions Needed

- LLM environment-inference accuracy: No target/eval. Need a labeled sample + accuracy threshold + low-confidence handling.  
- The 1165 'unknown' tickets - inferable by LLM, or left untagged? Decision deferred.
- Priority + environment composite: how the two combine into final criticality is not yet formalized.
- All-department access provisioning breadth - SOC out, real breadth pending Infrastructure categorization.
- Agent framework/runtime - what actually implements an agent calling APIs (tool-calling LLM loop? deterministic job + LLM step?). Biggest architecture decision - Answer: Both deterministic API calling and LLM step.

## 6. Action Plan (Sequence)

### Phase 0 - Cleanup and IA

- Remove all dummy data from dashboard charts.
- Rename "Help Desk Tickets" to "Execution Hub".
- Reduce menus to Dashboard / Execution Hub / Audit Logs; mark others "Coming Soon". 
- Move architecture/eligibility matrix content to LLD doc.
- Dedupe + de-crowd department/detail charts.
- Add tickets-by-environment and tickets-by-category (real data only).

### Phase 1 - Environment as First-Class Signal

- Coordinate with Siva to make environment mandatory in the ManageEngine template (dropdown preferred). Completed
- Confirm priority stays optional with default; write prioritization to key off environment (Prod -> Non-prod -> Sandbox).  
- Build the IDM environment drill-down (Sandbox/Non-prod/Prod) with per-ticket LLM inference + confidence.

### Phase 2 - Environment Backfill Pipeline (IDM First, Infrastructure Second)

- Dropdown-sourced env -> deterministic map.
- Free text / untagged -> LLM inference; output the split report for Siva.
- Build the Sentry Governance Agent to write env tags, with rollbacks.
- Get Siva's validation -> Run Sandbox + Non-prod only, batched 10-20-30-50-bulk. Prod excluded.

### Phase 3 - Agentic Access Provisioning

- Re-architect Contributor provisioning as an agent calling Azure RBAC/PIM APIs.  
- Demo one live end-to-end Contributor grant for sign-off.
- Enable Non-prod provisioning, keep Prod gated.

### Phase 4 - Infrastructure Expansion

- Categorize the approx 480 Infrastructure tickets by agent-actionable type; target approx 300-400 actionable.
- Define use cases (app registration, client secret, access grants) agents can handle.
- Apply IDM + Infra strategy, then generalize to other in-scope departments.

### Cross-Cutting (All Phases)

- Audit-log every agent action.
- Deploy to Azure.
- Keep human-in-the-loop validation + rollback on every write path.

## 7. Definition of Done for Next Iteration

1. Dashboard is dummy-data-free, IA renames (Execution Hub), 3 core menus + audit logs.
2. Environment is mandatory on new tickets and drives prioritization.
3. IDM environment split report generated by LLM, validated by Siva.
4. Governance agent backfills Sandbox + Non-prod environments in validated batches with working rollback.
5. At least one Contributor grant executed by an agent via API (not a CLI wrapper), demoed live.
6. Every agent action appears in audit logs.

---

