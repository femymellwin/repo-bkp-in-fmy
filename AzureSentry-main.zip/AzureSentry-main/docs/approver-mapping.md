# PIM Approver Mapping — AzureSentry (Deliverable #7)

**Spec ref:** §6.3 Production Approver Mapping Template  
**Owner:** Cloud Governance  
**Status:** Awaiting input  
**Instructions:** Fill in every `<...>` cell below. For Owner/UAA rows, both the Cloud Governance Lead and Security Lead are required (dual-approver chain per §6.2).

---

## Sandbox subscriptions (auto-approved — no approver needed)


| Subscription                        | Role | Approval                 | Notes                       |
| ----------------------------------- | ---- | ------------------------ | --------------------------- |
| *(all subs under mg-incep-sandbox)* | Any  | Auto-approved by runbook | §6.1 — no PIM approval gate |


## Production subscriptions

> **Add one row-group per production subscription. Copy the template block and fill in.**

### Prod-Sub-001: Sandbox-Sub-001


| Role        | Primary Approver                                                                  | Backup Approver                                                                                                                                                 | Escalation (Owner/UAA only) |
| ----------- | --------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------- |
| Reader      | [sivasankar.pushpavan@inceptionai.ai](mailto:sivasankar.pushpavan@inceptionai.ai) | [sivasankar.pushpavan@inceptionai.ai](mailto:sivasankar.pushpavan@inceptionai.ai) [sangeetha.baskaran@inceptionai.ai](mailto:sangeetha.baskaran@inceptionai.ai) | N/A                         |
| Contributor | [sangeetha.baskaran@inceptionai.ai](mailto:sangeetha.baskaran@inceptionai.ai)     | [sivasankar.pushpavan@inceptionai.ai](mailto:sivasankar.pushpavan@inceptionai.ai)                                                                               | N/A                         |
| Owner       | [sangeetha.baskaran@inceptionai.ai](mailto:sangeetha.baskaran@inceptionai.ai)     | [sivasankar.pushpavan@inceptionai.ai](mailto:sivasankar.pushpavan@inceptionai.ai)                                                                               | Both required (dual)        |
|             |                                                                                   |                                                                                                                                                                 |                             |





|     |
| --- |


Notes on Table:

- For testing Prod these are ids we can use 

- For now i gave your id for the approvals , post the demo , we shall update the approver mail to Sakthi for the RBAC tasks 

- Check the sandbox - if its giving the permissions by raising the ticket, report back if so and answer below?

   
  




## Notes for Cloud Governance

1. **Primary vs Backup:** Both receive the PIM notification simultaneously. If Primary doesn't act within 50% of the SLA window, PIM escalates to Backup.
2. **Dual-approver (Owner/UAA):** Denial by *either* approver terminates the request (§4.2). Both must approve.
3. **MFA:** All approvers must have MFA registered — PIM Role Settings enforce MFA-on-approval (§6.2).
4. **P2 licence:** Every person listed here must have an Entra ID P2 licence assigned.
5. **Scope:** One row-group per subscription. If a subscription isn't listed, the decision engine rejects requests for it (fail-closed, §3.2 step 2).

