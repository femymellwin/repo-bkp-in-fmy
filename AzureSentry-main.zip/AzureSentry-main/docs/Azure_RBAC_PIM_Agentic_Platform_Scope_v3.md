**AZURE RBAC & PIM**

Agentic Automation Platform

Scope of Work & Technical Specification

Version 3.0 | June 2026 | Confidential


| **Document Title**    | Azure RBAC & PIM Agentic Automation — Scope & Specification                                                                                                                        |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Version**           | 3.0 — Revised & Extended (Agentic Platform)                                                                                                                                        |
| **Prepared Date**     | June 2026                                                                                                                                                                          |
| **Status**            | Approved - Currently implementing                                                                                                                                                  |
| **Classification**    | Confidential — Internal Use Only                                                                                                                                                   |
| **Environment Scope** | Sandbox (Fully Automated) | Production (PIM Approval-Gated)                                                                                                                        |
| **Change from v2.0**  | Added: Agent Decision Framework, Automation Eligibility Matrix, Priority & Risk Tiers, Non-Functional Requirements, Agentic Architecture, Escalation Logic, Implementation Runbook |


This document supersedes v2.0. It retains all prior PIM architecture decisions and extends them with an Agentic Decision Framework governing which requests are fully automated, human-in-the-loop, or escalated — based on environment, role sensitivity, ticket priority, and risk tier.

# 1. Executive Summary

DevOps engineers currently fulfil Azure RBAC access requests manually — a ticket lands in the help desk (ManageEngine), gets assigned to an engineer, who then navigates the portal to grant access. This is slow, inconsistent, and creates audit gaps.

This document defines the scope and specification for an Agentic Automation Platform that replaces manual fulfilment with an intelligent agent pipeline. Agents evaluate every incoming RBAC ticket against a structured decision matrix — considering environment (Sandbox vs Production), role sensitivity (Reader → Owner), ticket priority (P1–P4), and business justification — and either fulfil the request autonomously, route it for human approval, or escalate it.

The platform is built on Azure Logic Apps (orchestration), Azure Automation Runbooks (PIM API execution), Azure PIM (access governance and native approval), and ManageEngine webhooks. No standing access is permitted — all assignments are time-bound via PIM.


| **Capability**   | **Description**                                                                                                                          |
| ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| Full Automation  | Sandbox requests for Reader/Contributor roles: ticket → active PIM assignment in under 60 seconds, zero human touch.                     |
| Approval-Gated   | Production Contributor/Owner requests: agent creates PIM eligible assignment; designated reviewer approves in Azure Portal or My Access. |
| Priority-Aware   | P1 (Critical) tickets in Production auto-escalate to the on-call engineer and trigger a shortened approval SLA.                          |
| Risk-Aware       | Owner-role and custom-role requests always require dual-approval regardless of environment.                                              |
| JIT & Time-Bound | No permanent assignments. PIM enforces expiry natively — no cleanup runbooks.                                                            |
| Full Audit Trail | Every agent decision, PIM event, and ticket update is logged in Log Analytics with KQL dashboards.                                       |


# 2. Problem Statement & Automation Opportunity

## 2.1 Current State — Manual Fulfilment

Today's process:

- Engineer submits an RBAC request via ManageEngine helpdesk ticket.
- Ticket is manually triaged and assigned to a DevOps engineer.
- DevOps engineer logs into the Azure Portal, navigates to IAM, grants the role.
- Ticket is manually resolved. No automatic expiry — access often persists indefinitely.
- Audit evidence is scattered across ticket history and Azure activity logs with no unified view.

Pain points: average fulfilment time of 2–4 hours for Sandbox, 1–2 days for Production; inconsistent justification capture; no automated access expiry; manual audit reconciliation.

## 2.2 Automation Opportunity Analysis

Not all request types are equal candidates for automation. The matrix below classifies every request type by automation eligibility:


| **Request Type**   | **Environment** | **Role**          | **Priority** | **Agent Action**             | **Human Touch?** | **Rationale**                                             |
| ------------------ | --------------- | ----------------- | ------------ | ---------------------------- | ---------------- | --------------------------------------------------------- |
| Standard Access    | Sandbox         | Reader            | Any          | Full Auto — Active PIM       | None             | Low risk, auto-expiry, no sensitive resources             |
| Standard Access    | Sandbox         | Contributor       | Any          | Full Auto — Active PIM       | None             | Controlled by policy; Owner blocked by Azure Policy       |
| Standard Access    | Sandbox         | Owner             | Any          | Reject — Policy Block        | None             | Owner blocked on Sandbox by Azure Policy                  |
| Standard Access    | Production      | Reader            | P3/P4        | PIM Eligible + Notify        | Single Approver  | Low sensitivity; standard approval SLA (24 hrs)           |
| Standard Access    | Production      | Reader            | P1/P2        | PIM Eligible + Escalate      | Single Approver  | Expedited SLA — approver notified immediately             |
| Standard Access    | Production      | Contributor       | P3/P4        | PIM Eligible + Notify        | Single Approver  | Standard approval SLA (24 hrs)                            |
| Standard Access    | Production      | Contributor       | P1/P2        | PIM Eligible + Escalate      | Single + On-Call | P1/P2 triggers on-call engineer notification              |
| Privileged Access  | Production      | Owner             | Any          | PIM Eligible + Dual Approval | Two Approvers    | Highest risk — always requires dual sign-off              |
| Privileged Access  | Production      | User Access Admin | Any          | PIM Eligible + Dual Approval | Two Approvers    | Grants ability to assign roles — always dual approval     |
| Emergency Access   | Production      | Contributor       | P1 only      | Auto-Approve + Alert         | Async Review     | Break-glass only; post-hoc review mandatory within 4 hrs  |
| Emergency Access   | Production      | Owner             | P1 only      | Reject — Escalate            | Incident Bridge  | No auto emergency Owner; human must convene               |
| Custom Role        | Either          | Custom            | Any          | Hold for Review              | Cloud Governance | Custom roles assessed case-by-case; outside runbook scope |
| Bulk Request       | Either          | Any               | Any          | Hold for Review              | Cloud Governance | Bulk (5 users same role) flagged for review               |
| Cross-Subscription | Production      | Any               | Any          | PIM Eligible + Notify        | Senior Approver  | Scope spans subscriptions — senior approver required      |


Emergency Access (break-glass) auto-approval applies only to P1 Contributor requests on pre-approved production subscriptions. All emergency grants trigger an immediate security alert and mandatory async review. Owner-level emergency requests are always rejected by the agent and routed to an incident bridge.

# 3. Agentic Platform Architecture

## 3.1 Architecture Overview

The platform comprises four logical layers that operate in sequence for every incoming ticket:


| **Layer**           | **Component**                  | **Responsibility**                                                                           |
| ------------------- | ------------------------------ | -------------------------------------------------------------------------------------------- |
| 1 — Intake          | ManageEngine Webhook           | Triggers on ticket creation; delivers structured payload to the Orchestrator.                |
| 2 — Orchestrate     | Azure Logic App (Orchestrator) | Receives payload, validates schema, classifies request, invokes the correct Agent path.      |
| 3 — Agent Execution | Azure Automation Runbooks      | Executes the PIM API calls, validates guardrails, updates ticket status.                     |
| 4 — Governance      | Azure PIM (Entra ID)           | Enforces approval workflow, manages assignment lifecycle, auto-expires access.               |
| 5 — Observability   | Log Analytics + KQL Workbook   | Records every agent decision, PIM event, and ticket state change for audit and dashboarding. |


## 3.2 Agent Decision Flow

The Orchestrator implements a deterministic decision tree — there is no ambiguity in how a ticket is classified. The tree evaluates five attributes in strict order:


| **Step** | **Attribute Evaluated**         | **Branch Logic**                                                                                                                                             |
| -------- | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1        | Ticket Schema Validation        | Missing required fields (Role, Environment, Subscription ID, Duration, Justification for Prod) → reject immediately; update ticket with missing-field error. |
| 2        | Subscription Allowlist Check    | Subscription ID not on approved allowlist → reject; notify Cloud Governance.                                                                                 |
| 3        | Role Eligibility Check          | Owner/UAA on Sandbox → reject (Azure Policy block). Custom role → hold for Cloud Governance review.                                                          |
| 4        | Environment Classification      | Sandbox → route to Sandbox Agent (Full Auto). Production → proceed to step 5.                                                                                |
| 5        | Priority Classification         | P1/P2 + Prod → Expedited path (immediate approver notification + on-call alert). P3/P4 + Prod → Standard approval path.                                      |
| 6        | Role Sensitivity Classification | Reader/Contributor → Single approver. Owner/UAA → Dual approver. Break-glass P1 Contributor → Emergency auto-approve + security alert.                       |
| 7        | Duplicate / Conflict Check      | Active assignment already exists for same user/role/scope → reject with existing-assignment notice.                                                          |


The decision tree is implemented as a Logic App condition chain, not AI inference. Every decision is deterministic, auditable, and reproducible. No LLM or probabilistic model is involved in access control decisions.

## 3.3 Approval SLA Tiers

PIM approval expiry and escalation notifications differ by priority tier:


| **Priority** | **Ticket Type**            | **Approval Window** | **Escalation at** | **Approval Mode**                     | **Example**                              |
| ------------ | -------------------------- | ------------------- | ----------------- | ------------------------------------- | ---------------------------------------- |
| P1           | Critical Incident / Outage | 4 hours             | 2 hours           | Expedited — on-call alerted           | Prod DB down; engineer needs Contributor |
| P2           | High Impact Business       | 8 hours             | 4 hours           | Expedited — primary + backup notified | Release blocker requiring access         |
| P3           | Standard Request           | 24 hours            | 20 hours          | Standard — primary approver notified  | Routine project access grant             |
| P4           | Low Priority / Planned     | 48 hours            | 36 hours          | Standard — approver notified          | Planned access for upcoming sprint       |


# 4. Sandbox Agent — Full Automation

## 4.1 Behaviour

The Sandbox Agent handles all Reader and Contributor requests against Sandbox subscriptions. The entire lifecycle — from ticket receipt to active access — completes with zero human intervention in under 60 seconds.


| **Step** | **Action**                   | **Detail**                                                                                                           |
| -------- | ---------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| 1        | Receive Webhook              | Logic App receives ManageEngine ticket creation event.                                                               |
| 2        | Validate Schema              | Verify all required fields present; reject with error note if not.                                                   |
| 3        | Check Subscription Allowlist | Subscription ID must be on the Sandbox allowlist.                                                                    |
| 4        | Enforce Role Cap             | Owner and User Access Administrator roles are blocked by Azure Policy — runbook rejects before API call.             |
| 5        | Check for Duplicate          | Query Graph API for existing active PIM assignments (same user, role, scope). Reject if active assignment exists.    |
| 6        | Validate Duration            | Duration must not exceed 90-day maximum. Reject if exceeded.                                                         |
| 7        | Resolve UPN to Object ID     | Graph API lookup of requester UPN to Entra Object ID.                                                                |
| 8        | Create Active PIM Assignment | POST to /roleAssignmentScheduleRequests: assignmentType=Activated, scheduleInfo.expiration.endDateTime=now+duration. |
| 9        | Capture Assignment ID        | Store PIM assignment ID from response.                                                                               |
| 10       | Update Ticket                | Resolve ManageEngine ticket with: assignment ID, role, scope, expiry timestamp, PIM confirmation link.               |


PIM enforces the end date natively. No cleanup runbook is required. When the assignment expires, Azure PIM removes the role automatically and logs the expiry event to Entra ID audit logs.

## 4.2 Sandbox Guardrails


| **Guardrail**          | **Implementation**                                                     | **Enforced By**          |
| ---------------------- | ---------------------------------------------------------------------- | ------------------------ |
| Owner role blocked     | Runbook rejects before API call; Azure Policy blocks at resource plane | Runbook + Azure Policy   |
| Duration cap (90 days) | Runbook validates duration field before PIM call                       | Runbook                  |
| Duplicate prevention   | Graph API query for active assignments before create                   | Runbook                  |
| Subscription allowlist | Hardcoded allowlist in Runbook; mismatch = reject                      | Runbook                  |
| Managed Identity only  | No stored credentials; system-assigned MI with minimum Graph scope     | Azure Automation         |
| Expiry enforcement     | PIM end date set at creation; no permanent assignments allowed         | Azure PIM + Azure Policy |


# 5. Production Agent — Approval-Gated

## 5.1 Standard Approval Flow (P3/P4)


| **Step** | **Action**                       | **Detail**                                                                                                          |
| -------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| 1        | Receive Webhook                  | Logic App receives ticket; validates schema and subscription allowlist.                                             |
| 2        | Classify Role Sensitivity        | Reader/Contributor → Single Approver path. Owner/UAA → Dual Approver path.                                          |
| 3        | Validate Justification           | Business justification must be present and minimum 20 characters; reject if missing.                                |
| 4        | Resolve UPN to Object ID         | Graph API lookup of requester Entra Object ID.                                                                      |
| 5        | Create Eligible PIM Assignment   | POST to /roleEligibilityScheduleRequests: requestType=AdminAssign, approvalRequired=true.                           |
| 6        | Update Ticket — Pending Approval | Update ManageEngine ticket to 'Pending Approval' status with PIM request ID and approver name.                      |
| 7        | PIM Notifies Approver            | PIM sends email to designated approver with deep link to My Access portal.                                          |
| 8        | Approver Acts in PIM             | Approver approves or denies in Azure Portal / My Access / Authenticator app. MFA required.                          |
| 9        | Logic App Polls PIM              | Logic App polls PIM for decision update (or receives event via Event Grid if configured).                           |
| 10       | Ticket Final Update              | Approved: ticket resolved with assignment details. Denied: ticket updated with denial reason and reviewer identity. |
| 11       | PIM Auto-Expiry                  | Role automatically removed at end of assignment window. Log entry created.                                          |


## 5.2 Expedited Approval Flow (P1/P2)

For P1/P2 production tickets, the agent modifies the standard flow with the following additional actions:

- Approval SLA is shortened to 4 hours (P1) or 8 hours (P2) instead of 24 hours.
- Both primary and backup approvers are notified simultaneously at ticket creation.
- For P1 tickets: the on-call DevOps engineer receives a separate alert via the configured notification channel (Teams/PagerDuty/email).
- Escalation at 50% of SLA window: if no approver action, a reminder notification is sent.
- Expiry at SLA end: if still no action, the PIM request is cancelled; ticket updated to 'Expired — Please Re-submit'.

## 5.3 Dual Approval Flow (Owner / UAA)

Owner and User Access Administrator role requests always require two independent approvals regardless of priority:

- Primary approver (per subscription Approver Mapping) must approve first.
- Secondary approver (Cloud Governance Lead or Security Lead) must subsequently approve.
- Cloud Security team receives notification at request creation and at each approval step.
- PIM is configured with dual-approver chain in Role Settings for Owner and UAA roles.
- Denial by either approver terminates the request immediately.

## 5.4 Emergency Break-Glass Flow (P1 Contributor Only)

Break-glass auto-approval is a last-resort mechanism for critical production incidents. It is strictly limited to P1 tickets for Contributor role on pre-approved production subscriptions. Owner-level emergency requests are never auto-approved.

- Agent detects: Environment=Production, Role=Contributor, Priority=P1, Justification contains approved break-glass code or on-call manager has pre-authorised in the ticket.
- Agent creates Active (not Eligible) PIM assignment immediately — bypassing the standard approval gate.
- Simultaneous actions: alert to Cloud Security team, alert to on-call manager, flag ticket as Break-Glass.
- Mandatory post-hoc async review within 4 hours by Cloud Governance — documented in the ticket.
- Failure to complete async review within 4 hours triggers automatic revocation of the break-glass grant.

# 6. Azure PIM Configuration

## 6.1 Sandbox Role Settings


| **PIM Setting**                    | **Configuration**                                                                      |
| ---------------------------------- | -------------------------------------------------------------------------------------- |
| Assignment type allowed            | Active only                                                                            |
| Maximum active assignment duration | 90 days — enforced by PIM; requests for longer are rejected by Runbook before API call |
| Permanent active assignment        | Not allowed — Azure Policy blocks and PIM Role Settings enforce                        |
| Require approval                   | No — Sandbox assignments are auto-approved via Runbook                                 |
| Require justification              | No (Sandbox only)                                                                      |
| Require MFA                        | Not applicable (Active assignment — no activation step)                                |
| Notifications                      | Requester notified on assignment; Subscription Owner notified if role is Contributor   |


## 6.2 Production Role Settings


| **PIM Setting**                      | **Configuration**                                                                     |
| ------------------------------------ | ------------------------------------------------------------------------------------- |
| Assignment type allowed              | Eligible (pending approval path)                                                      |
| Maximum eligible assignment duration | 90 days                                                                               |
| Permanent eligible assignment        | Not allowed                                                                           |
| Require approval                     | Yes — designated approver per role per subscription                                   |
| Require justification                | Yes — minimum 20 characters; enforced in PIM Role Settings and Runbook pre-validation |
| Require MFA on approval              | Yes — approver must complete MFA before approving                                     |
| Approvers — Reader/Contributor       | Primary + Backup per subscription (see Section 6.3)                                   |
| Approvers — Owner/UAA                | Primary + Cloud Governance Lead + Security Lead (dual-approver chain)                 |
| Approval expiry (P3/P4)              | 24 hours — request cancelled; requester must re-submit                                |
| Approval expiry (P1)                 | 4 hours — with escalation at 2 hours                                                  |
| Approval expiry (P2)                 | 8 hours — with escalation at 4 hours                                                  |
| Notifications                        | Approver on new request; requester on decision; Security team on Owner/UAA requests   |


## 6.3 Production Approver Mapping Template

Complete before go-live. Values to be provided by the Cloud Governance team.


| **Subscription** | **Role**    | **Primary Approver**  | **Secondary / Backup Approver** | **Escalation (Owner/UAA)** |
| ---------------- | ----------- | --------------------- | ------------------------------- | -------------------------- |
| Sandbox-Sub-001  | Any         | Auto-approved         | N/A                             | N/A                        |
| Prod-Sub-001     | Reader      | Reviewer Email        | Backup Email                    | N/A                        |
| Prod-Sub-001     | Contributor | Reviewer Email        | Backup Email                    | N/A                        |
| Prod-Sub-001     | Owner       | Cloud Governance Lead | Security Lead                   | Both required (dual)       |
| Prod-Sub-002     | Reader      | Reviewer Email        | Backup Email                    | N/A                        |
| Prod-Sub-002     | Contributor | Reviewer Email        | Backup Email                    | N/A                        |
| Prod-Sub-002     | Owner       | Cloud Governance Lead | Security Lead                   | Both required (dual)       |
| Prod-Sub-00N     | ...         | ...                   | ...                             | ...                        |


# 7. ManageEngine Ticket Template — RBAC Request

A dedicated request template must be configured in ManageEngine ServiceDesk Plus with the following fields. The webhook payload must include all required fields; missing fields result in agent rejection with a descriptive error note on the ticket.


| **Field Name**         | **Type**    | **Allowed Values**                        | **Required** | **Used In**  | **Agent Validation**                             |
| ---------------------- | ----------- | ----------------------------------------- | ------------ | ------------ | ------------------------------------------------ |
| Azure Role             | Dropdown    | Reader, Contributor, Owner, UAA, Custom   | Yes          | Both         | Custom → hold; Owner/UAA Sandbox → reject        |
| Environment            | Dropdown    | Sandbox, Production                       | Yes          | Both         | Routes to correct agent path                     |
| Subscription ID        | Text        | Azure Subscription GUID                   | Yes          | Both         | Validated against allowlist                      |
| Resource Scope         | Text        | /resourceGroups/name or /subscriptions/id | Yes          | Both         | Format validated                                 |
| Access Duration (days) | Number      | 1 – 90                                    | Yes          | Both         | Exceeds 90 → reject                              |
| Business Justification | Text Area   | Free text — min 20 chars                  | Prod only    | Production   | 20 chars → reject                                |
| Priority               | Dropdown    | P1, P2, P3, P4                            | Yes          | Both         | Drives SLA tier and escalation path              |
| Break-Glass Request    | Checkbox    | Yes / No                                  | No           | Prod P1 only | Triggers break-glass flow if P1+Contributor+Prod |
| Requester UPN          | Text (auto) | Azure AD UPN                              | Yes          | Both         | Resolved to Entra Object ID                      |


# 8. Component Specification

## 8.1 Azure Logic App — Orchestrator


| **Attribute**      | **Specification**                                                                                  |
| ------------------ | -------------------------------------------------------------------------------------------------- |
| Trigger            | HTTP Request (webhook from ManageEngine on ticket creation)                                        |
| Authentication     | Logic App endpoint protected by SAS key; ManageEngine webhook configured with key header           |
| Routing Logic      | Condition chain implementing the 7-step decision tree (Section 3.2)                                |
| Runbook Invocation | HTTP action to Azure Automation Runbook webhook or Azure Automation Job (async)                    |
| PIM Event Polling  | Recurrence trigger (every 5 min) polling PIM for pending prod requests; or Event Grid if available |
| Ticket Update      | HTTP action to ManageEngine REST API (REST ticket update endpoint)                                 |
| Error Handling     | Scope actions with catch blocks; failed runs trigger alert to Cloud Governance channel             |
| Concurrency        | Concurrency limit set to prevent parallel conflicting assignments for the same user/role/scope     |
| Deployment         | ARM template or Bicep; parameterised for subscription IDs and API endpoints                        |


## 8.2 Azure Automation Runbooks


| **Runbook**            | **Language**   | **Purpose**                                                        | **Key API Calls**                                           |
| ---------------------- | -------------- | ------------------------------------------------------------------ | ----------------------------------------------------------- |
| Runbook-Sandbox-PIM    | PowerShell 7.2 | Create Active PIM assignment for Sandbox requests                  | GET /users, PUT /roleAssignmentScheduleRequests             |
| Runbook-Prod-PIM       | PowerShell 7.2 | Create Eligible PIM assignment (pending approval) for Production   | GET /users, POST /roleEligibilityScheduleRequests           |
| Runbook-Emergency-PIM  | PowerShell 7.2 | Create Active PIM assignment for P1 break-glass (Contributor only) | PUT /roleAssignmentScheduleRequests + alert actions         |
| Runbook-Status-Updater | PowerShell 7.2 | Poll PIM for approval decisions and update ManageEngine ticket     | GET /roleEligibilityScheduleRequests/id, PATCH ManageEngine |


## 8.3 Managed Identity Permissions


| **Permission**                            | **Scope**            | **Reason**                                               |
| ----------------------------------------- | -------------------- | -------------------------------------------------------- |
| PrivilegedAccess.ReadWrite.AzureResources | Microsoft Graph      | Create and read PIM assignments                          |
| User.Read.All                             | Microsoft Graph      | Resolve requester UPN to Entra Object ID                 |
| Reader                                    | Target subscriptions | Validate subscription existence and existing assignments |


# 9. Security & Compliance Controls


| **Control**                       | **Implementation**                                                                                    | **Enforced By**          |
| --------------------------------- | ----------------------------------------------------------------------------------------------------- | ------------------------ |
| Managed Identity                  | Automation Account uses system-assigned MI — no stored secrets or credentials                         | Azure Automation         |
| JIT Access                        | All PIM assignments are time-bound; permanent assignments blocked                                     | Azure PIM + Azure Policy |
| Approval Integrity                | Production role activation only occurs after PIM records an approved decision — Runbook cannot bypass | Azure PIM                |
| MFA on Approval                   | PIM Role Settings require MFA for all production approval actions                                     | Azure PIM                |
| Dual Approval — Owner/UAA         | Two independent approvers required; denial by either terminates request                               | Azure PIM Role Settings  |
| Owner Role Cap (Sandbox)          | Azure Policy DenyAction blocks Owner/UAA from Sandbox subscriptions                                   | Azure Policy             |
| Production Subscription Allowlist | Production Runbook validates Subscription ID before any PIM call; unrecognised IDs are rejected       | Runbook                  |
| Break-Glass Controls              | Auto-grant limited to Contributor; Owner break-glass always rejected; mandatory 4-hr async review     | Runbook + Logic App      |
| Duplicate Prevention              | Runbook checks for active assignment before creating new — no role stacking                           | Runbook                  |
| Immutable Audit Trail             | All PIM events forwarded to Log Analytics; Entra ID audit logs retained per policy                    | Azure Monitor            |
| Ticket Justification Gate         | Production requests missing justification rejected before PIM API call                                | Runbook pre-validation   |
| Webhook Authentication            | ManageEngine webhook uses Logic App SAS key; Logic App validates key on receipt                       | Logic App                |


# 10. Non-Functional Requirements


| **Category**    | **Requirement**                                 | **Target**                                                                                                     |
| --------------- | ----------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| Performance     | Sandbox ticket-to-access latency                | 60 seconds end-to-end                                                                                          |
| Performance     | Production ticket-to-PIM-pending latency        | 2 minutes                                                                                                      |
| Performance     | Logic App PIM polling interval                  | Every 5 minutes (configurable)                                                                                 |
| Availability    | Logic App uptime                                | = 99.5% (Azure SLA)                                                                                            |
| Availability    | Automation Account uptime                       | = 99.9% (Azure SLA)                                                                                            |
| Reliability     | Failed agent run recovery                       | Logic App retry policy (3 retries, exponential backoff); failed run alerts sent to Cloud Governance            |
| Scalability     | Concurrent ticket handling                      | Logic App concurrency limit set to prevent conflicting assignments; Automation Account job queue handles burst |
| Auditability    | Retention of Log Analytics data                 | Minimum 90 days online; 1 year archive per policy                                                              |
| Auditability    | Every agent decision logged                     | Logic App run history + custom Log Analytics events for each decision step                                     |
| Security        | No credentials stored in Runbooks or Logic Apps | Managed Identity only; Key Vault for any external API tokens                                                   |
| Maintainability | Runbook unit test coverage                      | End-to-end test suite (sandbox auto, prod approval, prod denial, expiry, duplicate, break-glass)               |
| Compliance      | PIM policy peer review                          | Role Settings reviewed and approved by Cloud Governance before any production enablement                       |


# 11. Deliverables


| **#** | **Deliverable**            | **Description**                                                                                                      | **Format**               |
| ----- | -------------------------- | -------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| 1     | Logic App — Orchestrator   | HTTP trigger, 7-step decision tree, environment routing, PIM event polling, ticket update actions                    | Bicep / ARM              |
| 2     | Runbook — Sandbox PIM      | PowerShell: Active PIM assignment via Graph, input validation, duplicate check, ticket update                        | Azure Automation Runbook |
| 3     | Runbook — Production PIM   | PowerShell: Eligible PIM assignment pending approval, allowlist validation, ticket update                            | Azure Automation Runbook |
| 4     | Runbook — Emergency PIM    | PowerShell: Break-glass Active assignment, security alert, async review flag                                         | Azure Automation Runbook |
| 5     | Runbook — Status Updater   | PowerShell: Poll PIM for approval decisions, update ManageEngine ticket on decision                                  | Azure Automation Runbook |
| 6     | PIM Role Settings Config   | Role settings definitions per role per subscription — approval, duration, MFA, notifications, dual-approver          | ARM / JSON               |
| 7     | PIM Approver Mapping       | Completed approver mapping per role per subscription                                                                 | Documentation + ARM      |
| 8     | Azure Policy Definitions   | Duration enforcement, permanent assignment block, Owner/UAA Sandbox block                                            | ARM / JSON               |
| 9     | ManageEngine Configuration | Webhook setup guide, custom ticket template fields, API token scope documentation                                    | Documentation            |
| 10    | Log Analytics KQL Workbook | Access audit, approval SLA compliance, expiry tracking, break-glass report, agent decision log                       | KQL Workbook             |
| 11    | End-to-End Test Suite      | PowerShell test scripts: sandbox auto, prod approval, prod denial, expiry, duplicate, break-glass, schema validation | PowerShell               |
| 12    | Reviewer Training Guide    | How to approve/deny in Azure Portal, My Access, and Authenticator app; SLA expectations                              | Word / PDF               |
| 13    | This Document              | Full scope, architecture, agent decision framework, PIM config reference, implementation guide                       | Word / PDF               |


# 12. Assumptions & Dependencies

## 12.1 Assumptions

- Azure AD P2 (Entra ID P2) licensing is in place for all users who will request or approve RBAC access.
- ManageEngine ServiceDesk Plus supports outbound webhooks on ticket creation with a configurable payload schema.
- Azure subscriptions are clearly labelled and segmented into Sandbox and Production with distinct Subscription IDs.
- An Azure Automation Account exists or will be provisioned with system-assigned Managed Identity enabled.
- Designated approvers have Azure AD accounts and access to the Azure Portal or My Access portal.
- Requester accounts exist in Azure AD (Entra ID) as user principals with valid UPNs.
- PIM is not currently managing the target roles — initial PIM policy configuration is part of this engagement.
- A break-glass authorisation process (e.g., on-call manager pre-approval via ticket field) is defined before emergency flow is enabled.

## 12.2 Dependencies


| **Dependency**                         | **Owner**                   | **Action Required**                                                              |
| -------------------------------------- | --------------------------- | -------------------------------------------------------------------------------- |
| Entra ID P2 Licensing                  | IT / Procurement            | Confirm P2 licences assigned to all requesters and approvers before build begins |
| ManageEngine API Token                 | IT Operations               | Generate token with request read/write scope; store in Key Vault                 |
| Azure Automation Account               | Cloud Team                  | Provision with Managed Identity; grant Graph permissions                         |
| PIM Approver Mapping Table             | Cloud Governance            | Complete per subscription per role before Phase 2                                |
| PIM Role Settings Sign-off             | Cloud Governance            | Review and approve settings (approval, duration, MFA) per role                   |
| Production Subscription Allowlist      | Cloud Governance            | Provide definitive list of production Subscription IDs                           |
| Azure Policy Deployment                | Cloud Governance            | Approve and deploy duration-enforcement and role-block policies                  |
| Log Analytics Workspace                | Cloud Team                  | Confirm workspace ID, diagnostic settings, and retention policy                  |
| Break-Glass Authorisation Process      | Cloud Governance + Security | Define and document the pre-approval process for emergency access                |
| Notification Channel for P1 Escalation | IT Operations               | Confirm PagerDuty / Teams / email channel for on-call alerts                     |


# 13. Implementation Milestones


| **Phase**            | **Milestone**                                                                                  | **Duration** | **Owner**               | **Exit Criteria**                                           |
| -------------------- | ---------------------------------------------------------------------------------------------- | ------------ | ----------------------- | ----------------------------------------------------------- |
| 1 — Design           | Finalise scope, approver mapping, allowlist, break-glass process, ticket template fields       | Week 1       | Project Lead            | Scope doc signed off; approver mapping complete             |
| 2 — PIM Config       | Configure PIM Role Settings per role per subscription; assign approvers; validate P2 licensing | Week 2       | Cloud Governance        | PIM policies active in non-prod; P2 licences confirmed      |
| 3 — Build Core       | Develop Logic App orchestrator, Sandbox Runbook, Production Runbook, Azure Policy              | Weeks 3–4    | Cloud Engineer          | Sandbox auto-assign working end-to-end in dev environment   |
| 4 — Build Extended   | Emergency Runbook, Status Updater Runbook, KQL workbook, ManageEngine webhook                  | Week 5       | Cloud Engineer + IT Ops | All runbooks deployed; webhook connected to Logic App       |
| 5 — Integration Test | End-to-end test suite: sandbox, prod approval, prod denial, expiry, duplicate, break-glass     | Week 6       | Cloud Engineer          | All test cases pass; zero P1 defects outstanding            |
| 6 — UAT              | Stakeholder acceptance testing across all request types and priority tiers                     | Week 7       | Stakeholders            | UAT sign-off from Cloud Governance, IT Ops, Security        |
| 7 — Prod Go-Live     | Enable production PIM approval flow; monitor first 20 tickets with Cloud Governance on standby | Week 8       | Cloud Governance        | 20 production tickets processed without manual intervention |
| 8 — Handover         | KQL dashboards live; reviewer training session; runbook documentation; operational runbook     | Week 9       | Cloud Engineer          | Training completed; dashboards validated; doc delivered     |


# 14. Risks & Mitigations


| **Risk**                                                        | **Impact** | **Likelihood** | **Mitigation**                                                                                                    |
| --------------------------------------------------------------- | ---------- | -------------- | ----------------------------------------------------------------------------------------------------------------- |
| Entra ID P2 licences not in place                               | High       | Medium         | Confirm licensing in Week 1 before build begins. PIM cannot function without P2.                                  |
| PIM Role Settings misconfigured — approval not required in Prod | High       | Low            | Role Settings validated in non-prod; peer-reviewed by Cloud Governance before prod enablement.                    |
| Break-glass flow misused or bypassed                            | High       | Low            | Strict code-based authorisation; async review enforced; Security team alerted on every break-glass event.         |
| Approver does not action within SLA window                      | Medium     | Medium         | Escalation at 50% SLA; backup approver notified simultaneously on P1/P2; PIM re-notifies at 12hrs (P3/P4).        |
| Managed Identity lacks Graph API permissions                    | High       | Low            | Permissions pre-tested in Sandbox before Production cutover; minimum-scope principle.                             |
| PIM Graph API changes breaking Runbooks                         | Medium     | Low            | Pin Microsoft Graph SDK version; monitor Azure updates; quarterly review cadence.                                 |
| Existing permanent RBAC assignments conflict with PIM           | Medium     | Medium         | Audit of existing assignments completed before go-live; migration plan agreed separately.                         |
| Duplicate requests creating conflicting assignments             | Low        | Medium         | Sandbox Runbook duplicate check; PIM deduplicates by user/role/scope natively for Production.                     |
| ManageEngine webhook payload schema changes                     | Medium     | Low            | Schema validation in Logic App; breaking change alert to Cloud Governance.                                        |
| On-call engineer not available for P1 Prod escalation           | High       | Low            | Documented on-call rota integrated with notification channel; secondary escalation path to Cloud Governance Lead. |


# 15. Scope Boundaries

## 15.1 In Scope


| **In Scope Item**                                                   | **Notes**                                             |
| ------------------------------------------------------------------- | ----------------------------------------------------- |
| ManageEngine webhook configuration and RBAC request ticket template | Including all custom fields and priority mapping      |
| Azure Logic App — orchestrator with 7-step decision tree            | Full condition chain, error handling, retry policy    |
| Sandbox Agent Runbook — Active PIM auto-assignment                  | Reader and Contributor roles only                     |
| Production Agent Runbook — Eligible PIM approval-gated assignment   | All production roles                                  |
| Emergency Break-Glass Runbook — Active PIM (P1 Contributor only)    | Security alerts and async review flag included        |
| Status Updater Runbook — PIM polling and ticket update              |                                                       |
| PIM Role Settings configuration per role per subscription           | Approval, duration, MFA, notifications, dual-approver |
| PIM Approver Mapping                                                | Reviewer designation per role per subscription        |
| Azure Policy — duration enforcement and role-block on Sandbox       |                                                       |
| Log Analytics KQL Workbook — access audit and SLA dashboards        |                                                       |
| End-to-end test suite                                               | All request types, priority tiers, error paths        |
| Reviewer training guide                                             | Portal, My Access, Authenticator approval paths       |


## 15.2 Out of Scope


| **Out of Scope Item**                                   | **Reason / Future Phase**                                             |
| ------------------------------------------------------- | --------------------------------------------------------------------- |
| Self-service eligible role activation by end users      | Users do not self-activate; access is provisioned by agents or denied |
| Custom approval portal or self-service UI               | Azure Portal / My Access used natively                                |
| Non-Azure platforms (AWS, GCP)                          | Separate engagement                                                   |
| Migration of existing permanent RBAC assignments to PIM | Separate workstream; documented as dependency                         |
| Entra ID / Azure AD group-based PIM                     | Individual user assignments only in this phase                        |
| PIM for Entra ID directory roles                        | Azure resource roles only                                             |
| AI/ML-based approval recommendation engine              | Deterministic decision tree only in this phase                        |
| Automated access recertification campaigns              | Future phase                                                          |
| Integration with SIEM beyond Log Analytics              | Future phase                                                          |


# 16. Approval & Sign-Off

The following stakeholders are required to review and approve this scope document before implementation begins:


| **Name** | **Role**                   | **Date** | **Signature / Approval** |
| -------- | -------------------------- | -------- | ------------------------ |
|          | Cloud Governance Lead      |          |                          |
|          | IT Operations Manager      |          |                          |
|          | Security & Compliance Lead |          |                          |
|          | Entra ID / Identity Owner  |          |                          |
|          | DevOps Engineering Lead    |          |                          |
|          | Project Sponsor            |          |                          |


v3.0 — Agentic Platform scope. All implementation details subject to revision following technical review, Entra ID P2 licence confirmation, and stakeholder sign-off. Break-glass flow requires explicit Security & Compliance Lead approval before enablement.