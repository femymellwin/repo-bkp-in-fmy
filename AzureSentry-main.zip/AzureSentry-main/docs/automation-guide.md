# Using the Unattended Poller/Reaper — Local vs. VM

## What they do

- **Unattended ticket poller** — every cycle, fetches open ManageEngine tickets, decides
  each via the same RBAC decision engine the human dashboard path uses, and for the narrow
  slice that clears every gate (right template, complete fields, `Grant` decision,
  Sandbox/NonProd only, promotion ladder), grants it with no human click.
- **Grant expiry reaper** — every cycle, scans what's been granted and revokes anything
  whose recorded expiry has passed. This matters because group-based grants (the poller's
  normal fulfilment path) have **no Azure-enforced expiry at all** — the reaper is the only
  thing that ever takes that access back.

Both ship inert by default, and both run as a single-shot entry script
(`scripts/Invoke-TicketPollerCycle.ps1` / `scripts/Invoke-ReaperCycle.ps1`) that does exactly
one cycle and exits — there is no long-running poller process.

## The three things that all have to be true for either to run automatically

1. **Something has to trigger a cycle on a schedule** — a timer. Nothing runs "by itself"
   otherwise.
2. **The kill switch has to be on** — otherwise every triggered cycle halts immediately and
   does nothing.
3. **Mode has to be `enforce`** — otherwise a triggered, enabled cycle only decides and
   records (`shadow`); it never writes anything real.

Layers 2 and 3 are unified in the dashboard into one control per agent — **Automation:
Off / Rehearse / Live**. Layer 1, the scheduler, is separate on each environment and is
covered below.

## What each Automation state actually does

| State | Sets | Effect |
|---|---|---|
| **Off** | `enabled = false` | The cycle halts immediately on its very first check. Nothing is fetched, decided, or written. |
| **Rehearse** | `enabled = true`, `mode = shadow` | A cycle runs and makes real decisions against real tickets, but never writes anything: no Azure grant/revoke, no ME note, no ticket resolved. A ticket the poller would have granted shows up as `wouldGrant` instead of `granted` (the reaper: `wouldRevoke` instead of `revoked`) — you see the full decision trace with zero risk. `granted`/`revoked` staying `0` here is the whole point; if either is ever nonzero in Rehearse, that's a bug, not a configuration state. |
| **Live** | `enabled = true`, `mode = enforce` | The cycle performs real Azure writes and real ManageEngine note/resolve actions for anything that clears every gate. Requires a ≥4-character justification to switch to. |

**Recommended order, always:** Off → Rehearse (watch a few real cycles, confirm the
decisions look right) → Live. Nothing written in Rehearse means nothing to undo if a
decision looks wrong.

## Local machine

**No scheduler exists locally.** Nothing re-invokes the entry scripts on its own —
"automatic" here only ever means "the next time you (or something you set up) runs the
script."

Run one cycle by hand:
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Invoke-TicketPollerCycle.ps1 -VerboseOutput
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Invoke-ReaperCycle.ps1 -VerboseOutput
```

These read `.env` for `AZURESENTRY_POLLER_ENABLED`/`_MODE` (and the reaper equivalents),
**but check the dashboard's override files first** if the local dashboard is running
(`dashboard/api/poller.enabled`, `poller.mode`, `reaper.enabled`, `reaper.mode`) — so if
you've set Rehearse/Live in the dashboard UI, that's what the script actually does on its
next run, not what's sitting in `.env`.

To make this feel "automatic" locally, you'd need to add your own scheduling — e.g.
Windows Task Scheduler running one of the commands above every few minutes. Nothing built
into the project does this for you on a workstation.

## VM (the real production path)

**One-time infra step, done once ever per VM:**
```bash
sudo bash /opt/azuresentry/infra/systemd/install-poller-timer.sh
sudo bash /opt/azuresentry/infra/systemd/install-reaper-timer.sh
```
This installs and starts `azuresentry-poller.timer` (fires every 5 minutes) and
`azuresentry-reaper.timer` (every 30 minutes). Installing does **not** enable anything —
both stay inert until the next step.

**Turning it on — two equivalent ways:**

- **From the dashboard** (no SSH needed): open the VM's dashboard → Poller panel →
  **Automation** control → **Live** (type a justification, confirm). Same for the Reaper
  panel.
- **From the VM directly**, editing `/etc/azuresentry.env`:
  ```
  AZURESENTRY_POLLER_ENABLED=true
  AZURESENTRY_POLLER_MODE=enforce
  AZURESENTRY_REAPER_ENABLED=true
  AZURESENTRY_REAPER_MODE=enforce
  ```
  No restart needed — the timer starts a fresh process every cycle, which reads the file
  fresh each time.

Set both poller and reaper up together — enforcing grants while the reaper stays off means
access happens for real but nothing ever expires it back.

## Checking the real current state

Three independent facts, each worth checking separately — they can disagree for up to one
scheduling interval after you change something:

```bash
systemctl list-timers azuresentry-poller.timer azuresentry-reaper.timer --no-pager   # is a scheduler even running?
grep AZURESENTRY_{POLLER,REAPER}_ENABLED /etc/azuresentry.env                         # env-var fallback state
```

The dashboard panel itself shows two distinct facts, never merged: the **override** (the
instruction you just set) and the **last reported cycle** (what actually happened most
recently). If they disagree, wait for the next cycle and refresh.

## Further reading

- [`ticket-poller-runbook.md`](ticket-poller-runbook.md) — full operational detail,
  troubleshooting, per-cycle limits, duplicate-grant prevention.
- [`poller-eligibility-matrix.md`](poller-eligibility-matrix.md) — exactly which
  role/environment/priority combinations are auto-grantable.
- [`Hand-Over.md`](Hand-Over.md) — overall platform architecture and component map.
