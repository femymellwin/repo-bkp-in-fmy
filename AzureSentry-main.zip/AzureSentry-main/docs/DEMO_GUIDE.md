# AzureSentry — Live Demonstration Guide

> **Audience:** DevOps / Cloud Governance stakeholders
> **Goal:** Show the platform *actually automating* an Azure RBAC access request — a real
> **ManageEngine ticket raised by a requester** flows through the policy decision engine into
> a **real, time-bound PIM grant on a real subscription**, with the ticket annotated and
> resolved automatically. This replaces manual ticket-triage + manual portal-clicking.
> **Duration:** ~10–12 minutes
> **Runs locally:** dashboard on your machine, granting as the automation SPN.

---

> **Testing the automation instead of presenting it?** Skip to
> [§8 — User test: the unattended automation](#8-user-test--the-unattended-automation-raise-a-ticket-touch-nothing).
> Sections 0–7 are the attended demo, where an operator clicks *Provide Access*.

## 0. The scenario

A colleague (the **requester** — *not* the presenter) raises an access-request ticket in
**ManageEngine ServiceDesk Plus**, exactly like ticket **#2858**:

> *Subscription id: `<sub>` · Username: `<requester>` · Role: `Contributor` · Environment: `Sandbox`*

From there, **AzureSentry does everything**: sees the ticket, decides by policy, performs the
real PIM grant as the automation service principal, writes a note back onto the ticket, and
(optionally) resolves it — all auditable, all time-bound.

### What is real vs. prototype (say this up front — it builds trust)

| Capability | Status |
|------------|--------|
| ManageEngine ticket intake (live) | **Real** — tickets fetched live from ServiceDesk Plus |
| 7-step decision engine | **Real** — the actual `Resolve-RbacDecision` module (62/62 tests) |
| **Real PIM grant** (Sandbox = active; Production = eligible) | **Real** — ARM PIM via the automation SPN `e2455957` |
| Note posted back to the ticket | **Real** — decision audit trail written to ManageEngine |
| Ticket resolution + durable "Processed" state | **Real** |
| Idempotency (no double-grant) | **Real** |
| PIM Role Settings guardrails (§6.1) | **Real** — 90-day cap + "no permanent active" enforced on the sandbox |
| SLA / Expiry / Break-Glass monitoring views | **Prototype on seed data** — preview of the Log Analytics workbook (Deliverable #10) |
| Unattended auto-processing (no human click) | **Real, ships inert** — the ticket poller (§8). Off by default; shadow mode previews without writing |

Opening line:
> *"A teammate just raised an access request in ManageEngine. Watch the agent pick it up,
> decide by policy, and grant real, time-bound access in Azure — then close the ticket."*

---

## 1. How to run the project

The dashboard is a **React + MUI (G42 light theme)** UI (`dashboard/web`) backed by a PowerShell
API (`dashboard/api`). One launcher starts both.

### Prerequisites

| Tool | Notes |
|------|--------|
| **Node.js 18+** | UI only — [nodejs.org](https://nodejs.org/) |
| **PowerShell 7.2+** (or Windows PowerShell 5.1+) | API + launchers |
| **Azure CLI** | Live PIM / Real mode only (`az login`) |
| **`.env` at repo root** | Real mode + ManageEngine — SPN + ME creds |

### Safe local run (Mock PIM — recommended first)

```powershell
cd dashboard\web
npm install          # first time only
npm run dev          # starts API + Vite UI
```

Or from the repo root (must run *inside* PowerShell — double-click / Explorer opens Notepad):

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\dashboard\Start-Local.ps1
```

Open **http://localhost:5173**. Full UI options: [`dashboard/README.md`](../dashboard/README.md).

### Live demo preflight (run ~5–10 minutes before)

```powershell
# 1) Confirm the SPN can do real PIM (expect 4/4 PASS)
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Test-SpnAccess.ps1

# 2) Start the app in REAL mode (grants for real via the SPN). Safe Mock default is without -Mode.
powershell -NoProfile -ExecutionPolicy Bypass -File .\dashboard\Start-Local.ps1 -Mode Real
```

`Start-Local.ps1` frees the API port, runs an SPN token preflight, starts the API, and launches
the UI. Open **http://localhost:5173** (it prints the exact port) and leave it on **Help Desk
Tickets**.

**Have the requester raise the ticket** (or use one already raised) targeting an **allowlisted**
subscription so the decision engine will act:
- **Sandbox auto-grant path:** Environment `Sandbox`, Role `Reader`/`Contributor`, Subscription
  `inception-ai-Sandbox` (`efae0e0e-…`). → immediate **active** time-bound grant.
- **Production approval path:** Environment `Production`, Subscription
  `inception-internal-product` (`5a23842e-…`). → **eligible** assignment pending approval.

> Note the requester's ticket carries their email; guest/external requesters resolve by mail
> automatically.

---

## 2. Run-of-show

### Act 1 — The problem & the pipeline (1–2 min) · tab: **Overview** → **Architecture**
> *"Today a request is a ticket someone reads, judges, and fulfils by hand in the portal — slow
> and inconsistent. AzureSentry turns the judgment into a deterministic agent and the fulfilment
> into a real PIM grant."*
Walk **Architecture** left→right: *ManageEngine → decision engine → PIM (ARM) → audit.*

### Act 2 — The ticket arrives (1 min) · tab: **Help Desk Tickets**
> *"These are live from ManageEngine. Here's the one my colleague just raised."*
Find the requester's ticket (search by id). Expand it — the decision inputs auto-map from the
ticket (role, environment, subscription, requester). *"Read-only mapping — the agent works from
what the requester actually asked for."*

### Act 3 — The decision (2 min) · **Evaluate Decision**
> *"The core is a 7-step decision tree — pure, deterministic, unit-tested. The same code runs
> in production."*
Click **Evaluate Decision**. Walk the **7 steps** → the action:
- Sandbox Reader/Contributor → **GRANT / Sandbox-FullAuto**.
- (Optional contrast) show a Reject: an Owner-on-Sandbox or an un-allowlisted subscription stops
  early → **REJECT**. *"Fail-closed: anything ambiguous or disallowed is refused, deterministically."*

### Act 4 — THE REAL GRANT (3–4 min) ⭐ · **Process Ticket — Grant Access**
> *"Evaluating was read-only. Now the agent acts — as the automation service principal, not me."*
Click **Process Ticket — Grant Access**. Show the result panel:
- **Access Granted**, PIM client **Graph** (badge: *real PIM grant via automation SPN*),
  a real **Assignment ID**, and an **Expiry** (time-bound — no standing access).
- *"And it wrote the decision back onto the ticket"* — note posted to ManageEngine; requester gets the **"Note has been added"** email automatically.

**Prove it's real (strong):** alt-tab to a terminal and run the verify snippet (§4), or point out
that the companion script's Step 6 queries Azure directly.

**Idempotency:** click **Process** again → *"It doesn't grant twice — it detects the existing
assignment and refuses. No accidental double-grants."*

### Act 5 — Close the loop & the operational view (2 min)
- The ticket shows a persistent **Processed by AzureSentry** panel (survives reload — server-side).
- (Optional) Resolve the ticket → status **Resolved** with closure fields.
- **Access Audit / Expiry / SLA / Break-Glass** tabs: *"Every decision is logged; this is the
  shape of the Log Analytics workbook — illustrative data today."*

**Close:**
> *"End to end: a real ticket, decided by policy, granted as real time-bound PIM access by the
> agent, annotated and resolved — fully audited. The next build phase is the ManageEngine webhook
> so this triggers with zero clicks."*

---

## 3. One-command scripted run (CLI demo or rehearsal)

`Invoke-DemoScenario.ps1` drives the **same API the UI calls** and narrates every capability —
use it as a CLI-only demo, a rehearsal, or the "prove it" alongside the UI. Run it against the
ticket the requester raised:

```powershell
# Narrated, pausing between steps (real grant if the API is in -Mode Real)
.\dashboard\Invoke-DemoScenario.ps1 -TicketId <ticketId> -Pause

# Full run incl. resolving the ticket and cleaning up the grant afterwards (repeatable)
.\dashboard\Invoke-DemoScenario.ps1 -TicketId <ticketId> -Resolve -Cleanup
```

It performs: preflight → fetch+parse ticket → evaluate (7 steps) → **process (real grant)** →
**idempotency check** → **verify in Azure** → durable-state check → optional resolve → optional
cleanup. Inputs are parsed from the ticket; override with `-Role/-Environment/-SubscriptionId/-RequesterUpn/-DurationDays`.

---

## 4. Independent verification snippet (for skeptics)

Prove the grant exists in Azure, independent of the dashboard (set `$oid` to the requester's
object id, `$sub` to the target subscription):

```powershell
# uses the SPN in .env
. { Get-Content .\.env | %{ if($_ -match '^\s*([\w]+)\s*=\s*(.+)$'){[Environment]::SetEnvironmentVariable($matches[1],$matches[2],'Process')} } }
$sub='efae0e0e-09ab-4c17-82db-d2d1f4382d66'
$t=(Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$env:AZURE_TENANT_ID/oauth2/v2.0/token" -Body @{grant_type='client_credentials';client_id=$env:AZURE_CLIENT_ID;client_secret=$env:AZURE_CLIENT_SECRET;scope='https://management.azure.com/.default'} -ContentType 'application/x-www-form-urlencoded').access_token
(Invoke-RestMethod -Headers @{Authorization="Bearer $t"} -Uri "https://management.azure.com/subscriptions/$sub/providers/Microsoft.Authorization/roleAssignmentScheduleInstances?api-version=2020-10-01").value |
  ForEach-Object { "{0}  end={1}" -f (($_.properties.roleDefinitionId -split '/')[-1]), $_.properties.endDateTime }
```

---

## 5. Reset after the demo (repeatable)

- Easiest: run the scenario with **`-Cleanup`**, which `AdminRemove`s the assignment it created.
- Or delete the assignment from **Entra → PIM → Azure resources → Assignments**.
- Time-bound grants also **auto-expire** (Sandbox active = the ticket's duration; the §6.1 cap is
  90 days).
- The dashboard "Processed" marker lives in `dashboard/api/processed-tickets.json` (gitignored) —
  delete the ticket's entry to reset its dashboard state.

---

## 6. Troubleshooting

| Symptom | Fix |
|--------|-----|
| `Test-SpnAccess.ps1` not 4/4 | SPN missing UAA or `User.Read.All`; the blocked check names the exact gap |
| Process shows **PIM client: Mock** | API started without real mode — restart with `Start-Local.ps1 -Mode Real` |
| Decision = **Reject / Allowlist-Reject** | Ticket's subscription isn't in `config.json` `subscriptionAllowlist` — use an allowlisted sub |
| Decision = **Reject / Schema-Invalid** (justification) | Production requires a ≥20-char justification — the policy working, not a bug |
| Tickets don't load | Not on corp network/VPN (ManageEngine unreachable) or ME creds missing in `.env` |
| Grant returns a PIM error | Run `Test-SpnAccess.ps1`; verify SPN UAA on the target subscription |
| Port 8787 "conflicts with existing registration" | Stale API process — `Start-Local.ps1` clears it automatically |
| Verify shows nothing immediately | Azure PIM is eventually-consistent; re-run the query after a few seconds |

---

## 7. FAQ

### How it works (mechanics)

**Q: What are the 7 steps of the decision engine?**
In order, fail-closed (any failure stops and rejects): **1** Schema validation (required fields,
requester = submitter) · **2** Subscription allowlist · **3** Role eligibility (Owner/UAA on
Sandbox → reject; custom role → hold) · **4** Environment classification (Sandbox → auto path,
Production → approval path) · **5** Priority classification (P1/P2 → expedited SLA + on-call) ·
**6** Role sensitivity (Owner/UAA → dual approval; cross-subscription → senior approver) ·
**7** Duplicate check (an active assignment for the same user/role/scope → reject). It lives in
the `Resolve-RbacDecision` PowerShell module and is unit-tested (62/62).

**Q: Is an AI/LLM making the access decision?**
**No.** The decision is a pure, deterministic function — same inputs always give the same result,
and it's fully auditable and testable. "Agentic" refers to the automated pipeline, not an LLM on
the security path. The policy itself lives in a reviewable data file (`eligibility-matrix.json`).

**Q: How does the agent authenticate and grant?**
As the automation **service principal `e2455957`** using OAuth2 client-credentials, calling the
**Azure Resource Manager PIM API** (`roleAssignmentScheduleRequests` / `roleEligibilityScheduleRequests`).
The SPN holds **User Access Administrator** on the target subscriptions, which is the RBAC right
that authorizes creating role assignments for others.

**Q: Why ARM and not Microsoft Graph?**
Azure *resource* role PIM (subscription/RG scope) is an ARM feature — Microsoft Graph has no
`roleManagement/azureResources` endpoint. Graph is only used to resolve the requester's UPN/email
to an object id (`User.Read.All`). Entra *directory* roles would use Graph, but this platform
grants Azure resource roles.

**Q: How is a ticket turned into a decision?**
The requester's ticket fields map to the engine inputs: **Role**, **Environment**, **Subscription**,
**Priority**, **Requester**, **Justification**. In the dashboard these auto-fill (read-only) from
the ticket to preserve the audit trail; the scenario script parses them from the ticket body.

**Q: How is access time-bound?**
Every grant carries an `expiration` (`AfterDuration`). PIM owns the lifecycle and removes the
assignment at expiry — there is no "forget to revoke." The §6.1 sandbox policy additionally
enforces a **90-day maximum** and **forbids permanent active** assignments at the policy layer.

**Q: How does idempotency (no double-grant) work?**
Two layers: **(1)** if the ticket already has an active grant on record, the API returns the
existing result (`alreadyProcessed`) without granting again; **(2)** before granting it queries
live PIM for an existing user/role/scope assignment — if found, the engine's step 7 returns
`Reject / Duplicate-Assignment`.

**Q: How does the note-back and resolution work?**
On a successful grant the API posts a requester-visible note (`show_to_requester`) to the ticket via
the ManageEngine v3 API with decision + assignment details and next-step instructions (e.g. PIM
activate for Eligible). That fires ME's **"Note has been added"** email to the requester when
notification rules are enabled. Resolution sets status `Resolved` plus the template's mandatory
closure fields (e.g. Vendor Compliance, Account Status = "Access Granted").

**Q: How does the dashboard remember processed tickets across reloads?**
The API persists each processed ticket to `dashboard/api/processed-tickets.json` and serves it at
`/api/manageengine/processed`; the UI hydrates from it on load, so the "Processed" panel survives
refresh (it's not just browser state).

### What it can do (the decision paths / functionalities)

**Q: What are all the outcomes the engine can produce?**
- **Grant** — Sandbox Reader/Contributor → immediate **active**, time-bound PIM assignment (<60s, zero-touch).
- **Eligible** — Production Reader/Contributor → **eligible** assignment the requester activates later (approval + MFA).
- **Break-Glass** — P1 Contributor emergency on a pre-approved prod sub → active immediately, with a mandatory post-hoc review flag.
- **Reject** — schema-invalid, un-allowlisted subscription, Owner/UAA on Sandbox (Azure Policy block), or a duplicate.
- **Hold** — custom-role requests → parked for Cloud Governance review.

**Q: Owner or User Access Administrator requests?**
Always **eligible + dual approval** (two independent approvers; denial by either terminates),
regardless of priority — configured via the §6.2 production role settings.

**Q: Cross-subscription requests?**
Detected and routed to a **senior approver** path.

**Q: What can I configure without touching code?**
Policy behaviour is data: `eligibility-matrix.json` (the matrix), `config.json` (subscription
allowlist + labels), `approver-mapping.json` (who approves what). PIM guardrails are applied via
`infra/pim/Set-PimRoleSettings.ps1` from `rolesettings.*.json`.

**Q: How is the subscription allowlist maintained as we grow?**
Two modes (`config.json` → `allowlist.source`): **static** (a hand-kept list, used for testing)
or **managementGroup** (derived **live from Azure** — every subscription under a management
group, auto-expanding as subs are added). Dynamic mode caches, drops disabled subs, keeps a
governance **exclusions** list (e.g. `ceo-sub-application`), and **fails closed** to the static
list on any Azure error. Inspect via `GET /api/allowlist`. See `docs/allowlist.md`.

**Q: What stops a sensitive subscription being auto-granted via a mislabelled ticket?**
The **subscription sensitivity map** (`src/RbacDecision/Data/subscription-sensitivity.json`), applied
inside the decision engine. It maps subscriptions to their true environment and escalates: the engine
uses the *more restrictive* of the mapped value and the ticket's claimed environment. So a sensitive
sub (e.g. `ceo-sub-application`, `inception-internal-product`) is treated as **Production
(approval + MFA)** even if the ticket says "sandbox", and an explicit Production request is never
downgraded. The decision shows `ClaimedEnvironment` → `EffectiveEnvironment` when it escalates.

**Q: Mock vs Real mode?**
`Start-Local.ps1` (no flag) runs against a **Mock** PIM client — full flow, nothing changes in
Azure — for safe rehearsal. `-Mode Real` performs real grants via the SPN. `config.json` stays on
`Mock` so real is always an explicit opt-in.

### Security & governance

**Q: Can the agent grant more than the requester asked for?**
No. It grants exactly the role/scope/duration derived from the ticket, only after the decision
tree approves, and only on **allowlisted** subscriptions. The SPN's own rights bound what's
possible; the policy bounds what's permitted.

**Q: What stops a bad or forged request?**
Layered: fail-closed schema validation (incl. requester ≠ submitter rejection), subscription
allowlist, Azure Policy blocking Owner/UAA on Sandbox, production justification minimum (≥20
chars), duplicate detection, and time-bound-only grants. Anything ambiguous is rejected.

**Q: Is standing (permanent) access ever created?**
No — every grant is time-bound PIM, and the sandbox policy enforces "no permanent active" at the
platform layer.

**Q: What's audited?**
Every evaluation/decision (7-step trace) in the activity log, a note on the ManageEngine ticket,
and PIM's own native assignment history in Azure. Three independent records.

**Q: Does production access require MFA?**
Yes — activating a production *eligible* assignment requires approval **and** MFA (§6.2 role
settings). Sandbox active grants have no activation step by design.

### Operations & limits

**Q: What licence does this need?**
**Entra ID P2** (or Entra ID Governance) — PIM is P2-gated. Functionally confirmed (see
`docs/phase2-p2-evidence.md`).

**Q: What happens if a grant fails?**
The failure (e.g. a permission or PIM error) is surfaced in the result panel and the run doesn't
mark the ticket processed; nothing partial is left. `Test-SpnAccess.ps1` diagnoses SPN-side causes.

**Q: What isn't built yet?**
- **ManageEngine webhook** — today the agent is triggered from the dashboard (a click); the webhook (Phase 4) makes intake fully hands-off.
- **Production role settings + approver assignment in the tenant** — Phase 2 (prod) / go-live.
- **Log Analytics workbook** — the monitoring tabs are a seed-data prototype of Deliverable #10.
- **Azure deployment** (Automation Account/Logic App) — currently runs locally as the automation SPN.

**Q: Why did a query show nothing right after granting?**
Azure PIM is eventually-consistent — the assignment can take a few seconds to surface in list
APIs. The dashboard auto-refreshes; the script's verify step can be re-run.

---

## 8. User test — the unattended automation (raise a ticket, touch nothing)

Sections 0–7 are the *attended* demo: an operator clicks **Provide Access**. This section is
the *unattended* one. You raise an Azure Subscription ticket through the ManageEngine API,
and the **ticket poller** (`scripts/Invoke-TicketPollerCycle.ps1` +
`src/Agents/TicketPollerAgent.ps1`) finds it, decides it, grants it, notes it and resolves
it with nobody clicking anything.

Operations reference: [`docs/ticket-poller-runbook.md`](./ticket-poller-runbook.md). This
section is the *test recipe*; the runbook is what you run production from.

### 8.1 What the poller will actually auto-grant

Four gates, all required (`src/Agents/PollerGate.ps1`). Anything that fails any one of them
is **queued for a human** — which is a pass, not a bug.

| Gate | Requirement |
|------|-------------|
| Template | ME template name is exactly **`Azure Subscription`** (id `1502`). Exact match, not substring. |
| Structured fields | **Subscription**, **Azure Role** and **Environment** dropdowns all set, all mappable, subscription on the allowlist **by exact name**. |
| Decision | `Resolve-RbacDecision` returns **`Grant`**. `Eligible` / `Hold` / `Reject` / `BreakGlass` always queue. |
| Effective environment | **Sandbox or NonProd only.** Production is excluded *even for Reader*. |

Plus the promotion ladder (§8.5), which the unattended path enforces exactly as the human
path does — the unattended path is never more permissive than the human one.

### 8.2 The three dropdowns, and the values that actually exist

The poller reads three ME user-defined fields off the **detail** endpoint
(`dashboard/api/config.json` → `manageEngine.udfFields`):

| Field | UDF key |
|-------|---------|
| Subscription | `udf_pick_3728` |
| Azure Role | `udf_pick_3729` |
| Environment | `udf_pick_3719` |

> **The list endpoint returns `udf_fields` empty.** `GET /api/v3/requests` gives you nothing
> in `udf_fields` even when you name it in `fields_required`; only
> `GET /api/v3/requests/{id}` populates it. If you write your own probe and conclude "the
> requester left the dropdowns blank", check the detail endpoint before believing it.

**Azure Role options** (`udf_pick_3729`): `Reader` (3120), `Contributor` (3119),
`Owner` (3118), `Azure Kubernetes Service RBAC Admin` (3121).

**Environment options** (`udf_pick_3719`): `Development` (1503), `Test` (1504),
`Pre-Production` (1505), `Production` (1506).

> **There is no `Sandbox` option in ManageEngine.** `Development`, `Test` and
> `Pre-Production` all canonicalise to **NonProd**; `Production` to **Production**. So every
> auto-grantable ticket you can raise is a **NonProd** grant — which matters for the ladder
> in §8.5. Read `Get-CanonicalEnvironment` in `src/Agents/MeTicketMapper.ps1` before
> assuming any other label maps: `Stage`, `Shared` and `DR` deliberately map to *nothing*
> and queue for a human.

**Subscription** must match a subscription under management group `mg-incep-sandbox` **by
exact name** (case-insensitive, trimmed — no substring matching, unlike the UI). Two of the
names in the ME picklist are also mapped **Production** by
`src/RbacDecision/Data/subscription-sensitivity.json` and will therefore queue no matter
what the ticket claims:

| ME picklist value | Auto-grantable? |
|-------------------|-----------------|
| `inception-ai-Sandbox` (3062) | **Yes** — the recommended test target |
| `incep-data-platform` (3054) | Yes |
| `inception-internal-product` (3064) | No — sensitivity map raises it to Production |
| `ceo-sub-application` (3021) | No — sensitivity map raises it to Production |
| `Vantage-Dev`, `aegis-dev`, `Cortex-dev`, `koreai-*`, … | No — not under `mg-incep-sandbox`, so not on the allowlist |

Confirm the live allowlist before testing — it is derived from Azure, not from a file:

```powershell
az account management-group subscription show-sub-under-mg --name mg-incep-sandbox -o table
```

### 8.3 Raise the test ticket via the ManageEngine API

Credentials come from the repo-root `.env` (`MANAGE_ENGINE_URL`, `MANAGE_ENGINE_API_KEY`).

```powershell
$ErrorActionPreference = 'Stop'
Get-Content .env | ForEach-Object {
  if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
    [Environment]::SetEnvironmentVariable($Matches[1], $Matches[2].Trim(), 'Process')
  }
}
$base = ($env:MANAGE_ENGINE_URL).TrimEnd('/')
$headers = @{ authtoken = $env:MANAGE_ENGINE_API_KEY; Accept = 'application/vnd.manageengine.sdp.v3+json' }

$request = @{
  request = @{
    subject     = 'TEST - Azure Subscription access (unattended poller test)'
    description = 'Automated end-to-end test of AzureSentry unattended processing.'
    requester   = @{ email_id = 'you@inceptionai.ai' }   # must resolve to an Entra object id
    template    = @{ id = '1502'; name = 'Azure Subscription' }
    category    = @{ name = 'Access Management' }
    subcategory = @{ name = 'Azure Subscription' }
    item        = @{ name = 'New Request' }
    group       = @{ name = 'IDAM Team' }
    udf_fields  = @{
      udf_pick_3728 = @{ name = 'inception-ai-Sandbox'; id = '3062' }  # Subscription
      udf_pick_3729 = @{ name = 'Reader';               id = '3120' }  # Azure Role
      udf_pick_3719 = @{ name = 'Development';          id = '1503' }  # Environment -> NonProd
      udf_pick_3014 = @{ name = 'No';                   id = '923'  }  # Exception Request
      udf_mline_901 = 'End-to-end test of unattended access provisioning.'
    }
  }
}

$body = @{ input_data = ($request | ConvertTo-Json -Depth 6 -Compress) }
$resp = Invoke-RestMethod -Uri "$base/api/v3/requests" -Method Post -Headers $headers -Body $body
"created ticket #$($resp.request.id)"
```

Then **read it back from the detail endpoint** and confirm the three dropdowns actually
landed — a picklist value ME does not recognise is silently dropped, and the ticket will
queue with "dropdown is not set" rather than fail loudly:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Get-MeAccessFields.ps1 -RequestId <id>
```

Requirements the poller enforces on the ticket itself: status must **not** be
`Resolved` / `Closed` / `Cancelled`, it must be newer than
`AZURESENTRY_POLLER_MAX_AGE_DAYS` (default 7), and it must be in the newest 100 tickets the
list endpoint returns. A ticket you just created satisfies all three.

### 8.4 Run a cycle — shadow first, always

Shadow mode decides everything and writes **nothing**: no Azure grant, no ME note, no
resolution. `granted` is `0` in shadow, always; if you ever see `granted > 0` in shadow,
stop — that is a bug, not a configuration state.

```powershell
# Windows / local. AZURESENTRY_POLLER_ENABLED must be exactly "true".
$env:AZURESENTRY_POLLER_ENABLED = 'true'
$env:AZURESENTRY_POLLER_MODE    = 'shadow'
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Invoke-TicketPollerCycle.ps1 -VerboseOutput
```

Find your ticket in the output. You want `wouldGrant` to include it, with the subscription,
role and NonProd environment you expect. If it is queued instead, the entry carries the
reason — read it literally; every one of them is a named gate above.

When shadow looks right, run it for real. Either set the env var directly:

```powershell
$env:AZURESENTRY_POLLER_MODE = 'enforce'
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Invoke-TicketPollerCycle.ps1 -VerboseOutput
```

or use the dashboard's **Automation** control on the Unattended ticket poller panel
(Dashboard tab) — click **Live**, enter a justification, confirm. It writes
`dashboard/api/poller.enabled` and `poller.mode` together, both of which `Get-PollerConfig`
checks before their respective env vars, so it works identically whether you started the
cycle by hand or the VM's systemd timer runs it (see `docs/ticket-poller-runbook.md` §
"Toggle Enforce Mode from the dashboard"). Either way the switch only affects the *next*
cycle you run — it does not retroactively act on the shadow cycle you already saw.

Enforce mode requires `AZURE_TENANT_ID` / `AZURE_CLIENT_ID` / `AZURE_CLIENT_SECRET` — the
cycle throws immediately if enforce is requested without them, rather than granting nothing
and looking like a policy decision.

On the VM the same thing runs under systemd (`azuresentry-poller.timer`, 5-minute cadence);
see the runbook's "Enable it". Do not skip its shadow step there either.

### 8.5 The promotion ladder will block your first ticket. This is correct.

`Test-AccessPromotionLadder` (`dashboard/api/AccessPromotion.ps1`,
`accessPromotion.enforceLadder` in `dashboard/api/config.json`, default **on**):

> **NonProd requires a prior Sandbox grant for the same requester + role.**
> Production requires a prior Sandbox *or* NonProd grant. Break-Glass is exempt.

Because ME has no `Sandbox` environment option (§8.2), a first-time requester's very first
ticket is a NonProd request with no Sandbox prior, and it will queue with:

> `Access promotion required: grant Reader in Sandbox before Non-Prod for <upn>`

That is the ladder working. Two ways through it for a test:

1. **Give the requester a genuine Sandbox prior** — process one Sandbox grant for that
   requester + role through the dashboard, so `dashboard/api/processed-tickets/` holds a
   non-revoked Sandbox entry for them. This tests the real production behaviour.
2. **Turn the ladder off for the test** — set `accessPromotion.enforceLadder` to `false` in
   `dashboard/api/config.json`. Fastest path to a clean end-to-end run, but it disables a
   real control on the human path too. **Turn it back on afterwards.**

Use (1) if you are testing whether the platform is safe; (2) if you are testing whether the
automation plumbing works.

### 8.6 Verify what it did

**Enforce writes back to ManageEngine; shadow never does.** On a successful unattended grant
the poller posts a note (`Send-ManageEngineProcessNote`) and resolves the ticket
(`Set-ManageEngineTicketResolved`) — both in `dashboard/api/ManageEngineNotes.ps1`, the same
module the human grant path uses. On failure it posts the note and leaves the ticket open,
and the dashboard raises a banner saying a human needs to verify it.

| Where | What you should see |
|-------|---------------------|
| The ME ticket | Decision note posted; status **Resolved** on success, still open on failure |
| Dashboard → **Poller** panel | Last cycle's `mode`, `examined`, `wouldGrant`, `granted`, `queued`, `failed` |
| `dashboard/api/processed-tickets/<id>.*.json` | One claim file per ticket — the record of what was granted |
| `dashboard/api/audit-log-poller.jsonl` | Hash-chained audit entries (the poller's **own** chain, separate from the API's) |
| Azure | `az role assignment list --assignee <upn> --scope /subscriptions/<id>` — the actual truth |
| Dashboard → **Reaper** panel | The expiry that will revoke it. Group-based grants have **no native Azure expiry**; the reaper is solely responsible for revoking them |

### 8.7 Re-running the test

A ticket is claimed exactly once. The claim file is left in place **even when the grant
fails** — deliberately, so a transient failure is never auto-retried into a duplicate grant.
To re-run against the same ticket, delete its claim file by hand:

```powershell
Remove-Item .\dashboard\api\processed-tickets\<id>.*.json
```

Easier: raise a fresh ticket. Ticket ids are cheap; claim files are a safety mechanism.

### 8.8 Stopping it, fastest first

1. **Stop sentinel** — takes effect on the next cycle, no config edit, no restart. It is
   re-checked before *every* ticket, so it also stops a cycle already mid-run:
   ```powershell
   'halted <who> <why> <when>' | Set-Content .\dashboard\api\poller.stop
   ```
2. `AZURESENTRY_POLLER_ENABLED=false`.
3. Stop the timer: `sudo systemctl disable --now azuresentry-poller.timer` (VM only).

Delete `poller.stop` to resume.

### 8.9 Expected outcomes, so you can tell a pass from a bug

| You see | Meaning |
|---------|---------|
| `wouldGrant` contains your ticket | Shadow pass — the gates all cleared |
| `granted` contains it, ME resolved | **End-to-end pass** |
| Queued: "template is not an azure-subscription-grant template" | Wrong template. Every non-Azure-Subscription template is deliberately out of scope today |
| Queued: "Subscription '<x>' is not on the allowlist by exact name" | Not under `mg-incep-sandbox`, or a name typo. Exact match only |
| Queued: "Environment 'Stage' did not map" | Deliberate — see §8.2 |
| Queued: "Effective environment 'Production' is excluded" | The sensitivity map raised it. Working as designed |
| Queued: "Access promotion required" | The ladder — §8.5 |
| `examined` > 0 but `wouldGrant` is 0 across the board | Most likely correct, not broken. Historically ~50 of 53 open tickets are out-of-scope templates and the rest request subscriptions outside `mg-incep-sandbox` |
| `granted > 0` in shadow mode | **A bug.** Stop and investigate |
