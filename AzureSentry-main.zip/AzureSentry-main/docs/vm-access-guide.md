# AzureSentry — VM Access & Dashboard Usage Guide

**Applies to:** `vm-incp-uaen-001-sentry` (Ubuntu 22.04 LTS)  
**Last updated:** 2026-07-29

How to reach the VM, open the dashboard, and use the app.

---

## 1. What's deployed

| | |
|---|---|
| VM name | `vm-incp-uaen-001-sentry` |
| Resource group | `rg-webapps-shared-incp-uaen-001` |
| Subscription | `inception-marketing` (`b2a2ffcd-4eaf-4a65-ab9d-78cb17971147`) |
| Region / OS | UAE North / **Ubuntu 22.04 LTS** (Canonical) |
| Private IP | `172.20.191.4` (**no public IP**) |
| VNet / subnet | `vnet-internal-incp-uaen-001` / `snet-internal-incp-uaen-001` |
| Managed identity | `e6840f89-3d0d-429c-b334-d7fbea7d84a5` |
| App location | `/opt/azuresentry` |
| Service | `azuresentry.service` (systemd), port **8787** |
| Dashboard URL | **http://172.20.191.4:8787** |

One PowerShell process serves both the React UI and the API on that URL.

---

## 2. Before you start — network + VM power

### Network (required for the browser / SSH)

The VM has **no public IP**. You must be on:

- the office LAN, **or**
- the **corporate VPN**, **or**
- another host that routes to `172.20.0.0/16`

Quick check:

```powershell
Test-NetConnection 172.20.191.4 -Port 8787
```

`TcpTestSucceeded : True` → you can open the dashboard in a browser.

### Start the VM if it is deallocated

The VM is often stopped to save cost. If the port test fails, start it first (needs Contributor — activate PIM on `inception-marketing` if eligible-only):

```bash
az vm start \
  -g rg-webapps-shared-incp-uaen-001 \
  -n vm-incp-uaen-001-sentry \
  --subscription b2a2ffcd-4eaf-4a65-ab9d-78cb17971147
```

Wait until power state is **VM running** (~1–2 minutes), then re-test port 8787.

---

## 3. Access and use the app (everyone)

1. Connect to corp network / VPN (§2).
2. Confirm the VM is running (§2).
3. Open a browser to **http://172.20.191.4:8787**.
4. Use the tabs:
   - **Overview** — platform metrics  
   - **Help Desk Tickets** — live ManageEngine tickets  
   - **Request Simulator** — dry-run decision engine  
   - **Live PIM (Azure)** — self-activation against Azure (uses your `az login` where applicable)  
   - **Monitoring / SLA / Expiry / Break-Glass / Architecture** — ops views  

### Process a help-desk ticket

1. Open **Help Desk Tickets**.
2. Expand a ticket — role, environment, subscription, and requester are mapped from the ticket (edit subscription if the parser could not resolve it).
3. Click **Evaluate Decision** — review the 7-step trace and action (Grant / Eligible / Reject / Hold / Break-Glass).
4. If grantable, click **Process Ticket — Grant Access**:
   - runs the PIM/RBAC path, and  
   - posts a **requester-visible** note on the ManageEngine ticket (email via ME “note added” rules).  
5. A green **Processed** badge persists after success.

> **Today:** grants run as **Mock** PIM (`pimClient: Mock`) — simulated Azure assignment, **real** ME note. Real Graph/PIM grants need MI Graph consent + User Access Administrator (see §7).

---

## 4. SSH access (administrators)

Private key: `vm-sentry-id_rsa` · user: **`azureuser`** · host: `172.20.191.4`  
(Same network rule as §2.)

**macOS / Linux / Git Bash:**

```bash
chmod 600 /path/to/vm-sentry-id_rsa
ssh -i /path/to/vm-sentry-id_rsa azureuser@172.20.191.4
```

**Windows PowerShell (OpenSSH):**

```powershell
icacls "$env:USERPROFILE\Downloads\vm-sentry-id_rsa" /inheritance:r /grant:r "$($env:USERNAME):(R)"
ssh -i "$env:USERPROFILE\Downloads\vm-sentry-id_rsa" azureuser@172.20.191.4
```

Or Azure Portal → VM → **Connect → Bastion** if Bastion is enabled.

---

## 5. Administer without corp network (Azure Run Command)

When you cannot reach `172.20.x`:

1. Activate **Contributor** (PIM) on `inception-marketing` if needed.
2. Start the VM if deallocated (§2).
3. Run:

```bash
az vm run-command invoke \
  -g rg-webapps-shared-incp-uaen-001 \
  -n vm-incp-uaen-001-sentry \
  --subscription b2a2ffcd-4eaf-4a65-ab9d-78cb17971147 \
  --command-id RunShellScript \
  --scripts "systemctl status azuresentry --no-pager; curl -s http://localhost:8787/api/health"
```

Use the same pattern for restarts and log pulls.

---

## 6. Service management (on the VM)

```bash
systemctl status azuresentry
sudo systemctl restart azuresentry
sudo systemctl stop azuresentry
journalctl -u azuresentry -n 100 --no-pager

curl -s http://localhost:8787/api/health
```

| Item | Path |
|---|---|
| Config (ME URL/key, `LISTENER_HOST`, PIM mode) | `/etc/azuresentry.env` |
| App files | `/opt/azuresentry/` (`dashboard/api`, `dashboard/web/dist`, `src/`) |

After editing `/etc/azuresentry.env`, run `sudo systemctl restart azuresentry`.  
To enable real grants later: set `AZURESENTRY_PIM_CLIENT=Graph` and restart (only after §7 permissions land).

**Redeploy from this repo** (control plane; no SSH required):

```powershell
# From repo root — builds UI then uploads via Run Command
powershell -File .\scripts\Deploy-ToVm.ps1
# Or skip rebuild if dist/ is already fresh:
powershell -File .\scripts\Deploy-ToVm.ps1 -SkipBuild
```

> **One-time, on the FIRST deploy that includes the 2026-08-23 audit-chain fix
> (`AuditLog.ps1`'s `ConvertTo-CanonicalJsonValue`):** the VM's existing
> `audit-log*.jsonl` files were hashed under the old, `ConvertTo-Json`-based algorithm.
> The fix changes the algorithm, which invalidates every existing hash by construction —
> `/api/audit/integrity` will report a false break on the VM's very first record
> otherwise, even though the VM only ever ran pwsh 7 and never hit the cross-host bugs
> this fix addresses. Run the migration once, on the VM, after this deploy:
> ```bash
> cd /opt/azuresentry
> sudo pwsh -NoProfile -File ./scripts/Repair-AuditChainCanonicalization.ps1
> ```
> It backs up each file before rewriting it and is safe to re-run. Confirm afterward
> with `curl -s http://localhost:8787/api/audit/integrity | python3 -m json.tool` (or
> the dashboard's Trail Integrity button) — every chain should report `"ok": true`.

---

## 7. Known limitations

1. **Mock PIM** until MI Graph consent + UAA — see `docs/graph-consent-request.md`.
2. **HTTP only** on the private IP — add TLS / App Gateway for a production hostname.
3. **ME API key** in `/etc/azuresentry.env` — prefer Key Vault + MI later.
4. **Internal-only** — corp/VPN required for browser and SSH.
5. VM may be **deallocated** when idle — start it before use (§2).

---

## 8. Quick reference

```
Dashboard:   http://172.20.191.4:8787     (corp network / VPN; VM must be running)
Start VM:    az vm start -g rg-webapps-shared-incp-uaen-001 -n vm-incp-uaen-001-sentry --subscription b2a2ffcd-4eaf-4a65-ab9d-78cb17971147
SSH:         ssh -i vm-sentry-id_rsa azureuser@172.20.191.4
Health:      curl http://172.20.191.4:8787/api/health
Service:     systemctl {status|restart|stop} azuresentry
Logs:        journalctl -u azuresentry -n 100 --no-pager
Config:      /etc/azuresentry.env
App:         /opt/azuresentry
Deploy:      powershell -File .\scripts\Deploy-ToVm.ps1
Run-command: az vm run-command invoke -g rg-webapps-shared-incp-uaen-001 \
               -n vm-incp-uaen-001-sentry \
               --subscription b2a2ffcd-4eaf-4a65-ab9d-78cb17971147 \
               --command-id RunShellScript --scripts "<cmd>"
```
