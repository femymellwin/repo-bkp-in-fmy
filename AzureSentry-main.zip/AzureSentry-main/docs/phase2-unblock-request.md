# Phase 2 Unblock Request — Cloud Governance & IT/Procurement

**From:** Abdulla Alfalasi (Cloud Engineering)  
**To:** Cloud Governance, IT/Procurement  
**Date:** 2026-06-29  
**Subject:** AzureSentry — 5 items needed to complete Phase 2 (PIM Config)  
**Reference:** `docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md`, Phase 2 (§13)

---

## Context

All Phase 3 + 4 code (runbooks, decision engine, Azure Policy, tests — 62/62 passing) is authored and pushed to `main`. **Phase 2 is the sole gate** preventing end-to-end deployment and testing. Phase 2's exit criteria (§13):

> *"PIM policies active in non-prod; P2 licences confirmed."*

Neither criterion is met. The 5 items below are all owned externally — none are self-serviceable by the engineering team.

---

## Items requested

### 1. Entra ID P2 licence confirmation — IT/Procurement

**What:** Confirm that Entra ID P2 (or Entra ID Governance) licences are assigned to:
- All users who will **request** access via AzureSentry
- All users who will **approve** requests in PIM
- The automation identity (SP `d68581f3-910c-4c2c-9a34-a53b00811198`)

**Why:** PIM eligible assignments and approval workflows require P2. Without it, every PIM API call returns 403.  
**Spec ref:** §12.2 ("Entra ID P2 licences active for all requesters, approvers, and the automation identity")  
**Effort:** Verification only — no new procurement if P2 is already tenant-wide.

---

### 2. PIM Role Settings — Sandbox (§6.1) — Cloud Governance (Privileged Role Admin)

**What:** Configure PIM Role Settings for each role on the sandbox subscription(s) under `mg-incep-sandbox`:

| PIM Setting | Value (§6.1) |
|---|---|
| Assignment type | Active only |
| Max active duration | 90 days |
| Permanent active | Not allowed |
| Require approval | No (auto-approved) |
| Require justification | No |
| Require MFA | N/A (active, no activation step) |
| Notifications | Requester on assignment; Sub Owner on Contributor |

Apply to: **Reader, Contributor, Owner, User Access Administrator** on each sandbox subscription.

**Spec ref:** §6.1  
**Effort:** ~15 min per subscription in the Azure Portal (Entra > PIM > Azure Resources > Role Settings).

---

### 3. PIM Role Settings — Production (§6.2) — Cloud Governance (Privileged Role Admin)

**What:** Configure PIM Role Settings for each role on each production subscription:

| PIM Setting | Value (§6.2) |
|---|---|
| Assignment type | Eligible (pending approval) |
| Max eligible duration | 90 days |
| Permanent eligible | Not allowed |
| Require approval | **Yes** |
| Require justification | Yes (min 20 chars) |
| Require MFA on approval | **Yes** |
| Approvers — Reader/Contributor | Primary + Backup per sub (from Approver Mapping, item #4) |
| Approvers — Owner/UAA | Primary + Cloud Gov Lead + Security Lead (**dual-approver chain**) |
| Approval expiry P1 | 4h (escalate at 2h) |
| Approval expiry P2 | 8h (escalate at 4h) |
| Approval expiry P3/P4 | 24h |
| Notifications | Approver on new request; requester on decision; Security on Owner/UAA |

**Depends on:** Item #4 (Approver Mapping) — cannot assign approvers without names.  
**Spec ref:** §6.2  
**Effort:** ~20 min per subscription per role.

---

### 4. Approver Mapping (§6.3) — Cloud Governance

**What:** Fill in the approver-mapping table for every production subscription. A scaffold is attached at `docs/approver-mapping.md` — only the name/email columns need completing.

**Spec ref:** §6.3, Deliverable #7  
**Why this gates everything:** Item #3 (Prod Role Settings) cannot be configured without approver names. The decision engine's `Eligible` path creates PIM requests that go to these approvers — without them, the approval workflow is a dead end.

---

### 5. PIM Role Settings peer review & sign-off — Cloud Governance

**What:** After items #2 and #3 are applied, Cloud Governance reviews the live settings and provides written sign-off before any production enablement.

**Spec ref:** §13 Phase 2 exit criterion, §12 risk row "PIM Role Settings misconfigured"  
**Effort:** Review meeting (~30 min).

---

## Suggested sequencing

```
Items #1 + #4 can start immediately (parallel)
       │
       ▼
Item #2 (Sandbox Role Settings) — can start as soon as #1 confirms P2
       │
       ▼
Item #3 (Prod Role Settings) — needs #4 (approver names)
       │
       ▼
Item #5 (Sign-off) — needs #2 + #3 complete
       │
       ▼
Phase 2 exit criteria met → Phase 3 deploy unblocked
```

## What engineering will do once Phase 2 clears

- Deploy Bicep infrastructure (`deployRbac` flag)
- Admin-consent Graph permission `PrivilegedAccess.ReadWrite.AzureResources` for the SP
- Run end-to-end Sandbox auto-assign demo (Phase 3 exit criterion)
- Proceed to Phase 4+ integration testing

Please reach out with any questions. Happy to walk through any of the spec sections referenced above.
