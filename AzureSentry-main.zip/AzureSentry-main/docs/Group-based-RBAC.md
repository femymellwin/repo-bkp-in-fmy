Group-based RBAC assignment flow:
When a request comes for contributor access to a project/subscription, your code should first find the existing contributor group for that subscription, verify the group already has the right tole assignment, and then add the user to that group instead of assigning the role directly to the user. Tin Microsoft Entra ID > Groups for finiding the groups, and Subscriptions > Access control (IAM) > Role assignments for checking whether the group is already assigned at the subscription scope.

Requested Requirments
- During onboarding of a new subscription/project, they create a group that follows a naming convention like SG-<project>-<enviorment>-<role> or specifically contributor-style group such as "sg-jira-conf-prod-uaen-contributors".
- Your code should accept the subscription name or subscription ID from the requester and search for an existing contributor group associate with that subscription. 
- If a suitable group already exists and is already assigned the relevant role on that subscription, your automation should add the user to that group, it should not assign RBAC directly to the user.
- If the group or assignment does not already exist, create the canonical group (`sg-<subscription-slug>-contributors` / `…-readers`), assign the role at subscription scope, and add the user. Only when multiple groups match ambiguously, fall back to per-user PIM and flag an engineer.


Where to find the groups:
To see the groups in the portal, Microsoft Entra ID/ Entra ID > manage > groups. This is where you look for names like sg-jira-conf-prod-uaen-contributors and inspect the group objects.


Where to check role assignemnts:

Open a subscription and go to Access control (IAM) > Role assignments to verify whether the contributor group is assigned there. 

Path: Azure portal -> subscirptions -> open the target subscription -> left menu -> access control (IAM) -> Role assignments

Inside that page you can filter for Type=Group so you can look for group principals rather than individual users



Practical flow expected:

1. Read the requesters subscription name or subscription ID. 2. Find the contributor group for that project/subsciption using the naming convention orby checking group role assignments. 3. Open the targets subscription IAM > Role assignments and confirm the contributor group is already assigned there. 4. If yes, add the requester/user to the group in Entra ID >groups rather than granting RBAC directly.


The paths provided above are found via the web-browser, try using the azure cli instead.