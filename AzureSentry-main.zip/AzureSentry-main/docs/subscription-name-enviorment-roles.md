SUBSCRIPTION NAME|	ENVIRONMENT	|Roles|
adaacatalyst-prod|	prod	|Owner|
aegis-dev	|staging	|Contributor|
aicos-dev	|uat|	Reader|
aicos-qa	|qa	|Azure Kubernetes Service RBAC Admin|
aijudge-qa	|dev|	-|
Azure-Labs	|sandbox|	 -|
Backup-Vault-Subscription|	dr	 | -|
BO-Inception-Key	|shared	 |-|
ceo-sub-application	|training|	- |
Connectivity	|preprod| -|
cortex_2_-qa	|     -     | 	 -|
cortex-2.0-prprd|  -     |	 -	| 
Cortex-dev|      -   |	 -	 |
cortex-post-mvp	 |   -   |	- |
cortex-pre-prod	 |   -   |	- |
cortex-preprod	 |  -    |	 -|
Cortex-Prod	 | -         |	- |
Cortex-QA	  |   -      | 	 -|
cortex-stg	 |      -    |	 -|
cortex2-amber|       -      | -	 	| 
cortex2-dev	 	 |       -      | -	 |
cortex2-onprem-rancher	|       -      | -	|  	 
cortex2-preprod	 	|       -      | -	 | 
cortex2-prod	 |       -      | -	 |	 
cortex2-prod-prod |       -      | -	| 	 	 
cortex2-purple	 	|       -      | -	 | 
cortex2-qa	 |       -      | -	 	 |
cortex2-rainbow	 |       -      | -	 |	 
cortex2-uat	 	|       -      | -	  |
cortex2-violet	 	|       -      | -	 | 
dge-dev-procurement	 |       -      | -	 |	 
DOF-BO-DEV	 	 |       -      | -	 |
doh-chairman-dev	|       -      | -	|  	 
g42-ai-foundry-prod	 |       -      | -	 |	 
g42-bo-dev	 	 |       -      | -	 |
G42-BO-PROD	 |       -      | -	 	| 
github	 	 |       -      | -	 |
Identity	 	|       -      | -	|  
ince-aijudge-poc |       -      | -	| 	 	 
incep-audio-dev	 |       -      | -	 |	 
incep-chairman	 	|       -      | -	|  
incep-data-platform	 |       -      | -	 |	 
incep-devops-dev	 |       -      | -	 	| 
Incep-EnergyAI-Sandbox-Dev	|       -      | -	|  	 
incep-legal-process-automation-dev	|      -  |-	|  	 
incep-noor-dev|       -      | -	 |
incep-noor-prod	 	 |       -      | -	 |
incep-noor-staging	|       -      | -	 | 	 
Inception GPU Cluster	 |       -      | -	 |	 
inception-ai-Sandbox|       -      | -	 |	 	 
inception-growth|       -      | -	 |	 	 
inception-internal-product|       -      | -	 |	 	 
Inception-pmo-dev|       -      | -	 |	 	 
inception-sandbox-dev|       -      | -	 |	 	 
inceptionclaw-adaa-dev|       -      | -	 |	 	 
inceptionclaw-adda	|       -      | -	 | 	 
Inceptionclaw-dev	|       -      | -	 | 	 
Inceptionclaw-hackathon	|       -      | -	 | 	 
Inceptionclaw-prod	|       -      | -	 | 	 
incp-dataeng-dev	|       -      | -	 | 	 
incp-energyAI	 |       -      | -	 |	 
incp-inalpha-dev	|       -      | -	 | 	 
incp-mubadala-proc-dev|       -      | -	 |	 	 
incp-mubadala-proc-prd|       -      | -	 |	 	 
incp-mubadala-proc-preprd|       -      | -	 |	 	 
incp-shared-services-dev|       -      | -	 |	 	 
inmedia-dev	 |       -      | -	 |	 
insight-saas-dev|       -      | -	 |	 	 
Investment AI - ADNOC|       -      | -	 |	 	 
jira-conf-uat	 |       -      | -	 |	 
koreai-demo	 	|       -      | -	 | 
koreai-dev	 	|       -      | -	 | 
koreai-mubdla-qa|       -      | -	 |	 	 
koreai-preprd	 |       -      | -	 |	 
koreai-prod	 	|       -      | -	 | 
koreai-qa	 |       -      | -	 |	 
legal-process-automation-prod|       -      | -	 |	 	 
lms-qudratech-dev	|       -      | -	 | 	 
Managed-Engine|       -      | -	 |	 	 
Management	|       -      | -	 | 	 
mbo-dev	 	|       -      | -	 | 
mbo-poc	 	|       -      | -	 | 
mub-legalai-preprod	|       -      | -	 | 	 
mubadala-supertool-preprod	 |       -      | -	 |	 
NovaApp-dev|       -      | -	 |	 	 
NovaApp-prod|       -      | -	 |	 	 
pmo-dev	 |       -      | -	 |	 
pmo-fegma-deign|       -      | -	 |	 	 
pmo-prod	|       -      | -	 | 	 
pmo-qa	 |       -      | -	 |	 
ramesh-sandbox|       -      | -	 |	 	 
SaaS - CAI - DataEngineering - Prod|  -   | -	 |	 	 
sbx-openclaw-poc	 	 |       -      | -	 |
Security|       -      | -	 |	 	 
shared-applications	 |       -      | -	 |	 
shared-webapps	|       -      | -	 | 	 
SharedServices|       -      | -	 |	 	 
shelf-interview-prod|       -      | -	 |	 	 
shelf-interviewhost-dev	|       -      | -	 | 	 
shelf-interviewhost-prod|       -      | -	 |	 	 
shelf-interviewhost-uat	|       -      | -	 | 	 
shelf-rfp-dev	|       -      | -	 | 	 
shelf-rfp-uat	|       -      | -	 | 	 
stt-azure-poc	|       -      | -	 | 	 
Yeji Data Lab - poc	|       -      | -	 | 