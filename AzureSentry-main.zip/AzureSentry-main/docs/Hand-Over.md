# AzureSentry — Hand-Over Guide

**Audience:** someone new being brought up to speed on the platform's architecture and how to
install/operate it. **Not** a decision-engine reference (see
[`docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md`](Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md))
or a step-by-step demo script (see [`DEMO_GUIDE.md`](DEMO_GUIDE.md)) — this is the map that
tells you which of those documents to open next.

---

## 1. What this platform does, in one paragraph

AzureSentry replaces manual help-desk fulfilment of Azure access requests with a deterministic
decision pipeline. A requester raises a ticket in **ManageEngine ServiceDesk Plus**; AzureSentry
reads it, classifies it through a fixed 7-step decision tree (no LLM in this path), and either
**grants** it (a time-bound Azure PIM/RBAC assignment), marks it **Eligible** for a human
approver, or **queues/rejects** it. Everything is audited in a tamper-evident, hash-chained log.
There are two ways a ticket gets processed: an **operator clicking through the dashboard**, and
an **unattended poller** that does the same thing on a schedule with no human involved, for a
narrow, deliberately conservative slice of requests.

---

## 2. Architecture — what's actually running today

> ⚠️ **The root `README.md`'s architecture diagram (ManageEngine webhook → Logic App Standard →
> Automation Runbooks) describes the original design, not the deployed system.** That push/
> webhook model was superseded by the pull-based design below during Phase 3/4 — Azure App
> Service's `http.sys` sandbox couldn't host the PowerShell backend, so the platform moved to a
> single VM running one long-lived process, and the poller/reaper agents pull from ManageEngine
> directly on a timer instead of ME pushing a webhook. If you read the README first, don't be
> surprised the Logic App / Automation Account pieces aren't part of what's live.

```
                         ┌─────────────────────────────────────────────┐
                         │   vm-incp-uaen-001-sentry  (Ubuntu, private) │
                         │                                              │
  Browser ───HTTP:8787──▶│  dashboard/api  (PowerShell HttpListener)   │
                         │  serves REST API + built React UI (dist/)   │──┐
                         │        │                                    │  │
                         │        ▼                                    │  │
                         │  src/RbacDecision  (pure decision engine)   │  │
                         │        │                                    │  │
                         │        ▼                                    │  │
                         │  src/PimClient  (Graph/ARM PIM, or Mock)    │  │
                         └─────────────────────────────────────────────┘  │
                                                                            │
                         ┌─────────────────────────────────────────────┐  │
  ManageEngine  ◀──poll──│  azuresentry-poller.timer  (every 5 min)    │  │
  ServiceDesk Plus        │  Invoke-TicketPollerCycle.ps1 → same        │──┤
  (REST API, not          │  RbacDecision + PimClient modules above     │  │
   a webhook)             └─────────────────────────────────────────────┘  │
                         ┌─────────────────────────────────────────────┐  │
                         │  azuresentry-reaper.timer  (every 30 min)   │  │
                         │  Invoke-ReaperCycle.ps1 → revokes overdue   │──┘
                         │  grants the poller made (no native expiry)  │
                         └─────────────────────────────────────────────┘
                                          │
                                          ▼
                         Azure RBAC / PIM  +  local hash-chained audit logs
                         (Log Analytics forwarding is wired but optional)
```

Three independent processes share the same VM, the same config file, and the same decision/PIM
code — but write to **separate** state and audit files, on purpose (see §6). The dashboard API
is always running (systemd service); the poller and reaper are one-shot processes a systemd
timer launches on a cadence, not long-running daemons.

---

## 3. Component map

| Path | What it is | Key files |
|---|---|---|
| `src/RbacDecision/` | The decision engine. Pure PowerShell module, no I/O, fully unit-tested. Given a ticket, returns `Grant` / `Eligible` / `Hold` / `Reject` / `BreakGlass`. | `Resolve-RbacDecision.ps1`, `Data/eligibility-matrix.json` (the policy table), `Data/role-catalog.json` (every supported Azure role + its risk tier + Azure scope — adding a role here is the only change needed to make it requestable), `Data/subscription-sensitivity.json` (forces Production classification for sensitive subs regardless of what the ticket claims) |
| `src/PimClient/` | How a decision actually becomes an Azure RBAC change. | `GraphPimClient.psm1` (real Graph/ARM calls, works under both pwsh 7 and Windows PowerShell 5.1 via raw REST), `GroupRbac.ps1` (adds the requester to a pre-provisioned Entra group for the common Sandbox/NonProd Reader/Contributor case — no per-user Azure write at all; falls back to a real per-scope PIM assignment, `PimFallback`, when no matching group exists, e.g. any AKS RBAC role) |
| `src/Agents/` | The unattended pipeline's four stages. | `MeTicketMapper.ps1` (ME structured fields → canonical ticket, strict/no-guessing), `PollerGate.ps1` (the single policy boundary deciding if a `Grant` decision may execute with no human), `TicketPollerAgent.ps1` (orchestrates one poll cycle), `ReaperAgent.ps1` (the revocation mirror) |
| `dashboard/api/` | The REST API + shared helpers, and the app's config/state. | `Start-DashboardApi.ps1` (entry point — HttpListener, serves UI + API from one process), `config.json` (**shared** runtime config, checked into git), `MeAccessFields.ps1` (ME UDF field reading, shared by the dashboard AND the poller so there's one implementation of "what does this ticket ask for") |
| `dashboard/web/` | React + MUI (Emotion) frontend, built with Vite. | Served as static files from `dist/` by the API process — there is no separate frontend server in production |
| `scripts/` | Everything you actually run by hand or via systemd. | See §5 |
| `infra/systemd/` | The VM's scheduling for the poller and reaper. | See §5 |
| `tests/unit/` | Pester tests — 597 as of this writing, all passing. Run with `.\tests\Run-Pester.ps1` or `Invoke-Pester -Path .\tests\unit`. | |
| `docs/` | Everything else. See §8 for a map. | |

---

## 4. How a ticket actually moves through the system

**Attended (human) path:** operator opens **Help Desk Tickets** in the dashboard → **Evaluate
Decision** (calls `Resolve-RbacDecision` live) → if grantable, **Process Ticket — Grant Access**
→ real or Mock PIM call → a requester-visible note is posted back to the ME ticket.

**Unattended (poller) path**, every 5 minutes on the VM:
1. Fetch open ME tickets (list endpoint — **`udf_fields` always comes back empty here**, a real
   ME API quirk, not a bug; only the per-ticket detail endpoint populates them).
2. Filter cheaply: right status, right age window, not already claimed.
3. Fetch **detail** for survivors, map structured fields (`MeTicketMapper.ps1`) — anything
   ambiguous or incomplete queues for a human here, never guessed.
4. Run the same `Resolve-RbacDecision` the human path uses.
5. `PollerGate.ps1`: only a `Grant` decision on **Sandbox or NonProd** may proceed unattended —
   Production is excluded even for Reader, and `Eligible`/`Hold`/`Reject`/`BreakGlass` always
   queue for a human.
6. Claim the ticket (an atomic filesystem create — this is the whole duplicate-grant defense,
   no locks), then grant for real (enforce mode only), post a note, resolve the ticket.
7. The **reaper**, every 30 minutes, revokes anything the poller granted whose recorded expiry
   has passed — this is not optional bookkeeping: group-based grants have **no Azure-enforced
   expiry at all**, so if the reaper stops running, overdue access simply never comes back.

Full operational detail and troubleshooting: [`ticket-poller-runbook.md`](ticket-poller-runbook.md).
The exact eligibility table (which role/environment/priority combinations are auto-grantable):
[`poller-eligibility-matrix.md`](poller-eligibility-matrix.md).

---

## 5. Installation & operational scripts

### One-time / occasional (run from your machine, against the VM)

| Script | Purpose |
|---|---|
| `scripts/Deploy-ToVm.ps1` | Ships the app to the VM with **no SSH and no storage account** — builds the React UI locally, packages a slim tarball, uploads it as chunked base64 over `az vm run-command`. Deliberately excludes secrets (`.env`), runtime state (`processed-tickets.json`, `poller.{mode,stop,enabled,caps.json}`, `reaper.{mode,stop,enabled,caps.json}`), and the VM's own audit log, so a redeploy never clobbers production state or a live Automation override. `-SkipBuild` if `dist/` is already fresh. |
| `infra/systemd/install-poller-timer.sh` | Run **as root, on the VM**. Installs `azuresentry-poller.service` + `.timer` and enables the timer. Installing does **not** turn on real writes — `AZURESENTRY_POLLER_ENABLED` in `/etc/azuresentry.env` still gates everything and defaults to off. Safe to run any time. |
| `infra/systemd/install-reaper-timer.sh` | Same, for the reaper. |
| `scripts/Test-SpnAccess.ps1` | Authenticates **as the automation SPN** and probes Graph + ARM permissions (User.Read.All, Reader, User Access Administrator, a PIM write dry-run). Run this after any credential change, before trusting enforce mode. |
| `scripts/Test-ApiAccess.ps1` | Probes the deploy identity's own Graph/ARM permissions (used before the SPN pivot; still useful for diagnosing consent issues). |
| `scripts/Get-MeAccessFields.ps1 -RequestId <id>` | Reads a ManageEngine ticket via the **detail** endpoint and prints exactly what the app would map from it — the tool for discovering a UDF field's real key (`udf_pick_NNNN` / `udf_sline_NNNN`) or diagnosing "why did this ticket queue." |
| `scripts/Repair-AuditChainCanonicalization.ps1` | One-off migration for a specific historical fix (hash-chain canonicalization changed 2026-08-23, invalidating old hashes by construction). Backs up before rewriting; safe to re-run. Only relevant if you're bringing an older deployment forward. |

### Recurring (the VM runs these on its own via systemd)

| Script | Triggered by | Cadence | Notes |
|---|---|---|---|
| `scripts/Invoke-TicketPollerCycle.ps1` | `azuresentry-poller.timer` | Every 5 min | One cycle per invocation, deliberately — a hung cycle can't wedge the poller forever, and each run gets fresh tokens. Writes `dashboard/api/poller-status.json` and its own audit chain `audit-log-poller.jsonl`. |
| `scripts/Invoke-ReaperCycle.ps1` | `azuresentry-reaper.timer` | Every 30 min | Same one-shot pattern. 30 min vs. the poller's 5 because reaper cadence only bounds how long an *already-expired* grant lingers, not user-facing latency — negligible against grants measured in days. Writes `reaper-status.json` / `audit-log-reaper.jsonl`. |

Both entry scripts load `/etc/azuresentry.env` themselves and require **`AZURESENTRY_POLLER_ENABLED`** / **`AZURESENTRY_REAPER_ENABLED`** to be the exact string `true` to do anything at all — everything ships inert by default.

### Local development

| Command | What it does |
|---|---|
| `powershell -File .\dashboard\Start-Local.ps1` | One-command local run: frees a stale port, starts the API, waits for health, launches the Vite dev UI. **Mock PIM by default** — nothing real happens. |
| `powershell -File .\dashboard\Start-Local.ps1 -Mode Real` | Same, but preflights the SPN token and switches to real Graph/PIM grants if it succeeds (falls back to Mock if the preflight fails). |
| `.\tests\Run-Pester.ps1` | Full unit suite. |

---

## 6. Configuration & secrets — three layers, don't confuse them

| Layer | File | Committed to git? | Controls |
|---|---|---|---|
| **Shared app config** | `dashboard/api/config.json` | **Yes** | Allowlist source, ME UDF field key mapping (`manageEngine.udfFields`), grant duration default, ME closure fields, access-promotion-ladder on/off, demo seed toggle. Read by the dashboard API **and** the poller/reaper (via injected overrides) — this is the one place that should differ between environments only by careful, deliberate edit, never by accident. |
| **Secrets + per-deployment toggles** | `.env` (local) / `/etc/azuresentry.env` (VM) | **No — gitignored, never commit** | ME credentials, SPN credentials (`AZURE_TENANT_ID`/`CLIENT_ID`/`CLIENT_SECRET`), and every `AZURESENTRY_POLLER_*` / `AZURESENTRY_REAPER_*` kill switch, mode, and cap. `.env.example` documents every key with no real values. |
| **Live overrides** (dashboard-writable, no file edit needed) | `dashboard/api/poller.{mode,enabled,caps.json}` / `reaper.{mode,enabled,caps.json}` / `poller.stop` / `reaper.stop` | **No — runtime state, gitignored** | The **Automation** control and per-cycle-limits form (below), plus the stop sentinels. `Deploy-ToVm.ps1` explicitly excludes all of these so a redeploy never clobbers a live override. |

**The dashboard's Automation control (Off / Rehearse / Live) is now the single UI switch for
each agent — it replaces the older two-file "Enforce Mode toggle + env-only kill switch"
split.** Under the hood it still writes two independent files (`poller.enabled` +
`poller.mode`, same for reaper), each checked before its env var with the same fail-closed
contract, but the UI composes them into one 3-way choice:

| Selection | Writes |
|---|---|
| **Off** | `enabled=false` |
| **Rehearse** | `enabled=true`, `mode=shadow` |
| **Live** | `enabled=true`, `mode=enforce` — requires a ≥4-character justification |

This is a deliberate trade-off: earlier the kill switch was reachable only by editing
`/etc/azuresentry.env`, specifically so a UI click alone could never fully arm real writes.
That protection is gone now — anyone who can reach the dashboard (no authentication on this
API) can arm both agents. Accepted as appropriate for a single-operator deployment on a
trusted network; revisit if that stops being true. The systemd timer install (`docs/ticket-poller-runbook.md`
§"Enable it") is still a one-time, out-of-band infra step — the Automation control only ever
changes what a cycle does once it's already running on a schedule, never whether cycles run
at all.

Per-cycle limits (poller: max grants / tickets examined / ticket age; reaper: max revokes)
are also UI-editable now, on the same panel, via `poller.caps.json`/`reaper.caps.json` — a
small JSON override file with per-field fallback to the matching env var. Raising the grants
(or revokes) limit needs the same justification floor as going Live; lowering it, or
changing the other fields, doesn't.

---

## 7. Safety mechanisms — the things that make "unattended" acceptable

- **Shadow by default.** Both agents default to `shadow`: decide and record, write nothing —
  not to Azure, not to ManageEngine. `granted > 0` in shadow mode is a bug, always.
- **Per-cycle caps**, not just an on/off switch: `AZURESENTRY_POLLER_MAX_GRANTS` (default 5) is
  the real blast-radius bound; `AZURESENTRY_REAPER_MAX_REVOKES` (default 25) similarly for the
  reaper. `AZURESENTRY_POLLER_MAX_TICKETS` only bounds how many tickets are *examined* — raising
  it is a runaway guard, not a safety control. All of these are now also UI-editable from the
  Automation panel (§6) — raising the grants/revokes bound needs the same justification floor
  as arming Live.
- **Age window** (`AZURESENTRY_POLLER_MAX_AGE_DAYS`, default 7) so a cold start can't attempt
  the entire historical backlog at once.
- **Promotion ladder**: NonProd requires a prior Sandbox grant for the same requester+role;
  Production requires a prior Sandbox or NonProd grant. Enforced **identically** on the human
  and unattended paths (`accessPromotion.enforceLadder` in `config.json`) — the unattended path
  must never be more permissive than the human one.
- **Claim-based dedup, no locks:** claiming a ticket is one atomic "create if not exists"
  filesystem call. A failed grant keeps its claim on purpose — a transient failure is never
  auto-retried, because that's exactly the duplicate-grant risk the claim exists to prevent. A
  stuck ticket needs a human to look at `dashboard/api/processed-tickets/<id>.*.json` and either
  fix and re-run by hand, or delete the file to allow another attempt.
- **Resource-scope enforcement:** a role scoped to a specific Azure resource (AKS RBAC, Storage
  Blob Data) can never be granted at bare subscription scope — the schema validator rejects it
  outright rather than silently over-granting (e.g. cluster-admin across every AKS cluster in
  the subscription).
- **Separate, hash-chained audit trails per writer process**: `audit-log.jsonl` (dashboard API),
  `audit-log-poller.jsonl`, `audit-log-reaper.jsonl`. They're kept separate deliberately —
  concurrent writers on one chain would corrupt each other's hash sequence. `GET
  /api/audit/integrity` verifies all of them and reports each separately.
- **Stop sentinels** (`poller.stop` / `reaper.stop`): re-checked before every ticket, so they
  halt a cycle already mid-run, not just the next one. Fastest way to stop either agent with no
  config edit or service restart.

---

## 8. Where to go next

| Question | Document |
|---|---|
| "Walk me through a live demo" | [`DEMO_GUIDE.md`](DEMO_GUIDE.md) |
| "How do I run/enable/halt/troubleshoot the poller and reaper day to day" | [`ticket-poller-runbook.md`](ticket-poller-runbook.md) |
| "Exactly which role+environment+priority combos auto-grant" | [`poller-eligibility-matrix.md`](poller-eligibility-matrix.md) |
| "How do I reach the VM / restart the service / redeploy" | [`vm-access-guide.md`](vm-access-guide.md) |
| "What's the original scope and spec" | [`Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md`](Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md) |
| "What's left before this is a production sign-off, not a prototype" | [`BUILD_PLAN.md`](BUILD_PLAN.md), [`../progress.md`](../progress.md) |

---

## 9. Known limitations, as of this hand-over

1. **Mock vs. real PIM is a per-deployment/per-run choice**, not a fixed state — check
   `config.json`'s `pimClient` and whichever `AZURESENTRY_PIM_CLIENT` / `-Mode Real` was used
   for the process you're looking at before assuming which one is active.
2. **VM is internal-only, no public IP, no TLS** — corp network/VPN required, HTTP not HTTPS.
3. **VM may be deallocated when idle** — start it before expecting the dashboard to respond.
4. **The static `subscriptionAllowlist` in `config.json` (poller) can drift from the live,
   management-group-derived allowlist the dashboard uses** — keep them in step by hand; there's
   no automatic reconciliation.
5. **AKS RBAC role auto-grant is newly wired (2026-08-25/26)** — the ME "Azure Subscription"
   template's `udf_sline_3738` field ("Destination Resource ID") supplies the target cluster;
   it is not marked mandatory on the ME side, so it's easy for a requester to leave it blank —
   the ticket will correctly queue for a human in that case, not fail silently.
