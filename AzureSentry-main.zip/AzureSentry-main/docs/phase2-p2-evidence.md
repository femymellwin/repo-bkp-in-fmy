# Entra ID P2 — Evidence & Confirmation Request (Phase 2, item 2.1)

**From:** Cloud Engineering (Abdulla Alfalasi)
**To:** IT / Procurement
**Date:** 2026-07-09
**Purpose:** Close Phase 2 exit criterion *"P2 licences confirmed"* (scope §13, §12.2).

---

## Ask (one line)

Please **confirm in writing** that **Entra ID P2** (or **Entra ID Governance**) licensing is
active in tenant `5ac4936b-1ac4-4e57-9e2b-48673491865e` and assigned to: (a) users who
**request** access, (b) users who **approve** in PIM, and (c) the **automation identity**
(SPN `e2455957-63ef-41e9-bf10-9cfd2f625aea`).

## Why this is already technically proven

PIM (Privileged Identity Management) for Azure resources is a **P2-gated** feature — the ARM
PIM APIs return an authorization/licensing error when P2 is absent. AzureSentry has
**successfully exercised those APIs against this tenant**, which is only possible with P2:

| Evidence | Operation | Result | Date |
|----------|-----------|--------|------|
| Active, time-bound grant | `roleAssignmentScheduleRequests` (`AdminAssign`, Contributor, 1-day expiry) | `Provisioned` — verified active assignment + PIM schedule instance with expiry | 2026-07-08 |
| Eligible, approval-gated grant | `roleEligibilityScheduleRequests` (`AdminAssign`, Contributor, 7-day) | Eligible schedule instance created (no standing access), then removed | 2026-07-09 |
| Self-activation (dashboard Live PIM) | ARM PIM self-activate on `inception-internal-product` | 1-hour Contributor activation succeeded | 2026-06-25 |
| Role Settings management | ARM `roleManagementPolicies` PATCH (§6.1 guardrails) | Applied + verified on `inception-ai-Sandbox` | 2026-07-09 |

All four require PIM, and PIM requires P2 → **P2 is functionally active in the tenant.**

> If you have portal/admin access, this can also be seen at
> **Entra admin center → Billing → Licenses** (SKU `AAD_PREMIUM_P2` / Entra ID Governance),
> or by reading `subscribedSkus` via Graph.

## What this confirmation unblocks

It is the **sole remaining gate** for the Phase 2 (PIM Config) exit — the technical side
(PIM policies active in non-prod) is complete. Written confirmation closes Phase 2 for the
non-prod scope.

## Sign-off

| Role | Name | Date | Confirmed |
|------|------|------|-----------|
| IT / Procurement | | | ☐ P2 / Governance active & assigned as above |

---

*Related: `docs/phase2-unblock-request.md` (original Phase 2 request), `progress.md` (Phase 2 tracker).*
