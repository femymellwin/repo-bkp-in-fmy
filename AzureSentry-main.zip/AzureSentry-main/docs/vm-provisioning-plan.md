# AzureSentry — VM Provisioning Plan

**Author:** Abdulla Alfalasi (Cloud Engineering)
**Date:** 2026-07-06
**Purpose:** Host the AzureSentry backend (PowerShell API + built React UI, served by one process) on a VM that can reach the internal ManageEngine help desk and perform real Azure PIM/RBAC grants via a managed identity.
**Companion docs:** `docs/hosting-decision.md`, `docs/graph-consent-request.md`, `docs/required-api-access.md`

---

## 1. Target topology

```
Corporate network (on-prem / DC)
   helpdesk.int.inceptionai.ai
            ▲
            │  ExpressRoute / S2S VPN  (existing hub connectivity)
            │
      ┌─────┴───────────── Hub VNet ─────────────┐
      │  (DNS forwarder / corporate DNS servers)  │
      └─────┬─────────────────────────────────────┘
            │  VNet peering
            ▼
   Spoke VNet: vnet-azuresentry-uaen
     └── subnet: snet-azuresentry-app  (VM lives here)
            │
            ├──► helpdesk.int.inceptionai.ai   (internal, via hub)
            └──► graph.microsoft.com / management.azure.com  (public egress)
```

The VM behaves like any internal automation server: it resolves the corporate DNS name and routes to it through existing hub connectivity, while also reaching the public Microsoft Graph / ARM endpoints for grants.

---

## 2. Networking & DNS requirements — **networking team**

These are the real prerequisites; the VM cannot reach the help desk without them.

| Requirement | Detail |
|---|---|
| VNet + subnet | `vnet-azuresentry-uaen` / `snet-azuresentry-app` in **UAE North**. Small subnet (e.g. /27) is enough. |
| Connectivity to corp network | Peer the spoke to the existing hub VNet that carries ExpressRoute/VPN to on-prem, **or** confirm the help desk is already reachable from the chosen VNet. |
| DNS resolution | The VNet's DNS must resolve `helpdesk.int.inceptionai.ai` — i.e. custom DNS servers pointing at corporate DNS, or an Azure DNS Private Resolver / forwarder to corporate DNS. |
| Outbound to Azure APIs | Allow egress (443) to `graph.microsoft.com` and `management.azure.com` (NSG / firewall). |
| Inbound access | Restrict to the operator/team only. Prefer **no public IP**; access the dashboard via the private IP over the corp network, or via **Azure Bastion** for admin. Open only the app port (see §4) to the internal subnet, plus 3389/22 via Bastion. |

**Confirmation to request from networking:** "From a VM in `snet-azuresentry-app`, can we (a) resolve and (b) reach `helpdesk.int.inceptionai.ai:443`?" — this is the go/no-go check.

---

## 3. VM specification

| Attribute | Value | Notes |
|---|---|---|
| Name | `vm-azuresentry-uaen-01` | |
| Region | UAE North (`uaenorth`) | Same as help desk latency domain / existing footprint |
| OS | **Windows Server 2022** | Runs the existing PowerShell `HttpListener` unchanged. (Linux + PowerShell 7 also works but changes `http.sys`/service setup.) |
| Size | **Standard_B2s** (2 vCPU / 4 GB) to start | Low-traffic internal tool; scale to B2ms/B4ms if needed. Burstable = cost-optimized. |
| Disk | Standard SSD, 127 GB OS disk | No data disk needed |
| Public IP | **None** (private only) | Access via corp network / Bastion |
| Identity | **System-assigned Managed Identity** | Used for Graph + ARM grant calls — no secrets |
| Availability | Single instance (dev/demo) | Add availability set / second instance only if it becomes production-critical |
| Auto-shutdown | Optional dev cost control | e.g. shut down outside working hours |

---

## 4. Application setup on the VM

1. **Install prerequisites:** Windows PowerShell 5.1 is built in; install **Azure CLI** (for token acquisition / diagnostics) and **Node isn't required at runtime** (frontend is pre-built).
2. **Deploy the app payload** (same layout as the local run and the earlier deploy package):
   - `dashboard/api/` (Start-DashboardApi.ps1, config.json, DemoData.ps1, AzurePim.ps1)
   - `dashboard/web/dist/` (pre-built React UI)
   - `src/RbacDecision/`, `src/PimClient/`
3. **Configuration** (as machine environment variables, not a committed `.env`):
   - `MANAGE_ENGINE_URL=https://helpdesk.int.inceptionai.ai/`
   - `MANAGE_ENGINE_API_KEY=<key>`  *(store in Key Vault; fetch via the VM's managed identity)*
   - `AZURE_SUBSCRIPTION_ID`, `AZURE_SUBSCRIPTION_NAME`
   - `AZURESENTRY_PIM_CLIENT=Graph`  *(flip from Mock to real once permissions land)*
4. **Bind the listener:** on a VM there is no `http.sys` sandbox. Reserve the URL once (elevated) and run the listener on a fixed port:
   - `netsh http add urlacl url=http://+:8787/ user="NT AUTHORITY\NETWORK SERVICE"`
   - (Firewall) allow inbound 8787 from the internal subnet only.
5. **Run as a service** so it survives reboots/logoff — install the listener as a Windows Service (e.g. via NSSM) or a Scheduled Task at startup, running `Start-DashboardApi.ps1 -Port 8787`.
6. **Access:** browse to `http://<vm-private-ip>:8787` from the corp network. (Optional: put an internal reverse proxy / App Gateway with a friendly internal hostname + TLS in front.)

---

## 5. Managed identity — exact permissions

The VM's **system-assigned managed identity** replaces the automation SP as the grant executor. It needs the same access described in `docs/graph-consent-request.md`, assigned to **the VM's identity** (its object ID becomes known after VM creation):

| # | Permission | Type | Scope | Why |
|---|---|---|---|---|
| 1 | `PrivilegedAccess.ReadWrite.AzureResources` | Microsoft Graph — application | Tenant (admin consent) | Create/read Azure resource PIM assignment & eligibility requests (the grant step) |
| 2 | `User.Read.All` | Microsoft Graph — application | Tenant (admin consent) | Resolve requester UPN/email → Entra Object ID |
| 3 | **User Access Administrator** | Azure RBAC | Sandbox subscription(s) under `mg-incep-sandbox` (prod later) | Create role assignments for other users (Contributor's `notActions` deny this) |
| 4 | **Key Vault Secrets User** | Azure RBAC | Key Vault holding the ManageEngine token | Fetch the API key at runtime instead of an env var |
| 5 | **Reader** | Azure RBAC | Target subscription(s) | Validate subscription + duplicate-assignment detection |

> Least privilege: scope items 3 & 5 to the sandbox management group / subscription only (not tenant root). Item 3 can be a **PIM-eligible** assignment so each use is activated and logged. All actions land in the Azure Activity Log + our Log Analytics audit trail.

**Grant requests to raise:**
- Global Admin / PRA → items 1, 2 (Graph admin consent on the VM's managed identity), and item 3 (UAA).
- Cloud team → items 4, 5.

---

## 6. Provisioning outline (once networking confirms §2)

```powershell
# Variables
$rg   = 'rg-azuresentry-dashboard-uaen'      # existing RG (reuse) or a new one
$loc  = 'uaenorth'
$vnet = 'vnet-azuresentry-uaen'
$snet = 'snet-azuresentry-app'
$vm   = 'vm-azuresentry-uaen-01'

# (If networking provides the VNet, skip VNet/subnet creation and just reference them.)
az network vnet create -g $rg -n $vnet -l $loc --address-prefixes 10.50.0.0/24 `
  --subnet-name $snet --subnet-prefixes 10.50.0.0/27

# VM: Windows Server 2022, B2s, no public IP, system-assigned identity
az vm create -g $rg -n $vm -l $loc `
  --image Win2022Datacenter --size Standard_B2s `
  --vnet-name $vnet --subnet $snet `
  --public-ip-address '""' `
  --assign-identity `
  --admin-username azsentryadmin --admin-password '<strong-password>'

# Capture the managed identity principalId for the permission requests above
az vm identity show -g $rg -n $vm --query principalId -o tsv
```

> Set the DNS on the VNet/NIC to the corporate DNS servers (per §2) so the VM resolves `helpdesk.int.inceptionai.ai`. Prefer Azure Bastion for admin access rather than a public IP / open RDP.

---

## 7. Validation checklist (run on the VM)

1. `nslookup helpdesk.int.inceptionai.ai` → resolves to the internal IP.
2. `Test-NetConnection helpdesk.int.inceptionai.ai -Port 443` → TCP succeeds.
3. `scripts/Test-ApiAccess.ps1` → target **8/8 PASS** (uses the VM managed identity token).
4. Browse `http://<vm-private-ip>:8787` → dashboard loads; Help Desk Tickets tab lists live tickets.
5. Process ticket **#2858** with `AZURESENTRY_PIM_CLIENT=Graph` → a **real** assignment is created and a note is written back to the ticket.

---

## 8. Cost note

A single `Standard_B2s` (2 vCPU / 4 GB) burstable VM is the primary cost, materially lower than an always-on Premium App Service plan or an AKS control plane + node pool. Add optional auto-shutdown for dev to cut it further. The existing App Service Plan (`asp-azsentry-dashboard-uaen`, P0v3) can be deleted once this VM is the chosen path — say the word and I'll tear it down.
