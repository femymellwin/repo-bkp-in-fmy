# Running AzureSentry locally

How to run the AzureSentry dashboard (React UI + PowerShell API) on your machine, in
either **Mock** mode (safe, no real Azure changes) or **Real** mode (live PIM grants via
the automation service principal).

## Prerequisites

- **Node.js** (for the Vite UI) and **PowerShell** (Windows PowerShell 5.1 is fine).
- **`.env`** at the repo root (gitignored). Copy `.env.example` and fill in:
  - `MANAGE_ENGINE_URL`, `MANAGE_ENGINE_API_KEY` — to fetch/annotate tickets.
  - `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET` — the automation SPN (Real mode only).
  - `AZURE_SUBSCRIPTION_ID` — default subscription.
- Network line-of-sight to ManageEngine (`helpdesk.int.inceptionai.ai`) for the ticket views.

## Quick start

Run from a **PowerShell** prompt at the repo root. Do not double-click the `.ps1` or run it from
cmd/Explorer — on many Windows setups that opens **Notepad** instead of executing the script.

```powershell
# Mock mode (default) - full flow, but grants are simulated. Nothing changes in Azure.
powershell -NoProfile -ExecutionPolicy Bypass -File .\dashboard\Start-Local.ps1

# Real mode - performs REAL time-bound PIM grants via the SPN.
powershell -NoProfile -ExecutionPolicy Bypass -File .\dashboard\Start-Local.ps1 -Mode Real
```

If you are already inside PowerShell, this also works:

```powershell
& .\dashboard\Start-Local.ps1 -Mode Real
```

Then open **http://localhost:5173** (Vite picks the next free port if 5173 is taken —
check the console output).

`Start-Local.ps1`:
- frees the API port if a stale listener is holding it,
- in `-Mode Real`, checks the SPN creds and acquires a token as a preflight (falls back to
  Mock if that fails),
- starts the API (port 8787), waits until healthy, then launches the Vite dev server.

`config.json` stays on `pimClient: Mock`, so **real grants only happen when you explicitly
pass `-Mode Real`**. After a successful Real start the API window must show:

`PIM client: Graph (REAL grants via automation SPN)`

If it still says Mock, the launcher fell back (missing `.env` SPN keys or token preflight failed) —
read the red ERROR lines in the Start-Local console. **Demo seed** activity rows always load for
the SLA/Expiry/Break-Glass prototype views; that does not mean PIM is mocked.

## Verify SPN access (before Real mode)

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Test-SpnAccess.ps1
# expect: 4/4 PASS (User.Read.All, Reader, UAA, ARM PIM write)
```

## Using the dashboard

1. **Help Desk Tickets** tab — live ManageEngine tickets.
2. Expand a ticket → the decision inputs auto-map from it (edit if needed).
3. **Evaluate Decision** → shows the 7-step trace and the action (Grant / Eligible / Reject / Hold / Break-Glass).
4. **Process Ticket — Grant Access** → runs the PIM operation and posts a requester-visible note (`show_to_requester` + `notify_technician`). On your ME instance that fires the **"Note has been added"** email to the requester automatically (Admin → Notification Rules).
   - In Real mode this creates a **time-bound** PIM assignment (Sandbox = active; Production = eligible/approval).
   - Processed tickets keep a green **Processed** badge and a grant summary **across reloads**
     (persisted server-side in `dashboard/api/processed-tickets.json`, gitignored).

## Idempotency (no double grants)

Processing the same ticket twice does **not** create a second grant:
- **Ticket-level:** if the ticket already has an active grant on record, the API returns the
  existing result (`alreadyProcessed = true`) without granting again.
- **Assignment-level:** before granting, the API queries live PIM for an existing assignment
  of the same user/role/scope; if found, the decision engine returns
  `Reject / Duplicate-Assignment` (spec §3 step 7).

## PIM Role Settings (guardrails)

Apply the §6.1/§6.2 policy guardrails (90-day cap, no permanent active, approval/MFA) to a
subscription:

```powershell
./infra/pim/Set-PimRoleSettings.ps1 -SubscriptionId <sub> -Environment Sandbox           # dry-run
./infra/pim/Set-PimRoleSettings.ps1 -SubscriptionId <sub> -Environment Sandbox -Apply     # apply
```

Already applied to the sandbox `inception-ai-Sandbox` (`efae0e0e`).

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Failed to start HTTP listener ... conflicts with an existing registration" | A stale API process holds port 8787. `Start-Local.ps1` clears it automatically; or kill the `powershell` process running `Start-DashboardApi`. |
| Tickets don't load | Not on the corp network/VPN (ManageEngine unreachable), or ME creds missing in `.env`. |
| Real mode says "Falling back to Mock" | SPN creds missing/invalid in `.env`; run `scripts/Test-SpnAccess.ps1`. |
| Grant returns a PIM error | Run `scripts/Test-SpnAccess.ps1`; the SPN needs UAA + `User.Read.All` on the target. |
