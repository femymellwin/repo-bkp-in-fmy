Goal: Currently all tickets are treated as if they are Azure Subscription templates, this needs to be refactored so that depending on the ticket template, the placeholders will resemble exactly what the user specified. 

All temapletes must  have the requesters information, The category and subcategory, Description and subject and status. This needs to be shown on each ticket in the Azure UI.

Below I specify the mandatory fields supplied by the user on ME, they need to be show in the UI (Note some already do, do not repeat the fields if they already exist). 

Note: Keep the Template type in the UI, but dont repeat string "template" anywhere else except where it already exists.

Additional Context:Their are two types of templates that then branch out to other templates: Incident template that has an 1 category ("Others") with 3 types of subcategories and service templates that have 4 categories and their respecitive subcategories

Service Templates:
- Access Management Templates:
    Subcategories:
        - 1Password:
            * Item
            * Category	
            * Subcategory
            * Subject
            * Description
        -Cursor:
            * Category	
            * Subcategory
            * Subject
            * Description

        -Github Enterprise:
            * Category	
            * Subcategory
            * Environment	
            * Item
            * Exception Request 		
            * Request Type
            * Subject
            * Description

        - Azure subscription:
            * Subscription	
            * Azure Role	
            * Exception Request 	
            * Environment	
            * Request Type
            * Description
        -ADO:
            * Request Type	
            * Category
            * Subcategory	
            * Item
            * Exception Request 	
            * Environment	
            * Subject
        -General Access:
            * Category	
            * Subcategory	
            * Item
            * Business Justification	
            * Subject	
            * Description
 
- Azure Templates:
    Subcategories:
        - Infrastructure:
            * Category		
            * Subcategory
            * Item
            * Business Justification	
            * Subject	
            * Description
        - Networking:
            * Category	
            * Request Type	
            * Source IP	
            * Destination IP	
            * Port	
            * Access Direction	
            * Subcategory	
            * Item
            * Source IP Description	
            * Destination IP Description	
            * Protocol (TPC/UDP)	
            * Access Type	
            * Business Justification	
            * Subject	
            * Description
        -MLOps:
            * Category	
            * Subcategory
            * Item
            * Subject	
            * Description
        -Policy Exemptions:
            * Category	
            * Subcategory
            * Item
            * Business Justification	
            * Subject	
            * Description
        -New Project:
            * Category	
            * Subcategory
            * Item
            * Business Justification	
            * Subject	
            * Description
        -Cortex:
            * Category	
            * Subcategory
            * Item
            * Environment	
            * Request Type
            * Subject	
            * Description

- Infosec Templates:
    Subcategories:
        - Infosec:       
            * Category	
            * Subcategory
            * Item	
            * Business Justification 	
            * Subject
        - Security Assesment:
            * Category
            * Subject

- DevOps Access Templates:
    Subcategories:
        -DevOps Access:
            * Category	
            * Item
            * Business Justification		
            * Subcategory
            * Request Type		
            * Subject

Incident Templates
    - Others template:
        -Report and Issue Template:
            * Category	
            * Subject	
            * Description
        -Other Request Template:
            * Subject	
            * Description
        -SOC:
            * Subject	
            * Description





