# Azure RBAC & PIM Agentic Platform — Build Plan

**Authority:** `docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md` (scope §13 defines phases and exit criteria)  
**Status:** Active — code complete through Phase 4 authoring; **operational exit gates not met**  
**Last updated:** 2026-06-27  
**Audience:** Cloud Engineering, Cloud Governance, Security & Compliance

> **Document hierarchy (2026-06-27):** This file is the **single engineering plan**.  
> `progress.md` is the **living status tracker** for the same phases.  
> `.azure/deployment-plan.md` is **superseded** — deploy commands and validation proof are folded into **§7 Phase 3** and **§9** below. Keep `.azure/deployment-plan.md` only as a historical Azure-plugin artifact until removed.

---

## 1. Guiding principles

1. **The decision tree is the security boundary** — pure, deterministic, unit-testable PowerShell (`Resolve-RbacDecision`); no LLM on access-control paths (scope §3.2).
2. **No standing access** — every grant is time-bound via PIM; expiry enforced natively (scope §4.1, §9).
3. **Least privilege for the platform** — system-assigned MI, minimum Graph scopes, secrets in Key Vault only (scope §8.3, §9).
4. **Mock-first, swap-later** — all Graph/PIM access via `IPimClient`; mock for CI, Graph for live (D5).
5. **Every decision is auditable** — structured Log Analytics records keyed on ticket ID (scope §10) — *not yet wired*.
6. **Fail closed** — ambiguity, missing field, or unrecognised subscription → reject.

---

## 2. Decision log

Items marked **⚠ deviation** need Cloud Governance sign-off (Phase 1).

| # | Decision | Choice | Rationale |
|---|----------|--------|-----------|
| D1 | 7-step decision tree location | **⚠** `Resolve-RbacDecision` PS module; Logic App is thin router | Testable security boundary; behaviour identical to scope §3.2 |
| D2 | Eligibility matrix | JSON data file (`eligibility-matrix.json`) | Governance reviews data, not code |
| D3 | Logic App hosting | Logic App Standard | Workflow JSON in repo; local debug |
| D4 | IaC | Bicep, modular | Scope-sanctioned |
| D5 | Graph/PIM access | `IPimClient` → `MockPimClient` + `GraphPimClient` | Decouples build from P2 licensing |
| D6 | Approval capture | Status-Updater + Logic App polling (Event Grid later) | MVP on polling per §8.1 |
| D7 | Idempotency | Ticket ID + dedup check before grant | §4.1 step 5 |
| D8 | Partial failure | PIM-first; ticket update with retry; LA as source of truth | Audit gap mitigation |
| D9 | Secrets | Key Vault via MI | §9 — no secrets in runbooks |

---

## 3. Spec gaps — status

| Gap | Resolution | Code status | Blocks |
|-----|------------|-------------|--------|
| G1 Requester ≠ submitter | Reject on UPN mismatch | **Implemented** (`Test-TicketSchema.ps1`) | — |
| G2 Webhook auth | KV shared secret header + SAS | **Implemented** (Logic App) | IP allowlist not coded |
| G3 Break-glass 4h revocation | Scheduled reaper runbook | **Runbook authored**; no schedule, no grant store | Phase 4 integration |
| G4 Hold for review | Governance queue + notify | **Decision returns Hold**; no queue/notify | Phase 4 / governance process |
| G5 Cross-subscription | Senior approver path | **Implemented** | — |
| G6 Permanent assignment conflicts | Pre-go-live audit + dedup | Dedup for active PIM only | Phase 5 live tests |

---

## 4. Phase dependency map

Phases are **sequential for exit gates** but **parallel tracks** are possible within engineering.

```
Phase 1 (Design)
  ├─ HARD ──► Approver mapping ──► Phase 2 PIM Role Settings
  ├─ HARD ──► Prod allowlist ─────► Prod runbook live / Phase 2 prod config
  ├─ HARD ──► ME ticket template ─► Phase 4 webhook loop
  ├─ HARD ──► Break-glass process ► Phase 7 prod enablement (emergency)
  └─ SOFT ──► Sign-offs ──────────► Phase 6–8 formal gates only

Phase 2 (PIM Config) ──► Graph consent + Role Settings ──► Phase 3 live GraphPimClient
                              │
Phase 3 (Build Core) ◄────────┘ (Sandbox E2E needs Graph consent, NOT approver mapping)
  ├─ Deploy infra + runbooks
  └─ EXIT: Sandbox auto-assign on real Azure

Phase 4 (Build Extended) ── depends on Phase 3 deploy + Phase 1 ME template
  └─ EXIT: ME webhook → Logic App → all runbooks deployed

Phase 5 (Integration Test) ── depends on Phase 3–4 live paths
Phase 6 (UAT) ── depends on Phase 5 + Phase 1 sign-offs
Phase 7 (Go-Live) ── depends on Phase 2 prod PIM + Phase 6
Phase 8 (Handover) ── depends on Phase 7
```

**Critical path to first real value (Sandbox E2E):** Phase 2 technical (Graph consent) → Phase 3 deploy — **does not require** full Phase 1 closure.

---

## 5. Repository structure

```
AzureSentry/
├─ docs/
│  ├─ Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md   ← specification (authority)
│  ├─ BUILD_PLAN.md                                  ← this file
│  ├─ DEMO_GUIDE.md
│  └─ progress.md                                    ← live status per §13
├─ src/
│  ├─ RbacDecision/          ← decision engine + eligibility-matrix.json
│  ├─ PimClient/             ← GraphPimClient + MockPimClient + IPimClient.psd1
│  └─ Runbooks/              ← 6 runbooks (router + 5 specialised)
├─ infra/
│  ├─ main.bicep + modules/
│  └─ policy/sandbox-guardrails.bicep
├─ logicapp/workflows/orchestrator/
├─ dashboard/                ← prototype (Deliverable #10 stand-in)
├─ tests/
│  ├─ unit/ + contract/
│  ├─ Run-Pester.ps1
│  └─ Run-LocalE2E.ps1
├─ kql/                      ← MISSING (Deliverable #10)
├─ pipelines/                ← MISSING (CI)
└─ .azure/deployment-plan.md   ← SUPERSEDED — see §9
```

---

## 6. Component reference (condensed)

| Component | Path | Scope ref |
|-----------|------|-----------|
| Decision engine | `src/RbacDecision/` | §3.2, §2.2 |
| PIM abstraction | `src/PimClient/` | §8.2, D5 |
| Sandbox runbook | `Runbook-Sandbox-PIM.ps1` | §4.1 |
| Prod runbook | `Runbook-Prod-PIM.ps1` | §5.1 |
| Emergency runbook | `Runbook-Emergency-PIM.ps1` | §5.4 |
| Status updater | `Runbook-Status-Updater.ps1` | §8.2 |
| Break-glass reaper | `Runbook-BreakGlass-Reaper.ps1` | G3, §5.4 |
| Decision router | `Runbook-Decision-Router.ps1` | D1 entry point |
| Orchestrator | `logicapp/workflows/orchestrator/workflow.json` | §8.1 |
| Platform IaC | `infra/main.bicep` | §8.1, §11 #1 |
| Sandbox policy | `infra/policy/sandbox-guardrails.bicep` | §11 #8 |

---

## 7. Implementation milestones (scope §13)

Ordered phases with **exit criteria**, **deliverables**, **dependencies**, and **current blockers**.

---

### Phase 1 — Design

| | |
|---|---|
| **Duration (scope)** | Week 1 |
| **Owner** | Project Lead |
| **Exit criteria** | Scope doc signed off; **approver mapping complete** |
| **Gate met?** | ✅ **YES — CLOSED 2026-07-09** (design signed off, `docs/phase1-signoff.md`; approver mapping complete). 1.5/1.7/1.8 carried forward to their phases |

#### Ordered checklist

| # | Item | Depends on | Blocks | Status |
|---|------|------------|--------|--------|
| 1.1 | Scope document in repo | — | — | ✅ Done |
| 1.2 | Build plan (this file) | 1.1 | — | ✅ Done |
| 1.3 | Stakeholder sign-off (§16) | 1.1 | Phase 6–8 formal gates | ✅ Signed off 2026-07-09 (`docs/phase1-signoff.md`) |
| 1.4 | **Approver mapping** (§6.3) — per sub, per role | Cloud Governance input | **Phase 2**, prod approval | ✅ `docs/approver-mapping.md` + `approver-mapping.json` |
| 1.5 | Production subscription allowlist | Cloud Governance | Prod live tests, Phase 2 prod | ⏭️ Carried forward → Phase 2-prod / Phase 7 |
| 1.6 | Sandbox subscription allowlist | Cloud Governance | Sandbox live E2E config | ✅ `inception-ai-Sandbox` (`efae0e0e`) confirmed 2026-07-09 |
| 1.7 | Break-glass authorization process (§5.4) | Security + Governance | Phase 7 emergency enablement | ⏭️ Carried forward → Phase 7 |
| 1.8 | ManageEngine ticket template + webhook schema (§7) | IT Ops | **Phase 4** webhook loop | ⏭️ Carried forward → Phase 4 |
| 1.9 | D1 deviation sign-off | 1.3 | — | ✅ Covered by design sign-off 2026-07-09 |
| 1.10 | BUILD_PLAN gap resolutions G3–G6 accepted | 1.3 | — | ✅ Accepted in sign-off (G3/G4 impl continues in Phase 4) |

**What Phase 1 does *not* block:** mock tests, code authoring, infra deploy, Sandbox live E2E (no approvers needed on sandbox).

---

### Phase 2 — PIM Config

| | |
|---|---|
| **Duration (scope)** | Week 2 |
| **Owner** | Cloud Governance |
| **Exit criteria** | PIM policies active in non-prod; **P2 licences confirmed** |
| **Gate met?** | **Local/non-prod: near** — PIM policies active on sandbox (2.7); sole gate = **2.1 P2 written confirm** (evidence: `docs/phase2-p2-evidence.md`). 2.6 N/A-local; 2.8–2.10 scoped to prod go-live |

#### Ordered checklist

| # | Item | Depends on | Blocks | Status |
|---|------|------------|--------|--------|
| 2.1 | Entra ID P2 confirmed (requesters + approvers) | IT/Procurement | All live PIM | ⚠️ Functionally proven (grants + role-settings PATCH succeeded); written confirm pending — memo `docs/phase2-p2-evidence.md` |
| 2.2 | Automation identity created | — | — | ✅ **Canonical = `e2455957-…`** (obj `eabb6fe0-…`, UAA + User.Read.All). Legacy `d68581f3-…` superseded |
| 2.3 | UAA @ `mg-incep-sandbox` | 2.2 | Policy deploy, sandbox subs | ✅ Verified; SPN `e2455957` UAA on sandbox + live subs |
| 2.4 | ~~Graph consent: `PrivilegedAccess.ReadWrite.AzureResources`~~ | — | — | ✅ **N/A — obsolete.** Azure resource PIM = ARM+UAA, not Graph (`azureResources` segment doesn't exist) |
| 2.5 | Graph consent: `User.Read.All` | — | UPN resolution | ✅ Verified PASS on SPN `e2455957` |
| 2.6 | Automation MI credentials (deployed account) | Phase 3 deploy | Runbooks as platform identity | ⏭️ **N/A for local** — SPN `e2455957` is the local automation identity; MI deferred to Azure deploy (Phase 3) |
| 2.7 | Sandbox PIM Role Settings (§6.1) | ~~B3~~ ✅ | Correct sandbox behaviour | ✅ **Applied + verified 2026-07-09** on `inception-ai-Sandbox` (`efae0e0e`): no permanent active + 90-day cap, Reader+Contributor |
| 2.8 | Production PIM Role Settings (§6.2) | 2.9 | Prod approval path | ⏭️ **Out of scope for local/non-prod close** (prod go-live). IaC ready |
| 2.9 | Approvers assigned in PIM | ~~1.4~~ ✅ | Prod approvals meaningful | ⏭️ **Out of scope for local/non-prod close** (prod go-live). Data ready; `-SetApprovers` populates |
| 2.10 | Role Settings peer review | 2.7–2.9 | Prod enablement | ⏭️ **Out of scope for local/non-prod close** — Cloud Governance sign-off for prod |
| 2.11 | `pim-rolesettings` IaC in repo | — | Repeatable config | ✅ **`infra/pim/`** — config JSON + `Set-PimRoleSettings.ps1` + README (2026-07-08) |

---

### Phase 3 — Build Core

| | |
|---|---|
| **Duration (scope)** | Weeks 3–4 |
| **Owner** | Cloud Engineer |
| **Exit criteria** | **Sandbox auto-assign working end-to-end in dev environment** |
| **Gate met?** | **No** — code ~90%; **not deployed; not live on Azure** |

#### Code complete (do not re-build)

| Deliverable | Path | Tests |
|-------------|------|-------|
| Decision engine + §2.2 matrix | `src/RbacDecision/` | 21 unit cases |
| Sandbox runbook | `Runbook-Sandbox-PIM.ps1` | Via E2E harness |
| Prod runbook | `Runbook-Prod-PIM.ps1` | 8 unit cases |
| Decision router | `Runbook-Decision-Router.ps1` | E2E harness |
| Logic App skeleton | `logicapp/` | Manual |
| Platform Bicep | `infra/main.bicep` + modules | `az bicep build` clean |
| Azure Policy (authored) | `infra/policy/sandbox-guardrails.bicep` | Bicep compile clean |
| PIM clients | `GraphPimClient` + `MockPimClient` | 9 contract cases |

**Test suite:** 69/69 Pester; 5/5 mock local E2E (`tests/Run-LocalE2E.ps1`).

#### Ordered deploy + integration checklist

| # | Item | Depends on | Blocks | Status |
|---|------|------------|--------|--------|
| 3.1 | Bicep validate / what-if proof | Deployer Contributor on sub | 3.2 | ✅ Validated (historical) |
| 3.2 | Deploy infra (`deployRbac=false`) | 3.1, cost approval | All runtime | ❌ Not deployed |
| 3.3 | Apply platform RBAC (`deployRbac=true`) | 3.2, deployer UAA/Owner | MI → KV/LA/AA access | ❌ Not done |
| 3.4 | Upload all runbooks to Automation | 3.2 | Live execution | ❌ Not done |
| 3.5 | Set Automation env vars | 3.4 | Router dispatch | ❌ Not done |
| 3.6 | Deploy Logic App workflow (zip) | 3.2 | Webhook intake | ❌ Not done |
| 3.7 | Key Vault secrets (webhook secret, ME token) | 3.2 | G2 auth, Status-Updater | ❌ Not done |
| 3.8 | Deploy Azure Policy to `mg-incep-sandbox` | 2.3 | §9 Owner/UAA sandbox block | ❌ Authored only |
| 3.9 | Target sandbox subscription ID | 1.6 or ops decision | Live sandbox grant scope | ❌ Open |
| 3.10 | **Live Sandbox E2E** (GraphPimClient) | 2.4, 2.5, 3.2–3.5, 3.9 | **Phase 3 exit** | ❌ **Exit gate** |
| 3.11 | Post-grant ticket update wired | 3.10, Status-Updater | Full §4.1 step 10 | ❌ Not wired |
| 3.12 | Log Analytics decision events | 3.2 | §10 auditability | ❌ Not implemented |

#### Phase 3 deploy commands (from superseded deployment plan)

```powershell
# 1. Infra without RBAC assignments (Contributor sufficient)
az deployment sub create --location uaenorth `
  --template-file infra/main.bicep `
  --parameters infra/main.parameters.json deployRbac=false

# 2. Platform RBAC (requires UAA or Owner on subscription)
az deployment sub create --location uaenorth `
  --template-file infra/main.bicep `
  --parameters infra/main.parameters.json deployRbac=true

# 3. Sandbox policy (requires UAA on mg-incep-sandbox)
az deployment mg create --management-group-id mg-incep-sandbox --location uaenorth `
  --template-file infra/policy/sandbox-guardrails.bicep
```

**Azure context:** subscription `inception-internal-product` (`5a23842e-…`), tenant `5ac4936b-…`, region `uaenorth`, RG `rg-azuresentry-dev-incp-uaen-001`. Sandbox **PIM grants** should target a subscription under `mg-incep-sandbox`.

---

### Phase 4 — Build Extended

| | |
|---|---|
| **Duration (scope)** | Week 5 |
| **Owner** | Cloud Engineer + IT Ops |
| **Exit criteria** | **All runbooks deployed; webhook connected to Logic App** |
| **Gate met?** | **No** — runbooks authored; integration not wired |

#### Ordered checklist

| # | Item | Depends on | Blocks | Status |
|---|------|------------|--------|--------|
| 4.1 | Emergency runbook | — (code) | — | ✅ Authored + tested |
| 4.2 | Status-Updater runbook | — (code) | — | ✅ Authored + tested |
| 4.3 | BreakGlass-Reaper runbook | — (code) | — | ✅ Authored + tested |
| 4.4 | Publish all runbooks in Automation | **3.4** | Phase 4 exit | ❌ |
| 4.5 | ME webhook → Logic App HTTP trigger | **1.8**, 3.6 | Phase 4 exit | ❌ **Hard blocker** |
| 4.6 | Logic App PIM polling (5 min recurrence) | 3.6, 2.8 | Prod ticket closure | ❌ Not in workflow |
| 4.7 | Invoke Status-Updater on approve/deny/expiry | 4.6, 4.2 | §5.1 steps 9–10 | ❌ Not wired |
| 4.8 | BreakGlass-Reaper scheduled job (15 min) | 4.4, grant store | G3 enforcement | ❌ No schedule; no `TrackedGrants` store |
| 4.9 | P1 on-call notification channel | IT Ops | §5.2 expedited | ❌ Flags only in runbook output |
| 4.10 | Logic App error handling + alerts | 3.6 | §8.1 reliability | ❌ Not implemented |
| 4.11 | Logic App concurrency limit | 3.6 | §8.1 | ❌ Not implemented |
| 4.12 | ManageEngine configuration guide (§11 #9) | 1.8 | Handover | ❌ Missing |
| 4.13 | KQL workbook (§11 #10) | LA deployed | Phase 8 dashboards | ❌ `kql/` missing; dashboard is prototype |

---

### Phase 5 — Integration Test

| | |
|---|---|
| **Duration (scope)** | Week 6 |
| **Owner** | Cloud Engineer |
| **Exit criteria** | **All test cases pass; zero P1 defects** |
| **Gate met?** | **No** — mock only |

#### Ordered checklist

| # | Item | Depends on | Status |
|---|------|------------|--------|
| 5.1 | Unit + contract tests (69) | — | ✅ 69/69 |
| 5.2 | Mock local E2E (5 paths) | — | ✅ 5/5 |
| 5.3 | `tests/e2e/` live-Azure scenarios (§11 #11) | **3.10**, 4.5–4.7 | ❌ Missing |
| 5.4 | CI pipeline (`pipelines/`) | — | ❌ Missing |
| 5.5 | Full matrix on GraphPimClient (not dashboard ARM shortcut) | 2.4, 3.10 | ❌ |
| 5.6 | Defect triage — zero P1s | 5.3–5.5 | ❌ |

**Required live scenarios (scope §11 #11):** sandbox auto, prod approval, prod denial, expiry, duplicate, break-glass, schema validation; all priority tiers.

---

### Phase 6 — UAT

| | |
|---|---|
| **Duration (scope)** | Week 7 |
| **Owner** | Stakeholders |
| **Exit criteria** | **UAT sign-off from Cloud Governance, IT Ops, Security** |
| **Gate met?** | **No** |

| # | Item | Depends on |
|---|------|------------|
| 6.1 | UAT plan — every §2.2 row + P1–P4 | 5.6 |
| 6.2 | Governance dry-run (dual approval, hold, break-glass review) | 4.7, **1.4** |
| 6.3 | IT Ops dry-run (ME webhook + ticket lifecycle) | 4.5 |
| 6.4 | Security dry-run (alerts, audit, policy blocks) | 3.8, 4.8 |
| 6.5 | Written sign-off | **1.3**, 6.1–6.4 |

---

### Phase 7 — Prod Go-Live

| | |
|---|---|
| **Duration (scope)** | Week 8 |
| **Owner** | Cloud Governance |
| **Exit criteria** | **20 production tickets without manual portal grants** |
| **Gate met?** | **No** |

| # | Item | Depends on |
|---|------|------------|
| 7.1 | Production PIM Role Settings enabled | **2.8**, **1.4**, 6.5 |
| 7.2 | Production allowlist in deployed config | **1.5** |
| 7.3 | Rollback plan documented | 6.5 |
| 7.4 | On-call rota + escalation live | **1.7**, 4.9 |
| 7.5 | Monitor first 20 prod tickets | 7.1–7.4 |

---

### Phase 8 — Handover

| | |
|---|---|
| **Duration (scope)** | Week 9 |
| **Owner** | Cloud Engineer |
| **Exit criteria** | **Training completed; dashboards validated; doc delivered** |
| **Gate met?** | **No** |

| # | Item | Depends on | Status |
|---|------|------------|--------|
| 8.1 | KQL dashboards live in Log Analytics | 4.13, 3.12 | ❌ |
| 8.2 | Reviewer training guide (§11 #12) | — | ❌ Missing |
| 8.3 | Operational runbook (incidents, failed runs, reconciliation) | 7.5 | ❌ |
| 8.4 | Engineering runbook (env vars, secrets rotation) | 3.4 | ❌ |
| 8.5 | Training session + attendance | 8.2 | ❌ |

---

## 8. Testing strategy

| Layer | Command / path | Azure? | Phase |
|-------|----------------|--------|-------|
| Unit + contract | `powershell -File tests\Run-Pester.ps1` | No | 3+ ✅ |
| Mock E2E | `powershell -File tests\Run-LocalE2E.ps1` | No | 3+ ✅ |
| Live Sandbox smoke | Manual / future `tests/e2e/` | Yes | 3 exit |
| Full §11 suite | `tests/e2e/` (to create) | Yes | 5 exit |
| Dashboard live PIM | `dashboard/` Live PIM tab | Yes (ARM token) | Demo only — not runbook path |

---

## 9. Azure deploy reference (supersedes `.azure/deployment-plan.md`)

### Workflow gate

`azure-prepare` → `azure-validate` → `azure-deploy` — never skip validate before what-if or deploy.

### Platform resources

| Resource | Name |
|----------|------|
| Resource group | `rg-azuresentry-dev-incp-uaen-001` |
| Logic App | `la-azsentry-dev-uaen` |
| Automation Account | `aa-azsentry-dev-uaen` |
| Key Vault | `kv-azsentry-dev-uaen` |
| Log Analytics | `log-azsentry-dev-uaen` |
| App Service Plan | `asp-azsentry-dev-uaen` (WS1) |
| Storage | `stazsentrydev001` |

### RBAC model

- `deployRbac=false` — infra only; deployer needs **Contributor** on subscription.
- `deployRbac=true` — creates 4 platform MI role assignments; deployer needs **User Access Administrator** or **Owner**.
- Split deploy documented in pre-deploy audit (2026-06-24).

### Validation proof (2026-06-24)

- `az bicep build` / `az bicep lint` — pass  
- MCP `bicepschema_get` — 6 ARM types pass  
- What-if with `deployRbac=false` — 7 Create / 0 Unsupported  
- Log Analytics Contributor GUID corrected in `rbac-platform-identities.bicep`  
- Estimated cost ~USD 215–290/mo (WS1-dominated)

---

## 10. Cross-phase blocker summary

| Blocker | Owner | Unblocks |
|---------|-------|----------|
| Graph admin consent on automation SP | Global Admin / PRA | Phase 3 live E2E, Phase 5 |
| Infra deploy + cost approval | Cloud Engineer | Phase 3–4 runtime |
| Target sandbox sub under `mg-incep-sandbox` | Cloud Team / Governance | Phase 3 sandbox grant |
| ~~Approver mapping~~ | Cloud Governance | ✅ Resolved — `approver-mapping.json` wired |
| ME webhook + ticket template | IT Ops | Phase 4 exit |
| Break-glass process + Security sign-off | Governance + Security | Phase 7 emergency |
| Stakeholder sign-offs | All §16 roles | Phase 6–8 formal gates |

---

## 11. Parallel execution tracks (recommended)

| Track A — Engineering (start now) | Track B — Governance (parallel) |
|-----------------------------------|----------------------------------|
| Deploy infra + Graph consent | Approver mapping |
| Live Sandbox E2E | Prod/sandbox allowlists |
| Wire LA polling + Status-Updater | ME webhook + template |
| Log Analytics events + KQL | Break-glass process doc |
| `tests/e2e/` + CI pipeline | Stakeholder sign-offs |

**First exit gate reachable without Track B:** Phase 3 — Sandbox auto-assign in dev.

---

## 12. Dashboard prototype — current state & future build

The `dashboard/` tree is a **parallel deliverable** to the Automation/Logic App pipeline. It does not replace §11 #10 (KQL workbook) but is the working UI prototype used for demos, engineering smoke tests, and stakeholder walkthroughs. **Current progress is retained here** so it is not lost when tracking §13 platform phases.

### 12.1 Current progress (shipped)

| Component | Path | Status |
|-----------|------|--------|
| React UI (9 views) | `dashboard/web/src/` | ✅ Overview, Simulator, Live PIM, Audit, SLA, Expiry, Break-Glass, Matrix, Architecture |
| REST API | `dashboard/api/Start-DashboardApi.ps1` | ✅ Decision evaluate/simulate + monitoring endpoints |
| Live PIM client | `dashboard/api/AzurePim.ps1` | ✅ ARM token path; activate/deactivate on real subscription |
| Seed monitoring data | `dashboard/api/DemoData.ps1` | ✅ 14 illustrative records for SLA/expiry/break-glass/audit |
| Decision gating on live activate | `/api/pim/activate` | ✅ Reject/Hold blocked before any Azure call |
| Demo guide + preflight | `docs/DEMO_GUIDE.md`, `Invoke-DemoPreflight.ps1` | ✅ 10–12 min run-of-show |
| Live activation proof | `inception-internal-product` | ✅ 1h Contributor activation verified 2026-06-25 |

**Not production observability:** monitoring tabs use seed/session data until Log Analytics is wired (see §12.2).

### 12.2 Future build plan (ordered)

| # | Deliverable | Phase | Depends on | Priority |
|---|-------------|-------|------------|----------|
| D1 | Emit decision/PIM events to Log Analytics from runbooks | 3 | 3.2 deploy, 3.9 | **P0** — unblocks real audit |
| D2 | Dashboard reads LA instead of `DemoData.ps1` | 4 / 8 | D1 | P1 |
| D3 | Author `kql/` queries matching dashboard views | 4 | D1, 4.12 | P1 — §11 #10 |
| D4 | Azure Monitor Workbook publish (official Deliverable #10) | 8 | D3, Phase 7 | P1 — handover |
| D5 | Dashboard ticket POST → Logic App webhook (dev intake test) | 4 | 4.5 ME webhook | P2 |
| D6 | Live break-glass panel from reaper grant store | 4 | 4.8 | P2 |
| D7 | Live SLA panel from PIM approval timestamps | 5 | 4.6 polling | P2 |
| D8 | Preflight + Live PIM: optional GraphPimClient / automation SP path | 5 | B1 | P2 — aligns dashboard with runbooks |
| D9 | Approver mapping read-only panel (PIM Graph) | 2 | 1.4, 2.8 | P3 |
| D10 | Refresh `DEMO_GUIDE.md` — M5–M6 runbooks now exist (mock-tested) | 3 | — | P3 — doc drift |

### 12.3 Dashboard vs platform pipeline

```
Stakeholder demo (today):
  Browser → Dashboard API → Resolve-RbacDecision → ARM PIM (operator az token)

Production target (Phase 3–4 exit):
  ManageEngine → Logic App → Automation Runbook → GraphPimClient → Azure PIM
                              ↘ Log Analytics → KQL Workbook (Phase 8)
                               ↘ Dashboard (optional LA-backed ops view)
```

The dashboard remains valuable **after go-live** as an engineering console; Phase 8 promotes D3–D4 to the official governance-facing workbook.

---

## 13. Engineering milestone cross-reference (legacy M1–M7)

Retained for traceability with earlier planning conversations. **Authoritative sequencing is §7 (scope §13 phases).**

| Legacy | Scope §13 | Status |
|--------|-----------|--------|
| M1 Decision engine | Phase 1 design + Phase 3 code | ✅ Complete |
| M2 Mock PIM + Sandbox runbook | Phase 3 code | ✅ Complete |
| M3 Bicep + Logic App skeleton | Phase 3 code | ✅ Authored; not deployed |
| M4 GraphPimClient live smoke | Phase 3 exit | ⚠️ Dashboard ARM path only; runbook Graph path blocked on B1 |
| M5 Prod + Status-Updater + Policy | Phase 3–4 code | ✅ Authored; not integrated |
| M6 Emergency + reaper + KQL | Phase 4 code | ✅ Runbooks authored; KQL/dashboard LA wire pending |
| M7 Live e2e + UAT + handover | Phases 5–8 | ❌ Not started |

---

*Aligned to scope §13. Update `progress.md` when phase status changes — including dashboard §12 progress.*
