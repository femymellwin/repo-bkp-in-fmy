# Unattended Ticket Poller — Operations Runbook

Auto-processes ManageEngine access requests with no human click, for the narrow slice
policy already allows. Design: `docs/superpowers/specs/2026-08-19-unattended-ticket-poller-design.md`.

## What it will and will not do

**Auto-grants** `Grant` decisions on **Sandbox** and **Non-Prod** only — in practice
`sandbox-reader`, `sandbox-contributor`, `nonprod-reader`.

**Always queues for a human:**
- Any `Eligible` decision (prod Contributor / Owner / UAA). Its approval gate is the
  operator clicking *Provide Access* in the dashboard.
- **All Production, including Reader** — `prod-reader-*` is `Grant` in the matrix with no
  approver, and is still excluded here.
- `Hold`, `Reject`, `BreakGlass`.
- Any ticket whose ME Subscription / Azure Role / Environment dropdown is blank,
  unmappable, or not on the allowlist by exact name.
- Any ticket whose effective environment is raised to Production by subscription
  sensitivity, even if it claimed Sandbox.
- Any NonProd or Production grant that has not first climbed the Sandbox -> NonProd ->
  Production promotion ladder for that requester + role — the same
  `Test-AccessPromotionLadder` check the dashboard's human grant path enforces
  (`accessPromotion.enforceLadder` in `config.json`). The unattended path must never be
  more permissive than the human one.

Production is `vm-incp-uaen-001-sentry` (Ubuntu 22.04, systemd). App at
`/opt/azuresentry`, env at `/etc/azuresentry.env`. All commands below run on the VM as root
unless noted.

## Enable it

1. Install the timer (safe — installing does not enable the poller). Run with `bash`,
   not as a relative `./` path: the file arrives on the VM non-executable (deploy does not
   set the execute bit on ordinary files it ships), so a bare `./install-poller-timer.sh`
   fails `Permission denied` even after `cd`-ing into the right directory:
   ```bash
   sudo bash /opt/azuresentry/infra/systemd/install-poller-timer.sh
   ```
2. Shadow-run one cycle by hand and read the output. Plain `sudo VAR=value pwsh ...` does
   not work on Ubuntu's default sudoers (`env_reset` strips the inline assignment before
   pwsh ever sees it), and it never sources `/etc/azuresentry.env` for the ME/SPN
   credentials either. Source the env file first, inside the same `sudo bash -c`:
   ```bash
   sudo bash -c 'set -a; . /etc/azuresentry.env; set +a; AZURESENTRY_POLLER_ENABLED=true \
     pwsh -NoProfile -File /opt/azuresentry/scripts/Invoke-TicketPollerCycle.ps1 -VerboseOutput'
   ```
3. Set `AZURESENTRY_POLLER_ENABLED=true` in `/etc/azuresentry.env`, leaving
   `AZURESENTRY_POLLER_MODE=shadow`. Then `sudo systemctl restart azuresentry-poller.timer`
   and watch the dashboard's Poller panel.
4. When the `WouldGrant` rows look right, flip to enforce -- either edit
   `AZURESENTRY_POLLER_MODE=enforce` in `/etc/azuresentry.env` and restart the timer, or
   use the dashboard's Enforce Mode toggle (below), which needs neither.

`granted` stays 0 in shadow, always. If shadow reports `granted > 0`, stop and
investigate — that is a bug, not a configuration state.

Follow the cycles with:
```bash
journalctl -u azuresentry-poller -f
systemctl list-timers azuresentry-poller.timer --no-pager
```

## Toggle Enforce Mode from the dashboard

The Unattended Ticket Poller panel (Dashboard tab) has an Enforce Mode control. It is the
same shadow/enforce switch as `AZURESENTRY_POLLER_MODE` in `/etc/azuresentry.env`, reached
without SSH access, an env-file edit, or a timer restart -- useful for the user-test flow
in `docs/DEMO_GUIDE.md` §8.

**How it works:** `POST /api/poller/mode` writes `dashboard/api/poller.mode`, a plain-text
file containing the word `enforce` or `shadow`. `Get-PollerConfig` (both here and in
`scripts/Invoke-TicketPollerCycle.ps1`) checks this file **before**
`AZURESENTRY_POLLER_MODE` -- when it exists, its content decides, full stop: it can turn
enforce OFF even if the env var still says `enforce`, and it can turn enforce ON even if
the env var still says `shadow`. Content that is neither exactly `enforce` nor `shadow`
(a half-written file, stray text) fails closed to `shadow`, the same contract the env var
itself already has. `DELETE /api/poller/mode` removes the file, handing control back to
`AZURESENTRY_POLLER_MODE` alone.

**What it does NOT do:**
- **No longer leaves the kill switch alone.** The dashboard's Automation control (Off /
  Rehearse / Live) composes this Enforce Mode override together with a second,
  independent enabled-override file: `POST`/`DELETE /api/poller/enabled` writes/clears
  `dashboard/api/poller.enabled`, a plain-text file containing `true` or `false`.
  `Get-PollerConfig` checks it **before** `AZURESENTRY_POLLER_ENABLED`, with the
  identical fail-closed, override-wins contract the mode file above already has: when it
  exists, its content decides, full stop, and content that is not exactly `true` (after
  trim + lowercase) resolves to `false` regardless of what the env var says. In other
  words, this control now DOES effectively flip the kill switch from the poller's
  perspective, without ever touching `AZURESENTRY_POLLER_ENABLED` itself -- see "Halt it"
  below for why that matters during an emergency stop. Turning the poller on for the very
  first time on a fresh install, with no override files present at all, still needs the
  server-side step in "Enable it" above.
- **Does not take effect immediately.** The poller is a separate process that starts fresh
  every cycle (5 minutes by default); the toggle changes what its *next* cycle will do, not
  the one already running. The dashboard panel shows this as two distinct facts, never
  merged: the **override** (the instruction you just set) and **last reported mode** (what
  actually happened on the most recent cycle) -- if they disagree, wait for the next cycle
  and refresh.
- **Requires a justification (≥4 characters) to switch to enforce.** Not required to switch
  back to shadow -- that direction only reduces blast radius. Both actions are written to
  the poller's own audit trail (`Write-AuditEvent`, action `SetModeOverride` /
  `ClearModeOverride`).

**Redeploy safety:** `scripts/Deploy-ToVm.ps1` excludes `poller.mode` and `poller.enabled`
from what it ships, the same way it already excludes `poller.stop` — a redeploy never
overwrites or clears a live override.

### The reaper has the identical control

The Grant Expiry Reaper panel (Dashboard tab) has its own Enforce Mode control, structured
identically: `POST`/`DELETE /api/reaper/mode` writes/clears `dashboard/api/reaper.mode`,
which `Get-ReaperConfig` checks ahead of `AZURESENTRY_REAPER_MODE` with the same
fail-closed contract, the same "next cycle, not immediately" caveat, and the same
≥4-character justification to switch to enforce. It also has the identical
enabled-override behaviour described above: `POST`/`DELETE /api/reaper/enabled`
writes/clears `dashboard/api/reaper.enabled`, checked ahead of `AZURESENTRY_REAPER_ENABLED`
with the same override-wins, fails-closed-to-`false` contract -- so this control no longer
leaves the `AZURESENTRY_REAPER_ENABLED` kill switch untouched either. `scripts/Deploy-ToVm.ps1`
excludes `reaper.mode` and `reaper.enabled` the same way.

**Worth setting up together, not the poller alone:** the poller's grants (Group fulfilment)
have no Azure-enforced expiry — the reaper is the only thing that ever revokes them once
overdue. Enforcing the poller while the reaper stays in shadow means grants happen for real
but nothing ever automatically takes them back; check both panels' Enforce Mode state
before relying on either one unattended.

## Per-cycle limits are also UI-editable

The same panel that hosts the Automation control has a **Per-cycle limits** form: for the
poller, `AZURESENTRY_POLLER_MAX_GRANTS` / `_MAX_TICKETS` / `_MAX_AGE_DAYS`; for the reaper,
`AZURESENTRY_REAPER_MAX_REVOKES`. `POST /api/poller/caps` (and `/api/reaper/caps`) writes a
small JSON override file (`dashboard/api/poller.caps.json` / `reaper.caps.json`), read by
`Get-PollerConfig`/`Get-ReaperConfig` **per field** ahead of the matching env var — setting
only `maxGrants` leaves `maxTickets`/`maxAgeDays` reading from env, independently. A file
that isn't valid JSON is ignored entirely; a present-but-non-positive value for one key
falls back to env for that key only. Raising `maxGrants`/`maxRevokes` above their current
effective value needs the same ≥4-character justification as arming Live; lowering it, or
changing the other poller fields either direction, doesn't. `DELETE /api/poller/caps` (or
`/api/reaper/caps`) clears the whole override file. `scripts/Deploy-ToVm.ps1` excludes both
`*.caps.json` files, same as the mode/enabled overrides above.

## Halt it

Fastest first:

1. **Stop sentinel** — takes effect on the next cycle, no config edit, no restart:
   ```bash
   echo "halted <who> <why> <when>" | sudo tee /opt/azuresentry/dashboard/api/poller.stop
   ```
   The path is configurable via `AZURESENTRY_POLLER_STOP_FILE` in `/etc/azuresentry.env`
   (and documented the same way in `.env.example`). Without it, the default resolves next
   to the processed-tickets store: `dashboard/api/poller.stop`, as used above.
2. **Kill switch** — `AZURESENTRY_POLLER_ENABLED=false` in `/etc/azuresentry.env`. **Only
   reliable when no `poller.enabled` override file exists.** If the dashboard's Automation
   control has ever been used, `dashboard/api/poller.enabled` may still be present and
   containing `true` — that file is checked before the env var and wins, so editing the
   env var alone will silently do nothing. Either delete/clear the override file too
   (`DELETE /api/poller/enabled`, or the "Clear overrides" button on the panel) or use the
   stop sentinel or timer steps above/below instead, which are unaffected by it. The
   reaper's equivalent is `AZURESENTRY_REAPER_ENABLED` / `dashboard/api/reaper.enabled`.
3. **Stop the timer** — `sudo systemctl disable --now azuresentry-poller.timer`.

Delete `poller.stop` (or the file `AZURESENTRY_POLLER_STOP_FILE` points at) to resume.

## How duplicate grants are prevented

`dashboard/api/processed-tickets/` holds one small JSON file per ME ticket, not a single
shared document — see `dashboard/api/ProcessedStore.ps1`. There is no lock anywhere in
this design. Instead, claiming a ticket is `Request-ProcessedTicketClaim`: a single
`CreateNew` filesystem call that either creates that ticket's file (this caller won) or
fails because it already exists (this caller lost) — one atomic kernel operation on both
Windows and Linux, with no timeout and no ownership bookkeeping to get wrong.

The poller's `-ExecuteGrant` step in `scripts/Invoke-TicketPollerCycle.ps1` calls this
claim **before** touching Azure or ManageEngine, so the dashboard API's own grant path and
this poller can never both act on the same ticket: whichever one wins the claim is the
only one that proceeds to grant. If the grant then fails, the claim is deliberately left
in place — the same per-ticket file is overwritten with the failure instead of being
deleted — so the ticket will not be retried automatically. Retrying automatically on a
transient failure (a token blip, a throttled Graph call) is exactly the duplicate-grant
risk this claim exists to prevent. A failed ticket needs a human to look at
`dashboard/api/processed-tickets/<ticket>.*.json`, understand what happened, and either
fix the underlying problem and re-run by hand, or delete that file to allow another
attempt.

The live duplicate check against Azure (`Get-RealActiveAssignments`, called inside the
grant step after the claim succeeds) remains the real backstop — the claim file is an
optimization to stop two processes racing on the same ME ticket; Azure is truth.

Confirm the claim really is mutually exclusive on the VM, once, before enabling enforce —
run two processes racing to claim the *same* ticket ids and confirm exactly one winner
per id, not that every write eventually lands (a lost race is supposed to happen here):

```bash
cd /opt/azuresentry
for i in 1 2; do
  pwsh -NoProfile -Command '
    . ./dashboard/api/ProcessedStore.ps1
    Initialize-ProcessedStore -Path /tmp/claim-probe.json
    $wins = 0
    1..50 | ForEach-Object {
      if (Request-ProcessedTicketClaim -MeTicketId "probe-$_" -Entry @{ by = "'$i'" }) { $wins++ }
    }
    "process '$i' won $wins claims"
  ' &
done
wait
pwsh -NoProfile -Command '
  . ./dashboard/api/ProcessedStore.ps1
  Initialize-ProcessedStore -Path /tmp/claim-probe.json
  (Get-ProcessedTickets).Count
'
rm -rf /tmp/claim-probe /tmp/claim-probe.json*
```

Expected: the two "won N claims" lines add up to exactly **50**, and the final count is
exactly **50** — every id claimed exactly once, no id claimed by both, no id lost.
Anything else means the claim is not exclusive and the poller must not be switched to
enforce until that is fixed.

## Verify what it did

**Enforce mode writes back to ManageEngine; shadow mode never does.**
`scripts/Invoke-TicketPollerCycle.ps1` / `src/Agents/TicketPollerAgent.ps1` call
`Send-ManageEngineProcessNote` and `Set-ManageEngineTicketResolved`
(`dashboard/api/ManageEngineNotes.ps1` — the same module the dashboard's human grant path
uses, so requester-facing wording matches) from exactly two places:

- **Grant succeeds** (enforce, outcome `Granted`) — posts a requester-visible success
  note, then marks the ticket Resolved. A resolve failure is **non-fatal**: the Azure
  grant already happened by that point, so resolution is bookkeeping only. It does not
  fail the cycle, does not trigger a re-grant, and does not release the
  processed-ticket claim — it is recorded on the entry (`ticketResolved: false`,
  `resolveError`) for an operator to follow up on by hand.
- **Grant fails** (enforce, outcome `Failed`, reached the grant step) — posts a
  requester-visible **failure** note: what was requested, that automated provisioning
  did not complete, and that a human will verify. It deliberately does **not** resolve
  the ticket — it must stay open for a human, and the note must never imply access was
  granted.

**Every `Queued` outcome posts no note, on purpose — do not "fix" this.** Most `Queued`
reasons (incomplete ME fields, not on the allowlist, per-cycle cap, promotion ladder,
etc.) are never written to the processed store, so the identical ticket is re-examined
every single cycle. If Queued posted a note too, every re-examination would post
*another* note, spamming the requester's ticket indefinitely.

**Shadow mode posts nothing and resolves nothing — this is non-negotiable.** Shadow's
whole contract is that it writes nothing, and that includes ManageEngine; a `WouldGrant`
entry never calls either hook. `tests/unit/TicketPollerAgent.Tests.ps1` asserts this
directly (a shadow cycle over an eligible ticket calls neither hook).

Both hooks are dependency-injected via the cycle's `-Context` hashtable
(`Context.PostTicketNote` / `Context.ResolveTicket`), exactly like `ExecuteGrant` —
mockable in tests, with no live ManageEngine required to exercise any of this.

Every entry in `poller-status.json` (and the dashboard's Poller panel table) carries
`notePosted` / `noteError` / `ticketResolved` / `resolveError` for `Granted` and `Failed`
outcomes, so an operator can see bookkeeping that silently failed even though the Azure
grant itself succeeded — do not assume a `Granted` ticket was actually noted and resolved
in ManageEngine without checking these. When the last cycle has `Failed` entries in
enforce mode, the dashboard's Poller panel shows a banner stating that a note has been
posted back to the requester and the ticket is awaiting human verification.

### Closure fields are unverified — confirm them locally before relying on them

`Set-ManageEngineTicketResolved` writes `manageEngine.closureFields` from
`dashboard/api/config.json`:

```json
"closureFields": {
  "udfFields": {
    "udf_pick_3713": "Yes",
    "udf_pick_3722": "Access Granted"
  },
  "resolutionContent": "Access granted automatically by the AzureSentry unattended ticket poller. ..."
}
```

The default keys (`udf_pick_3713` = "Vendor Compliance", `udf_pick_3722` = "Account
Status") and values were discovered by hand against **one** real ManageEngine ticket
roughly six weeks before this was written — treat them as unverified placeholders, not
facts about this ME instance. Before relying on an enforce run in production: open a real
ticket in ManageEngine, confirm those two UDF field keys and the values that should land
in them (Admin → the request's field inspector, or an existing resolved ticket), and if
either is wrong, **edit `config.json`, never the code** — any key in `udfFields` not
starting with `_` is sent to ME as-is, so an extra field can be added or an existing one
renamed/removed there directly. A `_..._label` entry is documentation only and is ignored.

Whoever triages a ticket the poller could not resolve (a `Failed` entry, or a `Granted`
entry with `ticketResolved: false`) must correlate it by hand against
`poller-status.json` (by `ticketId`) or the poller's own audit chain
(`audit-log-poller.jsonl`) — do not assume the ME ticket's own state reflects reality
until the note/resolve columns confirm it.

- Dashboard → **Poller panel** (the "Unattended ticket poller" card), or
  `GET /api/poller/status` directly. Both read `dashboard/api/poller-status.json` and
  report the poller's own last-reported `enabled` / `mode` — never the dashboard
  process's own env vars, which can silently drift from what the poller is actually
  doing (see final-review C3). A status file that is missing or more than 15 minutes
  stale reports `enabled: null` / `mode: null` and the panel shows "Unknown", not a
  confident "Off" — go check `systemctl status azuresentry-poller.timer` on the VM
  directly in that case.
- `dashboard/api/poller-status.json` — the last cycle verbatim.
- The audit trail — every cycle writes `TicketPollerAgent` / `UnattendedGrant` events,
  including shadow decisions (outcome `DryRun`), to `dashboard/api/audit-log-poller.jsonl`
  — a SEPARATE file from the dashboard API's own `audit-log.jsonl`. The two processes
  cannot share one hash-chained file (each derives seq/prevHash from state cached in its
  own process, so concurrent writers corrupt each other's chain), so unattended grants are
  audited in the poller's own chain. `GET /api/audit/integrity` verifies both chains and
  reports them separately.
- `dashboard/api/processed-tickets/` — one file per ticket the poller has claimed,
  granted, or failed on.

## Allowlist: two sources that must be kept in step

The dashboard derives its allowlist live from Azure (`allowlist.source: managementGroup`
in `config.json` — every subscription under the configured management group). The poller
does **not** do this: it reads only the static `subscriptionAllowlist` array (and
`subscriptionLabels` for the names it maps a ManageEngine "Subscription" dropdown value
against) in `dashboard/api/config.json`. If a subscription is added to the management
group but not to `subscriptionAllowlist`, a ticket the dashboard would allow the poller
will queue as "not on the allowlist by exact name". If `subscriptionAllowlist` names a
subscription the poller cannot actually reach, its grant fails against a nonexistent
target — and because a failed grant deliberately keeps its claim (see above), that ticket
is stuck permanently until an operator deletes its file in
`dashboard/api/processed-tickets/`. Keep the two lists in step by hand; there is no
automatic reconciliation.

## Common outcomes

| Symptom | Cause |
|---|---|
| `HALTED: AZURESENTRY_POLLER_ENABLED is not true` | Kill switch off. Expected default. |
| `HALTED: Stop sentinel present` | `poller.stop` exists. Delete to resume. |
| `examined=0` | No open Azure Subscription tickets in the age window, or ME creds missing. |
| Everything `Queued` with "Structured ME fields are incomplete" | Requesters left dropdowns blank. Run Environment Governance to backfill, or fix the ME template. |
| `Queued` with "not on the allowlist by exact name" | ME subscription label does not exactly match an allowlist name. Fix the label or `subscriptionLabels` in config. |
| `STOPPED (fail-closed)` | A grant failed; the cycle stopped deliberately. Read `reason`, fix, next cycle resumes. |
| Enforce throws about `AZURE_*` | Enforce requested without SPN credentials. |
| A ticket stays `Failed` forever, never retried | Working as designed — the claim is not released on failure. Find its file in `dashboard/api/processed-tickets/`, fix the cause, and either re-run by hand or delete the file to allow another attempt. |

## Why the age window exists

`AZURESENTRY_POLLER_MAX_AGE_DAYS` (default 7) stops a first run attempting the whole open
historical backlog. Raising it on a cold system will queue or grant a large batch at once —
raise it deliberately, with `AZURESENTRY_POLLER_MAX_GRANTS` low.

## MaxTicketsPerCycle vs MaxGrantsPerCycle -- the real safety bound is grants, not examination

`AZURESENTRY_POLLER_MAX_TICKETS` (default 100, matching the ME fetch's own `row_count`)
only bounds how many tickets one cycle *looks at* -- a cheap, local, non-writing pass over
mapping and deciding. A queued ticket is never recorded as processed, so with the old
default of 25 it was re-examined and re-skipped every single cycle forever, and anything
past the cap in a fuller fetch (ticket #26 onward, with 100 fetched) was never reached in
*any* cycle -- not starved for one cycle, starved permanently. Raise this only as a runaway
guard against something pathological (e.g. a misbehaving ME query), never as a safety
control.

**`AZURESENTRY_POLLER_MAX_GRANTS` (default 5) is the actual blast-radius bound.** Only a
grant writes real Azure RBAC; examining and deciding do not. Keep this low and raise it
deliberately, exactly as with the age window above.

## Environment backfill is now API-only (2026-08-21)

The Execution Hub's "Environment Governance" page was removed. It existed to infer and
backfill the ManageEngine `Environment` field on tickets that lacked it. That is no
longer an operational feature: `Environment` is now a **mandatory** field on all four
structured templates (Azure Subscription, GitHub Enterprise, ADO, Cortex), and measured
against live ManageEngine it is populated on 22/22 tickets created since 2026-08-18 —
100%. Only pre-cutover tickets (created before that date) still have gaps.

The backend that page drove was **not** removed — it is kept for exactly one purpose: a
one-off migration of that pre-cutover backlog. That includes `src/Agents/EnvironmentInferenceAgent.ps1`,
`src/Agents/SentryGovernanceAgent.ps1`, the `Measure-EnvironmentInferenceAccuracy` eval
harness, and the `/api/governance/environment/*` routes in `dashboard/api/Start-DashboardApi.ps1`.
`api.governance.categorize` (Department Scope) is unrelated and still has a UI — only the
environment-backfill screen and its dedicated API client methods were removed.

### Running a one-off backfill against the historical backlog

Same pipeline the removed page called, driven directly against the running dashboard API
(`dashboard/Start-Local.ps1` or the deployed VM's `/api` origin):

1. **Analyze** (read-only; produces a plan, writes nothing):
   ```
   POST /api/governance/environment/analyze
   { "department": "IDM", "confidenceThreshold": 0.85, "useLlm": true, "maxTickets": 0 }
   ```
   Returns `planId`, a `summary` (tagged/inferred/needs-review/unresolved counts), and a
   `batches` list (10 → 20 → 30 → 50 → bulk). Production tickets are never included in a
   writable batch — the pipeline refuses to touch Production regardless of confidence.

2. **Review** the drill-down before writing anything:
   ```
   GET /api/governance/environment/report?planId=<planId>&format=csv
   ```

3. **Apply one batch at a time**, naming who validated it (required to write):
   ```
   POST /api/governance/environment/apply
   { "planId": "<planId>", "batchNumber": 1, "apply": true, "validatedBy": "you@inceptionai.ai" }
   ```
   Start with `"apply": false` for a dry run of the same batch first. Every write records
   its previous value, so it is fully reversible.

4. **Roll back** if needed:
   ```
   POST /api/governance/environment/rollback
   { "planId": "<planId>", "reason": "..." }
   ```

Every step is audited the same way the old page's calls were (`SentryGovernanceAgent`,
`AnalyzeEnvironments` / `ApplyEnvironmentBatch` / `RollbackEnvironmentBatch` actions in the
audit trail) — removing the UI did not remove the audit trail, only the button that drove it.
