# Required APIs & Access

## Microsoft Graph API is the central integration surface.

Three scopes are needed:
**PrivilegedAccess.ReadWrite.AzureResources** is the most critical — this grants the Managed Identity the ability to create and read PIM role assignment and eligibility schedule requests via **/roleAssignmentScheduleRequests** and **/roleEligibilityScheduleRequests**. Without this, no runbook can touch PIM at all.
**User.Read.All** is required to resolve requester UPNs to Entra Object IDs before any PIM call. PIM operates on Object IDs, not email addresses.
**Reader** on each target subscription is needed to validate that a subscription exists and to query existing active assignments for duplicate detection.

## ManageEngine ServiceDesk Plus REST API

requires a token scoped to read and write service requests. This is used by the Status Updater runbook to push ticket status changes (Pending Approval, Resolved, Denied, Expired). The token must be stored in Azure Key Vault — not hardcoded in any runbook.

## Azure Automation REST API

is used by the Logic App to invoke runbooks as async jobs or via Automation webhooks. The Logic App's Managed Identity needs Automation Operator on the Automation Account.

## Current Blockers

The critical API for real (non-mock) processing is Microsoft Graph API with one essential scope:

PrivilegedAccess.ReadWrite.AzureResources — this is the one that matters most. It lets the system create PIM role assignments via the /roleAssignmentScheduleRequests and /roleEligibilityScheduleRequests endpoints. Without it, no runbook can actually grant or make roles eligible. This is blocker B1 (Graph admin consent on the automation service principal).

Two supporting scopes are also required:
┌───────────────────────────────────────────┬────────────────────────────────────────────────────────────────────────┐
│                   Scope                   │                                Purpose                                 │
├───────────────────────────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ PrivilegedAccess.ReadWrite.AzureResources │ Create/read PIM assignments — the actual "grant access" call           │
├───────────────────────────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ User.Read.All                             │ Resolve requester email → Entra Object ID (PIM operates on Object IDs) │
├───────────────────────────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ Reader on target subscriptions            │ Validate subscription exists + duplicate assignment detection          │
└───────────────────────────────────────────┴────────────────────────────────────────────────────────────────────────┘


To go from mock to real, you need a Global Admin to grant admin consent for those Graph scopes on the automation service principal (Managed Identity). Once that's done, the code swap is minimal — the GraphPimClient module already implements all the real Graph API calls; the backend just needs $env:AZURESENTRY_PIM_CLIENT set to Graph instead of Mock.


┌─────┬───────────────────────────────────┬────────┬───────────────────────────┬─────────────────────────────────────────────────────────────────────┐
│  #  │             Endpoint              │ Status │           Error           │                            What's needed                            │
├─────┼───────────────────────────────────┼────────┼───────────────────────────┼─────────────────────────────────────────────────────────────────────┤
│ 1   │ GET /users/{upn}                  │ 404    │ Request_ResourceNotFound  │ My token lacks User.Read.All — Graph hides users with a 404       │
│     │                                   │        │                           │ instead of 403 when this scope is missing                           │
├─────┼───────────────────────────────────┼────────┼───────────────────────────┼─────────────────────────────────────────────────────────────────────┤
│ 2   │ GET                               │ 403    │ PermissionScopeNotGranted │ Missing RoleManagement.Read.Directory (or .ReadWrite.Directory) —   │
│     │ /roleAssignmentScheduleInstances  │        │                           │ can't read existing PIM assignments                                 │
├─────┼───────────────────────────────────┼────────┼───────────────────────────┼─────────────────────────────────────────────────────────────────────┤
│ 3   │ POST                              │ 403    │ PermissionScopeNotGranted │ Missing RoleManagement.ReadWrite.Directory — can't create PIM       │
│     │ /roleAssignmentScheduleRequests   │        │                           │ assignments (the critical grant call)                               │
├─────┼───────────────────────────────────┼────────┼───────────────────────────┼─────────────────────────────────────────────────────────────────────┤
│ 4   │ Subscription Reader               │ OK     │ —                         │ Already working                                                     │
└─────┴───────────────────────────────────┴────────┴───────────────────────────┴─────────────────────────────────────────────────────────────────────┘

Bottom line: A Global Admin needs to grant admin consent for these delegated or application scopes on the service principal:

1. RoleManagement.ReadWrite.Directory — create and read PIM assignments (the "grant access" call)
2. User.Read.All — resolve email addresses to Entra Object IDs

Once those two scopes are consented, the switch from Mock to real Graph is a one-line env var change (AZURESENTRY_PIM_CLIENT=Graph). All the code is already written.


"Process Ticket" on #2858, two things occurred:

1. Decision tree evaluated it as Grant via Sandbox-FullAuto (Reader + Sandbox = auto-approve)
2. A note was posted to ticket #2858 in ManageEngine with the decision details — your supervisor saw that note appear on the ticket in the helpdesk portal, which is why he's saying it's "approved now"

What actually happened vs. what it looks like:

┌───────────────────────────────┬──────────────────────────────────┬──────────────────────────┐
│             Step              │          What happened           │          Real?           │
├───────────────────────────────┼──────────────────────────────────┼──────────────────────────┤
│ Decision tree evaluation      │ Grant - Sandbox-FullAuto         │ Yes, real logic          │
├───────────────────────────────┼──────────────────────────────────┼──────────────────────────┤
│ Note posted to ME ticket      │ "AzureSentry Decision: Grant..." │ Yes, visible in helpdesk │
├───────────────────────────────┼──────────────────────────────────┼──────────────────────────┤
│ Azure RBAC permission granted │ MockPimClient simulated it       │ No - mock only           │
└───────────────────────────────┴──────────────────────────────────┴──────────────────────────┘

The supervisor sees the approval note on the ME ticket, but no actual Azure permission was assigned because the PIM client is running in Mock mode. The 5 blocked Graph API scopes from the Test-ApiAccess script are what prevent the real grant.

Once a Global Admin consents those two scopes (RoleManagement.ReadWrite.Directory + User.Read.All), clicking "Process Ticket" will do the same flow but with a real PIM assignment — the user would actually get the Reader role on the subscription.