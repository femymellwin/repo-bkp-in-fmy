# AzureSentry — Hosting Decision (VM vs Web App vs AKS)

**Author:** Abdulla Alfalasi (Cloud Engineering)
**Date:** 2026-07-06
**Audience:** Engineering supervisor / Cloud Governance
**Decision:** Host the AzureSentry backend on a **VM**, placed in a VNet with corporate-network connectivity.

---

## Background

AzureSentry ingests access-request tickets from our internal help desk (**ManageEngine ServiceDesk Plus**, `helpdesk.int.inceptionai.ai`), runs them through a decision engine, and executes the resulting Azure PIM / RBAC grant. Two constraints drive the hosting choice:

1. **Internal host reachability** — the help desk is an internal-only hostname; the compute must be able to route to it and resolve its DNS.
2. **Backend runtime** — the backend is a PowerShell HTTP listener (`System.Net.HttpListener`), which uses Windows `http.sys`.

## The key point

**The network problem is not solved by the compute choice.** VM, Web App, and AKS *all* require an Azure VNet with a route + DNS resolution to the corporate network (ExpressRoute/VPN to the hub + private DNS or a DNS forwarder). That is a networking-team dependency and the real long pole — identical for all three options.

Because network parity holds across all options, the decision is made on the **second** constraint: how cleanly each runs the PowerShell backend, and the ongoing cost/ops.

## Options compared

| Criterion | **VM** | **Web App (App Service)** | **AKS (cluster)** |
|---|---|---|---|
| Runs current PowerShell backend as-is | ✅ Yes | ❌ No — App Service sandbox blocks `http.sys` (verified); works only if containerized ("Web App for Containers") | ⚠️ Only containerized |
| Reaches internal ManageEngine host | ✅ VM in VNet + corporate DNS | ✅ Requires regional VNet integration + private DNS | ✅ Nodes in VNet + DNS |
| Managed Identity for real grants | ✅ | ✅ | ✅ (workload identity) |
| Code / rework required | **None** | Containerize + rework listener | Containerize + k8s manifests |
| Ongoing ops burden | OS patching | Low (PaaS) | **Highest** (control plane, nodes, ingress) |
| Relative cost | Low (small B-series VM) | Low–moderate | Highest |
| Fit for one low-traffic internal tool | **Best** | Good (if PaaS-first policy) | Overkill |

*Proof point:* We deployed the backend to an App Service Web App (P0v3, UAE North). The PowerShell process crash-looped with `HttpListener.Start(): Access is denied` — the App Service sandbox does not permit `http.sys` URL registration. Confirmed via the startup logs.

## Decision & rationale

**Chosen: VM.**

- Runs the **existing code with zero rework** — the exact failure that killed the App Service attempt does not exist on a VM.
- Sits **directly on the internal network** (once in a connected VNet), so it reaches `helpdesk.int.inceptionai.ai` like any internal automation server.
- Uses a **system-assigned Managed Identity** for Graph/ARM calls — no secrets to manage for the real grant.
- Matches what this actually is: a single, low-traffic, internal automation service.

**Rejected:**
- **Web App** — would require re-architecting the backend (containerize + replace the HTTP listener) for no functional gain at this scale. Reconsider only under a strict PaaS-first mandate.
- **AKS** — a full Kubernetes platform is unjustified operational and cost overhead for one small service. (If containers are desired without k8s overhead, **Azure Container Apps** is the lighter middle ground — but still requires the containerization work.)

## Dependencies (unchanged by this decision)

1. **Networking:** a VNet/subnet with routing + DNS to the corporate network reaching `helpdesk.int.inceptionai.ai` — networking team.
2. **Permissions for real grants:** Graph admin consent (`PrivilegedAccess.ReadWrite.AzureResources`, `User.Read.All`) + **User Access Administrator** for the automation identity — Global Admin / PRA. (See `docs/graph-consent-request.md`.)

## Next step

Provision the VM per `docs/vm-provisioning-plan.md`, then re-run `scripts/Test-ApiAccess.ps1` from the VM to confirm both internal reachability and Azure API access before the live demo.
