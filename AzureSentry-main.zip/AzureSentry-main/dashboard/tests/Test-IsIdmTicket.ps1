# Unit checks for Help Desk IAM-only ticket filter (Test-IsIdmTicket).
# Run: powershell -NoProfile -File .\dashboard\tests\Test-IsIdmTicket.ps1

$ErrorActionPreference = 'Stop'

# Dot-source only the filter helpers by extracting via a minimal stub of the function.
# Keep this file self-contained so it does not start the HTTP API.

function Test-IsIdmTicket {
    param([object]$Ticket, [string]$QueueName)
    $group = [string]$Ticket.group.name
    $cat = [string]$Ticket.category.name
    $sub = [string]$Ticket.subcategory.name
    $q = if ([string]::IsNullOrWhiteSpace($QueueName)) { 'IDM' } else { $QueueName.Trim() }

    $identityPattern = '(?i)(\bIDAM\b|\bIDM\b|Identity\s+and\s+Access\s+Management|Identity\s+Management)'
    foreach ($v in @($group, $cat, $sub)) {
        if ([string]::IsNullOrWhiteSpace($v)) { continue }
        if ($v -match $identityPattern) { return $true }
        if ($q.Length -le 4) {
            if ($v -match ("(?i)\b{0}\b" -f [regex]::Escape($q))) { return $true }
        }
        elseif ($v.ToLowerInvariant().Contains($q.ToLowerInvariant())) {
            return $true
        }
    }
    return $false
}

function New-Ticket {
    param($Group, $Category, $Subcategory, $Subject)
    [pscustomobject]@{
        group       = @{ name = $Group }
        category    = @{ name = $Category }
        subcategory = @{ name = $Subcategory }
        subject     = $Subject
    }
}

$pass = 0
$fail = 0
function Assert-True($cond, $name) {
    if ($cond) { $script:pass++; Write-Host "  PASS  $name" -ForegroundColor Green }
    else { $script:fail++; Write-Host "  FAIL  $name" -ForegroundColor Red }
}

Write-Host 'Test-IsIdmTicket (IAM-only Help Desk filter)' -ForegroundColor Cyan

Assert-True (Test-IsIdmTicket -Ticket (New-Ticket 'IDM' '' '' 'Anything') -QueueName 'IDM') `
    'group IDM'
Assert-True (Test-IsIdmTicket -Ticket (New-Ticket 'IDAM Team' '' '' 'Anything') -QueueName 'IDM') `
    'group IDAM Team'
Assert-True (Test-IsIdmTicket -Ticket (New-Ticket 'Identity and Access Management Team' '' '' 'x') -QueueName 'IDM') `
    'group expanded IAM name'
Assert-True (Test-IsIdmTicket -Ticket (New-Ticket '' 'Identity Management' '' 'x') -QueueName 'IDM') `
    'category Identity Management'

Assert-True (-not (Test-IsIdmTicket -Ticket (New-Ticket 'Infrastructure' '' '' 'Need Contributor on ceo-sub') -QueueName 'IDM')) `
    'rejects non-IAM group even with Contributor in subject'
Assert-True (-not (Test-IsIdmTicket -Ticket (New-Ticket 'GitHub Support' '' '' 'Access request for repo') -QueueName 'IDM')) `
    'rejects GitHub queue with access-request subject'
Assert-True (-not (Test-IsIdmTicket -Ticket (New-Ticket 'Random' '' '' 'pim rbac writer') -QueueName 'IDM')) `
    'no subject-keyword fallback'

Write-Host ''
Write-Host ("Result: {0} passed, {1} failed" -f $pass, $fail)
if ($fail -gt 0) { exit 1 }
