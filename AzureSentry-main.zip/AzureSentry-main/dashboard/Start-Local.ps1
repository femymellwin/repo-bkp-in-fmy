<#
.SYNOPSIS
    One-command local run of AzureSentry (PowerShell API + Vite UI), with a safe
    Mock default and an explicit Real (SPN/PIM) mode.

.DESCRIPTION
    - Frees the API port if a stale listener is holding it (the HttpListener URL
      registration survives a killed process and blocks restart).
    - In -Mode Real: checks the SPN creds are present in .env and acquires a token
      as a preflight; only then enables the real Graph/PIM path
      (AZURESENTRY_PIM_CLIENT=Graph). Falls back to Mock if the preflight fails.
    - Starts the API, waits until healthy, then launches the Vite dev server.

    config.json stays on pimClient=Mock so nothing grants for real unless this
    launcher is explicitly run with -Mode Real.

.EXAMPLE
    ./Start-Local.ps1                 # Mock mode (safe) - no real Azure grants
.EXAMPLE
    ./Start-Local.ps1 -Mode Real      # real PIM grants via the automation SPN
#>
[CmdletBinding()]
param(
    [ValidateSet('Mock', 'Real')][string]$Mode = 'Mock',
    [int]$Port = 8787
)

$ErrorActionPreference = 'Stop'
$dashboardRoot = $PSScriptRoot
$repoRoot = Split-Path $dashboardRoot -Parent
$apiScript = Join-Path $dashboardRoot 'api\Start-DashboardApi.ps1'
$webRoot = Join-Path $dashboardRoot 'web'
$healthUrl = "http://127.0.0.1:$Port/api/health"

function Test-ApiHealth { try { (Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2).status -eq 'ok' } catch { $false } }

# Load .env (needed for the Real preflight); strip optional surrounding quotes
$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            $val = $Matches[2].Trim()
            if (($val.StartsWith('"') -and $val.EndsWith('"')) -or ($val.StartsWith("'") -and $val.EndsWith("'"))) {
                $val = $val.Substring(1, $val.Length - 2)
            }
            [Environment]::SetEnvironmentVariable($Matches[1], $val, 'Process')
        }
    }
}

# --- Free the port: stop any stale API process, then confirm the port releases ---
# Health can fail (timeout/ECONNRESET) while HTTP.sys still holds the URLACL — always
# clear Start-DashboardApi processes before starting a new listener.
$stale = @(
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" |
        Where-Object { $_.CommandLine -like '*Start-DashboardApi*' }
)
if ($stale.Count -gt 0 -or (Test-ApiHealth)) {
    Write-Host "Stopping existing API on port $Port..." -ForegroundColor Yellow
    $stale | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 2
}
if (Test-ApiHealth) { Write-Error "Port $Port still held. Close the stale process manually and retry."; exit 1 }

# --- Real-mode preflight: verify SPN creds and that a token can be acquired ---
$pimMode = 'Mock'
if ($Mode -eq 'Real') {
    if (-not (Test-Path $envFile)) {
        Write-Host "ERROR: Real mode requested but no .env at $envFile" -ForegroundColor Red
        Write-Host "Copy .env.example and set AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET." -ForegroundColor Yellow
        Write-Warning 'Falling back to Mock.'
    }
    else {
        $missing = @('AZURE_TENANT_ID', 'AZURE_CLIENT_ID', 'AZURE_CLIENT_SECRET') | Where-Object {
            -not [Environment]::GetEnvironmentVariable($_, 'Process')
        }
        if ($missing) {
            Write-Host "ERROR: Real mode requested but .env is missing: $($missing -join ', ')" -ForegroundColor Red
            Write-Warning 'Falling back to Mock.'
        }
        else {
            try {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                $null = (Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$($env:AZURE_TENANT_ID)/oauth2/v2.0/token" `
                    -Body @{ grant_type='client_credentials'; client_id=$env:AZURE_CLIENT_ID; client_secret=$env:AZURE_CLIENT_SECRET; scope='https://management.azure.com/.default' } `
                    -ContentType 'application/x-www-form-urlencoded').access_token
                $pimMode = 'Graph'
                Write-Host 'Real mode: SPN token acquired. PIM grants will be REAL.' -ForegroundColor Green
                Write-Host 'Tip: run scripts\Test-SpnAccess.ps1 for a full permission check.' -ForegroundColor DarkGray
            }
            catch {
                Write-Host "ERROR: SPN token preflight failed: $($_.Exception.Message)" -ForegroundColor Red
                Write-Warning 'Falling back to Mock.'
            }
        }
    }
}
$env:AZURESENTRY_PIM_CLIENT = $pimMode
Write-Host "PIM client mode: $pimMode" -ForegroundColor $(if ($pimMode -eq 'Graph') { 'Yellow' } else { 'Cyan' })

# --- Start API with explicit -PimClient (do not rely on Start-Process env inheritance) ---
Write-Host 'Starting AzureSentry API...' -ForegroundColor Cyan
$apiArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $apiScript, '-Port', "$Port", '-PimClientMode', $pimMode)
Start-Process -FilePath 'powershell.exe' -ArgumentList $apiArgs -WindowStyle Normal | Out-Null

$deadline = (Get-Date).AddSeconds(30)
while ((Get-Date) -lt $deadline -and -not (Test-ApiHealth)) { Start-Sleep -Milliseconds 500 }
if (-not (Test-ApiHealth)) { Write-Error "API did not become healthy at $healthUrl."; exit 1 }
Write-Host "API ready at $healthUrl" -ForegroundColor Green

# --- Start Vite ---
Write-Host 'Starting Vite dev server (http://localhost:5173)...' -ForegroundColor Cyan
Push-Location $webRoot
try {
    if (-not (Test-Path 'node_modules')) { npm install }
    npm run dev:vite
}
finally { Pop-Location }
