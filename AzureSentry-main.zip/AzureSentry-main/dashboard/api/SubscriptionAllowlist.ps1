<#
.SYNOPSIS
    Resolves which Azure subscriptions are grantable: the allowlist (decision-tree step 2).

.DESCRIPTION
    Extracted from Start-DashboardApi.ps1 so the unattended poller can share it. That
    script cannot be dot-sourced at all -- it starts an HttpListener at top level -- so a
    second copy of this logic in the poller would let the two paths silently diverge on
    which subscriptions can be auto-granted. Same pattern as ProcessedStore.ps1,
    MeAccessFields.ps1, AccessPromotion.ps1 and ManageEngineNotes.ps1.

    The allowlist can be a static list (config.json's subscriptionAllowlist array, for
    testing / fallback) or derived LIVE from an Azure management group (production --
    auto-expands as subscriptions are added under the MG, no config.json edit needed).
    Dynamic results are cached in-process and fail CLOSED: any ARM error, timeout, or
    empty result falls back to the static list, never to "everything". An
    `allowlist.exclusions` entry is always dropped even if the management group returns
    it -- see Resolve-ManagementGroupAllowlist below.

    Config arrives as a -Config parameter rather than a script-scope $config read,
    because the poller has no such scope -- see MeAccessFields.ps1 for the identical
    reasoning. $script:AllowlistCache itself is intentionally still script-scoped state:
    dot-sourcing runs this file's code in the caller's own scope (no new scope is
    pushed), so the cache lives in whichever process dot-sources this file -- the
    dashboard API's long-running process, or one short-lived poller cycle. For the
    poller that in-memory cache buys nothing (the process exits every cycle and a fresh
    process starts the next one with $script:AllowlistCache back to $null) -- see
    Get-EffectiveAllowlist's own remark below. Deliberately NOT backed by an on-disk
    cache file: one ARM management-group query every ~5 minutes (the poller's cadence)
    is well inside ARM's read throttling limits, and a second piece of runtime state
    would need its own fail-closed staleness handling and its own Deploy-ToVm.ps1
    exclusion for no real benefit over just asking ARM again next cycle.
#>

$script:AllowlistCache = $null

function Get-AllowlistConfig {
    <#
    .SYNOPSIS
      Normalize config.json's `allowlist` block (or its absence) into a fixed shape.
    .PARAMETER Config
      The API/poller config object (parsed config.json). Back-compat: if it has no
      `allowlist` block at all, behaves as static using subscriptionAllowlist -- the
      original, pre-management-group behaviour -- rather than throwing on old configs.
    #>
    param([object]$Config)

    if (-not $Config -or $Config.PSObject.Properties.Name -notcontains 'allowlist') {
        return [PSCustomObject]@{ source = 'static'; managementGroupId = $null; cacheMinutes = 10; enabledOnly = $true; exclusions = @() }
    }
    $a = $Config.allowlist
    [PSCustomObject]@{
        source            = if ($a.PSObject.Properties.Name -contains 'source') { $a.source } else { 'static' }
        managementGroupId = $a.managementGroupId
        cacheMinutes      = if ($a.PSObject.Properties.Name -contains 'cacheMinutes') { [int]$a.cacheMinutes } else { 10 }
        enabledOnly       = if ($a.PSObject.Properties.Name -contains 'enabledOnly') { [bool]$a.enabledOnly } else { $true }
        exclusions        = if ($a.PSObject.Properties.Name -contains 'exclusions') { @($a.exclusions) } else { @() }
    }
}

function Get-SpnArmToken {
    <#
    .SYNOPSIS
      Client-credentials ARM token for the automation SPN. Same three env vars the real
      Graph/PIM client (src/PimClient/GraphPimClient.psm1) and the poller's enforce-mode
      pre-flight already require -- no separate credential story for the allowlist query.
    #>
    if (-not ($env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET)) {
        throw 'SPN credentials (AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET) required for the dynamic allowlist.'
    }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    (Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$($env:AZURE_TENANT_ID)/oauth2/v2.0/token" `
        -Body @{ grant_type='client_credentials'; client_id=$env:AZURE_CLIENT_ID; client_secret=$env:AZURE_CLIENT_SECRET; scope='https://management.azure.com/.default' } `
        -ContentType 'application/x-www-form-urlencoded').access_token
}

function Resolve-ManagementGroupAllowlist {
    <#
    .SYNOPSIS
      Live ARM lookup: every subscription under a management group, minus exclusions,
      optionally minus disabled subscriptions.
    .DESCRIPTION
      Exclusions are applied here, before EnabledOnly filtering and before this ever
      reaches a caller -- an excluded id can never appear in the returned Subs/Details no
      matter what state ARM reports for it, so it stays excluded even if it is enabled
      and directly under the management group.
    #>
    param([Parameter(Mandatory)][string]$MgId, [string[]]$Exclusions = @(), [bool]$EnabledOnly = $true)
    $token = Get-SpnArmToken
    $h = @{ Authorization = "Bearer $token" }

    # Recursive descendants of the management group -> subscription ids.
    $found = @{}
    $uri = "https://management.azure.com/providers/Microsoft.Management/managementGroups/$MgId/descendants?api-version=2020-05-01"
    while ($uri) {
        $resp = Invoke-RestMethod -Headers $h -Uri $uri -Method Get
        foreach ($e in $resp.value) {
            if ($e.type -match 'subscriptions$') { $found[$e.name] = $e.properties.displayName }
        }
        $uri = $resp.nextLink
    }

    # Subscription states (to optionally drop disabled subs).
    $stateMap = @{}
    try {
        $subs = Invoke-RestMethod -Headers $h -Uri 'https://management.azure.com/subscriptions?api-version=2020-01-01'
        foreach ($s in $subs.value) { $stateMap[$s.subscriptionId] = $s.state }
    } catch { }

    $details = @()
    foreach ($id in $found.Keys) {
        if ($Exclusions -contains $id) { continue }
        $state = if ($stateMap.ContainsKey($id)) { $stateMap[$id] } else { 'Unknown' }
        if ($EnabledOnly -and $stateMap.ContainsKey($id) -and $state -ne 'Enabled') { continue }
        $details += [PSCustomObject]@{ id = $id; name = $found[$id]; state = $state }
    }
    return @{ Subs = @($details.id); Details = @($details) }
}

function Get-EffectiveAllowlist {
    <#
    .SYNOPSIS
      The allowlist actually in force right now: static, or live management-group-derived
      with a fail-closed fallback to static on any error.
    .PARAMETER Config
      The API/poller config object.
    .PARAMETER ForceRefresh
      Bypass the in-process cache. No effect on a fresh process (e.g. the poller, which
      starts with $script:AllowlistCache already $null) -- only matters within a single
      long-running caller such as the dashboard API.
    #>
    [CmdletBinding()]
    param([object]$Config, [switch]$ForceRefresh)
    $cfg = Get-AllowlistConfig -Config $Config
    if ($cfg.source -ne 'managementGroup') {
        return @{ Subs = @($Config.subscriptionAllowlist); Source = 'static'; Degraded = $false; Details = @(); FetchedAt = (Get-Date) }
    }
    if (-not $ForceRefresh -and $script:AllowlistCache -and
        ((Get-Date) - $script:AllowlistCache.FetchedAt).TotalMinutes -lt $cfg.cacheMinutes) {
        return $script:AllowlistCache
    }
    try {
        $r = Resolve-ManagementGroupAllowlist -MgId $cfg.managementGroupId -Exclusions $cfg.exclusions -EnabledOnly $cfg.enabledOnly
        $script:AllowlistCache = @{
            Subs = $r.Subs; Details = $r.Details; Source = "managementGroup:$($cfg.managementGroupId)"
            Degraded = $false; FetchedAt = (Get-Date); Exclusions = $cfg.exclusions
        }
    }
    catch {
        # Fail CLOSED: fall back to the static known-good list, mark degraded, cache briefly.
        Write-Warning "Dynamic allowlist resolve failed; falling back to static list. $($_.Exception.Message)"
        $script:AllowlistCache = @{
            Subs = @($Config.subscriptionAllowlist); Details = @(); Source = 'static-fallback'
            Degraded = $true; FetchedAt = (Get-Date); Error = $_.Exception.Message
        }
    }
    return $script:AllowlistCache
}
