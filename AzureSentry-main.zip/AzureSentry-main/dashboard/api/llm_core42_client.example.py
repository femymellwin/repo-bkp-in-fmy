"""
Core42 OpenAI-compatible client — reference for the ticket summarization agent.

The dashboard API (PowerShell) calls the same endpoint. Prefer setting the key in
dashboard/api/llm.env (gitignored), not in this file.

Usage (local smoke test only):
  set CORE42_API_KEY=...
  python dashboard/api/llm_core42_client.example.py
"""

from __future__ import annotations

import json
import os

from openai import OpenAI

# Same pattern as the Core42 / OpenAI Python client:
#   base_url = https://api.core42.ai/v1
#   default_headers={"api-key": "<API_KEY>"}
API_KEY = os.environ.get("LLM_API_KEY") or os.environ.get("CORE42_API_KEY") or "PASTE_YOUR_CORE42_API_KEY_HERE"

client = OpenAI(
    base_url="https://api.core42.ai/v1",
    default_headers={"api-key": API_KEY},
    api_key=API_KEY,
)


def summarize_ticket(subject: str, body: str, requester: str = "") -> dict:
    system = (
        "You are AzureSentry's Access Ticket Summarization Agent. "
        "Reply with JSON only: "
        '{"summary":"...","who":"...","access":"...","environment":"Sandbox|Non-Prod|Production|Unknown",'
        '"subscription":"...","intent":"...","urgency":"P1|P2|P3|P4|Unknown"}. '
        "Use plain business language. Never mention AI, parsing, or schemas."
    )
    user = f"Requester: {requester}\nSubject: {subject}\nBody:\n{body}"
    resp = client.chat.completions.create(
        model=os.environ.get("LLM_MODEL", "gpt-5.1"),
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=0.15,
        max_completion_tokens=500,
        response_format={"type": "json_object"},
    )
    return json.loads(resp.choices[0].message.content or "{}")


if __name__ == "__main__":
    sample = summarize_ticket(
        subject="Need Contributor on inception-ai-Sandbox",
        body="Please grant me Contributor access on the sandbox subscription for 7 days.",
        requester="dev.user@contoso.com",
    )
    print(json.dumps(sample, indent=2))
