﻿<#
.SYNOPSIS
    FR6 / NFR3 / Deliverable #10 — ships audit events to Log Analytics via the
    DCR-based Logs Ingestion API, so "every agent decision, PIM event, and ticket
    update" lands somewhere queryable with KQL, not only in the local JSONL file.

.DESCRIPTION
    The local append-only trail (AuditLog.ps1) remains the system of record and the
    thing Test-AuditChainIntegrity verifies — it works before any infrastructure is
    deployed and never depends on network access. This client is a best-effort
    FORWARDER on top of it: Write-AuditEvent calls Send-LogAnalyticsAuditEvent after
    every successful local append, and a failure here never fails the caller's agent
    action — the same fail-open contract the LLM client uses.

    Requires (once infra/modules/loganalytics-audit-dcr.bicep is deployed):
      AZURESENTRY_LA_DCE_ENDPOINT     the DCE logs ingestion endpoint (module output)
      AZURESENTRY_LA_DCR_IMMUTABLE_ID the DCR immutable ID (module output)
      AZURESENTRY_LA_STREAM_NAME      defaults to Custom-AzureSentryAuditLog_CL
      AZURESENTRY_LA_TENANT_ID        Entra tenant ID
      AZURESENTRY_LA_CLIENT_ID        app registration / SPN with Monitoring Metrics
      AZURESENTRY_LA_CLIENT_SECRET    Publisher on the DCR (see rbac-platform-identities.bicep)

    Until those are set, Get-LogAnalyticsSettings.Configured is $false and every send
    is a silent, zero-cost no-op — this file is safe to dot-source today, before the
    workspace exists.
#>

$script:LogAnalyticsTokenCache = $null

function Get-LogAnalyticsSettings {
    <#
    .SYNOPSIS
      Resolves Log Analytics ingestion settings from environment variables.
    #>
    [CmdletBinding()]
    param()

    $endpoint = [string]$env:AZURESENTRY_LA_DCE_ENDPOINT
    $dcrImmutableId = [string]$env:AZURESENTRY_LA_DCR_IMMUTABLE_ID
    $streamName = if ($env:AZURESENTRY_LA_STREAM_NAME) { [string]$env:AZURESENTRY_LA_STREAM_NAME } else { 'Custom-AzureSentryAuditLog_CL' }
    $tenantId = [string]$env:AZURESENTRY_LA_TENANT_ID
    $clientId = [string]$env:AZURESENTRY_LA_CLIENT_ID
    $clientSecret = [string]$env:AZURESENTRY_LA_CLIENT_SECRET

    $configured = -not [string]::IsNullOrWhiteSpace($endpoint) -and
                  -not [string]::IsNullOrWhiteSpace($dcrImmutableId) -and
                  -not [string]::IsNullOrWhiteSpace($tenantId) -and
                  -not [string]::IsNullOrWhiteSpace($clientId) -and
                  -not [string]::IsNullOrWhiteSpace($clientSecret)

    return [pscustomobject]@{
        Endpoint       = $endpoint
        DcrImmutableId = $dcrImmutableId
        StreamName     = $streamName
        TenantId       = $tenantId
        ClientId       = $clientId
        ClientSecret   = $clientSecret
        Configured     = $configured
    }
}

function Get-LogAnalyticsAccessToken {
    <#
    .SYNOPSIS
      Client-credentials OAuth token for the monitor.azure.com scope, cached until
      shortly before expiry so every event doesn't re-authenticate.
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$Settings)

    if ($script:LogAnalyticsTokenCache -and
        $script:LogAnalyticsTokenCache.ExpiresAtUtc -gt (Get-Date).ToUniversalTime().AddMinutes(2)) {
        return $script:LogAnalyticsTokenCache.Token
    }

    $tokenUri = "https://login.microsoftonline.com/$($Settings.TenantId)/oauth2/v2.0/token"
    $body = @{
        client_id     = $Settings.ClientId
        client_secret = $Settings.ClientSecret
        scope         = 'https://monitor.azure.com/.default'
        grant_type    = 'client_credentials'
    }
    $resp = Invoke-RestMethod -Uri $tokenUri -Method Post -Body $body -ContentType 'application/x-www-form-urlencoded' -ErrorAction Stop

    $script:LogAnalyticsTokenCache = [pscustomobject]@{
        Token        = [string]$resp.access_token
        ExpiresAtUtc = (Get-Date).ToUniversalTime().AddSeconds([int]$resp.expires_in)
    }
    return $script:LogAnalyticsTokenCache.Token
}

function ConvertTo-LogAnalyticsAuditRecord {
    <#
    .SYNOPSIS
      Maps one AuditLog.ps1 event object to the custom table's column shape
      (see infra/modules/loganalytics-audit-dcr.bicep — column names must match).
    #>
    param([Parameter(Mandatory)][object]$Event)

    $toJsonOrNull = { param($v) if ($null -eq $v) { $null } else { $v | ConvertTo-Json -Depth 10 -Compress } }

    return @{
        TimeGenerated     = [string]$Event.timestamp
        seq_d             = [int64]$Event.seq
        id_s              = [string]$Event.id
        agent_s           = [string]$Event.agent
        action_s          = [string]$Event.action
        actor_s           = [string]$Event.actor
        runId_g           = [string]$Event.runId
        correlationId_g   = [string]$Event.correlationId
        ticketId_s        = [string]$Event.ticketId
        target_s          = & $toJsonOrNull $Event.target
        before_s          = & $toJsonOrNull $Event.before
        after_s           = & $toJsonOrNull $Event.after
        outcome_s         = [string]$Event.outcome
        reason_s          = [string]$Event.reason
        detail_s          = & $toJsonOrNull $Event.detail
        correctsEventId_s = [string]$Event.correctsEventId
        isWrite_b         = [bool]$Event.isWrite
        hash_s            = [string]$Event.hash
        prevHash_s        = [string]$Event.prevHash
    }
}

function Send-LogAnalyticsAuditEvent {
    <#
    .SYNOPSIS
      Best-effort forward of one audit event to Log Analytics. Never throws.

    .OUTPUTS
      pscustomobject: @{ ok = $true } or @{ ok = $false; error = '...'; skipped = $true|$false }
      skipped = $true means "not configured", not a failure — the caller can ignore it.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Event,
        [int]$TimeoutSec = 5
    )

    $settings = Get-LogAnalyticsSettings
    if (-not $settings.Configured) {
        return [pscustomobject]@{ ok = $false; skipped = $true; error = 'Log Analytics ingestion not configured.' }
    }

    try {
        $token = Get-LogAnalyticsAccessToken -Settings $settings
        $record = ConvertTo-LogAnalyticsAuditRecord -Event $Event
        $body = @($record) | ConvertTo-Json -Depth 10 -Compress
        # A single-element array must not unroll to a bare object — the ingestion API requires an array body.
        if ($body -notmatch '^\[') { $body = "[$body]" }

        $uri = "$($settings.Endpoint.TrimEnd('/'))/dataCollectionRules/$($settings.DcrImmutableId)/streams/$($settings.StreamName)?api-version=2023-01-01"
        $headers = @{ 'Authorization' = "Bearer $token"; 'Content-Type' = 'application/json' }
        Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $body -TimeoutSec $TimeoutSec -ErrorAction Stop | Out-Null
        return [pscustomobject]@{ ok = $true; skipped = $false }
    }
    catch {
        $detail = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $detail = $_.ErrorDetails.Message }
        Write-Host "[log-analytics] audit event forward failed (event stays in the local trail): $detail" -ForegroundColor Yellow
        return [pscustomobject]@{ ok = $false; skipped = $false; error = $detail }
    }
}
