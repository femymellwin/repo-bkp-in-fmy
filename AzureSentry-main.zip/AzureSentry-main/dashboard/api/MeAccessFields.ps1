﻿<#
.SYNOPSIS
    Reads Subscription / Azure Role / Environment from ManageEngine udf_fields.

.DESCRIPTION
    Extracted from Start-DashboardApi.ps1 so the unattended poller can share it. The
    poller cannot dot-source that script at all -- it starts an HttpListener at top level,
    so sourcing it would launch a second web server. And these three fields decide which
    subscription and role a ticket is asking for, so a second copy of this logic in the
    poller would mean a drift changes what gets granted unattended.

    Key overrides arrive as a parameter rather than being read from a $config script
    variable, because the poller has no such scope.
#>

function Get-MeUdfFieldValue {
    param(
        [object]$UdfFields,
        [string]$Key
    )
    if (-not $UdfFields -or [string]::IsNullOrWhiteSpace($Key)) { return '' }
    $prop = $UdfFields.PSObject.Properties[$Key]
    if (-not $prop) { return '' }
    $val = $prop.Value
    if ($null -eq $val) { return '' }
    if ($val -is [string] -or $val -is [ValueType]) { return ([string]$val).Trim() }
    foreach ($nameKey in @('name', 'value', 'display_value', 'displayValue')) {
        if ($val.PSObject.Properties.Name -contains $nameKey -and $val.$nameKey) {
            return ([string]$val.$nameKey).Trim()
        }
    }
    return ''
}

function Get-MeTemplateAccessFields {
    <#
    .SYNOPSIS
      Reads Subscription, Azure Role, Environment from ME udf_fields
      (Azure Subscription service template).
    .PARAMETER UdfKeyOverrides
      Optional object with any of: subscription, azureRole, environment,
      environmentsRequired. In the dashboard this comes from
      $config.manageEngine.udfFields; the poller passes its own.
    #>
    param(
        [object]$UdfFields,
        [object]$UdfKeyOverrides = $null
    )

    $map = @{
        subscription     = 'udf_pick_3728'
        azureRole        = 'udf_pick_3729'
        environment      = 'udf_pick_3719'
        # No default key: the ME "Azure Subscription" template has no field for this yet.
        # Get-MeUdfFieldValue returns '' for a blank Key, so leaving this unset is the
        # correct fail-closed default until a real UDF key is configured below.
        targetResourceId = ''
    }
    if ($UdfKeyOverrides) {
        $u = $UdfKeyOverrides
        if ($u.subscription) { $map.subscription = [string]$u.subscription }
        if ($u.azureRole) { $map.azureRole = [string]$u.azureRole }
        if ($u.environment) { $map.environment = [string]$u.environment }
        # Legacy key name from older config -- ignore Environments Required (udf_sline_3715).
        elseif ($u.environmentsRequired -and $u.environmentsRequired -ne 'udf_sline_3715') {
            $map.environment = [string]$u.environmentsRequired
        }
        if ($u.targetResourceId) { $map.targetResourceId = [string]$u.targetResourceId }
    }

    # ME placeholders are not answers. Treating "Not Specified" as a real selection would
    # send an unresolvable value to the decision engine.
    $isBlank = {
        param([string]$v)
        if ([string]::IsNullOrWhiteSpace($v)) { return $true }
        $n = $v.Trim().ToLowerInvariant()
        return @('not specified', 'n/a', 'na', '-', 'none') -contains $n
    }

    $sub = Get-MeUdfFieldValue -UdfFields $UdfFields -Key $map.subscription
    $role = Get-MeUdfFieldValue -UdfFields $UdfFields -Key $map.azureRole
    $env = Get-MeUdfFieldValue -UdfFields $UdfFields -Key $map.environment
    $resourceId = Get-MeUdfFieldValue -UdfFields $UdfFields -Key $map.targetResourceId
    if (& $isBlank $sub) { $sub = '' }
    if (& $isBlank $role) { $role = '' }
    if (& $isBlank $env) { $env = '' }
    if (& $isBlank $resourceId) { $resourceId = '' }

    return [ordered]@{
        Subscription     = $sub
        AzureRole        = $role
        Environment      = $env
        TargetResourceId = $resourceId
        fieldKeys        = [ordered]@{
            Subscription     = $map.subscription
            AzureRole        = $map.azureRole
            Environment      = $map.environment
            TargetResourceId = $map.targetResourceId
        }
    }
}

function Get-MeConfiguredAccessFields {
    <#
    .SYNOPSIS
      Get-MeTemplateAccessFields with a config's udf key overrides applied.
    .DESCRIPTION
      This is the seam where refactor fidelity could break, so it lives here (not in
      Start-DashboardApi.ps1) precisely so it is dot-sourceable and testable -- that
      script starts an HttpListener at top level, so nothing can dot-source it.
    .PARAMETER Config
      The API/poller config object. Overrides come from $Config.manageEngine.udfFields;
      a $null config, or one with no manageEngine (or no udfFields under it), falls back
      to the default udf key map.
    #>
    param(
        [object]$UdfFields,
        [object]$Config = $null
    )
    $overrides = $null
    if ($Config -and ($Config.PSObject.Properties.Name -contains 'manageEngine') -and $Config.manageEngine) {
        if ($Config.manageEngine.PSObject.Properties.Name -contains 'udfFields') {
            $overrides = $Config.manageEngine.udfFields
        }
    }
    return Get-MeTemplateAccessFields -UdfFields $UdfFields -UdfKeyOverrides $overrides
}
