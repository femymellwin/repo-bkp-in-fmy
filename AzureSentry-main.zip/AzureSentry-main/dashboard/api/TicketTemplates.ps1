<#
.SYNOPSIS
  ManageEngine ticket template schema registry + payload builder (mirrors dashboard/web).
#>

function Get-NormalizedTemplateName {
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
    $n = $Name.Trim()
    $n = [regex]::Replace($n, '\s+template$', '', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase).Trim()
    return $n
}

function Get-TicketTemplateAliasMap {
    return @{
        'security assesment'         = 'Security Assessment'
        'report and issue template'  = 'Report and Issue'
        'other request template'     = 'Other Request'
        'soc template'               = 'SOC'
    }
}

function Get-TicketTemplateSchemaTable {
    <#
    .SYNOPSIS
      Canonical schemas keyed by lowercased canonical name.
    #>
    $table = [ordered]@{}
    $add = {
        param([string]$Canonical, [string]$Handler, [string[]]$Fields)
        $table[$Canonical.ToLowerInvariant()] = [pscustomobject]@{
            CanonicalName = $Canonical
            Handler       = $Handler
            Fields        = @($Fields)
        }
    }
    & $add '1Password' 'pending' @('Item')
    & $add 'Cursor' 'pending' @()
    & $add 'GitHub Enterprise' 'pending' @('Environment', 'Item', 'Exception Request', 'Request Type')
    & $add 'Azure Subscription' 'azure-subscription-grant' @(
        'Subscription', 'Azure Role', 'Environment'
    )
    & $add 'ADO' 'pending' @('Request Type', 'Item', 'Exception Request', 'Environment')
    & $add 'General Access' 'pending' @('Item', 'Business Justification')
    & $add 'Infrastructure' 'pending' @('Item', 'Business Justification')
    & $add 'Networking' 'pending' @(
        'Request Type', 'Source IP', 'Destination IP', 'Port', 'Access Direction', 'Item',
        'Source IP Description', 'Destination IP Description', 'Protocol (TCP/UDP)',
        'Access Type', 'Business Justification'
    )
    & $add 'MLOps' 'pending' @('Item')
    & $add 'Policy Exemptions' 'pending' @('Item', 'Business Justification')
    & $add 'New Project' 'pending' @('Item', 'Business Justification')
    & $add 'Cortex' 'pending' @('Item', 'Environment', 'Request Type')
    & $add 'Infosec' 'pending' @('Item', 'Business Justification')
    & $add 'Security Assessment' 'pending' @()
    & $add 'DevOps Access' 'pending' @('Item', 'Business Justification', 'Request Type')
    & $add 'Report and Issue' 'pending' @()
    & $add 'Other Request' 'pending' @()
    & $add 'SOC' 'pending' @()
    return $table
}

function Get-TicketTemplateSchema {
    param([string]$TemplateName)
    $normalized = Get-NormalizedTemplateName -Name $TemplateName
    if (-not $normalized) { return $null }

    $table = Get-TicketTemplateSchemaTable
    $aliases = Get-TicketTemplateAliasMap
    $lower = $normalized.ToLowerInvariant()
    $rawLower = if ($TemplateName) { $TemplateName.Trim().ToLowerInvariant() } else { '' }

    if ($aliases.ContainsKey($lower)) {
        $target = $aliases[$lower].ToLowerInvariant()
        return $table[$target]
    }
    if ($rawLower -and $aliases.ContainsKey($rawLower)) {
        $target = $aliases[$rawLower].ToLowerInvariant()
        return $table[$target]
    }
    if ($table.Contains($lower)) { return $table[$lower] }
    return $null
}

function Get-MeUdfPickName {
    param([object]$Value)
    if ($null -eq $Value) { return '' }
    if ($Value -is [string] -or $Value -is [ValueType]) { return ([string]$Value).Trim() }
    if ($Value -is [hashtable] -or $Value -is [System.Collections.Specialized.OrderedDictionary]) {
        foreach ($k in @('name', 'value', 'display_value', 'displayValue')) {
            if ($Value.ContainsKey($k) -and $Value[$k]) {
                return ([string]$Value[$k]).Trim()
            }
        }
        return ''
    }
    foreach ($k in @('name', 'value', 'display_value', 'displayValue')) {
        if ($Value.PSObject.Properties.Name -contains $k -and $Value.$k) {
            return ([string]$Value.$k).Trim()
        }
    }
    return ''
}

function Test-MeUdfBlank {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $true }
    $n = $Value.Trim().ToLowerInvariant()
    return @('not specified', 'n/a', 'na', '-', 'none') -contains $n
}

function Get-UdfValueByKey {
    param(
        [object]$UdfFields,
        [string]$Key
    )
    if (-not $UdfFields -or [string]::IsNullOrWhiteSpace($Key)) { return '' }
    $prop = $UdfFields.PSObject.Properties[$Key]
    if (-not $prop) { return '' }
    $value = Get-MeUdfPickName -Value $prop.Value
    if (Test-MeUdfBlank $value) { return '' }
    return $value
}

function Set-TemplateFieldIfEmpty {
    param(
        [System.Collections.IDictionary]$Fields,
        [string]$Name,
        [string]$Value
    )
    if (-not $Fields.Contains($Name)) { return }
    $existing = [string]$Fields[$Name]
    if (-not [string]::IsNullOrWhiteSpace($existing) -and -not (Test-MeUdfBlank $existing)) { return }
    if ([string]::IsNullOrWhiteSpace($Value) -or (Test-MeUdfBlank $Value)) { return }
    $Fields[$Name] = $Value.Trim()
}

function Apply-KnownTemplateFieldFallbacks {
    <#
    .SYNOPSIS
      Fill schema fields ME returns without UDF labels, or as built-in request properties.
      Environment / Exception Request are keyed UDFs (no .label on GET).
      Item / Request Type are top-level ticket fields (item, request_type), not udf_fields.
    #>
    param(
        [System.Collections.IDictionary]$Fields,
        [object]$Ticket,
        [object]$AccessFields = $null
    )

    $udf = $null
    if ($Ticket -and ($Ticket.PSObject.Properties.Name -contains 'udf_fields')) {
        $udf = $Ticket.udf_fields
    }

    if ($Fields.Contains('Environment')) {
        $env = ''
        if ($AccessFields -and $AccessFields.Environment) { $env = [string]$AccessFields.Environment }
        if (-not $env) { $env = Get-UdfValueByKey -UdfFields $udf -Key 'udf_pick_3719' }
        Set-TemplateFieldIfEmpty -Fields $Fields -Name 'Environment' -Value $env
    }
    if ($Fields.Contains('Exception Request')) {
        $exc = Get-UdfValueByKey -UdfFields $udf -Key 'udf_pick_3014'
        Set-TemplateFieldIfEmpty -Fields $Fields -Name 'Exception Request' -Value $exc
    }
    if ($Fields.Contains('Business Justification')) {
        $bj = Get-UdfValueByKey -UdfFields $udf -Key 'udf_mline_901'
        Set-TemplateFieldIfEmpty -Fields $Fields -Name 'Business Justification' -Value $bj
    }
    if ($Fields.Contains('Item') -and $Ticket -and ($Ticket.PSObject.Properties.Name -contains 'item')) {
        Set-TemplateFieldIfEmpty -Fields $Fields -Name 'Item' -Value (Get-MeUdfPickName -Value $Ticket.item)
    }
    if ($Fields.Contains('Request Type') -and $Ticket -and ($Ticket.PSObject.Properties.Name -contains 'request_type')) {
        Set-TemplateFieldIfEmpty -Fields $Fields -Name 'Request Type' -Value (Get-MeUdfPickName -Value $Ticket.request_type)
    }
    if ($Fields.Contains('Subscription')) {
        $sub = ''
        if ($AccessFields -and $AccessFields.Subscription) { $sub = [string]$AccessFields.Subscription }
        if (-not $sub) { $sub = Get-UdfValueByKey -UdfFields $udf -Key 'udf_pick_3728' }
        Set-TemplateFieldIfEmpty -Fields $Fields -Name 'Subscription' -Value $sub
    }
    if ($Fields.Contains('Azure Role')) {
        $role = ''
        if ($AccessFields -and $AccessFields.AzureRole) { $role = [string]$AccessFields.AzureRole }
        if (-not $role) { $role = Get-UdfValueByKey -UdfFields $udf -Key 'udf_pick_3729' }
        Set-TemplateFieldIfEmpty -Fields $Fields -Name 'Azure Role' -Value $role
    }
}

function Get-CanonicalUdfFieldLabel {
    param([string]$Label)
    if ([string]::IsNullOrWhiteSpace($Label)) { return '' }
    $map = @{
        'protocol (tpc/udp)'              = 'Protocol (TCP/UDP)'
        'azure role'                      = 'Azure Role'
        'exception request'               = 'Exception Request'
        'request type'                    = 'Request Type'
        'business justification'          = 'Business Justification'
        'source ip'                       = 'Source IP'
        'destination ip'                  = 'Destination IP'
        'access direction'                = 'Access Direction'
        'source ip description'           = 'Source IP Description'
        'destination ip description'      = 'Destination IP Description'
        'access type'                     = 'Access Type'
    }
    $t = $Label.Trim()
    $key = $t.ToLowerInvariant()
    if ($map.ContainsKey($key)) { return $map[$key] }
    return $t
}

function Get-UdfFieldsByLabel {
    param([object]$UdfFields)
    $out = @{}
    if (-not $UdfFields) { return $out }
    $props = @($UdfFields.PSObject.Properties)
    foreach ($p in $props) {
        $raw = $p.Value
        if ($null -eq $raw) { continue }
        $labelRaw = ''
        if ($raw -isnot [string] -and $raw -isnot [ValueType]) {
            foreach ($lk in @('label', 'field_label', 'display_name')) {
                if ($raw.PSObject.Properties.Name -contains $lk -and $raw.$lk) {
                    $labelRaw = [string]$raw.$lk
                    break
                }
            }
        }
        if (-not $labelRaw) { $labelRaw = [string]$p.Name }
        $label = Get-CanonicalUdfFieldLabel -Label $labelRaw
        $value = Get-MeUdfPickName -Value $raw
        if ($label -and -not (Test-MeUdfBlank $value)) {
            $out[$label.ToLowerInvariant()] = $value
        }
    }
    return $out
}

function Get-TicketTemplateNameFromObject {
    param([object]$Ticket)
    if (-not $Ticket) { return '' }
    $t = $null
    if ($Ticket -is [hashtable] -or $Ticket -is [System.Collections.Specialized.OrderedDictionary]) {
        if ($Ticket.ContainsKey('template')) { $t = $Ticket['template'] }
    }
    elseif ($Ticket.PSObject.Properties.Name -contains 'template') {
        $t = $Ticket.template
    }
    if ($null -eq $t) { return '' }
    if ($t -is [string]) { return Get-NormalizedTemplateName -Name $t }
    if ($t -is [hashtable] -or $t -is [System.Collections.Specialized.OrderedDictionary]) {
        if ($t.ContainsKey('name') -and $t['name']) {
            return Get-NormalizedTemplateName -Name ([string]$t['name'])
        }
        return ''
    }
    if ($t.PSObject.Properties.Name -contains 'name' -and $t.name) {
        return Get-NormalizedTemplateName -Name ([string]$t.name)
    }
    return ''
}

function New-TemplatePayload {
    param(
        [Parameter(Mandatory)][object]$Ticket,
        [object]$AccessFields = $null
    )

    $templateName = Get-TicketTemplateNameFromObject -Ticket $Ticket
    $displayName = if ($templateName) { $templateName } else { 'Unspecified' }
    $schema = if ($templateName) { Get-TicketTemplateSchema -TemplateName $templateName } else { $null }

    $desc = ''
    if ($Ticket.description) {
        $desc = [regex]::Replace([string]$Ticket.description, '<[^>]+>', ' ')
        $desc = ($desc -replace '&nbsp;', ' ' -replace '&amp;', '&' -replace '\s+', ' ').Trim()
    }
    elseif ($Ticket.short_description) {
        $desc = [string]$Ticket.short_description
    }

    $common = [ordered]@{
        requesterName  = if ($Ticket.requester -and $Ticket.requester.name) { [string]$Ticket.requester.name } else { '' }
        requesterEmail = if ($Ticket.requester -and $Ticket.requester.email_id) { [string]$Ticket.requester.email_id } else { '' }
        category       = if ($Ticket.category -and $Ticket.category.name) { [string]$Ticket.category.name } else { '' }
        subcategory    = if ($Ticket.subcategory -and $Ticket.subcategory.name) { [string]$Ticket.subcategory.name } else { '' }
        subject        = if ($Ticket.subject) { [string]$Ticket.subject } else { '' }
        description    = $desc
        status         = if ($Ticket.status -and $Ticket.status.name) { [string]$Ticket.status.name } else { '' }
    }

    if (-not $schema) {
        return [ordered]@{
            templateName           = $displayName
            handler                = 'none'
            knownSchema            = $false
            common                 = $common
            fields                 = [ordered]@{}
            fieldOrder             = @()
            requiredFields         = @()
            requiredPlaceholders   = @()
            warnings               = @('Unknown template schema')
        }
    }

    $byLabel = Get-UdfFieldsByLabel -UdfFields $Ticket.udf_fields
    $fields = [ordered]@{}
    foreach ($f in @($schema.Fields)) {
        $key = $f.ToLowerInvariant()
        $fields[$f] = if ($byLabel.ContainsKey($key)) { [string]$byLabel[$key] } else { '' }
    }

    Apply-KnownTemplateFieldFallbacks -Fields $fields -Ticket $Ticket -AccessFields $AccessFields

    return [ordered]@{
        templateName    = $schema.CanonicalName
        handler         = $schema.Handler
        knownSchema     = $true
        common          = $common
        fields          = $fields
        fieldOrder      = @($schema.Fields)
        requiredFields         = @()
        requiredPlaceholders   = @()
        warnings               = @()
    }
}

function Test-TemplateAllowsGrant {
    param([object]$Payload)
    if (-not $Payload) { return $false }
    $handler = ''
    if ($Payload -is [hashtable] -or $Payload -is [System.Collections.Specialized.OrderedDictionary]) {
        $handler = [string]$Payload['handler']
    }
    elseif ($Payload.PSObject.Properties.Name -contains 'handler') {
        $handler = [string]$Payload.handler
    }
    return $handler -eq 'azure-subscription-grant'
}

function Get-MandatoryFieldKeyVariants {
    param([string]$Key)
    $k = ([string]$Key).Trim()
    if (-not $k) { return @() }
    $variants = [System.Collections.Generic.List[string]]::new()
    [void]$variants.Add($k.ToLowerInvariant())
    $noUdf = $k -replace '^udf_fields\.', ''
    if ($noUdf -ne $k) { [void]$variants.Add($noUdf.ToLowerInvariant()) }
    $tail = ($k -split '\.')[-1]
    if ($tail) { [void]$variants.Add($tail.ToLowerInvariant()) }
    # Humanize: source_ip → source ip; udf_sline_item → item (last token after underscores if short)
    $human = ($tail -replace '^udf_(pick|sline|mline|date|long|double|boolean)_', '' -replace '_', ' ').Trim()
    if ($human) { [void]$variants.Add($human.ToLowerInvariant()) }
    return @($variants | Select-Object -Unique)
}

function Resolve-MandatorySchemaFields {
    <#
    .SYNOPSIS
      Map ManageEngine mandatory field keys onto schema display labels.
      Also returns which common placeholders (Requester UPN, Justification) are required.
    #>
    param(
        [string[]]$MandatoryKeys,
        [string[]]$SchemaFields,
        [object]$UdfFields = $null
    )

    $requiredSchema = [System.Collections.Generic.List[string]]::new()
    $requiredPlaceholders = [System.Collections.Generic.List[string]]::new()

    if (-not $MandatoryKeys -or $MandatoryKeys.Count -eq 0) {
        return [pscustomobject]@{
            RequiredFields       = @()
            RequiredPlaceholders = @()
        }
    }

    # UDF key → display label from ticket payload
    $udfKeyToLabel = @{}
    if ($UdfFields) {
        foreach ($p in @($UdfFields.PSObject.Properties)) {
            $raw = $p.Value
            $labelRaw = ''
            if ($raw -and $raw -isnot [string] -and $raw -isnot [ValueType]) {
                foreach ($lk in @('label', 'field_label', 'display_name')) {
                    if ($raw.PSObject.Properties.Name -contains $lk -and $raw.$lk) {
                        $labelRaw = [string]$raw.$lk
                        break
                    }
                }
            }
            $label = if ($labelRaw) { Get-CanonicalUdfFieldLabel -Label $labelRaw } else { '' }
            if ($label) {
                $udfKeyToLabel[$p.Name.ToLowerInvariant()] = $label
            }
        }
    }

    $schemaByLower = @{}
    foreach ($f in @($SchemaFields)) {
        if ($f) { $schemaByLower[$f.ToLowerInvariant()] = $f }
    }

    foreach ($rawKey in $MandatoryKeys) {
        $variants = Get-MandatoryFieldKeyVariants -Key $rawKey
        $matchedSchema = $null

        foreach ($v in $variants) {
            if ($udfKeyToLabel.ContainsKey($v)) {
                $lab = $udfKeyToLabel[$v]
                $labLower = $lab.ToLowerInvariant()
                if ($schemaByLower.ContainsKey($labLower)) {
                    $matchedSchema = $schemaByLower[$labLower]
                    break
                }
            }
            if ($schemaByLower.ContainsKey($v)) {
                $matchedSchema = $schemaByLower[$v]
                break
            }
            # Canonical alias → schema (e.g. protocol (tpc/udp))
            $canon = Get-CanonicalUdfFieldLabel -Label $v
            if ($canon -and $schemaByLower.ContainsKey($canon.ToLowerInvariant())) {
                $matchedSchema = $schemaByLower[$canon.ToLowerInvariant()]
                break
            }
        }

        if ($matchedSchema -and -not ($requiredSchema -contains $matchedSchema)) {
            [void]$requiredSchema.Add($matchedSchema)
        }

        # Common placeholders we always show
        foreach ($v in $variants) {
            if ($v -match '^(requester|requester_email|email_id|email)$') {
                if (-not ($requiredPlaceholders -contains 'Requester UPN')) {
                    [void]$requiredPlaceholders.Add('Requester UPN')
                }
            }
            if ($v -match '^(description|short_description|justification)$') {
                if (-not ($requiredPlaceholders -contains 'Justification')) {
                    [void]$requiredPlaceholders.Add('Justification')
                }
            }
            if ($v -eq 'subject' -and -not ($requiredPlaceholders -contains 'Subject')) {
                [void]$requiredPlaceholders.Add('Subject')
            }
        }
    }

    return [pscustomobject]@{
        RequiredFields       = @($requiredSchema)
        RequiredPlaceholders = @($requiredPlaceholders)
    }
}

function Set-TemplatePayloadRequiredFields {
    param(
        [Parameter(Mandatory)]$Payload,
        [string[]]$MandatoryKeys,
        [object]$UdfFields = $null
    )
    if (-not $Payload) { return $Payload }
    $handler = if ($Payload.handler) { [string]$Payload.handler } else { '' }
    # Azure Subscription: never mark ME mandatory asterisks on placeholders.
    if ($handler -eq 'azure-subscription-grant') {
        $Payload.requiredFields = @()
        $Payload.requiredPlaceholders = @()
        return $Payload
    }

    $schemaFields = @()
    if ($Payload.fieldOrder) { $schemaFields = @($Payload.fieldOrder) }
    $resolved = Resolve-MandatorySchemaFields `
        -MandatoryKeys $MandatoryKeys `
        -SchemaFields $schemaFields `
        -UdfFields $UdfFields

    $Payload.requiredFields = @($resolved.RequiredFields)
    $Payload.requiredPlaceholders = @($resolved.RequiredPlaceholders)
    return $Payload
}

function Get-TemplateGrantBlockResponse {
    return @{
        decision = @{
            Action = 'Hold'
            Path   = 'Unsupported-Template'
            Reason = 'This request type does not have an Azure grant handler yet. Structured intake only.'
        }
        steps            = @()
        processed        = $false
        templateBlocked  = $true
    }
}

function Resolve-TemplateGrantAllowed {
    <#
    .SYNOPSIS
      Decide whether evaluate/process may run a grant.
      If the body carries no template identity, allow (simulator / legacy).
    #>
    param([object]$Body)
    if (-not $Body) { return @{ Allowed = $true; Skipped = $true } }

    $handler = ''
    $name = ''
    if ($Body.PSObject.Properties.Name -contains 'templatePayload' -and $Body.templatePayload) {
        $tp = $Body.templatePayload
        if ($tp.handler) { $handler = [string]$tp.handler }
        if ($tp.templateName) { $name = [string]$tp.templateName }
    }
    if (-not $handler -and $Body.PSObject.Properties.Name -contains 'templateHandler') {
        $handler = [string]$Body.templateHandler
    }
    if (-not $handler -and $Body.PSObject.Properties.Name -contains 'handler') {
        $handler = [string]$Body.handler
    }
    if (-not $name -and $Body.PSObject.Properties.Name -contains 'templateName') {
        $name = [string]$Body.templateName
    }

    if ($name) {
        $schema = Get-TicketTemplateSchema -TemplateName $name
        if ($schema) {
            return @{
                Allowed = ($schema.Handler -eq 'azure-subscription-grant')
                Handler = $schema.Handler
                Skipped = $false
            }
        }
        return @{ Allowed = $false; Handler = 'none'; Skipped = $false }
    }

    if ($handler) {
        return @{
            Allowed = ($handler -eq 'azure-subscription-grant')
            Handler = $handler
            Skipped = $false
        }
    }

    return @{ Allowed = $true; Skipped = $true }
}
