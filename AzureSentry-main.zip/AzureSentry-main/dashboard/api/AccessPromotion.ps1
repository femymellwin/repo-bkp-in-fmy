<#
.SYNOPSIS
    Enforces Sandbox -> NonProd -> Production access promotion.

.DESCRIPTION
    Extracted from Start-DashboardApi.ps1 so the unattended poller can share it. The
    poller cannot dot-source that script at all -- it starts an HttpListener at top level,
    so sourcing it would launch a second web server -- and a second copy of this logic
    would let the unattended path drift more permissive than the human one it must never
    exceed. Same pattern as ProcessedStore.ps1 and MeAccessFields.ps1.

    Depends on Get-ProcessedTickets (ProcessedStore.ps1) being dot-sourced into the
    caller's session already; both Start-DashboardApi.ps1 and
    scripts/Invoke-TicketPollerCycle.ps1 do this before calling in.

    Config overrides arrive as a -Config parameter rather than being read from a $config
    script variable, because the poller has no such scope -- see MeAccessFields.ps1 for
    the identical reasoning.
#>

function Test-AccessPromotionLadder {
    <#
    .SYNOPSIS
      Enforces Sandbox -> NonProd -> Production for access grants.
      Production requires a prior Sandbox or NonProd grant for same requester + role.
      NonProd requires a prior Sandbox grant. Break-Glass is exempt.
    .PARAMETER TicketInput
      Hashtable or object with at least Environment, Role, RequesterUpn.
    .PARAMETER Decision
      The RbacDecision result for this ticket (needs .Action).
    .PARAMETER Config
      The API/poller config object. Reads Config.accessPromotion.enforceLadder (defaults
      to enforced -- true -- when Config is absent or does not set it, which is the safe,
      fail-closed default for an unattended caller that failed to load its config).
    #>
    param(
        [object]$TicketInput,
        [object]$Decision,
        [object]$Config = $null
    )
    $enforce = $true
    if ($Config -and ($Config.PSObject.Properties.Name -contains 'accessPromotion') -and
        $null -ne $Config.accessPromotion.enforceLadder) {
        $enforce = [bool]$Config.accessPromotion.enforceLadder
    }
    if (-not $enforce) { return @{ Ok = $true } }
    if ($Decision.Action -eq 'BreakGlass') { return @{ Ok = $true } }
    # Enforce ladder on auto-grants (Grant). Eligible (approval) paths still surface the
    # promotion expectation to approvers via activity, but do not hard-block the request.
    if ($Decision.Action -ne 'Grant') { return @{ Ok = $true } }

    $envName = [string]$TicketInput.Environment
    if ($envName -eq 'Sandbox') { return @{ Ok = $true } }

    $role = [string]$TicketInput.Role
    $upn = [string]$TicketInput.RequesterUpn
    $roleNorm = if ($role -eq 'Writer') { @('Writer', 'Contributor') } else { @($role) }
    $store = Get-ProcessedTickets
    $priors = @($store.Values | Where-Object {
            -not $_.revoked -and
            ([string]$_.requesterUpn -eq $upn) -and
            ($roleNorm -contains [string]$_.role)
        })

    if ($envName -eq 'NonProd') {
        $hasSandbox = @($priors | Where-Object { [string]$_.environment -eq 'Sandbox' }).Count -gt 0
        if (-not $hasSandbox) {
            return @{
                Ok     = $false
                Reason = "Access promotion required: grant $role in Sandbox before Non-Prod for $upn (Sandbox -> Non-Prod -> Production)."
            }
        }
        return @{ Ok = $true }
    }

    if ($envName -eq 'Production') {
        $hasLower = @($priors | Where-Object { [string]$_.environment -in @('Sandbox', 'NonProd') }).Count -gt 0
        if (-not $hasLower) {
            return @{
                Ok     = $false
                Reason = "Access promotion required: complete Sandbox or Non-Prod access for $role before Production for $upn (Sandbox -> Non-Prod -> Production)."
            }
        }
        return @{ Ok = $true }
    }
    return @{ Ok = $true }
}
