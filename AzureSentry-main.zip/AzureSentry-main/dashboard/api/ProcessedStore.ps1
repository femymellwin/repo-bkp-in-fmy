<#
.SYNOPSIS
    Durable record of processed ME tickets, safe for concurrent access.

.DESCRIPTION
    This store is the dedup record that stops a ticket being granted twice. It was
    previously a single JSON document, read-modify-written by the API. The unattended
    poller now writes the same record from a separate process, and a lost or wrongly-
    empty write here means the same ticket gets granted twice.

    Rather than add cross-process locking around a shared document, this rewrite
    changes the data model: one small JSON file per ticket, in a directory. "Has ticket
    X been processed?" is a per-ticket fact, so it gets a per-ticket file. Claiming a
    ticket is a single atomic filesystem call -- creating a file that must not already
    exist -- which is exactly the mutual exclusion needed, is a single kernel operation
    on both Windows and Linux, and needs no timeout, no ownership bookkeeping, and no
    platform-specific fallback.

    The live duplicate check against Azure (Get-RealActiveAssignments plus the group
    duplicate check) remains the real backstop. This store is an optimization; Azure
    is truth.
#>

$script:ProcessedStorePath = $null

function Initialize-ProcessedStore {
    <#
    .DESCRIPTION
      Accepts the legacy JSON file path for compatibility with existing callers. The
      actual store is a sibling directory named after the file's base name (so
      ".../processed-tickets.json" -> ".../processed-tickets/"). If a legacy file
      exists there, its entries are migrated into that directory (see
      Invoke-ProcessedStoreMigration) and the file is renamed aside so this only
      happens once.
    #>
    param([Parameter(Mandatory)][string]$Path)
    $script:ProcessedStorePath = $Path

    $dir = Get-ProcessedStoreDir
    if (-not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    Invoke-ProcessedStoreMigration -LegacyPath $Path
}

function Get-ProcessedStorePath {
    if (-not $script:ProcessedStorePath) {
        throw 'ProcessedStore not initialized. Call Initialize-ProcessedStore -Path <file> first.'
    }
    return $script:ProcessedStorePath
}

function Get-ProcessedStoreDir {
    $path = Get-ProcessedStorePath
    $parent = Split-Path -Path $path -Parent
    if ([string]::IsNullOrEmpty($parent)) {
        # A bare relative filename (e.g. 'store.json') has no parent component --
        # Split-Path returns '' rather than throwing, so without this the Join-Path
        # below would throw on an empty -Path. '.' is the same directory Initialize-
        # ProcessedStore would have resolved the bare file against.
        $parent = '.'
    }
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($path)
    return Join-Path $parent $baseName
}

function Assert-ValidTicketId {
    # A blank id would sanitize to a filename indistinguishable from other blank ids,
    # and silently colliding two unrelated "tickets" onto the same file is worse than
    # refusing up front.
    param([string]$MeTicketId)
    if ([string]::IsNullOrWhiteSpace($MeTicketId)) {
        throw 'ProcessedStore: ticket id must not be empty or whitespace.'
    }
    return $MeTicketId
}

function ConvertTo-ProcessedTicketFileStem {
    <#
    .DESCRIPTION
      Ticket ids are arbitrary strings (e.g. "ELIG-ceo-sub--20260727135920"), not just
      numbers, and are not safe to use as filenames verbatim. The sanitized id keeps
      filenames readable; the hash suffix of the ORIGINAL id guarantees two different
      ids can never collide onto the same file even if sanitizing (or truncating a very
      long id) makes them look identical.
    #>
    param([Parameter(Mandatory)][string]$MeTicketId)

    $chars = $MeTicketId.ToCharArray() | ForEach-Object {
        if ($_ -match '[A-Za-z0-9._-]') { $_ } else { '_' }
    }
    $sanitized = -join $chars
    if ($sanitized.Length -gt 100) {
        $sanitized = $sanitized.Substring(0, 100)
    }
    if ([string]::IsNullOrEmpty($sanitized)) {
        $sanitized = '_'
    }

    $sha1 = [System.Security.Cryptography.SHA1]::Create()
    try {
        $hashBytes = $sha1.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($MeTicketId))
    }
    finally {
        $sha1.Dispose()
    }
    $hashHex = -join ($hashBytes | ForEach-Object { $_.ToString('x2') })
    $hashSuffix = $hashHex.Substring(0, 10)

    return "$sanitized.$hashSuffix"
}

function Get-ProcessedTicketFilePath {
    param([Parameter(Mandatory)][string]$MeTicketId)
    $stem = ConvertTo-ProcessedTicketFileStem -MeTicketId $MeTicketId
    return Join-Path (Get-ProcessedStoreDir) "$stem.json"
}

function ConvertTo-ProcessedTicketRecord {
    # Normalizes whatever the caller passed (hashtable or pscustomobject, with or
    # without a meTicketId field of its own) into a pscustomobject that definitely
    # carries the correct id -- Get-ProcessedTickets builds its keys from this field,
    # never from the filename, so it must be right.
    param([Parameter(Mandatory)][string]$MeTicketId, [object]$Entry)
    $json = $Entry | ConvertTo-Json -Depth 8
    $obj = if ([string]::IsNullOrWhiteSpace($json) -or $json -eq 'null') { [pscustomobject]@{} } else { $json | ConvertFrom-Json }
    $obj | Add-Member -NotePropertyName meTicketId -NotePropertyValue $MeTicketId -Force
    return $obj
}

function Set-ProcessedTicketFileAtomic {
    <#
    .DESCRIPTION
      A crash or kill between writing and installing the new content must never leave a
      truncated file where the old content, or the new content, used to be -- only ever
      one whole version or the other. Move-Item -Force is delete-then-rename on the
      PowerShell FileSystem provider, not an atomic replace, so it is not used here.

      On pwsh (.NET Core/5+), the 3-argument File.Move(src, dst, overwrite) overload is
      an atomic replace on both Windows and Linux (a straight rename(2) with overwrite
      on Unix) and is used directly. That overload does not exist on .NET Framework
      (Windows PowerShell 5.1, Windows-only), where the fallback is: File.Move (2-arg,
      itself atomic) when the destination does not yet exist, or File.Replace when it
      does.

      File.Replace's own signature documents its third (backup) argument as accepting
      $null to mean "no backup kept" -- but empirically, on both PS 5.1 and pwsh 7 on
      this host, passing $null throws ("The path is not of a legal form" / "The path is
      empty"), not the documented no-backup behaviour. A real scratch backup path works
      on both, so that is what this uses on the Desktop-only fallback path; the backup
      file is then deleted immediately (best-effort -- failing to tidy it away is
      cosmetic, the atomic swap itself has already happened by that point).
    #>
    param([Parameter(Mandatory)][string]$TempPath, [Parameter(Mandatory)][string]$DestPath)

    if ($PSVersionTable.PSEdition -eq 'Core') {
        [System.IO.File]::Move($TempPath, $DestPath, $true)
        return
    }

    try {
        [System.IO.File]::Move($TempPath, $DestPath)
    }
    catch [System.IO.IOException] {
        # Destination now exists (either it already did, or another writer just created
        # it) -- Replace is the atomic swap for that case.
        $backupPath = "$DestPath.bak-$([guid]::NewGuid().ToString('N'))"
        [System.IO.File]::Replace($TempPath, $DestPath, $backupPath)
        try { Remove-Item -LiteralPath $backupPath -Force -ErrorAction SilentlyContinue } catch { }
    }
}

function Get-ProcessedTickets {
    <#
    .DESCRIPTION
      Enumerates the per-ticket files. Initialize-ProcessedStore always creates the
      store directory, so by the time any caller reaches this function the directory
      should exist -- if it does not, something removed it after startup, and every
      ticket is about to read as unprocessed. That is exactly the silent-data-loss
      condition this store exists to prevent, so it is reported loudly rather than
      quietly returning an empty map. A single file that fails to parse is skipped with
      a named warning instead of aborting the whole read -- one corrupt ticket must
      never make every other already-processed ticket look unprocessed.
    #>
    [CmdletBinding()]
    param()
    $dir = Get-ProcessedStoreDir
    if (-not (Test-Path -LiteralPath $dir)) {
        Write-Warning "ProcessedStore: store directory '$dir' does not exist. Every ticket will read as unprocessed until it is restored or re-initialized. This is expected only if Initialize-ProcessedStore has never run in this process."
        return @{}
    }

    $store = @{}
    $files = @(Get-ChildItem -LiteralPath $dir -Filter '*.json' -File -ErrorAction SilentlyContinue)
    foreach ($file in $files) {
        # Request-ProcessedTicketClaim opens with FileShare::None between CreateNew and
        # the entry actually being written, so a file can legitimately exist-but-be-
        # unreadable for a brief moment while another process is mid-claim. Without this
        # retry that reads as "corrupt" here: a ticket that provably IS claimed would be
        # reported absent, and a routine concurrent claim would emit a false corruption
        # warning into the operator's log. A few short retries covers that window; a
        # genuine parse failure (bad JSON, missing field) is not a sharing violation and
        # still fails -- and still warns -- on the first attempt.
        $raw = $null
        $sharingViolation = $null
        for ($attempt = 1; $attempt -le 5; $attempt++) {
            try {
                $raw = Get-Content -Raw -LiteralPath $file.FullName -ErrorAction Stop
                $sharingViolation = $null
                break
            }
            catch [System.IO.IOException] {
                $sharingViolation = $_
                if ($attempt -lt 5) { Start-Sleep -Milliseconds 20 }
            }
        }
        if ($sharingViolation) {
            Write-Warning "ProcessedStore: '$($file.FullName)' was still locked after retrying and was skipped ($($sharingViolation.Exception.Message)). If a claim is in flight for this ticket this is transient; if it persists, investigate. Every other ticket's record is unaffected."
            continue
        }
        try {
            if ([string]::IsNullOrWhiteSpace($raw)) { throw 'file is empty' }
            $obj = $raw | ConvertFrom-Json -ErrorAction Stop
            $id = [string]$obj.meTicketId
            if ([string]::IsNullOrWhiteSpace($id)) { throw 'record has no meTicketId field' }
            $store[$id] = $obj
        }
        catch {
            Write-Warning "ProcessedStore: '$($file.FullName)' failed to load and was skipped ($($_.Exception.Message)). Every other ticket's record is unaffected."
        }
    }
    return $store
}

function Save-ProcessedTicket {
    # Unlike the read path, a write must throw on failure -- silently failing to record
    # a grant is exactly what causes a duplicate grant on the next pass. Overwrite is
    # allowed here (unlike Request-ProcessedTicketClaim): this is the "record what just
    # happened" path used by the API after it has already decided to grant or revoke.
    param([Parameter(Mandatory)][string]$MeTicketId, [object]$Entry)
    $id = Assert-ValidTicketId -MeTicketId $MeTicketId
    $dir = Get-ProcessedStoreDir
    $destPath = Get-ProcessedTicketFilePath -MeTicketId $id
    $record = ConvertTo-ProcessedTicketRecord -MeTicketId $id -Entry $Entry

    $tempPath = Join-Path $dir ("$([guid]::NewGuid().ToString('N')).tmp")
    # Set-Content -Encoding UTF8 writes a BOM on PS 5.1 (but not pwsh 7), which would
    # put two different encodings of "UTF-8" in the same directory depending on which
    # process wrote a given file. WriteAllBytes with UTF8.GetBytes (which never emits a
    # BOM) matches what Request-ProcessedTicketClaim already writes below.
    $bytes = [System.Text.Encoding]::UTF8.GetBytes(($record | ConvertTo-Json -Depth 8))
    [System.IO.File]::WriteAllBytes($tempPath, $bytes)
    try {
        Set-ProcessedTicketFileAtomic -TempPath $tempPath -DestPath $destPath
    }
    catch {
        try { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue } catch { }
        throw
    }
}

function Request-ProcessedTicketClaim {
    <#
    .DESCRIPTION
      The primitive the unattended poller uses to guarantee it never grants a ticket
      twice: returns $true only for whichever caller's CreateNew actually created the
      file, $false for every other contender. The CreateNew open IS the atomicity --
      the entry is written through that same handle, not created empty and then filled
      in by a separate write, which would reopen the race this function exists to
      close.
    #>
    param([Parameter(Mandatory)][string]$MeTicketId, [object]$Entry)
    $id = Assert-ValidTicketId -MeTicketId $MeTicketId
    $destPath = Get-ProcessedTicketFilePath -MeTicketId $id
    $record = ConvertTo-ProcessedTicketRecord -MeTicketId $id -Entry $Entry
    $bytes = [System.Text.Encoding]::UTF8.GetBytes(($record | ConvertTo-Json -Depth 8))

    try {
        $stream = [System.IO.File]::Open($destPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    }
    catch [System.IO.IOException] {
        # CreateNew throws IOException when the file already exists -- another caller
        # (this process or another) already holds this claim. Losing is a normal
        # outcome, not an error.
        #
        # DirectoryNotFoundException, FileNotFoundException and PathTooLongException are
        # ALL subclasses of IOException, so a bare "catch [IOException]" here also traps
        # every one of them -- a missing store directory, a bad path, anything -- and
        # reported every such failure back to the caller as "someone else already
        # claimed it", the exact inverse of the truth, with no warning. Only treat this
        # as "lost the race" when the destination file provably exists (the only way
        # CreateNew legitimately fails) or the exception is exactly IOException (not a
        # subclass carrying a different meaning). Anything else is a real failure and
        # must propagate so the caller cannot mistake it for a normal loss.
        $isExactIOException = $_.Exception.GetType() -eq [System.IO.IOException]
        if ((-not [System.IO.File]::Exists($destPath)) -and (-not $isExactIOException)) {
            throw
        }
        return $false
    }
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()
    }
    finally {
        $stream.Dispose()
    }
    return $true
}

function Remove-ProcessedTicketEntry {
    param([Parameter(Mandatory)][string]$MeTicketId)
    $id = Assert-ValidTicketId -MeTicketId $MeTicketId
    $path = Get-ProcessedTicketFilePath -MeTicketId $id
    if (Test-Path -LiteralPath $path) {
        Remove-Item -LiteralPath $path -Force -ErrorAction Stop
    }
}

function Invoke-ProcessedStoreMigration {
    <#
    .DESCRIPTION
      Runs once per legacy file. Reads dashboard/api/processed-tickets.json (if it is
      still there), writes any entry that does not already have a per-ticket file, then
      renames the legacy file aside so it is preserved but never re-migrated.

      Uses Request-ProcessedTicketClaim (the same CreateNew-based primitive as the
      poller) to write each entry, so this is safe to run from two processes that both
      start up at once: whichever one wins a given ticket's claim writes it, the other
      sees "already exists" and treats that as success, and neither can clobber a
      per-ticket file that is newer than the legacy snapshot.
    #>
    param([Parameter(Mandatory)][string]$LegacyPath)
    if (-not (Test-Path -LiteralPath $LegacyPath)) { return }

    $raw = $null
    try {
        $raw = Get-Content -Raw -LiteralPath $LegacyPath -ErrorAction Stop
    }
    catch {
        Write-Warning "ProcessedStore: could not read legacy store '$LegacyPath' for migration ($($_.Exception.Message)). Leaving it in place and continuing with whatever per-ticket files already exist."
        return
    }

    $legacyEntries = @{}
    if (-not [string]::IsNullOrWhiteSpace($raw)) {
        try {
            $parsed = $raw | ConvertFrom-Json -ErrorAction Stop
            $parsed.PSObject.Properties | ForEach-Object { $legacyEntries[$_.Name] = $_.Value }
        }
        catch {
            # Corrupt legacy file: never delete or rename it away, because that would
            # destroy the only copy of whatever real entries it still has. Warn loudly
            # and carry on with whatever per-ticket files already exist.
            Write-Warning "ProcessedStore: legacy store '$LegacyPath' failed to parse and was NOT migrated or renamed. Fix or remove it manually once you've confirmed no ticket is missing its per-ticket record."
            return
        }
    }

    foreach ($key in $legacyEntries.Keys) {
        $entryId = [string]$key
        if ([string]::IsNullOrWhiteSpace($entryId)) {
            Write-Warning "ProcessedStore: skipped a legacy entry with an empty/whitespace ticket id during migration."
            continue
        }
        try {
            # $false here normally means a per-ticket file already exists for this id
            # (from an earlier migration, or a normal write since), which is the "never
            # overwrite a newer per-ticket file" requirement, not a failure. But that is
            # only true if the file is actually there -- silently discarding the result
            # (as this used to do with [void]) would hide the one case that must never
            # be silent: a claim that neither won nor lost to an existing file, meaning
            # this legacy entry did not land anywhere.
            $won = Request-ProcessedTicketClaim -MeTicketId $entryId -Entry $legacyEntries[$key]
            if (-not $won) {
                $destPath = Get-ProcessedTicketFilePath -MeTicketId $entryId
                if (-not (Test-Path -LiteralPath $destPath)) {
                    Write-Warning "ProcessedStore: legacy entry '$entryId' was not migrated -- the claim lost but no per-ticket file exists for it. This entry may be lost; check '$LegacyPath' manually."
                }
            }
        }
        catch {
            Write-Warning "ProcessedStore: failed to migrate legacy entry '$entryId' ($($_.Exception.Message))."
        }
    }

    $renamedPath = "$LegacyPath.migrated-$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
    try {
        [System.IO.File]::Move($LegacyPath, $renamedPath)
    }
    catch [System.IO.FileNotFoundException] {
        # FileNotFoundException is IOException's sibling for "source is gone", not
        # "destination collided" -- it means another process already renamed the legacy
        # file aside while we were migrating (both migrations reading the same legacy
        # snapshot concurrently). That is success, not a failure to warn about: check
        # first before assuming otherwise.
        if (-not (Test-Path -LiteralPath $LegacyPath)) {
            return
        }
        Write-Warning "ProcessedStore: migrated legacy entries but could not rename '$LegacyPath' aside ($($_.Exception.Message)). It will be re-read (harmlessly, since per-ticket files now win) on next startup."
    }
    catch [System.IO.IOException] {
        # Two processes migrating within the same UTC second (or two runs in this same
        # process, as in a test) land on the identical timestamped name. Fall back to a
        # collision-proof name rather than losing this snapshot.
        $renamedPath = "$renamedPath-$([guid]::NewGuid().ToString('N'))"
        try {
            [System.IO.File]::Move($LegacyPath, $renamedPath)
        }
        catch {
            Write-Warning "ProcessedStore: migrated legacy entries but could not rename '$LegacyPath' aside ($($_.Exception.Message)). It will be re-read (harmlessly, since per-ticket files now win) on next startup."
        }
    }
    catch {
        Write-Warning "ProcessedStore: migrated legacy entries but could not rename '$LegacyPath' aside ($($_.Exception.Message)). It will be re-read (harmlessly, since per-ticket files now win) on next startup."
    }
}
