﻿<#
.SYNOPSIS
    FR6 / NFR3 — immutable, append-only audit trail for every AzureSentry agent action.

.DESCRIPTION
    Every agent activity (read, summarize, provision, tag-update, revoke, rollback)
    is appended as one JSON object per line to audit-log.jsonl. Lines are never
    rewritten or deleted: a correction or rollback is recorded as a NEW compensating
    event that references the original via CorrectsEventId.

    Each event carries:
      seq        monotonic sequence number
      hash       SHA256 over (prevHash + canonical event body) — tamper-evident chain
      prevHash   hash of the preceding event ('GENESIS' for the first)
      agent      which agent acted (see src/Agents/AgentRuntime.ps1 registry)
      action     what it did
      actor      the human or service identity on whose behalf it acted
      target     what was acted on (subscription, ticket, group, role)
      before/after   state snapshots, so a rollback is mechanically derivable
      outcome    Success | Failed | Blocked | DryRun

    NOT a replacement for Log Analytics (Deliverable #10) — this is the local,
    always-on trail that works before infra is deployed and seeds the LA ingest later.
#>

$script:AuditLogPath = $null
$script:AuditLastHash = $null
$script:AuditLastSeq = 0
$script:AuditLock = [System.Object]::new()

function Initialize-AuditLog {
    <#
    .SYNOPSIS
      Points the audit trail at a file and recovers the hash chain head.
      Safe to call repeatedly.
    #>
    param(
        [Parameter(Mandatory)][string]$Path
    )

    $script:AuditLogPath = $Path
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    $script:AuditLastHash = 'GENESIS'
    $script:AuditLastSeq = 0

    if (Test-Path $Path) {
        # Recover chain head from the last well-formed line (tail-read, not full parse).
        # -Encoding UTF8 explicitly, for the same reason as every other Get-Content call
        # in this file: its DEFAULT encoding differs by host (Windows PowerShell 5.1
        # falls back to the system ANSI code page for a BOM-less file; pwsh 7 defaults
        # to UTF-8), and Write-AuditEvent writes UTF-8 without a BOM -- confirmed against
        # this project's own log, a zero-width space mojibakes into 'â€‹' under PS 5.1
        # without this. This specific call only reads .hash/.seq (always ASCII, immune
        # either way) so a wrong encoding wouldn't corrupt chain-head recovery here --
        # fixed anyway for consistency, since every other reader of this file needs it
        # for correctness and a file should never be read two different ways.
        $lines = @(Get-Content -Path $Path -Encoding UTF8 -ErrorAction SilentlyContinue)
        for ($i = $lines.Count - 1; $i -ge 0; $i--) {
            $line = [string]$lines[$i]
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            try {
                $obj = $line | ConvertFrom-Json -ErrorAction Stop
                if ($obj.hash) {
                    $script:AuditLastHash = [string]$obj.hash
                    $script:AuditLastSeq = [int]$obj.seq
                    break
                }
            }
            catch { continue }
        }
    }
    return [pscustomobject]@{
        path    = $script:AuditLogPath
        lastSeq = $script:AuditLastSeq
    }
}

function Get-AuditLogPath {
    return $script:AuditLogPath
}

# The hashed fields, in the order they are hashed. `id`, `prevHash` and `hash` are
# envelope fields added after hashing and are deliberately excluded.
$script:AuditBodyFields = @(
    'seq', 'timestamp', 'agent', 'action', 'actor', 'runId', 'correlationId', 'ticketId',
    'target', 'before', 'after', 'outcome', 'reason', 'detail', 'correctsEventId', 'isWrite'
)

function ConvertTo-CanonicalJsonString {
    <#
    .SYNOPSIS
      JSON-escapes a string using ONLY what the JSON spec requires -- nothing else.
    .DESCRIPTION
      The whole reason ConvertTo-CanonicalJsonValue exists (see there): PowerShell's
      built-in ConvertTo-Json escapes MORE than JSON requires, and DIFFERENTLY on
      different hosts -- confirmed against this exact codebase's audit log: Windows
      PowerShell 5.1 escapes `'` as ', pwsh 7 does not. Escaping `'` is not
      wrong JSON, but it means recomputing a hash from the SAME already-written text
      produces a DIFFERENT byte sequence depending which host runs the recompute --
      exactly what broke chain verification here. This function escapes only `"`, `\`,
      and control characters below 0x20 (the JSON spec's own \b \f \n \r \t shortcuts,
      else \u00XX) -- every other character, including `'`, `<`, `>`, `&`, and all
      printable non-ASCII text, passes through as a literal UTF-16 char. The final hash
      is computed over UTF-8 BYTES of the resulting string (Get-AuditEventHash), so
      leaving non-ASCII unescaped is still correct, unambiguous JSON -- and, critically,
      identical on every host, because no host-specific cmdlet ever touches it.

      Character classification below compares [int] CODEPOINTS with -eq, NEVER a
      `switch` on char/string values and NEVER PowerShell's own -eq between a [char]
      and a [string]. Confirmed the hard way: PowerShell's `switch` statement compares
      string case labels CULTURE-AWARE, not ordinal, and .NET's culture-aware collation
      treats certain Unicode "format" characters as collation-equal to unrelated control
      characters -- concretely, `switch ([char]0x200B) { "`b" {...} }` MATCHES the
      backspace (U+0008) case under pwsh 7 (.NET's culture comparison there treats a
      zero-width space as equal to backspace) but correctly falls through to `default`
      under Windows PowerShell 5.1. That is a THIRD host-dependent divergence, on top of
      ConvertTo-Json's escaping and Get-Content's default encoding (see Test-
      AuditChainIntegrity and the Get-Content call sites), and it silently corrupted
      real data: a zero-width space in a real audit event got serialized as a literal
      backspace escape before this was caught. Integer codepoint comparison has no
      culture, so it cannot drift between hosts.
    #>
    param([string]$Value)

    if ($null -eq $Value) { return '""' }

    $sb = [System.Text.StringBuilder]::new($Value.Length + 8)
    [void]$sb.Append('"')
    foreach ($ch in $Value.ToCharArray()) {
        $code = [int]$ch
        if ($code -eq 0x22) { [void]$sb.Append('\"'); continue }
        if ($code -eq 0x5C) { [void]$sb.Append('\\'); continue }
        if ($code -eq 0x08) { [void]$sb.Append('\b'); continue }
        if ($code -eq 0x0C) { [void]$sb.Append('\f'); continue }
        if ($code -eq 0x0A) { [void]$sb.Append('\n'); continue }
        if ($code -eq 0x0D) { [void]$sb.Append('\r'); continue }
        if ($code -eq 0x09) { [void]$sb.Append('\t'); continue }
        if ($code -lt 0x20) {
            [void]$sb.Append(('\u{0:x4}' -f $code))
            continue
        }
        # Deliberately NOT escaped: ', <, >, &, and every printable character
        # including non-ASCII. A surrogate-pair character (an emoji, some CJK) arrives
        # here as two separate UTF-16 chars, each individually >= 0x20 -- both pass
        # through unescaped in order, which recombines correctly when the whole string
        # is later UTF-8-encoded. No special handling needed.
        [void]$sb.Append($ch)
    }
    [void]$sb.Append('"')
    return $sb.ToString()
}

function ConvertTo-CanonicalJsonValue {
    <#
    .SYNOPSIS
      Deterministic, host-independent JSON serialization for audit-chain hashing.
    .DESCRIPTION
      Replaces ConvertTo-Json for anything whose output feeds a hash. Two problems
      with ConvertTo-Json, both confirmed against this codebase's real audit log:

        1. Escaping is host-dependent (see ConvertTo-CanonicalJsonString) -- the same
           already-written record hashes differently depending which PowerShell host
           recomputes it, which is exactly what "Verify chain" reported as false
           tampering here.
        2. Hashtable/dictionary key order is not a language guarantee, and .NET
           Framework (PS 5.1) and .NET (pwsh 7+) do not have to agree on it even for
           identical insertions -- a SECOND, independent source of the same class of
           bug beyond escaping.

      This function sorts every object's keys ordinally (culture- and host-independent)
      at every nesting level and escapes strings itself rather than delegating to a
      cmdlet, so the same logical content always produces the exact same byte sequence
      everywhere: same host, different host, different .NET runtime, different locale.
      No artificial depth limit (ConvertTo-Json's default -Depth 2, or an explicit cap,
      silently truncates data that goes into a HASH -- silent truncation of hashed
      content is its own class of bug); a defensive MaxDepth still guards against a
      pathological/circular input by throwing loudly instead of recursing forever.
    #>
    param([object]$Value, [int]$Depth = 0)

    if ($Depth -gt 64) {
        throw 'ConvertTo-CanonicalJsonValue: exceeded max depth (64) -- circular reference or pathological input.'
    }

    if ($null -eq $Value) { return 'null' }

    if ($Value -is [bool]) { return $(if ($Value) { 'true' } else { 'false' }) }

    if ($Value -is [datetime]) {
        return ConvertTo-CanonicalJsonString -Value $Value.ToUniversalTime().ToString('o')
    }
    if ($Value -is [guid]) {
        return ConvertTo-CanonicalJsonString -Value $Value.ToString()
    }

    if ($Value -is [string]) { return ConvertTo-CanonicalJsonString -Value $Value }

    if ($Value -is [System.Collections.IDictionary]) {
        $keys = [string[]]@($Value.Keys | ForEach-Object { [string]$_ })
        [Array]::Sort($keys, [System.StringComparer]::Ordinal)
        $parts = foreach ($k in $keys) {
            (ConvertTo-CanonicalJsonString -Value $k) + ':' + (ConvertTo-CanonicalJsonValue -Value $Value[$k] -Depth ($Depth + 1))
        }
        return '{' + ($parts -join ',') + '}'
    }

    if ($Value -is [System.Management.Automation.PSCustomObject]) {
        $keys = [string[]]@($Value.PSObject.Properties.Name)
        [Array]::Sort($keys, [System.StringComparer]::Ordinal)
        $parts = foreach ($k in $keys) {
            (ConvertTo-CanonicalJsonString -Value $k) + ':' + (ConvertTo-CanonicalJsonValue -Value $Value.$k -Depth ($Depth + 1))
        }
        return '{' + ($parts -join ',') + '}'
    }

    # Arrays / any other enumerable (but not a string -- already handled above, and a
    # string IS IEnumerable<char>, which would otherwise wrongly fall into this branch).
    if ($Value -is [System.Collections.IEnumerable]) {
        $parts = foreach ($item in $Value) { ConvertTo-CanonicalJsonValue -Value $item -Depth ($Depth + 1) }
        return '[' + ($parts -join ',') + ']'
    }

    # Remaining value types: int/long/double/decimal/byte/etc. InvariantCulture so a
    # locale that uses ',' as a decimal separator can never produce invalid JSON.
    if ($Value -is [System.ValueType]) {
        return $Value.ToString([System.Globalization.CultureInfo]::InvariantCulture)
    }

    # Fallback for anything unanticipated: stringify rather than let ConvertTo-Json's
    # host-dependent behaviour back in through a gap in the type checks above.
    return ConvertTo-CanonicalJsonString -Value ([string]$Value)
}

function Get-AuditCanonicalBody {
    <#
    .SYNOPSIS
      Serializes the hashed portion of an event to one canonical JSON string.

    .DESCRIPTION
      Used by BOTH the writer and the integrity checker, so the two can never drift.
      It accepts either the ordered hashtable being written or an event parsed back
      from the log file.

      The important normalization is the timestamp: ConvertFrom-Json coerces an
      ISO-8601 string into a [datetime], so a naive re-serialize of a parsed event
      produces a different string than the one that was hashed, and every verification
      would fail as a false tamper alarm.

      Serialization itself is ConvertTo-CanonicalJsonValue, not ConvertTo-Json -- see
      that function's .DESCRIPTION for why: ConvertTo-Json's escaping and hashtable key
      order are not guaranteed identical across PowerShell hosts, which is exactly what
      caused real, confirmed false "tampered" reports in this project's own audit log
      (Windows PowerShell 5.1 vs pwsh 7 disagreeing on both).
    #>
    param([Parameter(Mandatory)]$Source)

    $read = {
        param($key)
        if ($Source -is [System.Collections.IDictionary]) { return $Source[$key] }
        return $Source.$key
    }

    $body = [ordered]@{}
    foreach ($field in $script:AuditBodyFields) {
        $value = & $read $field
        switch ($field) {
            'timestamp' {
                $value = if ($value -is [datetime]) { $value.ToUniversalTime().ToString('o') } else { [string]$value }
            }
            'seq' { $value = [int]$value }
            'isWrite' { $value = [bool]$value }
        }
        $body[$field] = $value
    }
    return (ConvertTo-CanonicalJsonValue -Value $body)
}

function Get-AuditEventHash {
    param([string]$PrevHash, [string]$BodyJson)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes("$PrevHash|$BodyJson")
        return ([System.BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-', '').ToLowerInvariant()
    }
    finally { $sha.Dispose() }
}

function Write-AuditEvent {
    <#
    .SYNOPSIS
      Appends one immutable audit event. Never throws into the caller's path —
      an audit write failure is reported but must not fail the agent action
      that was already carried out (that would be worse than a missing line).
    .OUTPUTS
      The event object that was written (or $null if the write failed).
    #>
    [CmdletBinding()]
    param(
        # Which agent performed the action (canonical agent name).
        [Parameter(Mandatory)][string]$Agent,
        # What the agent did, e.g. 'ProvisionAccess', 'UpdateEnvironmentTag', 'Summarize'.
        [Parameter(Mandatory)][string]$Action,
        # Human or service identity on whose behalf the agent acted.
        [string]$Actor = 'system',
        # Correlates every event in one agent run (see AgentRuntime).
        [string]$RunId,
        # Groups a multi-agent flow for one ticket / batch.
        [string]$CorrelationId,
        [string]$TicketId,
        # What was acted on: subscription id/name, group, role, ME ticket, ...
        [hashtable]$Target,
        # State before / after the change — the basis for rollback.
        [object]$Before,
        [object]$After,
        [ValidateSet('Success', 'Failed', 'Blocked', 'DryRun', 'Started')][string]$Outcome = 'Success',
        [string]$Reason,
        # Free-form structured extras (decision path, batch number, confidence, ...).
        [hashtable]$Detail,
        # Set when this event compensates/corrects an earlier one (rollback).
        [string]$CorrectsEventId,
        # True when the action changed state in an external system.
        [bool]$IsWrite = $false
    )

    if (-not $script:AuditLogPath) {
        Write-Verbose 'Audit log not initialized; call Initialize-AuditLog first.'
        return $null
    }

    # Populated inside the lock on success; used after the lock is released to decide
    # whether to forward to Log Analytics and what to return. No early `return` inside
    # the try below — a `return` there would exit the function as soon as `finally`
    # runs, skipping the forward step entirely.
    $resultEvent = $null

    [System.Threading.Monitor]::Enter($script:AuditLock)
    try {
        $seq = $script:AuditLastSeq + 1
        $prevHash = if ($script:AuditLastHash) { $script:AuditLastHash } else { 'GENESIS' }

        $body = [ordered]@{
            seq             = $seq
            timestamp       = (Get-Date).ToUniversalTime().ToString('o')
            agent           = $Agent
            action          = $Action
            actor           = $Actor
            runId           = $RunId
            correlationId   = $CorrelationId
            ticketId        = $TicketId
            target          = $Target
            before          = $Before
            after           = $After
            outcome         = $Outcome
            reason          = $Reason
            detail          = $Detail
            correctsEventId = $CorrectsEventId
            isWrite         = $IsWrite
        }

        $bodyJson = Get-AuditCanonicalBody -Source $body
        $hash = Get-AuditEventHash -PrevHash $prevHash -BodyJson $bodyJson

        $event = [ordered]@{}
        foreach ($k in $body.Keys) { $event[$k] = $body[$k] }
        $event['id'] = "$seq-$($hash.Substring(0, 12))"
        $event['prevHash'] = $prevHash
        $event['hash'] = $hash

        # Not ConvertTo-Json: same host-dependent escaping/key-order concerns as
        # Get-AuditCanonicalBody above -- see ConvertTo-CanonicalJsonValue's
        # .DESCRIPTION. Using it here too (not just for hashing) means the file on
        # disk is itself host-independent, not only the hash computed over it.
        $line = ConvertTo-CanonicalJsonValue -Value $event
        # Append-only. UTF8 without BOM, one line per event.
        $writer = [System.IO.StreamWriter]::new($script:AuditLogPath, $true, [Text.UTF8Encoding]::new($false))
        try { $writer.WriteLine($line) } finally { $writer.Dispose() }

        $script:AuditLastHash = $hash
        $script:AuditLastSeq = $seq
        $resultEvent = [pscustomobject]$event
    }
    catch {
        Write-Host "[audit] failed to append event ($Agent/$Action): $($_.Exception.Message)" -ForegroundColor Yellow
    }
    finally {
        [System.Threading.Monitor]::Exit($script:AuditLock)
    }

    # FR6/Deliverable #10 — best-effort forward to Log Analytics, deliberately OUTSIDE
    # the lock above so a slow/unreachable network call never serializes every other
    # audit write behind it. A no-op until AZURESENTRY_LA_* is configured (see
    # LogAnalyticsClient.ps1); a failure here never affects the local trail, which
    # already succeeded and is the system of record.
    if ($resultEvent -and (Get-Command -Name Send-LogAnalyticsAuditEvent -ErrorAction SilentlyContinue)) {
        # Send-LogAnalyticsAuditEvent already catches its own errors and returns
        # ok=false rather than throwing — this try/catch is a second, defensive layer
        # so a bug in that client (or a test mocking it to throw directly) can never
        # take down the caller's actual agent action, which already succeeded locally.
        try { Send-LogAnalyticsAuditEvent -Event $resultEvent | Out-Null }
        catch { Write-Host "[log-analytics] unexpected error forwarding audit event: $($_.Exception.Message)" -ForegroundColor Yellow }
    }

    return $resultEvent
}

function Get-AuditEvents {
    <#
    .SYNOPSIS
      Reads audit events newest-first, with optional filters.
    #>
    [CmdletBinding()]
    param(
        [int]$Limit = 200,
        [string]$Agent,
        [string]$Action,
        [string]$TicketId,
        [string]$Actor,
        [string]$Outcome,
        [string]$CorrelationId,
        # Only events written in the last N hours.
        [int]$Hours = 0,
        # Only events that changed external state.
        [switch]$WritesOnly
    )

    if (-not $script:AuditLogPath -or -not (Test-Path $script:AuditLogPath)) { return @() }

    $cutoff = if ($Hours -gt 0) { (Get-Date).ToUniversalTime().AddHours(-$Hours) } else { $null }
    $out = [System.Collections.Generic.List[object]]::new()

    # Read all lines then walk backwards so newest-first is cheap for the common
    # "latest 200" case. The local trail is bounded by demo/backfill volume.
    # -Encoding UTF8: see Initialize-AuditLog's identical comment. This one DOES matter
    # for correctness -- these events feed the Audit Logs UI directly, so a wrong
    # encoding here means ticket text with any non-ASCII character (a real, observed
    # case: a zero-width space from a copy-pasted description) renders as mojibake on
    # screen under PS 5.1, not just in a hash.
    $lines = @(Get-Content -Path $script:AuditLogPath -Encoding UTF8 -ErrorAction SilentlyContinue)
    for ($i = $lines.Count - 1; $i -ge 0; $i--) {
        if ($out.Count -ge $Limit) { break }
        $line = [string]$lines[$i]
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try { $obj = $line | ConvertFrom-Json -ErrorAction Stop } catch { continue }

        if ($Agent -and [string]$obj.agent -ne $Agent) { continue }
        if ($Action -and [string]$obj.action -ne $Action) { continue }
        if ($TicketId -and [string]$obj.ticketId -ne $TicketId) { continue }
        if ($Actor -and [string]$obj.actor -notlike "*$Actor*") { continue }
        if ($Outcome -and [string]$obj.outcome -ne $Outcome) { continue }
        if ($CorrelationId -and [string]$obj.correlationId -ne $CorrelationId) { continue }
        if ($WritesOnly -and -not $obj.isWrite) { continue }
        if ($cutoff) {
            $ts = $null
            if ([datetime]::TryParse([string]$obj.timestamp, [ref]$ts)) {
                if ($ts.ToUniversalTime() -lt $cutoff) { continue }
            }
        }
        $out.Add($obj)
    }
    return @($out)
}

function Get-AuditSummary {
    <#
    .SYNOPSIS
      Roll-up for the Audit Logs view header: totals by agent, action and outcome.
    #>
    param([int]$Limit = 5000)

    # Wrap in @() — PowerShell unrolls a single-element array on assignment, and then
    # .Count would be $null instead of 1.
    $events = @(Get-AuditEvents -Limit $Limit)
    $byAgent = @{}
    $byAction = @{}
    $byOutcome = @{}
    $writes = 0
    foreach ($e in $events) {
        $a = [string]$e.agent; if ($a) { $byAgent[$a] = 1 + [int]$byAgent[$a] }
        $c = [string]$e.action; if ($c) { $byAction[$c] = 1 + [int]$byAction[$c] }
        $o = [string]$e.outcome; if ($o) { $byOutcome[$o] = 1 + [int]$byOutcome[$o] }
        if ($e.isWrite) { $writes++ }
    }
    return [pscustomobject]@{
        total     = $events.Count
        writes    = $writes
        byAgent   = $byAgent
        byAction  = $byAction
        byOutcome = $byOutcome
        lastSeq   = $script:AuditLastSeq
        path      = $script:AuditLogPath
    }
}

function Test-AuditChainIntegrity {
    <#
    .SYNOPSIS
      NFR3 verification — recomputes the hash chain and reports the first break.
      Proves no line was edited or removed after the fact.
    #>
    param([string]$Path)

    $target = if ($Path) { $Path } else { $script:AuditLogPath }
    if (-not $target -or -not (Test-Path $target)) {
        return [pscustomobject]@{ ok = $true; checked = 0; reason = 'No audit log yet.' }
    }

    $prevHash = 'GENESIS'
    $expectedSeq = 1
    $checked = 0
    # -Encoding UTF8: see Initialize-AuditLog's identical comment. This is the call
    # that actually reproduced the false "tampered" report -- confirmed directly: PS 5.1
    # without this misreads a zero-width space in a real ticket description into three
    # garbage characters before it is ever re-hashed, which then never matches.
    foreach ($line in (Get-Content -Path $target -Encoding UTF8)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try { $obj = $line | ConvertFrom-Json -ErrorAction Stop }
        catch {
            return [pscustomobject]@{ ok = $false; checked = $checked; reason = "Unparseable line at position $($checked + 1)." }
        }

        if ([int]$obj.seq -ne $expectedSeq) {
            return [pscustomobject]@{ ok = $false; checked = $checked; reason = "Sequence gap: expected $expectedSeq, found $($obj.seq)." }
        }
        if ([string]$obj.prevHash -ne $prevHash) {
            return [pscustomobject]@{ ok = $false; checked = $checked; reason = "Chain break at seq $($obj.seq): prevHash mismatch." }
        }

        # Recompute over the hashed fields only, through the same canonicalizer the writer used.
        $recomputed = Get-AuditEventHash -PrevHash $prevHash -BodyJson (Get-AuditCanonicalBody -Source $obj)
        if ($recomputed -ne [string]$obj.hash) {
            return [pscustomobject]@{ ok = $false; checked = $checked; reason = "Tampered event at seq $($obj.seq): hash mismatch." }
        }

        $prevHash = [string]$obj.hash
        $expectedSeq++
        $checked++
    }
    return [pscustomobject]@{ ok = $true; checked = $checked; reason = 'Chain intact.' }
}

function Test-AuditChainIntegrityMulti {
    <#
    .SYNOPSIS
      Verifies one or more independent hash chains and reports a combined result.
    .DESCRIPTION
      The dashboard API and the unattended poller each own a SEPARATE audit log file
      (dashboard/api/audit-log.jsonl and dashboard/api/audit-log-poller.jsonl -- see
      Initialize-AuditLog call sites in Start-DashboardApi.ps1 and
      scripts/Invoke-TicketPollerCycle.ps1) precisely because two processes appending to
      ONE file corrupt each other's chain: each writer derives seq/prevHash from state
      cached in its own process at Initialize-AuditLog and never sees the other's writes.
      Each file is still a fully valid, independently verifiable chain on its own -- this
      runs Test-AuditChainIntegrity per file and reports whether ALL of them are intact,
      not just one, so an operator has a single answer to "is the audit trail OK" that
      covers both writers.
    .PARAMETER Chains
      Array of @{ Name = <label>; Path = <file path> }.
    #>
    param([Parameter(Mandatory)][object[]]$Chains)

    $results = foreach ($c in $Chains) {
        $name = [string]$c.Name
        $path = [string]$c.Path
        $r = Test-AuditChainIntegrity -Path $path
        [pscustomobject]@{ chain = $name; path = $path; ok = $r.ok; checked = $r.checked; reason = $r.reason }
    }
    $results = @($results)
    return [pscustomobject]@{
        ok     = (@($results | Where-Object { -not $_.ok })).Count -eq 0
        chains = $results
    }
}
