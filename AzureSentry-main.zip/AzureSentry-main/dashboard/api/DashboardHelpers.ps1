# Pure helper functions extracted from Start-DashboardApi.ps1 so the highest-value
# branches touched by the final-review fixes (ManageEngine note classification, and the
# revoke eligibility/mode decision) have direct, HTTP-listener-free test coverage.
# See final-review.md I4.

function Get-ManageEngineNoteKind {
    <#
    .SYNOPSIS
        Classifies which "what happens next" branch the requester-facing ManageEngine
        note should use, given a Decision and (optional) Execution result.
    .DESCRIPTION
        Mirrors the classification previously inlined in Send-ManageEngineProcessNote.
        Extracted as a pure function (no I/O, no globals) so the group-fulfilment note
        fix (I1/I2) is testable without running the dashboard's HTTP listener.
    #>
    param(
        [Parameter(Mandatory)]$Decision,
        $Execution = $null
    )

    $assignType = $null
    if ($Execution -and $Execution.AssignmentType) { $assignType = $Execution.AssignmentType }
    elseif ($Decision.AssignmentType) { $assignType = $Decision.AssignmentType }

    $isEligible = ($assignType -eq 'Eligible') -or
        (($Decision.Action -eq 'Eligible') -and ($assignType -ne 'Active'))

    # Failure branch: Execution.Success must be EXPLICITLY $false, not merely absent.
    # '$null -eq $false' is $false in PowerShell, so a caller that never sets Success at
    # all (every existing dashboard call site, which only calls this after Success is
    # already known true) falls through unaffected -- only a caller that deliberately
    # reports Success = $false (the poller, on a failed unattended grant) hits this.
    $isFailed = ($Execution -and ($Execution.Success -eq $false))

    $kind =
        if ($Decision.Action -eq 'Revoke') { 'Revoke' }
        elseif ($isFailed) { 'Failed' }
        elseif ($isEligible) { 'Eligible' }
        elseif ($assignType -eq 'GroupMembership') { 'GroupMembership' }
        elseif ($Decision.Action -eq 'Grant' -or $Decision.Action -eq 'BreakGlass') { 'TimeBoundGrant' }
        else { 'None' }

    return [pscustomobject]@{
        Kind           = $kind
        AssignmentType = $assignType
    }
}

function Test-GrantRevocable {
    <#
    .SYNOPSIS
        True when a processed-ticket store entry has something to revoke: either a PIM
        assignment id, or group-membership fulfilment with a stored groupId (final-review C1).
        Already-revoked entries are not revocable (allows re-process after rollback).
    #>
    param($Prior)
    if (-not $Prior) { return $false }
    if ($Prior.revoked) { return $false }
    if ($Prior.assignmentId) { return $true }
    if (([string]$Prior.fulfilment -eq 'Group') -and $Prior.groupId) { return $true }
    return $false
}

function Get-RevokeFulfilmentMode {
    <#
    .SYNOPSIS
        Which revoke mechanism applies to a stored processed-ticket entry: 'Group'
        (remove Entra group membership) or 'Assignment' (remove the PIM assignment).
    #>
    param($Prior)
    if ($Prior -and ([string]$Prior.fulfilment -eq 'Group') -and $Prior.groupId) { return 'Group' }
    return 'Assignment'
}

function Get-GrantExpiryTimestamp {
    <#
    .SYNOPSIS
        The recorded expiry timestamp (ISO-8601, UTC) to store on a processed-ticket
        record for a grant, regardless of how it was fulfilled.

    .DESCRIPTION
        Both call sites (scripts/Invoke-TicketPollerCycle.ps1's $executeGrant, and
        Start-DashboardApi.ps1's human grant path) compute the SAME value here now --
        Now + DurationDays -- but what that value MEANS differs by fulfilment, and that
        difference matters for the safety case:

          PimFallback: this is an AZURE-ENFORCED expiry. The role assignment schedule
          request itself carries the deadline; ARM times it out on its own, even if
          AzureSentry (dashboard, poller, reaper) is completely down.

          Group: this is a TRACKED expiry only. Entra group membership has NO native
          expiry mechanism -- there is nothing in Azure to enforce it. This timestamp is
          this platform remembering a deadline it is solely responsible for acting on,
          via the reaper agent (src/Agents/ReaperAgent.ps1 + scripts/Invoke-ReaperCycle.ps1)
          on its own schedule. If the reaper stops running (crashes, is disabled, the VM
          is down), a tracked-expired group grant does NOT evaporate by itself -- it sits
          there until the reaper (or a human) revokes it. Before this function existed,
          the Group path recorded $null here, meaning every unattended group grant was
          permanent until a human noticed and revoked it by hand.

        Do not read this value as "Azure will end this access on its own" for a Group
        fulfilment -- it will not. Callers that care about the distinction should branch
        on the record's own `fulfilment` field, not on how this value was computed (the
        computation is identical either way).
    #>
    param(
        [Parameter(Mandatory)][int]$DurationDays,
        [datetime]$Now = (Get-Date)
    )
    return $Now.AddDays($DurationDays).ToUniversalTime().ToString('o')
}

function Get-GrantExpiryEnforcement {
    <#
    .SYNOPSIS
        Names WHICH KIND of expiry Get-GrantExpiryTimestamp's value is for a given
        fulfilment, as an explicit string an auditor can read off the record without
        having to already know the PimFallback/Group distinction by heart.
    .DESCRIPTION
        Two callers write this alongside every grant-creation audit event (the poller's
        UnattendedGrant event and the dashboard's ProvisionAccess event) so the audit
        trail alone -- not the code, not tribal knowledge -- tells an auditor whether a
        given grant's expiry is Azure's problem or this platform's problem:

          'AzureEnforced' (Fulfilment 'PimFallback'): ARM times the assignment out on its
          own even if AzureSentry is completely down.

          'TrackedOnly' (everything else, chiefly Fulfilment 'Group'): Entra group
          membership has no native expiry. This platform -- specifically the reaper
          agent, src/Agents/ReaperAgent.ps1 -- is solely responsible for acting on the
          deadline.
    #>
    param([string]$Fulfilment)
    if ($Fulfilment -eq 'PimFallback') { return 'AzureEnforced' }
    return 'TrackedOnly'
}

function Get-AssignmentRecords {
    <#
    .SYNOPSIS
      Builds the Expiry Tracking view's rows from the durable processed-tickets store
      (ProcessedStore.ps1), not from the in-memory $script:ActivityLog this used to read.
    .DESCRIPTION
      ActivityLog is capped at 200 entries, reset to empty on every API restart, and is
      never written to by the poller -- a separate process. A view backed by it would
      report "0 active, 0 expired" after a routine restart, and would never show a
      single grant the unattended poller made, on precisely the readout where a false
      all-clear matters most: whether a still-standing Group grant (no native Azure
      expiry -- see Get-GrantExpiryEnforcement above) has passed its tracked deadline
      with nobody having revoked it. The processed-tickets store is the one place both
      the dashboard's human grant path and the poller write the same record shape to,
      so it is the only source that can show a true, cross-process, restart-durable
      picture.

      A revoked record is excluded -- it is no longer standing access. A record with no
      expiresAt (a pre-fix legacy write, or one that failed) is excluded too, the same
      way Get-ExpiredUnrevokedCount (ReaperAgent.ps1) treats that absence: inventing an
      expiry here would misrepresent what the platform actually knows.
    #>
    [CmdletBinding()]
    param([datetime]$Now = (Get-Date))

    $store = Get-ProcessedTickets
    $items = [System.Collections.ArrayList]@()

    foreach ($id in $store.Keys) {
        $rec = $store[$id]
        if ([bool]$rec.revoked) { continue }

        $expiresAtRaw = [string]$rec.expiresAt
        if ([string]::IsNullOrWhiteSpace($expiresAtRaw)) { continue }

        $expiresAt = [datetime]::MinValue
        if (-not [datetime]::TryParse(
                $expiresAtRaw, [System.Globalization.CultureInfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal,
                [ref]$expiresAt)) {
            continue
        }

        $remaining = ($expiresAt - $Now).TotalHours
        $isExpired = $expiresAt -le $Now
        $urgency = if ($isExpired) { 'expired' }
                   elseif ($remaining -le 24) { 'critical' }
                   elseif ($remaining -le 72) { 'warning' }
                   else { 'ok' }

        $assignmentId = if ($rec.assignmentId) { [string]$rec.assignmentId }
                        elseif ($rec.groupId) { "group:$($rec.groupId)" }
                        else { '' }

        $durationDays = $null
        $grantedAtRaw = [string]$rec.processedAt
        $grantedAt = [datetime]::MinValue
        if ($grantedAtRaw -and [datetime]::TryParse(
                $grantedAtRaw, [System.Globalization.CultureInfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal,
                [ref]$grantedAt)) {
            $durationDays = [math]::Round(($expiresAt - $grantedAt).TotalDays, 1)
        }

        $fulfilment = [string]$rec.fulfilment
        if ([string]::IsNullOrWhiteSpace($fulfilment)) {
            # Records written before the `fulfilment` field existed. A real ARM
            # assignmentId (roleAssignmentScheduleRequests / roleEligibilityScheduleRequests)
            # means Azure enforces this expiry regardless of what this JSON key says --
            # reporting it TrackedOnly here would tell an operator the reaper is solely
            # responsible for a grant ARM will already time out on its own. A groupId with
            # no assignmentId means the reaper genuinely is solely responsible. Neither
            # present fails safe to TrackedOnly, matching Get-GrantExpiryEnforcement's own
            # default for an unrecognised fulfilment.
            if ($rec.assignmentId) { $fulfilment = 'PimFallback' }
            elseif ($rec.groupId) { $fulfilment = 'Group' }
        }

        [void]$items.Add([ordered]@{
            assignmentId      = $assignmentId
            ticketId          = [string]$rec.ticketId
            requester         = [string]$rec.requesterUpn
            environment       = [string]$rec.environment
            role              = [string]$rec.role
            action            = [string]$rec.action
            grantedAt         = $grantedAtRaw
            expiresAt         = $expiresAtRaw
            remainingHours    = [math]::Round($remaining, 1)
            durationDays      = $durationDays
            status            = if ($isExpired) { 'ExpiredNotRevoked' } else { 'Active' }
            urgency           = $urgency
            isBreakGlass      = ([string]$rec.action -eq 'BreakGlass')
            fulfilment        = $fulfilment
            expiryEnforcement = Get-GrantExpiryEnforcement -Fulfilment $fulfilment
        })
    }

    return @($items | Sort-Object { if ($_.urgency -eq 'expired') { 0 } elseif ($_.urgency -eq 'critical') { 1 } else { 2 } }, { $_.remainingHours })
}

function Get-DemoGroupRbacSeed {
    <#
    .SYNOPSIS
        Builds mock-mode Entra groups + subscription IAM role assignments for every
        subscription in config.subscriptionLabels, so the Request Simulator and Mock-mode
        ManageEngine processing can exercise the group-fulfilment happy path (not just the
        PIM-fallback path) for Reader/Contributor/Writer roles (final-review I3).
    .DESCRIPTION
        Depends on Get-RbacGroupRoleSuffix / Get-RbacGroupSearchPrefix from GroupRbac.ps1
        being dot-sourced into the caller's scope already (Start-DashboardApi.ps1 does this).
    #>
    param([object]$SubscriptionLabels)

    $labels = @{}
    if ($SubscriptionLabels -is [hashtable]) {
        foreach ($k in $SubscriptionLabels.Keys) { $labels[[string]$k] = [string]$SubscriptionLabels[$k] }
    }
    elseif ($SubscriptionLabels) {
        $SubscriptionLabels.PSObject.Properties | ForEach-Object { $labels[[string]$_.Name] = [string]$_.Value }
    }

    $roleMap = @{
        Reader      = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'
        Contributor = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
    }

    $groups = New-Object System.Collections.Generic.List[object]
    $roleAssignments = New-Object System.Collections.Generic.List[object]
    $subscriptionNames = @{}

    foreach ($subId in $labels.Keys) {
        $label = $labels[$subId]
        if ([string]::IsNullOrWhiteSpace($label)) { continue }
        $subscriptionNames[$subId] = $label

        foreach ($roleName in $roleMap.Keys) {
            $suffix = Get-RbacGroupRoleSuffix -RoleName $roleName
            $prefix = Get-RbacGroupSearchPrefix -SubscriptionName $label -IncludeEnvironment:$false
            $groupId = "demo-grp-$subId-$roleName".ToLowerInvariant()
            $displayName = "$prefix-demo-$suffix"
            $groups.Add([pscustomobject]@{ id = $groupId; displayName = $displayName })
            $roleAssignments.Add([pscustomobject]@{
                    principalId      = $groupId
                    roleDefinitionId = $roleMap[$roleName]
                    scope            = "/subscriptions/$subId"
                })
        }
    }

    return [pscustomobject]@{
        Groups            = $groups.ToArray()
        RoleAssignments   = $roleAssignments.ToArray()
        SubscriptionNames = $subscriptionNames
    }
}

function Get-TicketTypeLabel {
    <#
    .SYNOPSIS
        ManageEngine request template name used as the ticket-type placeholder.
    #>
    param([object]$Ticket)
    if ($null -eq $Ticket) { return 'Unspecified' }
    $template = if ($Ticket -is [hashtable]) { $Ticket['template'] } else { $Ticket.template }

    $name = $null
    if ($template -is [string]) {
        $name = $template
    } elseif ($template -is [hashtable]) {
        $name = $template['name']
    } elseif ($template) {
        $name = $template.name
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$name)) {
        return ([string]$name).Trim()
    }
    return 'Unspecified'
}
