# Demo seed data and monitoring query helpers for the dashboard prototype.

function Get-SlaTierHours {
    param([string]$Priority)
    switch ($Priority) {
        'P1' { return @{ SlaHours = 4; EscalateAtHours = 2 } }
        'P2' { return @{ SlaHours = 8; EscalateAtHours = 4 } }
        'P3' { return @{ SlaHours = 24; EscalateAtHours = 20 } }
        'P4' { return @{ SlaHours = 48; EscalateAtHours = 36 } }
        default { return @{ SlaHours = 24; EscalateAtHours = 20 } }
    }
}

function New-DemoActivityEntry {
    param(
        [hashtable]$Props
    )

    $defaults = @{
        id               = [guid]::NewGuid().ToString()
        timestamp        = (Get-Date).ToUniversalTime().ToString('o')
        mode             = 'seed'
        steps            = @()
        slaHours         = $null
        escalateAtHours  = $null
        approvalStatus   = 'N/A'
        approvalRequestedAt = $null
        approvalCompletedAt = $null
        assignmentId     = $null
        expiresAt        = $null
        durationDays     = $null
        assignmentStatus = $null
        isBreakGlass     = $false
        reviewStatus     = $null
        reviewDeadline   = $null
        securityAlertSent = $false
        success          = $null
        runbook          = $null
        reason           = ''
    }

    foreach ($k in $Props.Keys) { $defaults[$k] = $Props[$k] }
    return [PSCustomObject]$defaults
}

function Initialize-DemoSeedData {
    param(
        [System.Collections.ArrayList]$ActivityLog,
        [hashtable]$Stats,
        [string[]]$Allowlist
    )

    if ($ActivityLog.Count -gt 0) { return }

    $sandboxSub = $Allowlist[0]
    $prodSub = $Allowlist[1]
    $now = Get-Date

    $seedEntries = @(
        # Sandbox auto-grants (active)
        @{
            ticketId = 'ME-10001'; requester = 'dev.user@contoso.com'; environment = 'Sandbox'
            role = 'Reader'; priority = 'P3'; action = 'Grant'; path = 'Sandbox-FullAuto'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Sandbox-PIM'; mode = 'seed'
            timestamp = $now.AddHours(-2).ToUniversalTime().ToString('o')
            assignmentId = 'mock-active-1001'; durationDays = 7
            expiresAt = $now.AddDays(7).AddHours(-2).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'; success = $true
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Reader permitted for Sandbox' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Sandbox -> full-auto path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P3 - standard SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        @{
            ticketId = 'ME-10002'; requester = 'qa.user@contoso.com'; environment = 'Sandbox'
            role = 'Contributor'; priority = 'P4'; action = 'Grant'; path = 'Sandbox-FullAuto'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Sandbox-PIM'; mode = 'seed'
            timestamp = $now.AddHours(-5).ToUniversalTime().ToString('o')
            assignmentId = 'mock-active-1002'; durationDays = 3
            expiresAt = $now.AddDays(3).AddHours(-5).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'; success = $true
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Contributor permitted for Sandbox' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Sandbox -> full-auto path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P4 - standard SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # Production eligible - SLA met
        @{
            ticketId = 'ME-10010'; requester = 'eng.user@contoso.com'; environment = 'Production'
            role = 'Contributor'; priority = 'P3'; action = 'Eligible'; path = 'Production-Standard'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Prod-PIM'
            timestamp = $now.AddHours(-30).ToUniversalTime().ToString('o')
            slaHours = 24; escalateAtHours = 20
            approvalStatus = 'Approved'; approvalRequestedAt = $now.AddHours(-30).ToUniversalTime().ToString('o')
            approvalCompletedAt = $now.AddHours(-18).ToUniversalTime().ToString('o')
            assignmentId = 'mock-eligible-1010'; durationDays = 14
            expiresAt = $now.AddDays(14).AddHours(-30).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Contributor permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P3 - standard SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # P2 expedited - SLA met
        @{
            ticketId = 'ME-10011'; requester = 'release.user@contoso.com'; environment = 'Production'
            role = 'Reader'; priority = 'P2'; action = 'Eligible'; path = 'Production-Expedited'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Prod-PIM'
            timestamp = $now.AddHours(-10).ToUniversalTime().ToString('o')
            slaHours = 8; escalateAtHours = 4
            approvalStatus = 'Approved'; approvalRequestedAt = $now.AddHours(-10).ToUniversalTime().ToString('o')
            approvalCompletedAt = $now.AddHours(-6).ToUniversalTime().ToString('o')
            assignmentId = 'mock-eligible-1011'; durationDays = 5
            expiresAt = $now.AddDays(5).AddHours(-10).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Reader permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P2 - expedited SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # P4 SLA breach - pending too long
        @{
            ticketId = 'ME-10012'; requester = 'contractor@contoso.com'; environment = 'Production'
            role = 'Reader'; priority = 'P4'; action = 'Eligible'; path = 'Production-Standard'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Prod-PIM'
            timestamp = $now.AddHours(-52).ToUniversalTime().ToString('o')
            slaHours = 48; escalateAtHours = 36
            approvalStatus = 'Breached'; approvalRequestedAt = $now.AddHours(-52).ToUniversalTime().ToString('o')
            approvalCompletedAt = $null
            assignmentStatus = 'PendingApproval'
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Reader permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P4 - standard SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # P1 pending - within SLA
        @{
            ticketId = 'ME-10013'; requester = 'oncall.user@contoso.com'; environment = 'Production'
            role = 'Contributor'; priority = 'P1'; action = 'Eligible'; path = 'Production-Expedited'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Prod-PIM'
            timestamp = $now.AddHours(-2).ToUniversalTime().ToString('o')
            slaHours = 4; escalateAtHours = 2
            approvalStatus = 'Pending'; approvalRequestedAt = $now.AddHours(-2).ToUniversalTime().ToString('o')
            approvalCompletedAt = $null
            assignmentStatus = 'PendingApproval'
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Contributor permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P1 - expedited SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # P1 SLA breach
        @{
            ticketId = 'ME-10014'; requester = 'ops.user@contoso.com'; environment = 'Production'
            role = 'Reader'; priority = 'P1'; action = 'Eligible'; path = 'Production-Expedited'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Prod-PIM'
            timestamp = $now.AddHours(-6).ToUniversalTime().ToString('o')
            slaHours = 4; escalateAtHours = 2
            approvalStatus = 'Breached'; approvalRequestedAt = $now.AddHours(-6).ToUniversalTime().ToString('o')
            approvalCompletedAt = $null
            assignmentStatus = 'PendingApproval'
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Reader permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P1 - expedited SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # Break-glass - review pending
        @{
            ticketId = 'ME-20001'; requester = 'oncall.user@contoso.com'; environment = 'Production'
            role = 'Contributor'; priority = 'P1'; action = 'BreakGlass'; path = 'Emergency-BreakGlass'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Emergency-PIM'; mode = 'seed'
            timestamp = $now.AddHours(-1).ToUniversalTime().ToString('o')
            isBreakGlass = $true; securityAlertSent = $true
            reviewStatus = 'Pending'; reviewDeadline = $now.AddHours(3).ToUniversalTime().ToString('o')
            assignmentId = 'mock-bg-2001'; durationDays = 1
            expiresAt = $now.AddHours(23).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'; success = $true
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Contributor permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P1 - expedited SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # Break-glass - review overdue
        @{
            ticketId = 'ME-20002'; requester = 'incident.lead@contoso.com'; environment = 'Production'
            role = 'Contributor'; priority = 'P1'; action = 'BreakGlass'; path = 'Emergency-BreakGlass'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Emergency-PIM'; mode = 'seed'
            timestamp = $now.AddHours(-5).ToUniversalTime().ToString('o')
            isBreakGlass = $true; securityAlertSent = $true
            reviewStatus = 'Overdue'; reviewDeadline = $now.AddHours(-1).ToUniversalTime().ToString('o')
            assignmentId = 'mock-bg-2002'; durationDays = 1
            expiresAt = $now.AddHours(19).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'; success = $true
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Contributor permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P1 - expedited SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # Break-glass - review complete
        @{
            ticketId = 'ME-20003'; requester = 'sre.user@contoso.com'; environment = 'Production'
            role = 'Contributor'; priority = 'P1'; action = 'BreakGlass'; path = 'Emergency-BreakGlass'
            reason = 'Approved by decision tree'; runbook = 'Runbook-Emergency-PIM'; mode = 'seed'
            timestamp = $now.AddHours(-8).ToUniversalTime().ToString('o')
            isBreakGlass = $true; securityAlertSent = $true
            reviewStatus = 'Complete'; reviewDeadline = $now.AddHours(-4).ToUniversalTime().ToString('o')
            assignmentId = 'mock-bg-2003'; durationDays = 1
            expiresAt = $now.AddHours(16).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'; success = $true
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Contributor permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P1 - expedited SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # Expiring soon
        @{
            ticketId = 'ME-10020'; requester = 'temp.user@contoso.com'; environment = 'Production'
            role = 'Reader'; priority = 'P3'; action = 'Grant'; path = 'Sandbox-FullAuto'
            reason = 'Approved by decision tree'; mode = 'seed'
            timestamp = $now.AddDays(-6).ToUniversalTime().ToString('o')
            assignmentId = 'mock-active-1020'; durationDays = 7
            expiresAt = $now.AddHours(6).ToUniversalTime().ToString('o')
            assignmentStatus = 'Active'; success = $true
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Reader permitted for Production' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Production -> approval path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P3 - standard SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # Expired but not revoked
        @{
            ticketId = 'ME-10021'; requester = 'legacy.user@contoso.com'; environment = 'Sandbox'
            role = 'Contributor'; priority = 'P4'; action = 'Grant'; path = 'Sandbox-FullAuto'
            reason = 'Approved by decision tree'; mode = 'seed'
            timestamp = $now.AddDays(-10).ToUniversalTime().ToString('o')
            assignmentId = 'mock-active-1021'; durationDays = 7
            expiresAt = $now.AddDays(-3).ToUniversalTime().ToString('o')
            assignmentStatus = 'ExpiredNotRevoked'; success = $true
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'pass'; detail = 'Role Contributor permitted for Sandbox' }
                @{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = 'Sandbox -> full-auto path' }
                @{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = 'Priority P4 - standard SLA' }
                @{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = 'Standard sensitivity' }
                @{ step = 7; name = 'Duplicate Check'; status = 'pass'; detail = 'No conflicting assignment' }
            )
        },
        # Reject example
        @{
            ticketId = 'ME-10030'; requester = 'bad.actor@contoso.com'; environment = 'Sandbox'
            role = 'Owner'; priority = 'P3'; action = 'Reject'; path = 'Policy-Block'
            reason = 'Owner role blocked on Sandbox by Azure Policy'
            timestamp = $now.AddHours(-1).ToUniversalTime().ToString('o')
            approvalStatus = 'N/A'
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'fail'; detail = 'Owner role blocked on Sandbox by Azure Policy' }
            )
        },
        # Hold example
        @{
            ticketId = 'ME-10040'; requester = 'arch.user@contoso.com'; environment = 'Production'
            role = 'Custom'; priority = 'P4'; action = 'Hold'; path = 'Governance-Review'
            reason = 'Custom roles assessed case-by-case'
            timestamp = $now.AddHours(-3).ToUniversalTime().ToString('o')
            approvalStatus = 'N/A'
            steps = @(
                @{ step = 1; name = 'Schema Validation'; status = 'pass'; detail = 'All required fields present' }
                @{ step = 2; name = 'Subscription Allowlist'; status = 'pass'; detail = 'Subscription on approved allowlist' }
                @{ step = 3; name = 'Role Eligibility'; status = 'fail'; detail = 'Custom roles assessed case-by-case' }
            )
        }
    )

    foreach ($e in $seedEntries) {
        $entry = New-DemoActivityEntry -Props $e
        [void]$ActivityLog.Add($entry)
        $Stats.Total++
        $actionKey = $entry.action
        if ($Stats.ContainsKey($actionKey)) { $Stats[$actionKey]++ }
    }

    # Sort newest first
    $sorted = $ActivityLog | Sort-Object { [datetime]$_.timestamp } -Descending
    $ActivityLog.Clear()
    foreach ($item in $sorted) { [void]$ActivityLog.Add($item) }
}

function Get-SlaMetrics {
    param([System.Collections.ArrayList]$ActivityLog)

    $tiers = @{
        P1 = @{ slaHours = 4; total = 0; compliant = 0; breached = 0; pending = 0; items = @() }
        P2 = @{ slaHours = 8; total = 0; compliant = 0; breached = 0; pending = 0; items = @() }
        P3 = @{ slaHours = 24; total = 0; compliant = 0; breached = 0; pending = 0; items = @() }
        P4 = @{ slaHours = 48; total = 0; compliant = 0; breached = 0; pending = 0; items = @() }
    }

    $breaches = [System.Collections.ArrayList]@()
    $now = Get-Date

    foreach ($item in $ActivityLog) {
        if ($item.action -ne 'Eligible') { continue }
        $pri = $item.priority
        if (-not $tiers.ContainsKey($pri)) { continue }

        $tiers[$pri].total++

        $status = $item.approvalStatus
        if ($status -eq 'Approved') {
            $tiers[$pri].compliant++
        }
        elseif ($status -eq 'Breached') {
            $tiers[$pri].breached++
            [void]$breaches.Add(@{
                ticketId = $item.ticketId; requester = $item.requester
                priority = $pri; slaHours = $item.slaHours
                requestedAt = $item.approvalRequestedAt
                status = 'Breached'; environment = $item.environment; role = $item.role
            })
        }
        elseif ($status -eq 'Pending') {
            $tiers[$pri].pending++
            $requested = [datetime]$item.approvalRequestedAt
            $elapsed = ($now - $requested).TotalHours
            if ($elapsed -gt $item.slaHours) {
                [void]$breaches.Add(@{
                    ticketId = $item.ticketId; requester = $item.requester
                    priority = $pri; slaHours = $item.slaHours
                    requestedAt = $item.approvalRequestedAt
                    status = 'PendingOverdue'; environment = $item.environment; role = $item.role
                })
            }
        }
    }

    $summary = @()
    foreach ($pri in @('P1','P2','P3','P4')) {
        $t = $tiers[$pri]
        $resolved = $t.compliant + $t.breached
        $rate = if ($resolved -gt 0) { [math]::Round(100.0 * $t.compliant / $resolved, 1) } else { 100.0 }
        $summary += @{
            priority = $pri; slaHours = $t.slaHours; total = $t.total
            compliant = $t.compliant; breached = $t.breached; pending = $t.pending
            complianceRate = $rate
        }
    }

    return @{
        tiers = $summary
        breaches = @($breaches)
        overallCompliance = if ($summary.Count -gt 0) {
            $resolved = ($summary | ForEach-Object { $_.compliant + $_.breached } | Measure-Object -Sum).Sum
            $compliant = ($summary | ForEach-Object { $_.compliant } | Measure-Object -Sum).Sum
            if ($resolved -gt 0) { [math]::Round(100.0 * $compliant / $resolved, 1) } else { 100.0 }
        } else { 100.0 }
    }
}

# Get-AssignmentRecords moved to DashboardHelpers.ps1 -- it now reads the durable
# processed-tickets store (shared with the poller), not this file's in-memory demo
# ActivityLog, so it belongs with the other grant/expiry semantics there.

function Get-BreakGlassRecords {
    param([System.Collections.ArrayList]$ActivityLog)

    $now = Get-Date
    $items = [System.Collections.ArrayList]@()

    foreach ($item in $ActivityLog) {
        if (-not $item.isBreakGlass) { continue }

        $deadline = if ($item.reviewDeadline) { [datetime]$item.reviewDeadline } else { $null }
        $reviewRemaining = if ($deadline) { ($deadline - $now).TotalHours } else { $null }

        [void]$items.Add(@{
            id = $item.id
            ticketId = $item.ticketId
            requester = $item.requester
            role = $item.role
            environment = $item.environment
            grantedAt = $item.timestamp
            assignmentId = $item.assignmentId
            expiresAt = $item.expiresAt
            reviewStatus = $item.reviewStatus
            reviewDeadline = $item.reviewDeadline
            reviewRemainingHours = if ($null -ne $reviewRemaining) { [math]::Round($reviewRemaining, 1) } else { $null }
            securityAlertSent = [bool]$item.securityAlertSent
            path = $item.path
            reason = $item.reason
        })
    }

    return @($items | Sort-Object { [datetime]$_.grantedAt } -Descending)
}

function Filter-ActivityLog {
    param(
        [System.Collections.ArrayList]$ActivityLog,
        [string]$Requester,
        [string]$Role,
        [string]$Environment,
        [string]$Action,
        [int]$Hours = 0
    )

    $items = @($ActivityLog)
    $cutoff = if ($Hours -gt 0) { (Get-Date).AddHours(-$Hours) } else { $null }

    foreach ($item in $items) {
        $match = $true
        if ($Requester -and $item.requester -notlike "*$Requester*") { $match = $false }
        if ($Role -and $item.role -ne $Role) { $match = $false }
        if ($Environment -and $item.environment -ne $Environment) { $match = $false }
        if ($Action -and $item.action -ne $Action) { $match = $false }
        if ($cutoff -and ([datetime]$item.timestamp) -lt $cutoff) { $match = $false }
        if ($match) { $item }
    }
}
