﻿<#
.SYNOPSIS
    Local REST API for the AzureSentry dashboard prototype.
    Uses real RbacDecision module + MockPimClient for end-to-end simulation.
#>
[CmdletBinding()]
param(
    [int]$Port = 0,
    # Explicit override from Start-Local.ps1 (-Mode Real â†’ Graph). Empty = use env / config.json.
    # Named PimClientMode (not PimClient) so it does not collide with local $pimClient objects
    # â€” PowerShell variables are case-insensitive.
    [ValidateSet('', 'Mock', 'Graph')][string]$PimClientMode = ''
)

$ErrorActionPreference = 'Stop'

$apiRoot = $PSScriptRoot
$repoRoot = Split-Path (Split-Path $apiRoot -Parent) -Parent
$configPath = Join-Path $apiRoot 'config.json'
$config = Get-Content -Raw -Path $configPath | ConvertFrom-Json

if ($Port -gt 0) { $config.port = $Port }

# Load .env file if present (key=value lines); strip optional surrounding quotes
$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            $val = $Matches[2].Trim()
            if (($val.StartsWith('"') -and $val.EndsWith('"')) -or ($val.StartsWith("'") -and $val.EndsWith("'"))) {
                $val = $val.Substring(1, $val.Length - 2)
            }
            [System.Environment]::SetEnvironmentVariable($Matches[1], $val, 'Process')
        }
    }
}

# Launcher override wins over config.json (config stays Mock so Real is always opt-in)
if ($PimClientMode) {
    $env:AZURESENTRY_PIM_CLIENT = $PimClientMode
}
$script:EffectivePimClient = if ($env:AZURESENTRY_PIM_CLIENT -eq 'Graph' -or $config.pimClient -eq 'Graph') { 'Graph' } else { 'Mock' }

# Load dashboard/api/llm.env (Core42 / OpenAI-compatible keys) after repo .env
$llmEnvFile = Join-Path $apiRoot 'llm.env'
if (Test-Path $llmEnvFile) {
    Get-Content $llmEnvFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            $val = $Matches[2].Trim()
            if (($val.StartsWith('"') -and $val.EndsWith('"')) -or ($val.StartsWith("'") -and $val.EndsWith("'"))) {
                $val = $val.Substring(1, $val.Length - 2)
            }
            [System.Environment]::SetEnvironmentVariable($Matches[1], $val, 'Process')
        }
    }
}

# Override ManageEngine config from env vars
if ($env:MANAGE_ENGINE_URL)      { $config.manageEngine.baseUrl = $env:MANAGE_ENGINE_URL }
if ($env:MANAGE_ENGINE_BASE_URL) { $config.manageEngine.baseUrl = $env:MANAGE_ENGINE_BASE_URL }
if ($env:MANAGE_ENGINE_API_KEY)  { $config.manageEngine.apiKey  = $env:MANAGE_ENGINE_API_KEY }
if ($env:MANAGE_ENGINE_IDM_QUEUE) {
    if (-not ($config.manageEngine.PSObject.Properties.Name -contains 'idmQueueGroup')) {
        $config.manageEngine | Add-Member -NotePropertyName idmQueueGroup -NotePropertyValue $env:MANAGE_ENGINE_IDM_QUEUE -Force
    } else {
        $config.manageEngine.idmQueueGroup = $env:MANAGE_ENGINE_IDM_QUEUE
    }
}

# LLM overrides â€” Core42 (default), Azure OpenAI, or public OpenAI
if (-not ($config.PSObject.Properties.Name -contains 'llm')) {
    $config | Add-Member -NotePropertyName llm -NotePropertyValue ([pscustomobject]@{
            enabled  = $true
            provider = 'core42'
            baseUrl  = 'https://api.core42.ai/v1'
            endpoint = ''
            apiKey   = ''
            deployment = 'gpt-5.1'
            apiVersion = '2024-08-01-preview'
            model    = 'gpt-5.1'
        }) -Force
}

# Prefer Core42 / generic OpenAI-compatible settings
if ($env:LLM_PROVIDER) { $config.llm | Add-Member -NotePropertyName provider -NotePropertyValue $env:LLM_PROVIDER -Force }
if ($env:LLM_BASE_URL)  { $config.llm | Add-Member -NotePropertyName baseUrl -NotePropertyValue $env:LLM_BASE_URL -Force }
if ($env:LLM_API_KEY -and $env:LLM_API_KEY -notmatch 'PASTE_YOUR_') {
    $config.llm.apiKey = $env:LLM_API_KEY
}
if ($env:LLM_MODEL) { $config.llm | Add-Member -NotePropertyName model -NotePropertyValue $env:LLM_MODEL -Force }
if ($env:CORE42_API_KEY -and $env:CORE42_API_KEY -notmatch 'PASTE_YOUR_') {
    $config.llm.apiKey = $env:CORE42_API_KEY
    if (-not $config.llm.provider) { $config.llm | Add-Member -NotePropertyName provider -NotePropertyValue 'core42' -Force }
}

if ($env:AZURE_OPENAI_ENDPOINT)   { $config.llm.endpoint   = $env:AZURE_OPENAI_ENDPOINT }
if ($env:AZURE_OPENAI_API_KEY)    { $config.llm.apiKey     = $env:AZURE_OPENAI_API_KEY }
if ($env:AZURE_OPENAI_KEY)        { $config.llm.apiKey     = $env:AZURE_OPENAI_KEY }
if ($env:AZURE_OPENAI_DEPLOYMENT) { $config.llm.deployment = $env:AZURE_OPENAI_DEPLOYMENT }
if ($env:AZURE_OPENAI_API_VERSION){ $config.llm.apiVersion = $env:AZURE_OPENAI_API_VERSION }
if ($env:OPENAI_API_KEY -and [string]::IsNullOrWhiteSpace([string]$config.llm.apiKey)) {
    $config.llm.apiKey = $env:OPENAI_API_KEY
}
if ($env:OPENAI_MODEL) { $config.llm | Add-Member -NotePropertyName model -NotePropertyValue $env:OPENAI_MODEL -Force }
if ($env:AZURESENTRY_LLM_ENABLED) {
    $config.llm.enabled = ($env:AZURESENTRY_LLM_ENABLED -match '^(1|true|yes)$')
}

# Default provider to core42 when base URL points at core42
if (-not ($config.llm.PSObject.Properties.Name -contains 'provider') -or [string]::IsNullOrWhiteSpace([string]$config.llm.provider)) {
    $config.llm | Add-Member -NotePropertyName provider -NotePropertyValue 'core42' -Force
}
if (-not ($config.llm.PSObject.Properties.Name -contains 'baseUrl') -or [string]::IsNullOrWhiteSpace([string]$config.llm.baseUrl)) {
    $config.llm | Add-Member -NotePropertyName baseUrl -NotePropertyValue 'https://api.core42.ai/v1' -Force
}

$script:LlmSummaryCache = @{}
$script:LastLlmError = $null

Import-Module (Join-Path $repoRoot 'src/RbacDecision/RbacDecision.psd1') -Force
Get-ChildItem (Join-Path $repoRoot 'src/RbacDecision/Private/*.ps1') | ForEach-Object { . $_.FullName }
Import-Module (Join-Path $repoRoot 'src/PimClient/MockPimClient.psm1') -Force
# Real Graph/SPN client imported with a 'Real' prefix so its function names
# (New-RealGraphPimClient, New-RealActiveAssignment, Resolve-RealUpnToObjectId, ...)
# do not collide with the identically-named Mock functions.
Import-Module (Join-Path $repoRoot 'src/PimClient/GraphPimClient.psm1') -Force -Prefix Real
. (Join-Path $repoRoot 'src/PimClient/GroupRbac.ps1')
. (Join-Path $apiRoot 'DemoData.ps1')
. (Join-Path $apiRoot 'AzurePim.ps1')
. (Join-Path $apiRoot 'DashboardHelpers.ps1')
# Send-ManageEngineProcessNote / Set-ManageEngineTicketResolved: depends on
# Get-ManageEngineNoteKind above, so this is sourced after DashboardHelpers.ps1.
. (Join-Path $apiRoot 'ManageEngineNotes.ps1')
. (Join-Path $apiRoot 'TicketTemplates.ps1')
. (Join-Path $apiRoot 'SubscriptionAllowlist.ps1')
# Resolve-PollerStatusView: GET /api/poller/status (final-review C3) reports the poller's
# enabled/mode from the poller's own last reported cycle, not this process's env vars.
. (Join-Path $repoRoot 'src/Agents/PollerGate.ps1')
# Resolve-ReaperStatusView / Get-ExpiredUnrevokedCount: GET /api/reaper/status reports the
# reaper's own last reported cycle the same way -- it is a separate scheduled process, not
# something this route triggers. Depends on Test-GrantRevocable (DashboardHelpers.ps1,
# already sourced above).
. (Join-Path $repoRoot 'src/Agents/ReaperAgent.ps1')

# --- FR6 audit trail + FR2/FR3/FR4 agents ---------------------------------------
# Load order matters: AuditLog before AgentRuntime (Invoke-Agent emits audit events),
# LlmClient before the agents that use an LLM step.
. (Join-Path $apiRoot 'LogAnalyticsClient.ps1')
. (Join-Path $apiRoot 'AuditLog.ps1')
. (Join-Path $repoRoot 'src/Agents/AgentRuntime.ps1')
. (Join-Path $repoRoot 'src/Agents/LlmClient.ps1')
. (Join-Path $repoRoot 'src/Agents/SubscriptionResolver.ps1')
# Test-IsStructuredEnvironmentTemplate / Get-CanonicalEnvironmentFromDropdown /
# Get-RuleBasedEnvironment / Test-IsGitHubEnterpriseTemplate -- the deterministic
# helpers Get-TicketEnvironmentResolved (below) uses for the Overview and Execution
# Hub environment display. Formerly src/Agents/EnvironmentInferenceAgent.ps1; see
# this file's header for why it moved and what was removed alongside it.
. (Join-Path $apiRoot 'EnvironmentResolution.ps1')
. (Join-Path $repoRoot 'src/Agents/TicketCategorizationAgent.ps1')

$auditPath = Join-Path $apiRoot 'audit-log.jsonl'
if ($config.PSObject.Properties.Name -contains 'audit' -and $config.audit.path) {
    $auditPath = if ([System.IO.Path]::IsPathRooted([string]$config.audit.path)) {
        [string]$config.audit.path
    } else {
        Join-Path $repoRoot ([string]$config.audit.path)
    }
}
Initialize-AuditLog -Path $auditPath | Out-Null

$script:LastCategorization = $null
# Idempotent TemplateIntake audit: ticket id → $true for this process lifetime.
$script:TemplateIntakeRecorded = @{}

function Invoke-RealGroupOrPimGrant {
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleName,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [Parameter(Mandatory)][string]$ResourceScope,
        [Parameter(Mandatory)][int]$DurationDays,
        [Parameter(Mandatory)][string]$Justification,
        [ValidateSet('Active', 'Eligible')]
        [string]$PimFallbackAssignmentType = 'Active'
    )

    # GroupRbac is client-agnostic and calls the standard command names. The real
    # module is prefix-imported above to avoid colliding with the mock commands.
    Set-Alias Get-RoleDefinitionId Get-RealRoleDefinitionId -Scope Local
    Set-Alias Get-SubscriptionDisplayName Get-RealSubscriptionDisplayName -Scope Local
    Set-Alias Find-EntraRbacGroups Find-RealEntraRbacGroups -Scope Local
    Set-Alias Test-GroupHasSubscriptionRole Test-RealGroupHasSubscriptionRole -Scope Local
    Set-Alias Add-EntraGroupMember Add-RealEntraGroupMember -Scope Local
    Set-Alias New-ActiveAssignment New-RealActiveAssignment -Scope Local
    Set-Alias New-EligibleAssignment New-RealEligibleAssignment -Scope Local
    Set-Alias New-EntraRbacGroup New-RealEntraRbacGroup -Scope Local
    Set-Alias New-GroupSubscriptionRoleAssignment New-RealGroupSubscriptionRoleAssignment -Scope Local
    Set-Alias Get-EntraGroupMembers Get-RealEntraGroupMembers -Scope Local

    Invoke-GroupOrPimGrant -Client $Client -UserId $UserId -RoleName $RoleName `
        -SubscriptionId $SubscriptionId -SubscriptionName $SubscriptionName `
        -ResourceScope $ResourceScope -DurationDays $DurationDays -Justification $Justification `
        -PimFallbackAssignmentType $PimFallbackAssignmentType
}

function Invoke-RealGroupDuplicateCheck {
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleName,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [string]$ResourceScope
    )
    Set-Alias Find-EntraRbacGroups Find-RealEntraRbacGroups -Scope Local
    Set-Alias Get-EntraGroupMembers Get-RealEntraGroupMembers -Scope Local
    Set-Alias Test-EntraGroupMember Test-RealEntraGroupMember -Scope Local
    Set-Alias Get-SubscriptionDisplayName Get-RealSubscriptionDisplayName -Scope Local
    Test-GroupRbacDuplicateAccess -Client $Client -UserId $UserId -RoleName $RoleName `
        -SubscriptionId $SubscriptionId -SubscriptionName $SubscriptionName -ResourceScope $ResourceScope
}

$script:ActivityLog = [System.Collections.ArrayList]@()
$script:Stats = @{
    Total    = 0
    Grant    = 0
    Eligible = 0
    Reject   = 0
    Hold     = 0
    BreakGlass = 0
}

function Write-JsonResponse {
    param(
        [System.Net.HttpListenerResponse]$Response,
        [object]$Body,
        [int]$StatusCode = 200
    )
    $json = $Body | ConvertTo-Json -Depth 12 -Compress:$false
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $Response.StatusCode = $StatusCode
    $Response.ContentType = 'application/json; charset=utf-8'
    $Response.Headers.Add('Access-Control-Allow-Origin', '*')
    $Response.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
    $Response.Headers.Add('Access-Control-Allow-Headers', 'Content-Type')
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.Close()
}

function Read-RequestBody {
    param([System.Net.HttpListenerRequest]$Request)
    $reader = New-Object System.IO.StreamReader($Request.InputStream, $Request.ContentEncoding)
    $raw = $reader.ReadToEnd()
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    return $raw | ConvertFrom-Json
}

# --- Durable record of processed tickets so the dashboard reflects them across reloads ---
# Extracted to ProcessedStore.ps1: one file per ticket, so the unattended poller writing
# this same store from a separate process needs no shared-document lock. A lost write
# here is a duplicate grant.
. (Join-Path $PSScriptRoot 'ProcessedStore.ps1')
Initialize-ProcessedStore -Path (Join-Path $apiRoot 'processed-tickets.json')

# Test-AccessPromotionLadder: extracted to AccessPromotion.ps1 so the unattended poller
# shares the identical Sandbox -> NonProd -> Production enforcement (see that file's
# header for why it cannot dot-source this script directly).
. (Join-Path $PSScriptRoot 'AccessPromotion.ps1')

# Invoke-GrantRevocationAction: the single revoke implementation, shared with the reaper
# agent (src/Agents/ReaperAgent.ps1) so /api/manageengine/revoke and the unattended
# expiry sweep can never diverge on what "revoke" means. See that file's header.
. (Join-Path $PSScriptRoot 'GrantRevocation.ps1')

function Get-IdmQueueName {
    $name = $null
    if ($config.manageEngine.PSObject.Properties.Name -contains 'idmQueueGroup') {
        $name = [string]$config.manageEngine.idmQueueGroup
    }
    if ($env:MANAGE_ENGINE_IDM_QUEUE) { $name = $env:MANAGE_ENGINE_IDM_QUEUE }
    if ([string]::IsNullOrWhiteSpace($name)) { $name = 'IDM' }
    return $name.Trim()
}

function ConvertFrom-ManageEngineTime {
    <#
    .SYNOPSIS
      Parses ManageEngine created_time (epoch ms string or display_value) to DateTime.
    #>
    param($CreatedTime)
    if ($null -eq $CreatedTime) { return $null }

    $raw = $null
    $display = $null
    if ($CreatedTime -is [string] -or $CreatedTime -is [long] -or $CreatedTime -is [int] -or $CreatedTime -is [double]) {
        $raw = [string]$CreatedTime
    }
    else {
        if ($CreatedTime.PSObject.Properties.Name -contains 'value') { $raw = [string]$CreatedTime.value }
        if ($CreatedTime.PSObject.Properties.Name -contains 'display_value') { $display = [string]$CreatedTime.display_value }
    }

    if ($raw -and ($raw -match '^\d{10,13}$')) {
        try {
            $ms = [int64]$raw
            if ($raw.Length -eq 10) { $ms = $ms * 1000 }
            return ([datetime]'1970-01-01Z').AddMilliseconds($ms).ToLocalTime()
        }
        catch { }
    }
    if ($raw) {
        try { return [datetime]$raw } catch { }
    }
    if ($display) {
        try { return [datetime]$display } catch { }
    }
    return $null
}

function Get-IdentityQueueDisplayName {
    <#
    .SYNOPSIS
      Expands IDM / IDAM abbreviations for user-facing labels.
    #>
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return $Name }
    $n = $Name.Trim()
    if ($n -match '(?i)^IDAM\s+Team$') { return 'Identity and Access Management Team' }
    if ($n -match '(?i)^IDAM$') { return 'Identity and Access Management' }
    if ($n -match '(?i)^IDM$') { return 'Identity Management' }
    # Expand embedded abbreviations while keeping other words (e.g. "IDAM Team" variants)
    $n = [regex]::Replace($n, '(?i)\bIDAM\b', 'Identity and Access Management')
    $n = [regex]::Replace($n, '(?i)\bIDM\b', 'Identity Management')
    return $n
}

function Get-IdentityQueueLabels {
    $primary = Get-IdmQueueName
    $names = @($primary, 'IDAM Team') | Select-Object -Unique
    return @(
        foreach ($n in $names) {
            @{
                name        = $n
                displayName = (Get-IdentityQueueDisplayName -Name $n)
            }
        }
    )
}

function Test-IsIdmTicket {
    <#
    .SYNOPSIS
      Help Desk filter: Identity and Access Management tickets only.
      Matches technician group / category / subcategory against IDM, IDAM,
      or the configured idmQueueGroup. Does NOT use subject keywords
      (those pulled in unrelated tickets that merely mention Contributor/Reader).
    #>
    param([object]$Ticket, [string]$QueueName)
    $group = [string]$Ticket.group.name
    $cat = [string]$Ticket.category.name
    $sub = [string]$Ticket.subcategory.name
    $q = if ([string]::IsNullOrWhiteSpace($QueueName)) { 'IDM' } else { $QueueName.Trim() }

    # Canonical IAM labels used in ManageEngine (abbrev + expanded forms).
    $identityPattern = '(?i)(\bIDAM\b|\bIDM\b|Identity\s+and\s+Access\s+Management|Identity\s+Management)'
    foreach ($v in @($group, $cat, $sub)) {
        if ([string]::IsNullOrWhiteSpace($v)) { continue }
        if ($v -match $identityPattern) { return $true }
        # Custom configured queue name (exact-ish: whole-string or word-boundary when short).
        if ($q.Length -le 4) {
            if ($v -match ("(?i)\b{0}\b" -f [regex]::Escape($q))) { return $true }
        }
        elseif ($v.ToLowerInvariant().Contains($q.ToLowerInvariant())) {
            return $true
        }
    }
    return $false
}

function Test-DepartmentFilterMatches {
    <#
    .SYNOPSIS
      Department-filter matcher for governance endpoints (/analyze, /categorize).

    .DESCRIPTION
      A plain "$group -like '*<filter>*'" substring check breaks the moment the filter
      text and the real ManageEngine group name diverge even slightly — e.g. a filter of
      "IDM" does not match a group literally named "IDAM Team" ("IDM" is not a substring
      of "IDAM"), and a filter of "Identity and Access Management Team" would not match a
      group literally named "IDAM Team" either. This happened in production.

      When the filter looks like any identity/IDAM/IDM reference, route through the same
      Test-IsIdmTicket matcher the Overview dashboard uses (regex over IDAM/IDM/Identity
      Management/Identity and Access Management, checked against group/category/
      subcategory) — the one matcher already proven correct against real ME group naming.
      Any other department filter keeps the simple substring match.
    #>
    param([object]$Ticket, [string]$Filter)

    if ($Filter -match '(?i)\bIDAM\b|\bIDM\b|Identity\s+and\s+Access\s+Management|Identity\s+Management') {
        return (Test-IsIdmTicket -Ticket $Ticket -QueueName $Filter)
    }
    $g = if ($Ticket.group.name) { [string]$Ticket.group.name } else { '' }
    return ($g -like "*$Filter*")
}

function Get-TicketCategoryBucket {
    param([object]$Ticket)
    $text = (@(
        [string]$Ticket.subject,
        [string]$Ticket.category.name,
        [string]$Ticket.subcategory.name,
        [string]$Ticket.short_description
    ) -join ' ').ToLowerInvariant()

    if ($text -match 'break.?glass|emergency') { return 'Break-Glass' }
    if ($text -match 'access|pim|rbac|role|eligibility|permission|idm|contributor|reader|writer') {
        return 'Access-Related'
    }
    if ($text -match 'environment|env |deploy|pipeline|outage|connectivity|network|vm |storage|dns') {
        return 'Environment-Issue'
    }
    return 'Other'
}

function Get-TicketEnvironmentResolved {
    <#
    .SYNOPSIS
      FR1/FR2 — resolves a ticket's environment with the ManageEngine Environment
      dropdown taking precedence over any text inference, and reports which was used.

      This is what makes 'inferred' visible in the Overview and Execution Hub instead
      of a keyword guess masquerading as a tagged value.

    .DESCRIPTION
      Uses the deterministic building blocks in dashboard/api/EnvironmentResolution.ps1
      (Test-IsStructuredEnvironmentTemplate, Get-CanonicalEnvironmentFromDropdown,
      Get-RuleBasedEnvironment, Test-IsGitHubEnterpriseTemplate) -- a dropdown map plus
      a keyword fallback, no LLM call and no write path.

      This function runs synchronously on every dashboard refresh (Overview analytics),
      so it deliberately does not call an LLM -- that would mean a call per ticket on
      every page load. A ticket that has neither a dropdown value nor a keyword hit is
      reported here as Unknown/'None'; there is no further inference pass to run on it
      any more -- see EnvironmentResolution.ps1's header for what was removed and why.

    .OUTPUTS
      hashtable: environment, source (Dropdown|Text|None|NotApplicable), inferred (bool), raw
    #>
    param([object]$Ticket)

    $ticketType = Get-TicketTypeLabel -Ticket $Ticket

    # Templates with no Environment field at all (General Access, Infrastructure, Report
    # an Issue, ...) are out of scope for environment classification entirely — same
    # scope decision the governance agent makes. Not "Unknown" (that implies the field
    # applies but couldn't be determined); this ticket has no environment concept.
    if (-not (Test-IsStructuredEnvironmentTemplate -TicketType $ticketType)) {
        return @{ environment = 'Unknown'; source = 'NotApplicable'; inferred = $false; raw = '' }
    }

    $raw = ''
    if ($Ticket.udf_fields) {
        $fields = Get-MeConfiguredAccessFields -UdfFields $Ticket.udf_fields -Config $config
        $raw = [string]$fields.Environment
    }

    $mapped = Get-CanonicalEnvironmentFromDropdown -Value $raw
    if ($mapped) {
        return @{ environment = $mapped; source = 'Dropdown'; inferred = $false; raw = $raw }
    }

    $probeText = @([string]$Ticket.subject, $raw, [string]$Ticket.description, [string]$Ticket.short_description) -join ' '
    $rule = Get-RuleBasedEnvironment -Text $probeText
    if ($rule.Environment -eq 'Unknown') {
        if (Test-IsGitHubEnterpriseTemplate -TicketType $ticketType) {
            # Same business default as the governance agent: no non-prod keyword found
            # on a GitHub Enterprise request means it defaults to Production.
            return @{ environment = 'Production'; source = 'Text'; inferred = $true; raw = $raw }
        }
        return @{ environment = 'Unknown'; source = 'None'; inferred = $false; raw = $raw }
    }
    return @{ environment = $rule.Environment; source = 'Text'; inferred = $true; raw = $raw }
}

# Extracted so the unattended poller can share the logic that decides which subscription
# and role a ticket is asking for. Sourcing this script from the poller is impossible
# (it starts an HttpListener at top level), and a second copy would drift. The wrapper
# that applies this API's config-driven udf key overrides, Get-MeConfiguredAccessFields,
# now lives in MeAccessFields.ps1 too (as a -Config parameter, since that file has no
# $config script scope of its own) so it stays testable without dot-sourcing this script.
. (Join-Path $PSScriptRoot 'MeAccessFields.ps1')

function Get-ManageEngineWebExceptionDetail {
    param([System.Management.Automation.ErrorRecord]$ErrorRecord)
    $msg = [string]$ErrorRecord.Exception.Message
    $body = ''
    try {
        $resp = $ErrorRecord.Exception.Response
        if (-not $resp -and $ErrorRecord.Exception.InnerException) {
            $resp = $ErrorRecord.Exception.InnerException.Response
        }
        if ($resp -and $resp.GetResponseStream) {
            $stream = $resp.GetResponseStream()
            if ($stream) {
                $reader = New-Object System.IO.StreamReader($stream)
                $body = $reader.ReadToEnd()
                $reader.Close()
            }
        }
    } catch { }

    $friendly = $null
    $meCode = $null
    if ($body) {
        try {
            $j = $body | ConvertFrom-Json
            $messages = @()
            if ($j.response_status.messages) { $messages = @($j.response_status.messages) }
            elseif ($j.messages) { $messages = @($j.messages) }
            foreach ($m in $messages) {
                if ($m.status_code) { $meCode = [string]$m.status_code }
                if ($m.message) {
                    if ($friendly) { $friendly = "$friendly; $($m.message)" }
                    else { $friendly = [string]$m.message }
                }
            }
            if (-not $friendly -and $j.response_status.status) {
                $friendly = [string]$j.response_status.status
            }
        } catch { }
    }

    # SDP rate limit: HTTP 400 + status_code 4001
    if ($meCode -eq '4001' -or ($friendly -match 'maximum access limit')) {
        $friendly = 'ManageEngine rate limit exceeded (max access limit). Wait ~30â€“60s, then refresh. Tip: avoid opening Overview + Help Desk at the same time while the limit cools down.'
    }

    return @{
        Message  = $(if ($friendly) { $friendly } else { $msg })
        Body     = $body
        MeCode   = $meCode
        RateLimited = ($meCode -eq '4001' -or ($friendly -match 'rate limit|maximum access limit'))
    }
}

function Invoke-ManageEngineRest {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [ValidateSet('Get', 'Post', 'Put')][string]$Method = 'Get',
        [hashtable]$Headers,
        # Do not type as [string] â€” PowerShell coerces $null to "" and then
        # Invoke-RestMethod sends a body on GET â†’ "Cannot send a content-body with this verb-type."
        $Body = $null
    )
    try {
        if ($Method -ne 'Get' -and $null -ne $Body -and "$Body" -ne '') {
            return Invoke-RestMethod -Uri $Uri -Method $Method -Headers $Headers -Body $Body -ErrorAction Stop
        }
        return Invoke-RestMethod -Uri $Uri -Method $Method -Headers $Headers -ErrorAction Stop
    }
    catch {
        $detail = Get-ManageEngineWebExceptionDetail -ErrorRecord $_
        throw $detail.Message
    }
}

# Short-lived caches to avoid SDP "maximum access limit" (4001) under UI refresh bursts.
$script:MeListCache = @{}      # key -> @{ FetchedAt; Payload }
$script:MeDetailCache = @{}    # id -> @{ FetchedAt; Payload }
$script:MeListCacheSeconds = 45
$script:MeDetailCacheSeconds = 120
$script:MeAnalyticsCache = $null
$script:MeAnalyticsCacheSeconds = 120

function Get-ManageEngineMandatoryFieldKeys {
    <#
    .SYNOPSIS
      Fetch ManageEngine mandatory field keys for a request (asterisk fields on the template).
      Tries per-request endpoint first, then template+status query. Non-fatal on failure.
    #>
    param(
        [Parameter(Mandatory)][string]$RequestId,
        [object]$Ticket = $null
    )
    $meBase = $config.manageEngine.baseUrl
    $meKey  = $config.manageEngine.apiKey
    if (-not $meBase -or -not $meKey) { return @() }

    $headers = @{
        'authtoken'    = $meKey
        'Content-Type' = 'application/json'
    }

    $extractKeys = {
        param($resp)
        $keys = [System.Collections.Generic.List[string]]::new()
        $block = $null
        if ($resp.mandatory_fields) { $block = $resp.mandatory_fields }
        elseif ($resp.status_mandatory_fields) { $block = $resp.status_mandatory_fields }
        if (-not $block) { return @() }
        # Prefer full mandatory set (fields); fall back to to_be_filled.
        $list = @()
        if ($block.fields) { $list = @($block.fields) }
        elseif ($block.to_be_filled) { $list = @($block.to_be_filled) }
        foreach ($item in $list) {
            if ($null -eq $item) { continue }
            if ($item -is [string] -or $item -is [ValueType]) {
                $s = ([string]$item).Trim()
                if ($s) { [void]$keys.Add($s) }
            }
            elseif ($item.name) {
                [void]$keys.Add(([string]$item.name).Trim())
            }
            elseif ($item.field) {
                [void]$keys.Add(([string]$item.field).Trim())
            }
        }
        return @($keys | Select-Object -Unique)
    }

    # 1) Per-request endpoint (build 15200+: .../requests/{id}/get_mandatory_fields)
    try {
        $uri = "$($meBase.TrimEnd('/'))/api/v3/requests/$RequestId/get_mandatory_fields"
        $resp = Invoke-ManageEngineRest -Uri $uri -Method Get -Headers $headers
        $keys = & $extractKeys $resp
        if ($keys.Count -gt 0) { return $keys }
    }
    catch {
        # Older builds use status_mandatory_fields
        try {
            $uri = "$($meBase.TrimEnd('/'))/api/v3/requests/$RequestId/status_mandatory_fields"
            $resp = Invoke-ManageEngineRest -Uri $uri -Method Get -Headers $headers
            $keys = & $extractKeys $resp
            if ($keys.Count -gt 0) { return $keys }
        }
        catch { }
    }

    # 2) Template + state/status query
    $templateId = $null
    $statusId = $null
    if ($Ticket) {
        if ($Ticket.template -and $Ticket.template.id) { $templateId = [string]$Ticket.template.id }
        if ($Ticket.status -and $Ticket.status.id) { $statusId = [string]$Ticket.status.id }
    }
    if (-not $templateId -or -not $statusId) { return @() }

    foreach ($payload in @(
            (@{ template_id = $templateId; state_id = $statusId } | ConvertTo-Json -Compress),
            (@{ template_id = $templateId; status_id = $statusId } | ConvertTo-Json -Compress)
        )) {
        foreach ($path in @('get_mandatory_fields', 'status_mandatory_fields')) {
            try {
                $uri = "$($meBase.TrimEnd('/'))/api/v3/requests/$path?input_data=$([uri]::EscapeDataString($payload))"
                $resp = Invoke-ManageEngineRest -Uri $uri -Method Get -Headers $headers
                $keys = & $extractKeys $resp
                if ($keys.Count -gt 0) { return $keys }
            }
            catch { }
        }
    }

    return @()
}

function Get-ManageEngineRequestById {
    param([Parameter(Mandatory)][string]$RequestId)
    $meBase = $config.manageEngine.baseUrl
    $meKey  = $config.manageEngine.apiKey
    if (-not $meBase -or -not $meKey) {
        throw 'ManageEngine not configured. Set MANAGE_ENGINE_BASE_URL and MANAGE_ENGINE_API_KEY in .env'
    }

    $cacheKey = [string]$RequestId
    $hit = $script:MeDetailCache[$cacheKey]
    if ($hit -and ((Get-Date) - $hit.FetchedAt).TotalSeconds -lt $script:MeDetailCacheSeconds) {
        return $hit.Payload
    }

    $meUrl = "$($meBase.TrimEnd('/'))/api/v3/requests/$RequestId"
    $payload = Invoke-ManageEngineRest -Uri $meUrl -Method Get -Headers @{
        'authtoken' = $meKey
        'Content-Type' = 'application/json'
    }
    $script:MeDetailCache[$cacheKey] = @{ FetchedAt = Get-Date; Payload = $payload }
    return $payload
}

function Get-ManageEngineRequestsRaw {
    param([int]$RowCount = 100, [int]$StartIndex = 1, [switch]$BypassCache)
    $meBase = $config.manageEngine.baseUrl
    $meKey  = $config.manageEngine.apiKey
    if (-not $meBase -or -not $meKey) {
        throw 'ManageEngine not configured. Set MANAGE_ENGINE_BASE_URL and MANAGE_ENGINE_API_KEY in .env'
    }

    $cacheKey = "$StartIndex|$RowCount"
    if (-not $BypassCache) {
        $hit = $script:MeListCache[$cacheKey]
        if ($hit -and ((Get-Date) - $hit.FetchedAt).TotalSeconds -lt $script:MeListCacheSeconds) {
            return $hit.Payload
        }
    }

    # udf_fields is requested so template picks (subscription/role) are available when ME returns them;
    # list responses may still omit values â€” detail GET /requests/{id} is authoritative.
    $fields = '"id","subject","short_description","description","status","priority","requester","technician","category","subcategory","item","request_type","created_time","due_by_time","completed_time","site","group","is_overdue","udf_fields","template"'
    $meParams = @{ input_data = '{"list_info":{"row_count":' + $RowCount + ',"start_index":' + $StartIndex + ',"fields_required":[' + $fields + ']}}' }
    $meUrl = "$($meBase.TrimEnd('/'))/api/v3/requests"
    $qsParts = $meParams.GetEnumerator() | ForEach-Object { "$($_.Key)=$([System.Uri]::EscapeDataString($_.Value))" }
    if ($qsParts) { $meUrl += "?$($qsParts -join '&')" }
    $payload = Invoke-ManageEngineRest -Uri $meUrl -Method Get -Headers @{
        'authtoken' = $meKey
        'Content-Type' = 'application/json'
    }
    $script:MeListCache[$cacheKey] = @{ FetchedAt = Get-Date; Payload = $payload }
    return $payload
}

function Get-ManageEngineAllRequests {
    <#
    .SYNOPSIS
      Pages ManageEngine requests until exhausted or MaxPages reached.
      Used by Overview analytics so counts cover all tickets, not one page.
    #>
    param([int]$PageSize = 100, [int]$MaxPages = 20)
    if ($script:MeAnalyticsCache -and
        ((Get-Date) - $script:MeAnalyticsCache.FetchedAt).TotalSeconds -lt $script:MeAnalyticsCacheSeconds) {
        return $script:MeAnalyticsCache.Payload
    }

    $all = [System.Collections.ArrayList]@()
    $start = 1
    $lastStatus = $null
    $listInfo = $null
    for ($page = 1; $page -le $MaxPages; $page++) {
        # First page can use list cache; subsequent pages bypass so pagination stays correct.
        $resp = if ($page -eq 1) {
            Get-ManageEngineRequestsRaw -RowCount $PageSize -StartIndex $start
        } else {
            Start-Sleep -Milliseconds 350
            Get-ManageEngineRequestsRaw -RowCount $PageSize -StartIndex $start -BypassCache
        }
        $lastStatus = $resp.response_status
        $listInfo = $resp.list_info
        $batch = @($resp.requests)
        if ($batch.Count -eq 0) { break }
        [void]$all.AddRange($batch)
        $hasMore = $false
        if ($listInfo -and $listInfo.has_more_rows) { $hasMore = [bool]$listInfo.has_more_rows }
        if (-not $hasMore) { break }
        $start += $PageSize
    }
    $payload = @{
        requests        = @($all)
        response_status = $lastStatus
        list_info       = $listInfo
    }
    $script:MeAnalyticsCache = @{ FetchedAt = Get-Date; Payload = $payload }
    return $payload
}

function Get-HeuristicTicketSummary {
    param([string]$Subject, [string]$Body, [string]$Requester)
    $text = "$Subject`n$Body"
    $who = $Requester
    if ($text -match '(?i)user\s*[:=]\s*([^\s<>]+@[^\s<>]+)') { $who = $Matches[1] }
    elseif ($text -match '(?i)mailto:([^\s"'']+@[^\s"'']+)') { $who = $Matches[1] }

    $role = 'access (role not specified)'
    if ($text -match '(?i)user access admin|\buaa\b') { $role = 'User Access Administrator' }
    elseif ($text -match '(?i)\bowner\b') { $role = 'Owner' }
    elseif ($text -match '(?i)writer|write access') { $role = 'Writer' }
    elseif ($text -match '(?i)contrib') { $role = 'Contributor' }
    elseif ($text -match '(?i)\bread') { $role = 'Reader' }

    $envLabel = 'environment not specified'
    if ($text -match '(?i)\bproduction\b|\bprod\b') { $envLabel = 'Production' }
    elseif ($text -match '(?i)non[\s_-]?prod|staging|uat') { $envLabel = 'Non-Prod' }
    elseif ($text -match '(?i)sandbox|sbx|\bdev\b') { $envLabel = 'Sandbox' }

    $subHint = $null
    if ($text -match '(?i)(ceo-sub-application|inception-ai-sandbox|inception-internal-product|shared-applications|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') {
        $subHint = $Matches[1]
    }

    $narrative = if ($who) {
        "$who is requesting $role access"
    } else {
        "A requester is asking for $role access"
    }
    if ($envLabel -ne 'environment not specified') { $narrative += " in $envLabel" }
    if ($subHint) { $narrative += " on $subHint" }
    $narrative += '.'
    if ($Subject) { $narrative += " Ticket subject: $Subject." }

    return @{
        summary    = $narrative
        highlights = @{
            who          = $who
            access       = $role
            environment  = $envLabel
            subscription = $subHint
        }
        source     = 'heuristic'
        llmConfigured = $false
    }
}

function Test-LlmConfigured {
    $llmEnabled = $true
    if ($config.PSObject.Properties.Name -contains 'llm' -and $null -ne $config.llm.enabled) {
        $llmEnabled = [bool]$config.llm.enabled
    }
    if (-not $llmEnabled) { return $false }
    $apiKey = [string]$config.llm.apiKey
    if ($env:LLM_API_KEY -and $env:LLM_API_KEY -notmatch 'PASTE_YOUR_') { $apiKey = $env:LLM_API_KEY }
    if ($env:CORE42_API_KEY -and $env:CORE42_API_KEY -notmatch 'PASTE_YOUR_') { $apiKey = $env:CORE42_API_KEY }
    if ($env:AZURE_OPENAI_API_KEY) { $apiKey = $env:AZURE_OPENAI_API_KEY }
    if ($env:AZURE_OPENAI_KEY) { $apiKey = $env:AZURE_OPENAI_KEY }
    if ($env:OPENAI_API_KEY -and ([string]::IsNullOrWhiteSpace($apiKey) -or $apiKey -match 'PASTE_YOUR_')) {
        $apiKey = $env:OPENAI_API_KEY
    }
    if ([string]::IsNullOrWhiteSpace($apiKey) -or $apiKey -match 'PASTE_YOUR_') { return $false }
    return $true
}

function Invoke-TicketSummaryAgent {
    <#
    .SYNOPSIS
      LLM agent for Help Desk ticket summaries (who / access / environment).

      Providers:
        - core42 (default): https://api.core42.ai/v1 with api-key header (OpenAI-compatible)
        - azure-openai: Azure OpenAI deployments API
        - openai: api.openai.com Bearer token
    #>
    param([string]$Subject, [string]$Body, [string]$Requester)

    $script:LastLlmError = $null
    $provider = 'core42'
    if ($config.llm.PSObject.Properties.Name -contains 'provider' -and $config.llm.provider) {
        $provider = [string]$config.llm.provider
    }
    if ($env:LLM_PROVIDER) { $provider = $env:LLM_PROVIDER }

    $baseUrl = 'https://api.core42.ai/v1'
    if ($config.llm.PSObject.Properties.Name -contains 'baseUrl' -and $config.llm.baseUrl) {
        $baseUrl = [string]$config.llm.baseUrl
    }
    if ($env:LLM_BASE_URL) { $baseUrl = $env:LLM_BASE_URL }

    $endpoint = [string]$config.llm.endpoint
    $apiKey = [string]$config.llm.apiKey
    $deployment = if ($config.llm.deployment) { [string]$config.llm.deployment } else { 'gpt-5.1' }
    $apiVersion = if ($config.llm.apiVersion) { [string]$config.llm.apiVersion } else { '2024-08-01-preview' }
    $model = if ($config.llm.PSObject.Properties.Name -contains 'model' -and $config.llm.model) {
        [string]$config.llm.model
    } else { $deployment }

    if ($env:LLM_API_KEY -and $env:LLM_API_KEY -notmatch 'PASTE_YOUR_') { $apiKey = $env:LLM_API_KEY }
    if ($env:CORE42_API_KEY -and $env:CORE42_API_KEY -notmatch 'PASTE_YOUR_') { $apiKey = $env:CORE42_API_KEY }
    if ($env:LLM_MODEL) { $model = $env:LLM_MODEL }
    if ($env:AZURE_OPENAI_ENDPOINT) { $endpoint = $env:AZURE_OPENAI_ENDPOINT }
    if ($env:AZURE_OPENAI_API_KEY) { $apiKey = $env:AZURE_OPENAI_API_KEY }
    if ($env:AZURE_OPENAI_KEY) { $apiKey = $env:AZURE_OPENAI_KEY }
    if ($env:AZURE_OPENAI_DEPLOYMENT) { $deployment = $env:AZURE_OPENAI_DEPLOYMENT; $model = $deployment }
    if ($env:AZURE_OPENAI_API_VERSION) { $apiVersion = $env:AZURE_OPENAI_API_VERSION }
    if ($env:OPENAI_API_KEY -and ([string]::IsNullOrWhiteSpace($apiKey) -or $apiKey -match 'PASTE_YOUR_')) {
        $apiKey = $env:OPENAI_API_KEY
    }
    if ($env:OPENAI_MODEL) { $model = $env:OPENAI_MODEL }

    if ($provider -eq 'core42' -and $endpoint -match 'openai\.azure\.com|cognitiveservices\.azure\.com') {
        $provider = 'azure-openai'
    }

    $llmEnabled = $true
    if ($config.PSObject.Properties.Name -contains 'llm' -and $null -ne $config.llm.enabled) {
        $llmEnabled = [bool]$config.llm.enabled
    }
    if (-not $llmEnabled) {
        $script:LastLlmError = 'LLM summarization is disabled (llm.enabled=false).'
        return $null
    }
    if ([string]::IsNullOrWhiteSpace($apiKey) -or $apiKey -match 'PASTE_YOUR_') {
        $script:LastLlmError = 'No LLM API key configured. Paste your key into dashboard/api/llm.env (LLM_API_KEY).'
        return $null
    }

    $rawForCache = "$Subject|$Requester|$Body"
    $cacheKey = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($rawForCache.Substring(0, [Math]::Min(800, $rawForCache.Length))))
    if ($script:LlmSummaryCache.ContainsKey($cacheKey)) {
        return $script:LlmSummaryCache[$cacheKey]
    }

    $system = @'
You summarize ManageEngine help-desk ticket descriptions for operators.

Your job: read the ticket subject and description (free text) and produce a short plain-language summary of what the description says.

Rules:
1. Reply with JSON only - no markdown fences.
2. JSON shape:
{"summary":"1 short paragraph, max 5 sentences","who":"person or email if stated","access":"role or permission if stated","environment":"Sandbox|Non-Prod|Production|Unknown","subscription":"name or blank","intent":"short phrase of what the description asks for","urgency":"P1|P2|P3|P4|Unknown"}
3. summary must paraphrase the description clearly and briefly. Cover who and what only when the description states them. Do not hunt for or invent a business justification.
4. Infer environment from words like prod/production, non-prod/staging/uat, sandbox/sbx/dev when present; otherwise Unknown.
5. Infer access from Reader, Contributor, Writer, Owner, UAA / User Access Administrator, or other permissions only when stated. Do not invent a role.
6. Never mention AI, LLM, models, agents, parsing, schemas, regex, or that information was "extracted".
7. If something is missing, omit it or mark Unknown - do not invent subscription GUIDs or motives.
'@

    $userMsg = @"
Ticket description to summarize:

Requester (portal field): $Requester
Subject: $Subject

Description:
$Body
"@

    $messages = @(
        @{ role = 'system'; content = $system },
        @{ role = 'user'; content = $userMsg }
    )

    try {
        $providerNorm = $provider.ToLowerInvariant()
        if ($providerNorm -eq 'azure-openai' -or $providerNorm -eq 'azure') {
            if ([string]::IsNullOrWhiteSpace($endpoint)) {
                throw 'Azure OpenAI selected but AZURE_OPENAI_ENDPOINT is empty.'
            }
            $uri = "$($endpoint.TrimEnd('/'))/openai/deployments/$([uri]::EscapeDataString($deployment))/chat/completions?api-version=$([uri]::EscapeDataString($apiVersion))"
            $payloadObj = @{
                messages        = $messages
                temperature     = 0.15
                max_tokens      = 500
                response_format = @{ type = 'json_object' }
            }
            $headers = @{
                'api-key'      = $apiKey
                'Content-Type' = 'application/json'
            }
            $providerLabel = 'azure-openai'
        }
        elseif ($providerNorm -eq 'openai') {
            $uri = 'https://api.openai.com/v1/chat/completions'
            $payloadObj = @{
                model           = $model
                messages        = $messages
                temperature     = 0.15
                max_tokens      = 500
                response_format = @{ type = 'json_object' }
            }
            $headers = @{
                'Authorization' = "Bearer $apiKey"
                'Content-Type'  = 'application/json'
            }
            $providerLabel = 'openai'
        }
        else {
            # Core42 â€” same as Python: base_url + default_headers api-key + api_key Bearer
            $uri = "$($baseUrl.TrimEnd('/'))/chat/completions"
            $payloadObj = @{
                model           = $model
                messages        = $messages
                temperature     = 0.15
                response_format = @{ type = 'json_object' }
            }
            if ($model -match '^gpt-5') {
                $payloadObj.max_completion_tokens = 500
            }
            else {
                $payloadObj.max_tokens = 500
            }
            $headers = @{
                'api-key'       = $apiKey
                'Authorization' = "Bearer $apiKey"
                'Content-Type'  = 'application/json'
            }
            $providerLabel = 'core42'
        }

        $payload = $payloadObj | ConvertTo-Json -Depth 10 -Compress
        if ($payload -notmatch '"messages"\s*:\s*\[') {
            $payloadObj.messages = @($messages)
            $payload = $payloadObj | ConvertTo-Json -Depth 10 -Compress
        }

        $resp = Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $payload -ErrorAction Stop
        $content = [string]$resp.choices[0].message.content
        if ([string]::IsNullOrWhiteSpace($content)) {
            throw 'LLM returned an empty completion.'
        }
        $jsonText = if ($content -match '\{[\s\S]*\}') { $Matches[0] } else { $content }
        $parsed = $jsonText | ConvertFrom-Json
        $summaryText = [string]$parsed.summary
        if ([string]::IsNullOrWhiteSpace($summaryText)) {
            $who = [string]$parsed.who
            $access = [string]$parsed.access
            $envL = [string]$parsed.environment
            $summaryText = "$(if ($who) { $who } else { 'Requester' }) needs $access in $envL."
            if ($parsed.intent) { $summaryText += " Intent: $($parsed.intent)." }
        }

        $result = @{
            summary = $summaryText.Trim()
            highlights = @{
                who          = [string]$parsed.who
                access       = [string]$parsed.access
                environment  = [string]$parsed.environment
                subscription = [string]$parsed.subscription
                intent       = [string]$parsed.intent
                urgency      = [string]$parsed.urgency
            }
            source        = 'llm'
            llmConfigured = $true
            provider      = $providerLabel
        }
        $script:LlmSummaryCache[$cacheKey] = $result
        return $result
    }
    catch {
        $providerError = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $providerError = $_.ErrorDetails.Message
        }
        if ($providerError -match '(?i)quota|access to use this model|subscription') {
            $script:LastLlmError = 'Intelligent summarization is unavailable because the Core42 account has no enabled chat-model quota. Contact compass.support@core42.ai to enable model access.'
        }
        else {
            $script:LastLlmError = 'Intelligent summarization is temporarily unavailable. Check the Core42 configuration and try again.'
        }
        Write-Host "[LLM] Ticket summary agent failed ($provider): $providerError" -ForegroundColor Yellow
        return $null
    }
}

function Get-TicketBusinessSummary {
    param([string]$Subject, [string]$Body, [string]$Requester)
    $configured = Test-LlmConfigured
    $llm = $null
    if ($configured) {
        # Retry once for transient provider/network failures. Do not retry a
        # definitive entitlement denial.
        for ($attempt = 1; $attempt -le 2; $attempt++) {
            $llm = Invoke-TicketSummaryAgent -Subject $Subject -Body $Body -Requester $Requester
            if ($llm -and $llm.summary) { return $llm }
            if ($script:LastLlmError -match 'no enabled chat-model quota') { break }
            if ($attempt -lt 2) { Start-Sleep -Milliseconds 350 }
        }
    }

    $fallback = Get-HeuristicTicketSummary -Subject $Subject -Body $Body -Requester $Requester
    $fallback.llmConfigured = $configured
    if ($configured -and $script:LastLlmError) {
        $fallback.llmError = $script:LastLlmError
    }
    elseif (-not $configured) {
        $fallback.llmError = 'LLM not configured. Paste your Core42 key into dashboard/api/llm.env (LLM_API_KEY), then restart the API.'
    }
    return $fallback
}

# Send-ManageEngineProcessNote / Set-ManageEngineTicketResolved / Get-ManageEngineClosureFields:
# extracted to ManageEngineNotes.ps1 so the unattended poller can share them (that script
# cannot be dot-sourced -- it starts an HttpListener at top level). Dot-sourced near
# DashboardHelpers.ps1 below, since Send-ManageEngineProcessNote depends on
# Get-ManageEngineNoteKind defined there. Config is now a -Config parameter throughout
# this file's call sites, not a script-scope $config read -- see MeAccessFields.ps1.

# Get-AllowlistConfig / Get-EffectiveAllowlist / Resolve-ManagementGroupAllowlist:
# extracted to SubscriptionAllowlist.ps1 so the unattended poller can share the exact
# same allowlist resolution (management-group-derived, fail-closed to the static list
# on any Azure error) instead of reading only the static subscriptionAllowlist array --
# see that file's own header for the full reasoning. Dot-sourced near the other
# extracted modules below; both call sites here now pass -Config $config explicitly
# since the shared functions have no script-scope $config of their own to read.

# Pick a sandbox/production subscription that is on the *effective* allowlist.
# Demo GUIDs (aaaaaaaaâ€¦/bbbbbbbbâ€¦) only resolve when allowlist.source=static.
function Get-PresetSubscriptionId {
    param(
        [Parameter(Mandatory)][ValidateSet('Sandbox', 'Production')][string]$Kind,
        [string[]]$EffectiveSubs,
        [object[]]$Details = @()
    )
    $eff = @($EffectiveSubs)
    $labels = $config.subscriptionLabels
    $prefer = if ($Kind -eq 'Sandbox') {
        @('efae0e0e-09ab-4c17-82db-d2d1f4382d66') + @($config.subscriptionAllowlist)
    } else {
        @('5a23842e-609d-42d4-bae5-e48e00e5b28d') + @($config.subscriptionAllowlist)
    }
    foreach ($id in $prefer) {
        if ($eff -notcontains $id) { continue }
        if ($Kind -eq 'Sandbox' -and $id -eq 'efae0e0e-09ab-4c17-82db-d2d1f4382d66') { return $id }
        if ($Kind -eq 'Production' -and $id -eq '5a23842e-609d-42d4-bae5-e48e00e5b28d') { return $id }
        $label = [string]$labels.$id
        $name = @($Details | Where-Object { $_.id -eq $id } | Select-Object -ExpandProperty name -First 1)
        $hay = "$label $name"
        if ($Kind -eq 'Sandbox' -and $hay -match '(?i)sandbox') { return $id }
        if ($Kind -eq 'Production' -and $hay -match '(?i)product|production') { return $id }
        # Static demo GUIDs when they are effectively allowed
        if ($id -match '^(aaaaaaaa|bbbbbbbb)-') { return $id }
    }
    if ($Kind -eq 'Sandbox') {
        $hit = @($Details | Where-Object { $_.name -match '(?i)sandbox' } | Select-Object -First 1)
        if ($hit) { return $hit.id }
    } else {
        $hit = @($Details | Where-Object { $_.name -match '(?i)product|prod' -and $_.name -notmatch '(?i)sandbox' } | Select-Object -First 1)
        if ($hit) { return $hit.id }
    }
    if ($eff.Count -gt 0) { return $eff[0] }
    return $config.subscriptionAllowlist[0]
}

function Get-DecisionSteps {
    param(
        [object]$Ticket,
        [string[]]$Allowlist,
        [bool]$HasExistingAssignment,
        [string]$DuplicateDetail
    )

    $matrixPath = Join-Path $repoRoot 'src/RbacDecision/Data/eligibility-matrix.json'
    $matrix = Get-Content -Raw -Path $matrixPath | ConvertFrom-Json
    $steps = [System.Collections.ArrayList]@()

    $schema = Test-TicketSchema -Ticket $Ticket -Policy $matrix.policyBlocks
    [void]$steps.Add(@{
            step = 1; name = 'Required Fields'; status = $(if ($schema.Valid) { 'pass' } else { 'fail' }); detail = $(if ($schema.Valid) { 'All required access details present' } else { $schema.Reason })
        })
    if (-not $schema.Valid) {
        return ,@($steps)
    }

    $subscriptionIds = @($Ticket.SubscriptionId)
    if ($Ticket -is [hashtable]) {
        if ($Ticket.ContainsKey('SubscriptionIds') -and $Ticket.SubscriptionIds) {
            $subscriptionIds = @($Ticket.SubscriptionIds)
        }
    }
    elseif ($Ticket.PSObject.Properties.Name -contains 'SubscriptionIds' -and $Ticket.SubscriptionIds) {
        $subscriptionIds = @($Ticket.SubscriptionIds)
    }
    $crossSub = $subscriptionIds.Count -gt 1
    $allowOk = $true
    $allowReason = 'Subscription is on the approved list'
    foreach ($subId in $subscriptionIds) {
        $allow = Test-SubscriptionAllowlist -SubscriptionId $subId -Allowlist $Allowlist
        if (-not $allow.Valid) { $allowOk = $false; $allowReason = $allow.Reason; break }
    }
    [void]$steps.Add(@{
            step = 2; name = 'Approved Subscriptions'; status = $(if ($allowOk) { 'pass' } else { 'fail' }); detail = $allowReason
        })
    if (-not $allowOk) { return ,@($steps) }

    $roleCheck = Test-RoleEligibility -Ticket $Ticket -Policy $matrix.policyBlocks
    [void]$steps.Add(@{
            step = 3; name = 'Role Eligibility'; status = $(if ($roleCheck.Valid) { 'pass' } else { 'fail' }); detail = $(if ($roleCheck.Valid) { "Role $($Ticket.Role) permitted for $($Ticket.Environment)" } else { $roleCheck.Reason })
        })
    if (-not $roleCheck.Valid) { return ,@($steps) }

    $envDetail = switch ($Ticket.Environment) {
        'Sandbox' { 'Sandbox - auto-grant path (promotion stage 1 of 3)' }
        'NonProd' { 'Non-Prod - auto-grant path (promotion stage 2 of 3)' }
        'Production' { 'Production - approval path (promotion stage 3 of 3)' }
        { [string]::IsNullOrWhiteSpace([string]$_) } { 'Environment not supplied on ticket â€” may be inferred from subscription sensitivity' }
        default { "$($Ticket.Environment) classified" }
    }
    [void]$steps.Add(@{ step = 4; name = 'Environment Classification'; status = 'pass'; detail = $envDetail })

    $priDetail = "Priority $($Ticket.Priority) - $(if ($Ticket.Priority -in @('P1','P2')) { 'expedited SLA' } else { 'standard SLA' })"
    [void]$steps.Add(@{ step = 5; name = 'Priority Classification'; status = 'pass'; detail = $priDetail })

    $sensDetail = switch ($Ticket.Role) {
        'Owner' { 'Privileged - dual approval' }
        'UAA' { 'Privileged - dual approval' }
        default { if ($crossSub) { 'Cross-subscription - senior approver' } else { 'Standard sensitivity' } }
    }
    [void]$steps.Add(@{ step = 6; name = 'Role Sensitivity'; status = 'pass'; detail = $sensDetail })

    $dupStatus = if ($HasExistingAssignment) { 'fail' } else { 'pass' }
    $dupDetail = if ($HasExistingAssignment) {
        if (-not [string]::IsNullOrWhiteSpace($DuplicateDetail)) { $DuplicateDetail }
        else { 'Active access already exists for this user, role, and scope' }
    }
    else { 'No conflicting access found' }
    [void]$steps.Add(@{ step = 7; name = 'Duplicate Access Check'; status = $dupStatus; detail = $dupDetail })

    return ,@($steps)
}

function Add-ActivityEntry {
    param(
        [hashtable]$Ticket,
        [object]$Decision,
        [array]$Steps = @(),
        [object]$Execution = $null,
        [string]$Mode = 'evaluate'
    )

    $sla = Get-SlaTierHours -Priority $Ticket.Priority
    $now = Get-Date
    $isBreakGlass = ($Decision.Action -eq 'BreakGlass') -or ($Ticket.ContainsKey('BreakGlass') -and $Ticket.BreakGlass)

    $approvalStatus = 'N/A'
    $approvalRequestedAt = $null
    $approvalCompletedAt = $null
    $assignmentStatus = $null
    $reviewStatus = $null
    $reviewDeadline = $null
    $securityAlertSent = $false

    if ($Decision.Action -eq 'Eligible') {
        $approvalStatus = 'Pending'
        $approvalRequestedAt = $now.ToUniversalTime().ToString('o')
        $assignmentStatus = 'PendingApproval'
        if ($Decision.SlaHours) { $sla.SlaHours = [int]$Decision.SlaHours }
        if ($Decision.EscalateAt) { $sla.EscalateAtHours = [int]$Decision.EscalateAt }
    }
    elseif ($isBreakGlass) {
        $approvalStatus = 'N/A'
        $reviewStatus = 'Pending'
        $reviewDeadline = $now.AddHours(4).ToUniversalTime().ToString('o')
        $securityAlertSent = $true
        $assignmentStatus = if ($Execution) { 'Active' } else { $null }
    }
    elseif ($Decision.Action -eq 'Grant' -and $Execution) {
        $assignmentStatus = 'Active'
    }

    $entry = [ordered]@{
        id                  = [guid]::NewGuid().ToString()
        timestamp           = $now.ToUniversalTime().ToString('o')
        mode                = $Mode
        ticketId            = $Ticket.TicketId
        requester           = $Ticket.RequesterUpn
        environment         = $Ticket.Environment
        role                = $Ticket.Role
        priority            = $Ticket.Priority
        action              = $Decision.Action
        path                = $Decision.Path
        reason              = $Decision.Reason
        runbook             = $Decision.Runbook
        steps               = @($Steps)
        slaHours            = if ($Decision.SlaHours) { [int]$Decision.SlaHours } else { $sla.SlaHours }
        escalateAtHours     = if ($Decision.EscalateAt) { [int]$Decision.EscalateAt } else { $sla.EscalateAtHours }
        approvalStatus      = $approvalStatus
        approvalRequestedAt = $approvalRequestedAt
        approvalCompletedAt = $approvalCompletedAt
        assignmentId        = if ($Execution -and $Execution.AssignmentId) { $Execution.AssignmentId } else { $null }
        expiresAt           = if ($Execution -and $Execution.ExpiresAt) { $Execution.ExpiresAt } else { $null }
        durationDays        = if ($Ticket.DurationDays) { [int]$Ticket.DurationDays } else { $null }
        assignmentStatus    = $assignmentStatus
        isBreakGlass        = $isBreakGlass
        reviewStatus        = $reviewStatus
        reviewDeadline      = $reviewDeadline
        securityAlertSent   = $securityAlertSent
        success             = if ($Execution) { $Execution.Success } else { $null }
    }

    [void]$script:ActivityLog.Insert(0, $entry)
    if ($script:ActivityLog.Count -gt 200) { $script:ActivityLog.RemoveAt($script:ActivityLog.Count - 1) }

    $script:Stats.Total++
    $key = $Decision.Action
    if ($script:Stats.ContainsKey($key)) { $script:Stats[$key]++ }

    # FR6 — every decision, and every provisioning result attached to it, is audited.
    # The in-memory ActivityLog above is a capped UI feed; this is the durable trail.
    if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
        $isRealWrite = ($null -ne $Execution) -and [bool]$Execution.Success -and ($Mode -ne 'simulate')
        # PS 5.1 — no ternary operator available.
        $auditActor = if ($Ticket.SubmitterUpn) { [string]$Ticket.SubmitterUpn } else { [string]$Ticket.RequesterUpn }
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'EvaluateAccessRequest' `
            -Actor $auditActor `
            -TicketId ([string]$Ticket.TicketId) `
            -Target @{
                subscriptionId = [string]$Ticket.SubscriptionId
                environment    = [string]$Ticket.Environment
                role           = [string]$Ticket.Role
                requester      = [string]$Ticket.RequesterUpn
            } `
            -After @{ action = [string]$Decision.Action; path = [string]$Decision.Path } `
            -Outcome 'Success' -Reason ([string]$Decision.Reason) `
            -Detail @{ mode = $Mode; runbook = [string]$Decision.Runbook; activityId = $entry.id
                       assignmentType = [string]$Decision.AssignmentType } | Out-Null

        if ($null -ne $Execution) {
            Write-AuditEvent -Agent 'AccessProvisioningAgent' -Action 'ProvisionAccess' `
                -Actor ([string]$Ticket.RequesterUpn) -TicketId ([string]$Ticket.TicketId) `
                -Target @{
                    subscriptionId = [string]$Ticket.SubscriptionId
                    scope          = "/subscriptions/$([string]$Ticket.SubscriptionId)"
                    role           = [string]$Ticket.Role
                    environment    = [string]$Ticket.Environment
                    principal      = [string]$Ticket.RequesterUpn
                    group          = [string]$Execution.GroupName
                } `
                -Before @{ hasAccess = $false } `
                -After @{
                    hasAccess      = [bool]$Execution.Success
                    assignmentId   = [string]$Execution.AssignmentId
                    assignmentType = [string]$Execution.AssignmentType
                    fulfilment     = [string]$Execution.Fulfilment
                    expiresAt      = [string]$Execution.ExpiresAt
                    # Get-GrantExpiryEnforcement (DashboardHelpers.ps1): names which
                    # expiry kind this is -- an auditor must be able to tell
                    # Azure-enforced (PimFallback) from tracked-only (Group, enforced
                    # solely by the reaper agent) from the audit record alone, without
                    # already knowing the fulfilment-to-enforcement mapping.
                    expiryEnforcement = if ($Execution.Fulfilment) {
                        Get-GrantExpiryEnforcement -Fulfilment ([string]$Execution.Fulfilment)
                    } else { '' }
                } `
                -Outcome $(if ($Execution.Success) { if ($Mode -eq 'simulate') { 'DryRun' } else { 'Success' } } else { 'Failed' }) `
                -Reason ([string]$Execution.Error) `
                -Detail @{ mode = $Mode; pimClient = [string]$Execution.PimClient
                           groupCreated = [bool]$Execution.GroupCreated
                           engineerActionRequired = [bool]$Execution.EngineerActionRequired } `
                -IsWrite $isRealWrite | Out-Null
        }
    }

    return $entry
}

function Invoke-TicketEvaluate {
    param(
        [object]$Body
    )

    $ticket = @{}
    $Body.PSObject.Properties | ForEach-Object { $ticket[$_.Name] = $_.Value }

    if (-not $ticket.TicketId) { $ticket.TicketId = "DEMO-$([guid]::NewGuid().ToString().Substring(0,8).ToUpper())" }
    if (-not $ticket.ResourceScope) {
        $ticket.ResourceScope = "/subscriptions/$($ticket.SubscriptionId)"
    }
    if (-not $ticket.SubmitterUpn) { $ticket.SubmitterUpn = $ticket.RequesterUpn }

    $hasDuplicate = $false
    if ($Body.PSObject.Properties.Name -contains 'hasExistingAssignment') {
        $hasDuplicate = [bool]$Body.hasExistingAssignment
    }

    $duplicateDetail = $null
    $wantGraph = ($env:AZURESENTRY_PIM_CLIENT -eq 'Graph')
    $haveSpn = $env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET
    if (-not $hasDuplicate -and $wantGraph -and $haveSpn -and $ticket.RequesterUpn) {
        try {
            $evalClient = New-RealGraphPimClient -TenantId $env:AZURE_TENANT_ID `
                -ClientId $env:AZURE_CLIENT_ID -ClientSecret $env:AZURE_CLIENT_SECRET
            $evalRole = [string]$ticket.Role
            $evalUserId = Resolve-RealUpnToObjectId -Client $evalClient -Upn ([string]$ticket.RequesterUpn)
            $evalRoleId = Get-RealRoleDefinitionId -RoleName $evalRole
            $evalScope = [string]$ticket.ResourceScope
            $existingPim = Get-RealActiveAssignments -Client $evalClient -UserId $evalUserId `
                -RoleDefinitionId $evalRoleId -Scope $evalScope
            if (@($existingPim).Count -gt 0) {
                $hasDuplicate = $true
                $duplicateDetail = 'Active PIM assignment already exists for this user, role, and scope'
            }
            elseif ($evalRole -match '^(?i)(Reader|Contributor|Writer)$') {
                $gdup = Invoke-RealGroupDuplicateCheck -Client $evalClient -UserId $evalUserId `
                    -RoleName $evalRole -SubscriptionId ([string]$ticket.SubscriptionId) `
                    -SubscriptionName $(if ($ticket.SubscriptionName) { [string]$ticket.SubscriptionName } else { $null }) `
                    -ResourceScope $evalScope
                if ($gdup.Duplicate) {
                    $hasDuplicate = $true
                    $duplicateDetail = $gdup.Reason
                }
            }
        }
        catch {
            # Non-fatal: validation still runs; process will surface grant errors.
        }
    }

    $allow = (Get-EffectiveAllowlist -Config $config).Subs
    # Decision first: the engine applies the sensitivity override + records claimed/effective,
    # and mutates the ticket's environment so the step-trace (built next) matches.
    $decision = Resolve-RbacDecision -Ticket $ticket -SubscriptionAllowlist $allow `
        -HasExistingAssignment:$hasDuplicate -ExistingAccessReason $duplicateDetail
    $steps = Get-DecisionSteps -Ticket $ticket -Allowlist $allow `
        -HasExistingAssignment:$hasDuplicate -DuplicateDetail $duplicateDetail

    $execution = $null
    $activity = Add-ActivityEntry -Ticket $ticket -Decision $decision -Steps $steps -Execution $execution -Mode 'evaluate'

    return @{
        ticket    = $ticket
        steps     = $steps
        decision  = $decision
        execution = $execution
        activity  = $activity
    }
}

function Get-MimeType {
    param([string]$Path)
    switch -Regex ($Path) {
        '\.html$' { return 'text/html; charset=utf-8' }
        '\.js$'   { return 'application/javascript; charset=utf-8' }
        '\.css$'  { return 'text/css; charset=utf-8' }
        '\.svg$'  { return 'image/svg+xml' }
        '\.json$' { return 'application/json; charset=utf-8' }
        '\.ico$'  { return 'image/x-icon' }
        default   { return 'application/octet-stream' }
    }
}

function Send-StaticFile {
    param(
        [System.Net.HttpListenerResponse]$Response,
        [string]$RelativePath
    )

    $webRoot = Join-Path (Split-Path $apiRoot -Parent) 'web/dist'
    if (-not (Test-Path $webRoot)) {
        $webRoot = Join-Path (Split-Path $apiRoot -Parent) 'web'
    }

    $safePath = $RelativePath.TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($safePath)) { $safePath = 'index.html' }
    if ($safePath -notmatch '\.') { $safePath = 'index.html' }

    $filePath = Join-Path $webRoot $safePath
    if (-not (Test-Path $filePath)) {
        $filePath = Join-Path $webRoot 'index.html'
    }

    $bytes = [System.IO.File]::ReadAllBytes($filePath)
    $Response.StatusCode = 200
    $Response.ContentType = Get-MimeType $filePath
    $Response.Headers.Add('Access-Control-Allow-Origin', '*')
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.Close()
}

$listener = New-Object System.Net.HttpListener
# Host binding precedence:
#   LISTENER_HOST env (explicit, e.g. a VM's private IP or '+') > App Service loopback > local dev.
# On a VM we bind the private IP so the dashboard is reachable over the corporate network.
$listenerHost = if ($env:LISTENER_HOST) { $env:LISTENER_HOST }
                elseif ($env:HTTP_PLATFORM_PORT) { 'localhost' }
                else { '127.0.0.1' }
$prefix = "http://${listenerHost}:$($config.port)/"
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
}
catch {
    Write-Error @"
Failed to start HTTP listener on $prefix

Common fixes on Windows:
  1. Reserve the URL (run elevated once):
     netsh http add urlacl url=$prefix user=$env:USERNAME
  2. Or try a different port:
     .\Start-DashboardApi.ps1 -Port 8788
     (update dashboard/web/vite.config.ts proxy target to match)

Original error: $($_.Exception.Message)
"@
    exit 1
}

Write-Host "AzureSentry Dashboard API listening on $prefix" -ForegroundColor Cyan
Write-Host "  RbacDecision: $repoRoot\src\RbacDecision" -ForegroundColor DarkGray
if ($script:EffectivePimClient -eq 'Graph') {
    Write-Host "  PIM client:   Graph (REAL grants via automation SPN)" -ForegroundColor Yellow
} else {
    Write-Host "  PIM client:   Mock (simulation - pass -Mode Real to Start-Local.ps1 for live PIM)" -ForegroundColor DarkGray
}

# Phase 0 — dummy data is OFF by default. The dashboard shows real data only unless
# a demo explicitly asks for the seed (config.demoSeed.enabled or -DemoSeed on Start-Local).
$script:DemoSeedEnabled = $false
if ($config.PSObject.Properties.Name -contains 'demoSeed' -and $null -ne $config.demoSeed.enabled) {
    $script:DemoSeedEnabled = [bool]$config.demoSeed.enabled
}
if ($env:AZURESENTRY_DEMO_SEED) {
    $script:DemoSeedEnabled = ($env:AZURESENTRY_DEMO_SEED -match '^(1|true|yes)$')
}
if ($script:DemoSeedEnabled) {
    Initialize-DemoSeedData -ActivityLog $script:ActivityLog -Stats $script:Stats -Allowlist $config.subscriptionAllowlist
}
Write-Host "  ManageEngine: $(if ($config.manageEngine.baseUrl) { $config.manageEngine.baseUrl } else { 'NOT CONFIGURED (set .env)' })" -ForegroundColor $(if ($config.manageEngine.baseUrl) { 'DarkGray' } else { 'Yellow' })
Write-Host "  Audit trail:  $auditPath" -ForegroundColor DarkGray
if ($script:DemoSeedEnabled) {
    Write-Host "  Demo seed:    ON — $($script:ActivityLog.Count) illustrative records (SLA/Expiry/Break-Glass views)" -ForegroundColor Yellow
} else {
    Write-Host "  Demo seed:    OFF — real data only (set demoSeed.enabled=true for a seeded demo)" -ForegroundColor DarkGray
}

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        $path = $request.Url.LocalPath
        $method = $request.HttpMethod

        try {
            if ($method -eq 'OPTIONS') {
                Write-JsonResponse -Response $response -Body @{ ok = $true }
                continue
            }

            if ($path -eq '/api/health' -and $method -eq 'GET') {
                Write-JsonResponse -Response $response -Body @{
                    status = 'ok'
                    service = 'AzureSentry Dashboard API'
                    modules = @{ rbacDecision = 'loaded'; pimClient = $script:EffectivePimClient }
                    port = [int]$config.port
                    logAnalytics = @{ configured = (Get-LogAnalyticsSettings).Configured }
                }
                continue
            }

            if ($path -eq '/api/config' -and $method -eq 'GET') {
                Write-JsonResponse -Response $response -Body $config
                continue
            }

            if ($path -eq '/api/matrix' -and $method -eq 'GET') {
                $matrixPath = Join-Path $repoRoot 'src/RbacDecision/Data/eligibility-matrix.json'
                $matrix = Get-Content -Raw -Path $matrixPath | ConvertFrom-Json
                Write-JsonResponse -Response $response -Body $matrix
                continue
            }

            if ($path -eq '/api/stats' -and $method -eq 'GET') {
                Write-JsonResponse -Response $response -Body @{
                    stats = $script:Stats
                    recentCount = $script:ActivityLog.Count
                }
                continue
            }

            if ($path -eq '/api/activity' -and $method -eq 'GET') {
                $q = $request.QueryString
                $filtered = Filter-ActivityLog -ActivityLog $script:ActivityLog `
                    -Requester $q['requester'] -Role $q['role'] `
                    -Environment $q['environment'] -Action $q['action'] `
                    -Hours $(if ($q['hours']) { [int]$q['hours'] } else { 0 })
                Write-JsonResponse -Response $response -Body @{ items = @($filtered); total = $filtered.Count }
                continue
            }

            if ($path -eq '/api/sla' -and $method -eq 'GET') {
                $sla = Get-SlaMetrics -ActivityLog $script:ActivityLog
                Write-JsonResponse -Response $response -Body $sla
                continue
            }

            if ($path -eq '/api/assignments' -and $method -eq 'GET') {
                # Reads dashboard/api/processed-tickets/ directly -- not $script:ActivityLog
                # (capped, in-memory, restart-volatile, and never written by the poller).
                # See Get-AssignmentRecords in DashboardHelpers.ps1.
                $assignments = Get-AssignmentRecords
                Write-JsonResponse -Response $response -Body @{
                    items = @($assignments)
                    active = @($assignments | Where-Object { $_.status -eq 'Active' }).Count
                    expiringSoon = @($assignments | Where-Object { $_.urgency -in @('critical','warning') }).Count
                    expiredNotRevoked = @($assignments | Where-Object { $_.status -eq 'ExpiredNotRevoked' }).Count
                }
                continue
            }

            if ($path -eq '/api/poller/status' -and $method -eq 'GET') {
                # Read-only view of the last unattended cycle. The poller is a separate
                # process; this endpoint never triggers it.
                $statusPath = Join-Path $apiRoot 'poller-status.json'
                $stopPath = Join-Path $apiRoot 'poller.stop'
                $last = $null
                if (Test-Path $statusPath) {
                    try { $last = Get-Content -Raw -Path $statusPath | ConvertFrom-Json }
                    catch { $last = $null }
                }
                # C3: enabled/mode come from the poller's own last reported cycle, never
                # from $env: in THIS (dashboard) process -- see Resolve-PollerStatusView.
                $view = Resolve-PollerStatusView -LastCycle $last

                # The Enforce Mode override (POST /api/poller/mode below) is deliberately
                # reported SEPARATELY from `mode` above, not merged into it: `mode` is what
                # the poller's last cycle actually reported doing; the override is an
                # instruction that only takes effect on the poller's NEXT cycle (up to one
                # scheduling interval away on the VM). Collapsing the two would let an
                # operator read "Enforcing" the instant they click the toggle, before the
                # poller -- a separate process -- has run again to act on it.
                #
                # Same literal apiRoot-relative path as scripts/Invoke-TicketPollerCycle.ps1
                # passes to Get-PollerConfig -ModeOverrideFilePath -- hardcoded here (not
                # resolved via Get-PollerConfig's own internal default, which lives inside
                # dashboard/api/processed-tickets/ instead) for the same reason $stopPath
                # above is hardcoded rather than derived: this process must never guess a
                # path that could silently diverge from the one the poller actually reads.
                $modeFile = Join-Path $apiRoot 'poller.mode'
                $modeOverridePresent = Test-Path -LiteralPath $modeFile
                $modeOverrideValue = $null
                if ($modeOverridePresent) {
                    try { $modeOverrideValue = (Get-Content -Raw -LiteralPath $modeFile).Trim().ToLowerInvariant() } catch { $modeOverrideValue = $null }
                }

                # Same hardcoded-path-not-guessed reasoning as $modeFile above. This
                # process does not dot-source TicketPollerAgent.ps1 (only PollerGate.ps1),
                # so it cannot call Get-PollerConfig -- it replicates the minimal
                # env/file-fallback read locally instead, same as $modeFile does today.
                $enabledFile = Join-Path $apiRoot 'poller.enabled'
                $enabledOverridePresent = Test-Path -LiteralPath $enabledFile
                $enabledOverrideValue = $null
                if ($enabledOverridePresent) {
                    try { $enabledOverrideValue = (Get-Content -Raw -LiteralPath $enabledFile).Trim().ToLowerInvariant() } catch { $enabledOverrideValue = $null }
                }

                $pollerEnvAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }
                $pollerCapsFile = Join-Path $apiRoot 'poller.caps.json'
                $pollerCapsValues = @{
                    maxGrants  = @{ value = (& $pollerEnvAsInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5); source = 'env' }
                    maxTickets = @{ value = (& $pollerEnvAsInt $env:AZURESENTRY_POLLER_MAX_TICKETS 100); source = 'env' }
                    maxAgeDays = @{ value = (& $pollerEnvAsInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7); source = 'env' }
                }
                if (Test-Path -LiteralPath $pollerCapsFile) {
                    try {
                        $pollerCapsJson = Get-Content -Raw -LiteralPath $pollerCapsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                        foreach ($key in @('maxGrants', 'maxTickets', 'maxAgeDays')) {
                            if ($pollerCapsJson.PSObject.Properties.Name -contains $key) {
                                $n = 0
                                if ([int]::TryParse([string]$pollerCapsJson.$key, [ref]$n) -and $n -gt 0) {
                                    $pollerCapsValues[$key] = @{ value = $n; source = 'override' }
                                }
                            }
                        }
                    } catch { }
                }

                Write-JsonResponse -Response $response -Body @{
                    configured  = (Test-Path $statusPath)
                    enabled     = $view.Enabled
                    mode        = $view.Mode
                    stale       = $view.Stale
                    stopFilePresent = (Test-Path $stopPath)
                    lastCycle   = $last
                    modeOverride = @{
                        present  = $modeOverridePresent
                        value    = $modeOverrideValue
                        filePath = $modeFile
                    }
                    enabledOverride = @{
                        present  = $enabledOverridePresent
                        value    = $enabledOverrideValue
                        filePath = $enabledFile
                    }
                    caps = $pollerCapsValues
                }
                continue
            }

            if ($path -eq '/api/poller/mode' -and $method -eq 'POST') {
                # The dashboard's Enforce Mode toggle. This process cannot set
                # AZURESENTRY_POLLER_MODE for the poller -- a separate process that
                # re-reads /etc/azuresentry.env fresh every cycle -- so it writes the
                # mode-override file Get-PollerConfig checks first instead. See that
                # function's .DESCRIPTION and docs/ticket-poller-runbook.md.
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                $requestedMode = ([string]$body.mode).Trim().ToLowerInvariant()
                if ($requestedMode -notin @('enforce', 'shadow')) {
                    throw "mode must be 'enforce' or 'shadow', got '$($body.mode)'."
                }
                $justification = ([string]$body.justification).Trim()
                if ($requestedMode -eq 'enforce' -and $justification.Length -lt 4) {
                    # Same minimum as the Production PIM activation justification field
                    # (LivePimView) -- switching the poller to enforce is not a per-grant
                    # action, it changes the platform's stance for every matching ticket
                    # until switched back, so it gets the same floor, enforced here too
                    # rather than trusting the UI's own confirmation step alone.
                    throw 'A justification of at least 4 characters is required to switch to enforce mode.'
                }

                $modeFile = Join-Path $apiRoot 'poller.mode'
                $previous = if (Test-Path -LiteralPath $modeFile) {
                    try { (Get-Content -Raw -LiteralPath $modeFile).Trim().ToLowerInvariant() } catch { $null }
                } else { $null }

                # Not Set-Content -Encoding utf8: that writes a BOM on PS 5.1 but not
                # pwsh 7 (ProcessedStore.ps1's Save-ProcessedTicket hit the same trap --
                # see its comment). WriteAllBytes with UTF8.GetBytes never emits a BOM on
                # either host, so the poller's Get-PollerConfig -- read by pwsh 7 in
                # production -- sees the same bytes regardless of which host wrote them.
                $modeBytes = [System.Text.Encoding]::UTF8.GetBytes($requestedMode)
                [System.IO.File]::WriteAllBytes($modeFile, $modeBytes)

                # FR6 -- this changes the platform's real-write posture, so it is audited
                # like any other write, even though the write it enables is a future one.
                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'SetModeOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ mode = $previous } -After @{ mode = $requestedMode } `
                        -Reason $justification `
                        -Detail @{ modeFile = $modeFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok        = $true
                    mode      = $requestedMode
                    filePath  = $modeFile
                    note      = 'Takes effect on the poller''s next scheduled cycle, not immediately -- it is a separate process.'
                }
                continue
            }

            if ($path -eq '/api/poller/mode' -and $method -eq 'DELETE') {
                # Clears the override so the poller falls back to AZURESENTRY_POLLER_MODE
                # from its own environment again -- the pre-toggle default behaviour.
                $modeFile = Join-Path $apiRoot 'poller.mode'
                $existed = Test-Path -LiteralPath $modeFile
                if ($existed) { Remove-Item -LiteralPath $modeFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'ClearModeOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ modeFile = $modeFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $modeFile }
                continue
            }

            if ($path -eq '/api/poller/enabled' -and $method -eq 'POST') {
                # The dashboard's automation on/off control. Mirrors POST /api/poller/mode
                # exactly (see that handler's comments) -- writes an override file this
                # process's sibling process (the poller) checks before its own env var.
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                if ($null -eq $body.enabled) { throw 'enabled (bool) is required' }
                if ($body.enabled -isnot [bool]) { throw 'enabled must be a boolean (true or false).' }
                $requestedEnabled = [bool]$body.enabled
                $justification = ([string]$body.justification).Trim()
                # No justification gate here: enabled=true alone only arms Rehearse
                # (shadow) -- the safe, no-write state the design spec explicitly says
                # needs none. The real escalation gate is POST /api/poller/mode's
                # justification requirement for mode=enforce, which Live still goes
                # through (Automation control calls setEnabled then setMode in sequence).

                $enabledFile = Join-Path $apiRoot 'poller.enabled'
                $previous = if (Test-Path -LiteralPath $enabledFile) {
                    try { (Get-Content -Raw -LiteralPath $enabledFile).Trim().ToLowerInvariant() } catch { $null }
                } else { $null }

                $valueText = if ($requestedEnabled) { 'true' } else { 'false' }
                $enabledBytes = [System.Text.Encoding]::UTF8.GetBytes($valueText)
                [System.IO.File]::WriteAllBytes($enabledFile, $enabledBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'SetEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ enabled = $previous } -After @{ enabled = $valueText } `
                        -Reason $justification `
                        -Detail @{ enabledFile = $enabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    enabled  = $requestedEnabled
                    filePath = $enabledFile
                    note     = 'Takes effect on the poller''s next scheduled cycle, not immediately -- it is a separate process.'
                }
                continue
            }

            if ($path -eq '/api/poller/enabled' -and $method -eq 'DELETE') {
                $enabledFile = Join-Path $apiRoot 'poller.enabled'
                $existed = Test-Path -LiteralPath $enabledFile
                if ($existed) { Remove-Item -LiteralPath $enabledFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'ClearEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ enabledFile = $enabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $enabledFile }
                continue
            }

            if ($path -eq '/api/poller/caps' -and $method -eq 'POST') {
                # Per-cycle limits (MaxGrantsPerCycle, MaxTicketsPerCycle, MaxTicketAgeDays)
                # -- see Get-PollerConfig's .DESCRIPTION (TicketPollerAgent.ps1) and
                # docs/superpowers/specs/2026-08-26-poller-reaper-automation-controls-design.md.
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }

                $envAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }

                $capsFile = Join-Path $apiRoot 'poller.caps.json'
                $current = @{
                    maxGrants  = & $envAsInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5
                    maxTickets = & $envAsInt $env:AZURESENTRY_POLLER_MAX_TICKETS 100
                    maxAgeDays = & $envAsInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7
                }
                $existingJson = $null
                if (Test-Path -LiteralPath $capsFile) {
                    try { $existingJson = Get-Content -Raw -LiteralPath $capsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { $existingJson = $null }
                }
                if ($existingJson) {
                    foreach ($key in @('maxGrants', 'maxTickets', 'maxAgeDays')) {
                        if ($existingJson.PSObject.Properties.Name -contains $key) {
                            $n = 0
                            if ([int]::TryParse([string]$existingJson.$key, [ref]$n) -and $n -gt 0) { $current[$key] = $n }
                        }
                    }
                }

                $updated = @{ maxGrants = $current.maxGrants; maxTickets = $current.maxTickets; maxAgeDays = $current.maxAgeDays }
                $providedKeys = @()
                foreach ($key in @('maxGrants', 'maxTickets', 'maxAgeDays')) {
                    if ($body.PSObject.Properties.Name -contains $key -and $null -ne $body.$key) {
                        $n = 0
                        if (-not ([int]::TryParse([string]$body.$key, [ref]$n)) -or $n -le 0) {
                            throw "$key must be a positive integer, got '$($body.$key)'."
                        }
                        $updated[$key] = $n
                        $providedKeys += $key
                    }
                }
                if ($providedKeys.Count -eq 0) { throw 'At least one of maxGrants, maxTickets, maxAgeDays is required.' }

                $justification = ([string]$body.justification).Trim()
                if (($providedKeys -contains 'maxGrants') -and $updated.maxGrants -gt $current.maxGrants -and $justification.Length -lt 4) {
                    throw 'A justification of at least 4 characters is required to raise maxGrants.'
                }

                # Build $toPersist: only keys that are already overridden or newly provided
                # should appear in the on-disk file. This ensures that a POST of just
                # {maxGrants: 3} creates a file with only maxGrants, not all three keys
                # (which would incorrectly mark maxTickets/maxAgeDays as source="override"
                # forever, even if maxGrants alone was the only intended change).
                $toPersist = @{}
                if ($existingJson) {
                    foreach ($key in @('maxGrants', 'maxTickets', 'maxAgeDays')) {
                        if ($existingJson.PSObject.Properties.Name -contains $key) {
                            $toPersist[$key] = $current[$key]  # carry forward already-overridden fields
                        }
                    }
                }
                foreach ($key in $providedKeys) {
                    $toPersist[$key] = $updated[$key]  # newly-provided fields (new or changing existing)
                }

                $capsBytes = [System.Text.Encoding]::UTF8.GetBytes(($toPersist | ConvertTo-Json -Compress))
                [System.IO.File]::WriteAllBytes($capsFile, $capsBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'SetCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before $current -After $updated -Reason $justification `
                        -Detail @{ capsFile = $capsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    caps     = $updated
                    filePath = $capsFile
                }
                continue
            }

            if ($path -eq '/api/poller/caps' -and $method -eq 'DELETE') {
                $capsFile = Join-Path $apiRoot 'poller.caps.json'
                $existed = Test-Path -LiteralPath $capsFile
                if ($existed) { Remove-Item -LiteralPath $capsFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'ClearCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ capsFile = $capsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $capsFile }
                continue
            }

            if ($path -eq '/api/reaper/status' -and $method -eq 'GET') {
                # Read-only view of the last reaper cycle -- same shape and reasoning as
                # /api/poller/status above. The reaper is a separate scheduled process;
                # this endpoint never triggers it. Fresh (uncached, unlike the timer's own
                # cadence) so a stale reaper.stop / last cycle age computed here is
                # accurate to the request, not to whenever this process last polled it.
                $reaperStatusPath = Join-Path $apiRoot 'reaper-status.json'
                $reaperStopPath = Join-Path $apiRoot 'reaper.stop'
                $lastReaper = $null
                if (Test-Path $reaperStatusPath) {
                    try { $lastReaper = Get-Content -Raw -Path $reaperStatusPath | ConvertFrom-Json }
                    catch { $lastReaper = $null }
                }
                $reaperView = Resolve-ReaperStatusView -LastCycle $lastReaper

                # Enforce Mode override (POST /api/reaper/mode below) -- same reasoning
                # and same explicit hardcoded path pattern as the poller's modeFile
                # above: it is an INSTRUCTION for the reaper's NEXT cycle, deliberately
                # reported separately from `mode` (the last cycle's actual behaviour),
                # and never resolved via Get-ReaperConfig's own internal default.
                $reaperModeFile = Join-Path $apiRoot 'reaper.mode'
                $reaperModeOverridePresent = Test-Path -LiteralPath $reaperModeFile
                $reaperModeOverrideValue = $null
                if ($reaperModeOverridePresent) {
                    try { $reaperModeOverrideValue = (Get-Content -Raw -LiteralPath $reaperModeFile).Trim().ToLowerInvariant() } catch { $reaperModeOverrideValue = $null }
                }

                $reaperEnabledFile = Join-Path $apiRoot 'reaper.enabled'
                $reaperEnabledOverridePresent = Test-Path -LiteralPath $reaperEnabledFile
                $reaperEnabledOverrideValue = $null
                if ($reaperEnabledOverridePresent) {
                    try { $reaperEnabledOverrideValue = (Get-Content -Raw -LiteralPath $reaperEnabledFile).Trim().ToLowerInvariant() } catch { $reaperEnabledOverrideValue = $null }
                }

                $reaperEnvAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }
                $reaperCapsFile = Join-Path $apiRoot 'reaper.caps.json'
                $reaperCapsValues = @{
                    maxRevokes = @{ value = (& $reaperEnvAsInt $env:AZURESENTRY_REAPER_MAX_REVOKES 25); source = 'env' }
                }
                if (Test-Path -LiteralPath $reaperCapsFile) {
                    try {
                        $reaperCapsJson = Get-Content -Raw -LiteralPath $reaperCapsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                        if ($reaperCapsJson.PSObject.Properties.Name -contains 'maxRevokes') {
                            $n = 0
                            if ([int]::TryParse([string]$reaperCapsJson.maxRevokes, [ref]$n) -and $n -gt 0) {
                                $reaperCapsValues.maxRevokes = @{ value = $n; source = 'override' }
                            }
                        }
                    } catch { }
                }

                Write-JsonResponse -Response $response -Body @{
                    configured  = (Test-Path $reaperStatusPath)
                    enabled     = $reaperView.Enabled
                    mode        = $reaperView.Mode
                    stale       = $reaperView.Stale
                    stopFilePresent = (Test-Path $reaperStopPath)
                    lastCycle   = $lastReaper
                    expiredUnrevoked = if ($lastReaper -and $null -ne $lastReaper.expiredUnrevoked) {
                        [int]$lastReaper.expiredUnrevoked
                    } else { $null }
                    modeOverride = @{
                        present  = $reaperModeOverridePresent
                        value    = $reaperModeOverrideValue
                        filePath = $reaperModeFile
                    }
                    enabledOverride = @{
                        present  = $reaperEnabledOverridePresent
                        value    = $reaperEnabledOverrideValue
                        filePath = $reaperEnabledFile
                    }
                    caps = $reaperCapsValues
                }
                continue
            }

            if ($path -eq '/api/reaper/mode' -and $method -eq 'POST') {
                # The dashboard's Enforce Mode toggle for the reaper. Mirrors
                # POST /api/poller/mode above exactly -- see its comments for the full
                # reasoning (separate process, next-cycle-only, fail-closed override).
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                $requestedMode = ([string]$body.mode).Trim().ToLowerInvariant()
                if ($requestedMode -notin @('enforce', 'shadow')) {
                    throw "mode must be 'enforce' or 'shadow', got '$($body.mode)'."
                }
                $justification = ([string]$body.justification).Trim()
                if ($requestedMode -eq 'enforce' -and $justification.Length -lt 4) {
                    throw 'A justification of at least 4 characters is required to switch to enforce mode.'
                }

                $reaperModeFile = Join-Path $apiRoot 'reaper.mode'
                $previous = if (Test-Path -LiteralPath $reaperModeFile) {
                    try { (Get-Content -Raw -LiteralPath $reaperModeFile).Trim().ToLowerInvariant() } catch { $null }
                } else { $null }

                # Not Set-Content -Encoding utf8: see the identical comment on the
                # poller's POST /api/poller/mode handler above (PS 5.1 BOM trap).
                $reaperModeBytes = [System.Text.Encoding]::UTF8.GetBytes($requestedMode)
                [System.IO.File]::WriteAllBytes($reaperModeFile, $reaperModeBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'SetModeOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ mode = $previous } -After @{ mode = $requestedMode } `
                        -Reason $justification `
                        -Detail @{ modeFile = $reaperModeFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok        = $true
                    mode      = $requestedMode
                    filePath  = $reaperModeFile
                    note      = 'Takes effect on the reaper''s next scheduled cycle, not immediately -- it is a separate process.'
                }
                continue
            }

            if ($path -eq '/api/reaper/mode' -and $method -eq 'DELETE') {
                $reaperModeFile = Join-Path $apiRoot 'reaper.mode'
                $existed = Test-Path -LiteralPath $reaperModeFile
                if ($existed) { Remove-Item -LiteralPath $reaperModeFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'ClearModeOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ modeFile = $reaperModeFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $reaperModeFile }
                continue
            }

            if ($path -eq '/api/reaper/enabled' -and $method -eq 'POST') {
                # Mirrors POST /api/poller/enabled exactly.
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                if ($null -eq $body.enabled) { throw 'enabled (bool) is required' }
                if ($body.enabled -isnot [bool]) { throw 'enabled must be a boolean (true or false).' }
                $requestedEnabled = [bool]$body.enabled
                $justification = ([string]$body.justification).Trim()
                # No justification gate here -- see the identical comment on
                # POST /api/poller/enabled. Live's escalation is still gated by
                # POST /api/reaper/mode's justification requirement for mode=enforce.

                $reaperEnabledFile = Join-Path $apiRoot 'reaper.enabled'
                $previous = if (Test-Path -LiteralPath $reaperEnabledFile) {
                    try { (Get-Content -Raw -LiteralPath $reaperEnabledFile).Trim().ToLowerInvariant() } catch { $null }
                } else { $null }

                $valueText = if ($requestedEnabled) { 'true' } else { 'false' }
                $reaperEnabledBytes = [System.Text.Encoding]::UTF8.GetBytes($valueText)
                [System.IO.File]::WriteAllBytes($reaperEnabledFile, $reaperEnabledBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'SetEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ enabled = $previous } -After @{ enabled = $valueText } `
                        -Reason $justification `
                        -Detail @{ enabledFile = $reaperEnabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    enabled  = $requestedEnabled
                    filePath = $reaperEnabledFile
                    note     = 'Takes effect on the reaper''s next scheduled cycle, not immediately -- it is a separate process.'
                }
                continue
            }

            if ($path -eq '/api/reaper/enabled' -and $method -eq 'DELETE') {
                $reaperEnabledFile = Join-Path $apiRoot 'reaper.enabled'
                $existed = Test-Path -LiteralPath $reaperEnabledFile
                if ($existed) { Remove-Item -LiteralPath $reaperEnabledFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'ClearEnabledOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ enabledFile = $reaperEnabledFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $reaperEnabledFile }
                continue
            }

            if ($path -eq '/api/reaper/caps' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }

                $envAsInt = {
                    param([string]$Value, [int]$Default)
                    $n = 0
                    if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
                    return $Default
                }

                $reaperCapsFile = Join-Path $apiRoot 'reaper.caps.json'
                $currentMaxRevokes = & $envAsInt $env:AZURESENTRY_REAPER_MAX_REVOKES 25
                if (Test-Path -LiteralPath $reaperCapsFile) {
                    try {
                        $existingJson = Get-Content -Raw -LiteralPath $reaperCapsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                        if ($existingJson.PSObject.Properties.Name -contains 'maxRevokes') {
                            $n = 0
                            if ([int]::TryParse([string]$existingJson.maxRevokes, [ref]$n) -and $n -gt 0) { $currentMaxRevokes = $n }
                        }
                    } catch { }
                }

                if ($null -eq $body.maxRevokes) { throw 'maxRevokes is required.' }
                $n = 0
                if (-not ([int]::TryParse([string]$body.maxRevokes, [ref]$n)) -or $n -le 0) {
                    throw "maxRevokes must be a positive integer, got '$($body.maxRevokes)'."
                }
                $updatedMaxRevokes = $n

                $justification = ([string]$body.justification).Trim()
                if ($updatedMaxRevokes -gt $currentMaxRevokes -and $justification.Length -lt 4) {
                    throw 'A justification of at least 4 characters is required to raise maxRevokes.'
                }

                $updated = @{ maxRevokes = $updatedMaxRevokes }
                $reaperCapsBytes = [System.Text.Encoding]::UTF8.GetBytes(($updated | ConvertTo-Json -Compress))
                [System.IO.File]::WriteAllBytes($reaperCapsFile, $reaperCapsBytes)

                if (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'SetCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Before @{ maxRevokes = $currentMaxRevokes } -After $updated -Reason $justification `
                        -Detail @{ capsFile = $reaperCapsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{
                    ok       = $true
                    caps     = $updated
                    filePath = $reaperCapsFile
                }
                continue
            }

            if ($path -eq '/api/reaper/caps' -and $method -eq 'DELETE') {
                $reaperCapsFile = Join-Path $apiRoot 'reaper.caps.json'
                $existed = Test-Path -LiteralPath $reaperCapsFile
                if ($existed) { Remove-Item -LiteralPath $reaperCapsFile -Force }

                if ($existed -and (Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)) {
                    Write-AuditEvent -Agent 'GrantReaperAgent' -Action 'ClearCapsOverride' `
                        -Actor 'operator' -IsWrite:$true -Outcome 'Success' `
                        -Detail @{ capsFile = $reaperCapsFile } | Out-Null
                }

                Write-JsonResponse -Response $response -Body @{ ok = $true; cleared = $existed; filePath = $reaperCapsFile }
                continue
            }

            if ($path -eq '/api/breakglass' -and $method -eq 'GET') {
                $records = Get-BreakGlassRecords -ActivityLog $script:ActivityLog
                Write-JsonResponse -Response $response -Body @{
                    items = @($records)
                    pendingReview = @($records | Where-Object { $_.reviewStatus -eq 'Pending' }).Count
                    overdueReview = @($records | Where-Object { $_.reviewStatus -eq 'Overdue' }).Count
                }
                continue
            }

            if ($path -eq '/api/activity' -and $method -eq 'DELETE') {
                $script:ActivityLog.Clear()
                $script:Stats = @{ Total = 0; Grant = 0; Eligible = 0; Reject = 0; Hold = 0; BreakGlass = 0 }
                if ($script:DemoSeedEnabled) {
                    Initialize-DemoSeedData -ActivityLog $script:ActivityLog -Stats $script:Stats -Allowlist $config.subscriptionAllowlist
                }
                # Clearing the in-memory activity feed never touches the append-only audit trail.
                Write-JsonResponse -Response $response -Body @{ ok = $true; reseeded = $script:ActivityLog.Count; demoSeed = $script:DemoSeedEnabled }
                continue
            }

            if ($path -eq '/api/evaluate' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                $grantGate = Resolve-TemplateGrantAllowed -Body $body
                if (-not $grantGate.Allowed) {
                    Write-JsonResponse -Response $response -Body (Get-TemplateGrantBlockResponse)
                    continue
                }
                $result = Invoke-TicketEvaluate -Body $body
                Write-JsonResponse -Response $response -Body $result
                continue
            }

            if ($path -eq '/api/presets' -and $method -eq 'GET') {
                # Prefer subscriptions on the *effective* allowlist (MG-derived in Real mode).
                # Demo GUIDs (aaaaaaaaâ€¦/bbbbbbbbâ€¦) only work when allowlist.source=static.
                $effObj = Get-EffectiveAllowlist -Config $config
                $eff = @($effObj.Subs)
                $details = @($effObj.Details)
                $labels = $config.subscriptionLabels
                $sandboxSub = Get-PresetSubscriptionId -Kind Sandbox -EffectiveSubs $eff -Details $details
                $prodSub = Get-PresetSubscriptionId -Kind Production -EffectiveSubs $eff -Details $details
                Write-JsonResponse -Response $response -Body @{
                    presets = @(
                        @{ id = 'sandbox-reader'; label = 'Sandbox Reader (auto-grant)'; ticket = @{
                                Environment = 'Sandbox'; Role = 'Reader'; Priority = 'P3'; DurationDays = 7
                                SubscriptionId = $sandboxSub; RequesterUpn = 'dev.user@contoso.com'
                                Justification = '' } },
                        @{ id = 'sandbox-owner'; label = 'Sandbox Owner (policy block)'; ticket = @{
                                Environment = 'Sandbox'; Role = 'Owner'; Priority = 'P3'; DurationDays = 7
                                SubscriptionId = $sandboxSub; RequesterUpn = 'dev.user@contoso.com' } },
                        @{ id = 'prod-contributor'; label = 'Production Contributor P3 (eligible)'; ticket = @{
                                Environment = 'Production'; Role = 'Contributor'; Priority = 'P3'; DurationDays = 14
                                SubscriptionId = $prodSub; RequesterUpn = 'eng.user@contoso.com'
                                Justification = 'Sprint deployment access for release 2.4 hotfix window' } },
                        @{ id = 'prod-owner'; label = 'Production Owner (dual approval)'; ticket = @{
                                Environment = 'Production'; Role = 'Owner'; Priority = 'P2'; DurationDays = 3
                                SubscriptionId = $prodSub; RequesterUpn = 'lead.user@contoso.com'
                                Justification = 'Incident bridge lead requires Owner for resource recovery' } },
                        @{ id = 'break-glass'; label = 'Break-glass P1 Contributor'; ticket = @{
                                Environment = 'Production'; Role = 'Contributor'; Priority = 'P1'; DurationDays = 1
                                SubscriptionId = $prodSub; RequesterUpn = 'oncall.user@contoso.com'
                                Justification = 'P1 outage - database connectivity failure in prod cluster'
                                BreakGlass = $true } },
                        @{ id = 'custom-role'; label = 'Custom role (hold)'; ticket = @{
                                Environment = 'Production'; Role = 'Custom'; Priority = 'P4'; DurationDays = 30
                                SubscriptionId = $prodSub; RequesterUpn = 'arch.user@contoso.com'
                                Justification = 'Custom role for data platform read-only analytics scope' } }
                    )
                    subscriptions = @(
                        foreach ($id in $eff) {
                            $fromDetail = @($details | Where-Object { $_.id -eq $id } | Select-Object -First 1)
                            $label = if ($labels.$id) { [string]$labels.$id }
                                     elseif ($fromDetail -and $fromDetail.name) { [string]$fromDetail.name }
                                     else { $id }
                            @{ id = $id; label = $label }
                        }
                    )
                }
                continue
            }

            if ($path -eq '/api/pim/status' -and $method -eq 'GET') {
                $azSub = $config.azure.subscriptionId
                $ctx = Get-PimContext -ExpectedSubscriptionId $azSub
                $ctx.azureEnabled = [bool]$config.azure.enabled
                $ctx.expectedSubscriptionName = $config.azure.subscriptionName
                $ctx.defaultDurationHours = $config.azure.defaultDurationHours
                Write-JsonResponse -Response $response -Body $ctx
                continue
            }

            if ($path -eq '/api/pim/eligible' -and $method -eq 'GET') {
                $azSub = $config.azure.subscriptionId
                $token = Get-AzMgmtToken
                $roles = Get-PimEligibleRoles -SubscriptionId $azSub -Token $token
                Write-JsonResponse -Response $response -Body @{ items = @($roles) }
                continue
            }

            if ($path -eq '/api/pim/active' -and $method -eq 'GET') {
                $azSub = $config.azure.subscriptionId
                $token = Get-AzMgmtToken
                # Cover the configured Live PIM sub plus every allowlisted subscription so
                # activations on ceo-sub / shared-apps / etc. all appear in Current Role Assignments.
                $subs = [System.Collections.Generic.List[string]]::new()
                if ($azSub) { [void]$subs.Add([string]$azSub) }
                try {
                    foreach ($s in @((Get-EffectiveAllowlist -Config $config).Subs)) {
                        if ($s -and -not $subs.Contains([string]$s)) { [void]$subs.Add([string]$s) }
                    }
                } catch { }
                foreach ($labelSub in @($config.subscriptionLabels.PSObject.Properties.Name)) {
                    if ($labelSub -match '^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$' -and -not $subs.Contains([string]$labelSub)) {
                        [void]$subs.Add([string]$labelSub)
                    }
                }
                # Drop demo placeholders from config (not real Azure IDs)
                $subs = [System.Collections.Generic.List[string]]@(
                    $subs | Where-Object { $_ -notmatch '^(aaaaaaaa|bbbbbbbb)-' }
                )
                $force = [bool]$request.QueryString['refresh']
                $active = Get-PimActiveAssignments -SubscriptionIds @($subs) -Token $token -IncludePendingRequests -ForceRefresh:$force
                Write-JsonResponse -Response $response -Body @{
                    items     = @($active)
                    activated = @($active | Where-Object { $_.isActivated }).Count
                    pending   = @($active | Where-Object { $_.isPending }).Count
                    scannedSubscriptions = @($subs)
                }
                continue
            }

            if ($path -eq '/api/pim/activate' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }

                $azSub = $config.azure.subscriptionId
                $ctx = Get-PimContext -ExpectedSubscriptionId $azSub
                if (-not $ctx.loggedIn) { throw $ctx.error }
                if (-not $ctx.principalId) { throw 'Could not resolve signed-in user object id (az ad signed-in-user show).' }

                $durationHours = if ($body.DurationHours) { [double]$body.DurationHours } else { [double]$config.azure.defaultDurationHours }
                $durationDays = [math]::Max(1, [math]::Ceiling($durationHours / 24.0))

                $ticket = @{
                    TicketId       = "LIVE-$([guid]::NewGuid().ToString().Substring(0,8).ToUpper())"
                    Role           = [string]$body.Role
                    Environment    = [string]$body.Environment
                    SubscriptionId = $azSub
                    ResourceScope  = "/subscriptions/$azSub"
                    DurationDays   = [int]$durationDays
                    Priority       = [string]$body.Priority
                    RequesterUpn   = $ctx.user
                    SubmitterUpn   = $ctx.user
                    Justification  = [string]$body.Justification
                }
                if ($body.BreakGlass) { $ticket.BreakGlass = [bool]$body.BreakGlass }

                # --- Decision gate: the platform's 7-step tree must approve before any live PIM call ---
                $allow = (Get-EffectiveAllowlist -Config $config).Subs
                $decision = Resolve-RbacDecision -Ticket $ticket -SubscriptionAllowlist $allow -HasExistingAssignment:$false
                $steps = Get-DecisionSteps -Ticket $ticket -Allowlist $allow -HasExistingAssignment:$false

                $approved = $decision.Action -in @('Grant', 'Eligible', 'BreakGlass')
                if (-not $approved) {
                    $null = Add-ActivityEntry -Ticket $ticket -Decision $decision -Steps $steps -Execution $null -Mode 'live-blocked'
                    Write-JsonResponse -Response $response -Body @{
                        ticket    = $ticket
                        steps     = $steps
                        decision  = $decision
                        activated = $false
                        blocked   = $true
                        reason    = "Decision tree returned '$($decision.Action)' - live activation not permitted."
                    }
                    continue
                }

                # --- Decision approved: perform the real PIM self-activation ---
                $token = Get-AzMgmtToken
                $activation = Invoke-PimActivate -SubscriptionId $azSub -Token $token `
                    -PrincipalId $ctx.principalId -RoleDefinitionId ([string]$body.RoleDefinitionId) `
                    -DurationHours $durationHours -Justification $ticket.Justification
                $script:ActiveAssignmentsCache = $null
                $script:ActiveAssignmentsCacheAt = [datetime]::MinValue

                $expiresAt = (Get-Date).AddHours($durationHours).ToUniversalTime().ToString('o')
                $execution = @{
                    Success      = $true
                    AssignmentId = $activation.requestId
                    ExpiresAt    = $expiresAt
                    PimClient    = 'Azure'
                }
                $activity = Add-ActivityEntry -Ticket $ticket -Decision $decision -Steps $steps -Execution $execution -Mode 'live'

                Write-JsonResponse -Response $response -Body @{
                    ticket     = $ticket
                    steps      = $steps
                    decision   = $decision
                    activated  = $true
                    activation = $activation
                    expiresAt  = $expiresAt
                    activity   = $activity
                }
                continue
            }

            if ($path -eq '/api/pim/deactivate' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                $azSub = if ($body.SubscriptionId) { [string]$body.SubscriptionId } else { $config.azure.subscriptionId }
                $ctx = Get-PimContext -ExpectedSubscriptionId $config.azure.subscriptionId
                if (-not $ctx.loggedIn) { throw $ctx.error }
                $token = Get-AzMgmtToken
                $result = Invoke-PimDeactivate -SubscriptionId $azSub -Token $token `
                    -PrincipalId $ctx.principalId -RoleDefinitionId ([string]$body.RoleDefinitionId) `
                    -Justification ([string]$body.Justification)
                $script:ActiveAssignmentsCache = $null
                $script:ActiveAssignmentsCacheAt = [datetime]::MinValue
                Write-JsonResponse -Response $response -Body @{ deactivated = $true; result = $result }
                continue
            }

            if ($path -eq '/api/manageengine/process' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }

                $grantGate = Resolve-TemplateGrantAllowed -Body $body
                if (-not $grantGate.Allowed) {
                    Write-JsonResponse -Response $response -Body (Get-TemplateGrantBlockResponse)
                    continue
                }

                $meTicketId = $body.meTicketId
                $ticketInput = @{}
                $body.ticket.PSObject.Properties | ForEach-Object { $ticketInput[$_.Name] = $_.Value }

                if (-not $ticketInput.TicketId) { $ticketInput.TicketId = "ME-$meTicketId" }
                if (-not $ticketInput.ResourceScope) {
                    $ticketInput.ResourceScope = "/subscriptions/$($ticketInput.SubscriptionId)"
                }
                if (-not $ticketInput.SubmitterUpn) { $ticketInput.SubmitterUpn = $ticketInput.RequesterUpn }

                $roleName = [string]$ticketInput.Role
                $scope    = [string]$ticketInput.ResourceScope
                $durDays  = [int]$ticketInput.DurationDays
                $just     = [string]$ticketInput.Justification
                $upn      = [string]$ticketInput.RequesterUpn

                # Choose PIM client: real Graph/SPN when explicitly enabled AND SPN creds present, else Mock.
                $wantGraph = ($script:EffectivePimClient -eq 'Graph') -or ($env:AZURESENTRY_PIM_CLIENT -eq 'Graph') -or ($config.pimClient -eq 'Graph')
                $haveSpn   = $env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET
                $useGraph  = $wantGraph -and $haveSpn
                $clientLabel = if ($useGraph) { 'Graph' } else { 'Mock' }

                # --- Idempotency layer 1: ticket already processed with a still-active grant ---
                # Only short-circuit when the PRIOR grant matches this request's role + subscription.
                # Otherwise a corrected reprocess (e.g. wrong sub â†’ right sub) would be blocked.
                $storeKey = [string]$meTicketId
                $store = Get-ProcessedTickets
                if ($storeKey -and $store.ContainsKey($storeKey) -and (Test-GrantRevocable -Prior $store[$storeKey])) {
                    $prior = $store[$storeKey]
                    $sameTarget = ([string]$prior.subscriptionId -eq [string]$ticketInput.SubscriptionId) -and
                                  ([string]$prior.role -eq [string]$ticketInput.Role)
                    $priorActive = $true
                    if ($prior.expiresAt) {
                        try { $priorActive = ([datetime]$prior.expiresAt).ToUniversalTime() -gt (Get-Date).ToUniversalTime() } catch { $priorActive = $true }
                    }
                    if ($priorActive -and $sameTarget) {
                        # Prior grant still active â€” do not create a new PIM assignment.
                        # If requester was never notified (older runs), post the ME note now.
                        $meUpdate = $null
                        $needsNotify = -not [bool]$prior.notifyRequester
                        if ($needsNotify -and $config.manageEngine.baseUrl -and $config.manageEngine.apiKey) {
                            $synthDecision = @{
                                Action                 = $prior.action
                                Path                   = $prior.path
                                AssignmentType         = $prior.assignmentType
                                EnvironmentOverridden  = $false
                                SlaHours               = $null
                            }
                            $synthExec = @{
                                Success                = $true
                                AssignmentId           = $prior.assignmentId
                                AssignmentType         = $prior.assignmentType
                                ExpiresAt              = $prior.expiresAt
                                PimClient              = $prior.pimClient
                                Fulfilment             = $prior.fulfilment
                                EngineerActionRequired = $prior.engineerActionRequired
                                EngineerActionReason   = $prior.engineerActionReason
                                GroupId                = $prior.groupId
                                GroupName              = $prior.groupName
                            }
                            $meUpdate = Send-ManageEngineProcessNote -MeTicketId $storeKey `
                                -TicketInput $ticketInput -Decision $synthDecision -Execution $synthExec -Config $config
                            if ($meUpdate -and -not $meUpdate.error) {
                                # prior comes from ConvertFrom-Json (PSCustomObject) â€” rebuild as hashtable to add fields
                                $updated = @{}
                                if ($prior -is [hashtable]) {
                                    $prior.GetEnumerator() | ForEach-Object { $updated[$_.Key] = $_.Value }
                                }
                                else {
                                    $prior.PSObject.Properties | ForEach-Object { $updated[$_.Name] = $_.Value }
                                }
                                $updated.notePosted = $true
                                $updated.notifyRequester = [bool]$meUpdate.notifyRequester
                                Save-ProcessedTicket -MeTicketId $storeKey -Entry $updated
                            }
                        }
                        Write-JsonResponse -Response $response -Body @{
                            ticket           = $ticketInput
                            steps            = @()
                            decision         = @{ Action = $prior.action; Path = $prior.path; Reason = 'Already processed - existing grant still active (idempotent, no new grant created)' }
                            execution        = @{
                                Success                = $true
                                AssignmentId           = $prior.assignmentId
                                AssignmentType         = $prior.assignmentType
                                ExpiresAt              = $prior.expiresAt
                                PimClient              = $prior.pimClient
                                Fulfilment             = $prior.fulfilment
                                EngineerActionRequired = $prior.engineerActionRequired
                                EngineerActionReason   = $prior.engineerActionReason
                                GroupId                = $prior.groupId
                                GroupName              = $prior.groupName
                            }
                            processed        = $true
                            alreadyProcessed = $true
                            activity         = $null
                            meUpdate         = $meUpdate
                        }
                        continue
                    }
                }

                # --- Idempotency layer 2 (decision step 7): existing active PIM assignment? ---
                # Resolve the requester + query live PIM once; reuse the client for the grant below.
                $pimClient = $null
                $roleDefId = $null
                $userId    = $null
                $hasExisting = $false
                $duplicateDetail = $null
                if ($useGraph) {
                    try {
                        $pimClient = New-RealGraphPimClient -TenantId $env:AZURE_TENANT_ID `
                            -ClientId $env:AZURE_CLIENT_ID -ClientSecret $env:AZURE_CLIENT_SECRET
                        $roleDefId = Get-RealRoleDefinitionId -RoleName $roleName
                        $userId    = Resolve-RealUpnToObjectId -Client $pimClient -Upn $upn
                        $existing  = Get-RealActiveAssignments -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId -Scope $scope
                        if (@($existing).Count -gt 0) {
                            $hasExisting = $true
                            $duplicateDetail = 'Active PIM assignment already exists for this user, role, and scope'
                        }
                        elseif ($userId -and ($roleName -match '^(?i)(Reader|Contributor|Writer)$')) {
                            $gdup = Invoke-RealGroupDuplicateCheck -Client $pimClient -UserId $userId `
                                -RoleName $roleName -SubscriptionId ([string]$ticketInput.SubscriptionId) `
                                -SubscriptionName $(if ($ticketInput.SubscriptionName) { [string]$ticketInput.SubscriptionName } else { $null }) `
                                -ResourceScope $scope
                            if ($gdup.Duplicate) {
                                $hasExisting = $true
                                $duplicateDetail = $gdup.Reason
                            }
                        }
                    }
                    catch {
                        # Non-fatal: if the pre-check fails we proceed; a real grant error is surfaced below.
                        $pimClient = $null
                    }
                }

                $allow = (Get-EffectiveAllowlist -Config $config).Subs
                $decision = Resolve-RbacDecision -Ticket $ticketInput -SubscriptionAllowlist $allow `
                    -HasExistingAssignment:$hasExisting -ExistingAccessReason $duplicateDetail
                $steps = Get-DecisionSteps -Ticket $ticketInput -Allowlist $allow `
                    -HasExistingAssignment:$hasExisting -DuplicateDetail $duplicateDetail

                # Enforce Sandbox â†’ NonProd â†’ Production promotion ladder before granting.
                $promo = Test-AccessPromotionLadder -TicketInput $ticketInput -Decision $decision -Config $config
                if (-not $promo.Ok) {
                    Write-JsonResponse -Response $response -Body @{
                        ticket    = $ticketInput
                        steps     = $steps
                        decision  = @{
                            Action = 'Hold'
                            Path   = 'Access-Promotion'
                            Reason = $promo.Reason
                        }
                        execution = $null
                        processed = $false
                        activity  = $null
                        meUpdate  = $null
                        promotionBlocked = $true
                    }
                    continue
                }

                $execution = $null
                $processed = $false

                if ($decision.Action -in @('Grant', 'BreakGlass', 'Eligible')) {
                    $isEligible = ($decision.Action -eq 'Eligible')
                    $usesGroupRole = $roleName -match '^(?i)(Reader|Contributor|Writer)$'

                    # Group fulfilment for Reader/Contributor/Writer on Grant and Eligible.
                    # Eligible = operator clicked Provide Access (approval). Missing groups are
                    # created as sg-<slug>-contributors|readers and granted at subscription scope.
                    try {
                        $demoSeed = $null
                        $subscriptionNameForGrant = if ($ticketInput.SubscriptionName) { [string]$ticketInput.SubscriptionName } else { $null }
                        if (-not $subscriptionNameForGrant -and $ticketInput.SubscriptionId -and $config.subscriptionLabels) {
                            $labelRaw = [string]$config.subscriptionLabels.($ticketInput.SubscriptionId)
                            if ($labelRaw) {
                                # Labels may include notes: "ceo-sub-application (sensitive - approval-gated)"
                                $subscriptionNameForGrant = ($labelRaw -split '\s*\(')[0].Trim()
                            }
                        }

                        if ($useGraph) {
                            if (-not $pimClient) {
                                $pimClient = New-RealGraphPimClient -TenantId $env:AZURE_TENANT_ID `
                                    -ClientId $env:AZURE_CLIENT_ID -ClientSecret $env:AZURE_CLIENT_SECRET
                                $roleDefId = Get-RealRoleDefinitionId -RoleName $roleName
                                $userId    = Resolve-RealUpnToObjectId -Client $pimClient -Upn $upn
                            }
                        }
                        else {
                            $env:AZURESENTRY_PIM_CLIENT = 'Mock'
                            $mockUserId = '11111111-1111-1111-1111-111111111111'
                            # Seed demo Entra groups/IAM so the group-fulfilment happy path is
                            # reachable in Mock mode instead of always PIM-falling-back (I3).
                            $demoSeed = Get-DemoGroupRbacSeed -SubscriptionLabels $config.subscriptionLabels
                            $pimClient = New-MockPimClient -Users @{ $upn = $mockUserId } `
                                -Groups $demoSeed.Groups -RoleAssignments $demoSeed.RoleAssignments `
                                -SubscriptionNames $demoSeed.SubscriptionNames
                            $roleDefId = Get-RoleDefinitionId -RoleName $roleName
                            $userId    = Resolve-UpnToObjectId -Client $pimClient -Upn $upn
                            if (-not $subscriptionNameForGrant -and $demoSeed.SubscriptionNames.ContainsKey([string]$ticketInput.SubscriptionId)) {
                                $subscriptionNameForGrant = $demoSeed.SubscriptionNames[[string]$ticketInput.SubscriptionId]
                            }
                        }

                        $useGroupGrant = $usesGroupRole -and ($decision.Action -in @('Grant', 'Eligible'))
                        if ($useGroupGrant) {
                            $gdup = if ($useGraph) {
                                Invoke-RealGroupDuplicateCheck -Client $pimClient -UserId $userId -RoleName $roleName `
                                    -SubscriptionId ([string]$ticketInput.SubscriptionId) `
                                    -SubscriptionName $subscriptionNameForGrant -ResourceScope $scope
                            }
                            else {
                                Test-GroupRbacDuplicateAccess -Client $pimClient -UserId $userId -RoleName $roleName `
                                    -SubscriptionId ([string]$ticketInput.SubscriptionId) `
                                    -SubscriptionName $subscriptionNameForGrant -ResourceScope $scope
                            }
                            if ($gdup.Duplicate) {
                                $decision = @{
                                    Action = 'Reject'
                                    Path   = 'Duplicate-Assignment'
                                    Reason = $gdup.Reason
                                }
                                $steps = Get-DecisionSteps -Ticket $ticketInput -Allowlist $allow `
                                    -HasExistingAssignment:$true -DuplicateDetail $gdup.Reason
                                Write-JsonResponse -Response $response -Body @{
                                    ticket            = $ticketInput
                                    steps             = $steps
                                    decision          = $decision
                                    execution         = @{
                                        Success     = $false
                                        GroupId     = $gdup.GroupId
                                        GroupName   = $gdup.GroupName
                                        Message     = $gdup.Reason
                                        PimClient   = $clientLabel
                                        Fulfilment  = 'Group'
                                    }
                                    processed         = $false
                                    duplicateBlocked  = $true
                                    activity          = $null
                                    meUpdate          = $null
                                }
                                continue
                            }
                            $pimFallbackType = if ($isEligible) { 'Eligible' } else { 'Active' }
                            if ($useGraph) {
                                $grant = Invoke-RealGroupOrPimGrant -Client $pimClient -UserId $userId -RoleName $roleName `
                                    -SubscriptionId ([string]$ticketInput.SubscriptionId) -SubscriptionName $subscriptionNameForGrant `
                                    -ResourceScope $scope -DurationDays $durDays -Justification $just `
                                    -PimFallbackAssignmentType $pimFallbackType
                            }
                            else {
                                $grant = Invoke-GroupOrPimGrant -Client $pimClient -UserId $userId -RoleName $roleName `
                                    -SubscriptionId ([string]$ticketInput.SubscriptionId) -SubscriptionName $subscriptionNameForGrant `
                                    -ResourceScope $scope -DurationDays $durDays -Justification $just `
                                    -PimFallbackAssignmentType $pimFallbackType
                            }
                            $execution = @{
                                Success                = $grant.Success
                                AssignmentId           = $grant.AssignmentId
                                AssignmentType         = if ($grant.Fulfilment -eq 'Group') {
                                    'GroupMembership'
                                }
                                elseif ($pimFallbackType -eq 'Eligible') {
                                    'Eligible'
                                }
                                else {
                                    'Active'
                                }
                                # Get-GrantExpiryTimestamp (DashboardHelpers.ps1): a Group
                                # fulfilment now records a TRACKED expiry too (enforced by
                                # the reaper agent, not by Azure -- see that function's
                                # comment), not $null. Previously this was permanent until
                                # a human revoked it by hand.
                                ExpiresAt              = Get-GrantExpiryTimestamp -DurationDays $durDays
                                PimClient              = $clientLabel
                                Fulfilment             = $grant.Fulfilment
                                EngineerActionRequired = $grant.EngineerActionRequired
                                EngineerActionReason   = $grant.EngineerActionReason
                                GroupId                = $grant.GroupId
                                GroupName              = $grant.GroupName
                                GroupCreated           = $grant.GroupCreated
                                GroupAlreadyExisted    = $grant.GroupAlreadyExisted
                                RoleAssignmentCreated  = $grant.RoleAssignmentCreated
                                Message                = $grant.Message
                            }
                        }
                        else {
                            if ($useGraph) {
                                if ($isEligible) {
                                    $assignment = New-RealEligibleAssignment -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId `
                                        -Scope $scope -DurationDays $durDays -Justification $just
                                }
                                else {
                                    $assignment = New-RealActiveAssignment -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId `
                                        -Scope $scope -DurationDays $durDays -Justification $just
                                }
                            }
                            else {
                                if ($isEligible) {
                                    $assignment = New-EligibleAssignment -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId `
                                        -Scope $scope -DurationDays $durDays -Justification $just
                                }
                                else {
                                    $assignment = New-ActiveAssignment -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId `
                                        -Scope $scope -DurationDays $durDays -Justification $just
                                }
                            }
                            $execution = @{
                                Success        = $true
                                AssignmentId   = $assignment.id
                                AssignmentType = if ($isEligible) { 'Eligible' } else { 'Active' }
                                ExpiresAt      = (Get-Date).AddDays($durDays).ToUniversalTime().ToString('o')
                                PimClient      = $clientLabel
                            }
                        }
                        $processed = $true
                    }
                    catch {
                        $errMsg = $_.Exception.Message
                        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
                            $errMsg = $_.ErrorDetails.Message
                        }
                        # Never stringify PIM client objects into the error (secrets live on the client).
                        if ($errMsg -match 'ClientSecret|GraphToken|ArmToken') {
                            $errMsg = 'PIM call failed (details redacted). Check API console / ARM response.'
                        }

                        # Duplicate grant: treat as idempotent success so the UI can confirm access
                        # already exists (common when Provide Access is clicked twice, or when a prior
                        # eligible/active assignment is still in place).
                        $isDuplicate = ($errMsg -match 'RoleAssignmentExists|already exists')
                        if ($isDuplicate -and $userId -and $roleDefId -and $scope) {
                            $existingId = $null
                            $existingExpiry = $null
                            try {
                                if ($useGraph) {
                                    if ($isEligible) {
                                        $existing = @(Get-RealEligibleAssignments -Client $pimClient -UserId $userId `
                                            -RoleDefinitionId $roleDefId -Scope $scope)
                                    }
                                    else {
                                        $existing = @(Get-RealActiveAssignments -Client $pimClient -UserId $userId `
                                            -RoleDefinitionId $roleDefId -Scope $scope)
                                    }
                                }
                                else {
                                    if ($isEligible) {
                                        $existing = @(Get-EligibleAssignments -Client $pimClient -UserId $userId `
                                            -RoleDefinitionId $roleDefId -Scope $scope)
                                    }
                                    else {
                                        $existing = @(Get-ActiveAssignments -Client $pimClient -UserId $userId `
                                            -RoleDefinitionId $roleDefId -Scope $scope)
                                    }
                                }
                                if ($existing.Count -gt 0) {
                                    $existingId = $existing[0].id
                                    $props = $existing[0].properties
                                    if ($props -and $props.endDateTime) {
                                        $existingExpiry = [string]$props.endDateTime
                                    }
                                    elseif ($existing[0].PSObject.Properties.Name -contains 'endDateTime' -and $existing[0].endDateTime) {
                                        $existingExpiry = [string]$existing[0].endDateTime
                                    }
                                    elseif ($existing[0].PSObject.Properties.Name -contains 'expiration' -and $existing[0].expiration) {
                                        $existingExpiry = ([datetime]$existing[0].expiration).ToUniversalTime().ToString('o')
                                    }
                                }
                            }
                            catch { }

                            $execution = @{
                                Success          = $true
                                AssignmentId     = $(if ($existingId) { $existingId } else { 'existing-assignment' })
                                AssignmentType   = if ($isEligible) { 'Eligible' } else { 'Active' }
                                ExpiresAt        = $(if ($existingExpiry) { $existingExpiry } else { (Get-Date).AddDays($durDays).ToUniversalTime().ToString('o') })
                                PimClient        = $clientLabel
                                AlreadyExisted   = $true
                                Message          = 'Access already present for this user/role/scope (idempotent).'
                            }
                            $processed = $true
                        }
                        else {
                            $execution = @{
                                Success   = $false
                                Error     = $errMsg
                                PimClient = $clientLabel
                            }
                            $processed = $false
                        }
                    }
                }

                $activity = Add-ActivityEntry -Ticket $ticketInput -Decision $decision -Steps $steps -Execution $execution -Mode 'process'

                # Post a note back to ManageEngine with the decision result.
                # show_to_requester + notify_requester â†’ requester can see/get emailed the outcome
                # (ME Admin > Notification Rules must allow note notifications to requesters).
                $meUpdate = $null
                if ($processed -and $meTicketId -and $config.manageEngine.baseUrl -and $config.manageEngine.apiKey) {
                    $meUpdate = Send-ManageEngineProcessNote -MeTicketId ([string]$meTicketId) `
                        -TicketInput $ticketInput -Decision $decision -Execution $execution -Config $config
                }

                # Persist so the dashboard shows this ticket as processed across reloads.
                if ($processed -and $meTicketId) {
                    Save-ProcessedTicket -MeTicketId ([string]$meTicketId) -Entry @{
                        meTicketId     = [string]$meTicketId
                        ticketId       = $ticketInput.TicketId
                        action         = $decision.Action
                        path           = $decision.Path
                        role           = $ticketInput.Role
                        environment    = $ticketInput.Environment
                        subscriptionId = $ticketInput.SubscriptionId
                        requesterUpn   = $ticketInput.RequesterUpn
                        pimClient      = $execution.PimClient
                        assignmentId   = $execution.AssignmentId
                        assignmentType = $execution.AssignmentType
                        expiresAt      = $execution.ExpiresAt
                        fulfilment     = $execution.Fulfilment
                        engineerActionRequired = $execution.EngineerActionRequired
                        engineerActionReason = $execution.EngineerActionReason
                        groupId        = $execution.GroupId
                        groupName      = $execution.GroupName
                        notePosted     = [bool]($meUpdate -and -not ($meUpdate.error))
                        notifyRequester = [bool]($meUpdate -and $meUpdate.notifyRequester)
                        processedAt    = (Get-Date).ToUniversalTime().ToString('o')
                        revoked        = $false
                    }
                }

                Write-JsonResponse -Response $response -Body @{
                    ticket           = $ticketInput
                    steps            = $steps
                    decision         = $decision
                    execution        = $execution
                    processed        = $processed
                    duplicateBlocked = ($decision.Path -eq 'Duplicate-Assignment')
                    activity         = $activity
                    meUpdate         = $meUpdate
                }
                continue
            }

            if ($path -eq '/api/manageengine/processed' -and $method -eq 'GET') {
                $store = Get-ProcessedTickets
                $items = @($store.Values)
                Write-JsonResponse -Response $response -Body @{ items = $items }
                continue
            }

            if ($path -eq '/api/allowlist' -and $method -eq 'GET') {
                $refresh = [bool]$request.QueryString['refresh']
                $cfg = Get-AllowlistConfig -Config $config
                $eff = Get-EffectiveAllowlist -Config $config -ForceRefresh:$refresh
                Write-JsonResponse -Response $response -Body @{
                    source            = $eff.Source
                    configuredSource  = $cfg.source
                    managementGroupId = $cfg.managementGroupId
                    cacheMinutes      = $cfg.cacheMinutes
                    exclusions        = @($cfg.exclusions)
                    degraded          = [bool]$eff.Degraded
                    error             = $eff.Error
                    fetchedAt         = $(if ($eff.FetchedAt) { $eff.FetchedAt.ToUniversalTime().ToString('o') } else { $null })
                    count             = @($eff.Subs).Count
                    subscriptions     = @($eff.Subs)
                    details           = @($eff.Details)
                }
                continue
            }

            if ($path -eq '/api/manageengine/requests' -and $method -eq 'GET') {
                try {
                    $q = $request.QueryString
                    $rowCount   = if ($q['row_count']) { [int]$q['row_count'] } else { 100 }
                    $startIndex = if ($q['page']) { [int]$q['page'] } else { 1 }
                    $allQueues  = ($q['all'] -eq '1' -or $q['all'] -eq 'true')
                    $meResponse = Get-ManageEngineRequestsRaw -RowCount $rowCount -StartIndex $startIndex
                    $queueName = Get-IdmQueueName
                    $allReqs = @($meResponse.requests)
                    $filtered = if ($allQueues) {
                        $allReqs
                    } else {
                        @($allReqs | Where-Object { Test-IsIdmTicket -Ticket $_ -QueueName $queueName })
                    }
                    Write-JsonResponse -Response $response -Body @{
                        requests        = $filtered
                        response_status = $meResponse.response_status
                        list_info       = $meResponse.list_info
                        idmQueue        = $queueName
                        idmQueueDisplay = (Get-IdentityQueueDisplayName -Name $queueName)
                        identityQueues  = @(@($queueName, 'IDAM Team') | Select-Object -Unique)
                        identityQueueLabels = @(Get-IdentityQueueLabels)
                        idmFiltered     = (-not $allQueues)
                        totalFetched    = $allReqs.Count
                        totalIdm        = $filtered.Count
                    }
                }
                catch {
                    $code = if ($_.Exception.Message -match 'not configured') { 500 } else { 502 }
                    Write-JsonResponse -Response $response -Body @{
                        error = "ManageEngine API error: $($_.Exception.Message)"
                    } -StatusCode $code
                }
                continue
            }

            if ($path -match '^/api/manageengine/requests/([^/]+)$' -and $method -eq 'GET') {
                try {
                    $reqId = $Matches[1]
                    $meResponse = Get-ManageEngineRequestById -RequestId $reqId
                    $reqObj = $meResponse.request
                    if (-not $reqObj) { throw "ManageEngine request $reqId not found" }
                    $accessFields = Get-MeConfiguredAccessFields -UdfFields $reqObj.udf_fields -Config $config
                    $templatePayload = New-TemplatePayload -Ticket $reqObj -AccessFields $accessFields
                    # Mandatory asterisks: fetch for all templates except Azure Subscription.
                    if ($templatePayload.handler -ne 'azure-subscription-grant') {
                        $mandatoryKeys = @()
                        try {
                            $mandatoryKeys = @(Get-ManageEngineMandatoryFieldKeys -RequestId $reqId -Ticket $reqObj)
                        }
                        catch {
                            Write-Host "[ME] mandatory fields lookup failed for #$reqId : $($_.Exception.Message)" -ForegroundColor Yellow
                        }
                        $templatePayload = Set-TemplatePayloadRequiredFields `
                            -Payload $templatePayload `
                            -MandatoryKeys $mandatoryKeys `
                            -UdfFields $reqObj.udf_fields
                    }
                    else {
                        $templatePayload.requiredFields = @()
                        $templatePayload.requiredPlaceholders = @()
                    }
                    # Structured intake audit once per ticket id for pending handlers.
                    $intakeKey = [string]$reqId
                    if (
                        $templatePayload.handler -eq 'pending' -and
                        $intakeKey -and
                        -not $script:TemplateIntakeRecorded.ContainsKey($intakeKey)
                    ) {
                        $null = Write-AuditEvent -Agent 'TicketIntake' -Action 'TemplateIntake' `
                            -TicketId $intakeKey `
                            -Target @{ templateName = [string]$templatePayload.templateName } `
                            -After $templatePayload `
                            -Outcome 'Success' `
                            -Reason 'Structured intake recorded — action handler pending' `
                            -Detail @{ handler = [string]$templatePayload.handler } `
                            -IsWrite:$false
                        $script:TemplateIntakeRecorded[$intakeKey] = $true
                    }
                    Write-JsonResponse -Response $response -Body @{
                        request          = $reqObj
                        accessFields     = $accessFields
                        templatePayload  = $templatePayload
                    }
                }
                catch {
                    $code = if ($_.Exception.Message -match 'not configured') { 500 } else { 502 }
                    Write-JsonResponse -Response $response -Body @{
                        error = "ManageEngine API error: $($_.Exception.Message)"
                    } -StatusCode $code
                }
                continue
            }

            if ($path -eq '/api/manageengine/analytics' -and $method -eq 'GET') {
                try {
                    $queueName = Get-IdmQueueName
                    # Overview uses ManageEngine tickets (paginated, capped to protect SDP rate limits).
                    $meResponse = Get-ManageEngineAllRequests -PageSize 100 -MaxPages 20
                    $allReqs = @($meResponse.requests)
                    $idm = @($allReqs | Where-Object { Test-IsIdmTicket -Ticket $_ -QueueName $queueName })

                    $now = Get-Date
                    $dayStart = $now.Date
                    # Must use midnight â€” Get-Date -Day 1 keeps the current clock time otherwise.
                    $monthStart = (Get-Date -Year $now.Year -Month $now.Month -Day 1).Date

                    $parseCreated = {
                        param($t)
                        return (ConvertFrom-ManageEngineTime -CreatedTime $t.created_time)
                    }

                    $daily = 0
                    $monthly = 0
                    $dailyIdm = 0
                    $monthlyIdm = 0
                    $byEnv = @{ Production = 0; NonProd = 0; Sandbox = 0; Unknown = 0 }
                    $byCategory = @{
                        'Access-Related'    = 0
                        'Environment-Issue' = 0
                        'Break-Glass'       = 0
                        'Other'             = 0
                    }
                    $byGroup = @{}
                    $byStatus = @{}
                    # FR1/FR2 environment-tag health: how much of the backlog can be prioritized at all.
                    $envTagged = 0
                    $envInferred = 0
                    $envUntagged = 0
                    # Templates with no Environment field at all (General Access, Infrastructure,
                    # Report an Issue, ...) — excluded from byEnvironment so they don't inflate
                    # "Unknown"; they have no environment concept, not an undetermined one.
                    $envNotApplicable = 0
                    $byCriticality = @{ Critical = 0; High = 0; Standard = 0; Unclassified = 0 }
                    $overviewTickets = [System.Collections.ArrayList]@()

                    foreach ($t in $allReqs) {
                        $created = & $parseCreated $t
                        $isIdm = Test-IsIdmTicket -Ticket $t -QueueName $queueName
                        if ($created) {
                            if ($created -ge $dayStart) {
                                $daily++
                                if ($isIdm) { $dailyIdm++ }
                            }
                            if ($created -ge $monthStart) {
                                $monthly++
                                if ($isIdm) { $monthlyIdm++ }
                            }
                        }
                        # FR1/FR2: the ME Environment dropdown wins; text is only a flagged inference.
                        $envResolved = Get-TicketEnvironmentResolved -Ticket $t
                        $envG = [string]$envResolved.environment
                        $envNotApplicableTicket = ($envResolved.source -eq 'NotApplicable')
                        if ($envNotApplicableTicket) {
                            $envNotApplicable++
                        }
                        else {
                            if (-not $byEnv.ContainsKey($envG)) { $byEnv[$envG] = 0 }
                            $byEnv[$envG]++
                            if ($envResolved.source -eq 'Dropdown') { $envTagged++ }
                            elseif ($envResolved.inferred) { $envInferred++ }
                            else { $envUntagged++ }
                        }

                        $prioName = if ($t.priority.name) { [string]$t.priority.name } else { '' }
                        $crit = Get-TicketCriticality -Environment $envG -Priority $prioName
                        $cat = Get-TicketCategoryBucket -Ticket $t
                        if (-not $byCategory.ContainsKey($cat)) { $byCategory[$cat] = 0 }
                        $byCategory[$cat]++
                        $gName = if ($t.group.name) { [string]$t.group.name } elseif ($t.site.name) { [string]$t.site.name } elseif ($t.category.name) { [string]$t.category.name } else { 'Unassigned' }
                        if (-not $byGroup.ContainsKey($gName)) { $byGroup[$gName] = 0 }
                        $byGroup[$gName]++
                        $st = if ($t.status.name) { [string]$t.status.name } else { 'Unknown' }
                        if (-not $byStatus.ContainsKey($st)) { $byStatus[$st] = 0 }
                        $byStatus[$st]++

                        $byCriticality[[string]$crit.Tier] = 1 + [int]$byCriticality[[string]$crit.Tier]

                        [void]$overviewTickets.Add(@{
                                id          = [string]$t.id
                                subject     = [string]$t.subject
                                department  = $gName
                                project     = $(if ($t.site.name) { [string]$t.site.name } else { $gName })
                                environment = $envG
                                # FR2: whether the environment came from the dropdown or was inferred from text.
                                environmentSource   = [string]$envResolved.source
                                environmentInferred = [bool]$envResolved.inferred
                                category    = $cat
                                ticketType  = (Get-TicketTypeLabel -Ticket $t)
                                status      = $st
                                priority    = $(if ($t.priority.name) { [string]$t.priority.name } else { 'Unknown' })
                                # FR1: environment-first criticality; priority only orders within the band.
                                criticalityScore = [int]$crit.Score
                                criticalityTier  = [string]$crit.Tier
                                priorityDemoted  = [bool]$crit.PriorityDemoted
                                requester   = $(if ($t.requester.name) { [string]$t.requester.name } elseif ($t.requester.email_id) { [string]$t.requester.email_id } else { 'Unknown' })
                                createdAt   = $(if ($t.created_time.display_value) { [string]$t.created_time.display_value } elseif ($created) { $created.ToString('o') } else { $null })
                                isIdm       = [bool]$isIdm
                            })
                    }

                    $store = Get-ProcessedTickets
                    $agentStates = @{
                        Evaluated   = [int]$script:Stats.Total
                        Granted     = [int]$script:Stats.Grant
                        Eligible    = [int]$script:Stats.Eligible
                        Rejected    = [int]$script:Stats.Reject
                        Hold        = [int]$script:Stats.Hold
                        BreakGlass  = [int]$script:Stats.BreakGlass
                        Revoked     = @($store.Values | Where-Object { $_.revoked }).Count
                    }

                    $queueLabels = Get-IdentityQueueLabels
                    Write-JsonResponse -Response $response -Body @{
                        idmQueue          = $queueName
                        idmQueueDisplay   = (Get-IdentityQueueDisplayName -Name $queueName)
                        identityQueues    = @($queueLabels | ForEach-Object { $_.name })
                        identityQueueLabels = @($queueLabels)
                        totalTickets      = $allReqs.Count
                        totalIdmTickets   = $idm.Count
                        dailyCount        = $daily
                        monthlyCount      = $monthly
                        dailyIdmCount     = $dailyIdm
                        monthlyIdmCount   = $monthlyIdm
                        byEnvironment     = $byEnv
                        byCategory        = $byCategory
                        byDepartment      = $byGroup
                        byStatus          = $byStatus
                        byCriticality     = $byCriticality
                        environmentTagHealth = @{
                            tagged        = $envTagged
                            inferred      = $envInferred
                            untagged      = $envUntagged
                            notApplicable = $envNotApplicable
                        }
                        tickets           = @($overviewTickets)
                        agentActionStates = $agentStates
                        scope             = 'all'
                        fetchedAt         = (Get-Date).ToUniversalTime().ToString('o')
                    }
                }
                catch {
                    Write-JsonResponse -Response $response -Body @{
                        error = $_.Exception.Message
                        idmQueue = (Get-IdmQueueName)
                        totalTickets = 0
                        totalIdmTickets = 0
                        dailyCount = 0
                        monthlyCount = 0
                        dailyIdmCount = 0
                        monthlyIdmCount = 0
                        byEnvironment = @{ Production = 0; NonProd = 0; Sandbox = 0; Unknown = 0 }
                        byCategory = @{ 'Access-Related' = 0; 'Environment-Issue' = 0; 'Break-Glass' = 0; Other = 0 }
                        byDepartment = @{}
                        byStatus = @{}
                        tickets = @()
                        scope = 'all'
                        agentActionStates = @{
                            Evaluated = [int]$script:Stats.Total
                            Granted = [int]$script:Stats.Grant
                            Eligible = [int]$script:Stats.Eligible
                            Rejected = [int]$script:Stats.Reject
                            Hold = [int]$script:Stats.Hold
                            BreakGlass = [int]$script:Stats.BreakGlass
                            Revoked = 0
                        }
                    } -StatusCode 200
                }
                continue
            }

            if ($path -eq '/api/manageengine/summarize' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                $subject = [string]$body.subject
                $desc = [string]$body.description
                if (-not $desc -and $body.short_description) { $desc = [string]$body.short_description }
                $requester = [string]$body.requester
                if (-not $requester -and $body.requesterEmail) { $requester = [string]$body.requesterEmail }
                # Strip HTML for summarization
                $plain = ($desc -replace '<[^>]+>', ' ' -replace '&nbsp;', ' ' -replace '\s+', ' ').Trim()
                $sum = Get-TicketBusinessSummary -Subject $subject -Body $plain -Requester $requester
                # FR6 — the summarization agent's read is an agent action too.
                Write-AuditEvent -Agent 'SummarizationAgent' -Action 'SummarizeTicket' `
                    -Actor 'operator' -TicketId ([string]$body.meTicketId) `
                    -Target @{ system = 'ManageEngine'; ticketId = [string]$body.meTicketId } `
                    -After @{ environment = [string]$sum.highlights.environment; access = [string]$sum.highlights.access } `
                    -Outcome $(if ($sum.source -eq 'llm') { 'Success' } else { 'Failed' }) `
                    -Reason ([string]$sum.llmError) `
                    -Detail @{ source = [string]$sum.source; provider = [string]$sum.provider } | Out-Null
                Write-JsonResponse -Response $response -Body $sum
                continue
            }

            if ($path -eq '/api/manageengine/revoke' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                $meTicketId = [string]$body.meTicketId
                if (-not $meTicketId) { throw 'meTicketId required' }

                $store = Get-ProcessedTickets
                $prior = if ($store.ContainsKey($meTicketId)) { $store[$meTicketId] } else { $null }
                if (-not (Test-GrantRevocable -Prior $prior)) {
                    Write-JsonResponse -Response $response -Body @{
                        error = "No active grant found for ticket #$meTicketId to revoke."
                    } -StatusCode 404
                    continue
                }
                $revokeMode = Get-RevokeFulfilmentMode -Prior $prior
                if ($prior.revoked) {
                    # If revoke succeeded earlier but requester was never notified, post the ME note now.
                    $meUpdate = $null
                    $needsNotify = -not [bool]$prior.revokeNotifyRequester
                    if ($needsNotify -and $config.manageEngine.baseUrl -and $config.manageEngine.apiKey) {
                        $synthDecision = @{ Action = 'Revoke'; Path = 'Access-Rollback'; Reason = $(if ($prior.revokeJustification) { $prior.revokeJustification } else { "Rollback / revoke for ME ticket #$meTicketId" }) }
                        $synthExec = @{ Success = $true; AssignmentId = $prior.assignmentId; PimClient = $prior.revokePimClient }
                        if ($revokeMode -eq 'Group') { $synthExec.GroupName = $prior.groupName }
                        $ticketInput = @{
                            Role             = $prior.role
                            SubscriptionId   = $prior.subscriptionId
                            RequesterUpn     = $prior.requesterUpn
                            Environment      = $prior.environment
                            Justification    = $synthDecision.Reason
                        }
                        $meUpdate = Send-ManageEngineProcessNote -MeTicketId $meTicketId `
                            -TicketInput $ticketInput -Decision $synthDecision -Execution $synthExec -Config $config
                        if ($meUpdate -and -not $meUpdate.error) {
                            $updated = @{}
                            if ($prior -is [hashtable]) {
                                $prior.GetEnumerator() | ForEach-Object { $updated[$_.Key] = $_.Value }
                            }
                            else {
                                $prior.PSObject.Properties | ForEach-Object { $updated[$_.Name] = $_.Value }
                            }
                            $updated.revokeNotePosted = $true
                            $updated.revokeNotifyRequester = [bool]$meUpdate.notifyRequester
                            Save-ProcessedTicket -MeTicketId $meTicketId -Entry $updated
                        }
                    }
                    Write-JsonResponse -Response $response -Body @{
                        revoked               = $true
                        alreadyRevoked        = $true
                        meTicketId            = $meTicketId
                        assignmentId          = $prior.assignmentId
                        groupId               = $prior.groupId
                        fulfilment            = $prior.fulfilment
                        meUpdate              = $meUpdate
                        revokeNotePosted      = $(
                            if ($meUpdate -and -not $meUpdate.error) { $true }
                            else { [bool]$prior.revokeNotePosted }
                        )
                        revokeNotifyRequester = $(
                            if ($meUpdate -and $meUpdate.notifyRequester) { $true }
                            else { [bool]$prior.revokeNotifyRequester }
                        )
                    }
                    continue
                }

                $wantGraph = ($script:EffectivePimClient -eq 'Graph') -or ($env:AZURESENTRY_PIM_CLIENT -eq 'Graph') -or ($config.pimClient -eq 'Graph')
                $haveSpn   = $env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET
                $useGraph  = $wantGraph -and $haveSpn
                $clientLabel = if ($useGraph) { 'Graph' } else { 'Mock' }
                $scope = "/subscriptions/$($prior.subscriptionId)"
                $just = if ($body.justification) { [string]$body.justification } else { "Rollback / revoke for ME ticket #$meTicketId" }

                try {
                    # Client construction (Real vs Mock) is this process's own concern --
                    # it depends on this request's config/env, not on what "revoke" means.
                    # Invoke-GrantRevocationAction (GrantRevocation.ps1) is the single
                    # revoke implementation shared with the reaper agent
                    # (src/Agents/ReaperAgent.ps1); see that file's header.
                    $pimClient = if ($useGraph) {
                        New-RealGraphPimClient -TenantId $env:AZURE_TENANT_ID `
                            -ClientId $env:AZURE_CLIENT_ID -ClientSecret $env:AZURE_CLIENT_SECRET
                    }
                    else {
                        $env:AZURESENTRY_PIM_CLIENT = 'Mock'
                        New-MockPimClient -Users @{ "$($prior.requesterUpn)" = '11111111-1111-1111-1111-111111111111' }
                    }

                    $revokeContext = if ($useGraph) {
                        @{
                            ResolveUpnToObjectId = { param($Upn) Resolve-RealUpnToObjectId -Client $pimClient -Upn $Upn }.GetNewClosure()
                            RemoveGroupMember    = { param($GroupId, $UserId) Remove-RealEntraGroupMember -Client $pimClient -GroupId $GroupId -UserId $UserId }.GetNewClosure()
                            GetRoleDefinitionId  = { param($RoleName) Get-RealRoleDefinitionId -RoleName $RoleName }.GetNewClosure()
                            RemoveAssignment     = {
                                param($AssignmentId, $Scope, $UserId, $RoleDefinitionId, $AssignmentType)
                                Remove-RealPimAssignment -Client $pimClient -AssignmentId $AssignmentId -Scope $Scope `
                                    -UserId $UserId -RoleDefinitionId $RoleDefinitionId -AssignmentType $AssignmentType
                            }.GetNewClosure()
                        }
                    }
                    else {
                        @{
                            ResolveUpnToObjectId = { param($Upn) Resolve-UpnToObjectId -Client $pimClient -Upn $Upn }.GetNewClosure()
                            RemoveGroupMember    = { param($GroupId, $UserId) Remove-EntraGroupMember -Client $pimClient -GroupId $GroupId -UserId $UserId }.GetNewClosure()
                            GetRoleDefinitionId  = { param($RoleName) Get-RoleDefinitionId -RoleName $RoleName }.GetNewClosure()
                            RemoveAssignment     = {
                                param($AssignmentId, $Scope, $UserId, $RoleDefinitionId, $AssignmentType)
                                Remove-PimAssignment -Client $pimClient -AssignmentId $AssignmentId -Scope $Scope `
                                    -UserId $UserId -RoleDefinitionId $RoleDefinitionId -AssignmentType $AssignmentType
                            }.GetNewClosure()
                        }
                    }

                    $revokeResult = Invoke-GrantRevocationAction -Prior $prior -Context $revokeContext
                    if (-not $revokeResult.Ok) { throw $revokeResult.Error }

                    $updated = @{}
                    if ($prior -is [hashtable]) {
                        $prior.GetEnumerator() | ForEach-Object { $updated[$_.Key] = $_.Value }
                    }
                    else {
                        $prior.PSObject.Properties | ForEach-Object { $updated[$_.Name] = $_.Value }
                    }
                    $updated.revoked = $true
                    $updated.revokedAt = (Get-Date).ToUniversalTime().ToString('o')
                    $updated.revokeJustification = $just
                    $updated.revokePimClient = $clientLabel

                    # FR6 — revocation is a write and gets its own audit event with before/after.
                    Write-AuditEvent -Agent 'AccessProvisioningAgent' -Action 'RevokeAccess' `
                        -Actor 'operator' -TicketId $meTicketId `
                        -Target @{
                            subscriptionId = [string]$prior.subscriptionId
                            scope          = $scope
                            role           = [string]$prior.role
                            environment    = [string]$prior.environment
                            principal      = [string]$prior.requesterUpn
                            group          = [string]$prior.groupName
                        } `
                        -Before @{ hasAccess = $true; assignmentId = [string]$prior.assignmentId
                                   fulfilment = [string]$prior.fulfilment } `
                        -After @{ hasAccess = $false; revokedAt = [string]$updated.revokedAt } `
                        -Outcome 'Success' -Reason $just `
                        -Detail @{ revokeMode = $revokeMode; pimClient = $clientLabel } `
                        -IsWrite ($clientLabel -ne 'Mock') | Out-Null

                    # Post requester-visible revoke note (ME emails requester when show_to_requester=true)
                    $meUpdate = $null
                    if ($config.manageEngine.baseUrl -and $config.manageEngine.apiKey) {
                        $synthDecision = @{ Action = 'Revoke'; Path = 'Access-Rollback'; Reason = $just }
                        $synthExec = @{ Success = $true; AssignmentId = $prior.assignmentId; PimClient = $clientLabel }
                        if ($revokeMode -eq 'Group') { $synthExec.GroupName = $prior.groupName }
                        $ticketInput = @{
                            Role           = $prior.role
                            SubscriptionId = $prior.subscriptionId
                            RequesterUpn   = $prior.requesterUpn
                            Environment    = $prior.environment
                            Justification  = $just
                        }
                        $meUpdate = Send-ManageEngineProcessNote -MeTicketId $meTicketId `
                            -TicketInput $ticketInput -Decision $synthDecision -Execution $synthExec -Config $config
                        $updated.revokeNotePosted = [bool]($meUpdate -and -not $meUpdate.error)
                        $updated.revokeNotifyRequester = [bool]($meUpdate -and $meUpdate.notifyRequester)
                        if ($meUpdate -and $meUpdate.error) {
                            $updated.revokeNoteError = [string]$meUpdate.error
                        }
                    }
                    Save-ProcessedTicket -MeTicketId $meTicketId -Entry $updated

                    Write-JsonResponse -Response $response -Body @{
                        revoked               = $true
                        meTicketId            = $meTicketId
                        assignmentId          = $prior.assignmentId
                        groupId               = $prior.groupId
                        fulfilment            = $prior.fulfilment
                        pimClient             = $clientLabel
                        meUpdate              = $meUpdate
                        revokeNotePosted      = [bool]$updated.revokeNotePosted
                        revokeNotifyRequester = [bool]$updated.revokeNotifyRequester
                    }
                }
                catch {
                    Write-JsonResponse -Response $response -Body @{
                        error = "Revoke failed: $($_.Exception.Message)"
                        pimClient = $clientLabel
                    } -StatusCode 500
                }
                continue
            }

            # ================= FR3 — agent registry =================

            if ($path -eq '/api/agents' -and $method -eq 'GET') {
                $registry = @(Get-AgentRegistry | ForEach-Object {
                        @{
                            name        = $_.Name
                            displayName = $_.DisplayName
                            kind        = $_.Kind
                            purpose     = $_.Purpose
                            writes      = [bool]$_.Writes
                            systems     = @($_.Systems)
                            permissions = @($_.Permissions)
                        }
                    })
                # Recent run counts per agent, straight from the audit trail.
                $runs = @{}
                foreach ($e in (Get-AuditEvents -Limit 2000)) {
                    $a = [string]$e.agent
                    if (-not $a -or [string]$e.outcome -eq 'Started') { continue }
                    $runs[$a] = 1 + [int]$runs[$a]
                }
                Write-JsonResponse -Response $response -Body @{
                    agents     = $registry
                    runCounts  = $runs
                    scope      = $config.departmentScope
                }
                continue
            }

            # ================= FR6 — audit trail =================

            if ($path -eq '/api/audit' -and $method -eq 'GET') {
                $q = $request.QueryString
                $limit = if ($q['limit']) { [int]$q['limit'] } else { 300 }
                $params = @{ Limit = $limit }
                foreach ($key in @('agent', 'action', 'ticketId', 'actor', 'outcome', 'correlationId')) {
                    if ($q[$key]) { $params[[System.Globalization.CultureInfo]::InvariantCulture.TextInfo.ToTitleCase($key)] = [string]$q[$key] }
                }
                if ($q['hours']) { $params['Hours'] = [int]$q['hours'] }
                if ($q['writesOnly'] -match '^(1|true|yes)$') { $params['WritesOnly'] = $true }

                Write-JsonResponse -Response $response -Body @{
                    events  = @(Get-AuditEvents @params)
                    summary = (Get-AuditSummary)
                    logAnalytics = @{ configured = (Get-LogAnalyticsSettings).Configured }
                }
                continue
            }

            if ($path -eq '/api/audit/integrity' -and $method -eq 'GET') {
                # Two independent writers -- the dashboard API and the unattended poller --
                # each own a separate hash-chained file, so integrity must cover both, not
                # just this process's own (see Test-AuditChainIntegrityMulti in AuditLog.ps1).
                $pollerAuditPath = Join-Path $apiRoot 'audit-log-poller.jsonl'
                Write-JsonResponse -Response $response -Body (Test-AuditChainIntegrityMulti -Chains @(
                        @{ Name = 'dashboard'; Path = (Get-AuditLogPath) }
                        @{ Name = 'poller'; Path = $pollerAuditPath }
                    ))
                continue
            }

            # ================= FR4 — department scope categorization =================

            if ($path -eq '/api/governance/categorize' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                $departmentFilter = if ($body -and $body.department) { [string]$body.department } else { 'Infrastructure' }
                $useLlm = $true
                if ($body -and $null -ne $body.useLlm) { $useLlm = [bool]$body.useLlm }

                try {
                    $meResponse = Get-ManageEngineAllRequests -PageSize 100 -MaxPages 20
                    $allReqs = @($meResponse.requests)
                    $scoped = if ($departmentFilter -eq 'All') { $allReqs }
                    elseif ($departmentFilter -match '(?i)\bIDAM\b|\bIDM\b|Identity\s+and\s+Access\s+Management|Identity\s+Management') {
                        @($allReqs | Where-Object { Test-IsIdmTicket -Ticket $_ -QueueName $departmentFilter })
                    }
                    else {
                        @($allReqs | Where-Object {
                                $g = if ($_.group.name) { [string]$_.group.name } else { '' }
                                $c = if ($_.category.name) { [string]$_.category.name } else { '' }
                                $tpl = Get-TicketTypeLabel -Ticket $_
                                ($g -like "*$departmentFilter*") -or ($c -like "*$departmentFilter*") -or ($tpl -like "*$departmentFilter*")
                            })
                    }

                    if ($scoped.Count -eq 0) {
                        Write-JsonResponse -Response $response -Body @{
                            error = "No tickets matched department '$departmentFilter'."
                            summary = $null; results = @()
                        } -StatusCode 200
                        continue
                    }

                    $inputTickets = @($scoped | ForEach-Object {
                            [pscustomobject]@{
                                id          = [string]$_.id
                                subject     = [string]$_.subject
                                description = $(if ($_.description) { [string]$_.description } else { [string]$_.short_description })
                                department  = $(if ($_.group.name) { [string]$_.group.name } else { '' })
                                ticketType  = (Get-TicketTypeLabel -Ticket $_)
                            }
                        })

                    $envelope = Invoke-Agent -Name 'TicketCategorizationAgent' -Action 'CategorizeDepartment' `
                        -Actor 'operator' -SwallowErrors `
                        -Target @{ system = 'ManageEngine'; department = $departmentFilter } `
                        -Detail @{ ticketCount = $inputTickets.Count; useLlm = $useLlm } `
                        -Body {
                        param($run)
                        $cat = Invoke-TicketCategorizationAgent -Tickets $inputTickets -NoLlm:(-not $useLlm)
                        $run.After = @{
                            total = $cat.Summary.total; actionable = $cat.Summary.actionable
                            unclassified = $cat.Summary.unclassified
                        }
                        if ($cat.LlmError) { $run.Reason = $cat.LlmError }
                        return $cat
                    }

                    $categorization = $envelope.Result
                    if (-not $categorization) { throw "Categorization failed: $($envelope.Error)" }
                    $script:LastCategorization = $categorization

                    Write-JsonResponse -Response $response -Body @{
                        department  = $departmentFilter
                        runId       = $envelope.RunId
                        generatedAt = $categorization.GeneratedAt
                        llmUsed     = [bool]$categorization.LlmUsed
                        llmError    = $categorization.LlmError
                        summary     = $categorization.Summary
                        catalog     = @($categorization.Catalog | ForEach-Object {
                                @{ key = $_.Key; displayName = $_.DisplayName; actionable = [bool]$_.Actionable
                                    humanAudit = [bool]$_.HumanAudit; description = $_.Description }
                            })
                        results     = @($categorization.Results)
                    }
                }
                catch {
                    Write-JsonResponse -Response $response -Body @{ error = $_.Exception.Message } -StatusCode 500
                }
                continue
            }

            # ================= FR3 — subscription disambiguation =================

            if ($path -eq '/api/subscriptions/resolve' -and $method -eq 'POST') {
                $body = Read-RequestBody -Request $request
                if (-not $body) { throw 'Request body required' }
                $reference = [string]$body.reference
                $environment = [string]$body.environment
                $effObj = Get-EffectiveAllowlist -Config $config
                $details = @($effObj.Details)
                $labels = $config.subscriptionLabels
                $subs = @(foreach ($id in @($effObj.Subs)) {
                        $fromDetail = @($details | Where-Object { $_.id -eq $id } | Select-Object -First 1)
                        $label = if ($labels.$id) { [string]$labels.$id }
                        elseif ($fromDetail -and $fromDetail.name) { [string]$fromDetail.name }
                        else { [string]$id }
                        [pscustomobject]@{ id = [string]$id; label = $label }
                    })
                $resolution = Resolve-TicketSubscription -Reference $reference -Subscriptions $subs -Environment $environment
                Write-AuditEvent -Agent 'SubscriptionResolverAgent' -Action 'ResolveSubscription' `
                    -Actor 'operator' -TicketId ([string]$body.ticketId) `
                    -Target @{ reference = $reference; environment = $environment } `
                    -After @{ status = $resolution.Status; subscriptionId = $resolution.SubscriptionId; matchType = $resolution.MatchType } `
                    -Outcome $(if ($resolution.Status -eq 'Resolved') { 'Success' } else { 'Blocked' }) `
                    -Reason $resolution.Reason -Detail @{ candidateCount = @($resolution.Candidates).Count } | Out-Null
                Write-JsonResponse -Response $response -Body @{
                    status         = $resolution.Status
                    subscriptionId = $resolution.SubscriptionId
                    label          = $resolution.Label
                    matchType      = $resolution.MatchType
                    candidates     = @($resolution.Candidates)
                    reason         = $resolution.Reason
                }
                continue
            }

            if ($path.StartsWith('/api/')) {
                Write-JsonResponse -Response $response -Body @{ error = 'Not found' } -StatusCode 404
                continue
            }

            Send-StaticFile -Response $response -RelativePath $path
        }
        catch {
            Write-JsonResponse -Response $response -Body @{
                error = $_.Exception.Message
            } -StatusCode 500
        }
    }
}
finally {
    $listener.Stop()
    $listener.Close()
}
