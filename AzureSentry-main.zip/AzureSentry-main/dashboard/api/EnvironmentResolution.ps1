<#
.SYNOPSIS
    Deterministic Environment-tag helpers shared by the dashboard API.

.DESCRIPTION
    These four functions used to live in src/Agents/EnvironmentInferenceAgent.ps1,
    alongside an LLM-based free-text inference pass and the SentryGovernanceAgent
    backfill/rollback engine that wrote inferred values back onto ManageEngine
    tickets. Both of those were removed: Environment is now a mandatory dropdown
    field on all four structured templates (Azure Subscription, GitHub Enterprise,
    ADO, Cortex) and has been populated on every ticket created since 2026-08-18,
    so there is no more backlog to infer or backfill.

    What is kept is purely deterministic -- a dropdown-value map and a keyword
    fallback, no LLM call, no write path -- and is still needed by
    Get-TicketEnvironmentResolved (below, in Start-DashboardApi.ps1) to power the
    Overview analytics "Environment Tag Health" chart and the Execution Hub's
    per-ticket environment display. That is a read-only, synchronous-on-every-
    dashboard-refresh path, which is exactly why it never called an LLM even back
    when this lived in the agent file.

.NOTES
    Not registered in the agent runtime (src/Agents/AgentRuntime.ps1): there is no
    write, no audit-worthy action, and no LLM step here to make it worth invoking
    through Invoke-Agent -- it is a plain shared helper module, the same class of
    file as MeAccessFields.ps1 or TicketTemplates.ps1.
#>

# ManageEngine Environment dropdown values -> canonical environment.
# Development / Test are Non-Prod per the agreed template mapping.
# Keys are normalized form: lowercase, with whitespace/underscores folded to hyphens
# (see Get-CanonicalEnvironmentFromDropdown), so 'Non Prod', 'non_prod' and 'Non-Prod'
# all reach the same entry without listing every spelling.
#
# Confirmed live options on the Environment dropdown for the four structured templates
# (Azure Subscription, GitHub Enterprise, ADO, Cortex): Development, Test, Preproduction,
# Production, Sandbox. All five are covered below; the remaining entries are defensive
# spelling/synonym variants kept for tickets or exports that use different wording.
$script:EnvironmentDropdownMap = @{
    'sandbox'        = 'Sandbox'
    'sbx'            = 'Sandbox'
    'lab'            = 'Sandbox'
    'development'    = 'NonProd'
    'dev'            = 'NonProd'
    'test'           = 'NonProd'
    'testing'        = 'NonProd'
    'qa'             = 'NonProd'
    'uat'            = 'NonProd'
    'staging'        = 'NonProd'
    'stage'          = 'NonProd'
    'non-prod'       = 'NonProd'
    'nonprod'        = 'NonProd'
    'non-production' = 'NonProd'
    'nonproduction'  = 'NonProd'
    'pre-prod'       = 'NonProd'
    'preprod'        = 'NonProd'
    'pre-production' = 'NonProd'
    'preproduction'  = 'NonProd'   # confirmed live dropdown value (one word, no hyphen)
    'production'     = 'Production'
    'prod'           = 'Production'
    'prd'            = 'Production'
    'live'           = 'Production'
}

function Get-CanonicalEnvironmentFromDropdown {
    <#
    .SYNOPSIS
      Deterministic map from a ManageEngine Environment dropdown value.
      Returns $null when the value is absent or not a recognised dropdown option
      (which means it is free text, reported as source 'Text'/'None' instead).
    #>
    param([string]$Value)

    $v = ([string]$Value).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($v)) { return $null }
    # Fold separators so spacing and punctuation variants collapse onto one key.
    $v = ($v -replace '[\s_]+', '-') -replace '-{2,}', '-'
    $v = $v.Trim('-')
    if ($script:EnvironmentDropdownMap.ContainsKey($v)) { return $script:EnvironmentDropdownMap[$v] }
    return $null
}

# ManageEngine templates where Environment is a REQUIRED dropdown the requester must
# fill in. When the dropdown is populated, that's the Dropdown source and none of this
# applies. When it is BLANK (a requester left a mandatory field empty), the keyword
# fallback below applies, with GitHub Enterprise carrying its own Production default.
#
# Matching is case-insensitive and tolerant of minor naming variants (e.g. "Github
# Enterprise" vs "GitHub Enterprise") via a substring check.
$script:EscalateToLlmTemplates = @(
    'Azure Subscription'
)
$script:RulesOnlyTemplates = @(
    'GitHub Enterprise',
    'ADO',
    'Cortex'
)
$script:GitHubEnterpriseTemplates = @(
    'GitHub Enterprise'
)

function Test-TemplateNameMatches {
    param([string]$TicketType, [string[]]$Candidates)
    $t = ([string]$TicketType).Trim()
    if ([string]::IsNullOrWhiteSpace($t)) { return $false }
    foreach ($known in $Candidates) {
        if ($t -ieq $known -or $t -ilike "*$known*") { return $true }
    }
    return $false
}

function Test-IsStructuredEnvironmentTemplate {
    <#
    .SYNOPSIS
      True when a ticket's ME template is one of the four with a mandatory Environment
      dropdown (Azure Subscription, GitHub Enterprise, ADO, Cortex). Every other
      template has no Environment field at all, so it is out of scope for
      classification entirely (reported as source 'NotApplicable'), not "Unknown".
    #>
    param([string]$TicketType)
    return (Test-TemplateNameMatches -TicketType $TicketType -Candidates ($script:EscalateToLlmTemplates + $script:RulesOnlyTemplates))
}

function Test-IsGitHubEnterpriseTemplate {
    <#
    .SYNOPSIS
      True for GitHub Enterprise -- the one structured template with a Production
      default when the keyword fallback finds nothing (see Get-TicketEnvironmentResolved
      in Start-DashboardApi.ps1).
    #>
    param([string]$TicketType)
    return (Test-TemplateNameMatches -TicketType $TicketType -Candidates $script:GitHubEnterpriseTemplates)
}

function Get-RuleBasedEnvironment {
    <#
    .SYNOPSIS
      Deterministic keyword fallback for when the Environment dropdown is blank.
    .DESCRIPTION
      KeywordMatch reports whether an environment term was actually present in the ticket
      text, as opposed to the environment being supplied by a template-level default
      (see Test-IsGitHubEnterpriseTemplate's caller). Confidence stays capped at 0.55
      because it is a calibration figure for ranking, never a threshold gate here --
      this path has no auto-apply/write step any more, only a read-only display.
    .OUTPUTS
      pscustomobject with Environment, Confidence, KeywordMatch, Rationale.
    #>
    param([string]$Text)

    $t = ([string]$Text).ToLowerInvariant()
    # Order matters: sandbox and non-prod are matched before a bare 'prod'.
    if ($t -match '\bsandbox\b|\bsbx\b|\blab\b') {
        return [pscustomobject]@{ Environment = 'Sandbox'; Confidence = 0.55; KeywordMatch = $true; Rationale = "Keyword match on 'sandbox'." }
    }
    if ($t -match 'non[\s_-]?prod|\bstaging\b|\bstage\b|\buat\b|\bqa\b|\bdev(?:elopment)?\b|\btest(?:ing)?\b|pre[\s_-]?prod') {
        return [pscustomobject]@{ Environment = 'NonProd'; Confidence = 0.55; KeywordMatch = $true; Rationale = 'Keyword match on a non-production term.' }
    }
    if ($t -match '\bproduction\b|\bprod\b|\bprd\b') {
        return [pscustomobject]@{ Environment = 'Production'; Confidence = 0.55; KeywordMatch = $true; Rationale = "Keyword match on 'production'." }
    }
    return [pscustomobject]@{ Environment = 'Unknown'; Confidence = 0.0; KeywordMatch = $false; Rationale = 'No environment keyword found in the ticket text.' }
}
