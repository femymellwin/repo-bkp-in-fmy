# Live Azure PIM client for the dashboard.
# Performs real PIM self-activation against Azure Resource Manager using the
# signed-in Azure CLI session. No service principal or Graph app registration
# required — it reuses the user's `az login` token for the ARM PIM endpoints.

$script:ArmBase = 'https://management.azure.com'
$script:PimApiVersion = '2020-10-01'
$script:TokenCache = $null
$script:TokenExpiresAt = [datetime]::MinValue
$script:CachedOid = $null
$script:ActiveAssignmentsCache = $null
$script:ActiveAssignmentsCacheAt = [datetime]::MinValue
$script:ActiveAssignmentsCacheKey = ''
$script:ActiveAssignmentsCacheSeconds = 45

function Get-AzCliAccount {
    # Returns the parsed `az account show` object, or $null if not logged in.
    try {
        $json = az account show -o json 2>$null
        if ([string]::IsNullOrWhiteSpace($json)) { return $null }
        return ($json | ConvertFrom-Json)
    }
    catch { return $null }
}

function Get-AzSignedInObjectId {
    if ($script:CachedOid) { return $script:CachedOid }
    try {
        $oid = az ad signed-in-user show --query id -o tsv 2>$null
        if ([string]::IsNullOrWhiteSpace($oid)) { return $null }
        $script:CachedOid = $oid.Trim()
        return $script:CachedOid
    }
    catch { return $null }
}

function Get-AzMgmtToken {
    # Cache the ARM token to avoid spawning the az CLI on every dashboard call.
    if ($script:TokenCache -and (Get-Date) -lt $script:TokenExpiresAt) {
        return $script:TokenCache
    }
    $json = az account get-access-token --resource $script:ArmBase -o json 2>$null | ConvertFrom-Json
    if (-not $json -or [string]::IsNullOrWhiteSpace($json.accessToken)) {
        throw 'Unable to acquire an Azure management token. Run: az login'
    }
    $script:TokenCache = $json.accessToken
    try { $script:TokenExpiresAt = ([datetime]$json.expiresOn).AddMinutes(-5) }
    catch { $script:TokenExpiresAt = (Get-Date).AddMinutes(50) }
    return $script:TokenCache
}

function Invoke-ArmRequest {
    param(
        [string]$Method,
        [string]$Url,
        [string]$Token,
        [object]$Body
    )
    $headers = @{ Authorization = "Bearer $Token" }
    $params = @{ Uri = $Url; Method = $Method; Headers = $headers; ContentType = 'application/json' }
    if ($Body) { $params.Body = ($Body | ConvertTo-Json -Depth 10) }

    try {
        return Invoke-RestMethod @params
    }
    catch {
        # Surface the ARM error body (policy validation, MFA, duration caps) instead
        # of a generic "(400) Bad Request".
        $raw = $null
        # PS 5.1 usually populates ErrorDetails.Message with the response body.
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $raw = $_.ErrorDetails.Message
        }
        elseif ($_.Exception.Response) {
            try {
                $stream = $_.Exception.Response.GetResponseStream()
                if ($stream.CanSeek) { $stream.Position = 0 }
                $reader = New-Object System.IO.StreamReader($stream)
                $raw = $reader.ReadToEnd()
                $reader.Close()
            }
            catch { }
        }

        $detail = $_.Exception.Message
        if (-not [string]::IsNullOrWhiteSpace($raw)) {
            try {
                $parsed = $raw | ConvertFrom-Json
                if ($parsed.error) { $detail = "$($parsed.error.code): $($parsed.error.message)" }
                else { $detail = $raw }
            }
            catch { $detail = $raw }
        }
        throw $detail
    }
}

function Get-PimContext {
    param([string]$ExpectedSubscriptionId)

    $acct = Get-AzCliAccount
    if (-not $acct) {
        return @{
            loggedIn = $false
            error    = 'Not logged in to Azure CLI. Run: az login'
        }
    }
    $oid = Get-AzSignedInObjectId
    return @{
        loggedIn               = $true
        account                = $acct.user.name
        user                   = $acct.user.name
        subscriptionId         = $acct.id
        subscriptionName       = $acct.name
        tenantId               = $acct.tenantId
        principalId            = $oid
        onExpectedSubscription = ($acct.id -eq $ExpectedSubscriptionId)
        expectedSubscriptionId = $ExpectedSubscriptionId
    }
}

function Get-PimEligibleRoles {
    param([string]$SubscriptionId, [string]$Token)

    $url = "$script:ArmBase/subscriptions/$SubscriptionId/providers/Microsoft.Authorization/roleEligibilityScheduleInstances?api-version=$script:PimApiVersion&`$filter=asTarget()"
    $resp = Invoke-ArmRequest -Method GET -Url $url -Token $Token
    $out = @()
    foreach ($v in $resp.value) {
        $p = $v.properties
        $out += [PSCustomObject]@{
            roleName         = $p.expandedProperties.roleDefinition.displayName
            roleDefinitionId = $p.roleDefinitionId
            roleDefId        = ($p.roleDefinitionId -split '/')[-1]
            scope            = $p.expandedProperties.scope.id
            scopeName        = $p.expandedProperties.scope.displayName
            scopeType        = $p.expandedProperties.scope.type
            endDateTime      = $p.endDateTime
        }
    }
    return , $out
}

function Get-PimActiveAssignments {
    param(
        [Parameter(Mandatory)][string[]]$SubscriptionIds,
        [string]$Token,
        [switch]$IncludePendingRequests,
        [switch]$ForceRefresh
    )

    $subList = @($SubscriptionIds | Where-Object { $_ -and $_ -notmatch '^(aaaaaaaa|bbbbbbbb)-' } | Select-Object -Unique)
    $cacheKey = (($subList | Sort-Object) -join ',') + "|pending=$([bool]$IncludePendingRequests)"
    if (-not $ForceRefresh -and $script:ActiveAssignmentsCache -and $script:ActiveAssignmentsCacheKey -eq $cacheKey `
        -and ((Get-Date) - $script:ActiveAssignmentsCacheAt).TotalSeconds -lt $script:ActiveAssignmentsCacheSeconds) {
        return , @($script:ActiveAssignmentsCache)
    }

    $now = (Get-Date).ToUniversalTime()
    $seen = @{}
    $out = [System.Collections.Generic.List[object]]::new()

    # Fan out ARM reads in-process (Start-Job is too slow on Windows).
    $armBase = $script:ArmBase
    $apiVer = $script:PimApiVersion
    $includePending = [bool]$IncludePendingRequests
    $chunks = New-Object System.Collections.ArrayList
    $pool = [runspacefactory]::CreateRunspacePool(1, [Math]::Min(8, [Math]::Max(1, $subList.Count)))
    $pool.Open()
    $pipes = @()
    foreach ($subId in $subList) {
        $ps = [powershell]::Create().AddScript({
            param($ArmBase, $ApiVer, $SubId, $Token, $IncludePending)
            $result = @{ subId = $SubId; instances = @(); requests = @() }
            try {
                $headers = @{ Authorization = "Bearer $Token" }
                $instUrl = "$ArmBase/subscriptions/$SubId/providers/Microsoft.Authorization/roleAssignmentScheduleInstances?api-version=$ApiVer&`$filter=asTarget()"
                $inst = Invoke-RestMethod -Uri $instUrl -Headers $headers -Method GET
                $result.instances = @($inst.value)
                if ($IncludePending) {
                    $reqUrl = "$ArmBase/subscriptions/$SubId/providers/Microsoft.Authorization/roleAssignmentScheduleRequests?api-version=$ApiVer&`$filter=asTarget()"
                    $req = Invoke-RestMethod -Uri $reqUrl -Headers $headers -Method GET
                    $result.requests = @($req.value)
                }
            }
            catch { }
            return $result
        }).AddArgument($armBase).AddArgument($apiVer).AddArgument($subId).AddArgument($Token).AddArgument($includePending)
        $ps.RunspacePool = $pool
        $pipes += @{ ps = $ps; handle = $ps.BeginInvoke() }
    }
    foreach ($p in $pipes) {
        try {
            $chunk = $p.ps.EndInvoke($p.handle)
            if ($chunk -and $chunk[0]) { [void]$chunks.Add($chunk[0]) }
        }
        catch { }
        finally { $p.ps.Dispose() }
    }
    $pool.Close()
    $pool.Dispose()

    foreach ($chunk in $chunks) {
            if (-not $chunk) { continue }
            $subId = $chunk.subId

            foreach ($v in @($chunk.instances)) {
                if (-not $v) { continue }
                $key = [string]$v.id
                if (-not $key) { $key = "$($v.properties.roleDefinitionId)|$($v.properties.scope)|$($v.properties.assignmentType)|$($v.properties.startDateTime)" }
                if ($seen.ContainsKey($key)) { continue }
                $seen[$key] = $true

                $p = $v.properties
                $remaining = $null
                if ($p.endDateTime) {
                    $end = ([datetime]$p.endDateTime).ToUniversalTime()
                    $remaining = [math]::Round(($end - $now).TotalHours, 1)
                }
                $scopeId = if ($p.expandedProperties.scope.id) { $p.expandedProperties.scope.id } else { $p.scope }
                $out.Add([PSCustomObject]@{
                    id               = $key
                    roleName         = $p.expandedProperties.roleDefinition.displayName
                    roleDefinitionId = $p.roleDefinitionId
                    roleDefId        = ($p.roleDefinitionId -split '/')[-1]
                    scope            = $scopeId
                    scopeName        = $p.expandedProperties.scope.displayName
                    scopeType        = $p.expandedProperties.scope.type
                    subscriptionId   = $subId
                    assignmentType   = $p.assignmentType
                    memberType       = $p.memberType
                    status           = $p.status
                    startDateTime    = $p.startDateTime
                    endDateTime      = $p.endDateTime
                    remainingHours   = $remaining
                    isActivated      = ($p.assignmentType -eq 'Activated')
                    isPending        = $false
                    requestId        = $null
                })
            }

            $pendingStatuses = @(
                'PendingApproval', 'PendingApprovalProvisioning', 'PendingAdminDecision',
                'PendingProvisioning', 'ProvisioningStarted', 'Accepted', 'PendingEvaluation',
                'PendingScheduleCreation', 'ScheduleCreated', 'PendingExternalProvisioning'
            )
            foreach ($v in @($chunk.requests)) {
                if (-not $v) { continue }
                $p = $v.properties
                if ($p.status -notin $pendingStatuses) { continue }
                if ($p.requestType -notin @('SelfActivate', 'AdminAssign')) { continue }

                $key = [string]$v.id
                if (-not $key) { $key = "req|$($v.name)|$subId" }
                if ($seen.ContainsKey($key)) { continue }
                $seen[$key] = $true

                $remaining = $null
                $endDt = $null
                if ($p.scheduleInfo -and $p.scheduleInfo.expiration -and $p.scheduleInfo.expiration.endDateTime) {
                    $endDt = $p.scheduleInfo.expiration.endDateTime
                    try {
                        $end = ([datetime]$endDt).ToUniversalTime()
                        $remaining = [math]::Round(($end - $now).TotalHours, 1)
                    } catch { }
                }
                $scopeId = if ($p.expandedProperties.scope.id) { $p.expandedProperties.scope.id } else { $p.scope }
                $out.Add([PSCustomObject]@{
                    id               = $key
                    roleName         = $p.expandedProperties.roleDefinition.displayName
                    roleDefinitionId = $p.roleDefinitionId
                    roleDefId        = ($p.roleDefinitionId -split '/')[-1]
                    scope            = $scopeId
                    scopeName        = $p.expandedProperties.scope.displayName
                    scopeType        = $p.expandedProperties.scope.type
                    subscriptionId   = $subId
                    assignmentType   = 'Pending'
                    memberType       = $p.requestType
                    status           = $p.status
                    startDateTime    = $p.scheduleInfo.startDateTime
                    endDateTime      = $endDt
                    remainingHours   = $remaining
                    isActivated      = $false
                    isPending        = $true
                    requestId        = $v.name
                })
            }
    }

    $sorted = @($out | Sort-Object `
        @{ Expression = { if ($_.isPending) { 0 } elseif ($_.isActivated) { 1 } else { 2 } } }, `
        @{ Expression = { $_.startDateTime }; Descending = $true }, `
        roleName)
    $script:ActiveAssignmentsCache = $sorted
    $script:ActiveAssignmentsCacheAt = Get-Date
    $script:ActiveAssignmentsCacheKey = $cacheKey
    return , $sorted
}


function Invoke-PimActivate {
    param(
        [string]$SubscriptionId,
        [string]$Token,
        [string]$PrincipalId,
        [string]$RoleDefinitionId,
        [double]$DurationHours,
        [string]$Justification
    )

    $scope = "/subscriptions/$SubscriptionId"
    $requestId = [guid]::NewGuid().ToString()
    $url = "$script:ArmBase$scope/providers/Microsoft.Authorization/roleAssignmentScheduleRequests/$requestId`?api-version=$script:PimApiVersion"

    $totalMinutes = [int][math]::Round($DurationHours * 60)
    if ($totalMinutes -lt 1) { $totalMinutes = 60 }

    $body = @{
        properties = @{
            principalId      = $PrincipalId
            roleDefinitionId = $RoleDefinitionId
            requestType      = 'SelfActivate'
            justification    = $Justification
            scheduleInfo     = @{
                startDateTime = $null
                expiration    = @{
                    type     = 'AfterDuration'
                    duration = "PT${totalMinutes}M"
                }
            }
        }
    }

    $resp = Invoke-ArmRequest -Method PUT -Url $url -Token $Token -Body $body
    return [PSCustomObject]@{
        requestId        = $requestId
        status           = $resp.properties.status
        roleName         = $resp.properties.expandedProperties.roleDefinition.displayName
        roleDefinitionId = $RoleDefinitionId
        startDateTime    = $resp.properties.scheduleInfo.startDateTime
        durationMinutes  = $totalMinutes
    }
}

function Invoke-PimDeactivate {
    param(
        [string]$SubscriptionId,
        [string]$Token,
        [string]$PrincipalId,
        [string]$RoleDefinitionId,
        [string]$Justification
    )

    $scope = "/subscriptions/$SubscriptionId"
    $requestId = [guid]::NewGuid().ToString()
    $url = "$script:ArmBase$scope/providers/Microsoft.Authorization/roleAssignmentScheduleRequests/$requestId`?api-version=$script:PimApiVersion"

    $body = @{
        properties = @{
            principalId      = $PrincipalId
            roleDefinitionId = $RoleDefinitionId
            requestType      = 'SelfDeactivate'
            justification    = $(if ($Justification) { $Justification } else { 'Deactivated from AzureSentry dashboard' })
        }
    }

    $resp = Invoke-ArmRequest -Method PUT -Url $url -Token $Token -Body $body
    return [PSCustomObject]@{ requestId = $requestId; status = $resp.properties.status }
}
