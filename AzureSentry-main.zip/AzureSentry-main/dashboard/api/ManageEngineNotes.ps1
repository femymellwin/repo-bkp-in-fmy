<#
.SYNOPSIS
    ManageEngine write-back: the requester-visible process note, and ticket resolution.

.DESCRIPTION
    Extracted from Start-DashboardApi.ps1 so the unattended poller can share it. The
    poller cannot dot-source that script at all -- it starts an HttpListener at top level,
    so sourcing it would launch a second web server. Same pattern as ProcessedStore.ps1,
    MeAccessFields.ps1 and AccessPromotion.ps1.

    Config arrives as a -Config parameter rather than being read from a $config script
    variable, because the poller has no such scope -- see MeAccessFields.ps1 for the
    identical reasoning.

    Depends on Get-ManageEngineNoteKind (dashboard/api/DashboardHelpers.ps1) being
    dot-sourced into the caller's session already; both Start-DashboardApi.ps1 and
    scripts/Invoke-TicketPollerCycle.ps1 do this before calling in.
#>

function Get-ManageEngineClosureFields {
    <#
    .SYNOPSIS
      Resolve the ManageEngine fields Set-ManageEngineTicketResolved writes when it
      closes a ticket, applying config.json overrides on top of built-in defaults.
    .DESCRIPTION
      The default udf keys/values below were discovered by hand against one real
      ManageEngine ticket roughly six weeks before this was written -- they are
      UNVERIFIED, not facts about this ME instance. Treat them as placeholders an
      operator is expected to confirm against a real ticket and correct via
      config.json's manageEngine.closureFields block if wrong. A wrong key must be
      fixable in config, never a code change.
    .PARAMETER Config
      The API/poller config object. Overrides come from
      $Config.manageEngine.closureFields.udfFields (a flat key -> value map; any key
      starting with '_' is a documentation/help entry and is ignored) and
      $Config.manageEngine.closureFields.resolutionContent. A $null config, or one with
      no manageEngine (or no closureFields under it), falls back to the defaults below.
    #>
    param([object]$Config = $null)

    # udf_pick_3713 = "Vendor Compliance" (value "Yes"); udf_pick_3722 = "Account Status"
    # (value "Access Granted"). Unverified defaults -- see .DESCRIPTION.
    $udfFields = [ordered]@{
        udf_pick_3713 = 'Yes'
        udf_pick_3722 = 'Access Granted'
    }
    $resolutionContent = 'Access granted automatically by the AzureSentry unattended ticket poller. See the processed-tickets store and audit log for the grant record.'

    if ($Config -and ($Config.PSObject.Properties.Name -contains 'manageEngine') -and $Config.manageEngine -and
        ($Config.manageEngine.PSObject.Properties.Name -contains 'closureFields') -and $Config.manageEngine.closureFields) {
        $cf = $Config.manageEngine.closureFields
        if (($cf.PSObject.Properties.Name -contains 'udfFields') -and $cf.udfFields) {
            $udfFields = [ordered]@{}
            $cf.udfFields.PSObject.Properties | ForEach-Object {
                if ($_.Name -notlike '_*') { $udfFields[[string]$_.Name] = [string]$_.Value }
            }
        }
        if (($cf.PSObject.Properties.Name -contains 'resolutionContent') -and $cf.resolutionContent) {
            $resolutionContent = [string]$cf.resolutionContent
        }
    }

    return [pscustomobject]@{
        UdfFields         = $udfFields
        ResolutionContent = $resolutionContent
    }
}

function Send-ManageEngineProcessNote {
    <#
    .SYNOPSIS
      Posts a requester-visible process outcome note to ManageEngine.
      On this SDP on-prem instance, show_to_requester=true triggers the
      "Note has been added" email to the requester (notification rules).
      notify_requester is NOT a valid note field here (EXTRA_KEY 4001).
    .PARAMETER Config
      The API/poller config object. Reads Config.manageEngine.baseUrl / apiKey and
      Config.subscriptionLabels -- see MeAccessFields.ps1 for why this is a parameter
      rather than a script-scope $config.
    #>
    param(
        [Parameter(Mandatory)][string]$MeTicketId,
        [Parameter(Mandatory)]$TicketInput,
        [Parameter(Mandatory)]$Decision,
        $Execution = $null,
        [Parameter(Mandatory)][object]$Config
    )
    if (-not $Config.manageEngine.baseUrl -or -not $Config.manageEngine.apiKey) {
        return @{ error = 'ManageEngine not configured' }
    }

    $meBase = $Config.manageEngine.baseUrl.TrimEnd('/')
    $subLabel = [string]$TicketInput.SubscriptionId
    if ($Config.subscriptionLabels -and $Config.subscriptionLabels.$($TicketInput.SubscriptionId)) {
        $subLabel = "$($Config.subscriptionLabels.$($TicketInput.SubscriptionId)) ($($TicketInput.SubscriptionId))"
    }
    $noteKind = Get-ManageEngineNoteKind -Decision $Decision -Execution $Execution
    $assignType = $noteKind.AssignmentType
    $isEligible = ($noteKind.Kind -eq 'Eligible')
    $isRevoke = ($noteKind.Kind -eq 'Revoke')
    $isFailed = ($noteKind.Kind -eq 'Failed')

    if ($isRevoke) {
        $noteLines = @(
            "<b>AzureSentry access revoked</b>"
            "Your previously granted access has been revoked."
            ""
            "Role: $($TicketInput.Role)"
            "Environment: $($TicketInput.Environment)"
            "Subscription: $subLabel"
        )
        if ($Execution -and $Execution.AssignmentId) {
            $noteLines += "Previous assignment ID: $($Execution.AssignmentId)"
        }
        elseif ($Execution -and $Execution.GroupName) {
            $noteLines += "Removed from Entra RBAC group: $($Execution.GroupName)"
        }
        if ($TicketInput.Justification) {
            $noteLines += "Reason: $($TicketInput.Justification)"
        }
        elseif ($Decision.Reason) {
            $noteLines += "Reason: $($Decision.Reason)"
        }
        $noteLines += ""
        $noteLines += "<b>What this means:</b> you no longer have this Azure role on the subscription. If you still need access, raise a new help-desk request."
    }
    elseif ($isFailed) {
        # Honest, not reassuring: this must never imply access was granted. It states
        # what was requested, that automated provisioning did not complete, and that a
        # human will follow up -- see docs/ticket-poller-runbook.md.
        $noteLines = @(
            "<b>AzureSentry access request received</b>"
            "Your access request could not be automatically provisioned."
            ""
            "Role: $($TicketInput.Role)"
            "Environment: $($TicketInput.Environment)"
            "Subscription: $subLabel"
        )
        if ($TicketInput.DurationDays) { $noteLines += "Duration requested: $($TicketInput.DurationDays) day(s)" }
        $noteLines += ""
        $noteLines += "<b>What this means:</b> automated provisioning did not complete. No Azure access has been granted. A human will verify this request and follow up; this ticket has not been closed."
        if ($Execution -and $Execution.Error) {
            $noteLines += ""
            $noteLines += "Details for the reviewer: $($Execution.Error)"
        }
    }
    else {
        $noteLines = @(
            "<b>AzureSentry access update</b>"
            "Your access request has been processed."
            ""
            "Decision: $($Decision.Action) ($($Decision.Path))"
            "Role: $($TicketInput.Role)"
            "Environment: $($TicketInput.Environment)$(if ($Decision.EnvironmentOverridden) { ' (escalated from ticket claim)' } else { '' })"
            "Subscription: $subLabel"
        )
        if ($noteKind.Kind -ne 'GroupMembership') {
            $noteLines += "Duration: $($TicketInput.DurationDays) day(s)"
        }
        if ($Execution -and $Execution.Success) {
            if ($assignType) { $noteLines += "Assignment type: $assignType" }
            if ($Execution.ExpiresAt) { $noteLines += "Expires: $($Execution.ExpiresAt)" }
            if ($Execution.AssignmentId) { $noteLines += "Assignment ID: $($Execution.AssignmentId)" }
            if ($Execution.GroupName) { $noteLines += "Entra RBAC group: $($Execution.GroupName)" }
        }
        if ($isEligible) {
            $noteLines += ""
            $noteLines += "<b>Next step for you:</b> this is <i>eligible</i> access (not standing). In the Azure portal open <b>Privileged Identity Management</b> - activate <b>$($TicketInput.Role)</b> on this subscription when you need it. Activation may require approval and MFA."
        }
        elseif ($noteKind.Kind -eq 'GroupMembership') {
            $noteLines += ""
            $groupNote = if ($Execution -and $Execution.GroupName) { " to the group <b>$($Execution.GroupName)</b>" } else { '' }
            if ($Execution -and $Execution.GroupCreated) {
                $noteLines += "<b>Next step for you:</b> AzureSentry created the Entra group <b>$($Execution.GroupName)</b>, assigned it the role on the subscription, and added you. Membership is permanent and does <u>not</u> expire automatically. To remove it, request a revoke on this ticket."
            }
            elseif ($Execution -and $Execution.GroupAlreadyExisted) {
                $noteLines += "<b>Next step for you:</b> the Entra group <b>$($Execution.GroupName)</b> already existed; you were added to it (or were already a member). Membership is permanent and does <u>not</u> expire automatically. To remove it, request a revoke on this ticket."
            }
            else {
                $noteLines += "<b>Next step for you:</b> access is granted via permanent Entra group membership$groupNote. This does <u>not</u> expire automatically. To remove it, request a revoke on this ticket."
            }
        }
        elseif ($Decision.Action -eq 'Grant' -or $Decision.Action -eq 'BreakGlass') {
            $noteLines += ""
            $noteLines += "<b>Next step for you:</b> access is active and time-bound. It will expire automatically; no standing access remains after expiry."
        }
        if ($Decision.SlaHours) { $noteLines += "SLA window: $($Decision.SlaHours)h" }
        if ($Execution -and $Execution.EngineerActionRequired) {
            $noteLines += ""
            $noteLines += "Access granted via PIM fallback. Engineer action required: verify/create Entra group and subscription IAM role assignment. $($Execution.EngineerActionReason)"
        }
    }

    $description = ($noteLines -join '<br/>')
    $headers = @{ 'authtoken' = $Config.manageEngine.apiKey; 'Content-Type' = 'application/x-www-form-urlencoded' }
    $meNoteUrl = "$meBase/api/v3/requests/$MeTicketId/notes"

    try {
        # Official SDP OP note fields: description, show_to_requester, notify_technician,
        # mark_first_response, add_to_linked_requests. Requester email is driven by
        # Admin > Notification Rules when show_to_requester is true.
        $notePayload = @{
            note = @{
                description       = $description
                show_to_requester = $true
                notify_technician = $true
            }
        }
        $noteJson = $notePayload | ConvertTo-Json -Depth 5 -Compress
        $raw = Invoke-RestMethod -Uri $meNoteUrl -Method Post `
            -Body "input_data=$([System.Uri]::EscapeDataString($noteJson))" `
            -Headers $headers -ErrorAction Stop
        return @{
            raw              = $raw
            showToRequester  = $true
            notifyTechnician = $true
            # Email to requester is via ME notification rules on public notes (verified on #3679)
            notifyRequester  = $true
        }
    }
    catch {
        $errText = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $errText = $_.ErrorDetails.Message }
        return @{ error = $errText }
    }
}

function Set-ManageEngineTicketResolved {
    <#
    .SYNOPSIS
      Marks a ManageEngine request Resolved after a successful unattended grant.
    .DESCRIPTION
      There is no existing resolve/close function anywhere in the repo (the
      src/Runbooks/Runbook-Status-Updater.ps1 Logic App runbook only sets a bare
      status.name and is not config-driven the same way); this is the first one. Uses
      the same v3 REST conventions as Send-ManageEngineProcessNote (form-urlencoded
      input_data, authtoken header) rather than the runbook's shape, so both write paths
      in this file behave identically against the same ME instance.

      The udf/resolution fields written are entirely config-driven (Get-ManageEngineClosureFields)
      because they were discovered by hand against one real ticket and are unverified --
      a wrong key must be fixable in config.json, never a code change. Never throws: a
      failed resolve is bookkeeping, not a reason to fail the caller's grant cycle.
    .PARAMETER Config
      The API/poller config object. Reads Config.manageEngine.baseUrl / apiKey and
      Config.manageEngine.closureFields (via Get-ManageEngineClosureFields).
    #>
    param(
        [Parameter(Mandatory)][string]$MeTicketId,
        [Parameter(Mandatory)][object]$Config,
        [string]$Status = 'Resolved'
    )
    if (-not $Config.manageEngine.baseUrl -or -not $Config.manageEngine.apiKey) {
        return @{ error = 'ManageEngine not configured' }
    }

    $meBase = $Config.manageEngine.baseUrl.TrimEnd('/')
    $closure = Get-ManageEngineClosureFields -Config $Config

    $requestBody = [ordered]@{
        status     = @{ name = $Status }
        resolution = @{ content = $closure.ResolutionContent }
    }
    if ($closure.UdfFields -and $closure.UdfFields.Count -gt 0) {
        $udf = @{}
        foreach ($k in $closure.UdfFields.Keys) { $udf[$k] = $closure.UdfFields[$k] }
        $requestBody.udf_fields = $udf
    }

    $payload = @{ request = $requestBody } | ConvertTo-Json -Depth 6 -Compress
    $headers = @{ 'authtoken' = $Config.manageEngine.apiKey; 'Content-Type' = 'application/x-www-form-urlencoded' }
    $meUrl = "$meBase/api/v3/requests/$MeTicketId"

    try {
        $raw = Invoke-RestMethod -Uri $meUrl -Method Put `
            -Body "input_data=$([System.Uri]::EscapeDataString($payload))" `
            -Headers $headers -ErrorAction Stop
        return @{ success = $true; raw = $raw }
    }
    catch {
        $errText = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $errText = $_.ErrorDetails.Message }
        return @{ success = $false; error = $errText }
    }
}
