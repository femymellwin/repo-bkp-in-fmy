<#
.SYNOPSIS
    The single implementation of "revoke this processed-ticket record's grant".

.DESCRIPTION
    Extracted from Start-DashboardApi.ps1's /api/manageengine/revoke route so the reaper
    agent (src/Agents/ReaperAgent.ps1, invoked by scripts/Invoke-ReaperCycle.ps1) can
    revoke expired grants without a second, potentially-diverging implementation of what
    "revoke" means. Start-DashboardApi.ps1 cannot be dot-sourced at all -- it starts an
    HttpListener at top level -- same reason ProcessedStore.ps1, MeAccessFields.ps1,
    AccessPromotion.ps1 and ManageEngineNotes.ps1 were already extracted this way.

    Depends on Test-GrantRevocable / Get-RevokeFulfilmentMode (DashboardHelpers.ps1)
    being dot-sourced into the caller's session already.

    Every Graph/ARM call is injected via -Context (same convention as
    TicketPollerAgent.ps1's -Context), so this has no live dependency on Azure and is
    unit-testable with fakes. Client construction (Real vs Mock) and its credentials are
    a caller concern, not this function's -- the caller builds the closures once and
    passes them in.
#>

function Invoke-GrantRevocationAction {
    <#
    .SYNOPSIS
      Revokes exactly what -Prior says this platform granted and recorded: an Entra
      group membership (Fulfilment = Group) or a PIM assignment (anything else).
    .PARAMETER Prior
      A processed-ticket store record (ConvertFrom-Json shape or hashtable).
    .PARAMETER Context
      Hashtable of injected scriptblocks:
        ResolveUpnToObjectId  ($Upn) -> objectId
        RemoveGroupMember     ($GroupId, $UserId) -> (Group mode only)
        GetRoleDefinitionId   ($RoleName) -> roleDefinitionId          (Assignment mode only)
        RemoveAssignment      ($AssignmentId, $Scope, $UserId, $RoleDefinitionId, $AssignmentType) -> (Assignment mode only)
    .OUTPUTS
      pscustomobject with Ok (bool), Mode ('Group'/'Assignment'/$null), Error (string or $null).
    .DESCRIPTION
      Deliberately re-checks Test-GrantRevocable itself rather than trusting the caller
      to have checked it: "never revoke a record this platform did not grant, and never
      revoke an already-revoked record" is a policy invariant, not merely a UI
      convenience, and must hold no matter which caller (dashboard route, reaper cycle)
      reaches this function.

      Persisting the updated record (revoked = true, revokedAt, ...), auditing, and any
      ManageEngine note are the CALLER's responsibility -- this function only performs
      the removal call and reports what happened, mirroring how TicketPollerAgent.ps1's
      ExecuteGrant hook is the one that persists, not the agent function itself.
    #>
    param(
        [Parameter(Mandatory)][object]$Prior,
        [Parameter(Mandatory)][hashtable]$Context
    )

    if (-not (Test-GrantRevocable -Prior $Prior)) {
        return [pscustomobject]@{
            Ok    = $false
            Mode  = $null
            Error = 'Record is not revocable: already revoked, or carries neither an assignmentId nor a Group fulfilment with a stored groupId.'
        }
    }

    $mode = Get-RevokeFulfilmentMode -Prior $Prior
    try {
        $userId = & $Context.ResolveUpnToObjectId ([string]$Prior.requesterUpn)

        if ($mode -eq 'Group') {
            & $Context.RemoveGroupMember ([string]$Prior.groupId) $userId
        }
        else {
            # Matches the exact heuristic Start-DashboardApi.ps1's revoke route used
            # before this extraction: prefer the stored assignmentType, fall back to
            # sniffing the assignment id's own shape when that field is absent (older
            # records, or ones written before assignmentType was tracked).
            $assignType = if (
                [string]$Prior.assignmentType -eq 'Eligible' -or
                [string]$Prior.assignmentId -match 'roleEligibilitySchedule'
            ) {
                'Eligible'
            }
            else {
                'Active'
            }
            $roleDefId = & $Context.GetRoleDefinitionId ([string]$Prior.role)
            $scope = "/subscriptions/$($Prior.subscriptionId)"
            & $Context.RemoveAssignment ([string]$Prior.assignmentId) $scope $userId $roleDefId $assignType
        }

        return [pscustomobject]@{ Ok = $true; Mode = $mode; Error = $null }
    }
    catch {
        return [pscustomobject]@{ Ok = $false; Mode = $mode; Error = $_.Exception.Message }
    }
}
