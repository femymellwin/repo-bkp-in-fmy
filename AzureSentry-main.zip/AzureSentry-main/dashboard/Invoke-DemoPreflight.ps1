<#
.SYNOPSIS
    Pre-demo readiness check for the AzureSentry dashboard live demonstration.
    Read-only: verifies the Azure session, eligible PIM roles, API/UI health, and
    the decision-gate — it does NOT activate anything (that is the live demo moment).

.DESCRIPTION
    Run this ~10 minutes before the demo. It will:
      1. Confirm the Azure CLI session and target subscription.
      2. Confirm you have an eligible PIM role to activate (real data).
      3. Start the dashboard API + Vite dev server if they are not already running.
      4. Health-check both, and run a decision-gate sanity test (a Reject case that
         makes NO Azure call).
    A green summary means you are ready to demo.

.PARAMETER Subscription
    Expected subscription ID (defaults to inception-internal-product).

.PARAMETER StartServers
    Start the API and Vite dev server if they are not running (default: $true).
#>
[CmdletBinding()]
param(
    [string]$Subscription = '5a23842e-609d-42d4-bae5-e48e00e5b28d',
    [bool]$StartServers = $true
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent
$apiScript = Join-Path $PSScriptRoot 'api\Start-DashboardApi.ps1'
$webRoot = Join-Path $PSScriptRoot 'web'
$apiBase = 'http://127.0.0.1:8787'
$uiUrl = 'http://localhost:5173'

$results = [System.Collections.ArrayList]@()
function Add-Check { param([string]$Name, [bool]$Ok, [string]$Detail)
    [void]$results.Add([PSCustomObject]@{ Check = $Name; Ok = $Ok; Detail = $Detail })
    $tag = if ($Ok) { '[ OK ]' } else { '[FAIL]' }
    $color = if ($Ok) { 'Green' } else { 'Red' }
    Write-Host ("{0} {1} - {2}" -f $tag, $Name, $Detail) -ForegroundColor $color
}

Write-Host "`n=== AzureSentry Demo Preflight ===`n" -ForegroundColor Cyan

# 1. Azure CLI session ------------------------------------------------------
try {
    $acct = az account show -o json 2>$null | ConvertFrom-Json
    if (-not $acct) { Add-Check 'Azure CLI session' $false 'Not logged in. Run: az login' }
    elseif ($acct.id -ne $Subscription) {
        Add-Check 'Azure CLI session' $false "On wrong sub ($($acct.name)). Run: az account set --subscription $Subscription"
    }
    else { Add-Check 'Azure CLI session' $true "$($acct.user.name) on $($acct.name)" }
}
catch { Add-Check 'Azure CLI session' $false $_.Exception.Message }

# 2. Eligible PIM role (real data) -----------------------------------------
try {
    $token = az account get-access-token --resource https://management.azure.com --query accessToken -o tsv
    $h = @{ Authorization = "Bearer $token" }
    $uri = "https://management.azure.com/subscriptions/$Subscription/providers/Microsoft.Authorization/roleEligibilityScheduleInstances?api-version=2020-10-01&`$filter=asTarget()"
    $el = Invoke-RestMethod -Uri $uri -Headers $h -Method Get
    $roles = @($el.value | ForEach-Object { $_.properties.expandedProperties.roleDefinition.displayName })
    if ($roles.Count -gt 0) { Add-Check 'Eligible PIM role' $true ("Can activate: " + ($roles -join ', ')) }
    else { Add-Check 'Eligible PIM role' $false 'No eligible roles found (already active? check Live PIM table)' }
}
catch { Add-Check 'Eligible PIM role' $false $_.Exception.Message }

# 3. API server -------------------------------------------------------------
function Test-Api { try { (Invoke-RestMethod -Uri "$apiBase/api/health" -TimeoutSec 2).status -eq 'ok' } catch { $false } }
if (-not (Test-Api) -and $StartServers) {
    Write-Host 'Starting dashboard API...' -ForegroundColor DarkGray
    Start-Process powershell.exe -ArgumentList @('-NoProfile', '-File', $apiScript) -WindowStyle Minimized | Out-Null
    $deadline = (Get-Date).AddSeconds(20)
    while ((Get-Date) -lt $deadline -and -not (Test-Api)) { Start-Sleep -Milliseconds 500 }
}
Add-Check 'Dashboard API' (Test-Api) "$apiBase"

# 4. Vite UI ----------------------------------------------------------------
function Test-Ui { try { (Invoke-WebRequest -Uri $uiUrl -TimeoutSec 2 -UseBasicParsing).StatusCode -eq 200 } catch { $false } }
if (-not (Test-Ui) -and $StartServers) {
    Write-Host 'Starting Vite dev server...' -ForegroundColor DarkGray
    Start-Process powershell.exe -ArgumentList @('-NoProfile', '-Command', "cd `"$webRoot`"; npm run dev:vite") -WindowStyle Minimized | Out-Null
    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline -and -not (Test-Ui)) { Start-Sleep -Milliseconds 500 }
}
Add-Check 'Dashboard UI' (Test-Ui) "$uiUrl"

# 5. Live PIM status endpoint ----------------------------------------------
try {
    $st = Invoke-RestMethod -Uri "$apiBase/api/pim/status" -TimeoutSec 10
    Add-Check 'Live PIM status' ([bool]$st.loggedIn -and [bool]$st.onExpectedSubscription) "loggedIn=$($st.loggedIn) onExpectedSub=$($st.onExpectedSubscription)"
}
catch { Add-Check 'Live PIM status' $false $_.Exception.Message }

# 6. Decision-gate sanity (NO Azure call — short justification must be blocked)
try {
    $body = @{ Role = 'Contributor'; Environment = 'Production'; Priority = 'P2'; DurationHours = 1; Justification = 'too short' } | ConvertTo-Json
    $r = Invoke-RestMethod -Uri "$apiBase/api/pim/activate" -Method POST -Body $body -ContentType 'application/json' -TimeoutSec 15
    Add-Check 'Decision gate' ([bool]$r.blocked -and -not $r.activated) "blocked=$($r.blocked) action=$($r.decision.Action) (correctly refused, no PIM call)"
}
catch { Add-Check 'Decision gate' $false $_.Exception.Message }

# Summary -------------------------------------------------------------------
$fail = @($results | Where-Object { -not $_.Ok }).Count
Write-Host ""
if ($fail -eq 0) {
    Write-Host "READY FOR DEMO - open $uiUrl and go to 'Live PIM (Azure)'." -ForegroundColor Green
}
else {
    Write-Host "$fail check(s) failed - resolve the red items above before demoing." -ForegroundColor Red
}
Write-Host ""
