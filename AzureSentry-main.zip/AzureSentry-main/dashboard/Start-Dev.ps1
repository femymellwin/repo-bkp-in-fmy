<#
.SYNOPSIS
    Starts the PowerShell API, waits until healthy, then launches the Vite dev server.
#>
[CmdletBinding()]
param(
    [int]$Port = 8787
)

$ErrorActionPreference = 'Stop'
$dashboardRoot = $PSScriptRoot
$apiScript = Join-Path $dashboardRoot 'api\Start-DashboardApi.ps1'
$webRoot = Join-Path $dashboardRoot 'web'
$healthUrl = "http://127.0.0.1:$Port/api/health"

function Test-ApiHealth {
    try {
        $r = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2
        return ($r.status -eq 'ok')
    }
    catch { return $false }
}

if (-not (Test-ApiHealth)) {
    Write-Host 'Starting AzureSentry Dashboard API...' -ForegroundColor Cyan
    $apiArgs = if ($Port -ne 8787) { @('-NoProfile', '-File', $apiScript, '-Port', $Port) } else { @('-NoProfile', '-File', $apiScript) }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $apiArgs -WindowStyle Normal | Out-Null

    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline) {
        if (Test-ApiHealth) {
            Write-Host "API ready at $healthUrl" -ForegroundColor Green
            break
        }
        Start-Sleep -Milliseconds 500
    }

    if (-not (Test-ApiHealth)) {
        Write-Error "API did not become ready at $healthUrl. Start it manually: cd dashboard\api; .\Start-DashboardApi.ps1"
        exit 1
    }
}
else {
    Write-Host "API already running at $healthUrl" -ForegroundColor Green
}

Write-Host 'Starting Vite dev server (http://localhost:5173)...' -ForegroundColor Cyan
Push-Location $webRoot
try {
    if (-not (Test-Path 'node_modules')) {
        npm install
    }
    npm run dev:vite
}
finally {
    Pop-Location
}
