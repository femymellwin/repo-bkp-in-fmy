import assert from 'node:assert/strict'
import test from 'node:test'

import { resolveTicketRole } from '../src/resolveTicketRole.ts'

test('leaves Role empty when the ticket does not supply one', () => {
  const result = resolveTicketRole('Need access on subscription efae0e0e-09ab-4c17-82db-d2d1f4382d66')

  assert.equal(result.role, '')
  assert.match(result.warning ?? '', /required/i)
})

test('detects Contributor and Reader when present', () => {
  assert.equal(resolveTicketRole('please grant Contributor access').role, 'Contributor')
  assert.equal(resolveTicketRole('reader on sandbox').role, 'Reader')
  assert.equal(resolveTicketRole('User Access Administrator please').role, 'UAA')
})

test('does not treat bare "read" as Reader', () => {
  assert.equal(resolveTicketRole('please read the runbook before requesting').role, '')
})
