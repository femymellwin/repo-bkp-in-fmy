import assert from 'node:assert/strict'
import test from 'node:test'

import { buildTemplatePayload } from '../src/buildTemplatePayload.ts'

test('builds Networking fields from labeled UDFs', () => {
  const payload = buildTemplatePayload({
    id: 1,
    subject: 'Open firewall',
    description: 'Need access',
    status: { name: 'Open' },
    category: { name: 'Azure' },
    subcategory: { name: 'Networking' },
    requester: { name: 'Ada', email_id: 'ada@example.com' },
    template: { name: 'Networking' },
    udf_fields: {
      a: { label: 'Source IP', name: '10.1.1.1' },
      b: { label: 'Destination IP', name: '10.2.2.2' },
      c: { label: 'Port', name: '443' },
      d: { label: 'Protocol (TPC/UDP)', name: 'TCP' },
    },
  })
  assert.equal(payload.knownSchema, true)
  assert.equal(payload.handler, 'pending')
  assert.equal(payload.fields['Source IP'], '10.1.1.1')
  assert.equal(payload.fields['Protocol (TCP/UDP)'], 'TCP')
  assert.equal(payload.common.subject, 'Open firewall')
  assert.ok(!('Category' in payload.fields))
})

test('unknown template warns and has empty fieldOrder', () => {
  const payload = buildTemplatePayload({
    id: 2,
    subject: 'x',
    template: { name: 'Mystery' },
    udf_fields: { a: { label: 'Item', name: 'secret' } },
  })
  assert.equal(payload.knownSchema, false)
  assert.equal(payload.handler, 'none')
  assert.deepEqual(payload.fieldOrder, [])
  assert.ok(payload.warnings.some((w) => /unknown template schema/i.test(w)))
  assert.ok(!payload.fields.Item)
})

test('Azure Subscription prefers accessFields override', () => {
  const payload = buildTemplatePayload(
    {
      id: 3,
      subject: 'Access',
      template: { name: 'Azure Subscription' },
      udf_fields: {},
    },
    { Subscription: 'sub-a', AzureRole: 'Reader', Environment: 'Sandbox' },
  )
  assert.equal(payload.handler, 'azure-subscription-grant')
  assert.equal(payload.fields.Subscription, 'sub-a')
  assert.equal(payload.fields['Azure Role'], 'Reader')
  assert.equal(payload.fields.Environment, 'Sandbox')
})

test('GitHub Enterprise fills Environment/Exception from keyed UDFs and Item/Request Type from ticket', () => {
  const payload = buildTemplatePayload({
    id: 4855,
    subject: 'GitHub access',
    template: { name: 'GitHub Enterprise' },
    item: { name: 'New Request', id: '2113' },
    request_type: { name: 'Service', id: '301' },
    udf_fields: {
      udf_pick_3719: { name: 'Test', id: '1504' },
      udf_pick_3014: { name: 'No', id: '923' },
    },
  })
  assert.equal(payload.handler, 'pending')
  assert.equal(payload.fields.Environment, 'Test')
  assert.equal(payload.fields['Exception Request'], 'No')
  assert.equal(payload.fields.Item, 'New Request')
  assert.equal(payload.fields['Request Type'], 'Service')
})

test('Cortex leaves Exception Request empty when template has no such field', () => {
  const payload = buildTemplatePayload({
    id: 4846,
    subject: 'AppReg',
    template: { name: 'Cortex' },
    item: { name: 'Create app registeration/enterprise application' },
    request_type: { name: 'Service' },
    udf_fields: {
      udf_pick_3719: { name: 'Development', id: '1503' },
    },
  })
  assert.equal(payload.fields.Environment, 'Development')
  assert.equal(payload.fields.Item, 'Create app registeration/enterprise application')
  assert.equal(payload.fields['Request Type'], 'Service')
  assert.ok(!('Exception Request' in payload.fields))
})

test('ADO fills schema fields; empty values stay empty for Missing UI', () => {
  const payload = buildTemplatePayload({
    id: 4763,
    subject: 'ADO access',
    template: { name: 'ADO' },
    item: { name: 'New Request' },
    request_type: { name: 'Service' },
    udf_fields: {
      udf_pick_3719: { name: 'Development' },
      udf_pick_3014: { name: 'No' },
    },
  })
  assert.equal(payload.fields.Environment, 'Development')
  assert.equal(payload.fields['Exception Request'], 'No')
  assert.equal(payload.fields.Item, 'New Request')
  assert.equal(payload.fields['Request Type'], 'Service')
})

test('General Access fills Business Justification from udf_mline_901', () => {
  const payload = buildTemplatePayload({
    id: 4857,
    subject: 'Provide access to Cortex admin ui for UAT environment',
    template: { name: 'General Access' },
    item: { name: 'Modify / Change Access Role or Permission' },
    udf_fields: {
      udf_mline_901: 'Provide access to Cortex admin ui for UAT environment',
    },
  })
  assert.equal(
    payload.fields['Business Justification'],
    'Provide access to Cortex admin ui for UAT environment',
  )
  assert.equal(payload.fields.Item, 'Modify / Change Access Role or Permission')
})
