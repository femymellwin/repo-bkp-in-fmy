import assert from 'node:assert/strict'
import test from 'node:test'

import {
  extractMeAccessFields,
  findMeCatalogSubscriptionName,
  mapMeAzureRole,
  mapMeEnvironment,
  ticketUsesMeCatalogSubscription,
} from '../src/extractMeAccessFields.ts'
import {
  allowlistDisplayNames,
  buildAllowlistSelectOptions,
  resolveTicketSubscription,
} from '../src/resolveSubscriptionId.ts'
import { resolveTicketEnvironment } from '../src/resolveTicketEnvironment.ts'
import { resolveTicketRole } from '../src/resolveTicketRole.ts'

const liveCatalog = [
  { id: '1251f2d0-787f-4063-8b74-178ad167c682', label: 'ceo-sub-application' },
  { id: '5a23842e-609d-42d4-bae5-e48e00e5b28d', label: 'inception-internal-product' },
  { id: '1f0eb417-e64c-4f97-9b12-261157d44b6d', label: 'shared-applications (live)' },
]

test('extracts Subscription, Azure Role, Environment from ME UDFs', () => {
  const fields = extractMeAccessFields({
    udf_pick_3728: { name: 'ceo-sub-application', id: '3021' },
    udf_pick_3729: { name: 'Contributor', id: '3119' },
    udf_pick_3719: { name: 'Development', id: '3201' },
  })
  assert.equal(fields.subscription, 'ceo-sub-application')
  assert.equal(fields.azureRole, 'Contributor')
  assert.equal(fields.environment, 'Development')
})

test('extracts ME pick values from value/display_value shapes', () => {
  const fields = extractMeAccessFields({
    udf_pick_3728: { value: 'inception-ai-Sandbox' },
    udf_pick_3729: { display_value: 'User Access Administrator' },
    udf_pick_3719: { name: 'Sandbox' },
  })
  assert.equal(fields.subscription, 'inception-ai-Sandbox')
  assert.equal(fields.azureRole, 'User Access Administrator')
  assert.equal(fields.environment, 'Sandbox')
})

test('does not read legacy Environments Required (udf_sline_3715)', () => {
  const fields = extractMeAccessFields({
    udf_pick_3728: { name: 'ceo-sub-application' },
    udf_pick_3729: { name: 'Contributor' },
    udf_sline_3715: 'sandbox',
  })
  assert.equal(fields.environment, '')
})

test('maps ME Environment Development/Test to NonProd', () => {
  assert.equal(mapMeEnvironment('Development').environment, 'NonProd')
  assert.equal(mapMeEnvironment('Test').environment, 'NonProd')
  assert.equal(mapMeEnvironment('Sandbox').environment, 'Sandbox')
})

test('maps ME subscription type against live MG allowlist', () => {
  const r = resolveTicketSubscription({
    meSubscription: 'shared-applications',
    catalog: liveCatalog,
  })
  assert.equal(r.subscriptionId, '1f0eb417-e64c-4f97-9b12-261157d44b6d')
  assert.equal(r.source, 'udf')
})

test('unmapped ME subscription keeps allowlist error path', () => {
  const r = resolveTicketSubscription({
    meSubscription: 'incp-dataeng-dev',
    catalog: liveCatalog,
  })
  assert.equal(r.subscriptionType, 'incp-dataeng-dev')
  assert.equal(r.subscriptionId, '')
})

test('dropdown options are live allowlist name + GUID', () => {
  const opts = buildAllowlistSelectOptions(liveCatalog)
  assert.equal(opts.length, 3)
  assert.ok(opts.every((o) => /^[0-9a-f-]{36}$/i.test(o.value)))
  assert.ok(opts.some((o) => o.label.includes('ceo-sub-application') && o.label.includes('1251f2d0')))
  assert.deepEqual(allowlistDisplayNames(liveCatalog).sort(), [
    'ceo-sub-application',
    'inception-internal-product',
    'shared-applications',
  ].sort())
})

test('finds allowlist name in secondary UDF; ignores generic github subject', () => {
  assert.equal(
    findMeCatalogSubscriptionName({
      preferredSubscription: '',
      udf: { udf_sline_2105: 'ceo-sub-application' },
      catalogNames: allowlistDisplayNames(liveCatalog),
    }),
    'ceo-sub-application',
  )
  assert.equal(
    findMeCatalogSubscriptionName({
      preferredSubscription: '',
      haystackText: 'Access to GitHub repositories',
      catalogNames: ['github', 'ceo-sub-application'],
    }),
    '',
  )
})

test('maps ME Environment picks accurately (non-prod before prod)', () => {
  assert.equal(mapMeEnvironment('dev').environment, 'NonProd')
  assert.equal(mapMeEnvironment('non-prod').environment, 'NonProd')
  assert.equal(mapMeEnvironment('non prod').environment, 'NonProd')
  assert.equal(mapMeEnvironment('NonProd').environment, 'NonProd')
  assert.equal(mapMeEnvironment('production').environment, 'Production')
  assert.equal(mapMeEnvironment('prod').environment, 'Production')
  assert.equal(mapMeEnvironment('sandbox').environment, 'Sandbox')
  assert.equal(mapMeEnvironment('staging').environment, 'NonProd')
  assert.equal(mapMeEnvironment('something-else').environment, '')
})

test('maps Azure Role from ME pick to platform role', () => {
  assert.equal(mapMeAzureRole('Contributor').role, 'Contributor')
  assert.equal(mapMeAzureRole('User Access Administrator').role, 'UAA')
  assert.equal(mapMeAzureRole('UAA').role, 'UAA')
  assert.equal(mapMeAzureRole('Writer').role, 'Writer')
  assert.equal(mapMeAzureRole('Reader').role, 'Reader')
  assert.equal(mapMeAzureRole('AKS Cluster Admin').role, 'AKS Cluster Admin')
})

test('free-text env/role resolvers stay accurate', () => {
  assert.equal(resolveTicketEnvironment('need access on non-prod').environment, 'NonProd')
  assert.equal(resolveTicketEnvironment('prod access please').environment, 'Production')
  assert.equal(resolveTicketEnvironment('sandbox contributor').environment, 'Sandbox')
  assert.equal(resolveTicketRole('please grant Contributor access').role, 'Contributor')
  assert.equal(resolveTicketRole('reader on sandbox').role, 'Reader')
  assert.equal(resolveTicketRole('please read the runbook').role, '')
})

test('ticketUsesMeCatalogSubscription is true from 2026-08-06', () => {
  assert.equal(
    ticketUsesMeCatalogSubscription({ value: String(Date.parse('2026-08-06T10:00:00')) }),
    true,
  )
  assert.equal(
    ticketUsesMeCatalogSubscription({ value: String(Date.parse('2026-08-04T10:00:00')) }),
    false,
  )
})
