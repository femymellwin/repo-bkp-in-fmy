import assert from 'node:assert/strict'
import test from 'node:test'

import { resolveTicketEnvironment } from '../src/resolveTicketEnvironment.ts'

test('leaves Environment empty when the ticket does not supply one', () => {
  const result = resolveTicketEnvironment('Need Contributor on subscription efae0e0e-09ab-4c17-82db-d2d1f4382d66')

  assert.equal(result.environment, '')
  assert.match(result.warning ?? '', /not supplied/i)
})

test('still detects Production, NonProd, and Sandbox when present', () => {
  assert.equal(resolveTicketEnvironment('prod access please').environment, 'Production')
  assert.equal(resolveTicketEnvironment('non-prod access').environment, 'NonProd')
  assert.equal(resolveTicketEnvironment('sandbox contributor').environment, 'Sandbox')
})
