import assert from 'node:assert/strict'
import test from 'node:test'

import {
  lookupTemplateSchema,
  normalizeTemplateName,
} from '../src/ticketTemplateSchemas.ts'

test('normalizes trailing Template suffix', () => {
  assert.equal(normalizeTemplateName('Report and Issue Template'), 'Report and Issue')
  assert.equal(normalizeTemplateName('  Azure Subscription  '), 'Azure Subscription')
})

test('Azure Subscription schema has grant handler and expected fields', () => {
  const s = lookupTemplateSchema('Azure Subscription')
  assert.ok(s)
  assert.equal(s.handler, 'azure-subscription-grant')
  assert.deepEqual(s.fields, [
    'Subscription',
    'Azure Role',
    'Environment',
  ])
})

test('Networking schema is pending with network fields', () => {
  const s = lookupTemplateSchema('Networking')
  assert.ok(s)
  assert.equal(s.handler, 'pending')
  assert.ok(s.fields.includes('Source IP'))
  assert.ok(s.fields.includes('Protocol (TCP/UDP)'))
})

test('alias Security Assesment → Security Assessment', () => {
  const s = lookupTemplateSchema('Security Assesment')
  assert.ok(s)
  assert.equal(s.canonicalName, 'Security Assessment')
})

test('unknown name returns null', () => {
  assert.equal(lookupTemplateSchema('Unspecified'), null)
  assert.equal(lookupTemplateSchema('Totally Fake'), null)
})
