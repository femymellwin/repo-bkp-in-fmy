import assert from 'node:assert/strict'
import test from 'node:test'

import { failedRevokeState, successfulRevokeState } from '../src/revokeUiState.ts'

test('creates a visible revoked state after successful revocation', () => {
  assert.deepEqual(successfulRevokeState(true), {
    phase: 'revoked',
    message: 'Access revoked and requester notified.',
  })
})

test('creates a visible failure state when revocation fails', () => {
  assert.deepEqual(failedRevokeState(new Error('ARM denied the request')), {
    phase: 'failed',
    message: 'ARM denied the request',
  })
})
