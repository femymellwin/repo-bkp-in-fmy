import assert from 'node:assert/strict'
import test from 'node:test'

import { ticketTypeLabel, UNSPECIFIED_TICKET_TYPE } from '../src/ticketTypeLabel.ts'

test('reads the ManageEngine template name', () => {
  assert.equal(ticketTypeLabel({ template: { name: 'Azure Subscription' } }), 'Azure Subscription')
  assert.equal(ticketTypeLabel({ template: { name: 'General Access' } }), 'General Access')
  assert.equal(ticketTypeLabel({ template: { name: 'ADO' } }), 'ADO')
  assert.equal(ticketTypeLabel({ template: { name: 'GitHub Enterprise' } }), 'GitHub Enterprise')
  assert.equal(ticketTypeLabel({ template: { name: 'Infrastructure' } }), 'Infrastructure')
})

test('accepts a string template and trims whitespace', () => {
  assert.equal(ticketTypeLabel({ template: '  Cursor  ' }), 'Cursor')
})

test('falls back when template is missing or blank', () => {
  assert.equal(ticketTypeLabel({}), UNSPECIFIED_TICKET_TYPE)
  assert.equal(ticketTypeLabel({ template: { name: '  ' } }), UNSPECIFIED_TICKET_TYPE)
  assert.equal(ticketTypeLabel(null), UNSPECIFIED_TICKET_TYPE)
  assert.equal(ticketTypeLabel(undefined), UNSPECIFIED_TICKET_TYPE)
})
