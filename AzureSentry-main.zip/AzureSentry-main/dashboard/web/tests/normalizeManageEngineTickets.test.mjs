import assert from 'node:assert/strict'
import test from 'node:test'

import { normalizeManageEngineTickets } from '../src/normalizeManageEngineTickets.ts'

test('normalizes ManageEngine string ticket IDs to numeric IDs', () => {
  const tickets = normalizeManageEngineTickets([{ id: '3806', subject: 'Contributor access' }])

  assert.equal(tickets[0].id, 3806)
})
