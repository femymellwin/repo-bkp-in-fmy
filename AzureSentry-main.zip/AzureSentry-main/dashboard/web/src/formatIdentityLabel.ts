/** Expand IDM / IDAM abbreviations for user-facing labels. */
export function formatIdentityLabel(name: string | null | undefined): string {
  if (!name) return ''
  const trimmed = name.trim()
  if (/^IDAM\s+Team$/i.test(trimmed)) return 'Identity and Access Management Team'
  if (/^IDAM$/i.test(trimmed)) return 'Identity and Access Management'
  if (/^IDM$/i.test(trimmed)) return 'Identity Management'
  return trimmed
    .replace(/\bIDAM\b/gi, 'Identity and Access Management')
    .replace(/\bIDM\b/gi, 'Identity Management')
}
