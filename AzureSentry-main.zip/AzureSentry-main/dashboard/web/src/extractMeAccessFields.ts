/** ManageEngine "Azure Subscription" template UDF keys (ServiceDesk Plus). */
export const ME_UDF_SUBSCRIPTION = 'udf_pick_3728'
export const ME_UDF_AZURE_ROLE = 'udf_pick_3729'
/** Shared "Environment" dropdown across Azure / GitHub / ADO / Cortex templates. */
export const ME_UDF_ENVIRONMENT = 'udf_pick_3719'
/** Shared "Exception Request" Yes/No pick (GitHub Enterprise, ADO, …). */
export const ME_UDF_EXCEPTION_REQUEST = 'udf_pick_3014'
/** Shared "Business Justification" multiline (General Access, Infrastructure, …). */
export const ME_UDF_BUSINESS_JUSTIFICATION = 'udf_mline_901'

/** Requesters select Subscription from the ME catalog starting this date (local). */
export const ME_CATALOG_SUBSCRIPTION_SINCE = '2026-08-06'

export interface MeAccessFields {
  /** Template "Subscription" dropdown value */
  subscription: string
  /** Template "Azure Role" dropdown value */
  azureRole: string
  /** Template "Environment" dropdown value */
  environment: string
}

function pickName(value: unknown): string {
  if (value == null) return ''
  if (typeof value === 'string' || typeof value === 'number') return String(value).trim()
  if (typeof value === 'object' && value !== null) {
    const obj = value as Record<string, unknown>
    for (const key of ['name', 'value', 'display_value', 'displayValue'] as const) {
      const n = obj[key]
      if (typeof n === 'string' && n.trim()) return n.trim()
      if (typeof n === 'number') return String(n).trim()
    }
  }
  return ''
}

function isUnspecified(value: string): boolean {
  const v = value.trim().toLowerCase()
  return !v || v === 'not specified' || v === 'n/a' || v === 'na' || v === '-' || v === 'none'
}

function collectUdfTextValues(udf: unknown): string[] {
  if (!udf || typeof udf !== 'object') return []
  const out: string[] = []
  for (const value of Object.values(udf as Record<string, unknown>)) {
    const name = pickName(value)
    if (name && !isUnspecified(name)) out.push(name)
  }
  return out
}

function normalizeLoose(s: string): string {
  return s.toLowerCase().replace(/[\s_\-]+/g, '')
}

/**
 * Find a live-allowlist subscription name inside ticket UDF / text (not a static MD list).
 * Prefer the dedicated Subscription UDF; otherwise scan other UDF values.
 * Free-text/subject is only used for distinctive names (hyphenated / long) to avoid
 * false hits like catalog "github" on GitHub Enterprise tickets.
 */
export function findMeCatalogSubscriptionName(args: {
  preferredSubscription?: string
  udf?: unknown
  haystackText?: string
  catalogNames: string[]
}): string {
  const preferred = (args.preferredSubscription ?? '').trim()
  if (preferred && !isUnspecified(preferred)) return preferred

  const names = [...args.catalogNames].sort((a, b) => b.length - a.length)
  const udfBlobs = collectUdfTextValues(args.udf)

  const matchIn = (blobs: string[], requireDistinctive: boolean): string => {
    for (const blob of blobs) {
      const blobNorm = blob.toLowerCase()
      const blobCompact = normalizeLoose(blob)
      for (const name of names) {
        const n = name.toLowerCase()
        const nc = normalizeLoose(name)
        if (n.length < 3) continue
        if (requireDistinctive) {
          const distinctive = n.includes('-') || n.includes('_') || n.includes(' ') || n.length >= 14
          if (!distinctive) continue
        }
        // Prefer exact field equality (Infrastructure template single-line sub names).
        if (blobNorm === n || normalizeLoose(blob) === nc) return name
        if (n.length >= 8 && (blobNorm.includes(n) || (nc.length >= 8 && blobCompact.includes(nc)))) {
          return name
        }
      }
    }
    return ''
  }

  const fromUdf = matchIn(udfBlobs, false)
  if (fromUdf) return fromUdf

  const hay = (args.haystackText ?? '').trim()
  if (hay) return matchIn([hay], true)
  return ''
}

/**
 * Extract Subscription, Azure Role, and Environment from ManageEngine udf_fields.
 * Uses the Azure Subscription service template field keys.
 */
export function extractMeAccessFields(udf: unknown): MeAccessFields {
  const empty: MeAccessFields = { subscription: '', azureRole: '', environment: '' }
  if (!udf || typeof udf !== 'object') return empty
  const fields = udf as Record<string, unknown>

  const subscription = pickName(fields[ME_UDF_SUBSCRIPTION])
  const azureRole = pickName(fields[ME_UDF_AZURE_ROLE])
  const environment = pickName(fields[ME_UDF_ENVIRONMENT])

  return {
    subscription: isUnspecified(subscription) ? '' : subscription,
    azureRole: isUnspecified(azureRole) ? '' : azureRole,
    environment: isUnspecified(environment) ? '' : environment,
  }
}

/** True when ticket created_time is on/after the ME catalog Subscription era. */
export function ticketUsesMeCatalogSubscription(createdTime?: {
  value?: string
  display_value?: string
}): boolean {
  const raw = createdTime?.value
  if (!raw) return true // unknown → assume current policy
  const ms = Number(raw)
  if (!Number.isFinite(ms) || ms <= 0) return true
  const created = new Date(ms)
  const since = new Date(`${ME_CATALOG_SUBSCRIPTION_SINCE}T00:00:00`)
  return created >= since
}

/**
 * Map ME "Environment" pick / text to decision-engine environment.
 * NonProd is checked before Production so "non-prod" / "non prod" are not misread as prod.
 */
export function mapMeEnvironment(raw: string): {
  environment: string
  warning?: string
} {
  const normalized = raw.toLowerCase().trim()
  if (!normalized) {
    return {
      environment: '',
      warning:
        'Environment was not supplied on the ManageEngine ticket (allowed). Classification may use the subscription sensitivity map.',
    }
  }
  if (/\bsandbox\b|\bsbx\b|\blab\b/.test(normalized)) {
    return { environment: 'Sandbox' }
  }
  if (
    /non[\s_-]?prod|\bstaging\b|\buat\b|\bqa\b|\bdev(?:elopment)?\b|\btest(?:ing)?\b|\bpre[\s_-]?prod|\btraining\b|\bshared\b|\bdr\b/.test(
      normalized,
    )
  ) {
    return { environment: 'NonProd' }
  }
  if (/\bproduction\b|\bprod\b/.test(normalized)) {
    return { environment: 'Production' }
  }
  return {
    environment: '',
    warning: `Environment "${raw}" did not map to Sandbox / NonProd / Production — select or confirm before granting.`,
  }
}

/**
 * Normalize ME Azure Role dropdown to platform role used by the decision engine.
 * Unknown / custom ME labels are kept as-is so the UI still reflects the request.
 */
export function mapMeAzureRole(raw: string): {
  role: string
  warning?: string
} {
  const v = raw.trim()
  if (!v) {
    return {
      role: '',
      warning:
        'Azure Role was not supplied on the ManageEngine ticket. Role is required — ask the requester to select it on the template.',
    }
  }
  const n = v.toLowerCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim()
  if (/user access admin|\buaa\b/.test(n)) return { role: 'UAA' }
  if (/\bowner\b/.test(n)) return { role: 'Owner' }
  if (/\bwriter\b|write access/.test(n)) return { role: 'Writer' }
  if (/\bcontrib/.test(n)) return { role: 'Contributor' }
  if (/\breader\b|\bread only\b|\bread-only\b/.test(n) || n === 'reader') {
    return { role: 'Reader' }
  }
  // Custom / AKS / other ME roles — keep the label so operators can see what was requested.
  return { role: v }
}
