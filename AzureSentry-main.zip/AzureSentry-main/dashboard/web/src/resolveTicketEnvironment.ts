/** Resolve Environment from ticket free text. Missing is allowed (empty string). */
export function resolveTicketEnvironment(text: string): {
  environment: string
  warning?: string
} {
  const normalized = text.toLowerCase()
  // Order matters: sandbox / non-prod before bare "prod".
  if (/\bsandbox\b|\bsbx\b|\blab\b/.test(normalized)) {
    return { environment: 'Sandbox' }
  }
  if (
    /non[\s_-]?prod|\bstaging\b|\buat\b|\bqa\b|\bdev(?:elopment)?\b|\bpre[\s_-]?prod/.test(
      normalized,
    )
  ) {
    return { environment: 'NonProd' }
  }
  if (/\bproduction\b|\bprod\b/.test(normalized)) {
    return { environment: 'Production' }
  }
  return {
    environment: '',
    warning:
      'Environment was not supplied in the ticket (allowed). Classification may use the subscription sensitivity map.',
  }
}
