import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { Fragment, type ReactNode } from 'react'

export function MetaList({ rows }: { rows: Array<[ReactNode, ReactNode]> }) {
  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: 'auto minmax(0, 1fr)',
        gap: '4px 16px',
        alignItems: 'baseline',
        fontSize: '0.85rem',
        minWidth: 0,
        maxWidth: '100%',
      }}
    >
      {rows.map(([k, v], i) => (
        <Fragment key={i}>
          <Typography variant="caption" color="text.secondary">{k}</Typography>
          <Typography
            variant="body2"
            component="div"
            sx={{ overflowWrap: 'anywhere', wordBreak: 'break-word', minWidth: 0 }}
          >
            {v}
          </Typography>
        </Fragment>
      ))}
    </Box>
  )
}
