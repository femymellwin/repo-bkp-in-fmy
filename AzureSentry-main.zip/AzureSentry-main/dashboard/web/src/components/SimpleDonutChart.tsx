import Box from '@mui/material/Box'
import Stack from '@mui/material/Stack'
import Typography from '@mui/material/Typography'
import { alpha, useTheme } from '@mui/material/styles'
import { PieChart } from '@mui/x-charts/PieChart'

export interface DonutDatum {
  label: string
  value: number
  /** Opaque id used for click-to-filter (e.g. raw department name). */
  id?: string
  color?: string
}

const valueFormatter = (item: { value: number }) => `${item.value.toFixed(1)}%`

/** Department/project share as a pie chart with percentage metrics. */
export function SimpleDonutChart({
  data,
  selectedId,
  onSelect,
  emptyLabel = 'No data yet',
}: {
  data: DonutDatum[]
  selectedId?: string | null
  onSelect?: (id: string | null) => void
  emptyLabel?: string
}) {
  const theme = useTheme()
  const palette = [
    theme.palette.primary.main,
    theme.palette.secondary.main,
    theme.palette.text.primary,
    theme.palette.divider,
    theme.palette.warning.main,
    theme.palette.error.main,
    '#91FF01',
    '#AE74FF',
  ]
  const total = data.reduce((n, d) => n + d.value, 0)

  if (total <= 0) {
    return (
      <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
        {emptyLabel}
      </Typography>
    )
  }

  const slices = data
    .filter((d) => d.value > 0)
    .map((d, i) => {
      const id = d.id ?? d.label
      return {
        id,
        label: d.label,
        count: d.value,
        percent: (d.value / total) * 100,
        color: d.color ?? palette[i % palette.length],
      }
    })

  const pieData = slices.map((s) => ({
    id: s.id,
    label: s.label,
    value: s.percent,
    color: s.color,
  }))
  const selectedIndex = slices.findIndex((s) => s.id === selectedId)

  return (
    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} sx={{ alignItems: 'center' }}>
      <Box sx={{ width: 200, height: 200, flexShrink: 0 }}>
        <PieChart
          series={[
            {
              id: 'departments',
              data: pieData,
              highlightScope: { fade: 'global', highlight: 'item' },
              faded: { innerRadius: 30, additionalRadius: -30, color: 'gray' },
              valueFormatter,
            },
          ]}
          height={200}
          width={200}
          hideLegend
          highlightedItem={
            selectedIndex >= 0
              ? { type: 'pie', seriesId: 'departments', dataIndex: selectedIndex }
              : null
          }
          onItemClick={
            onSelect
              ? (_event, _identifier, item) => {
                  const id = String(item.id)
                  onSelect(selectedId === id ? null : id)
                }
              : undefined
          }
        />
      </Box>
      <Stack spacing={0.75} sx={{ flexGrow: 1, minWidth: 0, maxHeight: 220, overflow: 'auto', width: '100%' }}>
        {slices.map((s) => {
          const selected = selectedId != null && selectedId === s.id
          return (
            <Box
              key={s.id}
              component={onSelect ? 'button' : 'div'}
              type={onSelect ? 'button' : undefined}
              onClick={onSelect ? () => onSelect(selected ? null : s.id) : undefined}
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 1,
                border: 'none',
                background: selected ? alpha(s.color, 0.12) : 'transparent',
                borderRadius: 1,
                px: 0.75,
                py: 0.5,
                cursor: onSelect ? 'pointer' : 'default',
                textAlign: 'left',
                width: '100%',
                font: 'inherit',
                color: 'inherit',
              }}
            >
              <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: s.color, flexShrink: 0 }} />
              <Typography variant="caption" sx={{ flexGrow: 1, minWidth: 0 }} noWrap title={s.label}>
                {s.label}
              </Typography>
              <Typography variant="caption" sx={{ fontWeight: 700, flexShrink: 0 }}>
                {s.percent.toFixed(1)}%
              </Typography>
            </Box>
          )
        })}
      </Stack>
    </Stack>
  )
}
