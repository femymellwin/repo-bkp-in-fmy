import Box from '@mui/material/Box'
import Stack from '@mui/material/Stack'
import Typography from '@mui/material/Typography'
import { alpha, useTheme } from '@mui/material/styles'

export interface BarDatum {
  label: string
  value: number
  id?: string
  color?: string
}

/** Lightweight horizontal bar chart — no extra chart library dependency. */
export function SimpleBarChart({
  title,
  data,
  emptyLabel = 'No data yet',
  selectedId,
  onSelect,
}: {
  title?: string
  data: BarDatum[]
  emptyLabel?: string
  selectedId?: string | null
  onSelect?: (id: string | null) => void
}) {
  const theme = useTheme()
  const max = Math.max(1, ...data.map((d) => d.value))
  const palette = [
    theme.palette.primary.main,
    theme.palette.secondary.main,
    theme.palette.text.primary,
    theme.palette.divider,
    theme.palette.warning.main,
    theme.palette.error.main,
  ]

  return (
    <Box>
      {title && (
        <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
          {title}
        </Typography>
      )}
      {data.length === 0 || data.every((d) => d.value === 0) ? (
        <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
          {emptyLabel}
        </Typography>
      ) : (
        <Stack spacing={1.25}>
          {data.map((d, i) => {
            const id = d.id ?? d.label
            const selected = selectedId != null && selectedId === id
            const color = d.color ?? palette[i % palette.length]
            return (
              <Box
                key={id}
                component={onSelect ? 'button' : 'div'}
                type={onSelect ? 'button' : undefined}
                onClick={
                  onSelect
                    ? () => onSelect(selected ? null : id)
                    : undefined
                }
                sx={{
                  border: 'none',
                  background: selected ? alpha(color, 0.1) : 'transparent',
                  borderRadius: 1,
                  p: onSelect ? 0.5 : 0,
                  m: 0,
                  width: '100%',
                  textAlign: 'left',
                  cursor: onSelect ? 'pointer' : 'default',
                  font: 'inherit',
                  color: 'inherit',
                }}
              >
                <Stack direction="row" sx={{ justifyContent: 'space-between', mb: 0.35 }}>
                  <Typography variant="caption" color="text.secondary" noWrap title={d.label}>
                    {d.label}
                  </Typography>
                  <Typography variant="caption" sx={{ fontWeight: 600 }}>
                    {d.value}
                  </Typography>
                </Stack>
                <Box
                  sx={{
                    height: 10,
                    borderRadius: 1,
                    bgcolor: alpha(theme.palette.text.primary, 0.06),
                    overflow: 'hidden',
                  }}
                >
                  <Box
                    sx={{
                      height: '100%',
                      width: `${Math.round((d.value / max) * 100)}%`,
                      bgcolor: color,
                      opacity: selectedId && !selected ? 0.4 : 1,
                      borderRadius: 1,
                      transition: 'width 0.4s ease, opacity 0.2s',
                    }}
                  />
                </Box>
              </Box>
            )
          })}
        </Stack>
      )}
    </Box>
  )
}
