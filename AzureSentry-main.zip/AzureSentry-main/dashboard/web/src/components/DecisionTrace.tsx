import Box from '@mui/material/Box'
import Stack from '@mui/material/Stack'
import Typography from '@mui/material/Typography'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import CancelIcon from '@mui/icons-material/Cancel'
import RemoveCircleIcon from '@mui/icons-material/RemoveCircle'
import { alpha, useTheme } from '@mui/material/styles'
import type { DecisionStep } from '../types'

export function DecisionTrace({ steps }: { steps: DecisionStep[] }) {
  const theme = useTheme()
  if (!steps.length) {
    return (
      <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
        No decision trace recorded.
      </Typography>
    )
  }
  const toneOf = (s: string) =>
    s === 'pass' ? theme.palette.success.dark
    : s === 'fail' ? theme.palette.error.main
    : theme.palette.text.secondary
  const iconOf = (s: string) =>
    s === 'pass' ? CheckCircleIcon : s === 'fail' ? CancelIcon : RemoveCircleIcon

  return (
    <Stack spacing={1}>
      {steps.map((s) => {
        const tone = toneOf(s.status)
        const Icon = iconOf(s.status)
        return (
          <Stack
            key={s.step}
            direction="row"
            spacing={1.25}
            sx={{
              alignItems: 'flex-start',
              p: 1,
              borderRadius: 1.5,
              border: `1px solid ${theme.palette.divider}`,
              bgcolor: alpha(tone, 0.05),
            }}
          >
            <Icon sx={{ color: tone, fontSize: 20, mt: '2px' }} />
            <Box>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {s.step}. {s.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {s.detail}
              </Typography>
            </Box>
          </Stack>
        )
      })}
    </Stack>
  )
}
