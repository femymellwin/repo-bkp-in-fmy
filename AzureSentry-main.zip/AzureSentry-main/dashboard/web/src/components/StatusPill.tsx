import Chip from '@mui/material/Chip'
import { alpha, useTheme } from '@mui/material/styles'
import type { ReactNode } from 'react'

export type PillTone = 'ok' | 'warn' | 'bad' | 'neutral'

export function StatusPill({ tone, label }: { tone: PillTone; label: ReactNode }) {
  const theme = useTheme()
  const color = {
    ok: theme.palette.success.main,
    warn: theme.palette.warning.main,
    bad: theme.palette.error.main,
    neutral: theme.palette.text.secondary,
  }[tone]
  const onLight = tone === 'ok' || tone === 'neutral'
  return (
    <Chip
      label={label}
      size="small"
      sx={{
        bgcolor: alpha(color, 0.18),
        color: onLight ? 'text.primary' : color,
        border: `1px solid ${color}`,
        fontWeight: 600,
        fontSize: '0.7rem',
        height: 22,
        borderRadius: 1,
      }}
    />
  )
}
