import Chip from '@mui/material/Chip'
import { alpha, useTheme } from '@mui/material/styles'
import type { DecisionAction } from '../types'

const KEY: Record<string, 'grant' | 'eligible' | 'reject' | 'hold' | 'breakglass'> = {
  Grant: 'grant',
  Eligible: 'eligible',
  Reject: 'reject',
  Hold: 'hold',
  BreakGlass: 'breakglass',
}

export function ActionBadge({ action }: { action: DecisionAction | string }) {
  const theme = useTheme()
  const color = theme.palette.decision[KEY[action] ?? 'eligible']
  return (
    <Chip
      label={String(action).toUpperCase()}
      size="small"
      sx={{
        bgcolor: alpha(color, 0.18),
        color: 'text.primary',
        border: `1px solid ${color}`,
        fontWeight: 700,
        fontSize: '0.7rem',
        letterSpacing: '0.03em',
        borderRadius: 1.5,
        height: 22,
      }}
    />
  )
}

export function formatDuration(hours: number): string {
  if (hours < 0) {
    const abs = Math.abs(hours)
    if (abs < 24) return `${Math.round(abs)}h overdue`
    return `${Math.round(abs / 24)}d overdue`
  }
  if (hours < 1) return `${Math.round(hours * 60)}m`
  if (hours < 48) return `${Math.round(hours)}h`
  return `${Math.round(hours / 24)}d`
}
