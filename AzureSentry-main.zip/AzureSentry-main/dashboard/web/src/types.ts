export type DecisionAction = 'Grant' | 'Eligible' | 'Reject' | 'Hold' | 'BreakGlass'

export interface Ticket {
  TicketId?: string
  Role: string
  Environment: string
  SubscriptionId: string
  ResourceScope?: string
  DurationDays: number
  Priority: string
  RequesterUpn: string
  SubmitterUpn?: string
  Justification?: string
  BreakGlass?: boolean
  hasExistingAssignment?: boolean
}

export interface DecisionStep {
  step: number
  name: string
  status: 'pass' | 'fail' | 'skip'
  detail: string
}

export interface Decision {
  Action: DecisionAction
  Path: string
  Reason: string
  Runbook?: string
  SlaHours?: number
  EscalateAt?: number
  MfaRequired?: boolean
  ApproverTier?: string
  AssignmentType?: string
  NotifyOnCall?: boolean
}

export interface EvaluateResult {
  ticket: Ticket & { TicketId: string }
  steps: DecisionStep[]
  decision: Decision
  execution?: {
    Success: boolean
    AssignmentId?: string
    ExpiresAt?: string
    PimClient?: string
    AssignmentType?: string
    Error?: string
    Fulfilment?: string
    GroupId?: string
    GroupName?: string
    GroupCreated?: boolean
    GroupAlreadyExisted?: boolean
    RoleAssignmentCreated?: boolean
    EngineerActionRequired?: boolean
    EngineerActionReason?: string
    AlreadyExisted?: boolean
    Message?: string
  }
  activity: ActivityItem
}

export interface ActivityItem {
  id: string
  timestamp: string
  mode: string
  ticketId: string
  requester: string
  environment: string
  role: string
  priority: string
  action: DecisionAction
  path: string
  reason: string
  runbook?: string
  steps?: DecisionStep[]
  slaHours?: number
  escalateAtHours?: number
  approvalStatus?: string
  approvalRequestedAt?: string
  approvalCompletedAt?: string
  success?: boolean
  assignmentId?: string
  expiresAt?: string
  durationDays?: number
  assignmentStatus?: string
  isBreakGlass?: boolean
  reviewStatus?: string
  reviewDeadline?: string
  securityAlertSent?: boolean
}

export interface ActivityFilters {
  requester?: string
  role?: string
  environment?: string
  action?: string
  hours?: number
}

export interface SlaTier {
  priority: string
  slaHours: number
  total: number
  compliant: number
  breached: number
  pending: number
  complianceRate: number
}

export interface SlaBreach {
  ticketId: string
  requester: string
  priority: string
  slaHours: number
  requestedAt: string
  status: string
  environment: string
  role: string
}

export interface SlaMetrics {
  tiers: SlaTier[]
  breaches: SlaBreach[]
  overallCompliance: number
}

export interface Assignment {
  assignmentId: string
  ticketId: string
  requester: string
  environment: string
  role: string
  action: DecisionAction
  grantedAt: string
  expiresAt: string
  remainingHours: number
  durationDays?: number
  status: string
  urgency: 'ok' | 'warning' | 'critical' | 'expired'
  isBreakGlass: boolean
  /** 'PimFallback' (real PIM assignment) or 'Group' (Entra group membership). */
  fulfilment: string
  /** 'AzureEnforced' = ARM times the assignment out on its own. 'TrackedOnly' = no
   *  native Azure expiry (Group fulfilment); the reaper agent is solely responsible
   *  for revoking it once expired. See Get-GrantExpiryEnforcement. */
  expiryEnforcement: 'AzureEnforced' | 'TrackedOnly'
}

export interface AssignmentsResponse {
  items: Assignment[]
  active: number
  expiringSoon: number
  expiredNotRevoked: number
}

export interface BreakGlassRecord {
  id: string
  ticketId: string
  requester: string
  role: string
  environment: string
  grantedAt: string
  assignmentId: string
  expiresAt: string
  reviewStatus: string
  reviewDeadline: string
  reviewRemainingHours: number | null
  securityAlertSent: boolean
  path: string
  reason: string
}

export interface BreakGlassResponse {
  items: BreakGlassRecord[]
  pendingReview: number
  overdueReview: number
}

export interface MatrixRow {
  id: string
  requestType: string
  environment: string
  role: string
  priority: string
  action: string
  path: string
  humanTouch: string
  runbook?: string
  reason?: string
}

export interface Stats {
  Total: number
  Grant: number
  Eligible: number
  Reject: number
  Hold: number
  BreakGlass: number
}

export interface Preset {
  id: string
  label: string
  ticket: Partial<Ticket>
}

export interface AllowlistSubscription {
  id: string
  label: string
}

export interface PimContext {
  loggedIn: boolean
  error?: string
  account?: string
  user?: string
  subscriptionId?: string
  subscriptionName?: string
  tenantId?: string
  principalId?: string
  onExpectedSubscription?: boolean
  expectedSubscriptionId?: string
  expectedSubscriptionName?: string
  azureEnabled?: boolean
  defaultDurationHours?: number
}

export interface EligibleRole {
  roleName: string
  roleDefinitionId: string
  roleDefId: string
  scope: string
  scopeName: string
  scopeType: string
  endDateTime?: string
}

export interface ActiveAssignment {
  id?: string
  roleName: string
  roleDefinitionId: string
  roleDefId: string
  scope: string
  scopeName: string
  scopeType: string
  subscriptionId?: string
  assignmentType: string
  memberType: string
  status: string
  startDateTime?: string
  endDateTime?: string
  remainingHours: number | null
  isActivated: boolean
  isPending?: boolean
  requestId?: string | null
}

export interface ActivationResult {
  ticket: Ticket & { TicketId: string }
  steps: DecisionStep[]
  decision: Decision
  activated: boolean
  blocked?: boolean
  reason?: string
  activation?: {
    requestId: string
    status: string
    roleName: string
    roleDefinitionId: string
    durationMinutes: number
  }
  expiresAt?: string
}

export interface METicket {
  id: number
  subject: string
  short_description?: string
  requester?: { name: string; email_id?: string }
  technician?: { name: string }
  status?: { name: string }
  priority?: { name: string }
  category?: { name: string }
  subcategory?: { name: string }
  created_time?: { display_value: string; value: string }
  due_by_time?: { display_value: string; value: string }
  completed_time?: { display_value: string; value: string }
  site?: { name: string }
  group?: { name: string }
  description?: string
  resolution?: { content: string }
  is_overdue?: boolean
  /** ManageEngine template custom fields (subscription/role/env often live here). */
  udf_fields?: Record<string, unknown>
  template?: { name?: string; id?: string }
  /** Built-in ME categorization item (schema field "Item") — not a UDF. */
  item?: { name?: string; id?: string } | string
  /** Built-in ME request type (schema field "Request Type") — not a UDF. */
  request_type?: { name?: string; id?: string } | string
}

/** Extracted Azure Subscription template fields from ME detail API. */
export interface MeAccessFields {
  Subscription?: string
  AzureRole?: string
  /** Raw ManageEngine Environment dropdown value. */
  Environment?: string
  fieldKeys?: Record<string, string>
}

/** Common ticket fields shown for every ManageEngine request. */
export interface TemplatePayloadCommon {
  requesterName: string
  requesterEmail: string
  category: string
  subcategory: string
  subject: string
  description: string
  status: string
}

/**
 * Normalized template-driven ticket payload for UI and agents.
 * handler `none` = unknown / unspecified template schema.
 */
export interface TemplatePayload {
  templateName: string
  handler: 'azure-subscription-grant' | 'pending' | 'none'
  knownSchema: boolean
  common: TemplatePayloadCommon
  fields: Record<string, string>
  fieldOrder: string[]
  /** Schema field labels marked mandatory in ManageEngine (non–Azure Subscription). */
  requiredFields?: string[]
  /** Always-shown placeholders marked mandatory (e.g. Requester UPN, Justification). */
  requiredPlaceholders?: string[]
  warnings: string[]
}

export interface ProcessResult extends EvaluateResult {
  processed: boolean
  alreadyProcessed?: boolean
  promotionBlocked?: boolean
  duplicateBlocked?: boolean
  meUpdate?: {
    error?: string
    warning?: string
    showToRequester?: boolean
    notifyTechnician?: boolean
    notifyRequester?: boolean
  } | null
}

export interface ProcessedSummary {
  meTicketId: string
  ticketId?: string
  action: string
  path?: string
  role?: string
  environment?: string
  subscriptionId?: string
  requesterUpn?: string
  pimClient?: string
  assignmentId?: string
  assignmentType?: string
  expiresAt?: string
  fulfilment?: string
  groupId?: string
  groupName?: string
  notePosted?: boolean
  notifyRequester?: boolean
  processedAt?: string
  revoked?: boolean
  revokedAt?: string
  revokeNotePosted?: boolean
  revokeNotifyRequester?: boolean
  revokeNoteError?: string
}

export interface TicketAnalytics {
  idmQueue: string
  idmQueueDisplay?: string
  identityQueues?: string[]
  identityQueueLabels?: Array<{ name: string; displayName: string }>
  totalTickets: number
  totalIdmTickets: number
  /** All ManageEngine tickets created today */
  dailyCount?: number
  /** All ManageEngine tickets created this month */
  monthlyCount?: number
  dailyIdmCount: number
  monthlyIdmCount: number
  byEnvironment: Record<string, number>
  byCategory: Record<string, number>
  byDepartment: Record<string, number>
  byStatus?: Record<string, number>
  /** FR1 — counts per environment-first criticality band. */
  byCriticality?: Record<string, number>
  /** FR2 — how much of the backlog carries a real Environment dropdown value. */
  environmentTagHealth?: { tagged: number; inferred: number; untagged: number; notApplicable: number }
  tickets?: OverviewTicket[]
  /** 'all' = Overview aggregates every ME ticket */
  scope?: string
  agentActionStates: {
    Evaluated: number
    Granted: number
    Eligible: number
    Rejected: number
    Hold: number
    BreakGlass: number
    Revoked?: number
  }
  fetchedAt?: string
  error?: string
}

export interface OverviewTicket {
  id: string
  subject: string
  department: string
  project: string
  environment: string
  /** Dropdown = tagged by the requester; Text = inferred; None = untagged. */
  environmentSource?: 'Dropdown' | 'Text' | 'None' | 'NotApplicable'
  environmentInferred?: boolean
  category: string
  /** ManageEngine request template (General Access, ADO, Azure Subscription, …). */
  ticketType?: string
  status: string
  priority: string
  /** FR1 — lower is more urgent. Environment band dominates; priority orders within it. */
  criticalityScore?: number
  criticalityTier?: 'Critical' | 'High' | 'Standard' | 'Unclassified'
  /** True when a P0–P2 was claimed outside Production and therefore did not jump the queue. */
  priorityDemoted?: boolean
  requester: string
  createdAt?: string
  isIdm: boolean
}

export interface TicketSummary {
  summary: string
  highlights?: {
    who?: string
    access?: string
    environment?: string
    subscription?: string
    intent?: string
    urgency?: string
  }
  source: 'llm' | 'heuristic'
  llmConfigured?: boolean
  llmError?: string
  provider?: string
}

export interface RevokeResult {
  revoked: boolean
  alreadyRevoked?: boolean
  meTicketId: string
  assignmentId?: string
  groupId?: string
  fulfilment?: string
  pimClient?: string
  meUpdate?: {
    error?: string
    warning?: string
    showToRequester?: boolean
    notifyTechnician?: boolean
    notifyRequester?: boolean
  } | null
  revokeNotePosted?: boolean
  revokeNotifyRequester?: boolean
  error?: string
}

export interface MERequestsResponse {
  requests: METicket[]
  response_status: { status_code: number; status: string }
  list_info?: { total_count: number; has_more_rows: boolean; start_index: number; row_count: number }
  idmQueue?: string
  idmQueueDisplay?: string
  identityQueues?: string[]
  identityQueueLabels?: Array<{ name: string; displayName: string }>
  idmFiltered?: boolean
  totalFetched?: number
  totalIdm?: number
}

/**
 * Core IA (FR5): Dashboard, Execution Hub, Audit Logs.
 * 'livepim' remains as an engineering tool; the seed-data-only monitoring
 * views ('sla' | 'expiry' | 'breakglass') are Coming Soon until wired to Log Analytics.
 * 'matrix' and 'architecture' moved out of the app into docs/LLD.md.
 */
export type View =
  | 'overview'
  | 'tickets'
  | 'audit'
  | 'livepim'
  | 'sla'
  | 'expiry'
  | 'breakglass'

/** Sub-tabs inside the Execution Hub — where agents act on tickets. */
export type ExecutionHubTab = 'queue' | 'scope'

// ---------------------------------------------------------------------------
// FR3 — agent registry
// ---------------------------------------------------------------------------

export interface AgentDefinition {
  name: string
  displayName: string
  /** Deterministic API caller, LLM reasoning step, or both. */
  kind: 'Deterministic' | 'Llm' | 'Hybrid'
  purpose: string
  writes: boolean
  systems: string[]
  permissions: string[]
}

export interface DepartmentScope {
  active?: string[]
  expanding?: string[]
  deferred?: string[]
}

export interface SubscriptionResolution {
  status: 'Resolved' | 'NeedsHumanChoice' | 'NotFound'
  subscriptionId?: string | null
  label?: string | null
  matchType?: string | null
  candidates: Array<{ id: string; label: string; environment: string }>
  reason: string
}

// ---------------------------------------------------------------------------
// FR6 — audit trail
// ---------------------------------------------------------------------------

export type AuditOutcome = 'Success' | 'Failed' | 'Blocked' | 'DryRun' | 'Started'

export interface AuditEvent {
  id: string
  seq: number
  timestamp: string
  agent: string
  action: string
  actor?: string
  runId?: string
  correlationId?: string
  ticketId?: string
  target?: Record<string, unknown> | null
  before?: Record<string, unknown> | null
  after?: Record<string, unknown> | null
  outcome: AuditOutcome
  reason?: string | null
  detail?: Record<string, unknown> | null
  correctsEventId?: string | null
  /** True when the action changed state in an external system. */
  isWrite: boolean
  hash: string
  prevHash: string
}

export interface AuditSummary {
  total: number
  writes: number
  byAgent: Record<string, number>
  byAction: Record<string, number>
  byOutcome: Record<string, number>
  lastSeq: number
  path: string
}

export interface AuditFilters {
  agent?: string
  action?: string
  ticketId?: string
  actor?: string
  outcome?: string
  correlationId?: string
  hours?: number
  limit?: number
  writesOnly?: string
}

// ---------------------------------------------------------------------------
// FR4 — department scope categorization
// ---------------------------------------------------------------------------
// FR2 environment-backfill UI types removed (Environment Governance page
// retired 2026-08-19). The backend endpoints (/api/governance/environment/*)
// and the EnvironmentInferenceAgent / SentryGovernanceAgent PowerShell backend
// were removed too: Environment is now mandatory at ticket creation, so there
// is no more backlog to infer or backfill. Their four deterministic helpers
// survive in dashboard/api/EnvironmentResolution.ps1, still used to resolve
// each ticket's environment for the Overview and Execution Hub display.

export interface WorkTypeCatalogEntry {
  key: string
  displayName: string
  actionable: boolean
  humanAudit: boolean
  description: string
}

export interface CategorizationRow {
  id: string
  subject: string
  department?: string
  ticketType?: string
  workType: string
  displayName: string
  actionable: boolean
  /**
   * Effective audit posture for this row. Cleared on actionable work whose
   * classification came from a deterministic keyword match. Reporting only — a write
   * path must read `policyHumanAudit`.
   */
  humanAudit: boolean
  /** The work type's standing audit posture, independent of this row's evidence. */
  policyHumanAudit?: boolean
  confidence: number
  source: 'Rules' | 'Llm'
  /** True when a deterministic rule pattern matched the ticket text. */
  keywordMatch?: boolean
  inferred: boolean
  rationale: string
}

export interface CategorizationSummary {
  total: number
  actionable: number
  notActionable: number
  actionableRate: number
  actionableWithAudit: number
  /** What actionableWithAudit would be on standing policy alone, for comparison. */
  actionableWithAuditByPolicy?: number
  actionableFullyAuto: number
  unclassified: number
  fromRules: number
  fromKeywordMatch?: number
  fromLlm: number
  /** Actionable rows whose standing audit posture a keyword match cleared. */
  auditClearedByKeyword?: number
  byWorkType: Record<string, number>
}

export interface CategorizationReport {
  department: string
  runId?: string
  generatedAt?: string
  llmUsed?: boolean
  llmError?: string | null
  summary?: CategorizationSummary | null
  catalog: WorkTypeCatalogEntry[]
  results: CategorizationRow[]
  error?: string
}

// ---------------------------------------------------------------------------
// Unattended ticket poller
// ---------------------------------------------------------------------------

export interface PollerEntry {
  ticketId: string
  /** WouldGrant (shadow) | Granted (enforce) | Queued | Failed. Never "Skipped". */
  outcome: 'WouldGrant' | 'Granted' | 'Queued' | 'Failed'
  reason: string
  action?: string | null
  effectiveEnvironment?: string | null
  role?: string
  subscriptionId?: string
  requesterUpn?: string
  assignmentId?: string
  applied: boolean
  /**
   * Only set on Granted/Failed enforce entries -- Queued and WouldGrant never post a
   * ManageEngine note (see TicketPollerAgent.ps1 Invoke-TicketPollerCycle .DESCRIPTION).
   * notePosted/ticketResolved surface bookkeeping that can silently fail even though the
   * Azure grant itself succeeded: a resolve failure is non-fatal by design.
   */
  notePosted?: boolean
  noteError?: string
  ticketResolved?: boolean
  resolveError?: string
}

export interface PollerCycle {
  runId: string
  mode: 'shadow' | 'enforce'
  examined: number
  wouldGrant: number
  granted: number
  queued: number
  failed: number
  stopped: boolean
  halted: boolean
  haltReason?: string
  ranAt: string
  entries: PollerEntry[]
}

export interface PollerModeOverride {
  /** Whether dashboard/api/poller.mode currently exists. */
  present: boolean
  /** Its trimmed, lowercased content, or `null` when absent/unreadable. */
  value: 'enforce' | 'shadow' | null
  filePath: string
}

export interface PollerEnabledOverride {
  /** Whether dashboard/api/poller.enabled (or reaper.enabled) currently exists. */
  present: boolean
  /** Its trimmed, lowercased content, or `null` when absent/unreadable. */
  value: 'true' | 'false' | null
  filePath: string
}

export interface PollerCapValue {
  value: number
  source: 'env' | 'override'
}

export interface PollerStatus {
  configured: boolean
  /**
   * Derived from the poller's own last reported cycle (poller-status.json), never from
   * the dashboard process's own env vars -- see Resolve-PollerStatusView. `null` means
   * unknown: no status has ever been recorded, or the last one is stale/unparseable.
   * Render `null` as "unknown", never as a confident "Off".
   */
  enabled: boolean | null
  mode: 'shadow' | 'enforce' | null
  /** True when `enabled`/`mode` are `null` because the status is missing or stale. */
  stale: boolean
  stopFilePresent: boolean
  lastCycle: PollerCycle | null
  /**
   * The dashboard's Enforce Mode toggle (POST/DELETE /api/poller/mode). This is an
   * INSTRUCTION for the poller's next cycle, not a live state -- it can disagree with
   * `mode` above (the last cycle's actual, already-happened behaviour) for up to one
   * scheduling interval after someone flips it. Never render this as if it were `mode`.
   */
  modeOverride: PollerModeOverride
  /**
   * The dashboard's automation on/off control (POST/DELETE /api/poller/enabled). Same
   * "instruction for the next cycle, not a live state" caveat as modeOverride.
   */
  enabledOverride: PollerEnabledOverride
  /** Per-cycle limits, current effective value and whether it came from an override file. */
  caps: {
    maxGrants: PollerCapValue
    maxTickets: PollerCapValue
    maxAgeDays: PollerCapValue
  }
}

// ---------------------------------------------------------------------------
// Reaper (grant expiry enforcement) -- ReaperAgent.ps1 / Invoke-ReaperCycle.ps1
// ---------------------------------------------------------------------------

export interface ReaperEntry {
  ticketId: string
  /** WouldRevoke (shadow) | Revoked (enforce) | Deferred (cap reached) | Failed. */
  outcome: 'WouldRevoke' | 'Revoked' | 'Deferred' | 'Failed'
  reason: string
  /** PimFallback = Azure-enforced expiry; Group = tracked-only, reaper-enforced. */
  fulfilment?: string
  expiresAt?: string
  requesterUpn?: string
  role?: string
  subscriptionId?: string
  scope?: string
  /** How long past its recorded expiry this grant was when the cycle examined it. */
  overdueHours?: number
}

export interface ReaperCycle {
  runId: string
  mode: 'shadow' | 'enforce'
  examined: number
  revoked: number
  wouldRevoke: number
  deferred: number
  failed: number
  stopped: boolean
  halted: boolean
  haltReason?: string
  /**
   * Records whose recorded expiry has passed and that are STILL unrevoked -- access
   * outliving its own authorisation. Populated even on a disabled/halted cycle; see
   * Get-ExpiredUnrevokedCount (ReaperAgent.ps1).
   */
  expiredUnrevoked: number
  ranAt: string
  entries: ReaperEntry[]
}

export interface ReaperStatus {
  configured: boolean
  /**
   * Derived from the reaper's own last reported cycle (reaper-status.json), never from
   * the dashboard process's own env vars -- see Resolve-ReaperStatusView. `null` means
   * unknown: no status has ever been recorded, or the last one is stale/unparseable.
   * Render `null` as "unknown", never as a confident "Off".
   */
  enabled: boolean | null
  mode: 'shadow' | 'enforce' | null
  /** True when `enabled`/`mode` are `null` because the status is missing or stale. */
  stale: boolean
  stopFilePresent: boolean
  lastCycle: ReaperCycle | null
  /**
   * Mirrors lastCycle.expiredUnrevoked at the top level so it renders even when
   * lastCycle itself is stale/unparseable -- this count must never be harder to reach
   * than the rest of the status payload. `null` only when there has never been a cycle.
   */
  expiredUnrevoked: number | null
  /**
   * The dashboard's Enforce Mode toggle (POST/DELETE /api/reaper/mode). Same shape and
   * same caveat as PollerStatus.modeOverride -- an instruction for the reaper's NEXT
   * cycle, not a live state. Never render this as if it were `mode`.
   */
  modeOverride: PollerModeOverride
  /** Same shape and caveat as PollerStatus.enabledOverride. */
  enabledOverride: PollerEnabledOverride
  /** Single field, same shape as PollerStatus.caps otherwise. */
  caps: {
    maxRevokes: PollerCapValue
  }
}
