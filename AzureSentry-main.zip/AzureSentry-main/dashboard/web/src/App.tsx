import { useCallback, useEffect, useState, type ReactNode } from 'react'
import Alert from '@mui/material/Alert'
import AppBar from '@mui/material/AppBar'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Chip from '@mui/material/Chip'
import Container from '@mui/material/Container'
import Divider from '@mui/material/Divider'
import Drawer from '@mui/material/Drawer'
import IconButton from '@mui/material/IconButton'
import List from '@mui/material/List'
import ListItemButton from '@mui/material/ListItemButton'
import ListItemIcon from '@mui/material/ListItemIcon'
import ListItemText from '@mui/material/ListItemText'
import ListSubheader from '@mui/material/ListSubheader'
import MenuItem from '@mui/material/MenuItem'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Tab from '@mui/material/Tab'
import Tabs from '@mui/material/Tabs'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import TextField from '@mui/material/TextField'
import Toolbar from '@mui/material/Toolbar'
import Tooltip from '@mui/material/Tooltip'
import Typography from '@mui/material/Typography'
import useMediaQuery from '@mui/material/useMediaQuery'
import { alpha, useTheme } from '@mui/material/styles'
import MenuIcon from '@mui/icons-material/Menu'
import RefreshIcon from '@mui/icons-material/Refresh'
import CircleIcon from '@mui/icons-material/Circle'
import DashboardIcon from '@mui/icons-material/Dashboard'
import BoltIcon from '@mui/icons-material/Bolt'
import FactCheckIcon from '@mui/icons-material/FactCheck'
import SpeedIcon from '@mui/icons-material/Speed'
import ScheduleIcon from '@mui/icons-material/Schedule'
import WarningAmberIcon from '@mui/icons-material/WarningAmber'
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber'

import { api } from './api/client'
import { formatIdentityLabel } from './formatIdentityLabel'
import { ActionBadge } from './components/ActionBadge'
import { PageHeader } from './components/PageHeader'
import { StatCard } from './components/StatCard'
import { StatusPill } from './components/StatusPill'
import { SimpleBarChart } from './components/SimpleBarChart'
import { SimpleDonutChart } from './components/SimpleDonutChart'
import { AuditLogsView } from './views/AuditLogsView'
import { DepartmentScopeView } from './views/DepartmentScopeView'
import { ExpiryView } from './views/ExpiryView'
import { LivePimView } from './views/LivePimView'
import { EnforceModeMismatchBanner } from './views/EnforceModeMismatchBanner'
import { PollerStatusPanel } from './views/PollerStatusPanel'
import { ReaperStatusPanel } from './views/ReaperStatusPanel'
import { TicketsView } from './views/TicketsView'
import type {
  ActivityItem,
  ExecutionHubTab,
  Stats,
  TicketAnalytics,
  View,
} from './types'

const DRAWER_WIDTH = 260

/**
 * FR5 information architecture. Three core menus: Dashboard, Execution Hub, Audit Logs.
 *
 * Everything that only ever had illustrative seed data is marked "Coming Soon" and
 * disabled, because Phase 0 removed the dummy data and those views have no real source
 * until Log Analytics is wired (roadmap D1–D3).
 *
 * Live PIM is grouped separately as an engineering tool: it runs against real ARM PIM,
 * so labelling it "Coming Soon" would be untrue.
 *
 * Expiry Tracking left "Coming Soon" the same way: it now reads the durable
 * processed-tickets store (dashboard/api/processed-tickets/, shared with the poller),
 * not illustrative seed data, so it has a real source.
 *
 * Eligibility Matrix and Architecture were removed from the app — that content now lives
 * in docs/LLD.md, per the review.
 */
const NAV: {
  id: View
  label: string
  group?: string
  icon: ReactNode
  comingSoon?: boolean
}[] = [
  { id: 'overview', label: 'Dashboard', icon: <DashboardIcon /> },
  { id: 'tickets', label: 'Execution Hub', icon: <ConfirmationNumberIcon /> },
  { id: 'audit', label: 'Audit Logs', icon: <FactCheckIcon /> },
  { id: 'expiry', label: 'Expiry Tracking', icon: <ScheduleIcon /> },
  { id: 'livepim', label: 'Live PIM (Azure)', group: 'Engineering tools', icon: <BoltIcon /> },
  { id: 'sla', label: 'SLA Compliance', group: 'Coming soon', icon: <SpeedIcon />, comingSoon: true },
  { id: 'breakglass', label: 'Break-Glass', group: 'Coming soon', icon: <WarningAmberIcon />, comingSoon: true },
]

const EXECUTION_HUB_TABS: { id: ExecutionHubTab; label: string }[] = [
  { id: 'queue', label: 'Ticket Queue' },
  { id: 'scope', label: 'Department Scope' },
]

const CRITICALITY_TONE: Record<string, 'ok' | 'warn' | 'bad' | 'neutral'> = {
  Critical: 'bad',
  High: 'warn',
  Standard: 'ok',
  Unclassified: 'neutral',
}

export default function App() {
  const [view, setView] = useState<View>('overview')
  const [hubTab, setHubTab] = useState<ExecutionHubTab>('queue')
  const [connected, setConnected] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [stats, setStats] = useState<Stats | null>(null)
  const [ticketAnalytics, setTicketAnalytics] = useState<TicketAnalytics | null>(null)
  const [overviewDepartment, setOverviewDepartment] = useState('All')
  const [overviewCategory, setOverviewCategory] = useState('All')
  const [overviewEnvironment, setOverviewEnvironment] = useState('All')
  const [overviewTicketType, setOverviewTicketType] = useState('All')
  const [activity, setActivity] = useState<ActivityItem[]>([])
  const [refreshing, setRefreshing] = useState(false)
  // Bumped whenever PollerStatusPanel or ReaperStatusPanel's own Enforce Mode toggle
  // succeeds, so EnforceModeMismatchBanner re-checks itself immediately rather than
  // lagging behind on its own next poll -- see that component's .DESCRIPTION.
  const [pollerReaperRefreshToken, setPollerReaperRefreshToken] = useState(0)
  const theme = useTheme()
  const isDesktop = useMediaQuery(theme.breakpoints.up('md'))
  const [mobileOpen, setMobileOpen] = useState(false)

  const overviewDepartments = Object.entries(ticketAnalytics?.byDepartment ?? {}).sort(
    (a, b) => b[1] - a[1],
  )
  const overviewTickets = ticketAnalytics?.tickets ?? []
  const overviewTicketTypes = [...new Set(overviewTickets.map((item) => item.ticketType || 'Unspecified'))].sort(
    (a, b) => a.localeCompare(b),
  )
  // FR1 — the queue is ordered by effective criticality (environment band first,
  // requester priority only inside the band), not by the priority the requester typed.
  const filteredOverviewTickets = overviewTickets
    .filter(
      (item) =>
        (overviewDepartment === 'All' || item.department === overviewDepartment) &&
        (overviewCategory === 'All' || item.category === overviewCategory) &&
        (overviewEnvironment === 'All' || item.environment === overviewEnvironment) &&
        (overviewTicketType === 'All' || (item.ticketType || 'Unspecified') === overviewTicketType),
    )
    .slice()
    .sort((a, b) => (a.criticalityScore ?? 99) - (b.criticalityScore ?? 99))
  // Overview "Recent Activity" shows live process/evaluate/live events only — not demo seed.
  const recentActivity = activity.filter(
    (item) => item.mode && !['simulate', 'demo', 'seed'].includes(String(item.mode)),
  )

  const refresh = useCallback(async () => {
    setRefreshing(true)
    try {
      await api.health()
      setConnected(true)
      const [s, a, analytics] = await Promise.all([
        api.stats(),
        api.activity(),
        api.manageEngine.analytics().catch(() => null),
      ])
      setStats(s.stats)
      setActivity(a.items)
      if (analytics) setTicketAnalytics(analytics)
      setError(null)
    } catch (e) {
      setConnected(false)
      setError(e instanceof Error ? e.message : 'API unavailable. Run: cd dashboard\\api && .\\Start-DashboardApi.ps1')
    } finally {
      setRefreshing(false)
    }
  }, [])

  useEffect(() => {
    refresh()
  }, [])

  const current = NAV.find((n) => n.id === view)

  const renderNav = () => {
    let lastGroup = ''
    const out: ReactNode[] = []
    for (const n of NAV) {
      if (n.group && n.group !== lastGroup) {
        lastGroup = n.group
        out.push(
          <ListSubheader
            key={`group-${n.group}`}
            disableSticky
            sx={{
              bgcolor: 'transparent',
              color: 'text.secondary',
              fontSize: '0.68rem',
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
              lineHeight: 2.4,
            }}
          >
            {n.group}
          </ListSubheader>,
        )
      }
      out.push(
        <ListItemButton
          key={n.id}
          selected={view === n.id}
          // Coming Soon entries are inert: their data source is not wired yet, and the
          // illustrative seed data that used to fill them was removed in Phase 0.
          disabled={n.comingSoon}
          onClick={() => {
            if (n.comingSoon) return
            setView(n.id)
            setMobileOpen(false)
          }}
          sx={{
            mx: 1,
            borderRadius: 1.5,
            '&.Mui-selected': {
              bgcolor: alpha(theme.palette.primary.main, 0.28),
              color: 'text.primary',
              '&:hover': { bgcolor: alpha(theme.palette.primary.main, 0.38) },
            },
          }}
        >
          <ListItemIcon
            sx={{ minWidth: 38, color: view === n.id ? 'text.primary' : 'text.secondary' }}
          >
            {n.icon}
          </ListItemIcon>
          <ListItemText primary={n.label} slotProps={{ primary: { sx: { fontSize: '0.9rem' } } }} />
          {n.comingSoon && (
            <Chip
              size="small"
              variant="outlined"
              label="Coming Soon"
              sx={{ height: 19, fontSize: '0.6rem', ml: 0.5 }}
            />
          )}
        </ListItemButton>,
      )
    }
    return out
  }

  const drawerContent = (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 2 }}>
        <Box
          component="img"
          src="/sentry-logo.png"
          alt="AzureSentry"
          sx={{
            width: 48,
            height: 48,
            borderRadius: 1.5,
            objectFit: 'contain',
            bgcolor: '#1E1F1E',
            flexShrink: 0,
          }}
        />
        <Box sx={{ minWidth: 0 }}>
          <Typography sx={{ fontWeight: 700, lineHeight: 1.15 }}>AzureSentry</Typography>
          <Typography variant="caption" color="text.secondary">
            RBAC / PIM Agentic Platform
          </Typography>
        </Box>
      </Box>
      {/* FR5 — Inception42 alongside AzureSentry. */}
      <Box sx={{ px: 2, pb: 1.5, display: 'flex', alignItems: 'center' }}>
        <Box
          component="img"
          src="/inception42-text-logo-rebranded.png"
          alt="Inception42"
          sx={{ height: 24, objectFit: 'contain', mixBlendMode: 'multiply' }}
        />
      </Box>
      <Divider />
      <List sx={{ flexGrow: 1, overflowY: 'auto', py: 1 }}>{renderNav()}</List>
      <Divider />
      <Box sx={{ p: 1.5, display: 'flex', alignItems: 'center', gap: 1 }}>
        <CircleIcon sx={{ fontSize: 11, color: connected ? 'success.main' : 'error.main' }} />
        <Typography variant="caption" color="text.secondary" sx={{ flexGrow: 1 }}>
          {connected ? 'API connected' : 'API offline'}
        </Typography>
        <Button
          size="small"
          variant="outlined"
          startIcon={<RefreshIcon />}
          disabled={refreshing}
          onClick={() => refresh()}
        >
          {refreshing ? '…' : 'Refresh'}
        </Button>
      </Box>
    </Box>
  )

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      <AppBar position="fixed" sx={{ zIndex: theme.zIndex.drawer + 1 }}>
        <Toolbar>
          {!isDesktop && (
            <IconButton edge="start" onClick={() => setMobileOpen(true)} aria-label="Open navigation" sx={{ mr: 1 }}>
              <MenuIcon />
            </IconButton>
          )}
          <Box
            component="img"
            src="/inception42-logo.png"
            alt=""
            sx={{
              width: 32,
              height: 32,
              mr: 1.25,
              objectFit: 'contain',
              mixBlendMode: 'multiply',
              display: { xs: 'none', sm: 'block' },
            }}
          />
          <Typography variant="h6" sx={{ fontWeight: 700 }}>
            {current?.label ?? 'AzureSentry'}
          </Typography>
          <Box sx={{ flexGrow: 1 }} />
          <Box
            component="img"
            src="/g42logo.png"
            alt="G42"
            sx={{
              height: 28,
              objectFit: 'contain',
              mixBlendMode: 'multiply',
              display: { xs: 'none', md: 'block' },
            }}
          />
        </Toolbar>
      </AppBar>

      <Box component="nav" sx={{ width: { md: DRAWER_WIDTH }, flexShrink: { md: 0 } }}>
        {isDesktop ? (
          <Drawer
            variant="permanent"
            open
            sx={{ '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' } }}
          >
            <Toolbar />
            {drawerContent}
          </Drawer>
        ) : (
          <Drawer
            variant="temporary"
            open={mobileOpen}
            onClose={() => setMobileOpen(false)}
            ModalProps={{ keepMounted: true }}
            sx={{ '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' } }}
          >
            {drawerContent}
          </Drawer>
        )}
      </Box>

      <Box component="main" sx={{ flexGrow: 1, width: { md: `calc(100% - ${DRAWER_WIDTH}px)` } }}>
        <Toolbar />
        <Container maxWidth="xl" sx={{ py: 3 }}>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          {view === 'overview' && (
            <>
              <PageHeader
                title="Platform Overview"
                subtitle="All ManageEngine tickets across departments — volume, categories, and agent action states"
              />
              <EnforceModeMismatchBanner refreshToken={pollerReaperRefreshToken} />
              <PollerStatusPanel
                onModeChanged={() => setPollerReaperRefreshToken((t) => t + 1)}
              />
              <ReaperStatusPanel
                onModeChanged={() => setPollerReaperRefreshToken((t) => t + 1)}
              />
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
                  gap: 2,
                  mb: 3,
                }}
              >
                <StatCard label="All Tickets" value={ticketAnalytics?.totalTickets ?? 0} />
                <StatCard
                  label="Today"
                  value={ticketAnalytics?.dailyCount ?? 0}
                  color="secondary.main"
                />
                <StatCard
                  label="This Month"
                  value={ticketAnalytics?.monthlyCount ?? 0}
                  color="success.main"
                />
                <StatCard
                  label={ticketAnalytics?.idmQueueDisplay ?? formatIdentityLabel(ticketAnalytics?.idmQueue ?? 'IDM')}
                  value={ticketAnalytics?.totalIdmTickets ?? 0}
                  color="primary.main"
                />
              </Box>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', md: '1.2fr 1fr' },
                  gap: 2,
                  mb: 3,
                }}
              >
                <Card>
                  <CardHeader
                    title="Tickets by Department / Project"
                    subheader={
                      overviewDepartment === 'All'
                        ? 'Share of tickets by department/project — click a slice to filter'
                        : `Filtered: ${formatIdentityLabel(overviewDepartment)} — click again to clear`
                    }
                    action={
                      overviewDepartment !== 'All' ? (
                        <Button size="small" onClick={() => setOverviewDepartment('All')}>
                          Clear filter
                        </Button>
                      ) : undefined
                    }
                  />
                  <CardContent>
                    <SimpleDonutChart
                      selectedId={overviewDepartment === 'All' ? null : overviewDepartment}
                      onSelect={(id) => setOverviewDepartment(id ?? 'All')}
                      emptyLabel="No ManageEngine tickets loaded yet"
                      data={overviewDepartments.map(([department, count]) => ({
                        id: department,
                        label: formatIdentityLabel(department),
                        value: count,
                      }))}
                    />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader title="Volume by Department" subheader="Counts — click to filter" />
                  <CardContent>
                    <SimpleBarChart
                      selectedId={overviewDepartment === 'All' ? null : overviewDepartment}
                      onSelect={(id) => setOverviewDepartment(id ?? 'All')}
                      emptyLabel="No department data yet"
                      data={overviewDepartments.slice(0, 10).map(([department, count]) => ({
                        id: department,
                        label: formatIdentityLabel(department),
                        value: count,
                      }))}
                    />
                  </CardContent>
                </Card>
              </Box>
              <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1.5 }}>
                Agent action states
              </Typography>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
                  gap: 2,
                  mb: 3,
                }}
              >
                <StatCard
                  label="Evaluated"
                  value={ticketAnalytics?.agentActionStates.Evaluated ?? stats?.Total ?? 0}
                />
                <StatCard
                  label="Granted"
                  value={ticketAnalytics?.agentActionStates.Granted ?? stats?.Grant ?? 0}
                  color="success.main"
                />
                <StatCard
                  label="Eligible"
                  value={ticketAnalytics?.agentActionStates.Eligible ?? stats?.Eligible ?? 0}
                  color="secondary.main"
                />
                <StatCard
                  label="Rejected"
                  value={ticketAnalytics?.agentActionStates.Rejected ?? stats?.Reject ?? 0}
                  color="error.main"
                />
                <StatCard
                  label="Hold"
                  value={ticketAnalytics?.agentActionStates.Hold ?? stats?.Hold ?? 0}
                  color="warning.main"
                />
                <StatCard
                  label="Break-Glass"
                  value={ticketAnalytics?.agentActionStates.BreakGlass ?? stats?.BreakGlass ?? 0}
                  color="secondary.main"
                />
              </Box>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
                  gap: 2,
                  mb: 2,
                }}
              >
                <Card>
                  <CardHeader
                    title="Tickets by Environment"
                    subheader="Dropdown + rules only, no LLM — a live estimate."
                  />
                  <CardContent>
                    <SimpleBarChart
                      data={[
                        { label: 'Production', value: ticketAnalytics?.byEnvironment?.Production ?? 0 },
                        { label: 'Non-Prod', value: ticketAnalytics?.byEnvironment?.NonProd ?? 0 },
                        { label: 'Sandbox', value: ticketAnalytics?.byEnvironment?.Sandbox ?? 0 },
                        { label: 'Unknown', value: ticketAnalytics?.byEnvironment?.Unknown ?? 0 },
                      ]}
                      emptyLabel="No ManageEngine tickets loaded yet"
                    />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader title="Tickets by Category" />
                  <CardContent>
                    <SimpleBarChart
                      data={Object.entries(ticketAnalytics?.byCategory ?? {}).map(([label, value]) => ({
                        label,
                        value,
                      }))}
                      emptyLabel="No category data yet"
                    />
                  </CardContent>
                </Card>
              </Box>
              <Card sx={{ mb: 2 }}>
                <CardHeader
                  title={
                    overviewDepartment === 'All'
                      ? 'All ManageEngine Ticket Details'
                      : `${formatIdentityLabel(overviewDepartment)} Ticket Details`
                  }
                  subheader={`${filteredOverviewTickets.length} matching ticket${
                    filteredOverviewTickets.length === 1 ? '' : 's'
                  } · ordered by effective criticality (Prod → Non-Prod → Sandbox, then priority) · drill down by department/project, category, environment, and ticket type`}
                />
                <CardContent>
                  <Box
                    sx={{
                      display: 'grid',
                      gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(180px, 1fr))', md: 'repeat(4, minmax(160px, 1fr))' },
                      gap: 1.5,
                      mb: 2,
                    }}
                  >
                    <TextField
                      select
                      size="small"
                      label="Department / Project"
                      value={overviewDepartment}
                      onChange={(event) => setOverviewDepartment(event.target.value)}
                    >
                      <MenuItem value="All">All departments</MenuItem>
                      {overviewDepartments.map(([department, count]) => (
                        <MenuItem key={department} value={department}>
                          {formatIdentityLabel(department)} ({count})
                        </MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      select
                      size="small"
                      label="Ticket Category"
                      value={overviewCategory}
                      onChange={(event) => setOverviewCategory(event.target.value)}
                    >
                      <MenuItem value="All">All categories</MenuItem>
                      {Object.entries(ticketAnalytics?.byCategory ?? {}).map(([category, count]) => (
                        <MenuItem key={category} value={category}>
                          {category.replaceAll('-', ' ')} ({count})
                        </MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      select
                      size="small"
                      label="Environment"
                      value={overviewEnvironment}
                      onChange={(event) => setOverviewEnvironment(event.target.value)}
                    >
                      <MenuItem value="All">All environments</MenuItem>
                      {['Production', 'NonProd', 'Sandbox', 'Unknown'].map((environment) => (
                        <MenuItem key={environment} value={environment}>
                          {environment === 'NonProd' ? 'Non-Prod' : environment}
                        </MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      select
                      size="small"
                      label="Ticket type"
                      value={overviewTicketType}
                      onChange={(event) => setOverviewTicketType(event.target.value)}
                    >
                      <MenuItem value="All">All types</MenuItem>
                      {overviewTicketTypes.map((type) => (
                        <MenuItem key={type} value={type}>
                          {type}
                        </MenuItem>
                      ))}
                    </TextField>
                  </Box>

                  {filteredOverviewTickets.length === 0 ? (
                    <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
                      No tickets match the selected filters.
                    </Typography>
                  ) : (
                    <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 440 }}>
                      <Table stickyHeader size="small" aria-label="ManageEngine ticket drill-down">
                        <TableHead>
                          <TableRow>
                            <TableCell>Ticket</TableCell>
                            <TableCell>Subject</TableCell>
                            <TableCell>Ticket type</TableCell>
                            <TableCell>Department / Project</TableCell>
                            <TableCell>Category</TableCell>
                            <TableCell>Environment</TableCell>
                            <TableCell>Criticality</TableCell>
                            <TableCell>Status</TableCell>
                            <TableCell>Priority</TableCell>
                            <TableCell>Requester</TableCell>
                            <TableCell>Created</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {filteredOverviewTickets.map((item) => (
                            <TableRow hover key={item.id}>
                              <TableCell>
                                <Box component="strong">#{item.id}</Box>
                              </TableCell>
                              <TableCell sx={{ minWidth: 260 }}>{item.subject || '—'}</TableCell>
                              <TableCell sx={{ minWidth: 140 }}>
                                <Chip
                                  size="small"
                                  variant="outlined"
                                  label={item.ticketType || 'Unspecified'}
                                  sx={{ height: 22, fontWeight: 600, fontSize: '0.7rem', borderRadius: 1 }}
                                />
                              </TableCell>
                              <TableCell sx={{ minWidth: 180 }}>
                                <Typography variant="body2">{formatIdentityLabel(item.department)}</Typography>
                                {item.project !== item.department && (
                                  <Typography variant="caption" color="text.secondary">
                                    {item.project}
                                  </Typography>
                                )}
                              </TableCell>
                              <TableCell>
                                <StatusPill
                                  tone={
                                    item.category === 'Access-Related'
                                      ? 'ok'
                                      : item.category === 'Environment-Issue'
                                        ? 'warn'
                                        : item.category === 'Break-Glass'
                                          ? 'bad'
                                          : 'neutral'
                                  }
                                  label={item.category.replaceAll('-', ' ')}
                                />
                              </TableCell>
                              <TableCell sx={{ minWidth: 120 }}>
                                <Typography variant="body2">
                                  {item.environment === 'NonProd' ? 'Non-Prod' : item.environment}
                                </Typography>
                                {item.environmentInferred && (
                                  <Typography variant="caption" color="warning.main">
                                    inferred from text
                                  </Typography>
                                )}
                                {item.environmentSource === 'None' && (
                                  <Typography variant="caption" color="error.main">
                                    untagged
                                  </Typography>
                                )}
                              </TableCell>
                              <TableCell sx={{ minWidth: 130 }}>
                                <StatusPill
                                  tone={CRITICALITY_TONE[item.criticalityTier ?? 'Unclassified'] ?? 'neutral'}
                                  label={item.criticalityTier ?? 'Unclassified'}
                                />
                              </TableCell>
                              <TableCell>{item.status}</TableCell>
                              <TableCell sx={{ minWidth: 110 }}>
                                <Typography variant="body2">{item.priority}</Typography>
                                {item.priorityDemoted && (
                                  <Tooltip title="A high priority claimed outside Production orders the ticket within its own environment band — it cannot outrank a Production ticket.">
                                    <Typography variant="caption" color="text.secondary">
                                      band-limited
                                    </Typography>
                                  </Tooltip>
                                )}
                              </TableCell>
                              <TableCell sx={{ minWidth: 160 }}>{item.requester}</TableCell>
                              <TableCell sx={{ whiteSpace: 'nowrap' }}>{item.createdAt || '—'}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  )}
                </CardContent>
              </Card>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
                  gap: 2,
                  mb: 2,
                }}
              >
                <Card>
                  <CardHeader
                    title="Criticality Mix"
                    subheader="Environment sets the band — Prod → Non-Prod → Sandbox. Requester priority orders tickets inside a band only."
                  />
                  <CardContent>
                    <SimpleBarChart
                      emptyLabel="No ManageEngine tickets loaded yet"
                      data={[
                        { label: 'Critical (Production)', value: ticketAnalytics?.byCriticality?.Critical ?? 0 },
                        { label: 'High (Non-Prod)', value: ticketAnalytics?.byCriticality?.High ?? 0 },
                        { label: 'Standard (Sandbox)', value: ticketAnalytics?.byCriticality?.Standard ?? 0 },
                        { label: 'Unclassified (untagged)', value: ticketAnalytics?.byCriticality?.Unclassified ?? 0 },
                      ]}
                    />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader
                    title="Environment Tag Health"
                    subheader="A ticket without an environment cannot be prioritized — this is the governance backfill queue."
                  />
                  <CardContent>
                    <Stack spacing={1} sx={{ alignItems: 'flex-start' }}>
                      <StatusPill
                        tone="ok"
                        label={`${ticketAnalytics?.environmentTagHealth?.tagged ?? 0} tagged via the Environment dropdown`}
                      />
                      <StatusPill
                        tone="warn"
                        label={`${ticketAnalytics?.environmentTagHealth?.inferred ?? 0} inferred from ticket text`}
                      />
                      <StatusPill
                        tone="bad"
                        label={`${ticketAnalytics?.environmentTagHealth?.untagged ?? 0} untagged — no environment signal`}
                      />
                      <StatusPill
                        tone="neutral"
                        label={`${ticketAnalytics?.environmentTagHealth?.notApplicable ?? 0} not applicable — template has no Environment field`}
                      />
                    </Stack>
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1.5 }}>
                      Environment is mandatory on all four structured templates as of
                      2026-08-18, so inferred/untagged rows here are pre-cutover backlog
                      only. Not-applicable tickets (General Access, Infrastructure, Report
                      an Issue, ...) are excluded from the environment chart entirely — they
                      have no Environment field to begin with.
                    </Typography>
                  </CardContent>
                </Card>
              </Box>
              <Card>
                <CardHeader
                  title="Recent Activity"
                  subheader="Live evaluations and grants only — demo seed excluded"
                />
                <CardContent>
                  {recentActivity.length === 0 ? (
                    <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
                      No live activity yet. Process a Help Desk ticket or run validation to populate this feed.
                    </Typography>
                  ) : (
                    <Stack spacing={1}>
                      {recentActivity.slice(0, 8).map((item) => (
                        <Paper
                          key={item.id}
                          variant="outlined"
                          sx={{
                            p: 1.25,
                            display: 'grid',
                            gridTemplateColumns: 'auto 1fr auto',
                            gap: 1.5,
                            alignItems: 'center',
                          }}
                        >
                          <ActionBadge action={item.action} />
                          <Box sx={{ minWidth: 0 }}>
                            <Typography variant="body2">
                              <strong>{item.ticketId}</strong> — {item.requester}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {item.environment} / {item.role} / {item.priority} → {item.path}
                            </Typography>
                          </Box>
                          <Typography variant="caption" color="text.secondary">
                            {new Date(item.timestamp).toLocaleTimeString()}
                          </Typography>
                        </Paper>
                      ))}
                    </Stack>
                  )}
                </CardContent>
              </Card>
            </>
          )}

          {view === 'livepim' && <LivePimView onChanged={refresh} />}
          {view === 'audit' && <AuditLogsView />}
          {view === 'expiry' && <ExpiryView />}

          {view === 'tickets' && (
            <>
              <PageHeader
                title="Execution Hub"
                subtitle="Where agents execute actions on tickets — access provisioning and department scope"
              />
              <Tabs
                value={hubTab}
                onChange={(_, next) => setHubTab(next as ExecutionHubTab)}
                sx={{ mb: 2, borderBottom: 1, borderColor: 'divider' }}
              >
                {EXECUTION_HUB_TABS.map((tab) => (
                  <Tab key={tab.id} value={tab.id} label={tab.label} />
                ))}
              </Tabs>
              {hubTab === 'queue' && <TicketsView />}
              {hubTab === 'scope' && <DepartmentScopeView />}
            </>
          )}

        </Container>
      </Box>
    </Box>
  )
}
