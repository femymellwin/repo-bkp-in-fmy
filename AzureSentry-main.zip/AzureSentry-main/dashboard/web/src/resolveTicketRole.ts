/** Resolve Azure role from ticket free text. Missing stays empty (no silent default). */
export function resolveTicketRole(text: string): {
  role: string
  warning?: string
} {
  const normalized = text.toLowerCase()
  if (/user access admin|\buaa\b/.test(normalized)) {
    return { role: 'UAA' }
  }
  if (/\bowner\b/.test(normalized)) {
    return { role: 'Owner' }
  }
  if (/\bwriter\b|write access/.test(normalized)) {
    return { role: 'Writer' }
  }
  if (/\bcontrib/.test(normalized)) {
    return { role: 'Contributor' }
  }
  // Require "reader" / "read-only" — bare "read" false-positives too easily.
  if (/\breader\b|\bread-only\b|\bread only\b/.test(normalized)) {
    return { role: 'Reader' }
  }
  return {
    role: '',
    warning:
      'Role was not supplied in the ticket. Role is required — ask the requester to include Reader, Contributor, or Writer.',
  }
}
