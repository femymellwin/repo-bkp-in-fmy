import type { MeAccessFields, METicket, TemplatePayload, TemplatePayloadCommon } from './types.ts'
import {
  extractMeAccessFields,
  ME_UDF_AZURE_ROLE,
  ME_UDF_BUSINESS_JUSTIFICATION,
  ME_UDF_ENVIRONMENT,
  ME_UDF_EXCEPTION_REQUEST,
  ME_UDF_SUBSCRIPTION,
} from './extractMeAccessFields.ts'
import { lookupTemplateSchema, normalizeTemplateName } from './ticketTemplateSchemas.ts'
import { ticketTypeLabel, UNSPECIFIED_TICKET_TYPE } from './ticketTypeLabel.ts'

/** Lowercased ME label → canonical schema field name. */
const FIELD_LABEL_ALIASES: Record<string, string> = {
  'protocol (tpc/udp)': 'Protocol (TCP/UDP)',
  'azure role': 'Azure Role',
  'exception request': 'Exception Request',
  'request type': 'Request Type',
  'business justification': 'Business Justification',
  'source ip': 'Source IP',
  'destination ip': 'Destination IP',
  'access direction': 'Access Direction',
  'source ip description': 'Source IP Description',
  'destination ip description': 'Destination IP Description',
  'access type': 'Access Type',
}

function pickName(value: unknown): string {
  if (value == null) return ''
  if (typeof value === 'string' || typeof value === 'number') return String(value).trim()
  if (typeof value === 'object' && value !== null) {
    const obj = value as Record<string, unknown>
    for (const key of ['name', 'value', 'display_value', 'displayValue'] as const) {
      const n = obj[key]
      if (typeof n === 'string' && n.trim()) return n.trim()
      if (typeof n === 'number') return String(n).trim()
    }
  }
  return ''
}

function isUnspecified(value: string): boolean {
  const v = value.trim().toLowerCase()
  return !v || v === 'not specified' || v === 'n/a' || v === 'na' || v === '-' || v === 'none'
}

function stripHtml(s?: string): string {
  return (s ?? '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim()
}

function canonicalFieldLabel(rawLabel: string): string {
  const trimmed = rawLabel.trim()
  if (!trimmed) return ''
  const alias = FIELD_LABEL_ALIASES[trimmed.toLowerCase()]
  return alias ?? trimmed
}

/**
 * Flatten ManageEngine udf_fields into label → value (labels lowercased as map keys).
 * Supports:
 * - `{ "Source IP": "10.0.0.1" }`
 * - `{ key: { label: "Source IP", name: "10.0.0.1" } }`
 * - `{ key: { name: "Reader" } }` with no label (skipped for label map; Azure keys handled separately)
 */
export function flattenUdfByLabel(udf: unknown): Map<string, string> {
  const out = new Map<string, string>()
  if (!udf || typeof udf !== 'object') return out

  for (const [key, raw] of Object.entries(udf as Record<string, unknown>)) {
    if (raw == null) continue

    if (typeof raw === 'string' || typeof raw === 'number') {
      const label = canonicalFieldLabel(key)
      const value = String(raw).trim()
      if (label && !isUnspecified(value)) {
        out.set(label.toLowerCase(), value)
      }
      continue
    }

    if (typeof raw === 'object') {
      const obj = raw as Record<string, unknown>
      const labelRaw =
        (typeof obj.label === 'string' && obj.label) ||
        (typeof obj.field_label === 'string' && obj.field_label) ||
        (typeof obj.display_name === 'string' && obj.display_name) ||
        ''
      const label = canonicalFieldLabel(labelRaw || key)
      const value = pickName(raw)
      if (label && !isUnspecified(value)) {
        // Prefer explicit .label over using the UDF key as label when both exist
        const mapKey = canonicalFieldLabel(labelRaw || label).toLowerCase()
        if (mapKey && !out.has(mapKey)) {
          out.set(mapKey, value)
        } else if (mapKey) {
          out.set(mapKey, value)
        }
      }
    }
  }

  return out
}

function resolveTemplateName(ticket: METicket): string {
  const label = ticketTypeLabel(ticket)
  if (label === UNSPECIFIED_TICKET_TYPE) return ''
  return normalizeTemplateName(label)
}

function buildCommon(ticket: METicket): TemplatePayloadCommon {
  return {
    requesterName: ticket.requester?.name?.trim() ?? '',
    requesterEmail: ticket.requester?.email_id?.trim() ?? '',
    category: ticket.category?.name?.trim() ?? '',
    subcategory: ticket.subcategory?.name?.trim() ?? '',
    subject: (ticket.subject ?? '').trim(),
    description: stripHtml(ticket.description) || stripHtml(ticket.short_description),
    status: ticket.status?.name?.trim() ?? '',
  }
}

/**
 * Fill schema fields ME returns without labels, or as built-in ticket properties.
 * Label flatten alone misses: Environment / Exception Request (keyed UDFs with no
 * `.label`), Item / Request Type (top-level request fields, not udf_fields).
 */
function applyKnownFieldFallbacks(
  fields: Record<string, string>,
  ticket: METicket,
  accessFields?: MeAccessFields | null,
): void {
  const udf = ticket.udf_fields as Record<string, unknown> | undefined
  const fromKeys = extractMeAccessFields(ticket.udf_fields)

  const setIfEmpty = (field: string, raw: string) => {
    if (!(field in fields) || fields[field]) return
    const v = raw.trim()
    if (v && !isUnspecified(v)) fields[field] = v
  }

  if ('Environment' in fields) {
    setIfEmpty(
      'Environment',
      (accessFields?.Environment ?? '').trim() ||
        fromKeys.environment ||
        pickName(udf?.[ME_UDF_ENVIRONMENT]),
    )
  }
  if ('Exception Request' in fields) {
    setIfEmpty('Exception Request', pickName(udf?.[ME_UDF_EXCEPTION_REQUEST]))
  }
  if ('Business Justification' in fields) {
    setIfEmpty('Business Justification', pickName(udf?.[ME_UDF_BUSINESS_JUSTIFICATION]))
  }
  if ('Item' in fields) {
    setIfEmpty('Item', pickName(ticket.item))
  }
  if ('Request Type' in fields) {
    setIfEmpty('Request Type', pickName(ticket.request_type))
  }
  if ('Subscription' in fields) {
    setIfEmpty(
      'Subscription',
      (accessFields?.Subscription ?? '').trim() ||
        fromKeys.subscription ||
        pickName(udf?.[ME_UDF_SUBSCRIPTION]),
    )
  }
  if ('Azure Role' in fields) {
    setIfEmpty(
      'Azure Role',
      (accessFields?.AzureRole ?? '').trim() ||
        fromKeys.azureRole ||
        pickName(udf?.[ME_UDF_AZURE_ROLE]),
    )
  }
}

/**
 * Build a structured templatePayload from a ManageEngine ticket (+ optional accessFields).
 */
export function buildTemplatePayload(
  ticket: METicket,
  accessFields?: MeAccessFields | null,
): TemplatePayload {
  const templateName = resolveTemplateName(ticket)
  const displayName = templateName || UNSPECIFIED_TICKET_TYPE
  const schema = templateName ? lookupTemplateSchema(templateName) : null
  const common = buildCommon(ticket)
  const warnings: string[] = []

  if (!schema) {
    warnings.push('Unknown template schema')
    return {
      templateName: displayName,
      handler: 'none',
      knownSchema: false,
      common,
      fields: {},
      fieldOrder: [],
      requiredFields: [],
      requiredPlaceholders: [],
      warnings,
    }
  }

  const byLabel = flattenUdfByLabel(ticket.udf_fields)
  const fields: Record<string, string> = {}
  for (const field of schema.fields) {
    const fromMap = byLabel.get(field.toLowerCase()) ?? ''
    fields[field] = fromMap
  }

  // Keyed UDFs (no label) + built-in Item / Request Type — all handlers, not just Azure.
  applyKnownFieldFallbacks(fields, ticket, accessFields)

  return {
    templateName: schema.canonicalName,
    handler: schema.handler,
    knownSchema: true,
    common,
    fields,
    fieldOrder: [...schema.fields],
    requiredFields: [],
    requiredPlaceholders: [],
    warnings,
  }
}
