export type TemplateHandler = 'azure-subscription-grant' | 'pending'

export interface TemplateSchema {
  canonicalName: string
  handler: TemplateHandler
  /** Template-specific fields only — common fields are never listed here. */
  fields: string[]
}

/** Lowercased alias → canonical display name. */
export const TEMPLATE_NAME_ALIASES: Record<string, string> = {
  'security assesment': 'Security Assessment',
  'report and issue template': 'Report and Issue',
  'other request template': 'Other Request',
  'soc template': 'SOC',
}

const SCHEMAS: TemplateSchema[] = [
  { canonicalName: '1Password', handler: 'pending', fields: ['Item'] },
  { canonicalName: 'Cursor', handler: 'pending', fields: [] },
  {
    canonicalName: 'GitHub Enterprise',
    handler: 'pending',
    fields: ['Environment', 'Item', 'Exception Request', 'Request Type'],
  },
  {
    canonicalName: 'Azure Subscription',
    handler: 'azure-subscription-grant',
    fields: [
      'Subscription',
      'Azure Role',
      'Environment',
    ],
  },
  {
    canonicalName: 'ADO',
    handler: 'pending',
    fields: ['Request Type', 'Item', 'Exception Request', 'Environment'],
  },
  {
    canonicalName: 'General Access',
    handler: 'pending',
    fields: ['Item', 'Business Justification'],
  },
  {
    canonicalName: 'Infrastructure',
    handler: 'pending',
    fields: ['Item', 'Business Justification'],
  },
  {
    canonicalName: 'Networking',
    handler: 'pending',
    fields: [
      'Request Type',
      'Source IP',
      'Destination IP',
      'Port',
      'Access Direction',
      'Item',
      'Source IP Description',
      'Destination IP Description',
      'Protocol (TCP/UDP)',
      'Access Type',
      'Business Justification',
    ],
  },
  { canonicalName: 'MLOps', handler: 'pending', fields: ['Item'] },
  {
    canonicalName: 'Policy Exemptions',
    handler: 'pending',
    fields: ['Item', 'Business Justification'],
  },
  {
    canonicalName: 'New Project',
    handler: 'pending',
    fields: ['Item', 'Business Justification'],
  },
  {
    canonicalName: 'Cortex',
    handler: 'pending',
    fields: ['Item', 'Environment', 'Request Type'],
  },
  {
    canonicalName: 'Infosec',
    handler: 'pending',
    fields: ['Item', 'Business Justification'],
  },
  { canonicalName: 'Security Assessment', handler: 'pending', fields: [] },
  {
    canonicalName: 'DevOps Access',
    handler: 'pending',
    fields: ['Item', 'Business Justification', 'Request Type'],
  },
  { canonicalName: 'Report and Issue', handler: 'pending', fields: [] },
  { canonicalName: 'Other Request', handler: 'pending', fields: [] },
  { canonicalName: 'SOC', handler: 'pending', fields: [] },
]

const BY_KEY = new Map<string, TemplateSchema>()
for (const schema of SCHEMAS) {
  BY_KEY.set(schema.canonicalName.toLowerCase(), schema)
}

/**
 * Trim and strip a trailing " Template" suffix (ManageEngine sometimes appends it).
 */
export function normalizeTemplateName(raw: string): string {
  let name = (raw ?? '').trim()
  if (!name) return ''
  name = name.replace(/\s+template$/i, '').trim()
  return name
}

/**
 * Resolve a ManageEngine template name to a known schema, or null if unknown.
 */
export function lookupTemplateSchema(templateName: string): TemplateSchema | null {
  const normalized = normalizeTemplateName(templateName)
  if (!normalized) return null

  const lower = normalized.toLowerCase()
  const aliasTarget = TEMPLATE_NAME_ALIASES[lower]
  if (aliasTarget) {
    return BY_KEY.get(aliasTarget.toLowerCase()) ?? null
  }

  // Also try alias on the raw (pre-strip) form for entries that include " Template".
  const rawLower = (templateName ?? '').trim().toLowerCase()
  const rawAlias = TEMPLATE_NAME_ALIASES[rawLower]
  if (rawAlias) {
    return BY_KEY.get(rawAlias.toLowerCase()) ?? null
  }

  return BY_KEY.get(lower) ?? null
}

/** All registered schemas (for tests / diagnostics). */
export function listTemplateSchemas(): TemplateSchema[] {
  return [...SCHEMAS]
}
