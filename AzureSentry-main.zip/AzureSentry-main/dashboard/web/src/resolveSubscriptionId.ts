export interface SubscriptionCatalogEntry {
  id: string
  label: string
  aliases?: string[]
}

export function normalizeTicketText(s: string): string {
  return s
    .toLowerCase()
    .replace(/subscriptioin/g, 'subscription')
    .replace(/[^a-z0-9\-_.@\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

export function compactTicketText(s: string): string {
  return normalizeTicketText(s).replace(/[\s_\-]+/g, '')
}

function catalogCandidates(catalog: SubscriptionCatalogEntry[]): Array<{ id: string; alias: string }> {
  const cands: Array<{ id: string; alias: string }> = []
  for (const e of catalog) {
    cands.push({ id: e.id, alias: e.label })
    const bare = e.label.split('(')[0].trim()
    if (bare && bare.toLowerCase() !== e.label.toLowerCase()) cands.push({ id: e.id, alias: bare })
    for (const a of e.aliases ?? []) cands.push({ id: e.id, alias: a })
  }
  cands.sort((a, b) => b.alias.length - a.alias.length)
  return cands
}

/** Match a ManageEngine Subscription dropdown value to a live allowlist GUID. */
export function matchSubscriptionNameToCatalog(
  name: string,
  catalog: SubscriptionCatalogEntry[],
): { id: string; matchedBy: string } | null {
  const needle = normalizeTicketText(name)
  const needleCompact = compactTicketText(name)
  if (!needle) return null

  for (const c of catalogCandidates(catalog)) {
    const alias = normalizeTicketText(c.alias)
    if (alias.length < 3) continue
    if (needle === alias || needle.includes(alias) || alias.includes(needle)) {
      return { id: c.id, matchedBy: `name "${c.alias}"` }
    }
    const aliasCompact = compactTicketText(c.alias)
    if (
      aliasCompact.length >= 6 &&
      (needleCompact === aliasCompact ||
        needleCompact.includes(aliasCompact) ||
        aliasCompact.includes(needleCompact))
    ) {
      return { id: c.id, matchedBy: `name "${c.alias}"` }
    }
  }
  return null
}

export interface TicketSubscriptionResolution {
  subscriptionId: string
  /** Raw ManageEngine "Subscription" value (empty → UI shows missing). */
  subscriptionType: string
  source: 'udf' | 'guid' | 'text' | null
  matchedBy?: string
}

/**
 * Resolve subscription from ME template "Subscription" field + live allowlist catalog.
 */
export function resolveTicketSubscription(args: {
  meSubscription: string
  text?: string
  catalog: SubscriptionCatalogEntry[]
}): TicketSubscriptionResolution {
  const { meSubscription, text = '', catalog } = args

  const guid = `${meSubscription} ${text}`.match(
    /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i,
  )?.[0]
  if (guid) {
    const id = guid.toLowerCase()
    const label = catalog.find((c) => c.id.toLowerCase() === id)?.label ?? id
    return {
      subscriptionId: id,
      subscriptionType: meSubscription || label.split('(')[0].trim() || id,
      source: 'guid',
      matchedBy: `GUID ${id}`,
    }
  }

  if (meSubscription) {
    const hit = matchSubscriptionNameToCatalog(meSubscription, catalog)
    if (hit) {
      return {
        subscriptionId: hit.id,
        subscriptionType: meSubscription,
        source: 'udf',
        matchedBy: hit.matchedBy,
      }
    }
    // ME named it but allowlist has no GUID yet — keep the name for the single field UI.
    return {
      subscriptionId: '',
      subscriptionType: meSubscription,
      source: 'udf',
      matchedBy: 'unmapped ManageEngine subscription',
    }
  }

  // No ME Subscription field — leave empty so UI shows "missing" + dropdown.
  return { subscriptionId: '', subscriptionType: '', source: null }
}

export function ensureSubscriptionInCatalog(
  catalog: SubscriptionCatalogEntry[],
  subscriptionId: string,
  preferredLabel?: string,
): SubscriptionCatalogEntry[] {
  if (!subscriptionId) return catalog
  if (catalog.some((e) => e.id === subscriptionId)) return catalog
  const label = preferredLabel?.trim() || subscriptionId
  return [{ id: subscriptionId, label, aliases: [label] }, ...catalog]
}

/** Dropdown options from the live MG allowlist — name + Azure GUID. */
export function buildAllowlistSelectOptions(
  allowlist: SubscriptionCatalogEntry[],
): Array<{ value: string; label: string }> {
  const seen = new Set<string>()
  const options: Array<{ value: string; label: string }> = []
  for (const e of allowlist) {
    const id = e.id.trim()
    if (!id || seen.has(id.toLowerCase())) continue
    seen.add(id.toLowerCase())
    const bare = e.label.split('(')[0].trim() || e.label || id
    options.push({
      value: id,
      label: `${bare} (${id})`,
    })
  }
  return options.sort((a, b) => a.label.localeCompare(b.label))
}

/** Display names from live allowlist entries (for matching ME subscription type). */
export function allowlistDisplayNames(allowlist: SubscriptionCatalogEntry[]): string[] {
  return allowlist
    .map((e) => e.label.split('(')[0].trim() || e.label)
    .filter(Boolean)
}

