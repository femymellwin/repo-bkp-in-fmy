import { createTheme } from '@mui/material/styles'

type DecisionKey = 'grant' | 'eligible' | 'reject' | 'hold' | 'breakglass'

declare module '@mui/material/styles' {
  interface Palette {
    decision: Record<DecisionKey, string>
  }
  interface PaletteOptions {
    decision?: Record<DecisionKey, string>
  }
}

const GREEN = '#91FF01'
const PURPLE = '#AE74FF'
const SLATE = '#1E1F1E'
const OFF_WHITE = '#FBF8FF'
const GREY = '#C2C8D6'

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: GREEN, contrastText: SLATE },
    secondary: { main: PURPLE, contrastText: SLATE },
    background: { default: OFF_WHITE, paper: '#FFFFFF' },
    text: { primary: SLATE, secondary: '#5F6570' },
    divider: GREY,
    success: { main: GREEN, dark: '#3D7A00', contrastText: SLATE },
    warning: { main: '#C67A12' },
    error: { main: '#D14343' },
    info: { main: PURPLE, contrastText: SLATE },
    decision: {
      grant: GREEN,
      eligible: PURPLE,
      reject: '#D14343',
      hold: '#C67A12',
      breakglass: PURPLE,
    },
  },
  shape: { borderRadius: 10 },
  typography: {
    fontFamily: "'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif",
    button: { textTransform: 'none', fontWeight: 600 },
  },
  components: {
    MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
    MuiCard: {
      defaultProps: { elevation: 0 },
      styleOverrides: {
        root: ({ theme }) => ({ border: `1px solid ${theme.palette.divider}` }),
      },
    },
    MuiCardHeader: {
      defaultProps: {
        slotProps: { title: { variant: 'subtitle1', sx: { fontWeight: 600 } } },
      },
    },
    MuiAppBar: {
      defaultProps: { elevation: 0, color: 'inherit' },
      styleOverrides: {
        root: ({ theme }) => ({
          backgroundColor: theme.palette.background.paper,
          borderBottom: `1px solid ${theme.palette.divider}`,
        }),
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: ({ theme }) => ({ borderColor: theme.palette.divider }),
      },
    },
    MuiButton: { defaultProps: { disableElevation: true } },
    MuiChip: {
      // MUI v9 has no combined `outlinedSuccess` / `filledPrimary` styleOverrides keys --
      // variant and colour are separate classes (`outlined`/`filled` x `colorSuccess`/
      // `colorPrimary`), so those keys were rejected by tsc and broke `npm run build`
      // (`tsc -b && vite build`). Deploy-ToVm.ps1 runs that build, so a stale dist/ was
      // shipping. Targeting the real class pairs keeps the intended styling.
      styleOverrides: {
        root: {
          '&.MuiChip-outlined.MuiChip-colorSuccess, &.MuiChip-outlined.MuiChip-colorPrimary': {
            color: SLATE,
            borderColor: GREEN,
          },
          '&.MuiChip-filled.MuiChip-colorSuccess, &.MuiChip-filled.MuiChip-colorPrimary': {
            backgroundColor: GREEN,
            color: SLATE,
          },
        },
      },
    },
  },
})

export default theme
