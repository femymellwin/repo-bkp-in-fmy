export interface RevokeUiState {
  phase: 'revoking' | 'revoked' | 'failed'
  message: string
}

export function successfulRevokeState(requesterNotified: boolean): RevokeUiState {
  return {
    phase: 'revoked',
    message: requesterNotified
      ? 'Access revoked and requester notified.'
      : 'Access revoked. The requester notification was not confirmed.',
  }
}

export function failedRevokeState(error: unknown): RevokeUiState {
  return {
    phase: 'failed',
    message: error instanceof Error ? error.message : 'Revocation failed.',
  }
}
