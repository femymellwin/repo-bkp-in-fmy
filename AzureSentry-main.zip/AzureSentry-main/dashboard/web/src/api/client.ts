import type {
  ActivationResult,
  ActiveAssignment,
  ActivityFilters,
  ActivityItem,
  AgentDefinition,
  AllowlistSubscription,
  AssignmentsResponse,
  AuditEvent,
  AuditFilters,
  AuditSummary,
  BreakGlassResponse,
  CategorizationReport,
  DepartmentScope,
  EligibleRole,
  SubscriptionResolution,
  EvaluateResult,
  MatrixRow,
  MERequestsResponse,
  METicket,
  MeAccessFields,
  PimContext,
  PollerStatus,
  Preset,
  ProcessedSummary,
  ProcessResult,
  ReaperStatus,
  RevokeResult,
  SlaMetrics,
  Stats,
  TicketAnalytics,
  TicketSummary,
  TemplatePayload,
} from '../types'

const API = '/api'

function qs(params: Record<string, string | number | undefined>): string {
  const parts = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
  return parts.length ? `?${parts.join('&')}` : ''
}

async function fetchJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error((err as { error?: string }).error ?? 'Request failed')
  }
  return res.json() as Promise<T>
}

export const api = {
  health: () => fetchJson<{ status: string; service: string }>('/health'),
  stats: () => fetchJson<{ stats: Stats; recentCount: number }>('/stats'),
  activity: (filters?: ActivityFilters) =>
    fetchJson<{ items: ActivityItem[]; total: number }>(
      `/activity${qs((filters ?? {}) as Record<string, string | number | undefined>)}`,
    ),
  sla: () => fetchJson<SlaMetrics>('/sla'),
  assignments: () => fetchJson<AssignmentsResponse>('/assignments'),
  breakglass: () => fetchJson<BreakGlassResponse>('/breakglass'),
  poller: {
    status: () => fetchJson<PollerStatus>('/poller/status'),
    setMode: (mode: 'enforce' | 'shadow', justification?: string) =>
      fetchJson<{ ok: boolean; mode: string; filePath: string; note: string }>('/poller/mode', {
        method: 'POST',
        body: JSON.stringify({ mode, justification }),
      }),
    clearMode: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/poller/mode', {
        method: 'DELETE',
      }),
    setEnabled: (enabled: boolean, justification?: string) =>
      fetchJson<{ ok: boolean; enabled: boolean; filePath: string; note: string }>(
        '/poller/enabled',
        { method: 'POST', body: JSON.stringify({ enabled, justification }) },
      ),
    clearEnabled: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/poller/enabled', {
        method: 'DELETE',
      }),
    setCaps: (
      caps: { maxGrants?: number; maxTickets?: number; maxAgeDays?: number },
      justification?: string,
    ) =>
      fetchJson<{
        ok: boolean
        caps: { maxGrants: number; maxTickets: number; maxAgeDays: number }
        filePath: string
      }>('/poller/caps', { method: 'POST', body: JSON.stringify({ ...caps, justification }) }),
    clearCaps: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/poller/caps', {
        method: 'DELETE',
      }),
  },
  reaper: {
    status: () => fetchJson<ReaperStatus>('/reaper/status'),
    setMode: (mode: 'enforce' | 'shadow', justification?: string) =>
      fetchJson<{ ok: boolean; mode: string; filePath: string; note: string }>('/reaper/mode', {
        method: 'POST',
        body: JSON.stringify({ mode, justification }),
      }),
    clearMode: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/reaper/mode', {
        method: 'DELETE',
      }),
    setEnabled: (enabled: boolean, justification?: string) =>
      fetchJson<{ ok: boolean; enabled: boolean; filePath: string; note: string }>(
        '/reaper/enabled',
        { method: 'POST', body: JSON.stringify({ enabled, justification }) },
      ),
    clearEnabled: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/reaper/enabled', {
        method: 'DELETE',
      }),
    setCaps: (caps: { maxRevokes?: number }, justification?: string) =>
      fetchJson<{ ok: boolean; caps: { maxRevokes: number }; filePath: string }>('/reaper/caps', {
        method: 'POST',
        body: JSON.stringify({ ...caps, justification }),
      }),
    clearCaps: () =>
      fetchJson<{ ok: boolean; cleared: boolean; filePath: string }>('/reaper/caps', {
        method: 'DELETE',
      }),
  },
  matrix: () => fetchJson<{ rows: MatrixRow[]; slaTiers: Record<string, unknown> }>('/matrix'),
  presets: () =>
    fetchJson<{ presets: Preset[]; subscriptions?: AllowlistSubscription[] }>('/presets'),
  allowlist: () =>
    fetchJson<{
      subscriptions: string[]
      details: Array<{ id: string; name: string; state?: string }>
      source: string
    }>('/allowlist'),
  evaluate: (ticket: Record<string, unknown>) =>
    fetchJson<EvaluateResult>('/evaluate', {
      method: 'POST',
      body: JSON.stringify(ticket),
    }),
  manageEngine: {
    requests: (page?: number) =>
      fetchJson<MERequestsResponse>(`/manageengine/requests${qs({ page })}`),
    request: (id: number) =>
      fetchJson<{
        request: METicket
        accessFields?: MeAccessFields
        templatePayload?: TemplatePayload
      }>(`/manageengine/requests/${id}`),
    process: (meTicketId: number, ticket: Record<string, unknown>) =>
      fetchJson<ProcessResult>('/manageengine/process', {
        method: 'POST',
        body: JSON.stringify({
          meTicketId,
          ticket,
          templateName: ticket.templateName,
          templateHandler: ticket.templateHandler,
        }),
      }),
    revoke: (meTicketId: number, justification?: string) =>
      fetchJson<RevokeResult>('/manageengine/revoke', {
        method: 'POST',
        body: JSON.stringify({ meTicketId, justification }),
      }),
    processed: () => fetchJson<{ items: ProcessedSummary[] }>('/manageengine/processed'),
    analytics: () => fetchJson<TicketAnalytics>('/manageengine/analytics'),
    summarize: (payload: {
      subject?: string
      description?: string
      short_description?: string
      requester?: string
    }) =>
      fetchJson<TicketSummary>('/manageengine/summarize', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
  },
  // FR3 — what the platform actually consists of: discrete, named agents.
  agents: () =>
    fetchJson<{
      agents: AgentDefinition[]
      runCounts: Record<string, number>
      scope?: DepartmentScope
    }>('/agents'),
  // FR6 — immutable audit trail.
  audit: (filters?: AuditFilters) =>
    fetchJson<{ events: AuditEvent[]; summary: AuditSummary; logAnalytics?: { configured: boolean } }>(
      `/audit${qs((filters ?? {}) as Record<string, string | number | undefined>)}`,
    ),
  auditIntegrity: () =>
    fetchJson<{ ok: boolean; checked: number; reason: string }>('/audit/integrity'),
  // FR4 — department scope categorization. The FR2 environment-backfill endpoints
  // (analyze/report/apply/rollback/status) and their SentryGovernanceAgent backend
  // were removed: Environment is now a mandatory dropdown field on every structured
  // template, so there is no more backlog to infer or backfill. This client keeps
  // only the method Department Scope still calls.
  governance: {
    categorize: (payload: { department?: string; useLlm?: boolean }) =>
      fetchJson<CategorizationReport>('/governance/categorize', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
  },
  // FR3 — never silently grant across every keyword match.
  resolveSubscription: (payload: { reference: string; environment?: string; ticketId?: string }) =>
    fetchJson<SubscriptionResolution>('/subscriptions/resolve', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  pim: {
    status: () => fetchJson<PimContext>('/pim/status'),
    eligible: () => fetchJson<{ items: EligibleRole[] }>('/pim/eligible'),
    active: (refresh = false) =>
      fetchJson<{ items: ActiveAssignment[]; activated: number; pending?: number }>(
        `/pim/active${refresh ? '?refresh=1' : ''}`,
      ),
    activate: (payload: Record<string, unknown>) =>
      fetchJson<ActivationResult>('/pim/activate', { method: 'POST', body: JSON.stringify(payload) }),
    deactivate: (payload: Record<string, unknown>) =>
      fetchJson<{ deactivated: boolean; result: { requestId: string; status: string } }>('/pim/deactivate', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
  },
}
