import { useEffect, useMemo, useState } from 'react'
import Alert from '@mui/material/Alert'
import AlertTitle from '@mui/material/AlertTitle'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Chip from '@mui/material/Chip'
import LinearProgress from '@mui/material/LinearProgress'
import MenuItem from '@mui/material/MenuItem'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import TextField from '@mui/material/TextField'
import Tooltip from '@mui/material/Tooltip'
import Typography from '@mui/material/Typography'

import { api } from '../api/client'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import { SimpleBarChart } from '../components/SimpleBarChart'
import type { AgentDefinition, CategorizationReport, DepartmentScope } from '../types'

export function DepartmentScopeView() {
  const [report, setReport] = useState<CategorizationReport | null>(null)
  const [department, setDepartment] = useState('Infrastructure')
  const [useLlm, setUseLlm] = useState(true)
  const [workTypeFilter, setWorkTypeFilter] = useState('All')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [agents, setAgents] = useState<AgentDefinition[]>([])
  const [runCounts, setRunCounts] = useState<Record<string, number>>({})
  const [scope, setScope] = useState<DepartmentScope | null>(null)

  useEffect(() => {
    api
      .agents()
      .then((res) => {
        setAgents(res.agents ?? [])
        setRunCounts(res.runCounts ?? {})
        setScope(res.scope ?? null)
      })
      .catch(() => undefined)
  }, [])

  const run = async () => {
    setBusy(true)
    setError(null)
    try {
      const res = await api.governance.categorize({ department, useLlm })
      if (res.error) setError(res.error)
      setReport(res)
      setWorkTypeFilter('All')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Categorization failed')
    } finally {
      setBusy(false)
    }
  }

  const summary = report?.summary ?? null
  const catalogByKey = useMemo(() => {
    const map: Record<string, string> = {}
    for (const entry of report?.catalog ?? []) map[entry.key] = entry.displayName
    return map
  }, [report])

  const filtered = (report?.results ?? []).filter(
    (r) => workTypeFilter === 'All' || r.workType === workTypeFilter,
  )

  return (
    <>
      <Alert severity="info" sx={{ mb: 2 }}>
        <AlertTitle>Measuring scope expansion instead of guessing it</AlertTitle>
        Agents action Identity Management today. This classifies another department's queue by the
        kind of work each ticket asks for, so the decision to expand rests on a real count of what
        an agent could take on — and on which of those still need a human audit. Actionable work
        classified by a deterministic keyword match needs no human read to confirm what it is, so
        its audit flag is cleared and counted separately; the work type's standing posture is still
        recorded on every row.
      </Alert>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {scope && (
        <Card sx={{ mb: 2 }}>
          <CardHeader title="Department scope" subheader="Where automation stands per department" />
          <CardContent>
            <Stack spacing={1.5}>
              {[
                { label: 'Agents provisioning today', items: scope.active ?? [], tone: 'ok' as const },
                { label: 'Expanding — categorization first', items: scope.expanding ?? [], tone: 'warn' as const },
                { label: 'Deferred / out of scope', items: scope.deferred ?? [], tone: 'neutral' as const },
              ].map((band) => (
                <Box key={band.label}>
                  <Typography variant="caption" color="text.secondary">
                    {band.label}
                  </Typography>
                  <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap', gap: 1, mt: 0.5 }}>
                    {band.items.length === 0 ? (
                      <Typography variant="body2" color="text.secondary">—</Typography>
                    ) : (
                      band.items.map((item) => <StatusPill key={item} tone={band.tone} label={item} />)
                    )}
                  </Stack>
                </Box>
              ))}
            </Stack>
          </CardContent>
        </Card>
      )}

      <Card sx={{ mb: 2 }}>
        <CardHeader
          title="Categorize a department's queue"
          subheader="Deterministic rules first; an LLM step classifies only what the rules could not place. Read-only — nothing is granted."
        />
        <CardContent>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, minmax(160px, 240px))' },
              gap: 1.5,
              alignItems: 'center',
            }}
          >
            <TextField
              select
              size="small"
              label="Department"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
            >
              <MenuItem value="Infrastructure">Infrastructure</MenuItem>
              <MenuItem value="IDM">Identity Management</MenuItem>
              <MenuItem value="All">All departments</MenuItem>
            </TextField>
            <TextField
              select
              size="small"
              label="Classification"
              value={useLlm ? 'llm' : 'rules'}
              onChange={(e) => setUseLlm(e.target.value === 'llm')}
            >
              <MenuItem value="llm">Rules + LLM</MenuItem>
              <MenuItem value="rules">Rules only</MenuItem>
            </TextField>
            <Button variant="contained" disabled={busy} onClick={run}>
              {busy ? 'Categorizing…' : 'Run categorization'}
            </Button>
          </Box>
          {busy && <LinearProgress sx={{ mt: 2 }} />}
          {report?.llmError && (
            <Alert severity="warning" sx={{ mt: 2 }}>
              {report.llmError} Rule-matched tickets are unaffected; the rest stay Unclassified
              rather than being guessed.
            </Alert>
          )}
        </CardContent>
      </Card>

      {summary && (
        <>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
              gap: 2,
              mb: 2,
            }}
          >
            <StatCard label={`${report?.department} tickets`} value={summary.total} />
            <StatCard label="Agent-actionable" value={summary.actionable} color="success.main" />
            <StatCard
              label="Actionable rate"
              value={`${Math.round(summary.actionableRate * 100)}%`}
              color="primary.main"
            />
            <StatCard label="Fully automatable" value={summary.actionableFullyAuto} color="success.main" />
            <StatCard label="Needs human audit" value={summary.actionableWithAudit} color="warning.main" />
            {(summary.auditClearedByKeyword ?? 0) > 0 && (
              <StatCard
                label="Audit cleared by keyword"
                value={summary.auditClearedByKeyword ?? 0}
                color="text.secondary"
              />
            )}
            <StatCard label="Unclassified" value={summary.unclassified} color="error.main" />
          </Box>

          <Card sx={{ mb: 2 }}>
            <CardHeader
              title="Queue by work type"
              subheader="What the department actually asks for — the basis for which use cases to automate next"
            />
            <CardContent>
              <SimpleBarChart
                emptyLabel="No categorization yet"
                data={Object.entries(summary.byWorkType)
                  .sort((a, b) => b[1] - a[1])
                  .map(([key, value]) => ({
                    id: key,
                    label: catalogByKey[key] ?? key,
                    value,
                  }))}
                selectedId={workTypeFilter === 'All' ? null : workTypeFilter}
                onSelect={(id) => setWorkTypeFilter(id ?? 'All')}
              />
            </CardContent>
          </Card>

          <Card sx={{ mb: 2 }}>
            <CardHeader
              title="Per-ticket classification"
              subheader={`${filtered.length} of ${report?.results.length ?? 0} rows`}
            />
            <CardContent>
              <TextField
                select
                size="small"
                label="Work type"
                value={workTypeFilter}
                onChange={(e) => setWorkTypeFilter(e.target.value)}
                sx={{ mb: 2, minWidth: 260 }}
              >
                <MenuItem value="All">All work types</MenuItem>
                {Object.entries(summary.byWorkType).map(([key, count]) => (
                  <MenuItem key={key} value={key}>
                    {catalogByKey[key] ?? key} ({count})
                  </MenuItem>
                ))}
              </TextField>

              <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 520 }}>
                <Table stickyHeader size="small" aria-label="Ticket work-type classification">
                  <TableHead>
                    <TableRow>
                      <TableCell>Ticket</TableCell>
                      <TableCell>Subject</TableCell>
                      <TableCell>Work type</TableCell>
                      <TableCell>Agent can action</TableCell>
                      <TableCell>Confidence</TableCell>
                      <TableCell>Source</TableCell>
                      <TableCell>Why</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {filtered.map((row) => (
                      <TableRow hover key={row.id}>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>#{row.id}</TableCell>
                        <TableCell sx={{ minWidth: 240 }}>{row.subject || '—'}</TableCell>
                        <TableCell sx={{ minWidth: 180 }}>{row.displayName}</TableCell>
                        <TableCell sx={{ minWidth: 150 }}>
                          {row.actionable ? (
                            <Tooltip
                              title={
                                !row.humanAudit && row.policyHumanAudit
                                  ? `Keyword match settled the classification, so no human read is needed to confirm it. "${row.displayName}" still carries a standing audit posture for the action itself.`
                                  : ''
                              }
                            >
                              <span>
                                <StatusPill
                                  tone={row.humanAudit ? 'warn' : 'ok'}
                                  label={
                                    row.humanAudit
                                      ? 'Yes, with audit'
                                      : row.policyHumanAudit
                                        ? 'Yes — audit cleared by keyword'
                                        : 'Yes, automatable'
                                  }
                                />
                              </span>
                            </Tooltip>
                          ) : (
                            <StatusPill tone="neutral" label="No" />
                          )}
                        </TableCell>
                        <TableCell>{row.confidence.toFixed(2)}</TableCell>
                        <TableCell>
                          {row.inferred ? (
                            <Chip
                              size="small"
                              variant="outlined"
                              color="secondary"
                              label="inferred"
                              sx={{ height: 19, fontSize: '0.65rem' }}
                            />
                          ) : (
                            'Rules'
                          )}
                        </TableCell>
                        <TableCell sx={{ minWidth: 240 }}>{row.rationale}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </>
      )}

      {agents.length > 0 && (
        <Card>
          <CardHeader
            title="Agents in this platform"
            subheader="Each agent has one job, its own runtime kind, and its own least-privilege surface. Run counts come from the audit trail."
          />
          <CardContent>
            <TableContainer component={Paper} variant="outlined">
              <Table size="small" aria-label="Agent registry">
                <TableHead>
                  <TableRow>
                    <TableCell>Agent</TableCell>
                    <TableCell>Kind</TableCell>
                    <TableCell>Job</TableCell>
                    <TableCell>Writes</TableCell>
                    <TableCell>Runs</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {agents.map((a) => (
                    <TableRow hover key={a.name}>
                      <TableCell sx={{ minWidth: 190 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {a.displayName}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {a.name}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          size="small"
                          variant="outlined"
                          label={a.kind}
                          color={a.kind === 'Llm' ? 'secondary' : a.kind === 'Hybrid' ? 'primary' : 'default'}
                          sx={{ height: 21, fontSize: '0.68rem' }}
                        />
                      </TableCell>
                      <TableCell sx={{ minWidth: 320 }}>{a.purpose}</TableCell>
                      <TableCell>
                        {a.writes ? (
                          <StatusPill tone="warn" label="yes" />
                        ) : (
                          <StatusPill tone="neutral" label="read-only" />
                        )}
                      </TableCell>
                      <TableCell>{runCounts[a.name] ?? 0}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}
    </>
  )
}
