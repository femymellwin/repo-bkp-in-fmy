import { useCallback, useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import AlertTitle from '@mui/material/AlertTitle'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import ToggleButton from '@mui/material/ToggleButton'
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup'

import { api } from '../api/client'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import type { ReaperStatus } from '../types'

const OUTCOME_TONE: Record<string, 'ok' | 'warn' | 'bad' | 'neutral'> = {
  Revoked: 'ok',
  WouldRevoke: 'neutral',
  Deferred: 'warn',
  Failed: 'bad',
}

type Automation = 'off' | 'rehearse' | 'live' | 'partial'

/**
 * Mostly a read-only view of the grant-expiry reaper -- it runs as a separate scheduled
 * process (same convention as PollerStatusPanel), so this panel reports what it has
 * already done. The two exceptions are the Automation control and the Per-cycle limit
 * form below: both write INSTRUCTION files (dashboard/api/reaper.enabled, reaper.mode,
 * reaper.caps.json) the reaper reads on its next cycle, never a live setting -- see
 * docs/superpowers/specs/2026-08-26-poller-reaper-automation-controls-design.md and the
 * Automation control's comment on PollerStatusPanel for the full reasoning. The
 * Automation control composes two independent override files (enabled + mode) into one
 * 3-way choice; each write is still a separate, independently-auditable API call under
 * the hood.
 *
 * Two things this panel exists specifically to make impossible to miss:
 *   1. expiredUnrevoked > 0 -- access that has outlived its own authorisation.
 *   2. a stale reaper (no recent cycle) -- for a Group grant there is nothing in Azure
 *      to fall back on, so the reaper going quiet IS the risk.
 */
export function ReaperStatusPanel({ onModeChanged }: { onModeChanged?: () => void } = {}) {
  const [status, setStatus] = useState<ReaperStatus | null>(null)
  const [pendingLive, setPendingLive] = useState(false)
  const [justification, setJustification] = useState('')
  const [busy, setBusy] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [actionNote, setActionNote] = useState<string | null>(null)

  const [capsInput, setCapsInput] = useState('')
  const [capsPendingConfirm, setCapsPendingConfirm] = useState(false)
  const [capsJustification, setCapsJustification] = useState('')
  const [capsError, setCapsError] = useState<string | null>(null)

  const load = useCallback(() => {
    return api.reaper.status().then((s) => {
      setStatus(s)
      setCapsInput(String(s.caps.maxRevokes.value))
    }).catch(() => setStatus(null))
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const justificationTooShort = justification.trim().length < 4

  const currentAutomation = (): Automation | null => {
    if (!status) return null
    const e = status.enabledOverride.value
    const m = status.modeOverride.value
    if (e === 'false') return 'off'
    if (e === 'true' && m === 'enforce') return 'live'
    if (e === 'true') return 'rehearse'
    // modeOverride says enforce but enabledOverride is absent or unreadable -- e.g. a
    // leftover pre-Automation-control Enforce Mode override from before this file
    // existed. Rendering this as null ("no override") would hide a live enforce
    // instruction; it must be flagged instead.
    if (status.modeOverride.present && m === 'enforce' && !(status.enabledOverride.present && e !== null)) {
      return 'partial'
    }
    return null
  }

  const applyAutomation = async (target: Automation, withJustification?: string) => {
    setBusy(true)
    setActionError(null)
    try {
      if (target === 'off') {
        const res = await api.reaper.setEnabled(false)
        setActionNote(res.note)
      } else if (target === 'rehearse') {
        await api.reaper.setEnabled(true)
        const res = await api.reaper.setMode('shadow')
        setActionNote(res.note)
      } else {
        await api.reaper.setEnabled(true, withJustification)
        const res = await api.reaper.setMode('enforce', withJustification)
        setActionNote(res.note)
      }
      setPendingLive(false)
      setJustification('')
      await load()
      // Lets EnforceModeMismatchBanner (rendered as a sibling in App.tsx, not a parent
      // of this self-fetching panel) know to re-check itself immediately rather than on
      // its own next poll -- see that component's .DESCRIPTION.
      onModeChanged?.()
    } catch (e) {
      setActionError(
        e instanceof Error
          ? `${e.message} (check Automation and Mode below -- one of the two writes may have already succeeded)`
          : 'Failed to set automation state.',
      )
    } finally {
      setBusy(false)
    }
  }

  const clearAllOverrides = async () => {
    setBusy(true)
    setActionError(null)
    try {
      await api.reaper.clearEnabled()
      await api.reaper.clearMode()
      await api.reaper.clearCaps()
      setActionNote(null)
      await load()
      onModeChanged?.()
    } catch (e) {
      setActionError(e instanceof Error ? e.message : 'Failed to clear overrides.')
    } finally {
      setBusy(false)
    }
  }

  const saveCaps = async (withJustification?: string) => {
    setCapsError(null)
    setBusy(true)
    try {
      const revokes = Number(capsInput)
      if (!Number.isInteger(revokes) || revokes <= 0) throw new Error('Max revokes must be a positive integer.')
      await api.reaper.setCaps({ maxRevokes: revokes }, withJustification)
      setCapsPendingConfirm(false)
      setCapsJustification('')
      await load()
    } catch (e) {
      setCapsError(e instanceof Error ? e.message : 'Failed to save limit.')
    } finally {
      setBusy(false)
    }
  }

  const onSaveCapsClick = () => {
    if (!status) return
    const revokes = Number(capsInput)
    if (Number.isInteger(revokes) && revokes > status.caps.maxRevokes.value) {
      setCapsPendingConfirm(true)
      return
    }
    saveCaps()
  }

  if (!status) return null

  const cycle = status.lastCycle
  const modeOverride = status.modeOverride
  const automation = currentAutomation()
  const expiredUnrevoked = status.expiredUnrevoked ?? cycle?.expiredUnrevoked ?? 0
  const dangerous = expiredUnrevoked > 0

  return (
    <Card sx={{ mb: 2 }}>
      <CardHeader
        title="Grant expiry reaper"
        subheader={
          status.enabled === null
            ? 'Status unknown -- the reaper has not reported recently'
            : status.enabled
              ? `Enabled · ${status.mode} mode (last reported)`
              : 'Disabled (reaper last reported AZURESENTRY_REAPER_ENABLED is not true)'
        }
        action={
          <StatusPill
            tone={
              status.enabled === null
                ? 'neutral'
                : !status.enabled
                  ? 'neutral'
                  : status.mode === 'enforce'
                    ? 'ok'
                    : 'warn'
            }
            label={
              status.enabled === null
                ? 'Unknown'
                : !status.enabled
                  ? 'Off'
                  : status.mode === 'enforce'
                    ? 'Enforcing'
                    : 'Shadow'
            }
          />
        }
      />
      <CardContent>
        {/* The single most important line on this panel: expired access that is still
            live. Shown ahead of every other alert, and independent of staleness -- a
            stale reaper does not make this number less true. */}
        {dangerous && (
          <Alert severity="error" sx={{ mb: 2 }}>
            <AlertTitle>
              {expiredUnrevoked} grant{expiredUnrevoked === 1 ? '' : 's'} expired but NOT
              revoked
            </AlertTitle>
            Access that has outlived its own authorisation. If these are Group-fulfilment
            grants, nothing in Azure will end them on its own -- only the reaper (or a
            human via Revoke) can. Check the table below and{' '}
            <code>docs/ticket-poller-runbook.md</code> if this persists across cycles.
          </Alert>
        )}

        {status.stale && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <AlertTitle>Reaper is quiet -- this is itself a risk</AlertTitle>
            {status.configured
              ? "The reaper's last reported status is missing or too old to trust. Group grants have no Azure-side expiry to fall back on, so a reaper that has stopped cycling means overdue access accumulates unseen. This does not mean it is off -- check the timer directly: "
              : 'The reaper has never reported a status. Check the timer directly: '}
            <code>systemctl status azuresentry-reaper.timer</code> on the VM.
          </Alert>
        )}

        {status.stopFilePresent && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <AlertTitle>Halted by stop sentinel</AlertTitle>
            <code>dashboard/api/reaper.stop</code> exists, so cycles are halting. Delete it
            to resume.
          </Alert>
        )}

        {status.enabled === true && status.mode === 'shadow' && !modeOverride.present && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Shadow mode: the reaper decides and records what it would revoke, and revokes
            nothing.
          </Alert>
        )}

        {/* Automation control. Composes reaper.enabled + reaper.mode into one 3-way
            choice; writes instruction files, never a live setting -- see the module
            .DESCRIPTION above. */}
        <Paper
          variant="outlined"
          sx={{
            p: 2,
            mb: 2,
            borderColor: automation === 'live' || automation === 'partial' ? 'error.main' : 'divider',
          }}
        >
          <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center', flexWrap: 'wrap' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
              Automation
            </Typography>
            <StatusPill
              tone={
                automation === null
                  ? 'neutral'
                  : automation === 'live' || automation === 'partial'
                    ? 'bad'
                    : automation === 'rehearse'
                      ? 'ok'
                      : 'neutral'
              }
              label={
                automation === null
                  ? 'No override -- follows env vars'
                  : automation === 'off'
                    ? 'Override: Off'
                    : automation === 'rehearse'
                      ? 'Override: Rehearse (shadow)'
                      : automation === 'partial'
                        ? 'Partial override -- mode says enforce, enabled state unclear'
                        : 'Override: Live (enforce)'
              }
            />
          </Stack>

          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
            Takes effect on the reaper&apos;s <b>next scheduled cycle</b>, not immediately --
            it is a separate process. This also does not start the reaper from a stopped
            systemd timer -- see docs/ticket-poller-runbook.md's "Enable it" for that
            one-time step.
          </Typography>

          {actionError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>
              {actionError}
            </Alert>
          )}
          {actionNote && !actionError && (
            <Alert severity="info" sx={{ mt: 1.5 }} onClose={() => setActionNote(null)}>
              {actionNote}
            </Alert>
          )}

          {!pendingLive ? (
            <Stack direction="row" spacing={1} sx={{ mt: 1.5, flexWrap: 'wrap' }}>
              <ToggleButtonGroup
                size="small"
                exclusive
                value={automation}
                disabled={busy}
                onChange={(_e, value: Automation | null) => {
                  if (!value || value === automation) return
                  if (value === 'live') {
                    setPendingLive(true)
                  } else {
                    applyAutomation(value)
                  }
                }}
              >
                <ToggleButton value="off">Off</ToggleButton>
                <ToggleButton value="rehearse">Rehearse</ToggleButton>
                <ToggleButton value="live" color="error">
                  Live
                </ToggleButton>
              </ToggleButtonGroup>
              {(status.enabledOverride.present || modeOverride.present) && (
                <Button size="small" variant="text" disabled={busy} onClick={clearAllOverrides}>
                  Clear overrides
                </Button>
              )}
            </Stack>
          ) : (
            <Paper variant="outlined" sx={{ p: 2, mt: 1.5, borderColor: 'error.main' }}>
              <Typography variant="body2">
                This lets the reaper start performing <strong>real Azure revokes</strong> with
                no human click, for any recorded grant whose tracked expiry has passed. Say
                why.
              </Typography>
              <TextField
                label="Justification (min 4 characters)"
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                fullWidth
                size="small"
                sx={{ mt: 1.5 }}
              />
              <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                <Button
                  color="error"
                  variant="contained"
                  disabled={busy || justificationTooShort}
                  onClick={() => applyAutomation('live', justification)}
                >
                  {busy ? 'Setting…' : 'Confirm: go Live'}
                </Button>
                <Button
                  variant="outlined"
                  disabled={busy}
                  onClick={() => {
                    setPendingLive(false)
                    setJustification('')
                  }}
                >
                  Cancel
                </Button>
              </Stack>
            </Paper>
          )}
        </Paper>

        {/* Max revokes per cycle. Writes reaper.caps.json, read before its env var -- see
            Get-ReaperConfig's .DESCRIPTION (ReaperAgent.ps1). */}
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
            Per-cycle limit
          </Typography>
          <Stack direction="row" spacing={2} sx={{ flexWrap: 'wrap' }}>
            <TextField
              label="Max revokes per cycle"
              helperText={`${status.caps.maxRevokes.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput}
              onChange={(e) => setCapsInput(e.target.value)}
            />
          </Stack>

          {capsError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>
              {capsError}
            </Alert>
          )}

          {!capsPendingConfirm ? (
            <Button size="small" variant="outlined" disabled={busy} onClick={onSaveCapsClick} sx={{ mt: 1.5 }}>
              Save limit
            </Button>
          ) : (
            <Paper variant="outlined" sx={{ p: 2, mt: 1.5, borderColor: 'error.main' }}>
              <Typography variant="body2">
                Raising the revokes cap increases how many real revocations one cycle can
                perform. Say why.
              </Typography>
              <TextField
                label="Justification (min 4 characters)"
                value={capsJustification}
                onChange={(e) => setCapsJustification(e.target.value)}
                fullWidth
                size="small"
                sx={{ mt: 1.5 }}
              />
              <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                <Button
                  color="error"
                  variant="contained"
                  disabled={busy || capsJustification.trim().length < 4}
                  onClick={() => saveCaps(capsJustification)}
                >
                  Confirm: raise limit
                </Button>
                <Button
                  variant="outlined"
                  disabled={busy}
                  onClick={() => {
                    setCapsPendingConfirm(false)
                    setCapsJustification('')
                  }}
                >
                  Cancel
                </Button>
              </Stack>
            </Paper>
          )}
        </Paper>

        {!cycle ? (
          <Typography color="text.secondary">
            No cycle has run yet. Install and start the scheduled timer with{' '}
            <code>sudo bash /opt/azuresentry/infra/systemd/install-reaper-timer.sh</code>,
            then <code>sudo systemctl start azuresentry-reaper.timer</code> (see
            docs/ticket-poller-runbook.md).
          </Typography>
        ) : (
          <>
            {cycle.halted && (
              <Alert severity="info" sx={{ mb: 2 }}>
                Last cycle halted: {cycle.haltReason}
              </Alert>
            )}
            {cycle.stopped && (
              <Alert severity="error" sx={{ mb: 2 }}>
                <AlertTitle>Stopped at the first failure (fail-closed)</AlertTitle>
                Later expired grants were deliberately not attempted. Fix the cause; the
                next cycle resumes.
              </Alert>
            )}

            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(6, 1fr)' },
                gap: 1.5,
                mb: 2,
              }}
            >
              <StatCard label="Examined" value={cycle.examined} />
              <StatCard
                label={cycle.mode === 'enforce' ? 'Revoked' : 'Would revoke'}
                value={cycle.mode === 'enforce' ? cycle.revoked : cycle.wouldRevoke}
                color="success.main"
              />
              <StatCard label="Deferred (cap)" value={cycle.deferred} color="warning.main" />
              <StatCard label="Failed" value={cycle.failed} color="error.main" />
              <StatCard
                label="Expired, not revoked"
                value={cycle.expiredUnrevoked}
                color={cycle.expiredUnrevoked > 0 ? 'error.main' : 'success.main'}
              />
              <StatCard label="Last run" value={new Date(cycle.ranAt).toLocaleTimeString()} />
            </Box>

            {cycle.entries.length > 0 && (
              <TableContainer sx={{ maxHeight: 300 }}>
                <Table stickyHeader size="small" aria-label="Reaper cycle entries">
                  <TableHead>
                    <TableRow>
                      <TableCell>Ticket</TableCell>
                      <TableCell>Outcome</TableCell>
                      <TableCell>Requester / Role</TableCell>
                      <TableCell>Fulfilment</TableCell>
                      <TableCell>Overdue</TableCell>
                      <TableCell>Why</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {cycle.entries.map((e) => (
                      <TableRow hover key={`${e.ticketId}-${e.outcome}`}>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>#{e.ticketId}</TableCell>
                        <TableCell>
                          <StatusPill
                            tone={OUTCOME_TONE[e.outcome] ?? 'neutral'}
                            label={e.outcome === 'WouldRevoke' ? 'Would revoke' : e.outcome}
                          />
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {e.requesterUpn ? `${e.requesterUpn} / ${e.role ?? '—'}` : '—'}
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {e.fulfilment === 'PimFallback'
                            ? 'PIM (Azure-enforced)'
                            : e.fulfilment === 'Group'
                              ? 'Group (tracked-only)'
                              : (e.fulfilment ?? '—')}
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {e.overdueHours !== undefined ? `${e.overdueHours.toFixed(1)}h` : '—'}
                        </TableCell>
                        <TableCell sx={{ minWidth: 280 }}>{e.reason}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
