import { useState } from 'react'
import type { ReactNode } from 'react'
import Accordion from '@mui/material/Accordion'
import AccordionDetails from '@mui/material/AccordionDetails'
import AccordionSummary from '@mui/material/AccordionSummary'
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import MenuItem from '@mui/material/MenuItem'
import Stack from '@mui/material/Stack'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import { ActionBadge } from '../components/ActionBadge'
import { DecisionTrace } from '../components/DecisionTrace'
import { MetaList } from '../components/MetaList'
import { PageHeader } from '../components/PageHeader'
import { StatusPill } from '../components/StatusPill'
import type { ActivityFilters, ActivityItem } from '../types'

interface Props {
  items: ActivityItem[]
  filters: ActivityFilters
  onFiltersChange: (f: ActivityFilters) => void
}

export function ActivityView({ items, filters, onFiltersChange }: Props) {
  const [expanded, setExpanded] = useState<string | null>(null)

  const setFilter = (key: keyof ActivityFilters, value: string | number) => {
    onFiltersChange({ ...filters, [key]: value || undefined })
  }

  return (
    <>
      <PageHeader
        title="Access Audit & Agent Decision Log"
        subtitle="Full 7-step decision trace per evaluation — prototype of Log Analytics KQL workbook views"
      />

      <Card sx={{ mb: 2 }}>
        <CardHeader title="Filters" />
        <CardContent>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 1.5 }}>
            <TextField
              size="small" label="Requester" placeholder="user@contoso.com"
              value={filters.requester ?? ''}
              onChange={(e) => setFilter('requester', e.target.value)}
            />
            <TextField
              select size="small" label="Role" value={filters.role ?? ''}
              onChange={(e) => setFilter('role', e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              {['Reader', 'Contributor', 'Owner', 'UAA', 'Custom'].map((r) => (
                <MenuItem key={r} value={r}>{r}</MenuItem>
              ))}
            </TextField>
            <TextField
              select size="small" label="Environment" value={filters.environment ?? ''}
              onChange={(e) => setFilter('environment', e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              <MenuItem value="Sandbox">Sandbox</MenuItem>
              <MenuItem value="Production">Production</MenuItem>
            </TextField>
            <TextField
              select size="small" label="Action" value={filters.action ?? ''}
              onChange={(e) => setFilter('action', e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              {['Grant', 'Eligible', 'Reject', 'Hold', 'BreakGlass'].map((a) => (
                <MenuItem key={a} value={a}>{a}</MenuItem>
              ))}
            </TextField>
            <TextField
              select size="small" label="Time range" value={filters.hours ?? 0}
              onChange={(e) => setFilter('hours', parseInt(e.target.value, 10))}
            >
              <MenuItem value={0}>All time</MenuItem>
              <MenuItem value={24}>Last 24h</MenuItem>
              <MenuItem value={72}>Last 72h</MenuItem>
              <MenuItem value={168}>Last 7d</MenuItem>
            </TextField>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1.5, display: 'block' }}>
            {items.length} record(s)
          </Typography>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          {items.length === 0 ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              No audit entries match filters.
            </Typography>
          ) : (
            <Stack spacing={1}>
              {items.map((item) => (
                <Accordion
                  key={item.id}
                  disableGutters
                  expanded={expanded === item.id}
                  onChange={(_, isOpen) => setExpanded(isOpen ? item.id : null)}
                  sx={{ '&:before': { display: 'none' }, border: (t) => `1px solid ${t.palette.divider}`, borderRadius: 1.5 }}
                >
                  <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                    <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center', width: '100%', pr: 1 }}>
                      <ActionBadge action={item.action} />
                      <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{item.ticketId}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {item.requester} · {item.environment}/{item.role}/{item.priority} → {item.path}
                        </Typography>
                      </Box>
                      {item.approvalStatus && item.approvalStatus !== 'N/A' && (
                        <StatusPill
                          tone={item.approvalStatus === 'Breached' ? 'bad' : item.approvalStatus === 'Pending' ? 'warn' : 'ok'}
                          label={item.approvalStatus}
                        />
                      )}
                      <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>
                        {new Date(item.timestamp).toLocaleString()}
                      </Typography>
                    </Stack>
                  </AccordionSummary>
                  <AccordionDetails>
                    <MetaList
                      rows={[
                        ['Mode', item.mode],
                        ['Reason', item.reason],
                        ...(item.runbook ? [['Runbook', item.runbook] as [string, string]] : []),
                        ...(item.slaHours != null
                          ? [['SLA', `${item.slaHours}h (escalate ${item.escalateAtHours}h)`] as [string, string]]
                          : []),
                        ...(item.assignmentId
                          ? [['Assignment', <Box key="a" component="code">{item.assignmentId}</Box>] as [string, ReactNode]]
                          : []),
                        ...(item.expiresAt
                          ? [['Expires', new Date(item.expiresAt).toLocaleString()] as [string, string]]
                          : []),
                        ...(item.isBreakGlass
                          ? [['Review', `${item.reviewStatus} (deadline ${item.reviewDeadline ? new Date(item.reviewDeadline).toLocaleString() : '—'})`] as [string, string]]
                          : []),
                      ]}
                    />
                    <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2, mb: 1 }}>
                      7-Step Decision Trace
                    </Typography>
                    <DecisionTrace steps={item.steps ?? []} />
                  </AccordionDetails>
                </Accordion>
              ))}
            </Stack>
          )}
        </CardContent>
      </Card>
    </>
  )
}
