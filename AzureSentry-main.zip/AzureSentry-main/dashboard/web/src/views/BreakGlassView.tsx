import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Stack from '@mui/material/Stack'
import Typography from '@mui/material/Typography'
import { alpha, useTheme } from '@mui/material/styles'
import { ActionBadge, formatDuration } from '../components/ActionBadge'
import { MetaList } from '../components/MetaList'
import { PageHeader } from '../components/PageHeader'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import type { BreakGlassResponse } from '../types'

export function BreakGlassView({ data }: { data: BreakGlassResponse | null }) {
  const theme = useTheme()
  if (!data) {
    return (
      <Typography color="text.secondary" sx={{ p: 4, textAlign: 'center' }}>
        Loading break-glass records...
      </Typography>
    )
  }

  const cardBorder = (status?: string) =>
    status === 'Overdue' ? theme.palette.error.main
    : status === 'Pending' ? theme.palette.warning.main
    : theme.palette.divider

  return (
    <>
      <PageHeader
        title="Break-Glass Report"
        subtitle="P1 emergency grants — mandatory 4-hour async review per scope §2.2 / G3"
      />

      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 2, mb: 3 }}>
        <StatCard label="Total Emergency Grants" value={data.items.length} color="secondary.main" />
        <StatCard label="Review Pending" value={data.pendingReview} color="warning.main" />
        <StatCard label="Review Overdue" value={data.overdueReview} color="error.main" />
      </Box>

      <Card>
        <CardHeader title="Emergency Access Log" />
        <CardContent>
          {data.items.length === 0 ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              No break-glass events in current session.
            </Typography>
          ) : (
            <Stack spacing={1.5}>
              {data.items.map((r) => (
                <Card
                  key={r.id}
                  variant="outlined"
                  sx={{
                    borderColor: cardBorder(r.reviewStatus),
                    bgcolor: r.reviewStatus === 'Overdue' ? alpha(theme.palette.error.main, 0.04) : 'transparent',
                  }}
                >
                  <CardContent>
                    <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center', flexWrap: 'wrap', mb: 1.5 }}>
                      <ActionBadge action="BreakGlass" />
                      <Typography sx={{ fontWeight: 600 }}>{r.ticketId}</Typography>
                      <StatusPill
                        tone={r.reviewStatus === 'Overdue' ? 'bad' : r.reviewStatus === 'Pending' ? 'warn' : 'ok'}
                        label={`Review: ${r.reviewStatus}`}
                      />
                    </Stack>
                    <MetaList
                      rows={[
                        ['Requester', r.requester],
                        ['Role', `${r.role} / ${r.environment}`],
                        ['Granted', new Date(r.grantedAt).toLocaleString()],
                        ['Assignment', <Box key="a" component="code">{r.assignmentId}</Box>],
                        ['Access Expires', new Date(r.expiresAt).toLocaleString()],
                        [
                          'Review Deadline',
                          <span key="d">
                            {new Date(r.reviewDeadline).toLocaleString()}
                            {r.reviewRemainingHours != null && (
                              <Box
                                component="span"
                                sx={{
                                  ml: 0.5,
                                  fontWeight: 600,
                                  color:
                                    r.reviewRemainingHours < 0 ? 'error.main'
                                    : r.reviewRemainingHours < 2 ? theme.palette.decision.breakglass
                                    : 'success.dark',
                                }}
                              >
                                ({formatDuration(r.reviewRemainingHours)} left)
                              </Box>
                            )}
                          </span>,
                        ],
                        ['Security Alert', r.securityAlertSent ? 'Sent' : '—'],
                      ]}
                    />
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1.5, pt: 1.5, borderTop: (t) => `1px solid ${t.palette.divider}` }}>
                      {r.reason}
                    </Typography>
                  </CardContent>
                </Card>
              ))}
            </Stack>
          )}
        </CardContent>
      </Card>
    </>
  )
}
