import { useCallback, useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Chip from '@mui/material/Chip'
import Collapse from '@mui/material/Collapse'
import IconButton from '@mui/material/IconButton'
import MenuItem from '@mui/material/MenuItem'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import TextField from '@mui/material/TextField'
import Tooltip from '@mui/material/Tooltip'
import Typography from '@mui/material/Typography'
import RefreshIcon from '@mui/icons-material/Refresh'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp'
import VerifiedUserIcon from '@mui/icons-material/VerifiedUser'
import GppMaybeIcon from '@mui/icons-material/GppMaybe'

import { api } from '../api/client'
import { PageHeader } from '../components/PageHeader'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import type { AuditEvent, AuditOutcome, AuditSummary } from '../types'

const OUTCOME_TONE: Record<AuditOutcome, 'ok' | 'warn' | 'bad' | 'neutral'> = {
  Success: 'ok',
  DryRun: 'neutral',
  Started: 'neutral',
  Blocked: 'warn',
  Failed: 'bad',
}

function shortJson(value: unknown): string {
  if (value === null || value === undefined) return '—'
  if (typeof value === 'string') return value
  return JSON.stringify(value)
}

function EventRow({ event }: { event: AuditEvent }) {
  const [open, setOpen] = useState(false)
  const hasDetail = Boolean(event.target || event.before || event.after || event.detail)

  return (
    <>
      <TableRow hover>
        <TableCell sx={{ width: 44 }}>
          {hasDetail && (
            <IconButton size="small" onClick={() => setOpen((v) => !v)} aria-label="Toggle event detail">
              {open ? <KeyboardArrowUpIcon fontSize="small" /> : <KeyboardArrowDownIcon fontSize="small" />}
            </IconButton>
          )}
        </TableCell>
        <TableCell sx={{ whiteSpace: 'nowrap' }}>{event.seq}</TableCell>
        <TableCell sx={{ whiteSpace: 'nowrap' }}>
          {new Date(event.timestamp).toLocaleString()}
        </TableCell>
        <TableCell sx={{ minWidth: 170 }}>
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            {event.agent}
          </Typography>
          {event.runId && (
            <Typography variant="caption" color="text.secondary" sx={{ wordBreak: 'break-all' }}>
              {event.runId}
            </Typography>
          )}
        </TableCell>
        <TableCell sx={{ minWidth: 150 }}>{event.action}</TableCell>
        <TableCell sx={{ minWidth: 150 }}>{event.actor || '—'}</TableCell>
        <TableCell>{event.ticketId || '—'}</TableCell>
        <TableCell>
          <StatusPill tone={OUTCOME_TONE[event.outcome] ?? 'neutral'} label={event.outcome} />
        </TableCell>
        <TableCell>
          {event.isWrite ? (
            <Chip size="small" color="warning" variant="outlined" label="write" sx={{ height: 20, fontSize: '0.68rem' }} />
          ) : (
            <Typography variant="caption" color="text.secondary">
              read
            </Typography>
          )}
        </TableCell>
      </TableRow>
      {hasDetail && (
        <TableRow>
          <TableCell colSpan={9} sx={{ py: 0, borderBottom: open ? undefined : 'none' }}>
            <Collapse in={open} unmountOnExit timeout="auto">
              <Box
                sx={{
                  py: 1.5,
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', md: '120px 1fr' },
                  gap: '4px 16px',
                  fontSize: '0.8rem',
                }}
              >
                <Typography variant="caption" color="text.secondary">Target</Typography>
                <Box component="code" sx={{ wordBreak: 'break-all' }}>{shortJson(event.target)}</Box>
                <Typography variant="caption" color="text.secondary">Before</Typography>
                <Box component="code" sx={{ wordBreak: 'break-all' }}>{shortJson(event.before)}</Box>
                <Typography variant="caption" color="text.secondary">After</Typography>
                <Box component="code" sx={{ wordBreak: 'break-all' }}>{shortJson(event.after)}</Box>
                <Typography variant="caption" color="text.secondary">Reason</Typography>
                <Box>{event.reason || '—'}</Box>
                <Typography variant="caption" color="text.secondary">Detail</Typography>
                <Box component="code" sx={{ wordBreak: 'break-all' }}>{shortJson(event.detail)}</Box>
                {event.correctsEventId && (
                  <>
                    <Typography variant="caption" color="text.secondary">Compensates</Typography>
                    <Box component="code" sx={{ wordBreak: 'break-all' }}>{event.correctsEventId}</Box>
                  </>
                )}
                <Typography variant="caption" color="text.secondary">Hash</Typography>
                <Box component="code" sx={{ wordBreak: 'break-all', color: 'text.secondary' }}>
                  {event.hash}
                </Box>
              </Box>
            </Collapse>
          </TableCell>
        </TableRow>
      )}
    </>
  )
}

export function AuditLogsView() {
  const [events, setEvents] = useState<AuditEvent[]>([])
  const [summary, setSummary] = useState<AuditSummary | null>(null)
  const [integrity, setIntegrity] = useState<{ ok: boolean; checked: number; reason: string } | null>(null)
  const [agent, setAgent] = useState('All')
  const [outcome, setOutcome] = useState('All')
  const [search, setSearch] = useState('')
  const [writesOnly, setWritesOnly] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [logAnalyticsConfigured, setLogAnalyticsConfigured] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await api.audit({
        limit: 500,
        agent: agent === 'All' ? undefined : agent,
        outcome: outcome === 'All' ? undefined : outcome,
        writesOnly: writesOnly ? 'true' : undefined,
      })
      setEvents(res.events ?? [])
      setSummary(res.summary ?? null)
      setLogAnalyticsConfigured(Boolean(res.logAnalytics?.configured))
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load the audit trail')
    } finally {
      setLoading(false)
    }
  }, [agent, outcome, writesOnly])

  useEffect(() => {
    load()
  }, [load])

  const verify = async () => {
    try {
      setIntegrity(await api.auditIntegrity())
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Integrity check failed')
    }
  }

  const agentNames = Object.keys(summary?.byAgent ?? {}).sort()
  const term = search.trim().toLowerCase()
  const filtered = term
    ? events.filter((e) =>
        [e.agent, e.action, e.actor, e.ticketId, e.reason, JSON.stringify(e.target ?? {})]
          .join(' ')
          .toLowerCase()
          .includes(term),
      )
    : events

  return (
    <>
      <PageHeader
        title="Audit Logs"
        subtitle="Every agent action — who, what, when, target, and before/after state. Append-only and hash-chained; rollbacks appear as compensating entries, never as deletions."
      />

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
          gap: 2,
          mb: 3,
        }}
      >
        <StatCard label="Recorded Events" value={summary?.total ?? 0} />
        <StatCard label="State Changes" value={summary?.writes ?? 0} color="warning.main" />
        <StatCard label="Agents Active" value={agentNames.length} color="primary.main" />
        <StatCard
          label="Failed Actions"
          value={summary?.byOutcome?.Failed ?? 0}
          color="error.main"
        />
      </Box>

      <Card sx={{ mb: 2 }}>
        <CardHeader
          title="Trail integrity"
          subheader="Recomputes the SHA-256 chain over every entry — proves nothing was edited or removed after the fact."
          action={
            <Button size="small" variant="outlined" onClick={verify}>
              Verify chain
            </Button>
          }
        />
        {integrity && (
          <CardContent sx={{ pt: 0 }}>
            <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center' }}>
              {integrity.ok ? (
                <VerifiedUserIcon color="success" />
              ) : (
                <GppMaybeIcon color="error" />
              )}
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {integrity.ok ? 'Chain intact' : 'Chain broken'}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {integrity.checked} entr{integrity.checked === 1 ? 'y' : 'ies'} verified — {integrity.reason}
                </Typography>
              </Box>
            </Stack>
          </CardContent>
        )}
      </Card>

      <Card>
        <CardHeader
          title="Agent activity"
          subheader={`${filtered.length} event${filtered.length === 1 ? '' : 's'} shown`}
          action={
            <IconButton onClick={load} disabled={loading} aria-label="Refresh audit trail">
              <RefreshIcon />
            </IconButton>
          }
        />
        <CardContent>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(4, 1fr)' },
              gap: 1.5,
              mb: 2,
            }}
          >
            <TextField
              select
              size="small"
              label="Agent"
              value={agent}
              onChange={(e) => setAgent(e.target.value)}
            >
              <MenuItem value="All">All agents</MenuItem>
              {agentNames.map((name) => (
                <MenuItem key={name} value={name}>
                  {name} ({summary?.byAgent?.[name] ?? 0})
                </MenuItem>
              ))}
            </TextField>
            <TextField
              select
              size="small"
              label="Outcome"
              value={outcome}
              onChange={(e) => setOutcome(e.target.value)}
            >
              <MenuItem value="All">All outcomes</MenuItem>
              {['Success', 'Failed', 'Blocked', 'DryRun', 'Started'].map((o) => (
                <MenuItem key={o} value={o}>
                  {o}
                </MenuItem>
              ))}
            </TextField>
            <TextField
              select
              size="small"
              label="Scope"
              value={writesOnly ? 'writes' : 'all'}
              onChange={(e) => setWritesOnly(e.target.value === 'writes')}
            >
              <MenuItem value="all">All actions</MenuItem>
              <MenuItem value="writes">State changes only</MenuItem>
            </TextField>
            <TextField
              size="small"
              label="Search"
              placeholder="ticket, actor, subscription…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </Box>

          {filtered.length === 0 ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              {loading
                ? 'Loading…'
                : 'No audit events match. Process a ticket or run a governance batch to populate the trail.'}
            </Typography>
          ) : (
            <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 620 }}>
              <Table stickyHeader size="small" aria-label="Audit trail">
                <TableHead>
                  <TableRow>
                    <TableCell />
                    <TableCell>Seq</TableCell>
                    <TableCell>When</TableCell>
                    <TableCell>Agent</TableCell>
                    <TableCell>Action</TableCell>
                    <TableCell>Actor</TableCell>
                    <TableCell>Ticket</TableCell>
                    <TableCell>Outcome</TableCell>
                    <TableCell>
                      <Tooltip title="Whether the action changed state in an external system">
                        <span>Effect</span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filtered.map((event) => (
                    <EventRow key={event.id} event={event} />
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}

          {summary?.path && (
            <Stack direction="row" spacing={1} sx={{ alignItems: 'center', mt: 1.5, flexWrap: 'wrap' }}>
              <Typography variant="caption" color="text.secondary">
                Append-only trail: <Box component="code">{summary.path}</Box>. This is the local
                always-on record and the system of record regardless of Log Analytics status.
              </Typography>
              <StatusPill
                tone={logAnalyticsConfigured ? 'ok' : 'neutral'}
                label={logAnalyticsConfigured ? 'Log Analytics: forwarding' : 'Log Analytics: not configured'}
              />
            </Stack>
          )}
        </CardContent>
      </Card>
    </>
  )
}
