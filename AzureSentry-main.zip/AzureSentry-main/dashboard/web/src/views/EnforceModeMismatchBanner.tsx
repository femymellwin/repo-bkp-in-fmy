import { useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import AlertTitle from '@mui/material/AlertTitle'

import { api } from '../api/client'
import type { PollerStatus, ReaperStatus } from '../types'

/**
 * Warns when the poller is enforcing real grants but the reaper is not enforcing
 * revokes -- the one dangerous combination of these two independently-switched agents
 * (see docs/ticket-poller-runbook.md § "The reaper has the identical control" for why
 * they are deliberately NOT a single combined switch). The reverse combination --
 * reaper enforcing, poller in shadow -- is not warned about: it is a perfectly good,
 * arguably recommended posture (the reaper can only ever reduce standing access, so
 * enforcing it early while still building confidence in the poller's grants is safe).
 *
 * Self-fetches independently, the same convention every other panel on this page
 * follows (PollerStatusPanel, ReaperStatusPanel, ExpiryView, ...) rather than sharing
 * state with its two sibling panels. `refreshToken` is the one deliberate exception:
 * App.tsx bumps it whenever either panel's own Enforce Mode toggle succeeds, so this
 * banner reflects a just-made change immediately instead of waiting for its own next
 * poll -- a stale "all clear" here is exactly the failure mode this banner exists to
 * prevent, so it must not lag a change the operator just made themselves.
 */
export function EnforceModeMismatchBanner({ refreshToken }: { refreshToken?: number } = {}) {
  const [poller, setPoller] = useState<PollerStatus | null>(null)
  const [reaper, setReaper] = useState<ReaperStatus | null>(null)

  useEffect(() => {
    api.poller.status().then(setPoller).catch(() => setPoller(null))
    api.reaper.status().then(setReaper).catch(() => setReaper(null))
  }, [refreshToken])

  // The instruction for the NEXT cycle when one exists (the override), otherwise the
  // last cycle's actually-reported behaviour -- the same "what will most likely happen
  // next" reading an operator would piece together by eye from the two facts each
  // panel already shows separately. `enabledOverride` wins outright, the same way
  // `modeOverride` already does below: a present `enabledOverride.value === 'false'`
  // means NOT enforcing regardless of modeOverride or the last cycle (an operator who
  // just went Off must see that reflected immediately, not after the next real cycle).
  // A present `enabledOverride.value === 'true'` overrides a stale `enabled === false`
  // for the same reason, symmetrically (an operator who just went Live must not be
  // reassured by a last cycle that predates the change). Otherwise (no override, or an
  // unreadable override file) `enabled === false` is the only thing that suppresses
  // this regardless of mode: a confirmed-off agent cannot enforce anything. `enabled
  // === null` (unknown/stale) does NOT suppress it -- an agent we cannot confirm is off
  // must not read as reassuring, the same fail-safe default this whole platform uses
  // everywhere else (Resolve-PollerStatusView / Resolve-ReaperStatusView).
  const isEffectivelyEnforcing = (status: PollerStatus | ReaperStatus | null): boolean => {
    if (!status) return false
    if (status.enabledOverride.present && status.enabledOverride.value === 'false') return false
    const enabledOverrideSaysOn = status.enabledOverride.present && status.enabledOverride.value === 'true'
    if (status.enabled === false && !enabledOverrideSaysOn) return false
    const mode = status.modeOverride.present ? status.modeOverride.value : status.mode
    return mode === 'enforce'
  }

  const pollerEnforcing = isEffectivelyEnforcing(poller)
  const reaperEnforcing = isEffectivelyEnforcing(reaper)

  if (!pollerEnforcing || reaperEnforcing) return null

  return (
    <Alert severity="warning" sx={{ mb: 2 }}>
      <AlertTitle>Poller is enforcing; Reaper is not</AlertTitle>
      The unattended poller is set to perform real Azure grants, but the grant reaper is
      not set to enforce revokes. Group-fulfilment grants have no native Azure expiry --
      without the reaper also enforcing, access it grants will not be automatically taken
      back once overdue; it will sit there until a human notices and revokes it by hand.
      Enable Enforce Mode on the Grant expiry reaper panel below, or accept that revocation
      is manual for now.
    </Alert>
  )
}
