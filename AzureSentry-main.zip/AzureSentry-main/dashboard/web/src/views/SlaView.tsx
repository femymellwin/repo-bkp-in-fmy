import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import LinearProgress from '@mui/material/LinearProgress'
import Stack from '@mui/material/Stack'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Typography from '@mui/material/Typography'
import { Gauge } from '../components/Gauge'
import { PageHeader } from '../components/PageHeader'
import { StatusPill } from '../components/StatusPill'
import type { SlaMetrics } from '../types'

export function SlaView({ data }: { data: SlaMetrics | null }) {
  if (!data) {
    return (
      <Typography color="text.secondary" sx={{ p: 4, textAlign: 'center' }}>
        Loading SLA metrics...
      </Typography>
    )
  }

  return (
    <>
      <PageHeader
        title="Approval SLA Compliance"
        subtitle="P1–P4 approval windows per scope §3.3 — demo data from session activity log"
      />

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: 2,
          mb: 3,
        }}
      >
        <Card>
          <CardContent sx={{ textAlign: 'center' }}>
            <Typography variant="overline" color="text.secondary">Overall Compliance</Typography>
            <Box sx={{ mt: 1 }}>
              <Gauge value={data.overallCompliance} />
            </Box>
          </CardContent>
        </Card>
        {data.tiers.map((t) => (
          <Card key={t.priority}>
            <CardContent>
              <Typography variant="overline" color="text.secondary">
                {t.priority} ({t.slaHours}h SLA)
              </Typography>
              <LinearProgress
                variant="determinate"
                value={t.complianceRate}
                sx={{ my: 1, height: 8, borderRadius: 4 }}
              />
              <Stack direction="row" sx={{ justifyContent: 'space-between' }}>
                <Typography variant="caption" color="text.secondary">
                  {t.complianceRate}% compliant
                </Typography>
                <Typography variant="caption" color="text.secondary">{t.total} total</Typography>
              </Stack>
              <Stack direction="row" spacing={0.75} sx={{ mt: 1, flexWrap: 'wrap' }}>
                <StatusPill tone="ok" label={`${t.compliant} met`} />
                <StatusPill tone="warn" label={`${t.pending} pending`} />
                <StatusPill tone="bad" label={`${t.breached} breached`} />
              </Stack>
            </CardContent>
          </Card>
        ))}
      </Box>

      <Card>
        <CardHeader title="SLA Breaches & Overdue" />
        <CardContent>
          {data.breaches.length === 0 ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              No SLA breaches in current session.
            </Typography>
          ) : (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Ticket', 'Requester', 'Priority', 'SLA', 'Requested', 'Status'].map((h) => (
                      <TableCell key={h}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.breaches.map((b) => (
                    <TableRow key={b.ticketId} hover>
                      <TableCell>{b.ticketId}</TableCell>
                      <TableCell>{b.requester}</TableCell>
                      <TableCell>{b.priority}</TableCell>
                      <TableCell>{b.slaHours}h</TableCell>
                      <TableCell>{new Date(b.requestedAt).toLocaleString()}</TableCell>
                      <TableCell>
                        <StatusPill tone={b.status === 'Breached' ? 'bad' : 'warn'} label={b.status} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>
    </>
  )
}
