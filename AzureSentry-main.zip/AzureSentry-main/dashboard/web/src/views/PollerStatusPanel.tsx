import { useCallback, useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import AlertTitle from '@mui/material/AlertTitle'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import ToggleButton from '@mui/material/ToggleButton'
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup'

import { api } from '../api/client'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import type { PollerStatus } from '../types'

const OUTCOME_TONE: Record<string, 'ok' | 'warn' | 'bad' | 'neutral'> = {
  Granted: 'ok',
  WouldGrant: 'neutral',
  Queued: 'warn',
  Failed: 'bad',
}

type Automation = 'off' | 'rehearse' | 'live' | 'partial'

/**
 * Mostly a read-only view of the unattended poller -- it runs as a separate scheduled
 * process, so this panel reports what it has already done. The two exceptions are the
 * Automation control and the Per-cycle limits form below: both write INSTRUCTION files
 * (dashboard/api/poller.enabled, poller.mode, poller.caps.json) the poller reads on its
 * next cycle, never a live setting -- see docs/superpowers/specs/
 * 2026-08-26-poller-reaper-automation-controls-design.md. The Automation control composes
 * two independent override files (enabled + mode) into one 3-way choice; each write is
 * still a separate, independently-auditable API call under the hood.
 */
export function PollerStatusPanel({ onModeChanged }: { onModeChanged?: () => void } = {}) {
  const [status, setStatus] = useState<PollerStatus | null>(null)
  const [pendingLive, setPendingLive] = useState(false)
  const [justification, setJustification] = useState('')
  const [busy, setBusy] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [actionNote, setActionNote] = useState<string | null>(null)

  const [capsInput, setCapsInput] = useState<{ maxGrants: string; maxTickets: string; maxAgeDays: string }>({
    maxGrants: '',
    maxTickets: '',
    maxAgeDays: '',
  })
  const [capsPendingConfirm, setCapsPendingConfirm] = useState(false)
  const [capsJustification, setCapsJustification] = useState('')
  const [capsError, setCapsError] = useState<string | null>(null)

  const load = useCallback(() => {
    return api.poller.status().then((s) => {
      setStatus(s)
      setCapsInput({
        maxGrants: String(s.caps.maxGrants.value),
        maxTickets: String(s.caps.maxTickets.value),
        maxAgeDays: String(s.caps.maxAgeDays.value),
      })
    }).catch(() => setStatus(null))
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const justificationTooShort = justification.trim().length < 4

  const currentAutomation = (): Automation | null => {
    if (!status) return null
    const e = status.enabledOverride.value
    const m = status.modeOverride.value
    if (e === 'false') return 'off'
    if (e === 'true' && m === 'enforce') return 'live'
    if (e === 'true') return 'rehearse'
    // modeOverride says enforce but enabledOverride is absent or unreadable -- e.g. a
    // leftover pre-Automation-control Enforce Mode override from before this file
    // existed. Rendering this as null ("no override") would hide a live enforce
    // instruction; it must be flagged instead.
    if (status.modeOverride.present && m === 'enforce' && !(status.enabledOverride.present && e !== null)) {
      return 'partial'
    }
    return null
  }

  const applyAutomation = async (target: Automation, withJustification?: string) => {
    setBusy(true)
    setActionError(null)
    try {
      if (target === 'off') {
        const res = await api.poller.setEnabled(false)
        setActionNote(res.note)
      } else if (target === 'rehearse') {
        await api.poller.setEnabled(true)
        const res = await api.poller.setMode('shadow')
        setActionNote(res.note)
      } else {
        await api.poller.setEnabled(true, withJustification)
        const res = await api.poller.setMode('enforce', withJustification)
        setActionNote(res.note)
      }
      setPendingLive(false)
      setJustification('')
      await load()
      // Lets EnforceModeMismatchBanner (rendered as a sibling in App.tsx, not a parent
      // of this self-fetching panel) know to re-check itself immediately rather than on
      // its own next poll -- see that component's .DESCRIPTION.
      onModeChanged?.()
    } catch (e) {
      setActionError(
        e instanceof Error
          ? `${e.message} (check Automation and Mode below -- one of the two writes may have already succeeded)`
          : 'Failed to set automation state.',
      )
    } finally {
      setBusy(false)
    }
  }

  const clearAllOverrides = async () => {
    setBusy(true)
    setActionError(null)
    try {
      await api.poller.clearEnabled()
      await api.poller.clearMode()
      await api.poller.clearCaps()
      setActionNote(null)
      await load()
      onModeChanged?.()
    } catch (e) {
      setActionError(e instanceof Error ? e.message : 'Failed to clear overrides.')
    } finally {
      setBusy(false)
    }
  }

  const saveCaps = async (withJustification?: string) => {
    setCapsError(null)
    setBusy(true)
    try {
      if (!status) throw new Error('Status not loaded yet.')
      const payload: { maxGrants?: number; maxTickets?: number; maxAgeDays?: number } = {}
      const grants = Number(capsInput.maxGrants)
      const tickets = Number(capsInput.maxTickets)
      const ageDays = Number(capsInput.maxAgeDays)
      if (!Number.isInteger(grants) || grants <= 0) throw new Error('Max grants must be a positive integer.')
      if (!Number.isInteger(tickets) || tickets <= 0) throw new Error('Max tickets must be a positive integer.')
      if (!Number.isInteger(ageDays) || ageDays <= 0) throw new Error('Max ticket age must be a positive integer.')
      // Only send fields the operator actually changed -- the server only persists
      // fields that are already-overridden or newly-provided, so sending all three
      // unconditionally would "provide" every field on every save and permanently pin
      // it as an override, silently freezing fields the operator never touched (see
      // Finding 4 in the final-review-fix report).
      if (grants !== status.caps.maxGrants.value) payload.maxGrants = grants
      if (tickets !== status.caps.maxTickets.value) payload.maxTickets = tickets
      if (ageDays !== status.caps.maxAgeDays.value) payload.maxAgeDays = ageDays

      await api.poller.setCaps(payload, withJustification)
      setCapsPendingConfirm(false)
      setCapsJustification('')
      await load()
    } catch (e) {
      setCapsError(e instanceof Error ? e.message : 'Failed to save limits.')
    } finally {
      setBusy(false)
    }
  }

  const onSaveCapsClick = () => {
    if (!status) return
    const grants = Number(capsInput.maxGrants)
    if (Number.isInteger(grants) && grants > status.caps.maxGrants.value) {
      setCapsPendingConfirm(true)
      return
    }
    saveCaps()
  }

  if (!status) return null

  const cycle = status.lastCycle
  const modeOverride = status.modeOverride
  const automation = currentAutomation()

  return (
    <Card sx={{ mb: 2 }}>
      <CardHeader
        title="Unattended ticket poller"
        subheader={
          status.enabled === null
            ? 'Status unknown -- the poller has not reported recently'
            : status.enabled
              ? `Enabled · ${status.mode} mode (last reported)`
              : 'Disabled (poller last reported AZURESENTRY_POLLER_ENABLED is not true)'
        }
        action={
          <StatusPill
            tone={
              status.enabled === null
                ? 'neutral'
                : !status.enabled
                  ? 'neutral'
                  : status.mode === 'enforce'
                    ? 'ok'
                    : 'warn'
            }
            label={
              status.enabled === null
                ? 'Unknown'
                : !status.enabled
                  ? 'Off'
                  : status.mode === 'enforce'
                    ? 'Enforcing'
                    : 'Shadow'
            }
          />
        }
      />
      <CardContent>
        {status.stale && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <AlertTitle>Status unknown</AlertTitle>
            {status.configured
              ? "The poller's last reported status is missing or too old to trust. This does not mean it is off -- check the timer directly: "
              : 'The poller has never reported a status. Check the timer directly: '}
            <code>systemctl status azuresentry-poller.timer</code> on the VM.
          </Alert>
        )}

        {status.stopFilePresent && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <AlertTitle>Halted by stop sentinel</AlertTitle>
            <code>dashboard/api/poller.stop</code> exists, so cycles are halting. Delete it to
            resume.
          </Alert>
        )}

        {status.enabled === true && status.mode === 'shadow' && !modeOverride.present && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Shadow mode: the poller decides and records what it would grant, and writes
            nothing.
          </Alert>
        )}

        {/* Automation control. Composes poller.enabled + poller.mode into one 3-way
            choice; writes instruction files, never a live setting -- see the module
            .DESCRIPTION above. */}
        <Paper
          variant="outlined"
          sx={{
            p: 2,
            mb: 2,
            borderColor: automation === 'live' || automation === 'partial' ? 'error.main' : 'divider',
          }}
        >
          <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center', flexWrap: 'wrap' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
              Automation
            </Typography>
            <StatusPill
              tone={
                automation === null
                  ? 'neutral'
                  : automation === 'live' || automation === 'partial'
                    ? 'bad'
                    : automation === 'rehearse'
                      ? 'ok'
                      : 'neutral'
              }
              label={
                automation === null
                  ? 'No override -- follows env vars'
                  : automation === 'off'
                    ? 'Override: Off'
                    : automation === 'rehearse'
                      ? 'Override: Rehearse (shadow)'
                      : automation === 'partial'
                        ? 'Partial override -- mode says enforce, enabled state unclear'
                        : 'Override: Live (enforce)'
              }
            />
          </Stack>

          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
            Takes effect on the poller&apos;s <b>next scheduled cycle</b>, not immediately -- it
            is a separate process. This also does not start the poller from a stopped systemd
            timer -- see docs/ticket-poller-runbook.md's "Enable it" for that one-time step.
          </Typography>

          {actionError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>
              {actionError}
            </Alert>
          )}
          {actionNote && !actionError && (
            <Alert severity="info" sx={{ mt: 1.5 }} onClose={() => setActionNote(null)}>
              {actionNote}
            </Alert>
          )}

          {!pendingLive ? (
            <Stack direction="row" spacing={1} sx={{ mt: 1.5, flexWrap: 'wrap' }}>
              <ToggleButtonGroup
                size="small"
                exclusive
                value={automation}
                disabled={busy}
                onChange={(_e, value: Automation | null) => {
                  if (!value || value === automation) return
                  if (value === 'live') {
                    setPendingLive(true)
                  } else {
                    applyAutomation(value)
                  }
                }}
              >
                <ToggleButton value="off">Off</ToggleButton>
                <ToggleButton value="rehearse">Rehearse</ToggleButton>
                <ToggleButton value="live" color="error">
                  Live
                </ToggleButton>
              </ToggleButtonGroup>
              {(status.enabledOverride.present || modeOverride.present) && (
                <Button size="small" variant="text" disabled={busy} onClick={clearAllOverrides}>
                  Clear overrides
                </Button>
              )}
            </Stack>
          ) : (
            <Paper variant="outlined" sx={{ p: 2, mt: 1.5, borderColor: 'error.main' }}>
              <Typography variant="body2">
                This lets the unattended poller start performing <strong>real Azure grants</strong>{' '}
                with no human click, for tickets that already pass every gate (template, exact
                allowlist match, Sandbox/NonProd only, promotion ladder). Say why.
              </Typography>
              <TextField
                label="Justification (min 4 characters)"
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                fullWidth
                size="small"
                sx={{ mt: 1.5 }}
              />
              <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                <Button
                  color="error"
                  variant="contained"
                  disabled={busy || justificationTooShort}
                  onClick={() => applyAutomation('live', justification)}
                >
                  {busy ? 'Setting…' : 'Confirm: go Live'}
                </Button>
                <Button
                  variant="outlined"
                  disabled={busy}
                  onClick={() => {
                    setPendingLive(false)
                    setJustification('')
                  }}
                >
                  Cancel
                </Button>
              </Stack>
            </Paper>
          )}
        </Paper>

        {/* Per-cycle limits. Writes poller.caps.json, read per-field before its env var --
            see Get-PollerConfig's .DESCRIPTION (TicketPollerAgent.ps1). */}
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
            Per-cycle limits
          </Typography>
          <Stack direction="row" spacing={2} sx={{ flexWrap: 'wrap' }}>
            <TextField
              label="Max grants per cycle"
              helperText={`${status.caps.maxGrants.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput.maxGrants}
              onChange={(e) => setCapsInput((c) => ({ ...c, maxGrants: e.target.value }))}
            />
            <TextField
              label="Max tickets examined per cycle"
              helperText={`${status.caps.maxTickets.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput.maxTickets}
              onChange={(e) => setCapsInput((c) => ({ ...c, maxTickets: e.target.value }))}
            />
            <TextField
              label="Max ticket age (days)"
              helperText={`${status.caps.maxAgeDays.source === 'override' ? 'Override' : 'Default (env)'}`}
              type="number"
              size="small"
              value={capsInput.maxAgeDays}
              onChange={(e) => setCapsInput((c) => ({ ...c, maxAgeDays: e.target.value }))}
            />
          </Stack>

          {capsError && (
            <Alert severity="error" sx={{ mt: 1.5 }}>
              {capsError}
            </Alert>
          )}

          {!capsPendingConfirm ? (
            <Button size="small" variant="outlined" disabled={busy} onClick={onSaveCapsClick} sx={{ mt: 1.5 }}>
              Save limits
            </Button>
          ) : (
            <Paper variant="outlined" sx={{ p: 2, mt: 1.5, borderColor: 'error.main' }}>
              <Typography variant="body2">
                Raising the grants cap increases how many real Azure grants one cycle can
                perform. Say why.
              </Typography>
              <TextField
                label="Justification (min 4 characters)"
                value={capsJustification}
                onChange={(e) => setCapsJustification(e.target.value)}
                fullWidth
                size="small"
                sx={{ mt: 1.5 }}
              />
              <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                <Button
                  color="error"
                  variant="contained"
                  disabled={busy || capsJustification.trim().length < 4}
                  onClick={() => saveCaps(capsJustification)}
                >
                  Confirm: raise limit
                </Button>
                <Button
                  variant="outlined"
                  disabled={busy}
                  onClick={() => {
                    setCapsPendingConfirm(false)
                    setCapsJustification('')
                  }}
                >
                  Cancel
                </Button>
              </Stack>
            </Paper>
          )}
        </Paper>

        {!cycle ? (
          <Typography color="text.secondary">
            No cycle has run yet. Install and start the scheduled timer with{' '}
            <code>sudo bash /opt/azuresentry/infra/systemd/install-poller-timer.sh</code>,
            then <code>sudo systemctl start azuresentry-poller.timer</code> (see
            docs/ticket-poller-runbook.md).
          </Typography>
        ) : (
          <>
            {cycle.halted && (
              <Alert severity="info" sx={{ mb: 2 }}>
                Last cycle halted: {cycle.haltReason}
              </Alert>
            )}
            {cycle.stopped && (
              <Alert severity="error" sx={{ mb: 2 }}>
                <AlertTitle>Stopped at the first failure (fail-closed)</AlertTitle>
                Later tickets were deliberately not attempted. Fix the cause; the next cycle
                resumes.
              </Alert>
            )}

            {cycle.mode === 'enforce' && cycle.failed > 0 && (
              <Alert severity="warning" sx={{ mb: 2 }}>
                <AlertTitle>Failed grant -- requester notified</AlertTitle>
                For a ticket that reached the grant step and failed, AzureSentry posts a
                note back to the requester explaining that automated provisioning did not
                complete, and the ticket is awaiting human verification -- it is not
                resolved automatically. Check the <b>Note</b> column below to confirm it
                actually posted for each ticket; a note failure is possible too (for
                example ManageEngine being unreachable).
              </Alert>
            )}

            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(5, 1fr)' },
                gap: 1.5,
                mb: 2,
              }}
            >
              <StatCard label="Examined" value={cycle.examined} />
              <StatCard
                label={cycle.mode === 'enforce' ? 'Granted' : 'Would grant'}
                value={cycle.mode === 'enforce' ? cycle.granted : cycle.wouldGrant}
                color="success.main"
              />
              <StatCard label="Queued for a human" value={cycle.queued} color="warning.main" />
              <StatCard label="Failed" value={cycle.failed} color="error.main" />
              <StatCard label="Last run" value={new Date(cycle.ranAt).toLocaleTimeString()} />
            </Box>

            {cycle.entries.length > 0 && (
              <TableContainer sx={{ maxHeight: 300 }}>
                <Table stickyHeader size="small" aria-label="Poller cycle entries">
                  <TableHead>
                    <TableRow>
                      <TableCell>Ticket</TableCell>
                      <TableCell>Outcome</TableCell>
                      <TableCell>Role / Env</TableCell>
                      <TableCell>Note</TableCell>
                      <TableCell>Resolved</TableCell>
                      <TableCell>Why</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {cycle.entries.map((e) => {
                      // notePosted/ticketResolved are only ever set on Granted/Failed
                      // enforce entries -- Queued and WouldGrant post no note by design
                      // (see the .DESCRIPTION on Invoke-TicketPollerCycle), so they
                      // render as "-" here rather than a false negative.
                      const noteCell =
                        e.notePosted === undefined ? '—' : e.notePosted ? 'Posted' : 'Failed'
                      const resolvedCell =
                        e.ticketResolved === undefined ? '—' : e.ticketResolved ? 'Yes' : 'No'
                      return (
                        <TableRow hover key={`${e.ticketId}-${e.outcome}`}>
                          <TableCell sx={{ whiteSpace: 'nowrap' }}>#{e.ticketId}</TableCell>
                          <TableCell>
                            <StatusPill
                              tone={OUTCOME_TONE[e.outcome] ?? 'neutral'}
                              label={e.outcome === 'WouldGrant' ? 'Would grant' : e.outcome}
                            />
                          </TableCell>
                          <TableCell sx={{ whiteSpace: 'nowrap' }}>
                            {e.role ? `${e.role} / ${e.effectiveEnvironment ?? '—'}` : '—'}
                          </TableCell>
                          <TableCell
                            sx={{ whiteSpace: 'nowrap' }}
                            title={e.noteError || undefined}
                          >
                            {noteCell}
                          </TableCell>
                          <TableCell
                            sx={{ whiteSpace: 'nowrap' }}
                            title={e.resolveError || undefined}
                          >
                            {resolvedCell}
                          </TableCell>
                          <TableCell sx={{ minWidth: 280 }}>{e.reason}</TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
