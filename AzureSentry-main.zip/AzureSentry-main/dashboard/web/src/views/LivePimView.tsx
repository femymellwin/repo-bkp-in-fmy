import { useCallback, useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import LinearProgress from '@mui/material/LinearProgress'
import MenuItem from '@mui/material/MenuItem'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Step from '@mui/material/Step'
import StepLabel from '@mui/material/StepLabel'
import Stepper from '@mui/material/Stepper'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import { api } from '../api/client'
import { ActionBadge, formatDuration } from '../components/ActionBadge'
import { DecisionTrace } from '../components/DecisionTrace'
import { MetaList } from '../components/MetaList'
import { PageHeader } from '../components/PageHeader'
import { StatusPill } from '../components/StatusPill'
import type { ActivationResult, ActiveAssignment, EligibleRole, PimContext } from '../types'

// Canonical 7-step validation checklist (scope §3.2) used for the live activation animation.
const STEP_NAMES = [
  'Required Fields',
  'Approved Subscriptions',
  'Role Eligibility',
  'Environment Classification',
  'Priority Classification',
  'Role Sensitivity',
  'Duplicate Access Check',
]
const STEP_MS = 480
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

type ActivationPhase = 'idle' | 'running' | 'done'

export function LivePimView({ onChanged }: { onChanged?: () => void }) {
  const [ctx, setCtx] = useState<PimContext | null>(null)
  const [eligible, setEligible] = useState<EligibleRole[]>([])
  const [active, setActive] = useState<ActiveAssignment[]>([])
  const [loadError, setLoadError] = useState<string | null>(null)
  const [eligibleLoaded, setEligibleLoaded] = useState(false)

  const [selectedRole, setSelectedRole] = useState<EligibleRole | null>(null)
  const [environment, setEnvironment] = useState('Production')
  const [priority, setPriority] = useState('P2')
  const [durationHours, setDurationHours] = useState(8)
  const [justification, setJustification] = useState('')

  const [pendingConfirm, setPendingConfirm] = useState(false)
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState<ActivationResult | null>(null)
  const [actionError, setActionError] = useState<string | null>(null)
  const [phase, setPhase] = useState<ActivationPhase>('idle')
  const [stepIdx, setStepIdx] = useState(0)
  const [refreshingActive, setRefreshingActive] = useState(false)

  // Fetch the live active-assignments list (manual refresh only).
  const refreshActive = useCallback(async (force = false): Promise<ActiveAssignment[] | null> => {
    setRefreshingActive(true)
    try {
      const ac = await api.pim.active(force)
      setActive(ac.items)
      return ac.items
    } catch {
      return null
    } finally {
      setRefreshingActive(false)
    }
  }, [])

  const loadLists = useCallback(async () => {
    let status: PimContext
    try {
      status = await api.pim.status()
      setCtx(status)
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : 'Failed to reach the dashboard API')
      return
    }
    if (!status.loggedIn) {
      setEligible([])
      setActive([])
      setEligibleLoaded(true)
      return
    }
    // Fetch eligible and active independently so a slow active-assignments
    // call never blocks the eligible-role form from rendering.
    try {
      const el = await api.pim.eligible()
      setEligible(el.items)
      setSelectedRole((prev) => prev ?? el.items[0] ?? null)
      setLoadError(null)
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : 'Failed to load eligible roles')
    } finally {
      setEligibleLoaded(true)
    }
    await refreshActive()
  }, [refreshActive])

  useEffect(() => {
    loadLists()
  }, [loadLists])

  const submitActivation = async () => {
    if (!selectedRole) return
    setBusy(true)
    setActionError(null)
    setResult(null)
    setPendingConfirm(false)
    setPhase('running')
    setStepIdx(0)

    // Run the real activation and the step animation in parallel so the
    // 7 decision cards fill in while the live PIM call is in flight.
    const apiCall = api.pim
      .activate({
        Role: selectedRole.roleName,
        RoleDefinitionId: selectedRole.roleDefinitionId,
        Environment: environment,
        Priority: priority,
        DurationHours: durationHours,
        Justification: justification,
        BreakGlass: priority === 'P1',
      })
      .then((r) => ({ ok: true as const, r }))
      .catch((e) => ({ ok: false as const, e }))

    const animate = (async () => {
      for (let i = 1; i <= STEP_NAMES.length; i++) {
        await sleep(STEP_MS)
        setStepIdx(i)
      }
    })()

    const [outcome] = await Promise.all([apiCall, animate])
    setBusy(false)

    if (!outcome.ok) {
      setPhase('idle')
      setActionError(outcome.e instanceof Error ? outcome.e.message : 'Activation failed')
      return
    }
    setResult(outcome.r)
    setPhase('done')
    onChanged?.()
    // ARM can lag after SelfActivate / PendingApproval — refresh a few times so
    // Current Role Assignments picks up the new instance or pending request.
    await refreshActive(true)
    for (const delay of [2500, 5000, 8000]) {
      await sleep(delay)
      const items = await refreshActive(true)
      if (!items) continue
      const matched =
        items.some((a) => a.isActivated || a.isPending) ||
        (outcome.r.activation?.requestId &&
          items.some((a) => a.requestId === outcome.r.activation?.requestId))
      if (matched) break
    }
    await loadLists()
  }

  const deactivate = async (a: ActiveAssignment) => {
    setBusy(true)
    setActionError(null)
    try {
      await api.pim.deactivate({
        RoleDefinitionId: a.roleDefinitionId,
        Justification: 'Deactivated from AzureSentry dashboard',
        SubscriptionId: a.subscriptionId,
      })
      await loadLists()
      onChanged?.()
    } catch (e) {
      setActionError(e instanceof Error ? e.message : 'Deactivation failed')
    } finally {
      setBusy(false)
    }
  }

  const justificationTooShort =
    (environment === 'Production' || environment === 'NonProd') &&
    justification.trim().length < 4
  const isBreakGlass = priority === 'P1'

  return (
    <>
      <PageHeader
        title="Live PIM (Azure)"
        subtitle="Real PIM self-activation on your subscription — gated by the validation checklist"
      />

      {loadError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {loadError}
        </Alert>
      )}

      {/* Session banner */}
      <Card sx={{ mb: 3 }}>
        <CardHeader title="Azure Session" />
        <CardContent>
          {!ctx ? (
            <Typography color="text.secondary">Checking Azure CLI session…</Typography>
          ) : !ctx.loggedIn ? (
            <Typography color="text.secondary">
              Not signed in to Azure CLI. Run <Box component="code">az login</Box> in a terminal, then reload.
            </Typography>
          ) : (
            <MetaList
              rows={[
                ['Signed in as', ctx.user],
                [
                  'Subscription',
                  <span key="sub">
                    {ctx.subscriptionName}{' '}
                    <StatusPill
                      tone={ctx.onExpectedSubscription ? 'ok' : 'warn'}
                      label={ctx.onExpectedSubscription ? 'expected' : 'unexpected'}
                    />
                  </span>,
                ],
                ['Object ID', <Box key="oid" component="code">{ctx.principalId}</Box>],
              ]}
            />
          )}
        </CardContent>
      </Card>

      {ctx?.loggedIn && (
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2, mb: 3 }}>
          {/* Activation form */}
          <Card>
            <CardHeader title="Activate Eligible Role" />
            <CardContent>
              {!eligibleLoaded ? (
                <Typography color="text.secondary">Loading eligible roles…</Typography>
              ) : eligible.length === 0 ? (
                <Typography color="text.secondary">No eligible PIM roles found for this subscription.</Typography>
              ) : (
                <>
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                    <TextField
                      select
                      label="Eligible Role"
                      value={selectedRole?.roleDefinitionId ?? ''}
                      onChange={(e) =>
                        setSelectedRole(eligible.find((r) => r.roleDefinitionId === e.target.value) ?? null)
                      }
                      fullWidth
                      size="small"
                    >
                      {eligible.map((r) => (
                        <MenuItem key={r.roleDefinitionId} value={r.roleDefinitionId}>
                          {r.roleName} — {r.scopeName}
                        </MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      select
                      label="Environment (classification)"
                      value={environment}
                      onChange={(e) => setEnvironment(e.target.value)}
                      fullWidth
                      size="small"
                    >
                      <MenuItem value="Sandbox">Sandbox</MenuItem>
                      <MenuItem value="NonProd">Non-Prod</MenuItem>
                      <MenuItem value="Production">Production</MenuItem>
                    </TextField>
                    <TextField
                      select
                      label="Priority"
                      value={priority}
                      onChange={(e) => setPriority(e.target.value)}
                      fullWidth
                      size="small"
                    >
                      <MenuItem value="P1">P1</MenuItem>
                      <MenuItem value="P2">P2</MenuItem>
                      <MenuItem value="P3">P3</MenuItem>
                      <MenuItem value="P4">P4</MenuItem>
                    </TextField>
                    <TextField
                      type="number"
                      label="Duration (hours)"
                      value={durationHours}
                      onChange={(e) => setDurationHours(Number(e.target.value))}
                      slotProps={{ htmlInput: { min: 1, max: 24 } }}
                      fullWidth
                      size="small"
                    />
                  </Box>
                  <TextField
                    label={
                      <>
                        Justification{' '}
                        {environment === 'Production' && (
                          <Box component="span" sx={{ color: 'warning.main' }}>
                            (min 4 chars)
                          </Box>
                        )}
                      </>
                    }
                    multiline
                    rows={3}
                    value={justification}
                    onChange={(e) => setJustification(e.target.value)}
                    placeholder="Why is this access needed?"
                    fullWidth
                    size="small"
                    sx={{ mt: 2 }}
                  />

                  {isBreakGlass && (
                    <Alert severity="error" icon={false} sx={{ mt: 2 }}>
                      <strong>P1 = emergency break-glass path.</strong> For Contributor on Production this returns{' '}
                      <strong>Break-Glass</strong> and creates an <strong>active</strong> assignment (not eligible),
                      raising a security alert and a 4h async-review flag. Use this to verify the emergency path on
                      real Azure.
                    </Alert>
                  )}

                  {actionError && (
                    <Alert severity="error" sx={{ mt: 2 }}>
                      {actionError}
                    </Alert>
                  )}

                  {!pendingConfirm ? (
                    <Button
                      variant="contained"
                      disabled={busy || justificationTooShort}
                      onClick={() => setPendingConfirm(true)}
                      sx={{ mt: 2 }}
                    >
                      Activate on Azure (live)
                    </Button>
                  ) : (
                    <Paper variant="outlined" sx={{ p: 2, mt: 2, borderColor: 'warning.main' }}>
                      <Typography variant="body2">
                        This performs a <strong>real PIM activation</strong> of{' '}
                        <strong>{selectedRole?.roleName}</strong> on <strong>{selectedRole?.scopeName}</strong> for{' '}
                        {durationHours}h. Proceed?
                      </Typography>
                      <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                        <Button color="error" variant="contained" disabled={busy} onClick={submitActivation}>
                          {busy ? 'Activating…' : 'Confirm activation'}
                        </Button>
                        <Button variant="outlined" disabled={busy} onClick={() => setPendingConfirm(false)}>
                          Cancel
                        </Button>
                      </Stack>
                    </Paper>
                  )}
                </>
              )}
            </CardContent>
          </Card>

          {/* Decision + result */}
          <Card>
            <CardHeader title="Decision & Result" />
            <CardContent>
              {phase === 'running' ? (
                <Box>
                  <Stepper activeStep={stepIdx} orientation="vertical">
                    {STEP_NAMES.map((name, i) => (
                      <Step key={name} completed={i < stepIdx}>
                        <StepLabel
                          optional={
                            <Typography variant="caption" color="text.secondary">
                              {i < stepIdx ? 'Complete' : i === stepIdx ? 'Processing…' : 'Pending'}
                            </Typography>
                          }
                        >
                          {name}
                        </StepLabel>
                      </Step>
                    ))}
                  </Stepper>
                  <LinearProgress sx={{ mt: 1 }} />
                  <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block', textAlign: 'center' }}>
                    Running validation checklist and calling Azure PIM…
                  </Typography>
                </Box>
              ) : !result ? (
                <Typography color="text.secondary">
                  Submit an activation to run the validation checklist and call Azure PIM.
                </Typography>
              ) : (
                <>
                  <DecisionTrace steps={result.steps} />
                  <Paper variant="outlined" sx={{ p: 2, mt: 2 }}>
                    <Stack direction="row" spacing={1.25} sx={{ alignItems: 'center' }}>
                      <ActionBadge action={result.decision.Action} />
                      <Typography sx={{ fontWeight: 600 }}>{result.decision.Path}</Typography>
                    </Stack>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                      {result.decision.Reason}
                    </Typography>
                  </Paper>
                  {result.blocked ? (
                    <Card variant="outlined" sx={{ mt: 2, borderLeft: '3px solid', borderLeftColor: 'error.main' }}>
                      <CardContent>
                        <Typography variant="subtitle2" sx={{ color: 'error.main', mb: 0.5 }}>
                          Activation Blocked
                        </Typography>
                        <Typography variant="body2">{result.reason}</Typography>
                      </CardContent>
                    </Card>
                  ) : result.activated ? (
                    <Card variant="outlined" sx={{ mt: 2, borderLeft: '3px solid', borderLeftColor: 'success.main' }}>
                      <CardContent>
                        <Typography variant="subtitle2" sx={{ color: 'success.dark', mb: 0.5 }}>
                          PIM Activated on Azure
                        </Typography>
                        <MetaList
                          rows={[
                            ['Request ID', <Box key="rid" component="code">{result.activation?.requestId}</Box>],
                            ['Status', result.activation?.status],
                            ['Role', result.activation?.roleName],
                            ['Expires', result.expiresAt ? new Date(result.expiresAt).toLocaleString() : '—'],
                          ]}
                        />
                      </CardContent>
                    </Card>
                  ) : null}
                </>
              )}
            </CardContent>
          </Card>
        </Box>
      )}

      {/* Active assignments */}
      {ctx?.loggedIn && (
        <Card>
          <CardHeader
            title="Current Role Assignments (live)"
            subheader="All active and pending PIM assignments for your account across allowlisted subscriptions"
            action={
              <Button size="small" variant="outlined" disabled={refreshingActive} onClick={() => refreshActive(true)}>
                {refreshingActive ? 'Refreshing…' : 'Refresh'}
              </Button>
            }
          />
          <CardContent>
            {phase === 'done' && result?.activated && !active.some((a) => a.isActivated || a.isPending) && (
              <Alert severity="info" sx={{ mb: 2 }}>
                Activation succeeded — Azure may take ~30–60s to surface the assignment (or it may be waiting on
                approval). Click Refresh to check again.
              </Alert>
            )}
            {active.length === 0 ? (
              <Typography color="text.secondary">No role assignments returned.</Typography>
            ) : (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Role</TableCell>
                      <TableCell>Scope</TableCell>
                      <TableCell>Type</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Remaining</TableCell>
                      <TableCell>Source</TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {active.map((a, idx) => (
                      <TableRow key={a.id || `${a.roleDefId}-${a.assignmentType}-${a.scope}-${idx}`}>
                        <TableCell>{a.roleName}</TableCell>
                        <TableCell>
                          <Typography variant="body2">{a.scopeName || '—'}</Typography>
                          {a.subscriptionId && (
                            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                              {a.subscriptionId}
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell>
                          <StatusPill
                            tone={a.isPending ? 'warn' : a.isActivated ? 'ok' : 'neutral'}
                            label={a.assignmentType}
                          />
                        </TableCell>
                        <TableCell>{a.status}</TableCell>
                        <TableCell>{a.remainingHours != null ? formatDuration(a.remainingHours) : '—'}</TableCell>
                        <TableCell>{a.memberType}</TableCell>
                        <TableCell>
                          {a.isActivated && (
                            <Button size="small" variant="outlined" disabled={busy} onClick={() => deactivate(a)}>
                              Deactivate
                            </Button>
                          )}
                          {a.isPending && (
                            <Typography variant="caption" color="warning.main">
                              Awaiting approval / provisioning
                            </Typography>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </CardContent>
        </Card>
      )}
    </>
  )
}
