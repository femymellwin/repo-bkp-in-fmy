import { useCallback, useEffect, useState } from 'react'
import Alert from '@mui/material/Alert'
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import IconButton from '@mui/material/IconButton'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Typography from '@mui/material/Typography'
import { alpha, useTheme } from '@mui/material/styles'
import RefreshIcon from '@mui/icons-material/Refresh'

import { api } from '../api/client'
import { ActionBadge, formatDuration } from '../components/ActionBadge'
import { PageHeader } from '../components/PageHeader'
import { StatCard } from '../components/StatCard'
import { StatusPill } from '../components/StatusPill'
import type { AssignmentsResponse } from '../types'

export function ExpiryView() {
  const theme = useTheme()
  const [data, setData] = useState<AssignmentsResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api.assignments()
      setData(res)
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load assignments.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const remainingColor = (urgency: string) =>
    urgency === 'expired' ? theme.palette.error.main
    : urgency === 'critical' ? theme.palette.decision.breakglass
    : urgency === 'warning' ? theme.palette.warning.main
    : theme.palette.success.dark

  const rowBg = (urgency: string) =>
    urgency === 'expired' ? alpha(theme.palette.error.main, 0.06)
    : urgency === 'critical' ? alpha(theme.palette.decision.breakglass, 0.05)
    : 'transparent'

  return (
    <>
      <PageHeader
        title="Expiry Tracking"
        subtitle="Every non-revoked grant on record, from both the dashboard and the unattended poller — durable across restarts"
      />

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 2, mb: 3 }}>
        <StatCard label="Active" value={data?.active ?? 0} color="success.main" />
        <StatCard label="Expiring Soon" value={data?.expiringSoon ?? 0} color="warning.main" />
        <StatCard label="Expired (Not Revoked)" value={data?.expiredNotRevoked ?? 0} color="error.main" />
      </Box>

      <Card>
        <CardHeader
          title="Assignment Inventory"
          subheader="Reaper-tracked rows have no native Azure expiry — the reaper agent is solely responsible for revoking them once expired"
          action={
            <IconButton onClick={load} disabled={loading} aria-label="Refresh assignments">
              <RefreshIcon />
            </IconButton>
          }
        />
        <CardContent>
          {!data ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              Loading assignments...
            </Typography>
          ) : data.items.length === 0 ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              No active assignments.
            </Typography>
          ) : (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Assignment', 'User', 'Role', 'Env', 'Action', 'Expires', 'Remaining', 'Enforcement', 'Status'].map((h) => (
                      <TableCell key={h}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.items.map((a, i) => (
                    <TableRow key={`${a.assignmentId}-${a.ticketId}-${i}`} sx={{ bgcolor: rowBg(a.urgency) }}>
                      <TableCell>
                        <Box component="code" sx={{ fontSize: '0.78rem' }}>{a.assignmentId}</Box>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                          {a.ticketId}
                        </Typography>
                      </TableCell>
                      <TableCell>{a.requester}</TableCell>
                      <TableCell>{a.role}</TableCell>
                      <TableCell>{a.environment}</TableCell>
                      <TableCell><ActionBadge action={a.action} /></TableCell>
                      <TableCell>{new Date(a.expiresAt).toLocaleString()}</TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ fontWeight: 600, color: remainingColor(a.urgency) }}>
                          {formatDuration(a.remainingHours)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <StatusPill
                          tone={a.expiryEnforcement === 'AzureEnforced' ? 'neutral' : 'warn'}
                          label={a.expiryEnforcement === 'AzureEnforced' ? 'Azure-enforced' : 'Reaper-tracked'}
                        />
                      </TableCell>
                      <TableCell>
                        <StatusPill
                          tone={a.urgency === 'expired' ? 'bad' : a.urgency === 'critical' ? 'warn' : 'ok'}
                          label={a.status === 'ExpiredNotRevoked' ? 'Expired' : 'Active'}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>
    </>
  )
}
