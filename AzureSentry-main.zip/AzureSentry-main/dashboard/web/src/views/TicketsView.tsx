import { useCallback, useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import Accordion from '@mui/material/Accordion'
import AccordionDetails from '@mui/material/AccordionDetails'
import AccordionSummary from '@mui/material/AccordionSummary'
import Alert from '@mui/material/Alert'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import Chip from '@mui/material/Chip'
import Collapse from '@mui/material/Collapse'
import MenuItem from '@mui/material/MenuItem'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import { api } from '../api/client'
import { formatIdentityLabel } from '../formatIdentityLabel'
import { normalizeManageEngineTickets } from '../normalizeManageEngineTickets'
import { resolveTicketEnvironment } from '../resolveTicketEnvironment'
import { resolveTicketRole } from '../resolveTicketRole'
import { collectTicketParseText } from '../collectTicketParseText'
import { ticketTypeLabel } from '../ticketTypeLabel'
import { buildTemplatePayload } from '../buildTemplatePayload'
import {
  extractMeAccessFields,
  findMeCatalogSubscriptionName,
  mapMeAzureRole,
  mapMeEnvironment,
  ticketUsesMeCatalogSubscription,
} from '../extractMeAccessFields'
import {
  allowlistDisplayNames,
  buildAllowlistSelectOptions,
  ensureSubscriptionInCatalog,
  resolveTicketSubscription,
  type SubscriptionCatalogEntry,
} from '../resolveSubscriptionId'
import {
  failedRevokeState,
  successfulRevokeState,
  type RevokeUiState,
} from '../revokeUiState'
import { ActionBadge } from '../components/ActionBadge'
import { DecisionTrace } from '../components/DecisionTrace'
import { MetaList } from '../components/MetaList'
import { PageHeader } from '../components/PageHeader'
import { StatusPill } from '../components/StatusPill'
import type { PillTone } from '../components/StatusPill'
import type {
  EvaluateResult,
  MeAccessFields,
  METicket,
  ProcessedSummary,
  ProcessResult,
  TicketSummary,
  TemplatePayload,
} from '../types'

function priorityTone(name?: string): PillTone {
  switch (name?.toLowerCase()) {
    case 'high':
      return 'bad'
    case 'medium':
      return 'warn'
    case 'low':
      return 'ok'
    default:
      return 'neutral'
  }
}

function statusTone(name?: string): PillTone {
  const n = name?.toLowerCase() ?? ''
  if (n === 'closed' || n === 'resolved') return 'ok'
  if (n === 'open') return 'warn'
  if (n === 'overdue') return 'bad'
  return 'neutral'
}

// Same three statuses TicketPollerAgent's own fetch already treats as "done"
// (scripts/Invoke-TicketPollerCycle.ps1's $fetchTickets) -- reused here rather than
// inventing a second definition of "closed out" that could drift from it.
const DONE_STATUSES = ['Resolved', 'Closed', 'Cancelled']
// Sentinel for the Status filter's explicit "show everything, including done
// tickets" option -- distinct from the empty-string default (open-only) so the two
// are never confused with each other or with a real ME status name.
const STATUS_FILTER_ALL = '__all__'

function guessPriority(me: METicket): string {
  const n = me.priority?.name?.toLowerCase() ?? ''
  if (n.includes('p1') || n === 'urgent' || n === 'high') return 'P1'
  if (n.includes('p2') || n === 'medium') return 'P2'
  if (n.includes('p3') || n === 'normal') return 'P3'
  return 'P4'
}

interface TicketMapping {
  /** Normalized role used by evaluate/process (UAA, Contributor, …). */
  Role: string
  /** Raw ManageEngine Azure Role pick (what the requester selected). */
  MeAzureRole: string
  Environment: string
  /** Raw ManageEngine Environment dropdown value (optional display). */
  MeEnvironment: string
  SubscriptionId: string
  /** Raw ManageEngine Subscription dropdown value (empty → UI shows missing). */
  MeSubscriptionType: string
  SubscriptionSource: string
  DurationDays: number
  Priority: string
  RequesterUpn: string
  Justification: string
}

function stripHtml(s?: string): string {
  return (s ?? '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim()
}

function extractRequesterFromBody(body: string, fallback: string): string {
  const m =
    body.match(/user\s*[:=]\s*([^\s<>]+@[^\s<>]+)/i) ||
    body.match(/mailto:([^\s"'?>]+@[^\s"'?>]+)/i)
  return m?.[1]?.trim() || fallback
}

/**
 * Map ME template fields (Subscription, Azure Role, Environment) + live allowlist.
 * Prefer what the requester selected on the Azure Subscription template; free-text inference
 * is a fallback only when those fields are empty. Allowlist miss still surfaces as an error.
 */
function parseTicket(
  t: METicket,
  catalog: SubscriptionCatalogEntry[] = [],
  accessFields?: MeAccessFields | null,
): { mapping: TicketMapping; warnings: string[] } {
  const body = stripHtml(t.description) || stripHtml(t.short_description)
  const parseText = collectTicketParseText(t)
  // Free-text fallback must not invent role/env from unrelated UDF noise.
  const freeText = [t.subject ?? '', body].filter(Boolean).join(' ').toLowerCase()
  const warnings: string[] = []

  const fromUdf = extractMeAccessFields(t.udf_fields)
  const preferredSubscription =
    (accessFields?.Subscription ?? '').trim() || fromUdf.subscription
  const meAzureRole = (accessFields?.AzureRole ?? '').trim() || fromUdf.azureRole
  const meEnvironment =
    (accessFields?.Environment ?? '').trim() || fromUdf.environment

  // Match ME Subscription type against live MG allowlist names (not a static MD list).
  const meSubscription = ticketUsesMeCatalogSubscription(t.created_time)
    ? findMeCatalogSubscriptionName({
        preferredSubscription,
        udf: t.udf_fields,
        haystackText: parseText,
        catalogNames: allowlistDisplayNames(catalog),
      })
    : preferredSubscription

  // Azure Role — prefer ME template dropdown; fall back to free-text parse.
  let role = ''
  if (meAzureRole) {
    const mapped = mapMeAzureRole(meAzureRole)
    role = mapped.role
    if (mapped.warning) warnings.push(mapped.warning)
  } else {
    const roleResult = resolveTicketRole(freeText)
    role = roleResult.role
    if (roleResult.warning) warnings.push(roleResult.warning)
  }

  // Subscription — ME type matched to live MG allowlist GUID. Keep error when unmapped.
  const sub = resolveTicketSubscription({
    meSubscription,
    text: parseText,
    catalog,
  })
  if (!sub.subscriptionType) {
    warnings.push(
      'ManageEngine Subscription was not set on the ticket. Select the subscription (missing).',
    )
  } else if (!sub.subscriptionId) {
    warnings.push(`${sub.subscriptionType} is not allowlisted`)
  }

  // Environment — ME Environment dropdown; map to Sandbox / NonProd / Production when possible.
  let environment = ''
  if (meEnvironment) {
    const envMapped = mapMeEnvironment(meEnvironment)
    environment = envMapped.environment
    if (envMapped.warning) warnings.push(envMapped.warning)
  } else {
    const envResult = resolveTicketEnvironment(freeText)
    environment = envResult.environment
    if (envResult.warning) warnings.push(envResult.warning)
  }

  const requesterFallback = t.requester?.email_id ?? ''
  const requesterUpn = extractRequesterFromBody(body, requesterFallback)

  return {
    mapping: {
      Role: role,
      MeAzureRole: meAzureRole,
      Environment: environment,
      MeEnvironment: meEnvironment,
      SubscriptionId: sub.subscriptionId,
      MeSubscriptionType: sub.subscriptionType,
      SubscriptionSource: sub.source ?? '',
      DurationDays: 7,
      Priority: guessPriority(t),
      RequesterUpn: requesterUpn,
      Justification: (body || t.subject || '').slice(0, 500),
    },
    warnings,
  }
}

export function TicketsView() {
  const [tickets, setTickets] = useState<METicket[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [priorityFilter, setPriorityFilter] = useState('')
  const [ticketTypeFilter, setTicketTypeFilter] = useState('')
  const [subscriptions, setSubscriptions] = useState<SubscriptionCatalogEntry[]>([])

  const [expanded, setExpanded] = useState<number | null>(null)
  const [mapping, setMapping] = useState<TicketMapping | null>(null)
  const [templatePayload, setTemplatePayload] = useState<TemplatePayload | null>(null)
  const [mappingWarnings, setMappingWarnings] = useState<string[]>([])
  const [evaluating, setEvaluating] = useState(false)
  const [result, setResult] = useState<EvaluateResult | null>(null)
  const [processing, setProcessing] = useState(false)
  const [revoking, setRevoking] = useState(false)
  const [revokeStates, setRevokeStates] = useState<Map<number, RevokeUiState>>(new Map())
  const [processedMap, setProcessedMap] = useState<Map<number, ProcessResult>>(new Map())
  const [processedSummaries, setProcessedSummaries] = useState<Map<number, ProcessedSummary>>(new Map())
  const [ticketSummary, setTicketSummary] = useState<TicketSummary | null>(null)
  const [summaryLoading, setSummaryLoading] = useState(false)
  const [rawDescriptionOpen, setRawDescriptionOpen] = useState(false)
  const [identityQueues, setIdentityQueues] = useState<string[]>([
    'Identity Management',
    'Identity and Access Management Team',
  ])
  const summaryRequestId = useRef(0)

  const load = useCallback(async () => {
    try {
      setLoading(true)
      const [res, processed, allow, presets] = await Promise.all([
        api.manageEngine.requests(),
        api.manageEngine.processed().catch(() => ({ items: [] as ProcessedSummary[] })),
        api.allowlist().catch(() => ({ subscriptions: [] as string[], details: [] as Array<{ id: string; name: string }>, source: '' })),
        api.presets().catch(() => ({ presets: [], subscriptions: [] as Array<{ id: string; label: string }> })),
      ])
      // ManageEngine serializes request IDs as strings. Normalize once so
      // persisted numeric Map keys still match after a browser refresh.
      setTickets(normalizeManageEngineTickets(res.requests ?? []))
      if (res.identityQueueLabels?.length) {
        setIdentityQueues(res.identityQueueLabels.map((q) => q.displayName))
      } else if (res.identityQueues?.length) {
        setIdentityQueues(res.identityQueues.map(formatIdentityLabel))
      } else if (res.idmQueueDisplay) {
        setIdentityQueues([res.idmQueueDisplay, formatIdentityLabel('IDAM Team')])
      } else if (res.idmQueue) {
        setIdentityQueues([formatIdentityLabel(res.idmQueue), formatIdentityLabel('IDAM Team')])
      }
      setProcessedSummaries(
        new Map((processed.items ?? []).map((p) => [Number(p.meTicketId), p])),
      )
      // Live MG allowlist only (name + GUID). No static MD / config catalog for the dropdown.
      const fromAllow = (allow.details ?? []).map((d) => ({
        id: d.id,
        label: d.name || d.id,
        aliases: d.name ? [d.name] : [],
      }))
      // Presets may only fill gaps when allowlist details are empty (e.g. static-fallback mode).
      const fromPresets =
        fromAllow.length > 0
          ? []
          : (presets.subscriptions ?? []).map((s) => ({
              id: s.id,
              label: s.label,
              aliases: [s.label, s.label.split('(')[0].trim()].filter(Boolean),
            }))
      const byId = new Map<string, SubscriptionCatalogEntry>()
      for (const e of [...fromAllow, ...fromPresets]) {
        if (!e.id || byId.has(e.id)) continue
        byId.set(e.id, e)
      }
      setSubscriptions([...byId.values()])
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load tickets')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const toggleExpand = async (t: METicket) => {
    if (expanded === t.id) {
      summaryRequestId.current += 1
      setExpanded(null)
      setMapping(null)
      setTemplatePayload(null)
      setMappingWarnings([])
      setResult(null)
      setTicketSummary(null)
      setSummaryLoading(false)
      setRawDescriptionOpen(false)
    } else {
      const requestId = ++summaryRequestId.current
      setExpanded(t.id)
      setRawDescriptionOpen(false)
      // List API often omits UDF values. Detail GET returns Subscription / Azure Role / Environment.
      let detailed = t
      let accessFields: MeAccessFields | null = null
      let serverPayload: TemplatePayload | null = null
      let detailWarning: string | null = null
      try {
        const detail = await api.manageEngine.request(t.id)
        if (detail.request) {
          detailed = {
            ...t,
            ...detail.request,
            id: Number(detail.request.id ?? t.id),
          }
          accessFields = detail.accessFields ?? null
          serverPayload = detail.templatePayload ?? null
          setTickets((prev) =>
            prev.map((row) => (row.id === t.id ? { ...row, ...detailed } : row)),
          )
        }
      } catch (e) {
        // Fall back to list payload (subject/description only).
        const msg = e instanceof Error ? e.message : String(e)
        if (/rate limit|maximum access limit/i.test(msg)) {
          detailWarning =
            'ManageEngine rate limit hit while loading full ticket fields — showing list data. Wait ~30s and reopen the ticket.'
        }
      }
      if (summaryRequestId.current !== requestId) return

      // Always rebuild fields from the detail ticket. ME returns keyed UDFs / built-in
      // item+request_type without labels; the shared builder fills those. Keep any
      // mandatory-field markers the API resolved from ME template metadata.
      const localPayload = buildTemplatePayload(detailed, accessFields)
      const payload: TemplatePayload = serverPayload
        ? {
            ...localPayload,
            requiredFields: serverPayload.requiredFields ?? localPayload.requiredFields,
            requiredPlaceholders:
              serverPayload.requiredPlaceholders ?? localPayload.requiredPlaceholders,
            warnings: Array.from(
              new Set([...(serverPayload.warnings ?? []), ...localPayload.warnings]),
            ),
          }
        : localPayload
      setTemplatePayload(payload)

      const parsed = parseTicket(detailed, subscriptions, accessFields)
      setMapping(parsed.mapping)
      setMappingWarnings(
        detailWarning
          ? [detailWarning, ...parsed.warnings, ...payload.warnings]
          : [...parsed.warnings, ...payload.warnings],
      )
      if (parsed.mapping.SubscriptionId) {
        setSubscriptions((prev) =>
          ensureSubscriptionInCatalog(
            prev,
            parsed.mapping.SubscriptionId,
            parsed.mapping.MeSubscriptionType || undefined,
          ),
        )
      }
      const prev = processedMap.get(t.id)
      setResult(prev ?? null)
      setTicketSummary(null)
      setSummaryLoading(true)
      try {
        const sum = await api.manageEngine.summarize({
          subject: detailed.subject,
          description:
            [stripHtml(detailed.description) || detailed.short_description, collectTicketParseText(detailed)]
              .filter(Boolean)
              .join('\n'),
          short_description: detailed.short_description,
          requester: detailed.requester?.email_id ?? detailed.requester?.name,
        })
        if (summaryRequestId.current === requestId) {
          setTicketSummary(sum)
        }
      } catch {
        if (summaryRequestId.current === requestId) {
          setTicketSummary(null)
        }
      } finally {
        if (summaryRequestId.current === requestId) {
          setSummaryLoading(false)
        }
      }
    }
  }

  const updateMapping = (field: keyof TicketMapping, value: string | number) => {
    setMapping((m) => (m ? { ...m, [field]: value } : m))
    setResult(null)
  }

  const runEvaluate = async (ticketId: number) => {
    if (!mapping) return
    if (!mapping.SubscriptionId) {
      setError('Select a subscription before running validation.')
      return
    }
    // FR1 — environment drives prioritization and the eligibility matrix, so it is
    // mandatory rather than defaulted.
    if (!mapping.Environment) {
      setError('Select an environment before running validation — it is the primary prioritization signal.')
      return
    }
    setEvaluating(true)
    setError(null)
    try {
      const payload = {
        ...mapping,
        TicketId: `ME-${ticketId}`,
        templateName: templatePayload?.templateName,
        templateHandler: templatePayload?.handler,
      }
      const res = await api.evaluate(payload)
      setResult(res)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Evaluation failed')
    } finally {
      setEvaluating(false)
    }
  }

  const runProcess = async (ticketId: number) => {
    if (!mapping) return
    if (!mapping.SubscriptionId) {
      setError('Select a subscription before granting access.')
      return
    }
    if (!mapping.Environment) {
      setError('Select an environment before granting access — it determines the approval path.')
      return
    }
    setProcessing(true)
    setError(null)
    try {
      const res = await api.manageEngine.process(ticketId, {
        ...mapping,
        templateName: templatePayload?.templateName,
        templateHandler: templatePayload?.handler,
      })
      setProcessedMap((prev) => new Map(prev).set(ticketId, res))
      setResult(res)
      if (res.duplicateBlocked || res.decision.Path === 'Duplicate-Assignment') {
        setError(null)
      } else if (res.promotionBlocked) {
        setError(res.decision.Reason)
      } else if (!res.processed) {
        const pimErr =
          res.execution && res.execution.Success === false
            ? String(res.execution.Error ?? 'PIM grant failed')
            : null
        setError(
          pimErr
            ? `Access was not granted: ${pimErr}`
            : `Access was not granted (${res.decision.Action}): ${res.decision.Reason}`,
        )
      } else if (res.processed) {
        setProcessedSummaries((prev) => {
          const next = new Map(prev)
          next.set(ticketId, {
            meTicketId: String(ticketId),
            action: res.decision.Action,
            role: mapping.Role,
            environment: mapping.Environment,
            subscriptionId: mapping.SubscriptionId,
            requesterUpn: mapping.RequesterUpn,
            assignmentId: res.execution?.AssignmentId,
            assignmentType: res.execution?.AssignmentType,
            expiresAt: res.execution?.ExpiresAt,
            pimClient: res.execution?.PimClient,
            fulfilment: res.execution?.Fulfilment,
            groupId: res.execution?.GroupId,
            groupName: res.execution?.GroupName,
            processedAt: new Date().toISOString(),
            revoked: false,
          })
          return next
        })
        if (res.execution && (res.execution.AlreadyExisted || res.execution.GroupAlreadyExisted)) {
          setError(null)
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Processing failed')
    } finally {
      setProcessing(false)
    }
  }

  const runRevoke = async (ticketId: number) => {
    setRevoking(true)
    setError(null)
    setRevokeStates((prev) =>
      new Map(prev).set(ticketId, {
        phase: 'revoking',
        message: 'Revoking Azure access…',
      }),
    )
    try {
      const res = await api.manageEngine.revoke(ticketId, `Access rollback for ticket #${ticketId}`)
      const noteOk = Boolean(res.revokeNotePosted ?? (res.meUpdate && !res.meUpdate.error))
      const notified = Boolean(res.revokeNotifyRequester ?? res.meUpdate?.notifyRequester)
      setRevokeStates((prev) =>
        new Map(prev).set(ticketId, successfulRevokeState(notified)),
      )
      setProcessedSummaries((prev) => {
        const next = new Map(prev)
        const cur = next.get(ticketId)
        if (cur) {
          next.set(ticketId, {
            ...cur,
            revoked: true,
            revokedAt: new Date().toISOString(),
            revokeNotePosted: noteOk,
            revokeNotifyRequester: notified,
            revokeNoteError: res.meUpdate?.error,
          })
        }
        return next
      })
      setProcessedMap((prev) => {
        const next = new Map(prev)
        next.delete(ticketId)
        return next
      })
      if (res.meUpdate?.error) {
        setError(`Access revoked, but ManageEngine note failed: ${res.meUpdate.error}`)
      }
    } catch (e) {
      const failed = failedRevokeState(e)
      setRevokeStates((prev) => new Map(prev).set(ticketId, failed))
      setError(failed.message)
    } finally {
      setRevoking(false)
    }
  }

  const filtered = tickets.filter((t) => {
    const typeLabel = ticketTypeLabel(t)
    if (search) {
      const q = search.toLowerCase()
      const match =
        t.subject?.toLowerCase().includes(q) ||
        t.requester?.name?.toLowerCase().includes(q) ||
        typeLabel.toLowerCase().includes(q) ||
        String(t.id).includes(q)
      if (!match) return false
    }
    if (statusFilter === STATUS_FILTER_ALL) {
      // explicit opt-in to see everything, done tickets included
    } else if (statusFilter) {
      if (t.status?.name !== statusFilter) return false
    } else if (DONE_STATUSES.includes(t.status?.name ?? '')) {
      // default: hide Resolved/Closed/Cancelled -- this queue exists to act on
      // open tickets, not to accumulate every one ever raised
      return false
    }
    if (priorityFilter && t.priority?.name !== priorityFilter) return false
    if (ticketTypeFilter && typeLabel !== ticketTypeFilter) return false
    return true
  })

  const hiddenDoneCount = statusFilter
    ? 0
    : tickets.filter((t) => DONE_STATUSES.includes(t.status?.name ?? '')).length

  const statuses = [...new Set(tickets.map((t) => t.status?.name).filter(Boolean))] as string[]
  const priorities = [...new Set(tickets.map((t) => t.priority?.name).filter(Boolean))] as string[]
  const ticketTypes = [...new Set(tickets.map((t) => ticketTypeLabel(t)))].sort((a, b) =>
    a.localeCompare(b),
  )

  return (
    <>
      <PageHeader
        title="Help Desk Tickets"
        subtitle={`Identity and Access Management tickets only (${identityQueues.join(' / ')}) — open a row to review prerequisites and run the validation checklist`}
      />

      <Card sx={{ mb: 2 }}>
        <CardContent>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 1.5 }}>
            <TextField
              size="small"
              label="Search"
              placeholder="ID, subject, requester, or ticket type"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <TextField
              select
              size="small"
              label="Status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <MenuItem value="">Open (hides Resolved/Closed/Cancelled)</MenuItem>
              <MenuItem value={STATUS_FILTER_ALL}>All statuses</MenuItem>
              {statuses.map((s) => (
                <MenuItem key={s} value={s}>{s}</MenuItem>
              ))}
            </TextField>
            <TextField
              select
              size="small"
              label="Priority"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              {priorities.map((p) => (
                <MenuItem key={p} value={p}>{p}</MenuItem>
              ))}
            </TextField>
            <TextField
              select
              size="small"
              label="Ticket type"
              value={ticketTypeFilter}
              onChange={(e) => setTicketTypeFilter(e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              {ticketTypes.map((type) => (
                <MenuItem key={type} value={type}>{type}</MenuItem>
              ))}
            </TextField>
            <Box sx={{ display: 'flex', alignItems: 'flex-end' }}>
              <Button variant="outlined" onClick={load} disabled={loading}>
                {loading ? 'Loading…' : 'Refresh'}
              </Button>
            </Box>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1.5, display: 'block' }}>
            {filtered.length} of {tickets.length} Identity and Access Management ticket(s) · queues “{identityQueues.join('”, “')}” · promotion: Sandbox → Non-Prod → Production
            {hiddenDoneCount > 0 && (
              <> · {hiddenDoneCount} resolved/closed/cancelled hidden — pick “All statuses” to see {hiddenDoneCount === 1 ? 'it' : 'them'}</>
            )}
          </Typography>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          {loading && tickets.length === 0 ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              Loading tickets from ManageEngine…
            </Typography>
          ) : filtered.length === 0 ? (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
              No tickets match filters.
            </Typography>
          ) : (
            <Stack spacing={1}>
              {filtered.map((t) => {
                const summary = processedSummaries.get(t.id)
                const revokeState = revokeStates.get(t.id)
                const isProcessed =
                  (processedMap.has(t.id) && processedMap.get(t.id)?.processed) ||
                  (summary != null && !summary.revoked)
                const isRevoked = Boolean(summary?.revoked) || revokeState?.phase === 'revoked'
                const hasGroupGrant =
                  (summary?.fulfilment === 'Group' && Boolean(summary?.groupId)) ||
                  (processedMap.get(t.id)?.execution?.Fulfilment === 'Group' && Boolean(processedMap.get(t.id)?.execution?.GroupId))
                const canRevoke =
                  isProcessed &&
                  !isRevoked &&
                  Boolean(summary?.assignmentId || processedMap.get(t.id)?.execution?.AssignmentId || hasGroupGrant)
                const canResendRevokeNotify =
                  isRevoked && summary?.revokeNotePosted !== true && revokeState?.phase !== 'revoking'
                const rawRequestText = stripHtml(t.description) || t.short_description || ''
                const typeLabel = ticketTypeLabel(t)
                const isGrantHandler = templatePayload?.handler === 'azure-subscription-grant'
                const isPendingHandler = templatePayload?.handler === 'pending'
                const requiredFieldSet = new Set(
                  !isGrantHandler ? (templatePayload?.requiredFields ?? []) : [],
                )
                const requiredPlaceholderSet = new Set(
                  !isGrantHandler ? (templatePayload?.requiredPlaceholders ?? []) : [],
                )
                return (
                  <Accordion
                    key={t.id}
                    disableGutters
                    expanded={expanded === t.id}
                    onChange={() => toggleExpand(t)}
                    sx={{ '&:before': { display: 'none' }, border: (th) => `1px solid ${th.palette.divider}`, borderRadius: 1.5 }}
                  >
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ overflow: 'hidden', '& .MuiAccordionSummary-content': { minWidth: 0, overflow: 'hidden' } }}>
                      <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center', width: '100%', pr: 1, minWidth: 0 }}>
                        <StatusPill tone={statusTone(t.status?.name)} label={t.status?.name ?? '—'} />
                        <Box sx={{ flexGrow: 1, minWidth: 0, overflow: 'hidden' }}>
                          <Typography
                            variant="body2"
                            sx={{
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              display: '-webkit-box',
                              WebkitLineClamp: 2,
                              WebkitBoxOrient: 'vertical',
                              wordBreak: 'break-word',
                            }}
                          >
                            <Box component="strong">#{t.id}</Box> {t.subject}
                          </Typography>
                          <Stack direction="row" spacing={0.75} sx={{ alignItems: 'center', flexWrap: 'wrap', mt: 0.35 }}>
                            <Chip
                              size="small"
                              variant="outlined"
                              label={typeLabel}
                              sx={{
                                height: 22,
                                fontWeight: 600,
                                fontSize: '0.7rem',
                                borderRadius: 1,
                                maxWidth: '100%',
                              }}
                            />
                            <Typography variant="caption" color="text.secondary">
                              {t.requester?.name ?? '—'} &middot;
                            </Typography>
                            <StatusPill tone={priorityTone(t.priority?.name)} label={t.priority?.name ?? '—'} />
                            {t.category?.name && (
                              <Typography variant="caption" color="text.secondary">
                                &middot; {t.category.name}
                              </Typography>
                            )}
                            {isProcessed && <StatusPill tone="ok" label="Access Granted" />}
                            {isRevoked && <StatusPill tone="warn" label="Revoked" />}
                          </Stack>
                        </Box>
                        <Stack sx={{ alignItems: 'flex-end' }}>
                          {t.technician?.name && (
                            <Typography variant="caption" color="text.secondary">
                              {t.technician.name}
                            </Typography>
                          )}
                          <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>
                            {t.created_time?.display_value ?? ''}
                          </Typography>
                        </Stack>
                      </Stack>
                    </AccordionSummary>

                    {expanded === t.id && mapping && (
                      <AccordionDetails>
                        {isRevoked && (
                          <Alert severity="warning" sx={{ mb: 2 }}>
                            <Typography variant="body2" sx={{ fontWeight: 600 }}>
                              Access has been revoked
                            </Typography>
                            <Typography variant="body2">
                              Privileged access for this ticket is no longer active. Revoke cannot be run again.
                            </Typography>
                          </Alert>
                        )}
                        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2, minWidth: 0 }}>
                          <Box sx={{ minWidth: 0, maxWidth: '100%', overflow: 'hidden' }}>
                            <Typography variant="subtitle2" sx={{ mb: 1 }}>Ticket Details</Typography>
                            <MetaList
                              rows={[
                                ['Ticket type', typeLabel],
                                ['Subject', t.subject],
                                ['Requester', `${t.requester?.name ?? ''} (${t.requester?.email_id ?? ''})`],
                                ['Status', t.status?.name],
                                ['Priority', t.priority?.name],
                                ...(t.category?.name ? [['Category', t.category.name] as [string, string]] : []),
                                ...(t.subcategory?.name
                                  ? [['Subcategory', t.subcategory.name] as [string, string]]
                                  : []),
                                ['Technician', t.technician?.name ?? 'Unassigned'],
                                ['Created', t.created_time?.display_value ?? '—'],
                                ...(t.due_by_time?.display_value
                                  ? [[
                                      'Due',
                                      <>
                                        {t.due_by_time.display_value}
                                        {t.is_overdue && (
                                          <Box component="span" sx={{ ml: 1 }}>
                                            <StatusPill tone="bad" label="Overdue" />
                                          </Box>
                                        )}
                                      </>,
                                    ] as [string, ReactNode]]
                                  : []),
                              ]}
                            />
                            {(ticketSummary || summaryLoading || rawRequestText) && (
                              <Box
                                sx={{
                                  mt: 1.5,
                                  fontSize: '0.85rem',
                                  color: 'text.secondary',
                                  borderTop: (th) => `1px solid ${th.palette.divider}`,
                                  pt: 1,
                                  minWidth: 0,
                                  maxWidth: '100%',
                                }}
                              >
                                {ticketSummary && (
                                  <Alert
                                    severity={ticketSummary.source === 'llm' ? 'info' : 'warning'}
                                    sx={{ mb: 1.25, fontSize: '0.8rem' }}
                                  >
                                    <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.35 }}>
                                      Description summary
                                    </Typography>
                                    <Typography variant="body2">{ticketSummary.summary}</Typography>
                                    {ticketSummary.highlights && (
                                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.75 }}>
                                        {[
                                          ticketSummary.highlights.who && `Who: ${ticketSummary.highlights.who}`,
                                          ticketSummary.highlights.access && `Access: ${ticketSummary.highlights.access}`,
                                          ticketSummary.highlights.environment && `Env: ${ticketSummary.highlights.environment}`,
                                          ticketSummary.highlights.subscription && `Sub: ${ticketSummary.highlights.subscription}`,
                                        ]
                                          .filter(Boolean)
                                          .join(' · ')}
                                      </Typography>
                                    )}
                                    {ticketSummary.source !== 'llm' && ticketSummary.llmError && (
                                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                                        Detailed summary unavailable. A basic ticket summary is shown.
                                      </Typography>
                                    )}
                                  </Alert>
                                )}
                                {summaryLoading && !ticketSummary && (
                                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                    Preparing description summary…
                                  </Typography>
                                )}
                                {rawRequestText && (
                                  <Box>
                                    <Button
                                      size="small"
                                      color="inherit"
                                      onClick={() => setRawDescriptionOpen((v) => !v)}
                                      endIcon={
                                        <ExpandMoreIcon
                                          sx={{
                                            transform: rawDescriptionOpen ? 'rotate(180deg)' : 'none',
                                            transition: 'transform 0.2s',
                                          }}
                                        />
                                      }
                                      sx={{ px: 0.5, mb: 0.5, textTransform: 'none', color: 'text.secondary' }}
                                    >
                                      {rawDescriptionOpen ? 'Hide request text' : 'Show request text'}
                                    </Button>
                                    <Collapse in={rawDescriptionOpen}>
                                      <Typography
                                        variant="body2"
                                        component="div"
                                        color="text.secondary"
                                        sx={{
                                          whiteSpace: 'pre-wrap',
                                          overflowWrap: 'anywhere',
                                          wordBreak: 'break-word',
                                          maxHeight: 280,
                                          overflow: 'auto',
                                          pr: 0.5,
                                          bgcolor: (th) => th.palette.action.hover,
                                          borderRadius: 1,
                                          p: 1,
                                        }}
                                      >
                                        {rawRequestText}
                                      </Typography>
                                    </Collapse>
                                  </Box>
                                )}
                              </Box>
                            )}
                          </Box>

                          <Box sx={{ minWidth: 0, maxWidth: '100%' }}>
                            <Typography variant="subtitle2" sx={{ mb: 1 }}>Request fields</Typography>
                            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1.5 }}>
                              {isGrantHandler
                                ? 'Required access details taken from the ticket. Fields stay fixed for the audit trail — the agent acts on what the requester asked for.'
                                : 'Fields supplied on this ManageEngine request. Non–Azure Subscription requests are recorded as structured intake until an action handler exists.'}
                            </Typography>
                            {templatePayload && !templatePayload.knownSchema && (
                              <Alert severity="warning" sx={{ mb: 1.5 }}>
                                Unknown template schema — showing common ticket details only.
                              </Alert>
                            )}
                            {isPendingHandler && (
                              <Alert severity="info" sx={{ mb: 1.5 }}>
                                Structured intake recorded — action handler pending.
                              </Alert>
                            )}
                            {(result?.decision.Path === 'Duplicate-Assignment' ||
                              processedMap.get(t.id)?.duplicateBlocked ||
                              processedMap.get(t.id)?.decision.Path === 'Duplicate-Assignment') && (
                              <Alert severity="warning" sx={{ mb: 1.5 }}>
                                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                                  Duplicate access request
                                </Typography>
                                <Typography variant="body2">
                                  {result?.decision.Path === 'Duplicate-Assignment'
                                    ? result.decision.Reason
                                    : processedMap.get(t.id)?.decision.Reason ||
                                      'The requester is already a member of the Entra RBAC group for this subscription and role. This ticket will not be processed.'}
                                </Typography>
                              </Alert>
                            )}
                            {isGrantHandler && mappingWarnings.length > 0 && (
                              <Alert severity="warning" sx={{ mb: 1.5, fontSize: '0.8rem' }}>
                                <Box component="strong">Validation needs attention:</Box>
                                <Box component="ul" sx={{ m: '0.35rem 0 0', pl: '1.1rem' }}>
                                  {mappingWarnings.map((w, i) => <li key={i}>{w}</li>)}
                                </Box>
                              </Alert>
                            )}
                            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 1.5 }}>
                              <TextField
                                label="Ticket type"
                                value={typeLabel}
                                size="small"
                                placeholder="Unspecified"
                                helperText="ManageEngine request template"
                                slotProps={{ input: { readOnly: true } }}
                              />
                              {templatePayload?.fieldOrder
                                .filter(
                                  (fieldName) =>
                                    !isGrantHandler ||
                                    !['Subscription', 'Azure Role', 'Environment'].includes(fieldName),
                                )
                                .map((fieldName) => {
                                  const supplied = (templatePayload.fields[fieldName] || '').trim()
                                  const isMissing = !supplied
                                  return (
                                <TextField
                                  key={fieldName}
                                  label={fieldName}
                                  value={isMissing ? 'Missing' : supplied}
                                  size="small"
                                  required={requiredFieldSet.has(fieldName)}
                                  placeholder="Missing"
                                  helperText={
                                    requiredFieldSet.has(fieldName)
                                      ? 'Required on the ManageEngine form'
                                      : isMissing
                                        ? 'Not supplied on the ManageEngine ticket'
                                        : undefined
                                  }
                                  slotProps={{ input: { readOnly: true } }}
                                  sx={{
                                    ...(fieldName === 'Business Justification' ||
                                    fieldName === 'Exception Request'
                                      ? { gridColumn: '1 / -1' }
                                      : {}),
                                    ...(isMissing
                                      ? {
                                          '& .MuiInputBase-input': {
                                            color: 'text.secondary',
                                            fontStyle: 'italic',
                                          },
                                        }
                                      : {}),
                                  }}
                                />
                                  )
                                })}
                              {isGrantHandler && (
                                <>
                              <TextField
                                label="Azure Role"
                                value={
                                  mapping.MeAzureRole
                                    ? mapping.MeAzureRole !== mapping.Role && mapping.Role
                                      ? `${mapping.MeAzureRole} → ${mapping.Role}`
                                      : mapping.MeAzureRole
                                    : mapping.Role || ''
                                }
                                size="small"
                                error={!mapping.Role}
                                helperText={
                                  mapping.MeAzureRole
                                    ? mapping.MeAzureRole !== mapping.Role && mapping.Role
                                      ? 'From ManageEngine Azure Role (normalized for validation)'
                                      : 'From ManageEngine Azure Role'
                                    : mapping.Role
                                      ? 'Inferred from ticket text'
                                      : 'Required — Azure Role missing on the ManageEngine ticket'
                                }
                                placeholder="Not supplied in ticket"
                                slotProps={{ input: { readOnly: true } }}
                              />
                              {/*
                                FR1 — Environment is mandatory. When ManageEngine supplied a value
                                that maps cleanly, it stays read-only so the audit trail reflects
                                what the requester actually asked for. When it did not map (or was
                                absent), the operator must choose one before the agent can act —
                                environment is the primary prioritization signal, so an unresolved
                                environment is a hard stop rather than a silent default.
                              */}
                              {mapping.MeEnvironment && mapping.Environment ? (
                                <TextField
                                  label="Environment (required)"
                                  value={`${mapping.MeEnvironment} → ${mapping.Environment}`}
                                  size="small"
                                  helperText="From the ManageEngine Environment dropdown"
                                  slotProps={{ input: { readOnly: true } }}
                                />
                              ) : (
                                <TextField
                                  select
                                  label="Environment (required)"
                                  value={mapping.Environment || ''}
                                  size="small"
                                  error={!mapping.Environment}
                                  onChange={(e) => updateMapping('Environment', e.target.value)}
                                  helperText={
                                    mapping.MeEnvironment
                                      ? `ManageEngine sent "${mapping.MeEnvironment}", which does not map to Sandbox / Non-Prod / Production — choose one`
                                      : 'Not supplied on the ticket — choose one. Prioritization keys off environment.'
                                  }
                                >
                                  <MenuItem value="Sandbox">Sandbox</MenuItem>
                                  <MenuItem value="NonProd">Non-Prod</MenuItem>
                                  <MenuItem value="Production">Production</MenuItem>
                                </TextField>
                              )}
                              <TextField
                                select
                                label="Priority"
                                value={mapping.Priority}
                                size="small"
                                onChange={(e) => updateMapping('Priority', e.target.value)}
                                helperText="Optional, defaults to P4. Orders tickets within an environment band only."
                              >
                                <MenuItem value="P1">P1</MenuItem>
                                <MenuItem value="P2">P2</MenuItem>
                                <MenuItem value="P3">P3</MenuItem>
                                <MenuItem value="P4">P4</MenuItem>
                              </TextField>
                              <TextField
                                type="number"
                                label="Duration (days)"
                                value={mapping.DurationDays}
                                size="small"
                                slotProps={{ input: { readOnly: true } }}
                              />
                              <TextField
                                select
                                label="Subscription"
                                value={
                                  mapping.SubscriptionId ||
                                  (mapping.MeSubscriptionType
                                    ? `name:${mapping.MeSubscriptionType}`
                                    : '')
                                }
                                size="small"
                                sx={{ gridColumn: '1 / -1' }}
                                error={!mapping.SubscriptionId}
                                helperText={
                                  mapping.SubscriptionId
                                    ? mapping.MeSubscriptionType
                                      ? `ManageEngine "${mapping.MeSubscriptionType}" → live MG allowlist`
                                      : 'Matched to live MG allowlist'
                                    : mapping.MeSubscriptionType
                                      ? `${mapping.MeSubscriptionType} is not allowlisted — pick an allowlisted subscription`
                                      : 'Missing on ManageEngine ticket — select a subscription'
                                }
                                onChange={(e) => {
                                  const v = e.target.value
                                  const opt = buildAllowlistSelectOptions(subscriptions).find(
                                    (o) => o.value === v,
                                  )
                                  setMapping((m) => {
                                    if (!m) return m
                                    if (!v) {
                                      return {
                                        ...m,
                                        SubscriptionId: '',
                                        SubscriptionSource: '',
                                      }
                                    }
                                    // Keep ME-provided name visible when still unmapped.
                                    if (v.startsWith('name:')) {
                                      return {
                                        ...m,
                                        SubscriptionId: '',
                                        MeSubscriptionType: v.slice(5),
                                        SubscriptionSource: 'udf',
                                      }
                                    }
                                    const bare =
                                      opt?.label.replace(/\s*\([0-9a-f-]{36}\)\s*$/i, '').trim() ||
                                      m.MeSubscriptionType
                                    return {
                                      ...m,
                                      SubscriptionId: v,
                                      // Preserve original ME value when operator overrides an unlisted name.
                                      MeSubscriptionType: m.MeSubscriptionType || bare,
                                      SubscriptionSource: 'udf',
                                    }
                                  })
                                }}
                              >
                                {!mapping.SubscriptionId && !mapping.MeSubscriptionType && (
                                  <MenuItem value="">
                                    <em>missing — select subscription…</em>
                                  </MenuItem>
                                )}
                                {!mapping.SubscriptionId && mapping.MeSubscriptionType && (
                                  <MenuItem value={`name:${mapping.MeSubscriptionType}`}>
                                    {mapping.MeSubscriptionType} — not allowlisted
                                  </MenuItem>
                                )}
                                {buildAllowlistSelectOptions(
                                  ensureSubscriptionInCatalog(
                                    subscriptions,
                                    mapping.SubscriptionId,
                                    mapping.MeSubscriptionType || undefined,
                                  ),
                                ).map((s) => (
                                  <MenuItem key={s.value} value={s.value}>
                                    {s.label}
                                  </MenuItem>
                                ))}
                              </TextField>
                                </>
                              )}
                              <TextField
                                label="Requester UPN"
                                value={
                                  mapping.RequesterUpn ||
                                  templatePayload?.common.requesterEmail ||
                                  'Missing'
                                }
                                size="small"
                                sx={{
                                  gridColumn: '1 / -1',
                                  ...(!(
                                    mapping.RequesterUpn ||
                                    templatePayload?.common.requesterEmail
                                  )
                                    ? {
                                        '& .MuiInputBase-input': {
                                          color: 'text.secondary',
                                          fontStyle: 'italic',
                                        },
                                      }
                                    : {}),
                                }}
                                required={requiredPlaceholderSet.has('Requester UPN')}
                                placeholder="Missing"
                                helperText={
                                  requiredPlaceholderSet.has('Requester UPN')
                                    ? 'Required on the ManageEngine form'
                                    : !(
                                          mapping.RequesterUpn ||
                                          templatePayload?.common.requesterEmail
                                        )
                                      ? 'Not supplied on the ManageEngine ticket'
                                      : undefined
                                }
                                slotProps={{ input: { readOnly: true } }}
                              />
                            </Box>
                            <Stack direction="row" spacing={1} sx={{ mt: 1.5, flexWrap: 'wrap' }}>
                              {isGrantHandler && !isProcessed && (
                                <Button
                                  variant="contained"
                                  disabled={evaluating || !mapping.SubscriptionId || !mapping.Role}
                                  onClick={() => runEvaluate(t.id)}
                                >
                                  {evaluating ? 'Checking…' : 'Run Validation'}
                                </Button>
                              )}
                              {isGrantHandler && result && !isProcessed &&
                                ['Grant', 'Eligible', 'BreakGlass'].includes(result.decision.Action) && (
                                <Button
                                  variant="contained"
                                  color="success"
                                  disabled={processing || !mapping.SubscriptionId || !mapping.Role}
                                  onClick={() => runProcess(t.id)}
                                >
                                  {processing ? 'Providing access…' : 'Provide Access'}
                                </Button>
                              )}
                              {canRevoke && (
                                <Button
                                  variant="outlined"
                                  color="warning"
                                  disabled={revoking || revokeState?.phase === 'revoking'}
                                  onClick={() => runRevoke(t.id)}
                                >
                                  {revoking ? 'Revoking…' : 'Revoke Access'}
                                </Button>
                              )}
                              {canResendRevokeNotify && (
                                <Button
                                  variant="outlined"
                                  color="warning"
                                  disabled={revoking}
                                  onClick={() => runRevoke(t.id)}
                                >
                                  {revoking ? 'Sending…' : 'Notify Requester of Revoke'}
                                </Button>
                              )}
                              {isProcessed && !isRevoked && <StatusPill tone="ok" label="Access Active" />}
                              {isRevoked && <StatusPill tone="warn" label="Access Revoked" />}
                            </Stack>
                            {revokeState && (
                              <Alert
                                severity={
                                  revokeState.phase === 'failed'
                                    ? 'error'
                                    : revokeState.phase === 'revoked'
                                      ? 'success'
                                      : 'info'
                                }
                                sx={{ mt: 1.5 }}
                              >
                                {revokeState.message}
                              </Alert>
                            )}
                          </Box>
                        </Box>

                        {isGrantHandler && result && (
                          <Box sx={{ mt: 3, borderTop: (th) => `1px solid ${th.palette.divider}`, pt: 2 }}>
                            <Typography variant="subtitle2" sx={{ mb: 1.5 }}>Validation Result</Typography>
                            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
                              <Box>
                                <DecisionTrace steps={result.steps} />
                              </Box>
                              <Box>
                                <Paper variant="outlined" sx={{ p: 2 }}>
                                  <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center', mb: 1 }}>
                                    <ActionBadge action={result.decision.Action} />
                                    <Box component="strong">{result.decision.Path}</Box>
                                  </Stack>
                                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
                                    {result.decision.Reason}
                                  </Typography>
                                  <MetaList
                                    rows={[
                                      ['Ticket ID', <Box key="tid" component="code">ME-{t.id}</Box>],
                                      ...(result.decision.SlaHours != null
                                        ? [['SLA', `${result.decision.SlaHours}h`] as [string, string]]
                                        : []),
                                      ...(result.decision.ApproverTier
                                        ? [['Approver Tier', result.decision.ApproverTier] as [string, string]]
                                        : []),
                                      ...(result.decision.Runbook
                                        ? [['Runbook', result.decision.Runbook] as [string, string]]
                                        : []),
                                      ...(result.decision.MfaRequired != null
                                        ? [['MFA Required', result.decision.MfaRequired ? 'Yes' : 'No'] as [string, string]]
                                        : []),
                                      ...(result.decision.AssignmentType
                                        ? [['Assignment Type', result.decision.AssignmentType] as [string, string]]
                                        : []),
                                    ]}
                                  />
                                </Paper>
                              </Box>
                            </Box>
                          </Box>
                        )}

                        {isRevoked && processedSummaries.has(t.id) && (() => {
                          const s = processedSummaries.get(t.id)!
                          return (
                            <Box sx={{ mt: 3, borderTop: (th) => `2px solid ${th.palette.warning.main}`, pt: 2 }}>
                              <Typography variant="subtitle2" color="warning.main" sx={{ mb: 1.5 }}>
                                Access Revoked
                              </Typography>
                              <MetaList
                                rows={[
                                  ['Role', `${s.role ?? '—'} on ${s.subscriptionId ?? '—'}`],
                                  ['Requester', s.requesterUpn ?? '—'],
                                  (s.fulfilment === 'Group'
                                    ? ['Entra RBAC group', <Box key="rgrp" component="code">{s.groupName ?? s.groupId ?? '—'}</Box>]
                                    : ['Assignment ID', <Box key="raid" component="code">{s.assignmentId ?? '—'}</Box>]) as [string, ReactNode],
                                  ...(s.revokedAt
                                    ? [['Revoked', new Date(s.revokedAt).toLocaleString()] as [string, string]]
                                    : []),
                                ]}
                              />
                              {s.revokeNotePosted && (
                                <Typography variant="caption" color="success.dark" sx={{ display: 'block', mt: 1 }}>
                                  Revocation note posted to ManageEngine ticket #{t.id}
                                  {s.revokeNotifyRequester
                                    ? ' — requester notified (portal + email via ME note rules)'
                                    : ' — visible to requester'}
                                </Typography>
                              )}
                              {s.revokeNoteError && (
                                <Typography variant="caption" color="error.main" sx={{ display: 'block', mt: 1 }}>
                                  ME revoke note failed: {s.revokeNoteError}
                                </Typography>
                              )}
                            </Box>
                          )
                        })()}

                        {isProcessed && !processedMap.has(t.id) && processedSummaries.has(t.id) && (() => {
                          const s = processedSummaries.get(t.id)!
                          return (
                            <Box sx={{ mt: 3, borderTop: (th) => `2px solid ${th.palette.success.main}`, pt: 2 }}>
                              <Typography variant="subtitle2" color="success.dark" sx={{ mb: 1.5 }}>
                                Processed by AzureSentry — {s.action}
                              </Typography>
                              <MetaList
                                rows={[
                                  ['Role', `${s.role} on ${s.subscriptionId}`],
                                  ['Requester', s.requesterUpn],
                                  (s.fulfilment === 'Group'
                                    ? ['Entra RBAC group', <Box key="grp" component="code">{s.groupName ?? s.groupId ?? '—'}</Box>]
                                    : ['Assignment ID', <Box key="aid" component="code">{s.assignmentId}</Box>]) as [string, ReactNode],
                                  ['Expires', s.fulfilment === 'Group' ? 'Permanent (group membership)' : (s.expiresAt ? new Date(s.expiresAt).toLocaleString() : '—')],
                                  ['PIM Client', (
                                    <>
                                      {s.pimClient}
                                      {s.pimClient === 'Graph' && (
                                        <Box component="span" sx={{ ml: 0.75 }}>
                                          <StatusPill tone="ok" label="Real PIM grant via automation SPN" />
                                        </Box>
                                      )}
                                    </>
                                  )],
                                  ...(s.processedAt
                                    ? [['Processed', new Date(s.processedAt).toLocaleString()] as [string, string]]
                                    : []),
                                ]}
                              />
                              {s.notePosted && (
                                <Typography variant="caption" color="success.dark" sx={{ display: 'block', mt: 1 }}>
                                  Note posted to ManageEngine ticket #{t.id}
                                  {s.notifyRequester
                                    ? ' — requester notified (portal + email via ME note rules)'
                                    : ' — visible to requester'}
                                </Typography>
                              )}
                            </Box>
                          )
                        })()}

                        {processedMap.has(t.id) && (() => {
                          const pr = processedMap.get(t.id)!
                          const isDuplicate = pr.duplicateBlocked || pr.decision.Path === 'Duplicate-Assignment'
                          const resultColor = pr.processed ? 'success.main' : isDuplicate ? 'warning.main' : 'error.main'
                          const resultText = pr.processed ? 'success.dark' : resultColor
                          return (
                            <Box
                              sx={{
                                mt: 3,
                                borderTop: '2px solid',
                                borderTopColor: resultColor,
                                pt: 2,
                              }}
                            >
                              <Typography variant="subtitle2" color={resultText} sx={{ mb: 1.5 }}>
                                {pr.processed
                                  ? pr.execution?.GroupAlreadyExisted
                                    ? 'Access Granted (group already existed)'
                                    : 'Access Granted'
                                  : isDuplicate
                                    ? 'Duplicate request — not processed'
                                    : 'Processing Blocked'}
                              </Typography>
                              {pr.execution && pr.execution.Success === false && (
                                <Typography variant="body2" color="error.main" sx={{ mt: 0.5 }}>
                                  <Box component="strong">{pr.execution.PimClient} PIM error:</Box> {pr.execution.Error}
                                </Typography>
                              )}
                              {pr.processed && pr.execution?.GroupAlreadyExisted && pr.execution.GroupName && (
                                <Alert severity="info" sx={{ mb: 1.5 }}>
                                  Entra group <Box component="strong">{pr.execution.GroupName}</Box> already exists —
                                  the requester was added to it (no new group was created).
                                </Alert>
                              )}
                              {pr.execution && pr.execution.Success !== false && (
                                <MetaList
                                  rows={[
                                    ...(pr.execution.AlreadyExisted
                                      ? [['Status', 'Already present (idempotent)'] as [string, string]]
                                      : []),
                                    ...(pr.execution.GroupAlreadyExisted && pr.execution.GroupName
                                      ? [['Group', `Already exists: ${pr.execution.GroupName}`] as [string, string]]
                                      : pr.execution.GroupCreated && pr.execution.GroupName
                                        ? [['Group', `Created: ${pr.execution.GroupName}`] as [string, string]]
                                        : pr.execution.GroupName
                                          ? [['Group', pr.execution.GroupName] as [string, string]]
                                          : []),
                                    ...(pr.execution.Message
                                      ? [['Details', pr.execution.Message] as [string, string]]
                                      : []),
                                    ...(pr.execution.AssignmentId
                                      ? [['Assignment ID', <Box key="aid" component="code">{pr.execution.AssignmentId}</Box>] as [string, ReactNode]]
                                      : []),
                                    ...(pr.execution.AssignmentType === 'GroupMembership'
                                      ? [['Expires', 'Permanent (group membership)'] as [string, string]]
                                      : [['Expires', pr.execution.ExpiresAt ? new Date(pr.execution.ExpiresAt).toLocaleString() : '—'] as [string, string]]),
                                    ['PIM Client', (
                                      <>
                                        {pr.execution.PimClient}
                                        {pr.execution.PimClient === 'Mock' && (
                                          <Box component="span" sx={{ ml: 0.75 }}>
                                            <StatusPill tone="warn" label="Graph admin consent pending — will use real PIM when B1 clears" />
                                          </Box>
                                        )}
                                        {pr.execution.PimClient === 'Graph' && (
                                          <Box component="span" sx={{ ml: 0.75 }}>
                                            <StatusPill tone="ok" label="Real PIM grant via automation SPN" />
                                          </Box>
                                        )}
                                      </>
                                    )],
                                    ...(pr.execution.AssignmentType
                                      ? [['Type', pr.execution.AssignmentType] as [string, string]]
                                      : []),
                                  ]}
                                />
                              )}
                              {pr.meUpdate && !('error' in pr.meUpdate) && (
                                <Typography variant="caption" color="success.dark" sx={{ display: 'block', mt: 1 }}>
                                  Note posted to ManageEngine ticket #{t.id}
                                  {pr.meUpdate.notifyRequester
                                    ? ' — requester notified (portal + email via ME note rules)'
                                    : pr.meUpdate.showToRequester
                                      ? ' — visible to requester'
                                      : ''}
                                  {pr.meUpdate.warning ? ` (${pr.meUpdate.warning})` : ''}
                                </Typography>
                              )}
                              {pr.meUpdate && 'error' in pr.meUpdate && (
                                <Typography variant="caption" color="error.main" sx={{ display: 'block', mt: 1 }}>
                                  ME note failed: {pr.meUpdate.error}
                                </Typography>
                              )}
                              {!pr.processed && (
                                <Typography variant="body2" color="text.secondary">
                                  Decision: {pr.decision.Action} — {pr.decision.Reason}
                                </Typography>
                              )}
                            </Box>
                          )
                        })()}
                      </AccordionDetails>
                    )}
                  </Accordion>
                )
              })}
            </Stack>
          )}
        </CardContent>
      </Card>
    </>
  )
}
