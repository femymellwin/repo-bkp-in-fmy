/**
 * Flatten ManageEngine UDF / nested pick values into searchable text.
 * Subscription and role are often only on template pick fields (e.g. udf_pick_3728),
 * not in the free-text description.
 */
export function flattenUdfFields(udf: unknown): string {
  if (udf == null) return ''
  const parts: string[] = []

  const walk = (value: unknown): void => {
    if (value == null) return
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      const s = String(value).trim()
      if (s) parts.push(s)
      return
    }
    if (Array.isArray(value)) {
      for (const item of value) walk(item)
      return
    }
    if (typeof value === 'object') {
      const obj = value as Record<string, unknown>
      // Prefer human-readable pick "name" over internal ids.
      if (typeof obj.name === 'string' && obj.name.trim()) {
        parts.push(obj.name.trim())
      }
      for (const [k, v] of Object.entries(obj)) {
        if (k === 'id' || k === 'name' || k === 'color') continue
        walk(v)
      }
    }
  }

  walk(udf)
  return parts.join(' ')
}

export function collectTicketParseText(ticket: {
  subject?: string
  description?: string
  short_description?: string
  category?: { name?: string }
  subcategory?: { name?: string }
  udf_fields?: unknown
}): string {
  const stripHtml = (s?: string) =>
    (s ?? '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/\s+/g, ' ')
      .trim()

  return [
    ticket.subject ?? '',
    stripHtml(ticket.description),
    stripHtml(ticket.short_description),
    ticket.category?.name ?? '',
    ticket.subcategory?.name ?? '',
    flattenUdfFields(ticket.udf_fields),
  ]
    .filter(Boolean)
    .join(' ')
}
