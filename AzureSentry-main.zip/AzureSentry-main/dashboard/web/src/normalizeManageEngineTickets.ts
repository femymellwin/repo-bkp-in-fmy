import type { METicket } from './types'

type ManageEngineTicket = Omit<METicket, 'id'> & { id: number | string }

export function normalizeManageEngineTickets(tickets: ManageEngineTicket[]): METicket[] {
  return tickets.map((ticket) => ({
    ...ticket,
    id: Number(ticket.id),
  }))
}
