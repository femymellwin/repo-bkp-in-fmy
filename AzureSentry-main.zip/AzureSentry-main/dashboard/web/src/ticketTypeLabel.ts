import type { METicket } from './types'

export const UNSPECIFIED_TICKET_TYPE = 'Unspecified'

/**
 * ManageEngine service template name (General Access, ADO, GitHub Enterprise,
 * Infrastructure, Azure Subscription, …). Used as the ticket-type placeholder.
 */
export function ticketTypeLabel(
  ticket?: Pick<METicket, 'template'> | { template?: unknown } | null,
): string {
  const template = ticket?.template as unknown
  if (typeof template === 'string' && template.trim()) return template.trim()
  if (template && typeof template === 'object') {
    const name = (template as { name?: unknown }).name
    if (typeof name === 'string' && name.trim()) return name.trim()
  }
  return UNSPECIFIED_TICKET_TYPE
}
