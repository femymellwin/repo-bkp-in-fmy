# AzureSentry Dashboard (Prototype)

Visual demonstration of the RBAC/PIM agentic platform — **React + MUI** UI with a G42-inspired light theme. The dashboard calls the **real** `Resolve-RbacDecision` PowerShell module and `MockPimClient` for safe end-to-end simulation.

## Prerequisites

- **Node.js 18+** and npm
- **PowerShell** 5.1+ (7.2+ recommended) for the API

## Quick start (recommended)

From `dashboard/web` — starts the API automatically, then Vite:

```powershell
cd dashboard\web
npm install          # first time only
npm run dev
```

Open **http://localhost:5173**

From the repo root (same stack; optional Real PIM mode). Run via PowerShell — Explorer / bare `.ps1` opens Notepad on many Windows setups:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\dashboard\Start-Local.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\dashboard\Start-Local.ps1 -Mode Real
```

Live stakeholder walkthrough: [`docs/DEMO_GUIDE.md`](../docs/DEMO_GUIDE.md).

### Manual two-terminal mode

**Terminal 1 — API (must run first):**
```powershell
cd dashboard\api
.\Start-DashboardApi.ps1
```

**Terminal 2 — UI:**
```powershell
cd dashboard\web
npm run dev:vite
```

### Single-server mode (after build)

```powershell
cd dashboard\web
npm run build
cd ..\api
.\Start-DashboardApi.ps1
```

Open **http://localhost:8787** — API serves the built static files.

## Features

| View | Description |
|------|-------------|
| **Overview** | Stats + SLA snapshot + expiry alerts + recent activity |
| **Request Simulator** | Submit tickets, see 7-step decision tree, simulate grants |
| **Access Audit** | Filterable audit log with expandable 7-step decision trace |
| **SLA Compliance** | P1–P4 compliance gauges, breach list (4h/8h/24h/48h tiers) |
| **Expiry Tracking** | Active assignments with time-remaining indicators |
| **Break-Glass** | Emergency P1 grants with 4-hour review status |
| **Eligibility Matrix** | Scope §2.2 matrix from `eligibility-matrix.json` |
| **Architecture** | Platform layer diagram |

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/matrix` | Eligibility matrix JSON |
| GET | `/api/presets` | Demo ticket presets |
| GET | `/api/stats` | Session counters |
| GET | `/api/activity` | Audit log (filters: `requester`, `role`, `environment`, `action`, `hours`) |
| GET | `/api/sla` | SLA compliance metrics by P1–P4 tier |
| GET | `/api/assignments` | Active assignments with expiry urgency |
| GET | `/api/breakglass` | Break-glass grants with review status |
| POST | `/api/evaluate` | Run decision tree only |
| POST | `/api/simulate` | Decision + Mock PIM grant |

## Backend

- `src/RbacDecision/` — decision engine (no mocks)
- `src/PimClient/MockPimClient.psm1` — PIM simulation for demo grants only
- Config: `dashboard/api/config.json` (demo subscription allowlist)
