<#
.SYNOPSIS
    Narrated end-to-end demo runner for AzureSentry. Drives the SAME API the dashboard
    UI calls, for a real ManageEngine ticket raised by a requester (the #2858 scenario),
    and exercises every capability the platform has today.

.DESCRIPTION
    Steps (each can pause with -Pause so you can narrate to an audience):
      1. Preflight  - API health + PIM mode (Mock vs real Graph/SPN).
      2. Intake     - fetch the ticket from ManageEngine; parse role/sub/env/requester.
      3. Evaluate   - POST /api/evaluate; show the 7-step decision trace + action.
      4. Process    - POST /api/manageengine/process; real PIM grant (active for Sandbox,
                      eligible for Production) + note posted back to the ticket.
      5. Idempotency- process again; show it does NOT double-grant (alreadyProcessed).
      6. Verify     - query Azure directly; prove the assignment is real and time-bound.
      7. Persisted  - GET /api/manageengine/processed; show durable dashboard state.
      8. Resolve    - (optional -Resolve) move the ticket to Resolved with closure fields.
      9. Cleanup    - (optional -Cleanup) remove the created assignment for a repeatable demo.

    The grant is real only if the API was started in real mode
    (dashboard/Start-Local.ps1 -Mode Real). Otherwise it runs against the Mock client.
    Azure verification / resolve use the SPN creds in .env.

.PARAMETER TicketId
    The ManageEngine request id raised by the requester (e.g. 2858).

.EXAMPLE
    ./Invoke-DemoScenario.ps1 -TicketId 2901 -Pause
.EXAMPLE
    ./Invoke-DemoScenario.ps1 -TicketId 2901 -Resolve -Cleanup
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$TicketId,
    [string]$ApiBase = 'http://127.0.0.1:8787',
    [string]$Role,
    [string]$Environment,
    [string]$SubscriptionId,
    [string]$RequesterUpn,
    [int]$DurationDays = 0,
    [switch]$Resolve,
    [switch]$Cleanup,
    [switch]$Pause
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$repoRoot = Split-Path $PSScriptRoot -Parent

# --- .env (ManageEngine + SPN creds) ---
$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            [Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], 'Process')
        }
    }
}
$meBase = if ($env:MANAGE_ENGINE_URL) { $env:MANAGE_ENGINE_URL } elseif ($env:MANAGE_ENGINE_BASE_URL) { $env:MANAGE_ENGINE_BASE_URL } else { $null }
if ($meBase) { $meBase = $meBase.TrimEnd('/') }
$meKey  = $env:MANAGE_ENGINE_API_KEY

$RoleIds = @{
    'Reader' = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'; 'Contributor' = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
    'Owner' = '8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d'; 'User Access Administrator' = '18d7d88d-d35e-4fb5-a5c3-7773c20a72d9'
}

function Step { param([int]$N, [string]$Title)
    Write-Host ''
    Write-Host ("=" * 70) -ForegroundColor DarkCyan
    Write-Host (" STEP {0}  {1}" -f $N, $Title) -ForegroundColor Cyan
    Write-Host ("=" * 70) -ForegroundColor DarkCyan
    if ($Pause) { Read-Host '   [Enter] to run this step' | Out-Null }
}
function Info { param($m) Write-Host "   $m" }
function Good { param($m) Write-Host "   $m" -ForegroundColor Green }
function Warn { param($m) Write-Host "   $m" -ForegroundColor Yellow }
function Get-Token { param([string]$Resource)
    (Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$($env:AZURE_TENANT_ID)/oauth2/v2.0/token" `
        -Body @{ grant_type='client_credentials'; client_id=$env:AZURE_CLIENT_ID; client_secret=$env:AZURE_CLIENT_SECRET; scope="$Resource/.default" } `
        -ContentType 'application/x-www-form-urlencoded').access_token
}
function Resolve-Oid { param([string]$Upn, [string]$GraphToken)
    try { return (Invoke-RestMethod -Headers @{Authorization="Bearer $GraphToken"} -Uri "https://graph.microsoft.com/v1.0/users/$([uri]::EscapeDataString($Upn))?`$select=id").id } catch {}
    $f = [uri]::EscapeDataString("mail eq '$Upn' or userPrincipalName eq '$Upn'")
    $r = Invoke-RestMethod -Headers @{Authorization="Bearer $GraphToken"} -Uri "https://graph.microsoft.com/v1.0/users?`$filter=$f&`$select=id&`$top=1"
    if ($r.value.Count -ge 1) { return $r.value[0].id }
    return $null
}

Write-Host ''
Write-Host 'AzureSentry - End-to-End Demo Scenario' -ForegroundColor Cyan
Write-Host "ManageEngine ticket #$TicketId (raised by the requester)" -ForegroundColor Cyan

# ============================ STEP 1 - Preflight ============================
Step 1 'Preflight - API + PIM mode'
$health = Invoke-RestMethod -Uri "$ApiBase/api/health" -TimeoutSec 5
Good "API healthy: $($health.service) (port $($health.port))"
$pimMode = $health.modules.pimClient
# The process endpoint uses real Graph when the API was started with AZURESENTRY_PIM_CLIENT=Graph.
try {
    $armToken = Get-Token 'https://management.azure.com'
    $graphToken = Get-Token 'https://graph.microsoft.com'
    Good "SPN token acquired - real Azure verification available (app id $($env:AZURE_CLIENT_ID))"
    $realCapable = $true
} catch { Warn "No SPN token (verification limited): $($_.Exception.Message)"; $realCapable = $false }

# ============================ STEP 2 - Intake ==============================
Step 2 'Intake - fetch + parse the ManageEngine ticket'
if (-not $meBase -or -not $meKey) { throw 'ManageEngine not configured in .env (MANAGE_ENGINE_URL / MANAGE_ENGINE_API_KEY).' }
$req = (Invoke-RestMethod -Uri "$meBase/api/v3/requests/$TicketId" -Headers @{authtoken=$meKey} -Method Get -TimeoutSec 30).request
$desc = ($req.description -replace '<[^>]+>', ' ')
Info "Subject   : $($req.subject)"
Info "Requester : $($req.requester.name) <$($req.requester.email_id)>"
Info "Status    : $($req.status.name)"
# Parse the #2858-style body (params override parsing). Also match subscription *names*
# in subject/body (e.g. "ceo-sub-application") — never silently default a GUID.
if (-not $Role -and $desc -match 'Role\s*:?\s*(User Access Administrator|Contributor|Reader|Owner)') { $Role = $Matches[1] }
if (-not $Environment -and $desc -match 'Environment\s*:?\s*(Sandbox|Production)') { $Environment = $Matches[1] }
$blob = "$($req.subject) $desc"
if (-not $SubscriptionId -and $blob -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
    $SubscriptionId = $Matches[1]
}
if (-not $SubscriptionId) {
    $nameMap = [ordered]@{
        'ceo-sub-application'         = '1251f2d0-787f-4063-8b74-178ad167c682'
        'inception-internal-product'  = '5a23842e-609d-42d4-bae5-e48e00e5b28d'
        'inception-ai-sandbox'        = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
        'shared-applications'         = '1f0eb417-e64c-4f97-9b12-261157d44b6d'
        'inception-sandbox-dev'       = '1726ee00-8a2d-4e60-839b-e794dc004ee1'
        'sbx-openclaw-poc'            = '334431cf-6b07-4549-8ab7-d5bca4280a47'
        'incep-data-platform'         = '428f239f-9870-46e9-b720-95671fe331da'
    }
    $hay = ($blob -replace 'subscriptioin', 'subscription').ToLowerInvariant()
    foreach ($k in $nameMap.Keys) {
        if ($hay.Contains($k)) { $SubscriptionId = $nameMap[$k]; break }
    }
}
if (-not $RequesterUpn) {
    if ($desc -match 'User\s*:?\s*([^\s<>]+@[^\s<>]+)') { $RequesterUpn = $Matches[1].Trim() }
    else { $RequesterUpn = $req.requester.email_id }
}
if ($DurationDays -le 0) { $DurationDays = 7 }
if (-not $Role -or -not $Environment -or -not $SubscriptionId -or -not $RequesterUpn) {
    throw "Could not derive all inputs from the ticket. Supply -Role/-Environment/-SubscriptionId/-RequesterUpn. Got: Role=$Role Env=$Environment Sub=$SubscriptionId Upn=$RequesterUpn"
}
Write-Host ''
Info "Mapped decision inputs:"
Good "  Role=$Role  Environment=$Environment  Sub=$SubscriptionId  Duration=${DurationDays}d  Requester=$RequesterUpn"

$ticketBody = @{
    TicketId = "ME-$TicketId"; Role = $Role; Environment = $Environment; SubscriptionId = $SubscriptionId
    DurationDays = $DurationDays; Priority = 'P3'; RequesterUpn = $RequesterUpn
    Justification = "Access request via ManageEngine #$TicketId ($($req.subject))"
}

# ============================ STEP 3 - Evaluate ============================
Step 3 'Evaluate - 7-step decision engine (no grant yet)'
$ev = Invoke-RestMethod -Uri "$ApiBase/api/evaluate" -Method Post -Body ($ticketBody | ConvertTo-Json) -ContentType 'application/json' -TimeoutSec 30
foreach ($s in $ev.steps) { $mark = if ($s.status -eq 'pass') { 'PASS' } else { 'STOP' }; Info ("  [{0}] {1}. {2} - {3}" -f $mark, $s.step, $s.name, $s.detail) }
Good "Decision: $($ev.decision.Action) / $($ev.decision.Path)"
if ($ev.decision.Action -notin @('Grant','Eligible','BreakGlass')) {
    Warn "Decision is '$($ev.decision.Action)' - the agent will not grant. (This is the policy working.) Stopping."
    return
}

# ============================ STEP 4 - Process ============================
Step 4 'Process - real PIM grant + note back to the ticket'
$proc = Invoke-RestMethod -Uri "$ApiBase/api/manageengine/process" -Method Post -Body (@{ meTicketId=$TicketId; ticket=$ticketBody } | ConvertTo-Json -Depth 6) -ContentType 'application/json' -TimeoutSec 90
Good "Processed: $($proc.processed)   PIM client: $($proc.execution.PimClient)   Type: $($proc.execution.AssignmentType)"
Info "Assignment: $($proc.execution.AssignmentId)"
Info "Expires   : $($proc.execution.ExpiresAt)"
if ($proc.execution.PimClient -eq 'Mock') { Warn "API is in MOCK mode - grant is simulated. Start with 'Start-Local.ps1 -Mode Real' for a real grant." }
if ($proc.meUpdate -and -not $proc.meUpdate.error) {
    Good "Note posted back to ManageEngine ticket #$TicketId (requester-visible; email via ME note rules)"
    if ($proc.meUpdate.notifyRequester) { Good "Requester notify flagged (show_to_requester)" }
}
elseif ($proc.meUpdate.error) { Warn "ME note: $($proc.meUpdate.error)" }

# ============================ STEP 5 - Idempotency =========================
Step 5 'Idempotency - process again; must NOT double-grant'
$proc2 = Invoke-RestMethod -Uri "$ApiBase/api/manageengine/process" -Method Post -Body (@{ meTicketId=$TicketId; ticket=$ticketBody } | ConvertTo-Json -Depth 6) -ContentType 'application/json' -TimeoutSec 90
if ($proc2.alreadyProcessed -or $proc2.decision.Path -eq 'Duplicate-Assignment') {
    Good "Second run blocked: $($proc2.decision.Reason) - no duplicate grant created."
} else {
    Warn "Second run returned $($proc2.decision.Action) (expected already-processed/duplicate)."
}

# ============================ STEP 6 - Verify in Azure =====================
Step 6 'Verify - prove the grant is real + time-bound in Azure'
if ($realCapable -and $proc.execution.PimClient -eq 'Graph') {
    $scope = "/subscriptions/$SubscriptionId"; $roleId = $RoleIds[$Role]
    $oid = Resolve-Oid -Upn $RequesterUpn -GraphToken $graphToken
    $isEligible = ($proc.execution.AssignmentType -eq 'Eligible')
    $kind = if ($isEligible) { 'roleEligibilityScheduleInstances' } else { 'roleAssignmentScheduleInstances' }
    $inst = Invoke-RestMethod -Headers @{Authorization="Bearer $armToken"} -Uri "https://management.azure.com$scope/providers/Microsoft.Authorization/$kind`?api-version=2020-10-01"
    $mine = @($inst.value | Where-Object { $_.properties.principalId -eq $oid -and ($_.properties.roleDefinitionId -split '/')[-1] -eq $roleId })
    if ($mine.Count -gt 0) {
        $m = $mine[0]
        Good ("Azure confirms: $Role ($($proc.execution.AssignmentType)) start=$($m.properties.startDateTime) end=$($m.properties.endDateTime)")
        Info "  -> time-bound (has an end date) = no standing access."
    } else { Warn "Assignment not surfaced yet by Azure (eventual consistency) - retry the query shortly." }
} else {
    Warn 'Skipped live verification (Mock mode or no SPN token).'
}

# ============================ STEP 7 - Persisted state =====================
Step 7 'Persisted - durable dashboard state (survives reload)'
$store = Invoke-RestMethod -Uri "$ApiBase/api/manageengine/processed" -TimeoutSec 15
$entry = @($store.items | Where-Object { $_.meTicketId -eq "$TicketId" })
if ($entry.Count -gt 0) { Good "Dashboard will show #$TicketId as Processed: $($entry[0].action) $($entry[0].role) via $($entry[0].pimClient)" }
else { Warn "No persisted entry for #$TicketId." }

# ============================ STEP 8 - Resolve (optional) ==================
if ($Resolve) {
    Step 8 'Resolve - close the ManageEngine ticket'
    $payload = @{ request = @{
        status     = @{ name = 'Resolved' }
        resolution = @{ content = "Access granted by AzureSentry. $Role ($($proc.execution.AssignmentType)) on $SubscriptionId, expires $($proc.execution.ExpiresAt). Assignment $($proc.execution.AssignmentId)." }
        udf_fields = @{ udf_pick_3713 = @{ name = 'Yes' }; udf_pick_3722 = @{ name = 'Access Granted' } }
    } } | ConvertTo-Json -Depth 6
    try {
        $r = Invoke-RestMethod -Uri "$meBase/api/v3/requests/$TicketId" -Method Put -Body "input_data=$([uri]::EscapeDataString($payload))" -Headers @{ authtoken=$meKey; 'Content-Type'='application/x-www-form-urlencoded' } -TimeoutSec 30
        if ($r.response_status.status_code -eq 2000) { Good "Ticket #$TicketId -> Resolved (Vendor Compliance=Yes, Account Status=Access Granted)" }
        else { Warn "Resolve returned: $($r.response_status | ConvertTo-Json -Compress)" }
    } catch { Warn "Resolve failed (ticket template may use different closure fields): $($_.ErrorDetails.Message)" }
}

# ============================ STEP 9 - Cleanup (optional) ==================
if ($Cleanup -and $realCapable -and $proc.execution.PimClient -eq 'Graph') {
    Step 9 'Cleanup - remove the created assignment (repeatable demo)'
    $scope = "/subscriptions/$SubscriptionId"; $roleId = $RoleIds[$Role]
    $oid = Resolve-Oid -Upn $RequesterUpn -GraphToken $graphToken
    $isEligible = ($proc.execution.AssignmentType -eq 'Eligible')
    $kind = if ($isEligible) { 'roleEligibilityScheduleRequests' } else { 'roleAssignmentScheduleRequests' }
    $body = @{ properties = @{ principalId=$oid; roleDefinitionId="$scope/providers/Microsoft.Authorization/roleDefinitions/$roleId"; requestType='AdminRemove'; justification='AzureSentry demo cleanup' } } | ConvertTo-Json -Depth 8
    try {
        $rm = Invoke-RestMethod -Method Put -Uri "https://management.azure.com$scope/providers/Microsoft.Authorization/$kind/$([guid]::NewGuid())?api-version=2020-10-01" -Headers @{Authorization="Bearer $armToken"} -Body $body -ContentType 'application/json'
        Good "Removed: status=$($rm.properties.status)"
    } catch { Warn "Cleanup: $($_.ErrorDetails.Message)" }
}

Write-Host ''
Write-Host 'Demo scenario complete.' -ForegroundColor Cyan
Write-Host ''
