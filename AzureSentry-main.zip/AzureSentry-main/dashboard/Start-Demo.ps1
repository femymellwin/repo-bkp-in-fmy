<#
.SYNOPSIS
    Starts the AzureSentry dashboard prototype (API + optional web UI).
.PARAMETER BuildWeb
    Build the React frontend before starting (requires npm).
.PARAMETER OpenBrowser
    Open the dashboard in the default browser.
#>
[CmdletBinding()]
param(
    [switch]$BuildWeb,
    [switch]$OpenBrowser
)

$ErrorActionPreference = 'Stop'
$dashboardRoot = Split-Path $PSScriptRoot -Parent
$apiScript = Join-Path $dashboardRoot 'api\Start-DashboardApi.ps1'
$webRoot = Join-Path $dashboardRoot 'web'

if ($BuildWeb) {
    Write-Host 'Building web UI...' -ForegroundColor Cyan
    Push-Location $webRoot
    if (-not (Test-Path 'node_modules')) { npm install }
    npm run build
    Pop-Location
    $url = 'http://localhost:8787'
}
else {
    $url = 'http://localhost:5173'
    Write-Host 'Starting API only. For dev UI run: cd dashboard\web && npm run dev' -ForegroundColor Yellow
}

if ($OpenBrowser) {
    Start-Job -ScriptBlock {
        Start-Sleep -Seconds 2
        Start-Process $using:url
    } | Out-Null
}

& $apiScript
