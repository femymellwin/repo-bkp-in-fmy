﻿$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Get-Module -ListAvailable Pester)) {
    Install-Module Pester -Force -Scope CurrentUser -SkipPublisherCheck
}
Import-Module Pester -MinimumVersion 5.0
$result = Invoke-Pester -Path `
    'tests\unit\RbacDecision.Tests.ps1', `
    'tests\unit\GroupRbacNaming.Tests.ps1', `
    'tests\unit\GroupOrPimGrant.Tests.ps1', `
    'tests\unit\SensitivityMap.Tests.ps1', `
    'tests\unit\Runbook-Sandbox-PIM.Tests.ps1', `
    'tests\unit\Runbook-Prod-PIM.Tests.ps1', `
    'tests\unit\Runbook-Emergency-PIM.Tests.ps1', `
    'tests\unit\Runbook-Status-Updater.Tests.ps1', `
    'tests\unit\Runbook-BreakGlass-Reaper.Tests.ps1', `
    'tests\unit\DashboardHelpers.Tests.ps1', `
    'tests\unit\TicketCriticality.Tests.ps1', `
    'tests\unit\SubscriptionResolver.Tests.ps1', `
    'tests\unit\AuditLog.Tests.ps1', `
    'tests\unit\EnvironmentResolution.Tests.ps1', `
    'tests\unit\TicketCategorization.Tests.ps1', `
    'tests\unit\LogAnalyticsClient.Tests.ps1', `
    'tests\unit\TicketTemplates.Tests.ps1', `
    'tests\unit\RoleCatalog.Tests.ps1', `
    'tests\contract\PimClient.Tests.ps1' -PassThru
Write-Output "PASSED=$($result.PassedCount) FAILED=$($result.FailedCount) TOTAL=$($result.TotalCount)"
if ($result.FailedCount -gt 0) { exit 1 }
