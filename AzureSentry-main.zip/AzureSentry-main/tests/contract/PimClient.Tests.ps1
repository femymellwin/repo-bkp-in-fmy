BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force

    $script:ReaderRoleId = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'
    $script:TestScope = '/subscriptions/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    $script:TestUpn = 'test.user@contoso.com'
    $script:TestUserId = '11111111-1111-1111-1111-111111111111'
}

Describe 'IPimClient contract — MockPimClient' {
    BeforeEach { $script:Client = New-MockPimClient }

    It 'ResolveUpnToObjectId returns object ID' {
        Resolve-UpnToObjectId -Client $script:Client -Upn $script:TestUpn | Should -Be $script:TestUserId
    }

    It 'ResolveUpnToObjectId throws for unknown UPN' {
        { Resolve-UpnToObjectId -Client $script:Client -Upn 'missing@contoso.com' } | Should -Throw
    }

    It 'GetActiveAssignments returns empty when none exist' {
        $result = @(Get-ActiveAssignments -Client $script:Client -UserId $script:TestUserId -RoleDefinitionId $script:ReaderRoleId -Scope $script:TestScope)
        $result.Count | Should -Be 0
    }

    It 'CreateActiveAssignment creates retrievable assignment' {
        $a = New-ActiveAssignment -Client $script:Client -UserId $script:TestUserId -RoleDefinitionId $script:ReaderRoleId -Scope $script:TestScope -DurationDays 7
        $a.id | Should -Not -BeNullOrEmpty
        $existing = @(Get-ActiveAssignments -Client $script:Client -UserId $script:TestUserId -RoleDefinitionId $script:ReaderRoleId -Scope $script:TestScope)
        $existing.Count | Should -Be 1
    }

    It 'CreateEligibleAssignment returns pending request' {
        $r = New-EligibleAssignment -Client $script:Client -UserId $script:TestUserId -RoleDefinitionId $script:ReaderRoleId -Scope $script:TestScope -DurationDays 14 -Justification 'test justification for prod'
        $r.status | Should -Be 'PendingApproval'
    }

    It 'GetApprovalDecision returns configured outcome' {
        $r = New-EligibleAssignment -Client $script:Client -UserId $script:TestUserId -RoleDefinitionId $script:ReaderRoleId -Scope $script:TestScope -DurationDays 7 -Justification 'test justification for prod'
        $decision = Get-ApprovalDecision -Client $script:Client -RequestId $r.id
        $decision.Status | Should -Be 'Approved'
        $decision.Reviewer | Should -Not -BeNullOrEmpty
    }

    It 'RevokeAssignment removes active assignment' {
        $a = New-ActiveAssignment -Client $script:Client -UserId $script:TestUserId -RoleDefinitionId $script:ReaderRoleId -Scope $script:TestScope -DurationDays 7
        Remove-PimAssignment -Client $script:Client -AssignmentId $a.id -Scope $script:TestScope | Out-Null
        $existing = @(Get-ActiveAssignments -Client $script:Client -UserId $script:TestUserId -RoleDefinitionId $script:ReaderRoleId -Scope $script:TestScope)
        $existing.Count | Should -Be 0
    }

    It 'GetRoleDefinitionId maps known roles' {
        Get-RoleDefinitionId -RoleName 'Reader' | Should -Be $script:ReaderRoleId
        Get-RoleDefinitionId -RoleName 'Contributor' | Should -Not -BeNullOrEmpty
    }

    It 'GetRoleDefinitionId maps the expanded Storage and AKS roles' {
        Get-RoleDefinitionId -RoleName 'Storage Blob Data Contributor' | Should -Be 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
        Get-RoleDefinitionId -RoleName 'Storage Blob Data Reader'      | Should -Be '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1'
        Get-RoleDefinitionId -RoleName 'Storage Blob Data Owner'       | Should -Be 'b7e6dc6d-f1e8-4753-8033-0f276bb0955b'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Reader'        | Should -Be '7f6c6a51-bcf8-42ba-9220-52d62157d7db'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Writer'        | Should -Be 'a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Admin'         | Should -Be '3498e952-d568-435e-9b2c-8d77e338d7f7'
        Get-RoleDefinitionId -RoleName 'Azure Kubernetes Service RBAC Cluster Admin' | Should -Be 'b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b'
    }

    It 'GetRoleDefinitionId still maps the User Access Administrator alias' {
        Get-RoleDefinitionId -RoleName 'User Access Administrator' | Should -Be '18d7d88d-d35e-4fb5-a5c3-7773c20a72d9'
    }

    It 'GetRoleDefinitionId throws for a role absent from the catalog' {
        { Get-RoleDefinitionId -RoleName 'Totally Made Up Role' } | Should -Throw '*Unknown role*'
    }

    It 'GetRoleDefinitionId throws for a role present in the catalog but with no assignable GUID' {
        { Get-RoleDefinitionId -RoleName 'Custom' } | Should -Throw '*Unknown role*'
    }
}

Describe 'IPimClient contract — GraphPimClient structure' -Tag 'GraphLive' {
    BeforeAll {
        $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
        Remove-Module MockPimClient -ErrorAction SilentlyContinue
        Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
    }
    It 'exports required functions' {
        $exports = (Get-Module GraphPimClient).ExportedCommands.Keys
        @(
            'Resolve-UpnToObjectId',
            'Get-ActiveAssignments',
            'Get-EligibleAssignments',
            'New-ActiveAssignment',
            'New-EligibleAssignment',
            'Get-ApprovalDecision',
            'Remove-PimAssignment',
            'Get-SubscriptionDisplayName',
            'Find-EntraRbacGroups',
            'Test-GroupHasSubscriptionRole',
            'Add-EntraGroupMember',
            'Get-EntraGroupMembers',
            'Test-EntraGroupMember',
            'Remove-EntraGroupMember',
            'New-EntraRbacGroup',
            'New-GroupSubscriptionRoleAssignment'
        ) | ForEach-Object {
            $exports | Should -Contain $_
        }
    }

    It 'GetRoleDefinitionId throws for a role present in the catalog but with no assignable GUID' {
        { Get-RoleDefinitionId -RoleName 'Custom' } | Should -Throw '*Unknown role*'
    }
}

Describe 'GraphPimClient requester alias disambiguation' {
    BeforeAll {
        $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
        Remove-Module GraphPimClient -ErrorAction SilentlyContinue
        Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
    }

    It 'prefers the only enabled alias match with a primary mail address' {
        InModuleScope GraphPimClient {
            $matches = @(
                [pscustomobject]@{
                    id = 'real-user'
                    mail = 'person@primary.example'
                    accountEnabled = $true
                },
                [pscustomobject]@{
                    id = 'test-user'
                    mail = $null
                    accountEnabled = $true
                }
            )

            Select-GraphUserMatch -Matches $matches -RequestedAddress 'person@alias.example' |
                Should -Be 'real-user'
        }
    }

    It 'still rejects genuinely ambiguous enabled primary accounts' {
        InModuleScope GraphPimClient {
            $matches = @(
                [pscustomobject]@{ id = 'user-1'; mail = 'one@example.com'; accountEnabled = $true },
                [pscustomobject]@{ id = 'user-2'; mail = 'two@example.com'; accountEnabled = $true }
            )

            { Select-GraphUserMatch -Matches $matches -RequestedAddress 'shared@example.com' } |
                Should -Throw '*Ambiguous requester*'
        }
    }

    It 'revokes subscription assignments through an ARM AdminRemove request' {
        InModuleScope GraphPimClient {
            $scope = '/subscriptions/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
            $grantRequestId = "$scope/providers/Microsoft.Authorization/roleAssignmentScheduleRequests/grant-request"
            $script:capturedRemoveBody = $null

            Mock Invoke-ArmApi {
                param($Client, $Method, $Uri, $Body)
                if ($Method -eq 'GET') {
                    return [pscustomobject]@{
                        properties = [pscustomobject]@{
                            principalId = '11111111-1111-1111-1111-111111111111'
                            roleDefinitionId = "$scope/providers/Microsoft.Authorization/roleDefinitions/acdd72a7-3385-48ef-bd42-f606fba81ae7"
                            targetRoleAssignmentScheduleId = 'active-schedule'
                        }
                    }
                }
                $script:capturedRemoveBody = $Body
                return [pscustomobject]@{ properties = [pscustomobject]@{ status = 'Accepted' } }
            }
            Mock Invoke-GraphApi { throw 'Graph must not be used for Azure resource PIM.' }

            $result = Remove-PimAssignment -Client ([pscustomobject]@{}) `
                -AssignmentId $grantRequestId -Scope $scope

            Assert-MockCalled Invoke-ArmApi -Times 1 -ParameterFilter { $Method -eq 'GET' }
            Assert-MockCalled Invoke-ArmApi -Times 1 -ParameterFilter { $Method -eq 'PUT' }
            $script:capturedRemoveBody.properties.requestType | Should -Be 'AdminRemove'
            $script:capturedRemoveBody.properties.principalId | Should -Be '11111111-1111-1111-1111-111111111111'
            $script:capturedRemoveBody.properties.targetRoleAssignmentScheduleId | Should -Be 'active-schedule'
            $result.properties.status | Should -Be 'Accepted'
        }
    }

    It 'resolves sentinel existing-assignment via eligible instances and AdminRemoves eligibility' {
        InModuleScope GraphPimClient {
            $scope = '/subscriptions/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
            $roleId = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
            $userId = '11111111-1111-1111-1111-111111111111'
            $script:capturedRemoveUri = $null
            $script:capturedRemoveBody = $null

            Mock Invoke-ArmApi {
                param($Client, $Method, $Uri, $Body)
                if ($Method -eq 'GET' -and $Uri -match 'roleEligibilityScheduleInstances') {
                    return [pscustomobject]@{
                        value = @(
                            [pscustomobject]@{
                                id = "$scope/providers/Microsoft.Authorization/roleEligibilityScheduleInstances/inst-1"
                                properties = [pscustomobject]@{
                                    principalId = $userId
                                    roleDefinitionId = "$scope/providers/Microsoft.Authorization/roleDefinitions/$roleId"
                                    scope = $scope
                                    roleEligibilityScheduleId = 'elig-schedule-1'
                                }
                            }
                        )
                    }
                }
                if ($Method -eq 'PUT') {
                    $script:capturedRemoveUri = $Uri
                    $script:capturedRemoveBody = $Body
                    return [pscustomobject]@{ properties = [pscustomobject]@{ status = 'Accepted' } }
                }
                throw "Unexpected ARM call: $Method $Uri"
            }

            $result = Remove-PimAssignment -Client ([pscustomobject]@{}) `
                -AssignmentId 'existing-assignment' -Scope $scope `
                -UserId $userId -RoleDefinitionId $roleId -AssignmentType Eligible

            $script:capturedRemoveUri | Should -Match 'roleEligibilityScheduleRequests/'
            $script:capturedRemoveBody.properties.requestType | Should -Be 'AdminRemove'
            $script:capturedRemoveBody.properties.targetRoleEligibilityScheduleId | Should -Be 'elig-schedule-1'
            $result.properties.status | Should -Be 'Accepted'
        }
    }

    It 'returns AlreadyRevoked when sentinel resolve finds no instances' {
        InModuleScope GraphPimClient {
            $scope = '/subscriptions/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
            Mock Invoke-ArmApi {
                [pscustomobject]@{ value = @() }
            }

            $result = Remove-PimAssignment -Client ([pscustomobject]@{}) `
                -AssignmentId 'existing-assignment' -Scope $scope `
                -UserId '11111111-1111-1111-1111-111111111111' `
                -RoleDefinitionId 'b24988ac-6180-42a0-ab88-20f7382dd24c' `
                -AssignmentType Eligible

            $result.AlreadyRevoked | Should -Be $true
        }
    }

    It 'gets a subscription display name through ARM' {
        InModuleScope GraphPimClient {
            Mock Invoke-ArmApi {
                [pscustomobject]@{ displayName = 'Production Subscription' }
            }

            Get-SubscriptionDisplayName -Client ([pscustomobject]@{}) `
                -SubscriptionId 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' |
                Should -Be 'Production Subscription'

            Assert-MockCalled Invoke-ArmApi -Times 1 -ParameterFilter {
                $Method -eq 'GET' -and
                $Uri -eq 'https://management.azure.com/subscriptions/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa?api-version=2022-12-01'
            }
        }
    }

    It 'escapes apostrophes when finding Entra RBAC groups' {
        InModuleScope GraphPimClient {
            Mock Invoke-GraphApi {
                [pscustomobject]@{ value = @([pscustomobject]@{ id = 'group-1'; displayName = "RBAC-O'Brien" }) }
            }

            $groups = @(Find-EntraRbacGroups -Client ([pscustomobject]@{}) -DisplayNamePrefix "RBAC-O'Brien")

            $groups.Count | Should -Be 1
            $groups[0].id | Should -Be 'group-1'
            Assert-MockCalled Invoke-GraphApi -Times 1 -ParameterFilter {
                $Method -eq 'GET' -and
                [uri]::UnescapeDataString($Uri) -match "startswith\(displayName,'RBAC-O''Brien'\)"
            }
        }
    }

    It 'detects a matching subscription role assignment by role definition suffix' {
        InModuleScope GraphPimClient {
            $subscriptionId = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
            $roleId = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'
            Mock Invoke-ArmApi {
                [pscustomobject]@{
                    value = @(
                        [pscustomobject]@{
                            properties = [pscustomobject]@{
                                scope = "/subscriptions/$subscriptionId"
                                roleDefinitionId = "/subscriptions/$subscriptionId/providers/Microsoft.Authorization/roleDefinitions/$roleId"
                            }
                        }
                    )
                }
            }

            Test-GroupHasSubscriptionRole -Client ([pscustomobject]@{}) -GroupId 'group-1' `
                -SubscriptionId $subscriptionId -RoleDefinitionId $roleId |
                Should -BeTrue

            Assert-MockCalled Invoke-ArmApi -Times 1 -ParameterFilter {
                $Method -eq 'GET' -and
                [uri]::UnescapeDataString($Uri) -match "principalId eq 'group-1'"
            }
        }
    }

    It 'ignores child-scope role assignments with a matching role definition suffix' {
        InModuleScope GraphPimClient {
            $subscriptionId = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
            $roleId = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'
            Mock Invoke-ArmApi {
                [pscustomobject]@{
                    value = @(
                        [pscustomobject]@{
                            properties = [pscustomobject]@{
                                scope = "/subscriptions/$subscriptionId/resourceGroups/rg-demo"
                                roleDefinitionId = "/subscriptions/$subscriptionId/providers/Microsoft.Authorization/roleDefinitions/$roleId"
                            }
                        }
                    )
                }
            }

            Test-GroupHasSubscriptionRole -Client ([pscustomobject]@{}) -GroupId 'group-1' `
                -SubscriptionId $subscriptionId -RoleDefinitionId $roleId |
                Should -BeFalse
        }
    }

    It 'adds an Entra group member with an OData reference' {
        InModuleScope GraphPimClient {
            $script:capturedMemberBody = $null
            Mock Invoke-GraphApi {
                param($Client, $Method, $Uri, $Body)
                $script:capturedMemberBody = $Body
            }

            $result = Add-EntraGroupMember -Client ([pscustomobject]@{}) -GroupId 'group-1' -UserId 'user-1'

            $result.AlreadyMember | Should -BeFalse
            $script:capturedMemberBody.'@odata.id' |
                Should -Be 'https://graph.microsoft.com/v1.0/directoryObjects/user-1'
            Assert-MockCalled Invoke-GraphApi -Times 1 -ParameterFilter {
                $Method -eq 'POST' -and $Uri -eq 'https://graph.microsoft.com/v1.0/groups/group-1/members/$ref'
            }
        }
    }

    It 'treats Graph already-exists errors as idempotent member adds' {
        InModuleScope GraphPimClient {
            Mock Invoke-GraphApi { throw 'Request_BadRequest: One or more added object references already exist.' }

            $result = Add-EntraGroupMember -Client ([pscustomobject]@{}) -GroupId 'group-1' -UserId 'user-1'

            $result.AlreadyMember | Should -BeTrue
        }
    }

    It 'retries ARM PrincipalNotFound when assigning a newly created group' {
        InModuleScope GraphPimClient {
            $script:putAttempts = 0
            Mock Invoke-ArmApi {
                param($Client, $Method, $Uri, $Body)
                if ($Method -eq 'GET') {
                    return [pscustomobject]@{ value = @() }
                }
                $script:putAttempts++
                if ($script:putAttempts -lt 3) {
                    throw 'The remote server returned an error: (400) Bad Request. | {"error":{"code":"PrincipalNotFound","message":"Principal f7f705f837b243c78b44cbe1116f865a does not exist in the directory 5ac4936b-1ac4-4e57-9e2b-48673491865e."}}'
                }
                return [pscustomobject]@{ name = 'ra-1' }
            }

            $result = New-GroupSubscriptionRoleAssignment -Client ([pscustomobject]@{}) `
                -GroupId 'f7f705f837b243c78b44cbe1116f865a' `
                -SubscriptionId 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' `
                -RoleDefinitionId 'b24988ac-6180-42a0-ab88-20f7382dd24c' `
                -RetryDelaySeconds 0

            $result.AlreadyExisted | Should -BeFalse
            $script:putAttempts | Should -Be 3
        }
    }

    It 'sends principalType Group and a dashed principal object id' {
        InModuleScope GraphPimClient {
            $script:capturedBody = $null
            Mock Invoke-ArmApi {
                param($Client, $Method, $Uri, $Body)
                if ($Method -eq 'GET') { return [pscustomobject]@{ value = @() } }
                $script:capturedBody = $Body
                return [pscustomobject]@{ name = 'ra-1' }
            }

            New-GroupSubscriptionRoleAssignment -Client ([pscustomobject]@{}) `
                -GroupId 'f7f705f837b243c78b44cbe1116f865a' `
                -SubscriptionId 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' `
                -RoleDefinitionId 'b24988ac-6180-42a0-ab88-20f7382dd24c' | Out-Null

            $script:capturedBody.properties.principalType | Should -Be 'Group'
            $script:capturedBody.properties.principalId | Should -Be 'f7f705f8-37b2-43c7-8b44-cbe1116f865a'
        }
    }

    It 'gets and removes Entra group members through Graph' {
        InModuleScope GraphPimClient {
            Mock Invoke-GraphApi {
                param($Client, $Method)
                if ($Method -eq 'GET') {
                    return [pscustomobject]@{ value = @([pscustomobject]@{ id = 'user-1' }) }
                }
            }

            $members = @(Get-EntraGroupMembers -Client ([pscustomobject]@{}) -GroupId 'group-1')
            $removed = Remove-EntraGroupMember -Client ([pscustomobject]@{}) -GroupId 'group-1' -UserId 'user-1'

            $members[0].id | Should -Be 'user-1'
            $removed.Removed | Should -BeTrue
            Assert-MockCalled Invoke-GraphApi -Times 1 -ParameterFilter {
                $Method -eq 'GET' -and $Uri -eq 'https://graph.microsoft.com/v1.0/groups/group-1/members'
            }
            Assert-MockCalled Invoke-GraphApi -Times 1 -ParameterFilter {
                $Method -eq 'DELETE' -and $Uri -eq 'https://graph.microsoft.com/v1.0/groups/group-1/members/user-1/$ref'
            }
        }
    }
}

Describe 'Role definition ids agree across both PIM clients' {
    It 'resolves every catalog role to the same GUID in Mock and Graph clients' {
        $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
        Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
        $roles = @(Get-RoleCatalogNames | Where-Object { $_ -ne 'Custom' })
        $roles.Count | Should -BeGreaterOrEqual 11

        Remove-Module MockPimClient, GraphPimClient -ErrorAction SilentlyContinue
        Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
        $mock = @{}
        foreach ($r in $roles) { $mock[$r] = Get-RoleDefinitionId -RoleName $r }

        Remove-Module MockPimClient -ErrorAction SilentlyContinue
        Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
        foreach ($r in $roles) {
            $mock[$r] | Should -Not -BeNullOrEmpty -Because "MockPimClient must resolve '$r'"
            Get-RoleDefinitionId -RoleName $r | Should -Be $mock[$r] -Because "both clients must agree on '$r'"
        }
    }
}
