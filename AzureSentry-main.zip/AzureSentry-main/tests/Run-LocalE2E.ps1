<#
.SYNOPSIS
    Local end-to-end harness - drive every decision path through the real
    decision engine + specialised runbooks against the Mock PIM client.
.DESCRIPTION
    AUTHORING / DEMO AID ONLY. No Azure, no cost, no Graph calls.

    Forces $env:AZURESENTRY_PIM_CLIENT='Mock' so the decision router and every
    downstream runbook (Sandbox / Prod / Emergency) resolve against the in-memory
    MockPimClient seeded with test.user@contoso.com. It feeds a small set of
    representative dummy tickets through Runbook-Decision-Router.ps1 exactly the
    way the Logic App orchestrator would (TicketJson + comma-separated allowlist),
    then prints a clean PASS-style summary table of what each path did.

    Run it directly:
        pwsh -File tests\Run-LocalE2E.ps1
        # or in Windows PowerShell 5.1:
        powershell -File tests\Run-LocalE2E.ps1

    Cases exercised:
        (1) Sandbox Reader              -> Grant      (Runbook-Sandbox-PIM)
        (2) Production Reader P3        -> Eligible   (Runbook-Prod-PIM)
        (3) Production Contributor P1   -> BreakGlass (Runbook-Emergency-PIM)
            BreakGlass / Emergency Access
        (4) Sandbox Owner              -> Reject     (Policy-Block, no dispatch)
        (5) Custom role                -> Hold       (Governance-Review, no dispatch)
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------------
# Force the Mock PIM client for the whole run - never touch Azure.
# ------------------------------------------------------------------
$env:AZURESENTRY_PIM_CLIENT = 'Mock'

$RepoRoot   = Split-Path $PSScriptRoot -Parent
$RouterPath = Join-Path $RepoRoot 'src\Runbooks\Runbook-Decision-Router.ps1'

if (-not (Test-Path $RouterPath)) {
    throw "Decision router not found at $RouterPath"
}

# ------------------------------------------------------------------
# Dummy subscriptions. Both go on the allowlist passed to the router.
# ------------------------------------------------------------------
$SandboxSub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
$ProdSub    = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
$Allowlist  = @($SandboxSub, $ProdSub) -join ','

# ------------------------------------------------------------------
# Representative dummy tickets (canonical schema). RequesterUpn is the
# seeded mock user so UPN -> objectId resolution succeeds offline.
# ------------------------------------------------------------------
$MockUpn = 'test.user@contoso.com'

$Cases = @(
    @{
        Label  = 'Sandbox Reader -> Grant'
        Ticket = @{
            TicketId       = 'E2E-001'
            Role           = 'Reader'
            Environment    = 'Sandbox'
            SubscriptionId = $SandboxSub
            ResourceScope  = "/subscriptions/$SandboxSub"
            DurationDays   = 7
            Priority       = 'P3'
            RequesterUpn   = $MockUpn
            SubmitterUpn   = $MockUpn
            Justification  = 'Sandbox reader access for local end-to-end demo run'
        }
    },
    @{
        Label  = 'Production Reader P3 -> Eligible'
        Ticket = @{
            TicketId       = 'E2E-002'
            Role           = 'Reader'
            Environment    = 'Production'
            SubscriptionId = $ProdSub
            ResourceScope  = "/subscriptions/$ProdSub"
            DurationDays   = 7
            Priority       = 'P3'
            RequesterUpn   = $MockUpn
            SubmitterUpn   = $MockUpn
            Justification  = 'Production read-only access for sprint work item 12345'
        }
    },
    @{
        Label  = 'Production Contributor P1 BreakGlass -> BreakGlass'
        Ticket = @{
            TicketId       = 'E2E-003'
            Role           = 'Contributor'
            Environment    = 'Production'
            SubscriptionId = $ProdSub
            ResourceScope  = "/subscriptions/$ProdSub"
            DurationDays   = 1
            Priority       = 'P1'
            RequesterUpn   = $MockUpn
            SubmitterUpn   = $MockUpn
            Justification  = 'Emergency break-glass access to mitigate active P1 incident'
            BreakGlass     = $true
            RequestType    = 'Emergency Access'
        }
    },
    @{
        Label  = 'Sandbox Owner -> Reject'
        Ticket = @{
            TicketId       = 'E2E-004'
            Role           = 'Owner'
            Environment    = 'Sandbox'
            SubscriptionId = $SandboxSub
            ResourceScope  = "/subscriptions/$SandboxSub"
            DurationDays   = 7
            Priority       = 'P3'
            RequesterUpn   = $MockUpn
            SubmitterUpn   = $MockUpn
            Justification  = 'Sandbox owner request - expected to be policy blocked'
        }
    },
    @{
        Label  = 'Custom role -> Hold'
        Ticket = @{
            TicketId       = 'E2E-005'
            Role           = 'Custom'
            Environment    = 'Production'
            SubscriptionId = $ProdSub
            ResourceScope  = "/subscriptions/$ProdSub"
            DurationDays   = 7
            Priority       = 'P3'
            RequesterUpn   = $MockUpn
            SubmitterUpn   = $MockUpn
            Justification  = 'Custom role request routed to governance review queue'
        }
    }
)

# ------------------------------------------------------------------
# Console helpers (ASCII only).
# ------------------------------------------------------------------
function Write-Header {
    param([string]$Text)
    Write-Host ''
    Write-Host ('=' * 78) -ForegroundColor DarkGray
    Write-Host $Text -ForegroundColor Cyan
    Write-Host ('=' * 78) -ForegroundColor DarkGray
}

function Get-PropOrNull {
    param([object]$Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    if ($Object.PSObject.Properties.Name -contains $Name) { return $Object.$Name }
    return $null
}

Write-Header 'AzureSentry - LOCAL END-TO-END (MOCK PIM, NO AZURE)'
Write-Host ("PIM client implementation : {0}" -f $env:AZURESENTRY_PIM_CLIENT)
Write-Host ("Decision router           : {0}" -f $RouterPath)
Write-Host ("Subscription allowlist    : {0}" -f $Allowlist)
Write-Host ("Mock seeded user          : {0}" -f $MockUpn)

$Rows = @()

foreach ($case in $Cases) {
    $ticket     = $case.Ticket
    $ticketJson = $ticket | ConvertTo-Json -Compress

    Write-Header ("CASE: {0}  [TicketId={1}]" -f $case.Label, $ticket.TicketId)
    Write-Host ("  Role={0}  Env={1}  Priority={2}  Sub={3}" -f `
            $ticket.Role, $ticket.Environment, $ticket.Priority, $ticket.SubscriptionId)

    $action      = '(error)'
    $dispatched  = $false
    $runbook     = '-'
    $success     = '-'
    $detailId    = '-'
    $message     = ''
    $status      = 'FAIL'

    try {
        $response = & $RouterPath -TicketJson $ticketJson -SubscriptionAllowlist $Allowlist

        $decision   = Get-PropOrNull -Object $response -Name 'Decision'
        $result     = Get-PropOrNull -Object $response -Name 'Result'
        $dispatched = [bool](Get-PropOrNull -Object $response -Name 'Dispatched')
        $runbookVal = Get-PropOrNull -Object $response -Name 'Runbook'
        $messageVal = Get-PropOrNull -Object $response -Name 'Message'

        if ($decision) { $action = [string]$decision.Action }
        if ($runbookVal) { $runbook = [string]$runbookVal }
        if ($messageVal) { $message = [string]$messageVal }

        if ($result) {
            $resSuccess = Get-PropOrNull -Object $result -Name 'Success'
            if ($null -ne $resSuccess) { $success = [string]$resSuccess }

            # Grant path surfaces AssignmentId; Eligible path surfaces RequestId.
            $assignmentId = Get-PropOrNull -Object $result -Name 'AssignmentId'
            $requestId    = Get-PropOrNull -Object $result -Name 'RequestId'
            if ($assignmentId) { $detailId = "AssignmentId=$assignmentId" }
            elseif ($requestId) { $detailId = "RequestId=$requestId" }

            $resMessage = Get-PropOrNull -Object $result -Name 'Message'
            if ($resMessage -and -not $message) { $message = [string]$resMessage }
        }

        # A row is considered PASS if the router produced a coherent response.
        # Reject/Hold legitimately do not dispatch; a missing Emergency runbook
        # is reported (not yet implemented) but is NOT a harness failure.
        $status = 'PASS'

        Write-Host ("  Action     : {0}" -f $action) -ForegroundColor Yellow
        Write-Host ("  Dispatched : {0}" -f $dispatched)
        Write-Host ("  Runbook    : {0}" -f $runbook)
        Write-Host ("  Result.Success : {0}" -f $success)
        if ($detailId -ne '-') { Write-Host ("  {0}" -f $detailId) -ForegroundColor Green }
        if ($message)          { Write-Host ("  Message    : {0}" -f $message) -ForegroundColor DarkGray }
        Write-Host ("  [PASS] router returned a coherent decision/result") -ForegroundColor Green
    }
    catch {
        $message = $_.Exception.Message
        $status  = 'FAIL'
        Write-Host ("  [FAIL] {0}" -f $message) -ForegroundColor Red
    }

    $Rows += [PSCustomObject]@{
        Case       = $case.Label
        Action     = $action
        Dispatched = $dispatched
        Runbook    = $runbook
        Success    = $success
        Detail     = $detailId
        Status     = $status
    }
}

# ------------------------------------------------------------------
# Summary table.
# ------------------------------------------------------------------
Write-Header 'SUMMARY'

$fmt = '{0,-4} {1,-44} {2,-11} {3,-5} {4,-22} {5,-8} {6}'
Write-Host ($fmt -f 'St', 'Case', 'Action', 'Disp', 'Runbook', 'Success', 'Detail') -ForegroundColor White
Write-Host ('-' * 110) -ForegroundColor DarkGray

foreach ($row in $Rows) {
    $stColor = if ($row.Status -eq 'PASS') { 'Green' } else { 'Red' }
    $runbookShort = $row.Runbook
    if ($runbookShort.Length -gt 22) { $runbookShort = $runbookShort.Substring(0, 22) }
    Write-Host ($fmt -f `
            $row.Status, $row.Case, $row.Action, ([string]$row.Dispatched), `
            $runbookShort, $row.Success, $row.Detail) -ForegroundColor $stColor
}

$passCount = @($Rows | Where-Object { $_.Status -eq 'PASS' }).Count
$total     = $Rows.Count

Write-Host ''
Write-Host ("Cases: {0}/{1} PASS" -f $passCount, $total) -ForegroundColor White
Write-Host ''
Write-Host 'LOCAL E2E COMPLETE' -ForegroundColor Cyan
Write-Host 'Legend: mock/dummy data only - MockPimClient, no Azure, no Graph, no cost.' -ForegroundColor DarkGray

# Exit non-zero only if the harness itself errored on a case (not for
# legitimate Reject/Hold or a not-yet-implemented Emergency runbook).
if ($passCount -ne $total) { exit 1 }
exit 0
