BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\MeTicketMapper.ps1')
    # Resolve-MeTicketMapping now confirms a pass-through role label against the role
    # catalog via Get-RoleCatalogEntry (RbacDecision module), matching production's load
    # order in Invoke-TicketPollerCycle.ps1 (dot-source MeTicketMapper.ps1, then import
    # RbacDecision) -- order between the two doesn't matter, only that both are loaded
    # before Resolve-MeTicketMapping is actually called.
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

    $script:Allowlist = @(
        [pscustomobject]@{ id = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'; name = 'inception-ai-Sandbox' }
        [pscustomobject]@{ id = '1251f2d0-787f-4063-8b74-178ad167c682'; name = 'ceo-sub-application' }
    )

    function New-MeAccess {
        param([string]$Subscription = 'inception-ai-Sandbox', [string]$AzureRole = 'Reader', [string]$Environment = 'Sandbox', [string]$TargetResourceId = '')
        [ordered]@{ Subscription = $Subscription; AzureRole = $AzureRole; Environment = $Environment; TargetResourceId = $TargetResourceId }
    }

    function New-MeReq {
        param([string]$Id = '9001', [string]$Subject = 'Need access', [string]$Email = 'dev.user@contoso.com', [string]$Priority = 'P3')
        [pscustomobject]@{
            id = $Id; subject = $Subject
            requester = [pscustomobject]@{ email_id = $Email; name = 'Dev User' }
            priority  = [pscustomobject]@{ name = $Priority }
            description = 'Please grant access.'
        }
    }
}

Describe 'Get-CanonicalAzureRole' {
    It 'maps the ME dropdown labels to platform roles' {
        Get-CanonicalAzureRole -Raw 'Reader'              | Should -Be 'Reader'
        Get-CanonicalAzureRole -Raw 'Read Only'           | Should -Be 'Reader'
        Get-CanonicalAzureRole -Raw 'Contributor'         | Should -Be 'Contributor'
        Get-CanonicalAzureRole -Raw 'contrib'             | Should -Be 'Contributor'
        Get-CanonicalAzureRole -Raw 'Writer'              | Should -Be 'Writer'
        Get-CanonicalAzureRole -Raw 'Owner'               | Should -Be 'Owner'
        Get-CanonicalAzureRole -Raw 'User Access Admin'   | Should -Be 'UAA'
        Get-CanonicalAzureRole -Raw 'UAA'                 | Should -Be 'UAA'
    }

    It 'passes an unrecognised-but-non-blank label through verbatim, mirroring mapMeAzureRole' {
        # A valid role-catalog name that just isn't one of the five coarse buckets above
        # (e.g. an AKS RBAC role) must reach Resolve-MeTicketMapping's catalog lookup
        # intact, not be silently discarded here. This function no longer decides what
        # counts as a real role -- Resolve-MeTicketMapping does, via role-catalog.json.
        Get-CanonicalAzureRole -Raw 'Azure Kubernetes Service RBAC Admin' | Should -Be 'Azure Kubernetes Service RBAC Admin'
        Get-CanonicalAzureRole -Raw 'AKS Cluster Admin'                  | Should -Be 'AKS Cluster Admin'
    }

    It 'returns empty only for a blank dropdown' {
        Get-CanonicalAzureRole -Raw ''    | Should -Be ''
        Get-CanonicalAzureRole -Raw '   ' | Should -Be ''
    }
}

Describe 'Get-CanonicalEnvironment' {
    It 'checks non-prod terms before production so "non-prod" is not read as prod' {
        Get-CanonicalEnvironment -Raw 'Non-Prod'    | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'non prod'    | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'UAT'         | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'Sandbox'     | Should -Be 'Sandbox'
        Get-CanonicalEnvironment -Raw 'Production'  | Should -Be 'Production'
    }

    It 'returns empty for an unmappable value' {
        Get-CanonicalEnvironment -Raw 'Somewhere else' | Should -Be ''
        Get-CanonicalEnvironment -Raw ''               | Should -Be ''
    }
}

Describe 'Get-CanonicalEnvironment -- deliberate asymmetry with the UI mapper' {
    # This mapper feeds an unattended granter and must never be MORE permissive than
    # mapMeEnvironment (dashboard/web/src/extractMeAccessFields.ts): resolving to an
    # auto-grantable environment where the UI would leave the value unmapped for a
    # human is a defect. These cases pin that rule so it cannot silently regress.

    It 'still maps "Staging" to NonProd' {
        Get-CanonicalEnvironment -Raw 'Staging' | Should -Be 'NonProd'
    }

    It 'does NOT auto-resolve "Stage" -- the UI leaves it unmapped for a human' {
        Get-CanonicalEnvironment -Raw 'Stage' | Should -Be '' -Because 'the UI only matches \bstaging\b, not \bstage\b; auto-granting here would be more permissive than the UI and is the defect this fix closes'
    }

    It 'does NOT auto-resolve "Shared" -- deliberately stricter than the UI' {
        Get-CanonicalEnvironment -Raw 'Shared' | Should -Be '' -Because 'queueing "Shared" for a human is the intended outcome; the UI auto-resolves it to NonProd but this unattended mapper intentionally does not'
    }

    It 'does NOT auto-resolve "DR" -- deliberately stricter than the UI' {
        Get-CanonicalEnvironment -Raw 'DR' | Should -Be '' -Because 'DR is production-adjacent and must never be auto-granted; queueing for a human is the intended outcome even though the UI auto-resolves it to NonProd'
    }

    It 'resolves "PRD" to Production, unlike the UI, because Production never auto-grants' {
        Get-CanonicalEnvironment -Raw 'PRD' | Should -Be 'Production' -Because 'Production is excluded from unattended grants entirely, so classifying PRD correctly only makes the queued reason legible -- it is not a permissive drift'
    }

    It 'still maps the existing recognised values' {
        Get-CanonicalEnvironment -Raw 'Non-Prod'   | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'non prod'   | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'UAT'        | Should -Be 'NonProd'
        Get-CanonicalEnvironment -Raw 'Sandbox'    | Should -Be 'Sandbox'
        Get-CanonicalEnvironment -Raw 'Production' | Should -Be 'Production'
    }
}

Describe 'Resolve-AllowlistSubscriptionId -- exact matching only' {
    It 'matches an allowlisted name case-insensitively' {
        Resolve-AllowlistSubscriptionId -Name 'inception-ai-sandbox' -AllowlistDetails $script:Allowlist |
            Should -Be 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
    }

    It 'accepts a bare GUID that is on the allowlist' {
        Resolve-AllowlistSubscriptionId -Name '1251f2d0-787f-4063-8b74-178ad167c682' -AllowlistDetails $script:Allowlist |
            Should -Be '1251f2d0-787f-4063-8b74-178ad167c682'
    }

    It 'refuses a GUID that is NOT on the allowlist' {
        Resolve-AllowlistSubscriptionId -Name '00000000-0000-0000-0000-000000000000' -AllowlistDetails $script:Allowlist |
            Should -Be ''
    }

    It 'refuses a partial name -- no substring matching in the unattended path' {
        # The UI deliberately fuzzy-matches to help an operator. Unattended granting
        # must not: "Sandbox" could match several subscriptions.
        Resolve-AllowlistSubscriptionId -Name 'Sandbox' -AllowlistDetails $script:Allowlist | Should -Be ''
        Resolve-AllowlistSubscriptionId -Name 'inception' -AllowlistDetails $script:Allowlist | Should -Be ''
    }
}

Describe 'Resolve-MeTicketMapping' {

    It 'produces a complete mapping when every dropdown is populated and allowlisted' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeTrue
        $m.Warnings.Count | Should -Be 0
        $m.Ticket.Role | Should -Be 'Reader'
        $m.Ticket.Environment | Should -Be 'Sandbox'
        $m.Ticket.SubscriptionId | Should -Be 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
        $m.Ticket.SubscriptionName | Should -Be 'inception-ai-Sandbox'
        $m.Ticket.RequesterUpn | Should -Be 'dev.user@contoso.com'
        $m.Ticket.ResourceScope | Should -Be '/subscriptions/efae0e0e-09ab-4c17-82db-d2d1f4382d66'
        $m.Ticket.TicketId | Should -Be '9001'
    }

    It 'is incomplete and names the field when the role dropdown is blank' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole '') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'Azure Role'
    }

    It 'is incomplete and names the field when the environment dropdown is blank' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -Environment '') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'Environment'
    }

    It 'is incomplete when the subscription is set but not allowlisted' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -Subscription 'some-other-sub') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'not on the allowlist'
    }

    It 'is incomplete when the role is an unrecognised ME label' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole 'AKS Cluster Admin') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'did not map'
    }

    It 'never infers from the ticket body even when it plainly states an environment' {
        # Free-text inference is the UI's job. Unattended, a blank dropdown means queue.
        $req = New-MeReq
        $req.description = 'This is definitely for the sandbox environment, Reader please.'
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -Environment '') -MeTicket $req -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
    }

    It 'is incomplete when the requester has no email to resolve' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket (New-MeReq -Email '') -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'requester'
    }

    It 'is incomplete when a resource-scoped role (AKS RBAC Admin) names no target resource' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole 'Azure Kubernetes Service RBAC Admin') -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'resource-scoped'
    }

    It 'is incomplete when the named target resource is the wrong resource type' {
        $storageId = '/subscriptions/efae0e0e-09ab-4c17-82db-d2d1f4382d66/resourceGroups/rg1/providers/Microsoft.Storage/storageAccounts/acct1'
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole 'Azure Kubernetes Service RBAC Admin' -TargetResourceId $storageId) -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeFalse
        ($m.Warnings -join ' ') | Should -Match 'does not look like a Microsoft.ContainerService/managedClusters'
    }

    It 'completes with the AKS cluster resource id as ResourceScope once one is supplied' {
        $clusterId = '/subscriptions/efae0e0e-09ab-4c17-82db-d2d1f4382d66/resourceGroups/rg1/providers/Microsoft.ContainerService/managedClusters/cluster1'
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole 'Azure Kubernetes Service RBAC Admin' -TargetResourceId $clusterId) -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeTrue
        $m.Ticket.Role | Should -Be 'Azure Kubernetes Service RBAC Admin'
        $m.Ticket.ResourceScope | Should -Be $clusterId
    }

    It 'ignores TargetResourceId for a plain subscription-scoped role -- ResourceScope stays subscription-level' {
        $clusterId = '/subscriptions/efae0e0e-09ab-4c17-82db-d2d1f4382d66/resourceGroups/rg1/providers/Microsoft.ContainerService/managedClusters/cluster1'
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess -AzureRole 'Reader' -TargetResourceId $clusterId) -MeTicket (New-MeReq) -AllowlistDetails $script:Allowlist
        $m.Complete | Should -BeTrue
        $m.Ticket.ResourceScope | Should -Be '/subscriptions/efae0e0e-09ab-4c17-82db-d2d1f4382d66'
    }

    It 'carries the ME priority through and defaults it when absent' {
        $m = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket (New-MeReq -Priority 'P2') -AllowlistDetails $script:Allowlist
        $m.Ticket.Priority | Should -Be 'P2'

        $noPri = New-MeReq
        $noPri.priority = $null
        $m2 = Resolve-MeTicketMapping -AccessFields (New-MeAccess) -MeTicket $noPri -AllowlistDetails $script:Allowlist
        $m2.Ticket.Priority | Should -Be 'P3'
    }
}
