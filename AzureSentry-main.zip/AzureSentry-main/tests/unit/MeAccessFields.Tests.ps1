﻿BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\MeAccessFields.ps1')

    function New-Udf {
        param([hashtable]$Fields = @{})
        [pscustomobject]$Fields
    }
}

Describe 'Get-MeUdfFieldValue' {
    It 'reads a plain string field' {
        Get-MeUdfFieldValue -UdfFields (New-Udf @{ udf_pick_3728 = 'inception-ai-Sandbox' }) -Key 'udf_pick_3728' |
            Should -Be 'inception-ai-Sandbox'
    }

    It 'unwraps a nested picklist object by name/value/display_value' {
        Get-MeUdfFieldValue -UdfFields (New-Udf @{ p = [pscustomobject]@{ name = 'Reader' } }) -Key 'p' | Should -Be 'Reader'
        Get-MeUdfFieldValue -UdfFields (New-Udf @{ p = [pscustomobject]@{ value = 'Sandbox' } }) -Key 'p' | Should -Be 'Sandbox'
        Get-MeUdfFieldValue -UdfFields (New-Udf @{ p = [pscustomobject]@{ display_value = 'Prod' } }) -Key 'p' | Should -Be 'Prod'
    }

    It 'returns empty for a missing key, null value, or missing udf object' {
        Get-MeUdfFieldValue -UdfFields (New-Udf @{ a = 'x' }) -Key 'nope' | Should -Be ''
        Get-MeUdfFieldValue -UdfFields (New-Udf @{ a = $null }) -Key 'a' | Should -Be ''
        Get-MeUdfFieldValue -UdfFields $null -Key 'a' | Should -Be ''
    }

    It 'trims whitespace' {
        Get-MeUdfFieldValue -UdfFields (New-Udf @{ a = '  Reader  ' }) -Key 'a' | Should -Be 'Reader'
    }
}

Describe 'Get-MeTemplateAccessFields' {
    It 'reads the three fields from the default udf keys' {
        $f = Get-MeTemplateAccessFields -UdfFields (New-Udf @{
                udf_pick_3728 = 'inception-ai-Sandbox'
                udf_pick_3729 = 'Reader'
                udf_pick_3719 = 'Sandbox'
            })
        $f.Subscription | Should -Be 'inception-ai-Sandbox'
        $f.AzureRole | Should -Be 'Reader'
        $f.Environment | Should -Be 'Sandbox'
    }

    It 'normalises ME placeholder values to empty so they are never treated as an answer' {
        foreach ($placeholder in @('Not Specified', 'n/a', 'NA', '-', 'none', '   ')) {
            $f = Get-MeTemplateAccessFields -UdfFields (New-Udf @{ udf_pick_3729 = $placeholder })
            $f.AzureRole | Should -Be '' -Because "'$placeholder' is not a real selection"
        }
    }

    It 'honours udf key overrides passed in as a parameter' {
        # The poller has no $config script scope, so the keys must be injectable.
        $f = Get-MeTemplateAccessFields -UdfFields (New-Udf @{ custom_sub = 'ceo-sub-application' }) `
            -UdfKeyOverrides ([pscustomobject]@{ subscription = 'custom_sub' })
        $f.Subscription | Should -Be 'ceo-sub-application'
    }

    It 'ignores the legacy environmentsRequired key udf_sline_3715' {
        $f = Get-MeTemplateAccessFields -UdfFields (New-Udf @{ udf_sline_3715 = 'Prod' }) `
            -UdfKeyOverrides ([pscustomobject]@{ environmentsRequired = 'udf_sline_3715' })
        $f.Environment | Should -Be ''
    }

    It 'reports the field keys it used' {
        (Get-MeTemplateAccessFields -UdfFields (New-Udf)).fieldKeys.AzureRole | Should -Be 'udf_pick_3729'
    }

    It 'TargetResourceId is blank by default -- no UDF key is configured for it out of the box' {
        # The ME "Azure Subscription" template has no field for this yet; a default key
        # would silently read the wrong UDF. Blank is the correct fail-closed default.
        $f = Get-MeTemplateAccessFields -UdfFields (New-Udf @{ udf_sline_9999 = 'anything' })
        $f.TargetResourceId | Should -Be ''
        $f.fieldKeys.TargetResourceId | Should -Be ''
    }

    It 'reads TargetResourceId once a UDF key override is supplied' {
        $f = Get-MeTemplateAccessFields -UdfFields (New-Udf @{ udf_sline_9999 = '/subscriptions/x/resourceGroups/y/providers/Microsoft.ContainerService/managedClusters/z' }) `
            -UdfKeyOverrides ([pscustomobject]@{ targetResourceId = 'udf_sline_9999' })
        $f.TargetResourceId | Should -Be '/subscriptions/x/resourceGroups/y/providers/Microsoft.ContainerService/managedClusters/z'
    }

    It 'normalises ME placeholder values for TargetResourceId too' {
        $f = Get-MeTemplateAccessFields -UdfFields (New-Udf @{ udf_sline_9999 = 'Not Specified' }) `
            -UdfKeyOverrides ([pscustomobject]@{ targetResourceId = 'udf_sline_9999' })
        $f.TargetResourceId | Should -Be ''
    }
}

Describe 'Get-MeConfiguredAccessFields' {
    It 'honours udf key overrides from $Config.manageEngine.udfFields' {
        $config = [pscustomobject]@{
            manageEngine = [pscustomobject]@{
                udfFields = [pscustomobject]@{ subscription = 'custom_sub' }
            }
        }
        $f = Get-MeConfiguredAccessFields -UdfFields (New-Udf @{ custom_sub = 'ceo-sub-application' }) -Config $config
        $f.Subscription | Should -Be 'ceo-sub-application'
    }

    It 'does not throw when the config has no manageEngine section, and falls back to the default keys' {
        $config = [pscustomobject]@{ someOtherSetting = 'x' }
        { Get-MeConfiguredAccessFields -UdfFields (New-Udf @{ udf_pick_3729 = 'Reader' }) -Config $config } | Should -Not -Throw
        $f = Get-MeConfiguredAccessFields -UdfFields (New-Udf @{ udf_pick_3729 = 'Reader' }) -Config $config
        $f.AzureRole | Should -Be 'Reader'
    }

    It 'does not throw when manageEngine exists but has no udfFields, and falls back to the default keys' {
        $config = [pscustomobject]@{ manageEngine = [pscustomobject]@{ baseUrl = 'https://example' } }
        $f = Get-MeConfiguredAccessFields -UdfFields (New-Udf @{ udf_pick_3728 = 'inception-ai-Sandbox' }) -Config $config
        $f.Subscription | Should -Be 'inception-ai-Sandbox'
    }

    It 'falls back to the default keys when Config is $null' {
        $f = Get-MeConfiguredAccessFields -UdfFields (New-Udf @{ udf_pick_3719 = 'Prod' }) -Config $null
        $f.Environment | Should -Be 'Prod'
    }

    It 'falls back to the default keys when Config is omitted entirely' {
        $f = Get-MeConfiguredAccessFields -UdfFields (New-Udf @{ udf_pick_3719 = 'Prod' })
        $f.Environment | Should -Be 'Prod'
    }

    It 'honours a targetResourceId override from $Config.manageEngine.udfFields' {
        $config = [pscustomobject]@{
            manageEngine = [pscustomobject]@{
                udfFields = [pscustomobject]@{ targetResourceId = 'udf_sline_9999' }
            }
        }
        $f = Get-MeConfiguredAccessFields -UdfFields (New-Udf @{ udf_sline_9999 = '/subscriptions/x/resourceGroups/y/providers/Microsoft.ContainerService/managedClusters/z' }) -Config $config
        $f.TargetResourceId | Should -Be '/subscriptions/x/resourceGroups/y/providers/Microsoft.ContainerService/managedClusters/z'
    }
}
