BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    $script:Runbook = Join-Path $repoRoot 'src\Runbooks\Runbook-Emergency-PIM.ps1'

    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

    $script:SandboxSub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    $script:ProdSub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    $script:Allowlist = @($script:SandboxSub, $script:ProdSub)

    function New-TestTicket {
        param(
            [string]$Environment = 'Production',
            [string]$Role = 'Contributor',
            [string]$Priority = 'P1',
            [int]$DurationDays = 1,
            [string]$Justification = '',
            [hashtable]$Extra = @{}
        )

        $ticket = @{
            TicketId       = [guid]::NewGuid().ToString()
            Role           = $Role
            Environment    = $Environment
            SubscriptionId = if ($Environment -eq 'Sandbox') { $script:SandboxSub } else { $script:ProdSub }
            ResourceScope  = "/subscriptions/$(if ($Environment -eq 'Sandbox') { $script:SandboxSub } else { $script:ProdSub })"
            DurationDays   = $DurationDays
            Priority       = $Priority
            RequesterUpn   = 'test.user@contoso.com'
            SubmitterUpn   = 'test.user@contoso.com'
            Justification  = $Justification
        }
        foreach ($k in $Extra.Keys) { $ticket[$k] = $Extra[$k] }
        if ($Environment -eq 'Production' -and [string]::IsNullOrWhiteSpace($ticket.Justification)) {
            $ticket.Justification = 'Break-glass P1 incident remediation - on-call manager pre-authorised'
        }
        return $ticket
    }

    function New-BreakGlassTicket {
        param(
            [string]$Role = 'Contributor',
            [string]$Priority = 'P1'
        )
        # RequestType 'Emergency Access' set for parity with matrix metadata; matching
        # is driven by the BreakGlass flag (see Get-EligibilityMatch).
        return New-TestTicket -Role $Role -Priority $Priority -Extra @{
            BreakGlass  = $true
            RequestType = 'Emergency Access'
        }
    }

    function Invoke-EmergencyRunbook {
        param([hashtable]$Ticket)
        return & $script:Runbook -Ticket $Ticket -SubscriptionAllowlist $script:Allowlist -PimClientImplementation 'Mock'
    }
}

Describe 'Runbook-Emergency-PIM - P1 Contributor break-glass auto-grant (Sec. 5.4)' {
    It 'grants an ACTIVE assignment with Success true' {
        $result = Invoke-EmergencyRunbook -Ticket (New-BreakGlassTicket)
        $result.Success | Should -Be $true
        $result.AssignmentId | Should -Not -BeNullOrEmpty
        $result.AssignmentType | Should -Be 'Active'
    }

    It 'flags the grant as break-glass and raises a security alert (Deliverable #4)' {
        $result = Invoke-EmergencyRunbook -Ticket (New-BreakGlassTicket)
        $result.BreakGlass | Should -Be $true
        $result.SecurityAlertRaised | Should -Be $true
        $result.AlertTargets | Should -Contain 'Cloud Security Team'
        $result.AlertTargets | Should -Contain 'On-Call Manager'
    }

    It 'propagates the 4-hour async review window from the decision engine' {
        $result = Invoke-EmergencyRunbook -Ticket (New-BreakGlassTicket)
        $result.ReviewHours | Should -Be 4
        $result.ReviewBy | Should -Not -BeNullOrEmpty
    }

    It 'resolves the requester UPN to the mock object id' {
        $result = Invoke-EmergencyRunbook -Ticket (New-BreakGlassTicket)
        $result.UserId | Should -Be '11111111-1111-1111-1111-111111111111'
    }

    It 'reports the Mock client implementation' {
        $result = Invoke-EmergencyRunbook -Ticket (New-BreakGlassTicket)
        $result.PimClient | Should -Be 'Mock'
    }
}

Describe 'Runbook-Emergency-PIM - Owner break-glass rejected upstream (Sec. 5.4)' {
    It 'P1 Owner break-glass - Success false, emergency-escalate reject' {
        $result = Invoke-EmergencyRunbook -Ticket (New-BreakGlassTicket -Role Owner)
        $result.Success | Should -Be $false
        $result.Decision.Action | Should -Be 'Reject'
        $result.Decision.Path | Should -Be 'Emergency-Escalate'
        $result.Message | Should -Not -BeNullOrEmpty
    }
}

Describe 'Runbook-Emergency-PIM - non-P1 contributor falls through to matrix' {
    It 'P2 Contributor break-glass - not BreakGlass, fails closed (Eligible per matrix)' {
        # Per Get-EligibilityMatch, break-glass only fires for P1; a P2 Contributor
        # falls through to prod-contributor-expedited (Eligible), so the Emergency
        # runbook fails closed (Success false, decision is not BreakGlass).
        $result = Invoke-EmergencyRunbook -Ticket (New-BreakGlassTicket -Priority P2)
        $result.Success | Should -Be $false
        $result.Decision.Action | Should -Not -Be 'BreakGlass'
        $result.Decision.Action | Should -Be 'Eligible'
    }
}

Describe 'Resolve-RbacDecision - review window propagation (engine edit)' {
    It 'break-glass decision carries ReviewHours = 4' {
        $ticket = New-BreakGlassTicket
        $decision = Resolve-RbacDecision -Ticket $ticket -SubscriptionAllowlist $script:Allowlist
        $decision.Action | Should -Be 'BreakGlass'
        $decision.ReviewHours | Should -Be 4
    }
}
