﻿BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
}

Describe 'Get-TicketCriticality — FR1 environment-first prioritization' {

    Context 'the stakeholder rule' {
        It 'ranks a P4 Production ticket above a P1 Non-Prod ticket' {
            $prod = Get-TicketCriticality -Environment 'Production' -Priority 'P4'
            $nonProd = Get-TicketCriticality -Environment 'NonProd' -Priority 'P1'
            $prod.Score | Should -BeLessThan $nonProd.Score
        }

        It 'ranks a P4 Non-Prod ticket above a P0 Sandbox ticket' {
            $nonProd = Get-TicketCriticality -Environment 'NonProd' -Priority 'P4'
            $sandbox = Get-TicketCriticality -Environment 'Sandbox' -Priority 'P0'
            $nonProd.Score | Should -BeLessThan $sandbox.Score
        }

        It 'flags PriorityDemoted when a high priority is claimed outside Production' {
            (Get-TicketCriticality -Environment 'NonProd' -Priority 'P1').PriorityDemoted | Should -BeTrue
            (Get-TicketCriticality -Environment 'Sandbox' -Priority 'P2').PriorityDemoted | Should -BeTrue
            (Get-TicketCriticality -Environment 'Production' -Priority 'P1').PriorityDemoted | Should -BeFalse
        }

        It 'explains the demotion in the reason text' {
            $r = Get-TicketCriticality -Environment 'NonProd' -Priority 'P1'
            $r.Reason | Should -Match 'cannot outrank a Production ticket'
        }
    }

    Context 'priority as a secondary tiebreaker' {
        It 'orders by priority inside the same environment band' {
            $p1 = Get-TicketCriticality -Environment 'Production' -Priority 'P1'
            $p3 = Get-TicketCriticality -Environment 'Production' -Priority 'P3'
            $p1.Score | Should -BeLessThan $p3.Score
        }

        It 'keeps every environment band strictly separated' {
            # Best possible Sandbox score must still be worse than the worst Non-Prod score.
            $bestSandbox = Get-TicketCriticality -Environment 'Sandbox' -Priority 'P0'
            $worstNonProd = Get-TicketCriticality -Environment 'NonProd' -Priority 'P4'
            $worstNonProd.Score | Should -BeLessThan $bestSandbox.Score
        }
    }

    Context 'priority defaulting' {
        It 'defaults a missing priority to P4 and records that it was not supplied' {
            $r = Get-TicketCriticality -Environment 'Sandbox'
            $r.Priority | Should -Be 'P4'
            $r.PrioritySupplied | Should -BeFalse
            $r.Reason | Should -Match 'defaulted to P4'
        }

        It 'captures a supplied priority' {
            $r = Get-TicketCriticality -Environment 'Sandbox' -Priority 'P2'
            $r.Priority | Should -Be 'P2'
            $r.PrioritySupplied | Should -BeTrue
        }

        It 'treats an unrecognised priority as P4' {
            (Get-TicketCriticality -Environment 'Sandbox' -Priority 'Urgent').Priority | Should -Be 'P4'
        }
    }

    Context 'environment normalization' {
        It 'maps template synonyms onto canonical bands' {
            (Get-TicketCriticality -Environment 'Development').Environment | Should -Be 'NonProd'
            (Get-TicketCriticality -Environment 'Test').Environment | Should -Be 'NonProd'
            (Get-TicketCriticality -Environment 'staging').Environment | Should -Be 'NonProd'
            (Get-TicketCriticality -Environment 'Non-Prod').Environment | Should -Be 'NonProd'
            (Get-TicketCriticality -Environment 'prod').Environment | Should -Be 'Production'
            (Get-TicketCriticality -Environment 'SANDBOX').Environment | Should -Be 'Sandbox'
        }

        It 'never reads non-prod as Production' {
            (Get-TicketCriticality -Environment 'non-production').Environment | Should -Be 'NonProd'
            (Get-TicketCriticality -Environment 'pre-prod').Environment | Should -Be 'NonProd'
        }
    }

    Context 'untagged tickets' {
        It 'sorts Unknown last and flags it for governance backfill' {
            $unknown = Get-TicketCriticality -Environment '' -Priority 'P1'
            $sandbox = Get-TicketCriticality -Environment 'Sandbox' -Priority 'P4'
            $sandbox.Score | Should -BeLessThan $unknown.Score
            $unknown.RequiresEnvironment | Should -BeTrue
            $unknown.Tier | Should -Be 'Unclassified'
        }

        It 'does not flag RequiresEnvironment for a tagged ticket' {
            (Get-TicketCriticality -Environment 'Sandbox').RequiresEnvironment | Should -BeFalse
        }
    }

    Context 'subscription-sensitivity escalation' {
        It 'prioritizes on the effective environment, not the claimed one' {
            # A "sandbox" request against a sensitive subscription is really Production.
            $r = Get-TicketCriticality -Environment 'Sandbox' -EffectiveEnvironment 'Production' -Priority 'P4'
            $r.Environment | Should -Be 'Production'
            $r.Tier | Should -Be 'Critical'
            $r.Reason | Should -Match 'escalated from claimed'
        }

        It 'still outranks a genuine Non-Prod P1 after escalation' {
            $escalated = Get-TicketCriticality -Environment 'Sandbox' -EffectiveEnvironment 'Production' -Priority 'P4'
            $nonProd = Get-TicketCriticality -Environment 'NonProd' -Priority 'P1'
            $escalated.Score | Should -BeLessThan $nonProd.Score
        }
    }

    Context 'sorting a mixed queue' {
        It 'produces the effective ordering Prod -> Non-Prod -> Sandbox -> Unknown' {
            $queue = @(
                @{ id = 'sbx-p0'; env = 'Sandbox'; prio = 'P0' }
                @{ id = 'unknown-p1'; env = ''; prio = 'P1' }
                @{ id = 'prod-p4'; env = 'Production'; prio = 'P4' }
                @{ id = 'nonprod-p1'; env = 'NonProd'; prio = 'P1' }
                @{ id = 'prod-p1'; env = 'Production'; prio = 'P1' }
            )
            $sorted = @($queue | ForEach-Object {
                    $c = Get-TicketCriticality -Environment $_.env -Priority $_.prio
                    [pscustomobject]@{ id = $_.id; score = $c.Score }
                } | Sort-Object score)

            @($sorted.id) | Should -Be @('prod-p1', 'prod-p4', 'nonprod-p1', 'sbx-p0', 'unknown-p1')
        }
    }
}
