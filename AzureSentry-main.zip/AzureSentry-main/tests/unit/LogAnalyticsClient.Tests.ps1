﻿BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\LogAnalyticsClient.ps1')

    function Reset-LogAnalyticsEnv {
        foreach ($v in @('AZURESENTRY_LA_DCE_ENDPOINT', 'AZURESENTRY_LA_DCR_IMMUTABLE_ID', 'AZURESENTRY_LA_STREAM_NAME',
                'AZURESENTRY_LA_TENANT_ID', 'AZURESENTRY_LA_CLIENT_ID', 'AZURESENTRY_LA_CLIENT_SECRET')) {
            [System.Environment]::SetEnvironmentVariable($v, $null, 'Process')
        }
        $script:LogAnalyticsTokenCache = $null
    }

    function Set-LogAnalyticsEnv {
        $env:AZURESENTRY_LA_DCE_ENDPOINT = 'https://dce-test.uaenorth-1.ingest.monitor.azure.com'
        $env:AZURESENTRY_LA_DCR_IMMUTABLE_ID = 'dcr-abc123'
        $env:AZURESENTRY_LA_TENANT_ID = 'tenant-guid'
        $env:AZURESENTRY_LA_CLIENT_ID = 'client-guid'
        $env:AZURESENTRY_LA_CLIENT_SECRET = 'super-secret'
    }

    function New-TestAuditEvent {
        [pscustomobject]@{
            seq = 1; timestamp = '2026-08-19T00:00:00.000Z'; id = '1-abcdef'
            agent = 'DecisionAgent'; action = 'Evaluate'; actor = 'test@x.com'
            runId = 'run-1'; correlationId = 'run-1'; ticketId = '1001'
            target = @{ subscriptionId = 'sub-1' }
            before = $null; after = @{ action = 'Grant' }
            outcome = 'Success'; reason = $null; detail = @{ mode = 'evaluate' }
            correctsEventId = $null; isWrite = $false
            hash = 'aaa'; prevHash = 'GENESIS'
        }
    }
}

Describe 'Get-LogAnalyticsSettings — FR6 optional configuration' {
    AfterEach { Reset-LogAnalyticsEnv }

    It 'reports not configured when no environment variables are set' {
        Reset-LogAnalyticsEnv
        (Get-LogAnalyticsSettings).Configured | Should -BeFalse
    }

    It 'reports configured only when all required variables are present' {
        Set-LogAnalyticsEnv
        (Get-LogAnalyticsSettings).Configured | Should -BeTrue
    }

    It 'reports not configured when only some variables are present' {
        Set-LogAnalyticsEnv
        Remove-Item Env:\AZURESENTRY_LA_CLIENT_SECRET
        (Get-LogAnalyticsSettings).Configured | Should -BeFalse
    }

    It 'defaults the stream name when not overridden' {
        Set-LogAnalyticsEnv
        (Get-LogAnalyticsSettings).StreamName | Should -Be 'Custom-AzureSentryAuditLog_CL'
    }

    It 'honours a custom stream name' {
        Set-LogAnalyticsEnv
        $env:AZURESENTRY_LA_STREAM_NAME = 'Custom-Other_CL'
        (Get-LogAnalyticsSettings).StreamName | Should -Be 'Custom-Other_CL'
    }
}

Describe 'Send-LogAnalyticsAuditEvent — fail-open contract' {
    AfterEach { Reset-LogAnalyticsEnv }

    It 'is a silent no-op when not configured — never throws, never calls the network' {
        Reset-LogAnalyticsEnv
        Mock -CommandName Invoke-RestMethod -MockWith { throw 'must not be called' }
        $r = Send-LogAnalyticsAuditEvent -Event (New-TestAuditEvent)
        $r.ok | Should -BeFalse
        $r.skipped | Should -BeTrue
        Should -Invoke -CommandName Invoke-RestMethod -Times 0
    }

    It 'acquires a token then posts to the DCE stream endpoint when configured' {
        Set-LogAnalyticsEnv
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'login.microsoftonline.com' } -MockWith {
            [pscustomobject]@{ access_token = 'fake-token'; expires_in = 3600 }
        }
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'dataCollectionRules' } -MockWith {
            return $null
        }
        $r = Send-LogAnalyticsAuditEvent -Event (New-TestAuditEvent)
        $r.ok | Should -BeTrue
        Should -Invoke -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'dataCollectionRules' } -Times 1
    }

    It 'sends the ingestion URI with the DCR immutable ID and stream name' {
        Set-LogAnalyticsEnv
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'login.microsoftonline.com' } -MockWith {
            [pscustomobject]@{ access_token = 'fake-token'; expires_in = 3600 }
        }
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'dataCollectionRules' } -MockWith { $null }
        Send-LogAnalyticsAuditEvent -Event (New-TestAuditEvent) | Out-Null
        Should -Invoke -CommandName Invoke-RestMethod -ParameterFilter {
            $Uri -match 'dcr-abc123' -and $Uri -match 'Custom-AzureSentryAuditLog_CL' -and $Headers.Authorization -eq 'Bearer fake-token'
        } -Times 1
    }

    It 'wraps the record in a JSON array even for a single event' {
        Set-LogAnalyticsEnv
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'login.microsoftonline.com' } -MockWith {
            [pscustomobject]@{ access_token = 'fake-token'; expires_in = 3600 }
        }
        $capturedBody = $null
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'dataCollectionRules' } -MockWith {
            $script:capturedBody = $Body
            return $null
        }
        Send-LogAnalyticsAuditEvent -Event (New-TestAuditEvent) | Out-Null
        $script:capturedBody.TrimStart() | Should -Match '^\['
    }

    It 'returns ok=false with the error message when the send fails, never throwing' {
        Set-LogAnalyticsEnv
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'login.microsoftonline.com' } -MockWith {
            [pscustomobject]@{ access_token = 'fake-token'; expires_in = 3600 }
        }
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'dataCollectionRules' } -MockWith {
            throw 'simulated ingestion failure'
        }
        $r = Send-LogAnalyticsAuditEvent -Event (New-TestAuditEvent)
        $r.ok | Should -BeFalse
        $r.error | Should -Match 'simulated ingestion failure'
    }

    It 'caches the access token across sends instead of re-authenticating every time' {
        Set-LogAnalyticsEnv
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'login.microsoftonline.com' } -MockWith {
            [pscustomobject]@{ access_token = 'fake-token'; expires_in = 3600 }
        }
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'dataCollectionRules' } -MockWith { $null }
        Send-LogAnalyticsAuditEvent -Event (New-TestAuditEvent) | Out-Null
        Send-LogAnalyticsAuditEvent -Event (New-TestAuditEvent) | Out-Null
        Should -Invoke -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'login.microsoftonline.com' } -Times 1
    }
}

Describe 'ConvertTo-LogAnalyticsAuditRecord — schema matches the DCR/table columns' {

    It 'maps every audit event field to its _CL column name' {
        $record = ConvertTo-LogAnalyticsAuditRecord -Event (New-TestAuditEvent)
        $record.seq_d | Should -Be 1
        $record.id_s | Should -Be '1-abcdef'
        $record.agent_s | Should -Be 'DecisionAgent'
        $record.action_s | Should -Be 'Evaluate'
        $record.actor_s | Should -Be 'test@x.com'
        $record.ticketId_s | Should -Be '1001'
        $record.outcome_s | Should -Be 'Success'
        $record.isWrite_b | Should -BeFalse
        $record.hash_s | Should -Be 'aaa'
        $record.prevHash_s | Should -Be 'GENESIS'
    }

    It 'serializes target/before/after/detail objects to JSON strings, not raw objects' {
        $record = ConvertTo-LogAnalyticsAuditRecord -Event (New-TestAuditEvent)
        $record.target_s | Should -Match '"subscriptionId"'
        $record.after_s | Should -Match '"action"\s*:\s*"Grant"'
        { $record.target_s | ConvertFrom-Json } | Should -Not -Throw
    }

    It 'leaves null before/after as null rather than the string "null"' {
        $record = ConvertTo-LogAnalyticsAuditRecord -Event (New-TestAuditEvent)
        $record.before_s | Should -BeNullOrEmpty
    }
}
