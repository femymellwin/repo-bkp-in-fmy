BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
    . (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')
}

Describe 'Mock group RBAC APIs' {
    BeforeEach { Reset-MockPimState }

    It 'Find-EntraRbacGroups returns groups by prefix' {
        $c = New-MockPimClient -Groups @(
            [pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }
        )
        $found = Find-EntraRbacGroups -Client $c -DisplayNamePrefix 'sg-jira-conf-prod'
        @($found).Count | Should -Be 1
    }

    It 'Test-GroupHasSubscriptionRole reads mock IAM' {
        $sub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
        $contrib = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
        $c = New-MockPimClient -RoleAssignments @(
            [pscustomobject]@{ principalId = 'g1'; roleDefinitionId = $contrib; scope = "/subscriptions/$sub" }
        )
        Test-GroupHasSubscriptionRole -Client $c -GroupId 'g1' -SubscriptionId $sub -RoleDefinitionId $contrib | Should -Be $true
        Test-GroupHasSubscriptionRole -Client $c -GroupId 'g1' -SubscriptionId $sub -RoleDefinitionId 'acdd72a7-3385-48ef-bd42-f606fba81ae7' | Should -Be $false
    }

    It 'Add-EntraGroupMember is idempotent' {
        $c = New-MockPimClient
        $r1 = Add-EntraGroupMember -Client $c -GroupId 'g1' -UserId 'u1'
        $r2 = Add-EntraGroupMember -Client $c -GroupId 'g1' -UserId 'u1'
        $r1.AlreadyMember | Should -Be $false
        $r2.AlreadyMember | Should -Be $true
    }
}

Describe 'Invoke-GroupOrPimGrant' {
    BeforeAll {
        $sub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
        $contrib = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
    }
    BeforeEach { Reset-MockPimState }

    It 'adds user to group when group+IAM exist' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }) `
            -RoleAssignments @([pscustomobject]@{ principalId = 'g1'; roleDefinitionId = $contrib; scope = "/subscriptions/$sub" }) `
            -SubscriptionNames @{ $sub = 'jira-conf-prod' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 7 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'Group'
        $r.EngineerActionRequired | Should -Be $false
        $r.GroupId | Should -Be 'g1'
        @(Get-EntraGroupMembers -Client $c -GroupId 'g1') | Should -Contain 'u1'
        @(Get-ActiveAssignments -Client $c -UserId 'u1' -RoleDefinitionId $contrib -Scope "/subscriptions/$sub").Count | Should -Be 0
    }

    It 'rejects roles unsupported by the group path' {
        $c = New-MockPimClient
        {
            Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Owner' `
                -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 7 -Justification 'test'
        } | Should -Throw "*Role 'Owner' is not supported on the group RBAC path*"
    }

    It 'extracts omitted SubscriptionId from ResourceScope' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }) `
            -RoleAssignments @([pscustomobject]@{ principalId = 'g1'; roleDefinitionId = $contrib; scope = "/subscriptions/$sub" }) `
            -SubscriptionNames @{ $sub = 'jira-conf-prod' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -ResourceScope "/subscriptions/$sub/resourceGroups/rg-test" -DurationDays 7 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'Group'
        @(Get-EntraGroupMembers -Client $c -GroupId 'g1') | Should -Contain 'u1'
    }

    It 'creates canonical group and IAM when group is missing' {
        $c = New-MockPimClient -SubscriptionNames @{ $sub = 'ceo-sub-application' } `
            -Users @{ 'test.user@contoso.com' = 'u1' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'Group'
        $r.GroupCreated | Should -Be $true
        $r.RoleAssignmentCreated | Should -Be $true
        $r.EngineerActionRequired | Should -Be $false
        $r.GroupName | Should -Be 'sg-ceo-sub-application-contributors'
        @(Get-EntraGroupMembers -Client $c -GroupId $r.GroupId) | Should -Contain 'u1'
        Test-GroupHasSubscriptionRole -Client $c -GroupId $r.GroupId -SubscriptionId $sub -RoleDefinitionId $contrib | Should -Be $true
    }

    It 'falls back with an actionable reason when group matches are ambiguous' {
        $c = New-MockPimClient `
            -Groups @(
                [pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }
                [pscustomobject]@{ id = 'g2'; displayName = 'sg-jira-conf-prod-platform-contributors' }
            ) `
            -SubscriptionNames @{ $sub = 'jira-conf-prod' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'PimFallback'
        $r.AssignmentId | Should -Not -BeNullOrEmpty
        $r.GroupId | Should -BeNullOrEmpty
        $r.GroupName | Should -BeNullOrEmpty
        $r.EngineerActionRequired | Should -Be $true
        $r.EngineerActionReason | Should -Match 'Status=Ambiguous'
        $r.EngineerActionReason | Should -Match 'PatternsTried='
        $r.PatternsTried | Should -Contain 'sg-jira-conf-prod-*-contributors'
    }

    It 'assigns subscription IAM when group exists without role assignment' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }) `
            -SubscriptionNames @{ $sub = 'jira-conf-prod' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'Group'
        $r.GroupCreated | Should -Be $false
        $r.RoleAssignmentCreated | Should -Be $true
        $r.GroupId | Should -Be 'g1'
        $r.EngineerActionRequired | Should -Be $false
        Test-GroupHasSubscriptionRole -Client $c -GroupId 'g1' -SubscriptionId $sub -RoleDefinitionId $contrib | Should -Be $true
        @(Get-EntraGroupMembers -Client $c -GroupId 'g1') | Should -Contain 'u1'
    }

    It 'reports already-existed when the Entra group is already present' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g-existing'; displayName = 'sg-ceo-sub-application-contributors' }) `
            -SubscriptionNames @{ $sub = 'ceo-sub-application' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'Group'
        $r.GroupCreated | Should -Be $false
        $r.GroupAlreadyExisted | Should -Be $true
        $r.GroupName | Should -Be 'sg-ceo-sub-application-contributors'
        $r.Message | Should -Match 'already exists'
    }

    It 'adds a different user when the group already exists' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-ceo-sub-application-contributors' }) `
            -RoleAssignments @([pscustomobject]@{ principalId = 'g1'; roleDefinitionId = $contrib; scope = "/subscriptions/$sub" }) `
            -GroupMembers @{ g1 = @('u-first') } `
            -SubscriptionNames @{ $sub = 'ceo-sub-application' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u-second' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'Group'
        $r.GroupCreated | Should -Be $false
        @(Get-EntraGroupMembers -Client $c -GroupId 'g1') | Should -Contain 'u-first'
        @(Get-EntraGroupMembers -Client $c -GroupId 'g1') | Should -Contain 'u-second'
    }

    It 'falls back to PIM when Graph group APIs return Forbidden' {
        Mock Find-EntraRbacGroups { throw 'The remote server returned an error: (403) Forbidden. | Authorization_RequestDenied' }
        $c = New-MockPimClient -SubscriptionNames @{ $sub = 'ceo-sub-application' } `
            -Users @{ 'test.user@contoso.com' = 'u1' }
        $r = Invoke-GroupOrPimGrant -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $sub -ResourceScope "/subscriptions/$sub" -DurationDays 3 -Justification 'test'
        $r.Success | Should -Be $true
        $r.Fulfilment | Should -Be 'PimFallback'
        $r.EngineerActionRequired | Should -Be $true
        $r.EngineerActionReason | Should -Match 'Group.ReadWrite.All'
        $r.AssignmentId | Should -Not -BeNullOrEmpty
    }
}

Describe 'Test-GroupRbacDuplicateAccess' {
    BeforeAll {
        $script:DupSub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    }
    BeforeEach { Reset-MockPimState }

    It 'is not a duplicate when no matching group exists' {
        $c = New-MockPimClient -SubscriptionNames @{ $script:DupSub = 'ceo-sub-application' }
        $r = Test-GroupRbacDuplicateAccess -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $script:DupSub
        $r.Duplicate | Should -Be $false
        $r.AlreadyMember | Should -Be $false
        $r.GroupId | Should -BeNullOrEmpty
    }

    It 'is not a duplicate when the group exists but the requester is not a member' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-ceo-sub-application-contributors' }) `
            -GroupMembers @{ g1 = @('someone-else') } `
            -SubscriptionNames @{ $script:DupSub = 'ceo-sub-application' }
        $r = Test-GroupRbacDuplicateAccess -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $script:DupSub
        $r.Duplicate | Should -Be $false
        $r.AlreadyMember | Should -Be $false
        $r.GroupId | Should -Be 'g1'
        $r.GroupName | Should -Be 'sg-ceo-sub-application-contributors'
    }

    It 'is a duplicate when the requester is already a member of the matching group' {
        $c = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'g1'; displayName = 'sg-ceo-sub-application-contributors' }) `
            -GroupMembers @{ g1 = @('u1') } `
            -SubscriptionNames @{ $script:DupSub = 'ceo-sub-application' }
        $r = Test-GroupRbacDuplicateAccess -Client $c -UserId 'u1' -RoleName 'Contributor' `
            -SubscriptionId $script:DupSub
        $r.Duplicate | Should -Be $true
        $r.AlreadyMember | Should -Be $true
        $r.GroupId | Should -Be 'g1'
        $r.Reason | Should -Match 'already a member'
    }
}
