BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    $script:Runbook = Join-Path $repoRoot 'src\Runbooks\Runbook-Status-Updater.ps1'

    function Invoke-StatusRunbook {
        param(
            [string]$TicketId = 'REQ-1001',
            [string]$Status = 'Resolved',
            [string]$Message = '',
            [string]$Implementation = 'Mock'
        )
        return & $script:Runbook -TicketId $TicketId -Status $Status -Message $Message -Implementation $Implementation
    }
}

Describe 'Runbook-Status-Updater - Mock mode (offline, no network)' {
    BeforeEach {
        # Guard: any real network call would mean the runbook leaked out of Mock mode.
        Mock -CommandName Invoke-RestMethod -MockWith { throw 'Network call must not happen in Mock mode' }
        $env:AZURESENTRY_ME_BASEURL = 'https://sdp.contoso.com'
        $env:AZURESENTRY_ME_TOKEN = 'unit-test-token'
    }

    AfterEach {
        Remove-Item Env:AZURESENTRY_ME_BASEURL -ErrorAction SilentlyContinue
        Remove-Item Env:AZURESENTRY_ME_TOKEN -ErrorAction SilentlyContinue
    }

    It 'returns Success true with Mode Mock' {
        $result = Invoke-StatusRunbook -TicketId 'REQ-2002' -Status 'Resolved' -Implementation 'Mock'
        $result.Success | Should -Be $true
        $result.Mode | Should -Be 'Mock'
    }

    It 'echoes the supplied TicketId and Status' {
        $result = Invoke-StatusRunbook -TicketId 'REQ-2002' -Status 'Pending Approval' -Implementation 'Mock'
        $result.TicketId | Should -Be 'REQ-2002'
        $result.Status | Should -Be 'Pending Approval'
    }

    It 'echoes the supplied Message' {
        $result = Invoke-StatusRunbook -TicketId 'REQ-2002' -Status 'Resolved' -Message 'Granted Reader for 7 days' -Implementation 'Mock'
        $result.Message | Should -Be 'Granted Reader for 7 days'
    }

    It 'makes NO network call in Mock mode' {
        Invoke-StatusRunbook -TicketId 'REQ-2002' -Status 'Resolved' -Implementation 'Mock' | Out-Null
        Should -Invoke -CommandName Invoke-RestMethod -Times 0 -Exactly
    }
}

Describe 'Runbook-Status-Updater - empty base url forces Mock behavior' {
    BeforeEach {
        Mock -CommandName Invoke-RestMethod -MockWith { throw 'Network call must not happen without a base url' }
        Remove-Item Env:AZURESENTRY_ME_BASEURL -ErrorAction SilentlyContinue
        $env:AZURESENTRY_ME_TOKEN = 'unit-test-token'
    }

    AfterEach {
        Remove-Item Env:AZURESENTRY_ME_TOKEN -ErrorAction SilentlyContinue
    }

    It 'returns Mode Mock even when Implementation is Live (no base url configured)' {
        $result = Invoke-StatusRunbook -TicketId 'REQ-3003' -Status 'Resolved' -Implementation 'Live'
        $result.Success | Should -Be $true
        $result.Mode | Should -Be 'Mock'
        $result.Status | Should -Be 'Resolved'
    }

    It 'makes NO network call when base url is empty' {
        Invoke-StatusRunbook -TicketId 'REQ-3003' -Status 'Resolved' -Implementation 'Live' | Out-Null
        Should -Invoke -CommandName Invoke-RestMethod -Times 0 -Exactly
    }
}
