BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    $script:Runbook = Join-Path $repoRoot 'src\Runbooks\Runbook-BreakGlass-Reaper.ps1'

    # Fixed reference clock so deadline math is deterministic.
    $script:Now = [datetime]::new(2026, 6, 27, 12, 0, 0, [System.DateTimeKind]::Utc)

    $script:Reader = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'
    $script:Contributor = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
    $script:Scope = '/subscriptions/bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    $script:Principal = '11111111-1111-1111-1111-111111111111'

    function New-Grant {
        param(
            [string]$AssignmentId,
            [int]$HoursBeforeNow,
            [bool]$Reviewed,
            $ReviewHours = $null
        )
        $grant = [PSCustomObject]@{
            AssignmentId     = $AssignmentId
            Scope            = $script:Scope
            PrincipalId      = $script:Principal
            RoleDefinitionId = $script:Contributor
            GrantedAt        = $script:Now.AddHours(-1 * $HoursBeforeNow)
            Reviewed         = $Reviewed
        }
        if ($null -ne $ReviewHours) {
            $grant | Add-Member -NotePropertyName ReviewHours -NotePropertyValue $ReviewHours
        }
        return $grant
    }

    function Invoke-Reaper {
        param([object[]]$Grants)
        return & $script:Runbook -TrackedGrants $Grants -PimClientImplementation 'Mock' -Now $script:Now
    }
}

Describe 'Runbook-BreakGlass-Reaper - G3 sweep (scope Sec. 5.4)' {
    BeforeAll {
        # Mixed batch:
        #  bg-breach : granted 6h ago, NOT reviewed -> reaped + breach
        #  bg-kept   : granted 1h ago               -> kept (inside 4h window)
        #  bg-clean  : granted 6h ago, reviewed     -> reaped, NOT a breach
        $script:Grants = @(
            (New-Grant -AssignmentId 'bg-breach' -HoursBeforeNow 6 -Reviewed $false),
            (New-Grant -AssignmentId 'bg-kept'   -HoursBeforeNow 1 -Reviewed $false),
            (New-Grant -AssignmentId 'bg-clean'  -HoursBeforeNow 6 -Reviewed $true)
        )
        $script:Result = Invoke-Reaper -Grants $script:Grants
    }

    It 'examines every tracked grant' {
        $script:Result.Examined | Should -Be 3
    }

    It 'reaps both grants past the review deadline' {
        $script:Result.Reaped.Count | Should -Be 2
    }

    It 'keeps the grant still inside its review window' {
        $script:Result.Kept.Count | Should -Be 1
        $script:Result.Kept[0].AssignmentId | Should -Be 'bg-kept'
    }

    It 'flags only the reaped-and-unreviewed grant as a review breach' {
        $script:Result.ReviewBreaches.Count | Should -Be 1
        $script:Result.ReviewBreaches[0].AssignmentId | Should -Be 'bg-breach'
    }

    It 'does not flag a reviewed grant as a breach even when reaped' {
        $reapedIds = @($script:Result.Reaped | ForEach-Object { $_.AssignmentId })
        $reapedIds | Should -Contain 'bg-clean'
        $breachIds = @($script:Result.ReviewBreaches | ForEach-Object { $_.AssignmentId })
        $breachIds | Should -Not -Contain 'bg-clean'
    }

    It 'reports the Mock client implementation' {
        $script:Result.PimClient | Should -Be 'Mock'
    }
}

Describe 'Runbook-BreakGlass-Reaper - defaults and defensive handling' {
    It 'defaults ReviewHours to 4 when the property is missing' {
        # Granted 5h ago, no ReviewHours -> default 4h window already elapsed -> reaped.
        $grant = New-Grant -AssignmentId 'bg-default' -HoursBeforeNow 5 -Reviewed $false
        $result = Invoke-Reaper -Grants @($grant)
        $result.Reaped.Count | Should -Be 1
        $result.ReviewBreaches.Count | Should -Be 1
    }

    It 'treats ReviewHours of 0 as the 4h default' {
        # Granted 5h ago, ReviewHours=0 -> default 4h window elapsed -> reaped.
        $grant = New-Grant -AssignmentId 'bg-zero' -HoursBeforeNow 5 -Reviewed $false -ReviewHours 0
        $result = Invoke-Reaper -Grants @($grant)
        $result.Reaped.Count | Should -Be 1
    }

    It 'honours an explicit non-default ReviewHours' {
        # Granted 5h ago, ReviewHours=8 -> window NOT elapsed -> kept.
        $grant = New-Grant -AssignmentId 'bg-long' -HoursBeforeNow 5 -Reviewed $false -ReviewHours 8
        $result = Invoke-Reaper -Grants @($grant)
        $result.Kept.Count | Should -Be 1
        $result.Reaped.Count | Should -Be 0
    }

    It 'handles an empty grant set (Examined 0, nothing reaped)' {
        $result = Invoke-Reaper -Grants @()
        $result.Examined | Should -Be 0
        $result.Reaped.Count | Should -Be 0
        $result.ReviewBreaches.Count | Should -Be 0
        $result.Kept.Count | Should -Be 0
    }
}
