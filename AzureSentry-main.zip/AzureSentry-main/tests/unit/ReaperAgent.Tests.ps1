BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\DashboardHelpers.ps1')
    . (Join-Path $repoRoot 'src\Agents\ReaperAgent.ps1')

    function New-RevocableGroupRecord {
        param(
            [string]$TicketId = 'ME-1001',
            [string]$ExpiresAt = '',
            [bool]$Revoked = $false
        )
        [pscustomobject]@{
            meTicketId     = $TicketId
            ticketId       = $TicketId
            action         = 'Grant'
            role           = 'Reader'
            environment    = 'Sandbox'
            subscriptionId = 'sub-1'
            requesterUpn   = 'dev.user@contoso.com'
            assignmentId   = $null
            fulfilment     = 'Group'
            groupId        = 'grp-1'
            groupName      = 'sg-sub-1-readers'
            expiresAt      = $ExpiresAt
            revoked        = $Revoked
        }
    }

    function New-RevocableAssignmentRecord {
        param(
            [string]$TicketId = 'ME-2001',
            [string]$ExpiresAt = '',
            [bool]$Revoked = $false
        )
        [pscustomobject]@{
            meTicketId     = $TicketId
            ticketId       = $TicketId
            action         = 'Grant'
            role           = 'Reader'
            environment    = 'Sandbox'
            subscriptionId = 'sub-2'
            requesterUpn   = 'dev.user2@contoso.com'
            assignmentId   = 'assign-1'
            assignmentType = 'Active'
            fulfilment     = 'PimFallback'
            expiresAt      = $ExpiresAt
            revoked        = $Revoked
        }
    }

    function New-ReaperContext {
        param(
            [hashtable]$Store = @{},
            [string]$Mode = 'shadow',
            [bool]$Enabled = $true,
            [int]$MaxRevokes = 25,
            [scriptblock]$RevokeGrant = $null,
            [string]$StopFilePath = '',
            [datetime]$Now = [datetime]::UtcNow
        )
        $script:RevokeCalls = [System.Collections.Generic.List[string]]::new()
        @{
            GetProcessedTickets = { $Store }.GetNewClosure()
            # No .GetNewClosure() here: $script:RevokeCalls is explicitly scope-qualified
            # and resolves dynamically at invocation time. GetNewClosure() instead
            # detaches the scriptblock's scope chain, which makes the explicitly-qualified
            # $script: reference bind to a DIFFERENT (empty) script scope at call time --
            # same pattern TicketPollerAgent.Tests.ps1's New-PollContext uses for its own
            # $script:Granted / $script:Recorded default hooks.
            RevokeGrant         = if ($RevokeGrant) { $RevokeGrant } else {
                { param($id, $prior) $script:RevokeCalls.Add([string]$id); @{ ok = $true } }
            }
            Config              = [pscustomobject]@{
                Enabled = $Enabled; Mode = $Mode
                MaxRevokesPerCycle = $MaxRevokes; StopFilePath = $StopFilePath
            }
            Now                 = $Now
        }
    }
}

Describe 'Get-ReaperConfig' {
    It 'is disabled and in shadow mode unless explicitly told otherwise' {
        $old = @{ e = $env:AZURESENTRY_REAPER_ENABLED; m = $env:AZURESENTRY_REAPER_MODE }
        try {
            Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue
            Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue
            $c = Get-ReaperConfig
            $c.Enabled | Should -BeFalse
            $c.Mode | Should -Be 'shadow'
        }
        finally {
            if ($old.e) { $env:AZURESENTRY_REAPER_ENABLED = $old.e }
            if ($old.m) { $env:AZURESENTRY_REAPER_MODE = $old.m }
        }
    }

    It 'only treats the exact string true as enabled' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'yes'
        try { (Get-ReaperConfig).Enabled | Should -BeFalse }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'recognises enforce case-insensitively (matches Get-PollerConfig''s own behaviour)' {
        $old = $env:AZURESENTRY_REAPER_MODE
        $env:AZURESENTRY_REAPER_MODE = 'ENFORCE'
        try { (Get-ReaperConfig).Mode | Should -Be 'enforce' }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'falls back to shadow for an unrecognised mode' {
        $old = $env:AZURESENTRY_REAPER_MODE
        $env:AZURESENTRY_REAPER_MODE = 'whatever'
        try { (Get-ReaperConfig).Mode | Should -Be 'shadow' }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default stop file path when neither the parameter nor the env var is set' {
        $old = $env:AZURESENTRY_REAPER_STOP_FILE
        Remove-Item Env:\AZURESENTRY_REAPER_STOP_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-ReaperConfig).StopFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'reaper\.stop$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_STOP_FILE = $old }
        }
    }

    # POST/DELETE /api/reaper/mode (Start-DashboardApi.ps1) write/remove exactly this
    # file -- the dashboard's Enforce Mode toggle for the reaper. Mirrors the identical
    # Get-PollerConfig coverage in TicketPollerAgent.Tests.ps1 one for one.
    It 'ignores a mode-override file that does not exist and falls back to the env var' {
        $old = $env:AZURESENTRY_REAPER_MODE
        $env:AZURESENTRY_REAPER_MODE = 'enforce'
        try {
            $missing = Join-Path $TestDrive 'no-such.mode'
            $c = Get-ReaperConfig -ModeOverrideFilePath $missing
            $c.Mode | Should -Be 'enforce'
            $c.ModeSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'an override file containing enforce wins over an env var of shadow' {
        $old = $env:AZURESENTRY_REAPER_MODE
        $env:AZURESENTRY_REAPER_MODE = 'shadow'
        try {
            $modeFile = Join-Path $TestDrive 'a.mode'
            Set-Content -LiteralPath $modeFile -Value 'enforce' -NoNewline
            $c = Get-ReaperConfig -ModeOverrideFilePath $modeFile
            $c.Mode | Should -Be 'enforce'
            $c.ModeSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'an override file containing shadow wins over an env var of enforce (the toggle can always turn enforce off)' {
        $old = $env:AZURESENTRY_REAPER_MODE
        $env:AZURESENTRY_REAPER_MODE = 'enforce'
        try {
            $modeFile = Join-Path $TestDrive 'b.mode'
            Set-Content -LiteralPath $modeFile -Value 'shadow' -NoNewline
            $c = Get-ReaperConfig -ModeOverrideFilePath $modeFile
            $c.Mode | Should -Be 'shadow'
            $c.ModeSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'an override file with unrecognised content fails closed to shadow, even with an env var of enforce' {
        $old = $env:AZURESENTRY_REAPER_MODE
        $env:AZURESENTRY_REAPER_MODE = 'enforce'
        try {
            $modeFile = Join-Path $TestDrive 'c.mode'
            Set-Content -LiteralPath $modeFile -Value 'ENFORCE-ish garbage' -NoNewline
            $c = Get-ReaperConfig -ModeOverrideFilePath $modeFile
            $c.Mode | Should -Be 'shadow'
            $c.ModeSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'trims whitespace and ignores case in the override file content' {
        $old = $env:AZURESENTRY_REAPER_MODE
        $env:AZURESENTRY_REAPER_MODE = 'shadow'
        try {
            $modeFile = Join-Path $TestDrive 'd.mode'
            Set-Content -LiteralPath $modeFile -Value "  ENFORCE`r`n" -NoNewline
            (Get-ReaperConfig -ModeOverrideFilePath $modeFile).Mode | Should -Be 'enforce'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default mode-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_REAPER_MODE_FILE
        Remove-Item Env:\AZURESENTRY_REAPER_MODE_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-ReaperConfig).ModeOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'reaper\.mode$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MODE_FILE = $old }
        }
    }

    # POST /api/reaper/enabled (Start-DashboardApi.ps1) write/remove exactly this
    # file -- the dashboard's Enabled toggle for the reaper. Mirrors the identical
    # Get-PollerConfig coverage in TicketPollerAgent.Tests.ps1 one for one.
    It 'ignores an enabled-override file that does not exist and falls back to the env var' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'true'
        try {
            $missing = Join-Path $TestDrive 'no-such.enabled'
            $c = Get-ReaperConfig -EnabledOverrideFilePath $missing
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing true wins over an env var of false' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'false'
        try {
            $enabledFile = Join-Path $TestDrive 'a.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'true' -NoNewline
            $c = Get-ReaperConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing false wins over an env var of true' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'b.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'false' -NoNewline
            $c = Get-ReaperConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file with unrecognised content fails closed to false' {
        $old = $env:AZURESENTRY_REAPER_ENABLED
        $env:AZURESENTRY_REAPER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'c.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'TRUE-ish garbage' -NoNewline
            $c = Get-ReaperConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default enabled-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_REAPER_ENABLED_FILE
        Remove-Item Env:\AZURESENTRY_REAPER_ENABLED_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-ReaperConfig).EnabledOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'reaper\.enabled$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_ENABLED_FILE = $old }
        }
    }

    It 'ignores a caps-override file that does not exist and uses the env var' {
        $old = $env:AZURESENTRY_REAPER_MAX_REVOKES
        $env:AZURESENTRY_REAPER_MAX_REVOKES = '9'
        try {
            $missing = Join-Path $TestDrive 'no-such.caps.json'
            $c = Get-ReaperConfig -CapsOverrideFilePath $missing
            $c.MaxRevokesPerCycle | Should -Be 9
            $c.MaxRevokesSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MAX_REVOKES = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MAX_REVOKES -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file overriding maxRevokes wins over the env var' {
        $old = $env:AZURESENTRY_REAPER_MAX_REVOKES
        $env:AZURESENTRY_REAPER_MAX_REVOKES = '25'
        try {
            $capsFile = Join-Path $TestDrive 'a.caps.json'
            Set-Content -LiteralPath $capsFile -Value '{"maxRevokes": 40}' -NoNewline
            $c = Get-ReaperConfig -CapsOverrideFilePath $capsFile
            $c.MaxRevokesPerCycle | Should -Be 40
            $c.MaxRevokesSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_MAX_REVOKES = $old }
            else { Remove-Item Env:\AZURESENTRY_REAPER_MAX_REVOKES -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file that is not parseable JSON at all is ignored entirely -- full fallback to env, no throw' {
        $capsFile = Join-Path $TestDrive 'broken.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{not valid json' -NoNewline
        { Get-ReaperConfig -CapsOverrideFilePath $capsFile } | Should -Not -Throw
        (Get-ReaperConfig -CapsOverrideFilePath $capsFile).MaxRevokesSource | Should -Be 'env'
    }

    It 'derives a default caps-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_REAPER_CAPS_FILE
        Remove-Item Env:\AZURESENTRY_REAPER_CAPS_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-ReaperConfig).CapsOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'reaper\.caps\.json$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_REAPER_CAPS_FILE = $old }
        }
    }
}

Describe 'Invoke-ReaperCycle' {
    It 'revokes an expired group grant and leaves a not-yet-expired one alone' {
        $store = @{
            'ME-EXPIRED' = New-RevocableGroupRecord -TicketId 'ME-EXPIRED' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
            'ME-FUTURE'  = New-RevocableGroupRecord -TicketId 'ME-FUTURE' -ExpiresAt ([datetime]::UtcNow.AddDays(5).ToString('o'))
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce'
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Revoked | Should -Be 1
        $result.Examined | Should -Be 1
        $script:RevokeCalls | Should -Contain 'ME-EXPIRED'
        $script:RevokeCalls | Should -Not -Contain 'ME-FUTURE'
        ($result.Entries | Where-Object { $_.ticketId -eq 'ME-EXPIRED' }).outcome | Should -Be 'Revoked'
    }

    It 'also reaps an expired PimFallback assignment record' {
        $store = @{
            'ME-PIM' = New-RevocableAssignmentRecord -TicketId 'ME-PIM' -ExpiresAt ([datetime]::UtcNow.AddHours(-2).ToString('o'))
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce'
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Revoked | Should -Be 1
        $script:RevokeCalls | Should -Contain 'ME-PIM'
    }

    It 'does not revoke an already-revoked record' {
        $store = @{
            'ME-DONE' = New-RevocableGroupRecord -TicketId 'ME-DONE' -ExpiresAt ([datetime]::UtcNow.AddDays(-3).ToString('o')) -Revoked $true
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce'
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Revoked | Should -Be 0
        $result.Examined | Should -Be 0
        $script:RevokeCalls.Count | Should -Be 0
    }

    It 'leaves a record with no recorded expiry alone (never guesses a deadline)' {
        $store = @{
            'ME-NOEXP' = New-RevocableGroupRecord -TicketId 'ME-NOEXP' -ExpiresAt ''
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce'
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Revoked | Should -Be 0
        $script:RevokeCalls.Count | Should -Be 0
    }

    It 'shadow mode revokes nothing -- the injected revoke hook is called zero times' {
        $store = @{
            'ME-EXPIRED' = New-RevocableGroupRecord -TicketId 'ME-EXPIRED' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
        }
        $ctx = New-ReaperContext -Store $store -Mode 'shadow'
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Revoked | Should -Be 0
        $result.WouldRevoke | Should -Be 1
        $script:RevokeCalls.Count | Should -Be 0
    }

    It 'kill switch off is a no-op, even with expired revocable grants present' {
        $store = @{
            'ME-EXPIRED' = New-RevocableGroupRecord -TicketId 'ME-EXPIRED' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce' -Enabled $false
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Halted | Should -BeTrue
        $result.HaltReason | Should -Match 'AZURESENTRY_REAPER_ENABLED'
        $result.Examined | Should -Be 0
        $script:RevokeCalls.Count | Should -Be 0
    }

    It 'honours the per-cycle revoke cap' {
        $store = @{
            'ME-A' = New-RevocableGroupRecord -TicketId 'ME-A' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
            'ME-B' = New-RevocableGroupRecord -TicketId 'ME-B' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce' -MaxRevokes 1
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Revoked | Should -Be 1
        $result.Deferred | Should -Be 1
        $script:RevokeCalls.Count | Should -Be 1
    }

    It 'fails closed: the first revoke error stops the cycle and later records are untouched' {
        $store = @{
            'ME-A' = New-RevocableGroupRecord -TicketId 'ME-A' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
            'ME-B' = New-RevocableGroupRecord -TicketId 'ME-B' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
        }
        $failingRevoke = {
            param($id, $prior)
            $script:RevokeCalls.Add([string]$id)
            if ($id -eq 'ME-A') { return @{ ok = $false; error = 'simulated Graph failure' } }
            return @{ ok = $true }
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce' -RevokeGrant $failingRevoke
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Failed | Should -Be 1
        $result.Revoked | Should -Be 0
        $result.Stopped | Should -BeTrue
        $result.Halted | Should -BeTrue
        # ME-A sorts before ME-B, so ME-A is attempted (and fails) and ME-B must never be
        # reached at all -- RevokeGrant is called exactly once.
        $script:RevokeCalls.Count | Should -Be 1
        $script:RevokeCalls | Should -Contain 'ME-A'
        $script:RevokeCalls | Should -Not -Contain 'ME-B'
    }

    It 'stops mid-cycle when the stop sentinel appears between records' {
        $stopFile = Join-Path $TestDrive 'mid-cycle.stop'
        $store = @{
            'ME-A' = New-RevocableGroupRecord -TicketId 'ME-A' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
            'ME-B' = New-RevocableGroupRecord -TicketId 'ME-B' -ExpiresAt ([datetime]::UtcNow.AddDays(-1).ToString('o'))
        }
        $dropSentinelRevoke = {
            param($id, $prior)
            $script:RevokeCalls.Add([string]$id)
            Set-Content -Path $stopFile -Value 'stop'
            @{ ok = $true }
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce' -RevokeGrant $dropSentinelRevoke -StopFilePath $stopFile
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Stopped | Should -BeTrue
        $script:RevokeCalls.Count | Should -Be 1
    }

    It 'never revokes a record that is not one this platform granted and recorded' {
        # No assignmentId and no Group+groupId -- Test-GrantRevocable must refuse this,
        # and the reaper must never guess it is safe to touch.
        $store = @{
            'ME-BOGUS' = [pscustomobject]@{
                meTicketId = 'ME-BOGUS'; role = 'Reader'; fulfilment = $null
                assignmentId = $null; groupId = $null; revoked = $false
                expiresAt = ([datetime]::UtcNow.AddDays(-1).ToString('o'))
            }
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce'
        $result = Invoke-ReaperCycle -Context $ctx

        $result.Revoked | Should -Be 0
        $script:RevokeCalls.Count | Should -Be 0
    }

    It 'enriches a revoked entry with who/what/scope/fulfilment/overdue -- not just ticketId' {
        $store = @{
            'ME-EXPIRED' = New-RevocableGroupRecord -TicketId 'ME-EXPIRED' -ExpiresAt ([datetime]::UtcNow.AddHours(-30).ToString('o'))
        }
        $ctx = New-ReaperContext -Store $store -Mode 'enforce'
        $result = Invoke-ReaperCycle -Context $ctx

        $entry = $result.Entries | Where-Object { $_.ticketId -eq 'ME-EXPIRED' }
        $entry.outcome | Should -Be 'Revoked'
        $entry.requesterUpn | Should -Be 'dev.user@contoso.com'
        $entry.role | Should -Be 'Reader'
        $entry.subscriptionId | Should -Be 'sub-1'
        $entry.scope | Should -Be '/subscriptions/sub-1'
        $entry.fulfilment | Should -Be 'Group'
        $entry.overdueHours | Should -BeGreaterOrEqual 29.9
    }

    Context 'Get-ExpiredUnrevokedCount / expiredUnrevoked (I3 -- the dangerous-state count)' {
        It 'counts an expired, unrevoked, revocable record and skips an expired-but-revoked one' {
            $now = [datetime]::UtcNow
            $store = @{
                'ME-UNREVOKED' = New-RevocableGroupRecord -TicketId 'ME-UNREVOKED' -ExpiresAt ($now.AddDays(-1).ToString('o')) -Revoked $false
                'ME-REVOKED'   = New-RevocableGroupRecord -TicketId 'ME-REVOKED' -ExpiresAt ($now.AddDays(-1).ToString('o')) -Revoked $true
            }

            (Get-ExpiredUnrevokedCount -Store $store -Now $now) | Should -Be 1
        }

        It 'excludes a record whose expiry has not yet passed' {
            $now = [datetime]::UtcNow
            $store = @{
                'ME-FUTURE' = New-RevocableGroupRecord -TicketId 'ME-FUTURE' -ExpiresAt ($now.AddDays(5).ToString('o'))
            }
            (Get-ExpiredUnrevokedCount -Store $store -Now $now) | Should -Be 0
        }

        It 'excludes a record with no recorded expiry or one this platform cannot revoke' {
            $now = [datetime]::UtcNow
            $store = @{
                'ME-NOEXP'  = New-RevocableGroupRecord -TicketId 'ME-NOEXP' -ExpiresAt ''
                'ME-BOGUS'  = [pscustomobject]@{
                    meTicketId = 'ME-BOGUS'; assignmentId = $null; groupId = $null; fulfilment = $null
                    revoked = $false; expiresAt = $now.AddDays(-1).ToString('o')
                }
            }
            (Get-ExpiredUnrevokedCount -Store $store -Now $now) | Should -Be 0
        }

        It 'is reported on Invoke-ReaperCycle''s result even when the reaper is disabled (I3/I4 -- visible, not inferred)' {
            $now = [datetime]::UtcNow
            $store = @{
                'ME-A' = New-RevocableGroupRecord -TicketId 'ME-A' -ExpiresAt ($now.AddDays(-2).ToString('o'))
                'ME-B' = New-RevocableAssignmentRecord -TicketId 'ME-B' -ExpiresAt ($now.AddHours(-3).ToString('o'))
            }
            $ctx = New-ReaperContext -Store $store -Mode 'enforce' -Enabled $false -Now $now
            $result = Invoke-ReaperCycle -Context $ctx

            $result.Halted | Should -BeTrue
            $result.expiredUnrevoked | Should -Be 2
        }

        It 'is reported on a normal shadow cycle alongside WouldRevoke' {
            $now = [datetime]::UtcNow
            $store = @{
                'ME-A' = New-RevocableGroupRecord -TicketId 'ME-A' -ExpiresAt ($now.AddDays(-1).ToString('o'))
            }
            $ctx = New-ReaperContext -Store $store -Mode 'shadow' -Now $now
            $result = Invoke-ReaperCycle -Context $ctx

            $result.expiredUnrevoked | Should -Be 1
            $result.WouldRevoke | Should -Be 1
        }
    }
}

Describe 'Resolve-ReaperStatusView (I4 -- a stale reaper must be detectable)' {

    BeforeAll {
        function New-ReaperCycleView {
            param(
                [string]$Mode = 'shadow',
                [bool]$Halted = $false,
                [string]$HaltReason = '',
                [string]$RanAt = ([datetime]::UtcNow.ToString('o')),
                [int]$ExpiredUnrevoked = 0
            )
            [pscustomobject]@{
                mode = $Mode; halted = $Halted; haltReason = $HaltReason; ranAt = $RanAt
                expiredUnrevoked = $ExpiredUnrevoked
            }
        }
    }

    It 'reports enforce/shadow from the reaper''s own last reported cycle' {
        $view = Resolve-ReaperStatusView -LastCycle (New-ReaperCycleView -Mode 'enforce')
        $view.Enabled | Should -BeTrue
        $view.Mode | Should -Be 'enforce'
        $view.Stale | Should -BeFalse
    }

    It 'reports disabled only for the specific enabled-kill-switch halt reason' {
        $view = Resolve-ReaperStatusView -LastCycle (New-ReaperCycleView -Halted $true -HaltReason 'AZURESENTRY_REAPER_ENABLED is not true.')
        $view.Enabled | Should -BeFalse
    }

    It 'reports enabled when halted for a different reason (stop sentinel)' {
        $view = Resolve-ReaperStatusView -LastCycle (New-ReaperCycleView -Halted $true -HaltReason 'Stop sentinel present at /opt/azuresentry/dashboard/api/reaper.stop.')
        $view.Enabled | Should -BeTrue
    }

    It 'reports unknown (nulls, Stale) when the reaper has never reported' {
        $view = Resolve-ReaperStatusView -LastCycle $null
        $view.Enabled | Should -BeNullOrEmpty
        $view.Stale | Should -BeTrue
    }

    It 'reports unknown rather than a confident Off for a status file older than the default staleness window' {
        # Default StaleAfterMinutes is 75 (> 2x the reaper's own 30-minute timer cadence).
        $view = Resolve-ReaperStatusView -LastCycle (New-ReaperCycleView -RanAt ([datetime]::UtcNow.AddHours(-2).ToString('o')))
        $view.Enabled | Should -BeNullOrEmpty
        $view.Stale | Should -BeTrue
    }

    It 'treats a cycle just inside the staleness window as fresh, distinct from "nothing to do"' {
        $view = Resolve-ReaperStatusView -LastCycle (New-ReaperCycleView -RanAt ([datetime]::UtcNow.AddMinutes(-40).ToString('o')))
        $view.Stale | Should -BeFalse
        $view.Enabled | Should -BeTrue
    }

    It 'reports unknown for an unparseable ranAt rather than assuming freshness' {
        $view = Resolve-ReaperStatusView -LastCycle (New-ReaperCycleView -RanAt 'not-a-date')
        $view.Stale | Should -BeTrue
        $view.Enabled | Should -BeNullOrEmpty
    }
}
