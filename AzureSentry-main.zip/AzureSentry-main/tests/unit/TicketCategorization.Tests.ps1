﻿BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\LlmClient.ps1')
    . (Join-Path $repoRoot 'src\Agents\TicketCategorizationAgent.ps1')

    function New-InfraTicket {
        param([string]$Id, [string]$Subject, [string]$Description = '', [string]$TicketType = 'Infrastructure')
        [pscustomobject]@{
            id = $Id; subject = $Subject; description = $Description
            department = 'Infrastructure'; ticketType = $TicketType
        }
    }
}

Describe 'Get-RuleBasedWorkType — FR4 deterministic classification' {

    It 'recognises app registration requests' {
        (Get-RuleBasedWorkType -Text 'Please create an app registration for the billing service').WorkType |
            Should -Be 'AppRegistration'
    }

    It 'recognises client secret requests' {
        (Get-RuleBasedWorkType -Text 'Our client secret expired, need a new secret').WorkType |
            Should -Be 'ClientSecret'
    }

    It 'prefers ClientSecret over AppRegistration when the ask is the credential' {
        # A secret on an existing app registration is a ClientSecret ticket.
        (Get-RuleBasedWorkType -Text 'Add a client secret to the existing app registration').WorkType |
            Should -Be 'ClientSecret'
    }

    It 'recognises RBAC / access grants' {
        (Get-RuleBasedWorkType -Text 'Need Contributor access to the subscription').WorkType | Should -Be 'AccessGrant'
        (Get-RuleBasedWorkType -Text 'Grant me PIM eligibility for Reader').WorkType | Should -Be 'AccessGrant'
    }

    It 'recognises group membership changes' {
        (Get-RuleBasedWorkType -Text 'Please add me to the sg-payments-contributors group').WorkType |
            Should -Be 'GroupMembership'
    }

    It 'recognises resource provisioning and quota requests' {
        (Get-RuleBasedWorkType -Text 'Create a resource group for project atlas').WorkType | Should -Be 'ResourceProvisioning'
        (Get-RuleBasedWorkType -Text 'Please increase the vCPU quota in uaenorth').WorkType | Should -Be 'QuotaIncrease'
    }

    It 'routes networking work to the out-of-scope bucket' {
        (Get-RuleBasedWorkType -Text 'Open a port on the NSG for the web tier').WorkType | Should -Be 'NetworkChange'
    }

    It 'classifies a broken-system report as troubleshooting' {
        (Get-RuleBasedWorkType -Text 'The VM is not working and users cannot log in').WorkType | Should -Be 'Troubleshooting'
    }

    It 'classifies a question as advisory' {
        (Get-RuleBasedWorkType -Text 'How do I request access to a subscription?').WorkType | Should -Be 'Advisory'
    }

    It 'returns Unclassified at zero confidence when nothing matches' {
        $r = Get-RuleBasedWorkType -Text 'Miscellaneous request'
        $r.WorkType | Should -Be 'Unclassified'
        $r.Confidence | Should -Be 0.0
    }

    It 'handles empty text' {
        (Get-RuleBasedWorkType -Text '').WorkType | Should -Be 'Unclassified'
    }
}

Describe 'Get-WorkTypeCatalog — actionability contract' {

    It 'marks the three work types named in the review as actionable' {
        $catalog = @{}
        foreach ($c in Get-WorkTypeCatalog) { $catalog[$c.Key] = $c }
        $catalog['AppRegistration'].Actionable | Should -BeTrue
        $catalog['ClientSecret'].Actionable | Should -BeTrue
        $catalog['AccessGrant'].Actionable | Should -BeTrue
    }

    It 'requires a human audit for anything that mints a credential' {
        $catalog = @{}
        foreach ($c in Get-WorkTypeCatalog) { $catalog[$c.Key] = $c }
        $catalog['ClientSecret'].HumanAudit | Should -BeTrue
        $catalog['AppRegistration'].HumanAudit | Should -BeTrue
    }

    It 'keeps out-of-scope work non-actionable' {
        $catalog = @{}
        foreach ($c in Get-WorkTypeCatalog) { $catalog[$c.Key] = $c }
        $catalog['NetworkChange'].Actionable | Should -BeFalse
        $catalog['Troubleshooting'].Actionable | Should -BeFalse
        $catalog['Advisory'].Actionable | Should -BeFalse
    }
}

Describe 'Invoke-TicketCategorizationAgent — the actionability report' {

    BeforeAll {
        $script:Report = Invoke-TicketCategorizationAgent -NoLlm -Tickets @(
            New-InfraTicket -Id '1' -Subject 'Create an app registration for reporting'
            New-InfraTicket -Id '2' -Subject 'Client secret is expiring next week'
            New-InfraTicket -Id '3' -Subject 'Need Contributor access on the sandbox subscription'
            New-InfraTicket -Id '4' -Subject 'Add me to the sg-data-readers group'
            New-InfraTicket -Id '5' -Subject 'Open a firewall port for the API'
            New-InfraTicket -Id '6' -Subject 'The build agent VM is down'
            New-InfraTicket -Id '7' -Subject 'Random unrelated request text'
        )
    }

    It 'classifies every ticket exactly once' {
        @($script:Report.Results).Count | Should -Be 7
        @($script:Report.Results.id | Sort-Object) | Should -Be @('1', '2', '3', '4', '5', '6', '7')
    }

    It 'counts how much of the queue an agent could action' {
        # 1,2,3,4 actionable; 5,6 out of scope; 7 unclassified.
        $script:Report.Summary.actionable | Should -Be 4
        $script:Report.Summary.notActionable | Should -Be 3
    }

    It 'reports an actionable rate for the scope decision' {
        $script:Report.Summary.actionableRate | Should -BeGreaterThan 0.5
    }

    It 'separates fully automatable work from work needing a human audit' {
        # All four actionable rows here are deterministic keyword matches, so the standing
        # audit posture is cleared on each and none is held for a human read.
        $script:Report.Summary.actionableFullyAuto | Should -Be 4
        $script:Report.Summary.actionableWithAudit | Should -Be 0
    }

    It 'keeps the cleared audit attributable rather than silently dropping it' {
        # AppRegistration + ClientSecret carry a standing audit posture; the report still
        # says so via policyHumanAudit and counts what the keyword match cleared.
        $script:Report.Summary.actionableWithAuditByPolicy | Should -Be 2
        $script:Report.Summary.auditClearedByKeyword | Should -Be 2
    }

    It 'breaks the queue down by work type' {
        $script:Report.Summary.byWorkType.AppRegistration | Should -Be 1
        $script:Report.Summary.byWorkType.ClientSecret | Should -Be 1
        $script:Report.Summary.byWorkType.AccessGrant | Should -Be 1
        $script:Report.Summary.byWorkType.NetworkChange | Should -Be 1
    }

    It 'reports what it could not place instead of forcing a fit' {
        $script:Report.Summary.unclassified | Should -Be 1
    }

    It 'attributes every row to rules or inference' {
        foreach ($row in $script:Report.Results) {
            $row.source | Should -BeIn @('Rules', 'Llm')
            $row.rationale | Should -Not -BeNullOrEmpty
        }
    }

    It 'marks nothing as inferred when the LLM is skipped' {
        @($script:Report.Results | Where-Object { $_.inferred }).Count | Should -Be 0
        $script:Report.LlmUsed | Should -BeFalse
    }

    It 'carries the actionability flags through onto each row' {
        $appReg = @($script:Report.Results | Where-Object { $_.id -eq '1' })[0]
        $appReg.actionable | Should -BeTrue
        $appReg.displayName | Should -Be 'App registration creation'
        # Cleared for this row by the keyword match, but the work type's standing posture
        # is still recorded — a write path must read policyHumanAudit, not humanAudit.
        $appReg.keywordMatch | Should -BeTrue
        $appReg.humanAudit | Should -BeFalse
        $appReg.policyHumanAudit | Should -BeTrue
    }

    It 'leaves the work-type catalog itself as the untouched policy reference' {
        $catalog = @{}
        foreach ($c in Get-WorkTypeCatalog) { $catalog[$c.Key] = $c }
        $catalog['ClientSecret'].HumanAudit | Should -BeTrue
        $catalog['AppRegistration'].HumanAudit | Should -BeTrue
    }

    It 'stamps the report with a generation time' {
        $script:Report.GeneratedAt | Should -Not -BeNullOrEmpty
    }
}
