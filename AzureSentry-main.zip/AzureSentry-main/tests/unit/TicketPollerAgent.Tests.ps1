BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\MeTicketMapper.ps1')
    . (Join-Path $repoRoot 'src\Agents\PollerGate.ps1')
    . (Join-Path $repoRoot 'src\Agents\TicketPollerAgent.ps1')
    # Resolve-MeTicketMapping (called inside TicketPollerAgent's cycle) now confirms a
    # role via Get-RoleCatalogEntry -- see the identical comment in MeTicketMapper.Tests.ps1.
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

    $script:Allowlist = @(
        [pscustomobject]@{ id = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'; name = 'inception-ai-Sandbox' }
    )

    function New-PollTicket {
        param(
            [string]$Id = '9001',
            [string]$Role = 'Reader',
            [string]$Env = 'Sandbox',
            [string]$Sub = 'inception-ai-Sandbox',
            [string]$Created = '',
            [string]$Email = 'dev.user@contoso.com'
        )
        $createdMs = if ($Created) {
            [string][int64](([datetime]$Created).ToUniversalTime() - [datetime]'1970-01-01').TotalMilliseconds
        } else {
            [string][int64](([datetime]::UtcNow.AddDays(-1)) - [datetime]'1970-01-01').TotalMilliseconds
        }
        [pscustomobject]@{
            id = $Id; subject = "Access request $Id"
            requester = [pscustomobject]@{ email_id = $Email }
            priority = [pscustomobject]@{ name = 'P3' }
            created_time = [pscustomobject]@{ value = $createdMs }
            description = 'please grant'
            _role = $Role; _env = $Env; _sub = $Sub
        }
    }

    function New-PollContext {
        param(
            [object[]]$Tickets = @(),
            [string]$Mode = 'shadow',
            [bool]$Enabled = $true,
            [int]$MaxGrants = 5,
            [int]$MaxTickets = 25,
            [string]$DecisionAction = 'Grant',
            [string]$EffectiveEnv = 'Sandbox',
            [scriptblock]$ExecuteGrant = $null,
            [string]$StopFilePath = '',
            [int]$DurationDays = 0
        )
        $script:Granted = [System.Collections.Generic.List[string]]::new()
        $script:Recorded = [System.Collections.Generic.List[string]]::new()
        @{
            # .GetNewClosure() is required here: a scriptblock defined inside a function does
            # not retain access to that function's local parameters once the function returns
            # (PowerShell resolves scriptblock scope dynamically at invocation, not lexically
            # at definition). Without it, $Tickets/$DecisionAction/$EffectiveEnv would resolve
            # to nothing when Invoke-TicketPollerCycle invokes these later.
            FetchTickets      = { param() $Tickets }.GetNewClosure()
            GetAccessFields   = { param($t) [ordered]@{ Subscription = $t._sub; AzureRole = $t._role; Environment = $t._env } }
            IsTemplateAllowed = { param($t) $true }
            Decide            = { param($ticket) [pscustomobject]@{ Action = $DecisionAction; EffectiveEnvironment = $EffectiveEnv; Path = 'test'; Reason = 'test' } }.GetNewClosure()
            AllowlistDetails  = $script:Allowlist
            ExecuteGrant      = if ($ExecuteGrant) { $ExecuteGrant } else {
                { param($ticket) $script:Granted.Add([string]$ticket.TicketId); @{ ok = $true; assignmentId = "a-$($ticket.TicketId)" } }
            }
            IsProcessed       = { param($id) $false }
            RecordProcessed   = { param($id, $entry) $script:Recorded.Add([string]$id) }
            Config            = [pscustomobject]@{
                Enabled = $Enabled; Mode = $Mode
                MaxTicketsPerCycle = $MaxTickets; MaxGrantsPerCycle = $MaxGrants
                MaxTicketAgeDays = 7; StopFilePath = $StopFilePath
            }
            # 0 (the parameter default) is falsy, so the agent's own fallback of 7 applies
            # unless a test explicitly passes -DurationDays -- matches how a real Context
            # built with no config.json wired never sets this key at all (I1).
            DurationDays      = $DurationDays
            Now               = [datetime]::UtcNow
        }
    }
}

Describe 'Get-PollerConfig' {
    It 'is disabled and in shadow mode unless explicitly told otherwise' {
        $old = @{ e = $env:AZURESENTRY_POLLER_ENABLED; m = $env:AZURESENTRY_POLLER_MODE }
        try {
            Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue
            Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue
            $c = Get-PollerConfig
            $c.Enabled | Should -BeFalse
            $c.Mode | Should -Be 'shadow'
        }
        finally {
            if ($old.e) { $env:AZURESENTRY_POLLER_ENABLED = $old.e }
            if ($old.m) { $env:AZURESENTRY_POLLER_MODE = $old.m }
        }
    }

    It 'defaults MaxTicketsPerCycle to at least the ME fetch size, not the old 25 (I2)' {
        # MaxGrantsPerCycle is the real blast-radius bound; MaxTicketsPerCycle is only a
        # runaway guard and must not starve the queue below what one fetch can return.
        $old = $env:AZURESENTRY_POLLER_MAX_TICKETS
        Remove-Item Env:\AZURESENTRY_POLLER_MAX_TICKETS -ErrorAction SilentlyContinue
        try {
            (Get-PollerConfig).MaxTicketsPerCycle | Should -BeGreaterOrEqual 100
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MAX_TICKETS = $old }
        }
    }

    It 'only treats the exact string true as enabled' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'yes'
        try { (Get-PollerConfig).Enabled | Should -BeFalse }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'only treats the exact string enforce as enforce' {
        $old = $env:AZURESENTRY_POLLER_MODE
        $env:AZURESENTRY_POLLER_MODE = 'ENFORCE'
        try { (Get-PollerConfig).Mode | Should -Be 'enforce' }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'falls back to shadow for an unrecognised mode' {
        $old = $env:AZURESENTRY_POLLER_MODE
        $env:AZURESENTRY_POLLER_MODE = 'whatever'
        try { (Get-PollerConfig).Mode | Should -Be 'shadow' }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'honours AZURESENTRY_POLLER_STOP_FILE when no explicit -StopFilePath is given' {
        $old = $env:AZURESENTRY_POLLER_STOP_FILE
        $envStop = Join-Path $TestDrive 'from-env.stop'
        $env:AZURESENTRY_POLLER_STOP_FILE = $envStop
        try { (Get-PollerConfig).StopFilePath | Should -Be $envStop }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_STOP_FILE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_STOP_FILE -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default stop file path when neither the parameter nor the env var is set' {
        # The documented "drop a poller.stop file, halt the cycle, no config edit needed"
        # promise must hold out of the box -- a mis-wired caller that never passes
        # -StopFilePath must still end up with a real, non-empty kill-file path.
        $old = $env:AZURESENTRY_POLLER_STOP_FILE
        Remove-Item Env:\AZURESENTRY_POLLER_STOP_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-PollerConfig).StopFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'poller\.stop$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_STOP_FILE = $old }
        }
    }

    It 'lets an explicit -StopFilePath override the env var' {
        $old = $env:AZURESENTRY_POLLER_STOP_FILE
        $env:AZURESENTRY_POLLER_STOP_FILE = Join-Path $TestDrive 'from-env.stop'
        try {
            $explicit = Join-Path $TestDrive 'explicit.stop'
            (Get-PollerConfig -StopFilePath $explicit).StopFilePath | Should -Be $explicit
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_STOP_FILE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_STOP_FILE -ErrorAction SilentlyContinue }
        }
    }

    # POST/DELETE /api/poller/mode (Start-DashboardApi.ps1) write/remove exactly this
    # file -- the dashboard's Enforce Mode toggle. No env var round-tripping needed here
    # (unlike the tests above): -ModeOverrideFilePath is always passed explicitly by both
    # real callers (scripts/Invoke-TicketPollerCycle.ps1 and the dashboard), so these
    # tests exercise the parameter directly.
    It 'ignores a mode-override file that does not exist and falls back to the env var' {
        $old = $env:AZURESENTRY_POLLER_MODE
        $env:AZURESENTRY_POLLER_MODE = 'enforce'
        try {
            $missing = Join-Path $TestDrive 'no-such.mode'
            $c = Get-PollerConfig -ModeOverrideFilePath $missing
            $c.Mode | Should -Be 'enforce'
            $c.ModeSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'an override file containing enforce wins over an env var of shadow' {
        $old = $env:AZURESENTRY_POLLER_MODE
        $env:AZURESENTRY_POLLER_MODE = 'shadow'
        try {
            $modeFile = Join-Path $TestDrive 'a.mode'
            Set-Content -LiteralPath $modeFile -Value 'enforce' -NoNewline
            $c = Get-PollerConfig -ModeOverrideFilePath $modeFile
            $c.Mode | Should -Be 'enforce'
            $c.ModeSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'an override file containing shadow wins over an env var of enforce (the toggle can always turn enforce off)' {
        $old = $env:AZURESENTRY_POLLER_MODE
        $env:AZURESENTRY_POLLER_MODE = 'enforce'
        try {
            $modeFile = Join-Path $TestDrive 'b.mode'
            Set-Content -LiteralPath $modeFile -Value 'shadow' -NoNewline
            $c = Get-PollerConfig -ModeOverrideFilePath $modeFile
            $c.Mode | Should -Be 'shadow'
            $c.ModeSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'an override file with unrecognised content fails closed to shadow, even with an env var of enforce' {
        # Same fail-closed contract as the env var itself (see 'falls back to shadow for
        # an unrecognised mode' above) -- a corrupted or half-written override file must
        # never be silently read as enforce, and must never fall through to trusting the
        # environment variable instead (that would defeat the point of an explicit
        # Turn Enforce OFF action: it must always win, even over a garbled file).
        $old = $env:AZURESENTRY_POLLER_MODE
        $env:AZURESENTRY_POLLER_MODE = 'enforce'
        try {
            $modeFile = Join-Path $TestDrive 'c.mode'
            Set-Content -LiteralPath $modeFile -Value 'ENFORCE-ish garbage' -NoNewline
            $c = Get-PollerConfig -ModeOverrideFilePath $modeFile
            $c.Mode | Should -Be 'shadow'
            $c.ModeSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'trims whitespace and ignores case in the override file content' {
        $old = $env:AZURESENTRY_POLLER_MODE
        $env:AZURESENTRY_POLLER_MODE = 'shadow'
        try {
            $modeFile = Join-Path $TestDrive 'd.mode'
            Set-Content -LiteralPath $modeFile -Value "  ENFORCE`r`n" -NoNewline
            (Get-PollerConfig -ModeOverrideFilePath $modeFile).Mode | Should -Be 'enforce'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default mode-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_POLLER_MODE_FILE
        Remove-Item Env:\AZURESENTRY_POLLER_MODE_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-PollerConfig).ModeOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'poller\.mode$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MODE_FILE = $old }
        }
    }

    # POST/DELETE /api/poller/enabled (Start-DashboardApi.ps1, Task 3) write/remove
    # exactly this file. Mirrors the -ModeOverrideFilePath tests above exactly.
    It 'ignores an enabled-override file that does not exist and falls back to the env var' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'true'
        try {
            $missing = Join-Path $TestDrive 'no-such.enabled'
            $c = Get-PollerConfig -EnabledOverrideFilePath $missing
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing true wins over an env var of false' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'false'
        try {
            $enabledFile = Join-Path $TestDrive 'a.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'true' -NoNewline
            $c = Get-PollerConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeTrue
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file containing false wins over an env var of true (the toggle can always turn automation off)' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'b.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'false' -NoNewline
            $c = Get-PollerConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'an enabled-override file with unrecognised content fails closed to false, even with an env var of true' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'true'
        try {
            $enabledFile = Join-Path $TestDrive 'c.enabled'
            Set-Content -LiteralPath $enabledFile -Value 'TRUE-ish garbage' -NoNewline
            $c = Get-PollerConfig -EnabledOverrideFilePath $enabledFile
            $c.Enabled | Should -BeFalse
            $c.EnabledSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'trims whitespace and ignores case in the enabled-override file content' {
        $old = $env:AZURESENTRY_POLLER_ENABLED
        $env:AZURESENTRY_POLLER_ENABLED = 'false'
        try {
            $enabledFile = Join-Path $TestDrive 'd.enabled'
            Set-Content -LiteralPath $enabledFile -Value "  TRUE`r`n" -NoNewline
            (Get-PollerConfig -EnabledOverrideFilePath $enabledFile).Enabled | Should -BeTrue
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
        }
    }

    It 'derives a default enabled-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_POLLER_ENABLED_FILE
        Remove-Item Env:\AZURESENTRY_POLLER_ENABLED_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-PollerConfig).EnabledOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'poller\.enabled$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_ENABLED_FILE = $old }
        }
    }

    # POST/DELETE /api/poller/caps (Start-DashboardApi.ps1, Task 3) write/remove this file.
    It 'ignores a caps-override file that does not exist and uses the env vars for all three fields' {
        $old = $env:AZURESENTRY_POLLER_MAX_GRANTS
        $env:AZURESENTRY_POLLER_MAX_GRANTS = '9'
        try {
            $missing = Join-Path $TestDrive 'no-such.caps.json'
            $c = Get-PollerConfig -CapsOverrideFilePath $missing
            $c.MaxGrantsPerCycle | Should -Be 9
            $c.MaxGrantsSource | Should -Be 'env'
            $c.MaxTicketsPerCycle | Should -Be 100
            $c.MaxTicketsSource | Should -Be 'env'
            $c.MaxTicketAgeDays | Should -Be 7
            $c.MaxAgeDaysSource | Should -Be 'env'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MAX_GRANTS = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MAX_GRANTS -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file overriding only maxGrants leaves maxTickets and maxAgeDays reading from env, independently' {
        $capsFile = Join-Path $TestDrive 'partial.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{"maxGrants": 20}' -NoNewline
        $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
        $c.MaxGrantsPerCycle | Should -Be 20
        $c.MaxGrantsSource | Should -Be 'override'
        $c.MaxTicketsPerCycle | Should -Be 100
        $c.MaxTicketsSource | Should -Be 'env'
        $c.MaxTicketAgeDays | Should -Be 7
        $c.MaxAgeDaysSource | Should -Be 'env'
    }

    It 'a caps file overriding all three fields wins for all three, independently of env' {
        $old = $env:AZURESENTRY_POLLER_MAX_GRANTS
        $env:AZURESENTRY_POLLER_MAX_GRANTS = '5'
        try {
            $capsFile = Join-Path $TestDrive 'full.caps.json'
            Set-Content -LiteralPath $capsFile -Value '{"maxGrants": 12, "maxTickets": 50, "maxAgeDays": 3}' -NoNewline
            $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
            $c.MaxGrantsPerCycle | Should -Be 12
            $c.MaxTicketsPerCycle | Should -Be 50
            $c.MaxTicketAgeDays | Should -Be 3
            $c.MaxGrantsSource | Should -Be 'override'
            $c.MaxTicketsSource | Should -Be 'override'
            $c.MaxAgeDaysSource | Should -Be 'override'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_MAX_GRANTS = $old }
            else { Remove-Item Env:\AZURESENTRY_POLLER_MAX_GRANTS -ErrorAction SilentlyContinue }
        }
    }

    It 'a caps file that is not parseable JSON at all is ignored entirely -- full fallback to env, no throw' {
        $capsFile = Join-Path $TestDrive 'broken.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{not valid json' -NoNewline
        { Get-PollerConfig -CapsOverrideFilePath $capsFile } | Should -Not -Throw
        $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
        $c.MaxGrantsPerCycle | Should -Be 5
        $c.MaxGrantsSource | Should -Be 'env'
    }

    It 'a caps file with a non-positive-integer value for one key falls back to env for that key only' {
        $capsFile = Join-Path $TestDrive 'bad-value.caps.json'
        Set-Content -LiteralPath $capsFile -Value '{"maxGrants": 0, "maxTickets": 30}' -NoNewline
        $c = Get-PollerConfig -CapsOverrideFilePath $capsFile
        $c.MaxGrantsPerCycle | Should -Be 5
        $c.MaxGrantsSource | Should -Be 'env'
        $c.MaxTicketsPerCycle | Should -Be 30
        $c.MaxTicketsSource | Should -Be 'override'
    }

    It 'derives a default caps-override file path next to the default stop file when neither is set' {
        $old = $env:AZURESENTRY_POLLER_CAPS_FILE
        Remove-Item Env:\AZURESENTRY_POLLER_CAPS_FILE -ErrorAction SilentlyContinue
        try {
            $path = (Get-PollerConfig).CapsOverrideFilePath
            $path | Should -Not -BeNullOrEmpty
            $path | Should -Match 'poller\.caps\.json$'
        }
        finally {
            if ($null -ne $old) { $env:AZURESENTRY_POLLER_CAPS_FILE = $old }
        }
    }
}

Describe 'Get-MeTicketCreatedUtc' {
    It 'parses created_time wrapped in a Hashtable, not just a PSCustomObject' {
        # ConvertFrom-Json -AsHashtable (used by some pwsh 7 callers) wraps created_time as
        # a Hashtable, whose adapted properties are Keys/Values/Count -- not 'value'.
        # Checking only PSObject.Properties misses this shape and every ticket silently
        # reads as unparseable and gets dropped with no explanation.
        $ms = [string][int64](([datetime]::UtcNow.AddDays(-1)) - [datetime]'1970-01-01').TotalMilliseconds
        $t = [pscustomobject]@{ id = 'ht-1'; created_time = @{ value = $ms } }
        $result = Get-MeTicketCreatedUtc -MeTicket $t
        $result | Should -Not -BeNullOrEmpty
        $result.Year | Should -Be ([datetime]::UtcNow.Year)
    }

    It 'returns $null rather than throwing for an epoch value that overflows DateTime' {
        # Epoch microseconds (or nanoseconds) parse fine as an int64 but overflow
        # AddMilliseconds, which throws ArgumentOutOfRangeException if unguarded.
        $t = [pscustomobject]@{ id = 'overflow-1'; created_time = [pscustomobject]@{ value = '1755000000000000' } }
        { Get-MeTicketCreatedUtc -MeTicket $t } | Should -Not -Throw
        Get-MeTicketCreatedUtc -MeTicket $t | Should -BeNullOrEmpty
    }
}

Describe 'Test-PollerTicketInWindow' {
    It 'accepts a recent ticket' {
        $t = New-PollTicket -Created ([datetime]::UtcNow.AddDays(-2).ToString('o'))
        Test-PollerTicketInWindow -MeTicket $t -MaxAgeDays 7 -Now ([datetime]::UtcNow) | Should -BeTrue
    }

    It 'rejects a ticket older than the window so a first run cannot stampede the backlog' {
        $t = New-PollTicket -Created ([datetime]::UtcNow.AddDays(-40).ToString('o'))
        Test-PollerTicketInWindow -MeTicket $t -MaxAgeDays 7 -Now ([datetime]::UtcNow) | Should -BeFalse
    }

    It 'rejects a ticket with no parseable created_time rather than treating it as new' {
        $t = New-PollTicket
        $t.created_time = $null
        Test-PollerTicketInWindow -MeTicket $t -MaxAgeDays 7 -Now ([datetime]::UtcNow) | Should -BeFalse
    }

    It 'rejects a ticket dated far in the future rather than treating clock skew as safe' {
        # The window exists to fail closed on cold start. A past-side-only check fails
        # OPEN in this direction: a single clock-skewed or corrupt created_time would
        # otherwise bypass the window forever, since "in the future" never ages out.
        $t = New-PollTicket -Created ([datetime]::UtcNow.AddYears(50).ToString('o'))
        Test-PollerTicketInWindow -MeTicket $t -MaxAgeDays 7 -Now ([datetime]::UtcNow) | Should -BeFalse
    }
}

Describe 'Invoke-TicketPollerCycle -- shadow mode' {

    It 'does nothing at all when the kill switch is off' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Enabled $false
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Halted | Should -BeTrue
        $r.Examined | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'halts when the stop sentinel file exists' {
        $stop = Join-Path $TestDrive 'poller.stop'
        Set-Content -Path $stop -Value 'halt' -Encoding UTF8
        $ctx = New-PollContext -Tickets @(New-PollTicket) -StopFilePath $stop
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Halted | Should -BeTrue
        $script:Granted.Count | Should -Be 0
    }

    It 'reports wouldGrant and writes nothing in shadow mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '1'), (New-PollTicket -Id '2')
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Mode | Should -Be 'shadow'
        $r.WouldGrant | Should -Be 2
        $r.Granted | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'never uses the word skipped in an entry outcome' {
        # The environment backfill reported a successful dry run as "N skipped", which read
        # as failure and cost real debugging time. Shadow says WouldGrant.
        $ctx = New-PollContext -Tickets @(New-PollTicket)
        $r = Invoke-TicketPollerCycle -Context $ctx
        ($r.Entries | ForEach-Object { $_.outcome }) -join ' ' | Should -Not -Match 'skip'
        $r.Entries[0].outcome | Should -Be 'WouldGrant'
    }

    It 'does not record a processed entry in shadow mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket)
        Invoke-TicketPollerCycle -Context $ctx | Out-Null
        $script:Recorded.Count | Should -Be 0
    }

    It 'queues a Production decision instead of granting' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -EffectiveEnv 'Production'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 0
        $r.Queued | Should -Be 1
        $r.Entries[0].outcome | Should -Be 'Queued'
        $r.Entries[0].reason | Should -Match 'Production'
    }

    It 'queues an Eligible decision instead of granting' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -DecisionAction 'Eligible'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 0
        $r.Queued | Should -Be 1
    }

    It 'queues a ticket whose environment dropdown is blank' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Env '')
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Queued | Should -Be 1
        $r.Entries[0].reason | Should -Match 'Environment'
    }

    It 'queues a ticket whose subscription is not allowlisted' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Sub 'not-allowlisted-sub')
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Queued | Should -Be 1
        $r.Entries[0].reason | Should -Match 'allowlist'
    }

    It 'skips a ticket already in the processed store' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '55')
        $ctx.IsProcessed = { param($id) $true }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 0
        $r.WouldGrant | Should -Be 0
    }

    It 'honours MaxTicketsPerCycle' {
        $many = 1..10 | ForEach-Object { New-PollTicket -Id "$_" }
        $ctx = New-PollContext -Tickets $many -MaxTickets 4
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 4
    }

    It 'examines tickets beyond the old 25-ticket cap when the cap is raised (I2)' {
        # Regression guard: with the old default of 25, ticket #26+ in a 30-ticket fetch
        # was never examined, in ANY cycle -- queued tickets are never recorded as
        # processed, so they are re-skipped forever rather than reached on a later cycle.
        $many = 1..30 | ForEach-Object { New-PollTicket -Id "starve-$_" }
        $ctx = New-PollContext -Tickets $many -MaxTickets 100
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 30
        ($r.Entries | Where-Object { $_.ticketId -eq 'starve-26' }) | Should -Not -BeNullOrEmpty
        ($r.Entries | Where-Object { $_.ticketId -eq 'starve-30' }) | Should -Not -BeNullOrEmpty
    }

    It 'stamps a run id on the cycle' {
        $r = Invoke-TicketPollerCycle -Context (New-PollContext -Tickets @(New-PollTicket))
        $r.RunId | Should -Not -BeNullOrEmpty
    }

    It 'excludes a ticket older than the age window from the cycle entirely' {
        # Regression guard for the cold-start protection: a ticket outside the window must
        # not be examined, must not appear in Entries, and must not grant -- Examined only
        # counting in-window tickets is what keeps a first run from stampeding the backlog.
        $old = New-PollTicket -Id 'old-1' -Created ([datetime]::UtcNow.AddDays(-40).ToString('o'))
        $ctx = New-PollContext -Tickets @($old)
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 0
        $r.WouldGrant | Should -Be 0
        $r.Entries.Count | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }
}

Describe 'Invoke-TicketPollerCycle -- fail-safe behaviour' {

    It 'survives a malformed created_time (epoch microseconds) without aborting the cycle' {
        # Reviewer repro: SDP occasionally emits created_time in epoch microseconds instead
        # of milliseconds. Unguarded, AddMilliseconds throws ArgumentOutOfRangeException on
        # a value this large, which used to abort the whole cycle with no result object at
        # all -- tickets before and after the bad one were silently never reported.
        $bad = New-PollTicket -Id 'bad-2'
        $bad.created_time = [pscustomobject]@{ value = '1755000000000000' }
        $tickets = @((New-PollTicket -Id '1'), $bad, (New-PollTicket -Id '3'))
        $ctx = New-PollContext -Tickets $tickets
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Halted | Should -BeFalse
        $r.Examined | Should -Be 2
        ($r.Entries | Where-Object { $_.ticketId -eq '1' }) | Should -Not -BeNullOrEmpty
        ($r.Entries | Where-Object { $_.ticketId -eq '3' }) | Should -Not -BeNullOrEmpty
        ($r.Entries | Where-Object { $_.ticketId -eq 'bad-2' }) | Should -BeNullOrEmpty
    }

    It 'caps wouldGrant at MaxGrantsPerCycle in shadow mode, matching what enforce would grant' {
        # Before the fix, the cap compared only $tally.Granted, which shadow never
        # increments -- so shadow reported wouldGrant for ALL eligible tickets regardless
        # of the cap. An operator reviewing a shadow run must see the same blast radius
        # enforce would actually produce, or the preview is worthless.
        $many = 1..10 | ForEach-Object { New-PollTicket -Id "cap-$_" }
        $ctx = New-PollContext -Tickets $many -MaxGrants 3
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 3
        $r.Queued | Should -Be 7
        $capped = @($r.Entries | Where-Object { $_.outcome -eq 'Queued' })
        $capped.Count | Should -Be 7
        foreach ($entry in $capped) { $entry.reason | Should -Match 'cap' }
    }

    It 'counts a throwing Decide as Failed and stops, without the exception escaping the cycle' {
        $ctx = New-PollContext -Tickets @((New-PollTicket -Id '1'), (New-PollTicket -Id '2'))
        $ctx.Decide = { param($ticket) throw 'boom: decision engine exploded' }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r | Should -Not -BeNullOrEmpty
        $r.Failed | Should -Be 1
        $r.Stopped | Should -BeTrue
        $r.Entries[0].outcome | Should -Be 'Failed'
    }

    It 'stops processing later tickets when the stop sentinel appears mid-cycle' {
        $stop = Join-Path $TestDrive 'poller-midcycle.stop'
        $tickets = @((New-PollTicket -Id '1'), (New-PollTicket -Id '2'), (New-PollTicket -Id '3'))
        $ctx = New-PollContext -Tickets $tickets -StopFilePath $stop
        # Side effect: the sentinel appears the moment the first ticket is decided,
        # simulating an operator dropping poller.stop while the cycle is already running.
        $ctx.Decide = {
            param($ticket)
            if ($ticket.TicketId -eq '1') { Set-Content -Path $stop -Value 'halt' -Encoding UTF8 }
            [pscustomobject]@{ Action = 'Grant'; EffectiveEnvironment = 'Sandbox'; Path = 'test'; Reason = 'test' }
        }.GetNewClosure()
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 1
        $r.Stopped | Should -BeTrue
        ($r.Entries | Where-Object { $_.ticketId -eq '2' }) | Should -BeNullOrEmpty
        ($r.Entries | Where-Object { $_.ticketId -eq '3' }) | Should -BeNullOrEmpty
    }
}

Describe 'Invoke-TicketPollerCycle -- enforce mode' {

    BeforeAll {
        . (Join-Path $repoRoot 'dashboard\api\ProcessedStore.ps1')
    }

    BeforeEach {
        $script:EnforceStore = Join-Path $TestDrive "enforce-$([guid]::NewGuid().ToString('N')).json"
        Initialize-ProcessedStore -Path $script:EnforceStore
    }

    It 'executes the grant and records it' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '77') -Mode 'enforce'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
        $r.WouldGrant | Should -Be 0
        $script:Granted | Should -Contain '77'
        $r.Entries[0].outcome | Should -Be 'Granted'
        $r.Entries[0].applied | Should -BeTrue
    }

    It 'stops at the first failure instead of continuing to the next ticket' {
        $ctx = New-PollContext -Tickets @(
            (New-PollTicket -Id 'a'), (New-PollTicket -Id 'b'), (New-PollTicket -Id 'c')
        ) -Mode 'enforce' -ExecuteGrant { param($ticket) @{ ok = $false; error = 'ARM returned 403' } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Failed | Should -Be 1
        $r.Stopped | Should -BeTrue
        $r.Granted | Should -Be 0
        # b and c must not have been attempted.
        @($r.Entries).Count | Should -Be 1
    }

    It 'treats a thrown exception from the grant as a failure and stops' {
        $ctx = New-PollContext -Tickets @((New-PollTicket -Id 'x'), (New-PollTicket -Id 'y')) `
            -Mode 'enforce' -ExecuteGrant { param($ticket) throw 'token expired' }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Failed | Should -Be 1
        $r.Stopped | Should -BeTrue
        $r.Entries[0].reason | Should -Match 'token expired'
    }

    It 'stops granting once the per-cycle cap is hit and defers the rest' {
        $many = 1..6 | ForEach-Object { New-PollTicket -Id "cap$_" }
        $ctx = New-PollContext -Tickets $many -Mode 'enforce' -MaxGrants 2
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 2
        $r.Queued | Should -Be 4
        ($r.Entries | Where-Object { $_.outcome -eq 'Queued' })[0].reason | Should -Match 'cap'
    }

    It 'persists the grant to the real store so a later cycle will not repeat it' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id '4242') -Mode 'enforce'
        $ctx.RecordProcessed = { param($id, $entry) Save-ProcessedTicket -MeTicketId $id -Entry $entry }
        Invoke-TicketPollerCycle -Context $ctx | Out-Null

        (Get-ProcessedTickets).ContainsKey('4242') | Should -BeTrue

        # Second cycle with a real dedup check must not grant again.
        $script:Granted.Clear()
        $ctx2 = New-PollContext -Tickets @(New-PollTicket -Id '4242') -Mode 'enforce'
        $ctx2.IsProcessed = { param($id) (Get-ProcessedTickets).ContainsKey($id) }
        $r2 = Invoke-TicketPollerCycle -Context $ctx2
        $r2.Granted | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'still refuses Production in enforce mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce' -EffectiveEnv 'Production'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 0
        $r.Queued | Should -Be 1
        $script:Granted.Count | Should -Be 0
    }

    It 'still refuses Eligible in enforce mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce' -DecisionAction 'Eligible'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 0
        $script:Granted.Count | Should -Be 0
    }

    It 'writes nothing when the kill switch is off even in enforce mode' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce' -Enabled $false
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Halted | Should -BeTrue
        $script:Granted.Count | Should -Be 0
    }
}

Describe 'Invoke-TicketPollerCycle -- grant duration (2026-08-20 final review I1)' {
    It 'threads Context.DurationDays through to the ticket ExecuteGrant receives' {
        $captured = $null
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'dur-1') -Mode 'enforce' -DurationDays 2 `
            -ExecuteGrant { param($ticket) $script:CapturedDuration = [int]$ticket.DurationDays; @{ ok = $true; assignmentId = 'a-1' } }
        Invoke-TicketPollerCycle -Context $ctx | Out-Null
        $script:CapturedDuration | Should -Be 2
    }

    It 'falls back to 7 when no DurationDays is wired into the context (backward compatible)' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'dur-2') -Mode 'enforce' `
            -ExecuteGrant { param($ticket) $script:CapturedDuration = [int]$ticket.DurationDays; @{ ok = $true; assignmentId = 'a-2' } }
        Invoke-TicketPollerCycle -Context $ctx | Out-Null
        $script:CapturedDuration | Should -Be 7
    }
}

Describe 'Invoke-TicketPollerCycle -- group duplicate detection (2026-08-20 final review C1)' {
    # Get-RealActiveAssignments only sees direct user->role->scope assignments; normal
    # fulfilment for everything this poller may grant is via an Entra group, invisible to
    # that check. ExecuteGrant signals this with { ok = $false; duplicate = $true }; the
    # cycle must queue, never report Granted, and must NOT stop later tickets over it (a
    # duplicate is not a system error).

    It 'queues rather than grants when ExecuteGrant reports a duplicate' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'dup-1') -Mode 'enforce' `
            -ExecuteGrant { param($ticket) @{ ok = $false; duplicate = $true; error = "Requester is already a member of Entra group 'sg-x-readers'." } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 0
        $r.Queued | Should -Be 1
        $r.Failed | Should -Be 0
        $r.Stopped | Should -BeFalse
        $r.Entries[0].outcome | Should -Be 'Queued'
        $r.Entries[0].applied | Should -BeFalse
        $r.Entries[0].reason | Should -Match 'already a member'
        $script:Granted.Count | Should -Be 0
    }

    It 'does not stop the cycle -- a later ticket in the same cycle still gets attempted' {
        $ctx = New-PollContext -Tickets @((New-PollTicket -Id 'dup-a'), (New-PollTicket -Id 'dup-b')) -Mode 'enforce' `
            -ExecuteGrant {
                param($ticket)
                if ($ticket.TicketId -eq 'dup-a') { return @{ ok = $false; duplicate = $true; error = 'duplicate' } }
                return @{ ok = $true; assignmentId = "a-$($ticket.TicketId)" }
            }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Queued | Should -Be 1
        $r.Granted | Should -Be 1
        $r.Stopped | Should -BeFalse
        @($r.Entries).Count | Should -Be 2
    }
}

Describe 'Invoke-TicketPollerCycle -- access promotion ladder (final-review C3)' {
    # Reviewer repro: the poller never called Test-AccessPromotionLadder at all, so a
    # requester who had never held Sandbox access could get NonProd Reader granted
    # unattended while the identical ticket clicked through the dashboard was refused.
    # The unattended path must never be MORE permissive than the human path.

    It 'queues instead of granting when the promotion ladder refuses' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce'
        $ctx.CheckPromotionLadder = {
            param($Ticket, $Decision)
            @{ Ok = $false; Reason = 'Access promotion required: grant Reader in Sandbox before Non-Prod for dev.user@contoso.com.' }
        }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 0
        $r.Queued | Should -Be 1
        $r.Entries[0].outcome | Should -Be 'Queued'
        $r.Entries[0].reason | Should -Match 'Access promotion required'
        $script:Granted.Count | Should -Be 0
    }

    It 'also refuses in shadow mode (reports Queued, not WouldGrant)' {
        $ctx = New-PollContext -Tickets @(New-PollTicket)
        $ctx.CheckPromotionLadder = { param($Ticket, $Decision) @{ Ok = $false; Reason = 'ladder refused' } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 0
        $r.Queued | Should -Be 1
    }

    It 'grants normally when the ladder allows it' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce'
        $ctx.CheckPromotionLadder = { param($Ticket, $Decision) @{ Ok = $true } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
        $r.Queued | Should -Be 0
    }

    It 'grants normally when no CheckPromotionLadder is wired at all (backward compatible)' {
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
    }

    It 'does not consult the ladder for a ticket the gate already refused' {
        # The ladder read hits the processed store; it must not be paid for on a ticket
        # that is being Queued for an unrelated reason (e.g. Production is excluded
        # outright regardless of promotion history).
        $script:LadderCalls = 0
        $ctx = New-PollContext -Tickets @(New-PollTicket) -Mode 'enforce' -EffectiveEnv 'Production'
        $ctx.CheckPromotionLadder = { param($Ticket, $Decision) $script:LadderCalls++; @{ Ok = $true } }
        Invoke-TicketPollerCycle -Context $ctx | Out-Null
        $script:LadderCalls | Should -Be 0
    }
}

Describe 'Invoke-TicketPollerCycle -- RunId threading (final-review C2)' {
    It 'uses Context.RunId when supplied instead of minting its own' {
        $ctx = New-PollContext -Tickets @(New-PollTicket)
        $ctx.RunId = 'poll-fixed-run-id-123'
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.RunId | Should -Be 'poll-fixed-run-id-123'
    }

    It 'still mints a run id when Context carries none (backward compatible)' {
        $ctx = New-PollContext -Tickets @(New-PollTicket)
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.RunId | Should -Not -BeNullOrEmpty
    }
}

Describe 'Invoke-TicketPollerCycle -- ManageEngine write-back (unattended note + resolve)' {

    It 'shadow mode calls neither PostTicketNote nor ResolveTicket (shadow writes nothing, ManageEngine included)' {
        $script:NoteCalls = 0
        $script:ResolveCalls = 0
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'shadow-1')
        $ctx.PostTicketNote = { param($MeTicketId, $Ticket, $Decision, $Execution) $script:NoteCalls++; @{} }
        $ctx.ResolveTicket = { param($MeTicketId) $script:ResolveCalls++; @{ success = $true } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.WouldGrant | Should -Be 1
        $script:NoteCalls | Should -Be 0
        $script:ResolveCalls | Should -Be 0
    }

    It 'a Queued ticket calls neither hook (queued tickets are re-examined every cycle -- a note per cycle would spam the ticket)' {
        $script:NoteCalls = 0
        $script:ResolveCalls = 0
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'queued-1') -Mode 'enforce' -EffectiveEnv 'Production'
        $ctx.PostTicketNote = { param($MeTicketId, $Ticket, $Decision, $Execution) $script:NoteCalls++; @{} }
        $ctx.ResolveTicket = { param($MeTicketId) $script:ResolveCalls++; @{ success = $true } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Queued | Should -Be 1
        $script:NoteCalls | Should -Be 0
        $script:ResolveCalls | Should -Be 0
    }

    It 'a successful enforce grant posts the success note, then resolves, and records both on the entry' {
        $script:NoteArgs = $null
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'ok-1') -Mode 'enforce'
        $ctx.PostTicketNote = {
            param($MeTicketId, $Ticket, $Decision, $Execution)
            $script:NoteArgs = @{ MeTicketId = $MeTicketId; Execution = $Execution }
            @{ notifyRequester = $true }
        }
        $ctx.ResolveTicket = { param($MeTicketId) @{ success = $true } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
        $r.Entries[0].notePosted | Should -BeTrue
        $r.Entries[0].ticketResolved | Should -BeTrue
        $script:NoteArgs.MeTicketId | Should -Be 'ok-1'
        $script:NoteArgs.Execution.Success | Should -BeTrue
    }

    It 'a grant failure posts the failure note (Execution.Success = false) and does not resolve' {
        $script:NoteArgs = $null
        $script:ResolveCalls = 0
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'fail-1') -Mode 'enforce' `
            -ExecuteGrant { param($ticket) @{ ok = $false; error = 'ARM returned 403' } }
        $ctx.PostTicketNote = {
            param($MeTicketId, $Ticket, $Decision, $Execution)
            $script:NoteArgs = @{ MeTicketId = $MeTicketId; Execution = $Execution }
            @{ notifyRequester = $true }
        }
        $ctx.ResolveTicket = { param($MeTicketId) $script:ResolveCalls++; @{ success = $true } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Failed | Should -Be 1
        $r.Entries[0].notePosted | Should -BeTrue
        $r.Entries[0].ticketResolved | Should -BeFalse
        $script:NoteArgs.Execution.Success | Should -BeFalse
        $script:NoteArgs.Execution.Error | Should -Match 'ARM returned 403'
        $script:ResolveCalls | Should -Be 0
    }

    It 'a note failure is recorded on the entry without affecting the Granted outcome' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'noteerr-1') -Mode 'enforce'
        $ctx.PostTicketNote = { param($MeTicketId, $Ticket, $Decision, $Execution) @{ error = 'ManageEngine unreachable' } }
        $ctx.ResolveTicket = { param($MeTicketId) @{ success = $true } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
        $r.Entries[0].notePosted | Should -BeFalse
        $r.Entries[0].noteError | Should -Match 'ManageEngine unreachable'
        # A note failure must not block resolution -- they are independent write-backs.
        $r.Entries[0].ticketResolved | Should -BeTrue
    }

    It 'a throwing ResolveTicket is non-fatal: the grant still counts, the claim is retained, the cycle does not stop, and the failure is recorded' {
        $ctx = New-PollContext -Tickets @((New-PollTicket -Id 'resolve-throws'), (New-PollTicket -Id 'next-ticket')) -Mode 'enforce'
        $ctx.PostTicketNote = { param($MeTicketId, $Ticket, $Decision, $Execution) @{ notifyRequester = $true } }
        $ctx.ResolveTicket = { param($MeTicketId) throw 'ME PUT timed out' }
        $r = Invoke-TicketPollerCycle -Context $ctx

        # The grant itself is unaffected by the resolve failure.
        $r.Granted | Should -Be 2
        $r.Failed | Should -Be 0
        $r.Stopped | Should -BeFalse
        $script:Granted | Should -Contain 'resolve-throws'
        # RecordProcessed (the claim) still ran for both tickets despite the throw.
        $script:Recorded | Should -Contain 'resolve-throws'
        $script:Recorded | Should -Contain 'next-ticket'

        $entry = $r.Entries | Where-Object { $_.ticketId -eq 'resolve-throws' }
        $entry.outcome | Should -Be 'Granted'
        $entry.ticketResolved | Should -BeFalse
        $entry.resolveError | Should -Match 'ME PUT timed out'
    }

    It 'a throwing PostTicketNote is non-fatal and still allows resolve to run' {
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'note-throws') -Mode 'enforce'
        $ctx.PostTicketNote = { param($MeTicketId, $Ticket, $Decision, $Execution) throw 'ME POST timed out' }
        $ctx.ResolveTicket = { param($MeTicketId) @{ success = $true } }
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
        $r.Stopped | Should -BeFalse
        $r.Entries[0].notePosted | Should -BeFalse
        $r.Entries[0].noteError | Should -Match 'ME POST timed out'
        $r.Entries[0].ticketResolved | Should -BeTrue
    }

    It 'omits the write-back hooks entirely when Context wires neither (backward compatible with existing callers)' {
        # New-PollContext never sets PostTicketNote/ResolveTicket by default -- this is
        # the exact shape of every pre-existing test/context in this file.
        $ctx = New-PollContext -Tickets @(New-PollTicket -Id 'no-hooks') -Mode 'enforce'
        { Invoke-TicketPollerCycle -Context $ctx } | Should -Not -Throw
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Granted | Should -Be 1
        $r.Entries[0].notePosted | Should -BeFalse
        $r.Entries[0].ticketResolved | Should -BeFalse
    }
}

Describe 'Invoke-TicketPollerCycle -- ME list-vs-detail udf_fields (Critical bug: LIST returns udf_fields empty)' {
    # Regression suite for a real, confirmed ManageEngine behaviour: GET /api/v3/requests
    # (the LIST endpoint FetchTickets calls) returns udf_fields EMPTY on every ticket, even
    # when udf_fields is explicitly named in fields_required. Only GET
    # /api/v3/requests/{id} (the DETAIL endpoint) populates them. Before this fix, every
    # ticket mapped as "structured fields incomplete" and wouldGrant was permanently 0.
    # These tests use the REAL Get-MeTemplateAccessFields extractor (not the New-PollContext
    # stub) so a revert to reading list-level udf_fields fails loudly here.

    BeforeAll {
        . (Join-Path $repoRoot 'dashboard\api\MeAccessFields.ps1')

        function New-PollTicketWithUdf {
            <#
            .SYNOPSIS
              Same shape New-PollTicket builds, plus a real (nested-object) udf_fields
              block -- the actual shape ManageEngine's detail endpoint returns, each
              value read via .name by Get-MeUdfFieldValue.
            #>
            param(
                [string]$Id = '9001',
                [string]$Sub = 'inception-ai-Sandbox',
                [string]$Role = 'Reader',
                [string]$Env = 'Development',
                [switch]$EmptyUdf
            )
            $t = New-PollTicket -Id $Id
            $udf = if ($EmptyUdf) {
                # The exact LIST-endpoint bug shape: udf_fields present but empty.
                [pscustomobject]@{}
            } else {
                [pscustomobject]@{
                    udf_pick_3728 = [pscustomobject]@{ name = $Sub }
                    udf_pick_3729 = [pscustomobject]@{ name = $Role }
                    udf_pick_3719 = [pscustomobject]@{ name = $Env }
                }
            }
            $t | Add-Member -NotePropertyName udf_fields -NotePropertyValue $udf -Force
            return $t
        }
    }

    It 'maps complete and becomes eligible using DETAIL udf_fields when the LIST ticket has them empty' {
        # This is the exact regression this bug describes: list-level udf_fields empty,
        # detail-level udf_fields populated. Must fail if someone reverts to reading
        # $me.udf_fields (the list ticket) directly.
        $listTicket = New-PollTicketWithUdf -Id 'udf-1' -EmptyUdf
        $detailTicket = New-PollTicketWithUdf -Id 'udf-1'

        $ctx = New-PollContext -Tickets @($listTicket)
        $ctx.GetAccessFields = { param($t) Get-MeTemplateAccessFields -UdfFields $t.udf_fields -UdfKeyOverrides $null }
        # A plain (unscoped) local List, not $script: -- GetNewClosure() snapshots an
        # explicitly $script:-qualified variable into an isolated copy under Pester (the
        # mutation inside the closure is invisible to this It block afterwards, and can
        # even throw "cannot call a method on a null-valued expression" here). A List is
        # a reference type, so closing over the plain local variable and reading the SAME
        # variable back afterward works: no scope crossing needed either way.
        $detailCallLog = [System.Collections.Generic.List[string]]::new()
        $ctx.FetchTicketDetail = { param($id) $detailCallLog.Add([string]$id); $detailTicket }.GetNewClosure()

        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 1
        $r.WouldGrant | Should -Be 1
        $r.Queued | Should -Be 0
        $r.Entries[0].outcome | Should -Be 'WouldGrant'
        $detailCallLog.Count | Should -Be 1
    }

    It 'reverting to list-level udf_fields (no detail fetch wired) reproduces the original bug -- queued as incomplete' {
        # Not a test of desired behaviour -- a canary. If GetAccessFields is fed the list
        # ticket directly (no FetchTicketDetail hook at all, matching the pre-fix code),
        # the ticket must map incomplete, proving this suite actually exercises the trap.
        $listTicket = New-PollTicketWithUdf -Id 'udf-2' -EmptyUdf
        $ctx = New-PollContext -Tickets @($listTicket)
        $ctx.GetAccessFields = { param($t) Get-MeTemplateAccessFields -UdfFields $t.udf_fields -UdfKeyOverrides $null }
        # Deliberately no FetchTicketDetail wired.
        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Queued | Should -Be 1
        $r.WouldGrant | Should -Be 0
        $r.Entries[0].reason | Should -Match 'incomplete'
    }

    It 'queues a ticket with a clear reason when FetchTicketDetail fails, and still processes the next ticket in the same cycle' {
        $failing = New-PollTicketWithUdf -Id 'detail-fail-1' -EmptyUdf
        $okListTicket = New-PollTicketWithUdf -Id 'detail-fail-2' -EmptyUdf
        $okDetail = New-PollTicketWithUdf -Id 'detail-fail-2'

        $ctx = New-PollContext -Tickets @($failing, $okListTicket)
        $ctx.GetAccessFields = { param($t) Get-MeTemplateAccessFields -UdfFields $t.udf_fields -UdfKeyOverrides $null }
        $ctx.FetchTicketDetail = {
            param($id)
            if ($id -eq 'detail-fail-1') { throw 'ManageEngine detail endpoint timed out' }
            return $okDetail
        }.GetNewClosure()

        $r = Invoke-TicketPollerCycle -Context $ctx
        $r.Examined | Should -Be 2
        $r.Stopped | Should -BeFalse
        $r.Failed | Should -Be 0

        $failedEntry = $r.Entries | Where-Object { $_.ticketId -eq 'detail-fail-1' }
        $failedEntry.outcome | Should -Be 'Queued'
        $failedEntry.reason | Should -Match 'ticket detail'
        $failedEntry.reason | Should -Match 'timed out'

        $okEntry = $r.Entries | Where-Object { $_.ticketId -eq 'detail-fail-2' }
        $okEntry.outcome | Should -Be 'WouldGrant'
    }

    It 'does not fetch ticket detail for tickets filtered out by the processed store, the age window, or the template gate' {
        $detailCallLog = [System.Collections.Generic.List[string]]::new()
        $processed = New-PollTicketWithUdf -Id 'proc-1'
        $old = New-PollTicketWithUdf -Id 'old-1'
        $old.created_time = [pscustomobject]@{ value = [string][int64](([datetime]::UtcNow.AddDays(-40)) - [datetime]'1970-01-01').TotalMilliseconds }
        $disallowedTemplate = New-PollTicketWithUdf -Id 'tmpl-1'
        $eligible = New-PollTicketWithUdf -Id 'ok-1'

        $ctx = New-PollContext -Tickets @($processed, $old, $disallowedTemplate, $eligible)
        $ctx.IsProcessed = { param($id) $id -eq 'proc-1' }
        $ctx.IsTemplateAllowed = { param($t) [string]$t.id -ne 'tmpl-1' }
        $ctx.GetAccessFields = { param($t) Get-MeTemplateAccessFields -UdfFields $t.udf_fields -UdfKeyOverrides $null }
        $ctx.FetchTicketDetail = { param($id) $detailCallLog.Add([string]$id); $null }.GetNewClosure()

        Invoke-TicketPollerCycle -Context $ctx | Out-Null

        # Only 'ok-1' survives IsProcessed, the age window, and the template gate.
        $detailCallLog.Count | Should -Be 1
        $detailCallLog | Should -Contain 'ok-1'
    }
}
