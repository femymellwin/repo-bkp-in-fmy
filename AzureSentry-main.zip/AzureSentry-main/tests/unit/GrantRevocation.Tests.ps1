BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\DashboardHelpers.ps1')
    . (Join-Path $repoRoot 'dashboard\api\GrantRevocation.ps1')

    function New-FakeRevokeContext {
        # No .GetNewClosure() on any of these: $script:Calls is explicitly scope-qualified
        # and must resolve dynamically at invocation time (see ReaperAgent.Tests.ps1's
        # New-ReaperContext for the full reasoning).
        #
        # ${GroupId}: (braces), not $GroupId: -- inside a double-quoted string, a bare
        # variable name immediately followed by ':' parses as an attempt at a scope-
        # qualified variable reference (e.g. $env:PATH), not "the variable's value, then a
        # literal colon". ${...} unambiguously delimits the name.
        $script:Calls = [System.Collections.Generic.List[string]]::new()
        @{
            ResolveUpnToObjectId = { param($Upn) $script:Calls.Add("resolve:${Upn}"); 'user-obj-id' }
            RemoveGroupMember    = { param($GroupId, $UserId) $script:Calls.Add("removeGroup:${GroupId}:${UserId}") }
            GetRoleDefinitionId  = { param($RoleName) $script:Calls.Add("roleDef:${RoleName}"); 'role-def-id' }
            RemoveAssignment     = {
                param($AssignmentId, $Scope, $UserId, $RoleDefinitionId, $AssignmentType)
                $script:Calls.Add("removeAssignment:${AssignmentId}:${Scope}:${UserId}:${RoleDefinitionId}:${AssignmentType}")
            }
        }
    }
}

Describe 'Invoke-GrantRevocationAction' {
    It 'removes group membership for a Group-fulfilment record' {
        $prior = [pscustomobject]@{
            requesterUpn = 'dev.user@contoso.com'; role = 'Reader'; subscriptionId = 'sub-1'
            assignmentId = $null; fulfilment = 'Group'; groupId = 'grp-1'; revoked = $false
        }
        $ctx = New-FakeRevokeContext
        $result = Invoke-GrantRevocationAction -Prior $prior -Context $ctx

        $result.Ok | Should -BeTrue
        $result.Mode | Should -Be 'Group'
        $script:Calls | Should -Contain 'resolve:dev.user@contoso.com'
        $script:Calls | Should -Contain 'removeGroup:grp-1:user-obj-id'
        ($script:Calls | Where-Object { $_ -like 'removeAssignment:*' }) | Should -BeNullOrEmpty
    }

    It 'removes a PIM assignment for a non-Group record' {
        $prior = [pscustomobject]@{
            requesterUpn = 'dev.user@contoso.com'; role = 'Reader'; subscriptionId = 'sub-2'
            assignmentId = 'assign-1'; assignmentType = 'Active'; fulfilment = 'PimFallback'; revoked = $false
        }
        $ctx = New-FakeRevokeContext
        $result = Invoke-GrantRevocationAction -Prior $prior -Context $ctx

        $result.Ok | Should -BeTrue
        $result.Mode | Should -Be 'Assignment'
        $script:Calls | Should -Contain 'roleDef:Reader'
        $script:Calls | Should -Contain 'removeAssignment:assign-1:/subscriptions/sub-2:user-obj-id:role-def-id:Active'
        ($script:Calls | Where-Object { $_ -like 'removeGroup:*' }) | Should -BeNullOrEmpty
    }

    It 'infers Eligible assignment type from the assignment id when assignmentType is absent' {
        $prior = [pscustomobject]@{
            requesterUpn = 'dev.user@contoso.com'; role = 'Owner'; subscriptionId = 'sub-3'
            assignmentId = '/providers/.../roleEligibilityScheduleRequests/abc'; revoked = $false
        }
        $ctx = New-FakeRevokeContext
        $result = Invoke-GrantRevocationAction -Prior $prior -Context $ctx

        $result.Ok | Should -BeTrue
        ($script:Calls | Where-Object { $_ -like '*:Eligible' }) | Should -Not -BeNullOrEmpty
    }

    It 'refuses to revoke an already-revoked record and never calls any removal hook' {
        $prior = [pscustomobject]@{
            requesterUpn = 'dev.user@contoso.com'; role = 'Reader'; subscriptionId = 'sub-1'
            assignmentId = $null; fulfilment = 'Group'; groupId = 'grp-1'; revoked = $true
        }
        $ctx = New-FakeRevokeContext
        $result = Invoke-GrantRevocationAction -Prior $prior -Context $ctx

        $result.Ok | Should -BeFalse
        $script:Calls.Count | Should -Be 0
    }

    It 'refuses to revoke a record with neither an assignmentId nor a Group+groupId' {
        $prior = [pscustomobject]@{
            requesterUpn = 'dev.user@contoso.com'; role = 'Reader'; subscriptionId = 'sub-1'
            assignmentId = $null; fulfilment = $null; groupId = $null; revoked = $false
        }
        $ctx = New-FakeRevokeContext
        $result = Invoke-GrantRevocationAction -Prior $prior -Context $ctx

        $result.Ok | Should -BeFalse
        $script:Calls.Count | Should -Be 0
    }

    It 'reports Ok = $false with the exception message when a removal call throws' {
        $prior = [pscustomobject]@{
            requesterUpn = 'dev.user@contoso.com'; role = 'Reader'; subscriptionId = 'sub-1'
            assignmentId = $null; fulfilment = 'Group'; groupId = 'grp-1'; revoked = $false
        }
        $ctx = New-FakeRevokeContext
        $ctx.RemoveGroupMember = { param($GroupId, $UserId) throw 'Graph 403' }
        $result = Invoke-GrantRevocationAction -Prior $prior -Context $ctx

        $result.Ok | Should -BeFalse
        $result.Error | Should -Match 'Graph 403'
    }
}
