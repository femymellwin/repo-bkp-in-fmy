BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\TicketTemplates.ps1')
}

Describe 'Get-NormalizedTemplateName' {
    It 'strips trailing Template suffix' {
        Get-NormalizedTemplateName -Name 'Report and Issue Template' | Should -Be 'Report and Issue'
    }
}

Describe 'Get-TicketTemplateSchema' {
    It 'returns grant handler for Azure Subscription' {
        $s = Get-TicketTemplateSchema -TemplateName 'Azure Subscription'
        $s.Handler | Should -Be 'azure-subscription-grant'
    }
    It 'returns pending for Networking' {
        (Get-TicketTemplateSchema -TemplateName 'Networking').Handler | Should -Be 'pending'
    }
    It 'aliases Security Assesment' {
        (Get-TicketTemplateSchema -TemplateName 'Security Assesment').CanonicalName | Should -Be 'Security Assessment'
    }
    It 'returns null for unknown' {
        Get-TicketTemplateSchema -TemplateName 'Mystery' | Should -Be $null
    }
}

Describe 'Test-TemplateAllowsGrant' {
    It 'allows only azure-subscription-grant' {
        Test-TemplateAllowsGrant -Payload @{ handler = 'azure-subscription-grant' } | Should -Be $true
        Test-TemplateAllowsGrant -Payload @{ handler = 'pending' } | Should -Be $false
        Test-TemplateAllowsGrant -Payload @{ handler = 'none' } | Should -Be $false
    }
}

Describe 'New-TemplatePayload' {
    It 'extracts Networking fields by label' {
        $ticket = [pscustomobject]@{
            subject     = 'Open firewall'
            description = 'Need access'
            status      = @{ name = 'Open' }
            category    = @{ name = 'Azure' }
            subcategory = @{ name = 'Networking' }
            requester   = @{ name = 'Ada'; email_id = 'ada@example.com' }
            template    = @{ name = 'Networking' }
            udf_fields  = [pscustomobject]@{
                a = [pscustomobject]@{ label = 'Source IP'; name = '10.1.1.1' }
                b = [pscustomobject]@{ label = 'Protocol (TPC/UDP)'; name = 'TCP' }
            }
        }
        $p = New-TemplatePayload -Ticket $ticket
        $p.knownSchema | Should -Be $true
        $p.handler | Should -Be 'pending'
        $p.fields['Source IP'] | Should -Be '10.1.1.1'
        $p.fields['Protocol (TCP/UDP)'] | Should -Be 'TCP'
    }

    It 'warns on unknown template' {
        $ticket = [pscustomobject]@{
            subject  = 'x'
            template = @{ name = 'Mystery' }
        }
        $p = New-TemplatePayload -Ticket $ticket
        $p.knownSchema | Should -Be $false
        $p.handler | Should -Be 'none'
        $p.warnings[0] | Should -Match 'Unknown template schema'
    }

    It 'fills GitHub Enterprise fields from keyed UDFs and built-in item/request_type' {
        $ticket = [pscustomobject]@{
            subject      = 'GitHub access'
            template     = @{ name = 'GitHub Enterprise' }
            item         = @{ name = 'New Request'; id = '2113' }
            request_type = @{ name = 'Service'; id = '301' }
            udf_fields   = [pscustomobject]@{
                udf_pick_3719 = [pscustomobject]@{ name = 'Test'; id = '1504' }
                udf_pick_3014 = [pscustomobject]@{ name = 'No'; id = '923' }
            }
        }
        $p = New-TemplatePayload -Ticket $ticket
        $p.fields['Environment'] | Should -Be 'Test'
        $p.fields['Exception Request'] | Should -Be 'No'
        $p.fields['Item'] | Should -Be 'New Request'
        $p.fields['Request Type'] | Should -Be 'Service'
    }

    It 'fills Cortex Environment/Item/Request Type without Exception Request' {
        $ticket = [pscustomobject]@{
            subject      = 'AppReg'
            template     = @{ name = 'Cortex' }
            item         = @{ name = 'Others' }
            request_type = @{ name = 'Service' }
            udf_fields   = [pscustomobject]@{
                udf_pick_3719 = [pscustomobject]@{ name = 'Development'; id = '1503' }
            }
        }
        $p = New-TemplatePayload -Ticket $ticket
        $p.fields['Environment'] | Should -Be 'Development'
        $p.fields['Item'] | Should -Be 'Others'
        $p.fields['Request Type'] | Should -Be 'Service'
        $p.fields.Contains('Exception Request') | Should -Be $false
    }

    It 'fills General Access Business Justification from udf_mline_901' {
        $ticket = [pscustomobject]@{
            subject    = 'Provide access to Cortex admin ui for UAT environment'
            template   = @{ name = 'General Access' }
            item       = @{ name = 'Modify / Change Access Role or Permission' }
            udf_fields = [pscustomobject]@{
                udf_mline_901 = 'Provide access to Cortex admin ui for UAT environment'
            }
        }
        $p = New-TemplatePayload -Ticket $ticket
        $p.fields['Business Justification'] | Should -Be 'Provide access to Cortex admin ui for UAT environment'
        $p.fields['Item'] | Should -Be 'Modify / Change Access Role or Permission'
    }
}

Describe 'Resolve-MandatorySchemaFields' {
    It 'maps UDF keys via labels to schema fields' {
        $udf = [pscustomobject]@{
            udf_pick_1 = [pscustomobject]@{ label = 'Source IP'; name = '10.0.0.1' }
            udf_pick_2 = [pscustomobject]@{ label = 'Port'; name = '443' }
        }
        $r = Resolve-MandatorySchemaFields `
            -MandatoryKeys @('udf_pick_1', 'description', 'requester') `
            -SchemaFields @('Source IP', 'Destination IP', 'Port') `
            -UdfFields $udf
        $r.RequiredFields | Should -Contain 'Source IP'
        $r.RequiredFields | Should -Not -Contain 'Destination IP'
        $r.RequiredPlaceholders | Should -Contain 'Justification'
        $r.RequiredPlaceholders | Should -Contain 'Requester UPN'
    }

    It 'maps humanized keys like source_ip' {
        $r = Resolve-MandatorySchemaFields `
            -MandatoryKeys @('source_ip', 'item') `
            -SchemaFields @('Source IP', 'Item', 'Port') `
            -UdfFields $null
        $r.RequiredFields | Should -Contain 'Source IP'
        $r.RequiredFields | Should -Contain 'Item'
    }
}

Describe 'Set-TemplatePayloadRequiredFields' {
    It 'clears required markers for Azure Subscription' {
        $p = [ordered]@{
            handler                = 'azure-subscription-grant'
            fieldOrder             = @('Subscription', 'Azure Role', 'Environment')
            requiredFields         = @('Subscription')
            requiredPlaceholders   = @('Justification')
        }
        $out = Set-TemplatePayloadRequiredFields -Payload $p -MandatoryKeys @('subscription', 'description')
        $out.requiredFields.Count | Should -Be 0
        $out.requiredPlaceholders.Count | Should -Be 0
    }

    It 'sets required fields for pending templates' {
        $p = [ordered]@{
            handler      = 'pending'
            fieldOrder   = @('Item', 'Business Justification')
        }
        $udf = [pscustomobject]@{
            udf_x = [pscustomobject]@{ label = 'Item'; name = 'Laptop' }
        }
        $out = Set-TemplatePayloadRequiredFields -Payload $p -MandatoryKeys @('udf_x', 'description') -UdfFields $udf
        $out.requiredFields | Should -Contain 'Item'
        $out.requiredPlaceholders | Should -Contain 'Justification'
    }
}

Describe 'Resolve-TemplateGrantAllowed' {
    It 'blocks pending handler' {
        $r = Resolve-TemplateGrantAllowed -Body ([pscustomobject]@{ templateHandler = 'pending' })
        $r.Allowed | Should -Be $false
    }
    It 'allows azure-subscription-grant by template name' {
        $r = Resolve-TemplateGrantAllowed -Body ([pscustomobject]@{ templateName = 'Azure Subscription' })
        $r.Allowed | Should -Be $true
    }
    It 'allows when no template identity (legacy)' {
        $r = Resolve-TemplateGrantAllowed -Body ([pscustomobject]@{ ticket = @{} })
        $r.Allowed | Should -Be $true
        $r.Skipped | Should -Be $true
    }

    # final-review C2: the poller used to gate on `-like '*Azure Subscription*'`, a
    # substring test that a name like "Azure Subscription Deletion Request" also
    # satisfies. Resolve-TemplateGrantAllowed does an exact schema lookup (via
    # Get-NormalizedTemplateName + the alias map) and must refuse any near-miss name
    # that is not itself a recognised template -- the unattended path must never be more
    # permissive than this, the dashboard's own gate.
    It 'refuses a near-miss template name that only contains "Azure Subscription"' {
        $r = Resolve-TemplateGrantAllowed -Body ([pscustomobject]@{ templateName = 'Azure Subscription Deletion Request' })
        $r.Allowed | Should -Be $false
        $r.Skipped | Should -Be $false
    }

    It 'refuses other near-miss Azure Subscription template names' {
        foreach ($name in @('Legacy Azure Subscription Access', 'Azure Subscription Owner Elevation')) {
            $r = Resolve-TemplateGrantAllowed -Body ([pscustomobject]@{ templateName = $name })
            $r.Allowed | Should -Be $false
        }
    }
}
