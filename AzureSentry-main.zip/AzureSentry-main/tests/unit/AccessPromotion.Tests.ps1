BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\ProcessedStore.ps1')
    . (Join-Path $repoRoot 'dashboard\api\AccessPromotion.ps1')

    function New-LadderStore {
        $path = Join-Path $TestDrive "ladder-$([guid]::NewGuid().ToString('N')).json"
        Initialize-ProcessedStore -Path $path
        return $path
    }

    $script:GrantDecision = @{ Action = 'Grant'; EffectiveEnvironment = 'NonProd' }
}

Describe 'Test-AccessPromotionLadder' {
    BeforeEach {
        New-LadderStore | Out-Null
    }

    It 'allows Sandbox unconditionally (the bottom rung, nothing to climb from)' {
        $ticket = @{ Environment = 'Sandbox'; Role = 'Reader'; RequesterUpn = 'a@b.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision
        $r.Ok | Should -Be $true
    }

    It 'refuses NonProd for a requester with no prior Sandbox grant' {
        $ticket = @{ Environment = 'NonProd'; Role = 'Reader'; RequesterUpn = 'new.user@contoso.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision
        $r.Ok | Should -Be $false
        $r.Reason | Should -Match 'Sandbox before Non-Prod'
    }

    It 'allows NonProd once the same requester+role has a prior Sandbox grant' {
        Save-ProcessedTicket -MeTicketId 'prior-1' -Entry @{
            requesterUpn = 'promoted.user@contoso.com'; role = 'Reader'; environment = 'Sandbox'; revoked = $false
        }
        $ticket = @{ Environment = 'NonProd'; Role = 'Reader'; RequesterUpn = 'promoted.user@contoso.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision
        $r.Ok | Should -Be $true
    }

    It 'ignores a prior Sandbox grant that was revoked' {
        Save-ProcessedTicket -MeTicketId 'prior-2' -Entry @{
            requesterUpn = 'revoked.user@contoso.com'; role = 'Reader'; environment = 'Sandbox'; revoked = $true
        }
        $ticket = @{ Environment = 'NonProd'; Role = 'Reader'; RequesterUpn = 'revoked.user@contoso.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision
        $r.Ok | Should -Be $false
    }

    It 'ignores a prior Sandbox grant for a DIFFERENT role' {
        Save-ProcessedTicket -MeTicketId 'prior-3' -Entry @{
            requesterUpn = 'cross.role@contoso.com'; role = 'Writer'; environment = 'Sandbox'; revoked = $false
        }
        $ticket = @{ Environment = 'NonProd'; Role = 'Reader'; RequesterUpn = 'cross.role@contoso.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision
        $r.Ok | Should -Be $false
    }

    It 'treats Writer and Contributor as the same rung' {
        Save-ProcessedTicket -MeTicketId 'prior-4' -Entry @{
            requesterUpn = 'writer.user@contoso.com'; role = 'Contributor'; environment = 'Sandbox'; revoked = $false
        }
        $ticket = @{ Environment = 'NonProd'; Role = 'Writer'; RequesterUpn = 'writer.user@contoso.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision
        $r.Ok | Should -Be $true
    }

    It 'refuses Production with no lower-rung grant at all' {
        $ticket = @{ Environment = 'Production'; Role = 'Reader'; RequesterUpn = 'prod.hopeful@contoso.com' }
        $decision = @{ Action = 'Grant'; EffectiveEnvironment = 'Production' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $decision
        $r.Ok | Should -Be $false
        $r.Reason | Should -Match 'Production'
    }

    It 'allows Production once NonProd has been granted (Sandbox is not mandatory for Production)' {
        Save-ProcessedTicket -MeTicketId 'prior-5' -Entry @{
            requesterUpn = 'nonprod.first@contoso.com'; role = 'Reader'; environment = 'NonProd'; revoked = $false
        }
        $ticket = @{ Environment = 'Production'; Role = 'Reader'; RequesterUpn = 'nonprod.first@contoso.com' }
        $decision = @{ Action = 'Grant'; EffectiveEnvironment = 'Production' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $decision
        $r.Ok | Should -Be $true
    }

    It 'exempts BreakGlass from the ladder regardless of history' {
        $ticket = @{ Environment = 'Production'; Role = 'Owner'; RequesterUpn = 'oncall@contoso.com' }
        $decision = @{ Action = 'BreakGlass'; EffectiveEnvironment = 'Production' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $decision
        $r.Ok | Should -Be $true
    }

    It 'does not hard-block Eligible (approval) actions' {
        $ticket = @{ Environment = 'Production'; Role = 'Owner'; RequesterUpn = 'approver.needed@contoso.com' }
        $decision = @{ Action = 'Eligible'; EffectiveEnvironment = 'Production' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $decision
        $r.Ok | Should -Be $true
    }

    It 'is a no-op when Config disables enforceLadder' {
        $ticket = @{ Environment = 'NonProd'; Role = 'Reader'; RequesterUpn = 'no.enforcement@contoso.com' }
        $cfg = [pscustomobject]@{ accessPromotion = [pscustomobject]@{ enforceLadder = $false } }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision -Config $cfg
        $r.Ok | Should -Be $true
    }

    It 'defaults to enforced (fail-closed) when Config is not supplied at all' {
        # This is the poller's behaviour when config.json failed to load: $cfg is $null,
        # and the ladder must not silently go permissive because of it.
        $ticket = @{ Environment = 'NonProd'; Role = 'Reader'; RequesterUpn = 'no.config@contoso.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision -Config $null
        $r.Ok | Should -Be $false
    }

    It 'accepts a pscustomobject TicketInput, not just a hashtable (the poller passes one)' {
        # scripts/Invoke-TicketPollerCycle.ps1 calls this with $mapping.Ticket, which is a
        # pscustomobject from Resolve-MeTicketMapping -- not the hashtable the dashboard's
        # own $ticketInput happens to be. Both must work identically.
        $ticket = [pscustomobject]@{ Environment = 'NonProd'; Role = 'Reader'; RequesterUpn = 'poller.shaped@contoso.com' }
        $r = Test-AccessPromotionLadder -TicketInput $ticket -Decision $script:GrantDecision
        $r.Ok | Should -Be $false
        $r.Reason | Should -Match 'Sandbox before Non-Prod'
    }
}
