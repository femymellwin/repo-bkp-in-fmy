BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    # ConvertTo-LlmSafeText lives in LlmClient.ps1 and has no dependency on the
    # environment-resolution helpers below; it is tested here only because this
    # file is where its only coverage has always lived.
    . (Join-Path $repoRoot 'src\Agents\LlmClient.ps1')
    . (Join-Path $repoRoot 'dashboard\api\EnvironmentResolution.ps1')
}

Describe 'ConvertTo-LlmSafeText -- strips control bytes PS 5.1 JSON serialization mishandles' {

    It 'removes raw control characters outside the standard escaped set' {
        $dirty = "Access request" + [char]0x01 + "for the sandbox sub" + [char]0x1F
        $clean = ConvertTo-LlmSafeText -Text $dirty
        $clean | Should -Be 'Access requestfor the sandbox sub'
    }

    It 'removes DEL (0x7F)' {
        (ConvertTo-LlmSafeText -Text "before$([char]0x7F)after") | Should -Be 'beforeafter'
    }

    It 'leaves normal text and standard escaped whitespace alone' {
        (ConvertTo-LlmSafeText -Text "Line one`nLine two`tTabbed") | Should -Be "Line one`nLine two`tTabbed"
    }

    It 'handles null and empty input' {
        ConvertTo-LlmSafeText -Text '' | Should -Be ''
        ConvertTo-LlmSafeText -Text $null | Should -BeNullOrEmpty
    }
}

Describe 'Get-CanonicalEnvironmentFromDropdown -- deterministic mapping' {

    It 'maps the ManageEngine dropdown options' {
        Get-CanonicalEnvironmentFromDropdown -Value 'Sandbox' | Should -Be 'Sandbox'
        Get-CanonicalEnvironmentFromDropdown -Value 'Development' | Should -Be 'NonProd'
        Get-CanonicalEnvironmentFromDropdown -Value 'Test' | Should -Be 'NonProd'
        Get-CanonicalEnvironmentFromDropdown -Value 'Production' | Should -Be 'Production'
    }

    It 'maps all five confirmed live options for the structured templates (Azure Subscription, GitHub Enterprise, ADO, Cortex)' {
        Get-CanonicalEnvironmentFromDropdown -Value 'Development' | Should -Be 'NonProd'
        Get-CanonicalEnvironmentFromDropdown -Value 'Test' | Should -Be 'NonProd'
        Get-CanonicalEnvironmentFromDropdown -Value 'Preproduction' | Should -Be 'NonProd'
        Get-CanonicalEnvironmentFromDropdown -Value 'Production' | Should -Be 'Production'
        Get-CanonicalEnvironmentFromDropdown -Value 'Sandbox' | Should -Be 'Sandbox'
    }

    It 'is case and whitespace insensitive' {
        Get-CanonicalEnvironmentFromDropdown -Value '  PRODUCTION ' | Should -Be 'Production'
    }

    It 'maps non-prod spellings to NonProd, never Production' {
        Get-CanonicalEnvironmentFromDropdown -Value 'Non-Prod' | Should -Be 'NonProd'
        Get-CanonicalEnvironmentFromDropdown -Value 'non production' | Should -Be 'NonProd'
        Get-CanonicalEnvironmentFromDropdown -Value 'pre-prod' | Should -Be 'NonProd'
    }

    It 'returns null for free text so the caller falls back to the keyword rule' {
        Get-CanonicalEnvironmentFromDropdown -Value 'the prod one I think' | Should -BeNullOrEmpty
        Get-CanonicalEnvironmentFromDropdown -Value '' | Should -BeNullOrEmpty
        Get-CanonicalEnvironmentFromDropdown -Value $null | Should -BeNullOrEmpty
    }
}

Describe 'Test-IsStructuredEnvironmentTemplate -- template-aware routing' {

    It 'recognises the four templates with a mandatory Environment dropdown' {
        Test-IsStructuredEnvironmentTemplate -TicketType 'Azure Subscription' | Should -BeTrue
        Test-IsStructuredEnvironmentTemplate -TicketType 'GitHub Enterprise' | Should -BeTrue
        Test-IsStructuredEnvironmentTemplate -TicketType 'ADO' | Should -BeTrue
        Test-IsStructuredEnvironmentTemplate -TicketType 'Cortex' | Should -BeTrue
    }

    It 'is case-insensitive and tolerant of minor naming variants' {
        Test-IsStructuredEnvironmentTemplate -TicketType 'github enterprise' | Should -BeTrue
        Test-IsStructuredEnvironmentTemplate -TicketType 'Github Enterprise Access' | Should -BeTrue
        Test-IsStructuredEnvironmentTemplate -TicketType 'azure subscription' | Should -BeTrue
    }

    It 'treats other templates as out of scope -- no Environment field to resolve' {
        Test-IsStructuredEnvironmentTemplate -TicketType 'General Access' | Should -BeFalse
        Test-IsStructuredEnvironmentTemplate -TicketType 'Infrastructure' | Should -BeFalse
        Test-IsStructuredEnvironmentTemplate -TicketType '' | Should -BeFalse
        Test-IsStructuredEnvironmentTemplate -TicketType $null | Should -BeFalse
    }
}

Describe 'Test-IsGitHubEnterpriseTemplate -- the one template with a Production default' {

    It 'matches GitHub Enterprise and naming variants' {
        Test-IsGitHubEnterpriseTemplate -TicketType 'GitHub Enterprise' | Should -BeTrue
        Test-IsGitHubEnterpriseTemplate -TicketType 'github enterprise' | Should -BeTrue
        Test-IsGitHubEnterpriseTemplate -TicketType 'Github Enterprise Access' | Should -BeTrue
    }

    It 'does not match the other structured templates' {
        Test-IsGitHubEnterpriseTemplate -TicketType 'Azure Subscription' | Should -BeFalse
        Test-IsGitHubEnterpriseTemplate -TicketType 'ADO' | Should -BeFalse
        Test-IsGitHubEnterpriseTemplate -TicketType 'Cortex' | Should -BeFalse
        Test-IsGitHubEnterpriseTemplate -TicketType '' | Should -BeFalse
        Test-IsGitHubEnterpriseTemplate -TicketType $null | Should -BeFalse
    }
}

Describe 'Get-RuleBasedEnvironment -- keyword fallback' {

    It 'matches sandbox, non-prod and production terms' {
        (Get-RuleBasedEnvironment -Text 'need access to the sandbox').Environment | Should -Be 'Sandbox'
        (Get-RuleBasedEnvironment -Text 'UAT access please').Environment | Should -Be 'NonProd'
        (Get-RuleBasedEnvironment -Text 'production incident').Environment | Should -Be 'Production'
    }

    It 'checks sandbox and non-prod before a bare prod' {
        (Get-RuleBasedEnvironment -Text 'non-prod deployment').Environment | Should -Be 'NonProd'
        (Get-RuleBasedEnvironment -Text 'sandbox copy of prod data').Environment | Should -Be 'Sandbox'
    }

    It 'returns Unknown at zero confidence when nothing matches' {
        $r = Get-RuleBasedEnvironment -Text 'please grant access'
        $r.Environment | Should -Be 'Unknown'
        $r.Confidence | Should -Be 0.0
    }

    It 'keeps keyword confidence a low ranking figure' {
        $m = Get-RuleBasedEnvironment -Text 'sandbox'
        $m.Confidence | Should -BeLessThan 0.85
        $m.KeywordMatch | Should -BeTrue
    }

    It 'reports no keyword match when nothing was found in the text' {
        (Get-RuleBasedEnvironment -Text 'please reset my password').KeywordMatch | Should -BeFalse
    }
}
