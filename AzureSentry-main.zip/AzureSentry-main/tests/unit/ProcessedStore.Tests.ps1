﻿BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    $script:ModulePath = Join-Path $repoRoot 'dashboard\api\ProcessedStore.ps1'
    . $script:ModulePath
}

Describe 'ProcessedStore -- the record that prevents double-granting' {

    BeforeEach {
        $script:StorePath = Join-Path $TestDrive "processed-$([guid]::NewGuid().ToString('N')).json"
        Initialize-ProcessedStore -Path $script:StorePath
    }

    It 'returns an empty map when no file exists yet' {
        (Get-ProcessedTickets).Count | Should -Be 0
    }

    It 'round-trips an entry' {
        Save-ProcessedTicket -MeTicketId '2858' -Entry ([pscustomobject]@{ action = 'Grant'; requesterUpn = 'a@b.com' })
        $store = Get-ProcessedTickets
        $store.ContainsKey('2858') | Should -BeTrue
        $store['2858'].action | Should -Be 'Grant'
        $store['2858'].requesterUpn | Should -Be 'a@b.com'
    }

    It 'lets multiple distinct tickets coexist with all fields intact' {
        Save-ProcessedTicket -MeTicketId '1' -Entry @{ action = 'Grant'; role = 'Reader' }
        Save-ProcessedTicket -MeTicketId '2' -Entry @{ action = 'Eligible'; role = 'Contributor' }
        Save-ProcessedTicket -MeTicketId '3' -Entry @{ action = 'Grant'; role = 'Owner' }

        $store = Get-ProcessedTickets
        $store.Count | Should -Be 3
        $store['1'].role | Should -Be 'Reader'
        $store['2'].role | Should -Be 'Contributor'
        $store['3'].role | Should -Be 'Owner'
    }

    It 'overwrites an existing ticket entry on a second save' {
        Save-ProcessedTicket -MeTicketId '9' -Entry @{ action = 'Eligible' }
        Save-ProcessedTicket -MeTicketId '9' -Entry @{ action = 'Grant'; revoked = $true }
        $store = Get-ProcessedTickets
        $store.Count | Should -Be 1
        $store['9'].action | Should -Be 'Grant'
        $store['9'].revoked | Should -BeTrue
    }

    It 'removes an entry' {
        Save-ProcessedTicket -MeTicketId '1' -Entry ([pscustomobject]@{ action = 'Grant' })
        Remove-ProcessedTicketEntry -MeTicketId '1'
        (Get-ProcessedTickets).ContainsKey('1') | Should -BeFalse
    }

    It 'removes only its own ticket, leaving others intact' {
        Save-ProcessedTicket -MeTicketId 'keep-a' -Entry @{ action = 'Grant' }
        Save-ProcessedTicket -MeTicketId 'remove-me' -Entry @{ action = 'Grant' }
        Save-ProcessedTicket -MeTicketId 'keep-b' -Entry @{ action = 'Grant' }

        Remove-ProcessedTicketEntry -MeTicketId 'remove-me'

        $store = Get-ProcessedTickets
        $store.Count | Should -Be 2
        $store.ContainsKey('keep-a') | Should -BeTrue
        $store.ContainsKey('keep-b') | Should -BeTrue
        $store.ContainsKey('remove-me') | Should -BeFalse
    }

    It 'no-ops when removing a ticket that was never saved' {
        { Remove-ProcessedTicketEntry -MeTicketId 'never-existed' } | Should -Not -Throw
    }

    It 'rejects an empty ticket id on save' {
        { Save-ProcessedTicket -MeTicketId '' -Entry @{ action = 'Grant' } } | Should -Throw
    }

    It 'rejects a whitespace-only ticket id on save' {
        { Save-ProcessedTicket -MeTicketId '   ' -Entry @{ action = 'Grant' } } | Should -Throw
    }

    It 'rejects an empty ticket id on claim' {
        { Request-ProcessedTicketClaim -MeTicketId '' -Entry @{ action = 'Grant' } } | Should -Throw
    }

    Context 'ticket ids that are not plain numbers' {

        It 'round-trips a non-numeric id with punctuation' {
            $id = 'ELIG-ceo-sub--20260727135920'
            Save-ProcessedTicket -MeTicketId $id -Entry @{ action = 'Eligible'; role = 'Reader' }
            $store = Get-ProcessedTickets
            $store.ContainsKey($id) | Should -BeTrue
            $store[$id].meTicketId | Should -Be $id
        }

        It 'round-trips an id containing characters outside [A-Za-z0-9._-]' {
            $id = 'ME/Ticket #4160 (urgent!) @site'
            Save-ProcessedTicket -MeTicketId $id -Entry @{ action = 'Grant' }
            $store = Get-ProcessedTickets
            $store.ContainsKey($id) | Should -BeTrue
            $store[$id].action | Should -Be 'Grant'
        }

        It 'round-trips a very long ticket id' {
            $id = 'ELIG-' + ('x' * 400) + '-tail'
            Save-ProcessedTicket -MeTicketId $id -Entry @{ action = 'Grant' }
            $store = Get-ProcessedTickets
            $store.ContainsKey($id) | Should -BeTrue
            $store[$id].meTicketId | Should -Be $id
        }

        It 'does not collide two ids that sanitize to the same filename stem' {
            # Both contain only one alphanumeric run of the same length once every
            # other character is replaced by "_" -- if the hash suffix were missing,
            # both would sanitize to the identical filename stem and the second save
            # would silently overwrite the first.
            $idA = 'ticket#one'
            $idB = 'ticket!one'
            (ConvertTo-ProcessedTicketFileStem -MeTicketId $idA).Split('.')[0] |
                Should -Be (ConvertTo-ProcessedTicketFileStem -MeTicketId $idB).Split('.')[0]

            Save-ProcessedTicket -MeTicketId $idA -Entry @{ action = 'Grant'; tag = 'A' }
            Save-ProcessedTicket -MeTicketId $idB -Entry @{ action = 'Grant'; tag = 'B' }

            $store = Get-ProcessedTickets
            $store.Count | Should -Be 2
            $store[$idA].tag | Should -Be 'A'
            $store[$idB].tag | Should -Be 'B'
        }

        It 'does not collide two long ids that truncate to the same sanitized prefix' {
            $idA = ('a' * 200) + '-A'
            $idB = ('a' * 200) + '-B'
            Save-ProcessedTicket -MeTicketId $idA -Entry @{ tag = 'A' }
            Save-ProcessedTicket -MeTicketId $idB -Entry @{ tag = 'B' }

            $store = Get-ProcessedTickets
            $store.Count | Should -Be 2
            $store[$idA].tag | Should -Be 'A'
            $store[$idB].tag | Should -Be 'B'
        }
    }

    Context 'Request-ProcessedTicketClaim' {

        It 'returns true the first time and false on every subsequent attempt for the same id' {
            (Request-ProcessedTicketClaim -MeTicketId 'claim-1' -Entry @{ action = 'Grant' }) | Should -BeTrue
            (Request-ProcessedTicketClaim -MeTicketId 'claim-1' -Entry @{ action = 'Grant' }) | Should -BeFalse
            (Request-ProcessedTicketClaim -MeTicketId 'claim-1' -Entry @{ action = 'Grant' }) | Should -BeFalse
        }

        It 'does not throw when it loses the race -- losing is a normal outcome' {
            Request-ProcessedTicketClaim -MeTicketId 'claim-2' -Entry @{ action = 'Grant' } | Out-Null
            { Request-ProcessedTicketClaim -MeTicketId 'claim-2' -Entry @{ action = 'Grant' } } | Should -Not -Throw
        }

        It 'writes the entry that won the claim so Get-ProcessedTickets can see it' {
            Request-ProcessedTicketClaim -MeTicketId 'claim-3' -Entry @{ action = 'Grant'; role = 'Owner' } | Out-Null
            $store = Get-ProcessedTickets
            $store.ContainsKey('claim-3') | Should -BeTrue
            $store['claim-3'].role | Should -Be 'Owner'
        }
    }

    It 'skips a corrupt file, warns naming it, and still loads the others' {
        Save-ProcessedTicket -MeTicketId 'good-1' -Entry @{ action = 'Grant' }
        Save-ProcessedTicket -MeTicketId 'good-2' -Entry @{ action = 'Grant' }

        $badPath = Get-ProcessedTicketFilePath -MeTicketId 'bad-1'
        Set-Content -LiteralPath $badPath -Value 'not json at all' -Encoding UTF8

        $warnings = @()
        $store = Get-ProcessedTickets -WarningVariable warnings -WarningAction SilentlyContinue

        $store.Count | Should -Be 2
        $store.ContainsKey('good-1') | Should -BeTrue
        $store.ContainsKey('good-2') | Should -BeTrue
        ($warnings -join ' ') | Should -Match ([regex]::Escape($badPath))
    }

    It 'skips a file whose JSON is valid but missing the meTicketId field' {
        Save-ProcessedTicket -MeTicketId 'good' -Entry @{ action = 'Grant' }
        $orphanPath = Join-Path (Split-Path (Get-ProcessedTicketFilePath -MeTicketId 'good') -Parent) 'orphan.json'
        '{"action":"Grant"}' | Set-Content -LiteralPath $orphanPath -Encoding UTF8

        $store = Get-ProcessedTickets -WarningAction SilentlyContinue
        $store.Count | Should -Be 1
        $store.ContainsKey('good') | Should -BeTrue
    }

    Context 'concurrency -- the load-bearing tests' {

        It 'lets exactly one of N contenders win Request-ProcessedTicketClaim on the same id' {
            $sentinelFile = Join-Path $TestDrive "start-$([guid]::NewGuid().ToString('N')).signal"
            $resultDir = Join-Path $TestDrive "results-$([guid]::NewGuid().ToString('N'))"
            New-Item -ItemType Directory -Path $resultDir -Force | Out-Null
            $contenderCount = 8

            $jobs = 1..$contenderCount | ForEach-Object {
                $index = $_
                Start-Job -ScriptBlock {
                    param($storeFile, $module, $sentinel, $resultDir, $index)
                    . $module
                    Initialize-ProcessedStore -Path $storeFile
                    while (-not (Test-Path $sentinel)) { Start-Sleep -Milliseconds 5 }
                    $won = Request-ProcessedTicketClaim -MeTicketId 'contended-ticket' -Entry @{ winner = $index }
                    Set-Content -LiteralPath (Join-Path $resultDir "$index.txt") -Value "$won" -Encoding UTF8
                } -ArgumentList $script:StorePath, $script:ModulePath, $sentinelFile, $resultDir, $index
            }

            $deadline = (Get-Date).AddSeconds(60)
            while (@($jobs | Where-Object { $_.State -ne 'Running' }).Count -gt 0) {
                if ((Get-Date) -gt $deadline) { throw 'Jobs did not reach the Running state in time.' }
                Start-Sleep -Milliseconds 20
            }
            New-Item -Path $sentinelFile -ItemType File -Force | Out-Null

            $jobs | Wait-Job -Timeout 120 | Out-Null
            $jobs | Receive-Job | Out-Null
            $jobs | Remove-Job -Force

            $results = Get-ChildItem -Path $resultDir -Filter '*.txt' | ForEach-Object { (Get-Content -Raw $_.FullName).Trim() }
            $results.Count | Should -Be $contenderCount
            @($results | Where-Object { $_ -eq 'True' }).Count | Should -Be 1
            @($results | Where-Object { $_ -eq 'False' }).Count | Should -Be ($contenderCount - 1)

            (Get-ProcessedTickets).ContainsKey('contended-ticket') | Should -BeTrue
        }

        It 'lets N contenders each claim a DIFFERENT id with no lost entries' {
            $sentinelFile = Join-Path $TestDrive "start-$([guid]::NewGuid().ToString('N')).signal"
            $contenderCount = 8

            $jobs = 1..$contenderCount | ForEach-Object {
                $index = $_
                Start-Job -ScriptBlock {
                    param($storeFile, $module, $sentinel, $index)
                    . $module
                    Initialize-ProcessedStore -Path $storeFile
                    while (-not (Test-Path $sentinel)) { Start-Sleep -Milliseconds 5 }
                    Request-ProcessedTicketClaim -MeTicketId "distinct-$index" -Entry @{ winner = $index } | Out-Null
                } -ArgumentList $script:StorePath, $script:ModulePath, $sentinelFile, $index
            }

            $deadline = (Get-Date).AddSeconds(60)
            while (@($jobs | Where-Object { $_.State -ne 'Running' }).Count -gt 0) {
                if ((Get-Date) -gt $deadline) { throw 'Jobs did not reach the Running state in time.' }
                Start-Sleep -Milliseconds 20
            }
            New-Item -Path $sentinelFile -ItemType File -Force | Out-Null

            $jobs | Wait-Job -Timeout 120 | Out-Null
            $jobs | Receive-Job | Out-Null
            $jobs | Remove-Job -Force

            $store = Get-ProcessedTickets
            $store.Count | Should -Be $contenderCount
            1..$contenderCount | ForEach-Object {
                $store.ContainsKey("distinct-$_") | Should -BeTrue
            }
        }
    }

    Context 'migration from the legacy single-file store' {

        BeforeEach {
            $script:LegacyId1 = 'legacy-a'
            $script:LegacyId2 = 'legacy-b'
            $script:LegacyPath = Join-Path $TestDrive "legacy-$([guid]::NewGuid().ToString('N')).json"
            $legacyJson = @{
                $LegacyId1 = @{ meTicketId = $LegacyId1; action = 'Grant'; role = 'Reader' }
                $LegacyId2 = @{ meTicketId = $LegacyId2; action = 'Eligible'; role = 'Contributor' }
            } | ConvertTo-Json -Depth 8
            Set-Content -LiteralPath $script:LegacyPath -Value $legacyJson -Encoding UTF8
        }

        It 'produces a per-ticket file for every legacy entry with correct keys and values' {
            Initialize-ProcessedStore -Path $script:LegacyPath
            $store = Get-ProcessedTickets
            $store.Count | Should -Be 2
            $store[$LegacyId1].action | Should -Be 'Grant'
            $store[$LegacyId1].role | Should -Be 'Reader'
            $store[$LegacyId2].action | Should -Be 'Eligible'
            $store[$LegacyId2].role | Should -Be 'Contributor'
        }

        It 'renames the legacy file aside instead of leaving or deleting it' {
            Initialize-ProcessedStore -Path $script:LegacyPath
            Test-Path -LiteralPath $script:LegacyPath | Should -BeFalse
            $renamed = @(Get-ChildItem -Path (Split-Path $script:LegacyPath -Parent) -Filter '*.migrated-*')
            $renamed.Count | Should -BeGreaterThan 0
        }

        It 'is a no-op on a second Initialize-ProcessedStore call with the same path' {
            Initialize-ProcessedStore -Path $script:LegacyPath
            $store1 = Get-ProcessedTickets

            Initialize-ProcessedStore -Path $script:LegacyPath
            $store2 = Get-ProcessedTickets

            $store2.Count | Should -Be $store1.Count
            $store2[$LegacyId1].action | Should -Be 'Grant'
        }

        It 'does not clobber a per-ticket file that already exists and is newer than the legacy snapshot' {
            Initialize-ProcessedStore -Path $script:LegacyPath
            # Simulate a write that happened after migration but before some later re-run.
            Save-ProcessedTicket -MeTicketId $LegacyId1 -Entry @{ action = 'Grant'; role = 'Owner'; revoked = $true }

            # Re-create a legacy file with the OLD values and run migration again -- the
            # newer per-ticket file must win.
            $legacyJsonAgain = @{ $LegacyId1 = @{ meTicketId = $LegacyId1; action = 'Grant'; role = 'Reader' } } | ConvertTo-Json -Depth 8
            Set-Content -LiteralPath $script:LegacyPath -Value $legacyJsonAgain -Encoding UTF8
            Initialize-ProcessedStore -Path $script:LegacyPath

            (Get-ProcessedTickets)[$LegacyId1].role | Should -Be 'Owner'
        }

        It 'leaves a corrupt legacy file in place, unrenamed, and warns' {
            Set-Content -LiteralPath $script:LegacyPath -Value 'not json at all' -Encoding UTF8
            # -WarningVariable assigns in the invocation's own scope, so it must be the
            # outermost statement rather than inside a { } passed to Should -Not -Throw --
            # a script block runs in a child scope and the assignment would not be visible
            # here.
            $warnings = @()
            { Initialize-ProcessedStore -Path $script:LegacyPath } | Should -Not -Throw
            Initialize-ProcessedStore -Path $script:LegacyPath -WarningVariable warnings -WarningAction SilentlyContinue
            Test-Path -LiteralPath $script:LegacyPath | Should -BeTrue
            ($warnings -join ' ') | Should -Match 'failed to parse'
            # $TestDrive is shared across every It in this file, so filter to files derived
            # from THIS test's legacy path -- other migration tests' .migrated-* files also
            # live alongside it.
            $legacyDir = Split-Path $script:LegacyPath -Parent
            $legacyLeaf = Split-Path $script:LegacyPath -Leaf
            @(Get-ChildItem -Path $legacyDir -Filter "$legacyLeaf.migrated-*").Count | Should -Be 0
        }
    }

    Context 'atomic write -- must genuinely discriminate a broken implementation' {

        It 'throws when the destination cannot be replaced, leaving the prior record byte-identical and no tmp residue' {
            Save-ProcessedTicket -MeTicketId 'locked-1' -Entry @{ action = 'Eligible'; tag = 'original' }
            $destPath = Get-ProcessedTicketFilePath -MeTicketId 'locked-1'
            $originalBytes = [System.IO.File]::ReadAllBytes($destPath)
            $dir = Split-Path $destPath -Parent

            $lockStream = [System.IO.File]::Open($destPath, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None)
            try {
                { Save-ProcessedTicket -MeTicketId 'locked-1' -Entry @{ action = 'Grant'; tag = 'new' } } | Should -Throw
            }
            finally {
                $lockStream.Dispose()
            }

            $afterBytes = [System.IO.File]::ReadAllBytes($destPath)
            [System.Convert]::ToBase64String($afterBytes) | Should -Be ([System.Convert]::ToBase64String($originalBytes))
            @(Get-ChildItem -Path $dir -Filter '*.tmp').Count | Should -Be 0
        }

        It 'never writes to the destination in place -- content only ever arrives by rename' {
            # Atomicity is a claim about the HISTORY of filesystem operations, not just the
            # end state: a truncate-in-place replace (Copy-Item onto an existing destination)
            # lands on the correct final bytes just like a real atomic rename does, so a test
            # that only inspects content after the call returns cannot tell them apart. Two
            # techniques were tried and rejected before this one: (1) a concurrent reader
            # thread polling the destination -- on this host, opening the file from a second
            # thread at high frequency perturbs Windows' own rename/replace call often enough
            # to fail even the genuinely correct implementation (confirmed by running the
            # identical loop with no reader at all -- zero failures), an artifact of this
            # machine's filesystem filter/AV stack, not of the code under test; (2) also
            # asserting zero Deleted notifications for the destination's name -- on pwsh
            # (Core), the legitimate single-syscall File.Move(overwrite) empirically also
            # raises a Deleted notification for the old directory entry (an NTFS journal
            # characteristic of MoveFileEx REPLACE_EXISTING, confirmed by re-running this
            # exact watcher against unmodified production code), so that check produced a
            # false failure against CORRECT code and was dropped. A Changed notification, by
            # contrast, only ever fires when a handle writes into the destination's own bytes
            # in place -- confirmed absent for real atomic replaces on both hosts, and present
            # for the Copy-Item mutation on both hosts -- so it is the one filesystem-level
            # signal here that reliably discriminates truncate-in-place without also flagging
            # legitimate renames.
            $dir = Get-ProcessedStoreDir
            $destPath = Join-Path $dir 'atomicity-probe.json'
            [System.IO.File]::WriteAllBytes($destPath, [System.Text.Encoding]::UTF8.GetBytes('{"v":0}'))

            $events = New-Object System.Collections.Concurrent.ConcurrentBag[string]
            $watcher = New-Object System.IO.FileSystemWatcher($dir)
            $watcher.Filter = [System.IO.Path]::GetFileName($destPath)
            $watcher.NotifyFilter = [System.IO.NotifyFilters]::LastWrite -bor [System.IO.NotifyFilters]::Size -bor [System.IO.NotifyFilters]::FileName
            $subChanged = Register-ObjectEvent -InputObject $watcher -EventName Changed -Action {
                param($s, $e) $Event.MessageData.Add("Changed:$($e.FullPath)")
            } -MessageData $events
            $watcher.EnableRaisingEvents = $true

            try {
                1..3 | ForEach-Object {
                    $tmp = Join-Path $dir ("$([guid]::NewGuid().ToString('N')).tmp")
                    [System.IO.File]::WriteAllBytes($tmp, [System.Text.Encoding]::UTF8.GetBytes("{`"v`":$_}"))
                    Set-ProcessedTicketFileAtomic -TempPath $tmp -DestPath $destPath
                }
                Start-Sleep -Milliseconds 300
            }
            finally {
                Unregister-Event -SourceIdentifier $subChanged.Name -ErrorAction SilentlyContinue
                $watcher.Dispose()
            }

            @($events).Count | Should -Be 0
        }

        It 'never uses the Move-Item or Copy-Item cmdlets for the swap -- only File.Move/File.Replace' {
            # Move-Item -Force on the PowerShell FileSystem provider is delete-then-rename,
            # not atomic; Copy-Item truncates the destination in place. Both are explicitly
            # banned by this function's own design (see its doc comment). On Windows, a
            # legitimate single MoveFileEx/ReplaceFile call and a naive delete+rename can
            # produce indistinguishable directory-change notifications to an external watcher
            # (both surface Deleted+Renamed -- confirmed empirically against this exact host,
            # see the test above), so runtime observation alone cannot reliably prove the ban
            # is upheld without flaking on Windows-specific NTFS journal behaviour unrelated
            # to the code under test. Enforce the ban at the source level instead: the
            # function must reach its result exclusively through the static File.Move /
            # File.Replace APIs.
            # Strip the block comment first -- its prose explains, by name, exactly which
            # cmdlets are banned and why, which would otherwise make this check match its
            # own documentation.
            $atomicSource = (Get-Command Set-ProcessedTicketFileAtomic).ScriptBlock.ToString() -replace '(?s)<#.*?#>', ''
            $atomicSource | Should -Not -Match '\bMove-Item\b'
            $atomicSource | Should -Not -Match '\bCopy-Item\b'
        }

        It 'takes the branch matching the host PSEdition, not the other one' {
            # Nothing else in this suite pins WHICH branch of Set-ProcessedTicketFileAtomic
            # ran -- both produce a correct replace on Windows, so a passing round-trip test
            # does not prove the PSEdition guard itself is intact. Breakpoint actions fire
            # deterministically on the exact line, unlike timing-based detection.
            $moduleLines = Get-Content -LiteralPath $script:ModulePath
            $coreLine = 1 + ([array]::IndexOf($moduleLines, ($moduleLines | Where-Object { $_ -match '\[System\.IO\.File\]::Move\(\$TempPath, \$DestPath, \$true\)' } | Select-Object -First 1)))
            $desktopTryLine = 1 + ([array]::IndexOf($moduleLines, ($moduleLines | Where-Object { $_ -match '\[System\.IO\.File\]::Move\(\$TempPath, \$DestPath\)$' } | Select-Object -First 1)))
            $coreLine | Should -BeGreaterThan 0
            $desktopTryLine | Should -BeGreaterThan 0

            $script:coreHit = $false
            $script:desktopHit = $false
            $bpCore = Set-PSBreakpoint -Script $script:ModulePath -Line $coreLine -Action { $script:coreHit = $true; continue }
            $bpDesktop = Set-PSBreakpoint -Script $script:ModulePath -Line $desktopTryLine -Action { $script:desktopHit = $true; continue }

            try {
                Save-ProcessedTicket -MeTicketId 'edition-probe' -Entry @{ action = 'Grant' }
            }
            finally {
                Remove-PSBreakpoint -Id $bpCore.Id, $bpDesktop.Id -ErrorAction SilentlyContinue
            }

            if ($PSVersionTable.PSEdition -eq 'Core') {
                $script:coreHit | Should -BeTrue
                $script:desktopHit | Should -BeFalse
            }
            else {
                $script:coreHit | Should -BeFalse
                $script:desktopHit | Should -BeTrue
            }
        }
    }

    Context 'reading while a claim is in flight (Important 4)' {

        It 'retries a sharing violation instead of reporting it as corruption' {
            $id = 'inflight-1'
            $destPath = Get-ProcessedTicketFilePath -MeTicketId $id
            $bytes = [System.Text.Encoding]::UTF8.GetBytes('{"meTicketId":"inflight-1","action":"Grant"}')

            # Hold the file open exclusively (as Request-ProcessedTicketClaim does between
            # CreateNew and the write completing) on a background thread, release it after a
            # short delay, and confirm the foreground read waited it out instead of reporting
            # a corruption warning for a file that provably was never corrupt.
            $sentinelPath = Join-Path $TestDrive "inflight-sentinel-$([guid]::NewGuid().ToString('N')).signal"
            $rs = [runspacefactory]::CreateRunspace()
            $rs.Open()
            $ps = [powershell]::Create()
            $ps.Runspace = $rs
            [void]$ps.AddScript({
                param($path, $bytes, $sentinelPath)
                $stream = [System.IO.File]::Open($path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
                # Signal only after CreateNew has genuinely happened, so the foreground
                # never calls Get-ProcessedTickets before the file exists -- that would just
                # make it invisible to the directory listing, not exercise the retry path
                # this test is for.
                New-Item -Path $sentinelPath -ItemType File -Force | Out-Null
                Start-Sleep -Milliseconds 60
                $stream.Write($bytes, 0, $bytes.Length)
                $stream.Flush()
                $stream.Dispose()
            }).AddArgument($destPath).AddArgument($bytes).AddArgument($sentinelPath)
            $handle = $ps.BeginInvoke()

            $deadline = (Get-Date).AddSeconds(10)
            while (-not (Test-Path -LiteralPath $sentinelPath)) {
                if ((Get-Date) -gt $deadline) { throw 'Background claim never signaled readiness.' }
                Start-Sleep -Milliseconds 5
            }

            $warnings = @()
            $store = Get-ProcessedTickets -WarningVariable warnings -WarningAction SilentlyContinue

            [void]$ps.EndInvoke($handle)
            $ps.Dispose()
            $rs.Close()

            $store.ContainsKey($id) | Should -BeTrue
            ($warnings -join ' ') | Should -Not -Match 'failed to load'
        }
    }

    Context 'store directory removed after initialization (Important 5)' {

        It 'warns loudly instead of quietly returning an empty map' {
            Remove-Item -LiteralPath (Get-ProcessedStoreDir) -Recurse -Force
            $warnings = @()
            $store = Get-ProcessedTickets -WarningVariable warnings -WarningAction SilentlyContinue
            $store.Count | Should -Be 0
            ($warnings -join ' ') | Should -Match 'does not exist'
        }
    }

    Context 'Get-ProcessedStoreDir with a bare relative filename (Minor)' {

        It 'falls back to the current directory instead of throwing' {
            Push-Location $TestDrive
            try {
                { Initialize-ProcessedStore -Path 'bare-store.json' } | Should -Not -Throw
            }
            finally {
                Pop-Location
            }
        }
    }

    Context 'encoding -- both write paths must agree (Minor)' {

        It 'writes BOM-less UTF-8 from both Save-ProcessedTicket and Request-ProcessedTicketClaim' {
            Save-ProcessedTicket -MeTicketId 'enc-save' -Entry @{ action = 'Grant' }
            Request-ProcessedTicketClaim -MeTicketId 'enc-claim' -Entry @{ action = 'Grant' } | Out-Null

            $bom = [byte[]](0xEF, 0xBB, 0xBF)
            foreach ($id in @('enc-save', 'enc-claim')) {
                $bytes = [System.IO.File]::ReadAllBytes((Get-ProcessedTicketFilePath -MeTicketId $id))
                $hasBom = $bytes.Length -ge 3 -and $bytes[0] -eq $bom[0] -and $bytes[1] -eq $bom[1] -and $bytes[2] -eq $bom[2]
                $hasBom | Should -BeFalse
            }
        }
    }
}
