BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    $script:Runbook = Join-Path $repoRoot 'src\Runbooks\Runbook-Sandbox-PIM.ps1'

    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force

    $script:SandboxSub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    $script:Allowlist = @($script:SandboxSub)
    $script:ReaderRole = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'

    function New-SandboxTicket {
        return @{
            TicketId        = [guid]::NewGuid().ToString()
            Role            = 'Reader'
            Environment     = 'Sandbox'
            SubscriptionId  = $script:SandboxSub
            SubscriptionName = 'platform-sandbox'
            ResourceScope   = "/subscriptions/$($script:SandboxSub)"
            DurationDays    = 7
            Priority        = 'P3'
            RequesterUpn    = 'test.user@contoso.com'
            SubmitterUpn    = 'test.user@contoso.com'
            Justification   = 'Sandbox engineering access'
        }
    }

    function Invoke-SandboxRunbook {
        return & $script:Runbook -Ticket (New-SandboxTicket) `
            -SubscriptionAllowlist $script:Allowlist -PimClientImplementation 'Mock'
    }

    function New-SandboxTicketWith {
        param([hashtable]$Override = @{})
        $ticket = New-SandboxTicket
        foreach ($k in $Override.Keys) { $ticket[$k] = $Override[$k] }
        return $ticket
    }

    function Invoke-SandboxRunbookWith {
        param([hashtable]$Override = @{})
        return & $script:Runbook -Ticket (New-SandboxTicketWith -Override $Override) `
            -SubscriptionAllowlist $script:Allowlist -PimClientImplementation 'Mock'
    }
}

Describe 'Runbook-Sandbox-PIM group-first grant' {
    BeforeEach {
        Reset-MockPimState
        Mock Import-Module {}
    }

    It 'fulfils through group membership when the group and IAM assignment exist' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -Groups @([pscustomobject]@{ id = 'sandbox-readers'; displayName = 'sg-platform-sandbox-uaen-readers' }) `
            -RoleAssignments @([pscustomobject]@{
                    principalId = 'sandbox-readers'
                    roleDefinitionId = $script:ReaderRole
                    scope = "/subscriptions/$($script:SandboxSub)"
                }) `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $result = Invoke-SandboxRunbook

        $result.Success | Should -Be $true
        $result.Fulfilment | Should -Be 'Group'
        $result.GroupId | Should -Be 'sandbox-readers'
        $result.AssignmentId | Should -BeNullOrEmpty
        $result.EngineerActionRequired | Should -Be $false
        @(Get-EntraGroupMembers -Client $global:SandboxRunbookSeededClient -GroupId 'sandbox-readers') |
            Should -Contain '11111111-1111-1111-1111-111111111111'
    }

    It 'creates the canonical group and IAM when no group exists' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $result = Invoke-SandboxRunbook

        $result.Success | Should -Be $true
        $result.Fulfilment | Should -Be 'Group'
        $result.GroupCreated | Should -Be $true
        $result.RoleAssignmentCreated | Should -Be $true
        $result.GroupName | Should -Be 'sg-platform-sandbox-readers'
        $result.AssignmentId | Should -BeNullOrEmpty
        $result.EngineerActionRequired | Should -Be $false
        $result.ExpiresAt | Should -BeNullOrEmpty
        @(Get-EntraGroupMembers -Client $global:SandboxRunbookSeededClient -GroupId $result.GroupId) |
            Should -Contain '11111111-1111-1111-1111-111111111111'
    }
}

Describe 'Runbook-Sandbox-PIM — resource-scoped roles bypass the group path' {
    BeforeEach {
        Reset-MockPimState
        Mock Import-Module {}
    }

    It 'fulfils a Storage data role via a direct PIM assignment' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $scope = "/subscriptions/$($script:SandboxSub)/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        $result = Invoke-SandboxRunbookWith -Override @{
            Role          = 'Storage Blob Data Reader'
            ResourceScope = $scope
            Justification = 'Sandbox blob read access'
        }

        $result.Success | Should -Be $true
        $result.Fulfilment | Should -Be 'DirectPim'
        $result.AssignmentType | Should -Be 'Active'
        $result.GroupId | Should -BeNullOrEmpty
        $result.GroupCreated | Should -Be $false
        $result.RoleAssignmentCreated | Should -Be $false
        $result.EngineerActionRequired | Should -Be $false
        $result.AssignmentId | Should -Not -BeNullOrEmpty
        $result.Scope | Should -Be $scope
        $result.ExpiresAt | Should -Not -BeNullOrEmpty

        # The grant must land at the resource scope, not the subscription.
        @(Get-ActiveAssignments -Client $global:SandboxRunbookSeededClient `
            -UserId '11111111-1111-1111-1111-111111111111' `
            -RoleDefinitionId '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1' `
            -Scope $scope).Count | Should -Be 1
    }

    It 'fulfils an AKS data-plane role via a direct PIM assignment' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $scope = "/subscriptions/$($script:SandboxSub)/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        $result = Invoke-SandboxRunbookWith -Override @{
            Role          = 'Azure Kubernetes Service RBAC Reader'
            ResourceScope = $scope
            Justification = 'Sandbox cluster read access'
        }

        $result.Success | Should -Be $true
        $result.Fulfilment | Should -Be 'DirectPim'
        $result.Scope | Should -Be $scope
    }

    It 'still uses the group path for subscription-scoped Contributor' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        $result = Invoke-SandboxRunbookWith -Override @{ Role = 'Contributor' }

        $result.Fulfilment | Should -Be 'Group'
        $result.GroupName | Should -Be 'sg-platform-sandbox-contributors'
    }

    It 'fails closed for a role absent from the catalog' {
        $global:SandboxRunbookSeededClient = New-MockPimClient `
            -SubscriptionNames @{ $script:SandboxSub = 'platform-sandbox' }
        Mock New-MockPimClient { $global:SandboxRunbookSeededClient }

        # Schema validation (Resolve-RbacDecision step 1) already rejects an unknown role
        # before this runbook's scope-type gate is ever reached, so the observable outcome
        # is a non-throwing Reject rather than an exception — either way, nothing is granted.
        $result = Invoke-SandboxRunbookWith -Override @{ Role = 'Totally Made Up Role' }
        $result.Success | Should -Be $false
        $result.Decision.Action | Should -Be 'Reject'
    }
}
