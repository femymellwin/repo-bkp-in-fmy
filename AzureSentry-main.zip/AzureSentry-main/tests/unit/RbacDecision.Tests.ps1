BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

    $script:SandboxSub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    $script:ProdSub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    $script:Allowlist = @($script:SandboxSub, $script:ProdSub)

    function New-TestTicket {
        param(
            [string]$Environment = 'Sandbox',
            [string]$Role = 'Reader',
            [string]$Priority = 'P3',
            [int]$DurationDays = 7,
            [string]$Justification = '',
            [hashtable]$Extra = @{}
        )

        $ticket = @{
            TicketId       = [guid]::NewGuid().ToString()
            Role           = $Role
            Environment    = $Environment
            SubscriptionId = if ($Environment -eq 'Sandbox') { $script:SandboxSub } else { $script:ProdSub }
            ResourceScope  = "/subscriptions/$(if ($Environment -eq 'Sandbox') { $script:SandboxSub } else { $script:ProdSub })"
            DurationDays   = $DurationDays
            Priority       = $Priority
            RequesterUpn   = 'test.user@contoso.com'
            SubmitterUpn   = 'test.user@contoso.com'
            Justification  = $Justification
        }
        foreach ($k in $Extra.Keys) { $ticket[$k] = $Extra[$k] }
        if ($Environment -eq 'Production' -and [string]::IsNullOrWhiteSpace($ticket.Justification)) {
            $ticket.Justification = 'Production access for sprint work item 12345'
        }
        return $ticket
    }
}

Describe 'Resolve-RbacDecision — §2.2 eligibility matrix' {
    It 'sandbox-reader — Full Auto Grant' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Role Reader) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
        $d.Runbook | Should -Be 'Runbook-Sandbox-PIM'
    }

    It 'sandbox-contributor — Full Auto Grant' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Role Contributor) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
    }

    It 'sandbox-owner — Policy Reject' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Role Owner) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }

    It 'prod-reader-standard — Grant (no approval)' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role Reader -Priority P4) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Runbook | Should -Be 'Runbook-Sandbox-PIM'
        $d.Path | Should -Be 'Production-Reader-FullAuto'
    }

    It 'prod-reader-expedited — Grant (no approval)' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role Reader -Priority P1) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Runbook | Should -Be 'Runbook-Sandbox-PIM'
        $d.Path | Should -Be 'Production-Reader-FullAuto'
    }

    It 'nonprod-contributor -- Grant (auto, operator decision 2026-08-21)' {
        # Changed from Eligible/single-approver: Contributor is the bulk of Non-Prod
        # demand, and grants are now time-bound with a reaper that revokes on expiry,
        # so a wrong grant self-revokes instead of persisting.
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment NonProd -Role Contributor -Priority P3 -Justification 'NonProd contributor access for sprint work item 12345') -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Runbook | Should -Be 'Runbook-Sandbox-PIM'
        $d.Path | Should -Be 'NonProd-FullAuto'
        $d.ApproverTier | Should -BeNullOrEmpty -Because 'a Grant has no approver'
    }

    It 'prod-contributor-standard — Eligible P3' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role Contributor -Priority P3) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-Standard'
    }

    It 'prod-contributor-expedited — Eligible P2 with on-call' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role Contributor -Priority P2) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-Expedited'
        $d.NotifyOnCall | Should -Be $true
        $d.SlaHours | Should -Be 8
    }

    It 'prod-owner-dual — Dual approval' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role Owner -Priority P3) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-DualApproval'
        $d.ApproverTier | Should -Be 'Dual'
        $d.MfaRequired | Should -Be $true
    }

    It 'prod-uaa-dual — Dual approval' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role UAA -Priority P4) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.ApproverTier | Should -Be 'Dual'
    }

    It 'emergency-contributor-p1 — BreakGlass' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role Contributor -Priority P1 -Extra @{ BreakGlass = $true }) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'BreakGlass'
        $d.Path | Should -Be 'Emergency-BreakGlass'
        $d.Runbook | Should -Be 'Runbook-Emergency-PIM'
    }

    It 'emergency-owner-p1 — Reject escalate' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role Owner -Priority P1 -Extra @{ BreakGlass = $true }) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Emergency-Escalate'
    }

    It 'emergency-owner-p1-reject — UAA (Owner tier) break-glass escalates rather than granting' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Environment Production -Role UAA -Priority P1 -Extra @{ BreakGlass = $true }) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Emergency-Escalate'
    }

    It 'emergency-owner-p1-reject — Storage Blob Data Owner (Owner tier) break-glass escalates rather than granting' {
        $t = New-TestTicket -Environment Production -Role 'Storage Blob Data Owner' -Priority P1 -Extra @{
            BreakGlass    = $true
            ResourceScope = "/subscriptions/$script:ProdSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Emergency-Escalate'
    }

    It 'emergency-contributor-p1 — AKS RBAC Admin (Contributor tier) break-glass grants' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Admin' -Priority P1 -Extra @{
            BreakGlass    = $true
            ResourceScope = "/subscriptions/$script:ProdSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'BreakGlass'
        $d.Path | Should -Be 'Emergency-BreakGlass'
        $d.Runbook | Should -Be 'Runbook-Emergency-PIM'
    }

    It 'custom-role — Hold' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Role Custom) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Hold'
        $d.Path | Should -Be 'Governance-Review'
    }

    It 'bulk-request — Hold' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Extra @{ UserCount = 10 }) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Hold'
    }

    It 'cross-subscription-prod — Senior approver' {
        $t = New-TestTicket -Environment Production -Role Reader -Priority P3
        $t.SubscriptionIds = @($script:ProdSub, 'cccccccc-cccc-cccc-cccc-cccccccccccc')
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist ($script:Allowlist + 'cccccccc-cccc-cccc-cccc-cccccccccccc')
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-CrossSubscription'
        $d.ApproverTier | Should -Be 'Senior'
    }
}

Describe 'Resolve-RbacDecision — reject paths (fail closed)' {
    It 'rejects missing required fields' {
        $d = Resolve-RbacDecision -Ticket @{ Role = 'Reader' } -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    It 'allows missing Environment through schema validation' {
        $t = New-TestTicket -Environment Sandbox -Role Reader
        $t.Environment = ''
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Path | Should -Not -Be 'Schema-Invalid'
    }

    It 'still rejects an invalid Environment value' {
        $t = New-TestTicket -Environment Sandbox -Role Reader
        $t.Environment = 'Staging'
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        $d.Reason | Should -Match 'Invalid environment'
    }

    It 'infers Environment from subscription sensitivity when the ticket omits it' {
        $sandbox = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
        $t = New-TestTicket -Environment Sandbox -Role Reader
        $t.Environment = ''
        $t.SubscriptionId = $sandbox
        $t.ResourceScope = "/subscriptions/$sandbox"
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist @($sandbox)
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
        $d.EffectiveEnvironment | Should -Be 'Sandbox'
    }

    It 'rejects subscription not on allowlist' {
        # ResourceScope must move with SubscriptionId: schema validation now requires the
        # scope to sit inside a declared subscription, so leaving the scope on the sandbox
        # sub would reject at Schema-Invalid and never exercise the allowlist gate.
        $t = New-TestTicket
        $t.SubscriptionId = 'ffffffff-ffff-ffff-ffff-ffffffffffff'
        $t.ResourceScope = '/subscriptions/ffffffff-ffff-ffff-ffff-ffffffffffff'
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Allowlist-Reject'
    }

    It 'rejects duration over 90 days' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -DurationDays 91) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
    }

    It 'rejects production without justification' {
        $t = New-TestTicket -Environment Production
        $t.Justification = 'abc'  # under minJustificationLength (4)
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
    }

    It 'rejects requester/submitter mismatch (G1)' {
        $t = New-TestTicket
        $t.SubmitterUpn = 'other.user@contoso.com'
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Reason | Should -Match 'submitter'
    }

    It 'rejects duplicate assignment (step 7)' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket) -SubscriptionAllowlist $script:Allowlist -HasExistingAssignment $true
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Duplicate-Assignment'
    }

    It 'rejects sandbox UAA' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Role UAA) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }
}

Describe 'Resolve-RbacDecision — expanded role schema validation' {
    It 'accepts a resource-scoped Storage role at a storage account scope' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Reader' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Path | Should -Not -Be 'Schema-Invalid'
    }

    It 'accepts a resource-scoped AKS role at a managed cluster scope' {
        $t = New-TestTicket -Environment Sandbox -Role 'Azure Kubernetes Service RBAC Reader' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Path | Should -Not -Be 'Schema-Invalid'
    }

    It 'rejects a resource-scoped role requested at bare subscription scope' {
        # New-TestTicket defaults ResourceScope to /subscriptions/<id> only.
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor'
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        $d.Reason | Should -Match 'Microsoft.Storage/storageAccounts'
    }

    It 'rejects a resource-scoped role pointed at the wrong resource type' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    It 'still rejects a role absent from the catalog' {
        $t = New-TestTicket -Environment Sandbox -Role 'Totally Made Up Role'
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        $d.Reason | Should -Match 'Invalid role'
    }

    It 'still accepts subscription-scoped classic roles at subscription scope' {
        $d = Resolve-RbacDecision -Ticket (New-TestTicket -Role Reader) -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
    }
}

Describe 'Resolve-RbacDecision — Owner-tier roles blocked below Production' {
    It 'rejects Storage Blob Data Owner in Sandbox' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Owner' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }

    It 'rejects AKS RBAC Cluster Admin in Sandbox' {
        $t = New-TestTicket -Environment Sandbox -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }

    It 'rejects AKS RBAC Cluster Admin in NonProd' {
        $t = New-TestTicket -Environment NonProd -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Justification 'NonProd cluster admin for sprint work item 12345' -Extra @{
            ResourceScope = "/subscriptions/$script:ProdSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Policy-Block'
    }
}

Describe 'Resolve-RbacDecision — new roles route by tier' {
    BeforeAll {
        $script:StorageScope = "/subscriptions/$script:ProdSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        $script:AksScope     = "/subscriptions/$script:ProdSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        $script:SbxStorage   = "/subscriptions/$script:SandboxSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        $script:SbxAks       = "/subscriptions/$script:SandboxSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
    }

    It 'grants Reader-tier Storage role in Sandbox like Reader' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Reader' -Extra @{ ResourceScope = $script:SbxStorage }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
    }

    It 'grants Reader-tier AKS role in Production like Reader' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Reader' -Priority P4 -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Production-Reader-FullAuto'
    }

    It 'grants Contributor-tier Storage role in Sandbox (auto)' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{ ResourceScope = $script:SbxStorage }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
    }

    It 'gates Contributor-tier Storage role in Production P3 behind single approval' {
        $t = New-TestTicket -Environment Production -Role 'Storage Blob Data Contributor' -Priority P3 -Extra @{ ResourceScope = $script:StorageScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-Standard'
        $d.ApproverTier | Should -Be 'Primary'
    }

    It 'expedites Contributor-tier AKS Admin in Production P2 with on-call' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Admin' -Priority P2 -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-Expedited'
        $d.NotifyOnCall | Should -Be $true
        $d.SlaHours | Should -Be 8
    }

    It 'auto-grants AKS RBAC Writer in NonProd via the Contributor tier' {
        # Deliberately pinned: AKS RBAC Writer resolves through the Contributor TIER, so
        # flipping nonprod-contributor to Grant auto-grants Writer-tier AKS roles in
        # NonProd as well. If that is ever not wanted, the tier mapping is what to change,
        # not this test.
        $t = New-TestTicket -Environment NonProd -Role 'Azure Kubernetes Service RBAC Writer' -Priority P3 -Justification 'NonProd AKS write access for sprint work item 12345' -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'NonProd-FullAuto'
    }

    It 'grants Reader-tier AKS role in NonProd (auto)' {
        $t = New-TestTicket -Environment NonProd -Role 'Azure Kubernetes Service RBAC Reader' -Justification 'NonProd read access for sprint work item 12345' -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'NonProd-FullAuto'
    }

    It 'requires dual approval and MFA for Owner-tier Storage role in Production' {
        $t = New-TestTicket -Environment Production -Role 'Storage Blob Data Owner' -Priority P3 -Extra @{ ResourceScope = $script:StorageScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-DualApproval'
        $d.ApproverTier | Should -Be 'Dual'
        $d.MfaRequired | Should -Be $true
    }

    It 'requires dual approval for Owner-tier AKS Cluster Admin in Production' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Priority P4 -Extra @{ ResourceScope = $script:AksScope }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-DualApproval'
        $d.ApproverTier | Should -Be 'Dual'
    }
}

Describe 'Resolve-RbacDecision — approver resolution for expanded roles' {
    BeforeAll {
        # This subscription has per-role approver entries in approver-mapping.json.
        $script:MappedProdSub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    }

    It 'falls back to the Contributor tier approvers for a Storage data role' {
        $t = New-TestTicket -Environment Production -Role 'Storage Blob Data Contributor' -Priority P3 -Extra @{
            ResourceScope = "/subscriptions/$script:MappedProdSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $t.SubscriptionId = $script:MappedProdSub
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist @($script:MappedProdSub)
        $d.Action | Should -Be 'Eligible'
        $d.Approvers | Should -Not -BeNullOrEmpty
        $d.Approvers | Should -Contain 'sangeetha.baskaran@inceptionai.ai'
    }

    It 'falls back to the Owner tier approvers for an AKS Cluster Admin role' {
        $t = New-TestTicket -Environment Production -Role 'Azure Kubernetes Service RBAC Cluster Admin' -Priority P3 -Extra @{
            ResourceScope = "/subscriptions/$script:MappedProdSub/resourceGroups/rg-aks/providers/Microsoft.ContainerService/managedClusters/mycluster"
        }
        $t.SubscriptionId = $script:MappedProdSub
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist @($script:MappedProdSub)
        $d.ApproverTier | Should -Be 'Dual'
        $d.Approvers | Should -Not -BeNullOrEmpty
    }

    It 'still prefers an exact role-name approver entry over the tier fallback' {
        $t = New-TestTicket -Environment Production -Role Contributor -Priority P3
        $t.SubscriptionId = $script:MappedProdSub
        $t.ResourceScope = "/subscriptions/$script:MappedProdSub"
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist @($script:MappedProdSub)
        $d.Approvers | Should -Contain 'sangeetha.baskaran@inceptionai.ai'
        $d.Approvers | Should -Contain 'sivasankar.pushpavan@inceptionai.ai'
    }
}

Describe 'Resolve-RbacDecision — resource scope bound to declared subscription (privilege escalation fix)' {
    It 'rejects a resource-scoped role whose ResourceScope names a foreign, non-declared subscription' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = '/subscriptions/99999999-9999-9999-9999-999999999999/resourceGroups/rg-prod/providers/Microsoft.Storage/storageAccounts/prodsecrets'
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        $d.Reason | Should -Match 'not among'
    }

    It 'still grants when the resource-scoped role scope names the same declared subscription' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-data/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
    }

    It 'rejects a subscription-scoped role whose ResourceScope names a foreign, non-declared subscription' {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = '/subscriptions/99999999-9999-9999-9999-999999999999'
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    It 'rejects a bare /resourceGroups/ scope with no subscription' {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = '/resourceGroups/rg-orphan'
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    It 'still allows a cross-subscription ticket whose ResourceScope names one of the declared SubscriptionIds' {
        $t = New-TestTicket -Environment Production -Role Reader -Priority P3
        $t.SubscriptionIds = @($script:ProdSub, $script:SandboxSub)
        $t.ResourceScope = "/subscriptions/$script:SandboxSub"
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Eligible'
        $d.Path | Should -Be 'Production-CrossSubscription'
    }

    # System.Uri collapses '..' when the scope is interpolated into the ARM URL, so a scope
    # that merely STARTS with a declared subscription can still resolve to a foreign one.
    It 'rejects a ResourceScope that traverses out of the declared subscription' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/../99999999-9999-9999-9999-999999999999/resourceGroups/rg-prod/providers/Microsoft.Storage/storageAccounts/prodsecrets"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        # Either guard is a correct rejection; the canonical-form check fires first.
        $d.Reason | Should -Match 'canonical form|relative path segments'
    }

    It 'rejects a ResourceScope containing a single-dot segment' {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/./resourceGroups/rg-data"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        # Either guard is a correct rejection; the canonical-form check fires first.
        $d.Reason | Should -Match 'canonical form|relative path segments'
    }

    It 'rejects a ResourceScope whose subscription segment is not a full GUID' {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = '/subscriptions/not-a-guid/resourceGroups/rg-data'
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    It 'rejects a ResourceScope whose subscription is a prefix-extension of a declared id' {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = "/subscriptions/$($script:SandboxSub)aaaa/resourceGroups/rg-data"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    # Blocklisting traversal spellings loses: System.Uri unescapes %2e before compressing
    # the path, and converts backslashes to separators. Each of these validated clean and
    # still resolved to the foreign subscription at the ARM API before the canonical-form
    # check was added. Table-driven so a new spelling is one line to cover.
    It 'rejects traversal spelling <Name> that would canonicalize into another subscription' -ForEach @(
        @{ Name = 'literal-dotdot';    Payload = '../' }
        @{ Name = 'encoded-lower';     Payload = '%2e%2e/' }
        @{ Name = 'encoded-upper';     Payload = '%2E%2E/' }
        @{ Name = 'half-encoded-tail'; Payload = '.%2e/' }
        @{ Name = 'half-encoded-head'; Payload = '%2e./' }
        @{ Name = 'encoded-separator'; Payload = '..%2f' }
        @{ Name = 'backslash';         Payload = 'x\..\..\subscriptions\' }
    ) {
        $foreign = '99999999-9999-9999-9999-999999999999'
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/$($Payload)$foreign/resourceGroups/rg-prod/providers/Microsoft.Storage/storageAccounts/prodsecrets"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    # Guards the PRIMARY control specifically. The traversal table above is also caught by
    # the '%' / '\' / dot-segment guards, so it cannot prove the canonical-form check is
    # doing anything. These payloads pass every character guard and are rejected ONLY by
    # the canonical-form comparison - delete that check and these two tests fail.
    It 'rejects a ResourceScope that only the canonical-form check can catch (<Name>)' -ForEach @(
        @{ Name = 'trailing-newline'; Suffix = "`n" }
        @{ Name = 'trailing-cr';      Suffix = "`r" }
    ) {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub$Suffix"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
        $d.Reason | Should -Match 'canonical form'
    }

    # Documents an accepted limitation rather than a desired behavior: Uri.AbsolutePath
    # percent-encodes non-ASCII, so a Unicode-named target cannot satisfy the canonical-form
    # check. It fails closed (rejected), never open. Pinned so the trade-off is visible and
    # a future change to it is deliberate.
    It 'rejects a Unicode resource id - accepted limitation, fails closed' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-caf$([char]0xE9)/providers/Microsoft.Storage/storageAccounts/mystorage"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    It 'rejects a ResourceScope with an empty path segment' {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub//resourceGroups/rg-data"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Reject'
        $d.Path | Should -Be 'Schema-Invalid'
    }

    # The character allowlist must not be so strict that it rejects real resource ids:
    # storage account and resource group names legitimately contain dots, underscores,
    # hyphens and parentheses. A dot inside a NAME is not a dot SEGMENT.
    It 'still accepts a legitimate deep resource id containing dots, underscores and parentheses' {
        $t = New-TestTicket -Environment Sandbox -Role 'Storage Blob Data Contributor' -Extra @{
            ResourceScope = "/subscriptions/$script:SandboxSub/resourceGroups/rg-a_b(test)/providers/Microsoft.Storage/storageAccounts/my.stor.acct"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
        $d.Path | Should -Be 'Sandbox-FullAuto'
    }

    It 'still accepts an uppercase subscription id in the scope against a lowercase declared id' {
        $t = New-TestTicket -Environment Sandbox -Role Reader -Extra @{
            ResourceScope = "/subscriptions/$($script:SandboxSub.ToUpper())"
        }
        $d = Resolve-RbacDecision -Ticket $t -SubscriptionAllowlist $script:Allowlist
        $d.Action | Should -Be 'Grant'
    }
}
