BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
    $script:CatalogPath = Join-Path $repoRoot 'src\RbacDecision\Data\role-catalog.json'
}

Describe 'role-catalog.json integrity' {
    BeforeAll {
        $script:Catalog = Get-Content -Raw -Path $script:CatalogPath | ConvertFrom-Json
        $script:RoleNames = @($script:Catalog.PSObject.Properties.Name | Where-Object { -not $_.StartsWith('_') })
    }

    It 'is valid JSON with at least the 12 expected roles' {
        $script:RoleNames.Count | Should -BeGreaterOrEqual 12
    }

    It 'gives every role a known tier' {
        foreach ($name in $script:RoleNames) {
            $script:Catalog.$name.tier | Should -BeIn @('Reader', 'Contributor', 'Owner', 'Custom') -Because "role '$name' must have a known tier"
        }
    }

    It 'gives every role a known scopeType' {
        foreach ($name in $script:RoleNames) {
            $script:Catalog.$name.scopeType | Should -BeIn @('subscription', 'resource', 'any') -Because "role '$name' must have a known scopeType"
        }
    }

    It 'gives every resource-scoped role a resourceType' {
        $resourceScoped = @($script:RoleNames | Where-Object { $script:Catalog.$_.scopeType -eq 'resource' })
        $resourceScoped.Count | Should -BeGreaterThan 0
        foreach ($name in $resourceScoped) {
            $script:Catalog.$name.resourceType | Should -Not -BeNullOrEmpty -Because "resource-scoped role '$name' needs a resourceType"
        }
    }

    It 'gives every non-Custom role a roleDefinitionId GUID' {
        foreach ($name in ($script:RoleNames | Where-Object { $script:Catalog.$_.tier -ne 'Custom' })) {
            $script:Catalog.$name.roleDefinitionId | Should -Match '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' -Because "role '$name' needs a valid GUID"
        }
    }
}

Describe 'Get-RoleTier' {
    It 'resolves the existing subscription-scoped roles' {
        Get-RoleTier -RoleName 'Reader'      | Should -Be 'Reader'
        Get-RoleTier -RoleName 'Contributor' | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Owner'       | Should -Be 'Owner'
        Get-RoleTier -RoleName 'UAA'         | Should -Be 'Owner'
    }

    It 'resolves Writer to Contributor via aliasOf' {
        Get-RoleTier -RoleName 'Writer' | Should -Be 'Contributor'
    }

    It 'resolves the new Storage roles' {
        Get-RoleTier -RoleName 'Storage Blob Data Reader'      | Should -Be 'Reader'
        Get-RoleTier -RoleName 'Storage Blob Data Contributor' | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Storage Blob Data Owner'       | Should -Be 'Owner'
    }

    It 'resolves the new AKS roles' {
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Reader'        | Should -Be 'Reader'
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Writer'        | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Admin'         | Should -Be 'Contributor'
        Get-RoleTier -RoleName 'Azure Kubernetes Service RBAC Cluster Admin' | Should -Be 'Owner'
    }

    It 'is case-insensitive on role name' {
        Get-RoleTier -RoleName 'storage blob data contributor' | Should -Be 'Contributor'
    }

    It 'returns $null for an unknown role (fail closed at the caller)' {
        Get-RoleTier -RoleName 'Totally Made Up Role' | Should -BeNullOrEmpty
    }
}

Describe 'Get-RoleCatalogEntry' {
    It 'returns scope metadata for a resource-scoped role' {
        $e = Get-RoleCatalogEntry -RoleName 'Storage Blob Data Contributor'
        $e.scopeType    | Should -Be 'resource'
        $e.resourceType | Should -Be 'Microsoft.Storage/storageAccounts'
        $e.roleDefinitionId | Should -Be 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
    }

    It 'returns subscription scopeType for classic roles' {
        (Get-RoleCatalogEntry -RoleName 'Contributor').scopeType | Should -Be 'subscription'
    }

    It 'returns $null for an unknown role' {
        Get-RoleCatalogEntry -RoleName 'Nope' | Should -BeNullOrEmpty
    }
}

Describe 'Get-AssignableRoleDefinitionId' {
    It 'returns the correct GUID for a normal role' {
        Get-AssignableRoleDefinitionId -RoleName 'Storage Blob Data Contributor' | Should -Be 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
    }

    It 'resolves the User Access Administrator display name to the UAA GUID' {
        Get-AssignableRoleDefinitionId -RoleName 'User Access Administrator' | Should -Be '18d7d88d-d35e-4fb5-a5c3-7773c20a72d9'
    }

    It 'returns $null for Custom, which is present in the catalog but has no GUID' {
        Get-AssignableRoleDefinitionId -RoleName 'Custom' | Should -BeNullOrEmpty
    }

    It 'returns $null for an unknown role name' {
        Get-AssignableRoleDefinitionId -RoleName 'Totally Made Up Role' | Should -BeNullOrEmpty
    }

    It 'returns $null for an empty string' {
        Get-AssignableRoleDefinitionId -RoleName '' | Should -BeNullOrEmpty
    }
}
