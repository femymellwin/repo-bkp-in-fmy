BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')
    . (Join-Path $repoRoot 'dashboard\api\DashboardHelpers.ps1')
}

Describe 'Get-ManageEngineNoteKind' {
    It 'classifies a Revoke decision as Revoke regardless of execution' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Revoke' }
        $kind.Kind | Should -Be 'Revoke'
    }

    It 'classifies an Eligible decision as Eligible' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Eligible' } -Execution @{ AssignmentType = 'Eligible' }
        $kind.Kind | Should -Be 'Eligible'
    }

    It 'classifies a successful group grant as GroupMembership, not a time-bound grant' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Grant' } -Execution @{ AssignmentType = 'GroupMembership' }
        $kind.Kind | Should -Be 'GroupMembership'
    }

    It 'classifies a PIM-fallback grant (AssignmentType Active) as a time-bound grant' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Grant' } -Execution @{ AssignmentType = 'Active' }
        $kind.Kind | Should -Be 'TimeBoundGrant'
    }

    It 'classifies BreakGlass as a time-bound grant' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'BreakGlass' } -Execution @{ AssignmentType = 'Active' }
        $kind.Kind | Should -Be 'TimeBoundGrant'
    }

    It 'falls back to Decision.AssignmentType when there is no Execution' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Eligible'; AssignmentType = 'Eligible' }
        $kind.Kind | Should -Be 'Eligible'
    }

    It 'classifies a failed unattended grant as Failed when Execution.Success is explicitly false' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Grant' } -Execution @{ Success = $false; Error = 'boom' }
        $kind.Kind | Should -Be 'Failed'
    }

    It 'still classifies Revoke as Revoke even when Execution.Success is explicitly false' {
        # Revoke is checked first -- a revoke's own failure handling is a separate,
        # pre-existing concern from the poller's grant-failure note.
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Revoke' } -Execution @{ Success = $false }
        $kind.Kind | Should -Be 'Revoke'
    }

    It 'does not classify as Failed when Execution.Success is absent (only $null, not $false)' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Grant' } -Execution @{ AssignmentType = 'Active' }
        $kind.Kind | Should -Be 'TimeBoundGrant'
    }

    It 'does not classify as Failed when there is no Execution at all' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Eligible' }
        $kind.Kind | Should -Be 'Eligible'
    }
}

Describe 'Test-GrantRevocable / Get-RevokeFulfilmentMode' {
    It 'is not revocable when there is no prior entry' {
        Test-GrantRevocable -Prior $null | Should -Be $false
    }

    It 'is not revocable when already revoked, even with an assignmentId' {
        $prior = @{ assignmentId = 'mock-active-1'; revoked = $true }
        Test-GrantRevocable -Prior $prior | Should -Be $false
    }

    It 'is revocable with a stored PIM assignment id' {
        $prior = @{ assignmentId = 'mock-active-1' }
        Test-GrantRevocable -Prior $prior | Should -Be $true
        Get-RevokeFulfilmentMode -Prior $prior | Should -Be 'Assignment'
    }

    It 'is revocable with Group fulfilment + a stored groupId, even with no assignmentId' {
        $prior = @{ assignmentId = $null; fulfilment = 'Group'; groupId = 'grp-1' }
        Test-GrantRevocable -Prior $prior | Should -Be $true
        Get-RevokeFulfilmentMode -Prior $prior | Should -Be 'Group'
    }

    It 'is not revocable when fulfilment is Group but groupId is missing' {
        $prior = @{ assignmentId = $null; fulfilment = 'Group'; groupId = $null }
        Test-GrantRevocable -Prior $prior | Should -Be $false
    }

    It 'is not revocable when there is neither an assignmentId nor a group grant' {
        $prior = @{ assignmentId = $null; fulfilment = 'PimFallback'; groupId = $null }
        Test-GrantRevocable -Prior $prior | Should -Be $false
    }

    It 'works against a PSCustomObject (as returned by ConvertFrom-Json on the store file)' {
        $prior = [pscustomobject]@{ assignmentId = $null; fulfilment = 'Group'; groupId = 'grp-2' }
        Test-GrantRevocable -Prior $prior | Should -Be $true
        Get-RevokeFulfilmentMode -Prior $prior | Should -Be 'Group'
    }

    It 'is revocable for a poller-shaped group-fulfilment record (final-review C2)' {
        # Reviewer repro: the poller's $executeGrant used to return only assignmentId +
        # fulfilment on the group path (AssignmentId is $null there -- the normal path for
        # Reader/Contributor, i.e. everything the poller is permitted to grant) and never
        # persisted groupId at all. Test-GrantRevocable then satisfied neither branch, and
        # clicking Revoke on a poller-granted ticket 404'd with no rollback -- for exactly
        # the grants that had no human in the loop. This is the exact shape
        # scripts/Invoke-TicketPollerCycle.ps1's $executeGrant now persists on success.
        $pollerRecord = [pscustomobject]@{
            meTicketId     = 'ME-9001'
            ticketId       = 'ME-9001'
            action         = 'Grant'
            role           = 'Reader'
            environment    = 'Sandbox'
            subscriptionId = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
            requesterUpn   = 'dev.user@contoso.com'
            assignmentId   = $null
            fulfilment     = 'Group'
            groupId        = 'grp-sandbox-readers'
            groupName      = 'sg-inception-ai-sandbox-readers'
            expiresAt      = $null
            runId          = 'poll-20260820120000-abc123'
            actor          = 'poller'
            processedAt    = '2026-08-20T12:00:00Z'
            revoked        = $false
        }
        Test-GrantRevocable -Prior $pollerRecord | Should -Be $true
        Get-RevokeFulfilmentMode -Prior $pollerRecord | Should -Be 'Group'
    }
}

Describe 'Get-GrantExpiryTimestamp' {
    It 'computes Now + DurationDays as an ISO-8601 UTC string' {
        # -Now is compared against its own +7 days rather than a hardcoded literal, so
        # this test is not sensitive to the host's local timezone offset.
        $now = [datetime]::UtcNow
        $expiry = Get-GrantExpiryTimestamp -DurationDays 7 -Now $now
        ([datetime]$expiry).ToUniversalTime() | Should -BeGreaterOrEqual $now.ToUniversalTime().AddDays(7).AddSeconds(-5)
        ([datetime]$expiry).ToUniversalTime() | Should -BeLessOrEqual $now.ToUniversalTime().AddDays(7).AddSeconds(5)
    }

    It 'now returns a populated value for what used to be the Group path''s $null (I1/reaper)' {
        # Before this fix, both call sites (scripts/Invoke-TicketPollerCycle.ps1 and
        # Start-DashboardApi.ps1's grant route) special-cased Fulfilment -eq 'PimFallback'
        # and left ExpiresAt $null for Fulfilment -eq 'Group' -- meaning every unattended
        # group grant (the poller's normal path) was permanent until a human revoked it.
        # Get-GrantExpiryTimestamp is fulfilment-agnostic: it always returns a populated
        # timestamp, so a Group-fulfilment record now gets one too. See its own comment
        # for why that value is a TRACKED expiry (reaper-enforced), not an Azure one, for
        # the Group case specifically.
        $expiry = Get-GrantExpiryTimestamp -DurationDays 1
        $expiry | Should -Not -BeNullOrEmpty
        { [datetime]$expiry } | Should -Not -Throw
    }
}

Describe 'Get-GrantExpiryEnforcement' {
    It 'names PimFallback as Azure-enforced' {
        Get-GrantExpiryEnforcement -Fulfilment 'PimFallback' | Should -Be 'AzureEnforced'
    }

    It 'names Group as tracked-only' {
        Get-GrantExpiryEnforcement -Fulfilment 'Group' | Should -Be 'TrackedOnly'
    }

    It 'defaults anything else (including missing/blank) to tracked-only -- never silently claims Azure enforcement' {
        Get-GrantExpiryEnforcement -Fulfilment '' | Should -Be 'TrackedOnly'
        Get-GrantExpiryEnforcement -Fulfilment $null | Should -Be 'TrackedOnly'
        Get-GrantExpiryEnforcement -Fulfilment 'SomethingUnexpected' | Should -Be 'TrackedOnly'
    }

    It 'makes a Group-fulfilment grant''s audit record distinguishable from a PimFallback one' {
        # Task requirement: an auditor must be able to tell the two apart from the audit
        # record ALONE. Simulate the two -Detail/-After shapes the poller and dashboard
        # grant paths actually write and assert they disagree on expiry enforcement even
        # though both carry a populated expiresAt.
        $pimRecord = @{
            fulfilment = 'PimFallback'
            expiresAt = (Get-GrantExpiryTimestamp -DurationDays 7)
        }
        $pimRecord.expiryEnforcement = Get-GrantExpiryEnforcement -Fulfilment $pimRecord.fulfilment

        $groupRecord = @{
            fulfilment = 'Group'
            expiresAt = (Get-GrantExpiryTimestamp -DurationDays 7)
        }
        $groupRecord.expiryEnforcement = Get-GrantExpiryEnforcement -Fulfilment $groupRecord.fulfilment

        $pimRecord.expiresAt | Should -Not -BeNullOrEmpty
        $groupRecord.expiresAt | Should -Not -BeNullOrEmpty
        $pimRecord.expiryEnforcement | Should -Be 'AzureEnforced'
        $groupRecord.expiryEnforcement | Should -Be 'TrackedOnly'
        $pimRecord.expiryEnforcement | Should -Not -Be $groupRecord.expiryEnforcement
    }
}

Describe 'Get-TicketTypeLabel' {
    It 'reads the ManageEngine template name' {
        Get-TicketTypeLabel -Ticket @{ template = @{ name = 'Azure Subscription' } } | Should -Be 'Azure Subscription'
        Get-TicketTypeLabel -Ticket @{ template = @{ name = 'General Access' } } | Should -Be 'General Access'
        Get-TicketTypeLabel -Ticket @{ template = @{ name = 'ADO' } } | Should -Be 'ADO'
        Get-TicketTypeLabel -Ticket @{ template = @{ name = 'GitHub Enterprise' } } | Should -Be 'GitHub Enterprise'
        Get-TicketTypeLabel -Ticket @{ template = @{ name = 'Infrastructure' } } | Should -Be 'Infrastructure'
    }

    It 'accepts a string template' {
        Get-TicketTypeLabel -Ticket @{ template = '  Cursor  ' } | Should -Be 'Cursor'
    }

    It 'reads a PSCustomObject template (ManageEngine JSON shape)' {
        $ticket = [pscustomobject]@{ template = [pscustomobject]@{ name = 'Infrastructure'; id = '42' } }
        Get-TicketTypeLabel -Ticket $ticket | Should -Be 'Infrastructure'
    }

    It 'falls back when template is missing' {
        Get-TicketTypeLabel -Ticket @{} | Should -Be 'Unspecified'
        Get-TicketTypeLabel -Ticket $null | Should -Be 'Unspecified'
        Get-TicketTypeLabel -Ticket @{ template = @{ name = '  ' } } | Should -Be 'Unspecified'
    }
}

Describe 'Get-DemoGroupRbacSeed' {
    It 'builds a Reader + Contributor group per labeled subscription, matched by the group naming helpers' {
        $labels = @{
            'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' = 'platform-sandbox'
            'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' = 'platform-prod'
        }
        $seed = Get-DemoGroupRbacSeed -SubscriptionLabels $labels

        @($seed.Groups).Count | Should -Be 4
        @($seed.RoleAssignments).Count | Should -Be 4
        $seed.SubscriptionNames['aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'] | Should -Be 'platform-sandbox'

        $prefix = Get-RbacGroupSearchPrefix -SubscriptionName 'platform-prod' -IncludeEnvironment:$false
        $suffix = Get-RbacGroupRoleSuffix -RoleName 'Contributor'
        $match = @($seed.Groups | Where-Object { Test-RbacGroupNameMatch -GroupDisplayName $_.displayName -Prefix $prefix -Suffix $suffix })
        $match.Count | Should -Be 1
    }

    It 'skips subscriptions with an empty label and accepts a PSCustomObject (as config.subscriptionLabels is)' {
        $labels = [pscustomobject]@{
            'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' = 'platform-sandbox'
            'cccccccc-cccc-cccc-cccc-cccccccccccc' = ''
        }
        $seed = Get-DemoGroupRbacSeed -SubscriptionLabels $labels
        @($seed.Groups).Count | Should -Be 2
        $seed.SubscriptionNames.ContainsKey('cccccccc-cccc-cccc-cccc-cccccccccccc') | Should -Be $false
    }
}
