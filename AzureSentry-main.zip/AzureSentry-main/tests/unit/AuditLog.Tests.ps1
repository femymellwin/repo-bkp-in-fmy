BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\AuditLog.ps1')
    . (Join-Path $repoRoot 'src\Agents\AgentRuntime.ps1')

    # Pester 5 forbids BeforeEach directly in the container root, so each Describe
    # calls these instead of duplicating the setup body.
    function Reset-TestAuditLog {
        $script:LogPath = Join-Path ([System.IO.Path]::GetTempPath()) "azsentry-audit-$([guid]::NewGuid().ToString('N')).jsonl"
        Initialize-AuditLog -Path $script:LogPath | Out-Null
    }

    function Remove-TestAuditLog {
        if ($script:LogPath -and (Test-Path $script:LogPath)) { Remove-Item $script:LogPath -Force }
    }
}

Describe 'Write-AuditEvent — Log Analytics forwarding (Deliverable #10)' {
    BeforeAll {
        . (Join-Path $repoRoot 'dashboard\api\LogAnalyticsClient.ps1')
    }
    BeforeEach { Reset-TestAuditLog }
    AfterEach { Remove-TestAuditLog }

    It 'forwards the written event to Log Analytics when the client is loaded' {
        Mock -CommandName Send-LogAnalyticsAuditEvent -MockWith { [pscustomobject]@{ ok = $true; skipped = $false } }
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' | Out-Null
        Should -Invoke -CommandName Send-LogAnalyticsAuditEvent -Times 1
    }

    It 'still returns the event and keeps the local append even if the forwarder throws unexpectedly' {
        # Send-LogAnalyticsAuditEvent is designed to never throw (it catches its own
        # errors), but Write-AuditEvent defends against it doing so anyway — a bug in
        # the forwarder, or a test double like this one, must never take down the
        # caller's actual agent action.
        Mock -CommandName Send-LogAnalyticsAuditEvent -MockWith { throw 'network unreachable' }
        { Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' } | Should -Not -Throw
        $result = Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate'
        $result | Should -Not -BeNullOrEmpty
        @(Get-AuditEvents -Agent 'DecisionAgent').Count | Should -Be 2
    }

    It 'never calls the forwarder for a failed local append' {
        Mock -CommandName Send-LogAnalyticsAuditEvent -MockWith { [pscustomobject]@{ ok = $true } }
        # Force a local append failure by pointing at an invalid path after init.
        $script:AuditLogPath = 'Z:\definitely\does\not\exist\audit.jsonl'
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' | Out-Null
        Should -Invoke -CommandName Send-LogAnalyticsAuditEvent -Times 0
    }
}

Describe 'Write-AuditEvent — FR6 / NFR3 append-only trail' {
    BeforeEach { Reset-TestAuditLog }
    AfterEach { Remove-TestAuditLog }

    It 'appends an event with who / what / when and the target' {
        $e = Write-AuditEvent -Agent 'AccessProvisioningAgent' -Action 'ProvisionAccess' `
            -Actor 'siva@example.com' -TicketId '4441' `
            -Target @{ subscriptionId = 'sub-1'; role = 'Contributor' } `
            -Before @{ hasAccess = $false } -After @{ hasAccess = $true } -IsWrite $true

        $e | Should -Not -BeNullOrEmpty
        $e.agent | Should -Be 'AccessProvisioningAgent'
        $e.actor | Should -Be 'siva@example.com'
        $e.ticketId | Should -Be '4441'
        $e.target.role | Should -Be 'Contributor'
        $e.before.hasAccess | Should -BeFalse
        $e.after.hasAccess | Should -BeTrue
        $e.timestamp | Should -Not -BeNullOrEmpty
        $e.isWrite | Should -BeTrue
    }

    It 'assigns monotonic sequence numbers' {
        1..5 | ForEach-Object { Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' | Out-Null }
        $events = Get-AuditEvents -Limit 10
        @($events).Count | Should -Be 5
        # Get-AuditEvents is newest-first.
        @($events.seq) | Should -Be @(5, 4, 3, 2, 1)
    }

    It 'chains each event hash to the previous one' {
        $a = Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate'
        $b = Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate'
        $a.prevHash | Should -Be 'GENESIS'
        $b.prevHash | Should -Be $a.hash
    }

    It 'appends one line per event and never rewrites earlier lines' {
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'First' | Out-Null
        $afterFirst = (Get-Content $script:LogPath -Raw)
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'Second' | Out-Null
        $afterSecond = (Get-Content $script:LogPath -Raw)
        $afterSecond.StartsWith($afterFirst) | Should -BeTrue
        @(Get-Content $script:LogPath).Count | Should -Be 2
    }

    It 'recovers the chain head when re-initialized against an existing log' {
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'One' | Out-Null
        $second = Write-AuditEvent -Agent 'DecisionAgent' -Action 'Two'
        Initialize-AuditLog -Path $script:LogPath | Out-Null
        $third = Write-AuditEvent -Agent 'DecisionAgent' -Action 'Three'
        $third.seq | Should -Be 3
        $third.prevHash | Should -Be $second.hash
    }
}

Describe 'Get-AuditEvents filters' {
    AfterEach { Remove-TestAuditLog }
    BeforeEach {
        Reset-TestAuditLog
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' -Actor 'a@x.com' -TicketId '1' | Out-Null
        Write-AuditEvent -Agent 'AccessProvisioningAgent' -Action 'UpdateEnvironmentTag' -Actor 'siva@x.com' -TicketId '2' -IsWrite $true | Out-Null
        Write-AuditEvent -Agent 'AccessProvisioningAgent' -Action 'UpdateEnvironmentTag' -Actor 'siva@x.com' -TicketId '3' -Outcome 'Failed' | Out-Null
    }

    It 'filters by agent' { @(Get-AuditEvents -Agent 'AccessProvisioningAgent').Count | Should -Be 2 }
    It 'filters by action' { @(Get-AuditEvents -Action 'Evaluate').Count | Should -Be 1 }
    It 'filters by ticket' { @(Get-AuditEvents -TicketId '2').Count | Should -Be 1 }
    It 'filters by outcome' { @(Get-AuditEvents -Outcome 'Failed').Count | Should -Be 1 }
    It 'filters to writes only' { @(Get-AuditEvents -WritesOnly).Count | Should -Be 1 }
    It 'honours the limit' { @(Get-AuditEvents -Limit 2).Count | Should -Be 2 }

    It 'summarizes by agent and outcome' {
        $s = Get-AuditSummary
        $s.total | Should -Be 3
        $s.writes | Should -Be 1
        $s.byAgent['AccessProvisioningAgent'] | Should -Be 2
        $s.byOutcome['Failed'] | Should -Be 1
    }
}

Describe 'Test-AuditChainIntegrity — NFR3 tamper evidence' {
    BeforeEach { Reset-TestAuditLog }
    AfterEach { Remove-TestAuditLog }

    It 'reports an intact chain' {
        1..4 | ForEach-Object { Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' | Out-Null }
        $r = Test-AuditChainIntegrity
        $r.ok | Should -BeTrue
        $r.checked | Should -Be 4
    }

    It 'reports ok on an empty trail' {
        (Test-AuditChainIntegrity).ok | Should -BeTrue
    }

    It 'detects an edited event' {
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' -Actor 'honest@x.com' | Out-Null
        Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' | Out-Null
        # Rewrite the actor on line 1 without recomputing the hash.
        $lines = @(Get-Content $script:LogPath)
        $lines[0] = $lines[0].Replace('honest@x.com', 'forged@x.com')
        Set-Content -Path $script:LogPath -Value $lines -Encoding UTF8

        $r = Test-AuditChainIntegrity
        $r.ok | Should -BeFalse
        $r.reason | Should -Match 'hash mismatch'
    }

    It 'detects a removed event' {
        1..3 | ForEach-Object { Write-AuditEvent -Agent 'DecisionAgent' -Action 'Evaluate' | Out-Null }
        $lines = @(Get-Content $script:LogPath)
        Set-Content -Path $script:LogPath -Value @($lines[0], $lines[2]) -Encoding UTF8

        $r = Test-AuditChainIntegrity
        $r.ok | Should -BeFalse
        $r.reason | Should -Match 'Sequence gap'
    }
}

Describe 'ConvertTo-CanonicalJsonValue / ConvertTo-CanonicalJsonString (2026-08-23 host-independence fix)' {
    <#
    Three confirmed, real bugs motivate this block, all found by verifying this
    project's own local audit log across Windows PowerShell 5.1 and pwsh 7:

      1. ConvertTo-Json escapes ' as ' on PS 5.1 but not pwsh 7 -- different bytes,
         different hash, for the exact same already-written record.
      2. Get-Content's default encoding differs by host for a BOM-less UTF-8 file --
         PS 5.1 mojibakes non-ASCII text without -Encoding UTF8 (covered by the
         Get-Content-site comments in AuditLog.ps1, not re-tested here).
      3. PowerShell's `switch` statement compares string case labels CULTURE-AWARE, not
         ordinal: `switch ([char]0x200B) { "`b" {...} }` matched the backspace case
         under pwsh 7 (silently corrupting a zero-width space into a literal backspace
         escape) but not under PS 5.1. Fixed by comparing [int] codepoints with -eq,
         never `switch` or -eq between a [char] and a [string] -- see
         ConvertTo-CanonicalJsonString's .DESCRIPTION.

    These tests can only run under whichever host invokes Pester, so they cannot
    literally prove cross-host agreement themselves -- that was verified by hand,
    running the real functions against the real log files under both hosts, recorded
    in progress.md. What they CAN and do prove: the specific inputs that broke each
    bug now produce the specific, correct, ordinal (host-blind) output; the exact-hash
    pin at the bottom is a regression tripwire if host-dependent behaviour ever creeps
    back in, on WHICHEVER host next runs this suite.
    #>

    It 'does not escape an apostrophe (bug 1: PS 5.1 ConvertTo-Json did)' {
        ConvertTo-CanonicalJsonString -Value "Subscription 'Vantage-Dev'" |
            Should -Be '"Subscription ''Vantage-Dev''"'
    }

    It 'does not escape angle brackets or ampersand (JSON does not require it, unlike some hosts'' ConvertTo-Json)' {
        ConvertTo-CanonicalJsonString -Value 'a < b & b > c' | Should -Be '"a < b & b > c"'
    }

    It 'escapes " and \ (JSON requires it)' {
        ConvertTo-CanonicalJsonString -Value 'say "hi"' | Should -Be '"say \"hi\""'
        ConvertTo-CanonicalJsonString -Value 'a\b' | Should -Be '"a\\b"'
    }

    It 'escapes the JSON short-form control characters correctly' {
        ConvertTo-CanonicalJsonString -Value "a$([char]8)b" | Should -Be '"a\bb"'   # real backspace
        ConvertTo-CanonicalJsonString -Value "a$([char]9)b" | Should -Be '"a\tb"'   # tab
        ConvertTo-CanonicalJsonString -Value "a$([char]10)b" | Should -Be '"a\nb"'  # LF
        ConvertTo-CanonicalJsonString -Value "a$([char]12)b" | Should -Be '"a\fb"'  # form feed
        ConvertTo-CanonicalJsonString -Value "a$([char]13)b" | Should -Be '"a\rb"'  # CR
    }

    It 'escapes an uncommon control character as a backslash-u sequence, not a raw byte' {
        # Written as a round-trip rather than typing a literal escape sequence in
        # this test file's own source, to avoid this file being subject to the
        # same kind of escape-handling pitfall the function under test exists to fix.
        $escaped = ConvertTo-CanonicalJsonString -Value "a$([char]1)b"
        $escaped | Should -Not -Match ([string][char]1)
        ($escaped | ConvertFrom-Json) | Should -Be "a$([char]1)b"
    }

    It 'does NOT mistake a zero-width space for backspace (bug 3, regression pin)' {
        # This is the exact failure mode: switch ([char]0x200B) { "`b" {...} } matched
        # under pwsh 7 due to culture-aware comparison. Must stay unescaped, literal.
        $zwsp = [char]0x200B
        $result = ConvertTo-CanonicalJsonString -Value "before${zwsp}after"
        $result | Should -Not -Match '\\b'
        [int]$result[7] | Should -Be 0x200B
    }

    It 'leaves other printable non-ASCII text untouched (emoji, CJK, accents)' {
        $value = 'café 日本語 🎉'
        ConvertTo-CanonicalJsonString -Value $value | Should -Be "`"$value`""
    }

    It 'sorts object keys ordinally regardless of insertion order' {
        $a = [ordered]@{ zebra = 1; apple = 2; Middle = 3 }
        $b = [ordered]@{ apple = 2; Middle = 3; zebra = 1 }
        (ConvertTo-CanonicalJsonValue -Value $a) | Should -Be (ConvertTo-CanonicalJsonValue -Value $b)
        # 'M' (0x4D) sorts before 'a' (0x61) under ordinal comparison.
        (ConvertTo-CanonicalJsonValue -Value $a) | Should -Be '{"Middle":3,"apple":2,"zebra":1}'
    }

    It 'sorts nested object keys at every depth' {
        $value = @{ outer = @{ z = 1; a = 2 } }
        (ConvertTo-CanonicalJsonValue -Value $value) | Should -Be '{"outer":{"a":2,"z":1}}'
    }

    It 'round-trips a [datetime] to full-precision ISO-8601, matching what ConvertFrom-Json hands back on a host that auto-parses it' {
        # pwsh 7's ConvertFrom-Json auto-coerces an ISO-8601 string into [datetime];
        # PS 5.1 does not. Both must canonicalize to the identical string.
        $dt = [datetime]::Parse('2026-08-17T14:29:17.3182648Z', $null, [System.Globalization.DateTimeStyles]::RoundtripKind)
        ConvertTo-CanonicalJsonValue -Value $dt | Should -Be '"2026-08-17T14:29:17.3182648Z"'
    }

    It 'serializes a [guid] as a quoted string, not a bare token' {
        $g = [guid]'11111111-2222-3333-4444-555555555555'
        ConvertTo-CanonicalJsonValue -Value $g | Should -Be '"11111111-2222-3333-4444-555555555555"'
    }

    It 'serializes null, bool, int, and array correctly' {
        ConvertTo-CanonicalJsonValue -Value $null | Should -Be 'null'
        ConvertTo-CanonicalJsonValue -Value $true | Should -Be 'true'
        ConvertTo-CanonicalJsonValue -Value $false | Should -Be 'false'
        ConvertTo-CanonicalJsonValue -Value 42 | Should -Be '42'
        ConvertTo-CanonicalJsonValue -Value @(1, 'two', $null) | Should -Be '[1,"two",null]'
    }

    It 'throws rather than recursing forever on a pathological/circular input' {
        $node = @{}
        $node['self'] = $node
        { ConvertTo-CanonicalJsonValue -Value $node } | Should -Throw '*max depth*'
    }

    It 'pins a known-good hash for a record containing both bug triggers together (regression tripwire)' {
        # If ConvertTo-CanonicalJsonValue's output for this exact body ever changes on
        # ANY host -- a reintroduced ConvertTo-Json call, a reintroduced switch/-eq on
        # char, a key-order change -- this fails, on whichever host runs it.
        $body = [ordered]@{
            seq = 1; timestamp = '2026-08-17T14:29:17.3182648Z'; agent = 'TicketIntake'
            action = 'TemplateIntake'; actor = 'system'; runId = ''; correlationId = ''
            ticketId = '4671'; target = $null; before = $null
            after = @{ note = "Subscription 'Vantage-Dev'$([char]0x200B)ok" }
            outcome = 'Success'; reason = 'ok'; detail = $null
            correctsEventId = ''; isWrite = $false
        }
        $canon = Get-AuditCanonicalBody -Source $body
        $hash = Get-AuditEventHash -PrevHash 'GENESIS' -BodyJson $canon
        # Confirmed identical when computed under both Windows PowerShell 5.1 and pwsh 7.
        $hash | Should -Be 'cf43b9199a10fa13b0fa2c48c1f6151571d005def7ad90ddbe9707f5685b2d9b'
    }
}

Describe 'Test-AuditChainIntegrityMulti (final-review I3 -- poller has its own chain)' {
    # The dashboard API and the unattended poller each own a SEPARATE audit log file
    # (audit-log.jsonl vs audit-log-poller.jsonl) because two processes appending to ONE
    # file corrupt each other's chain -- each derives seq/prevHash from state cached in
    # its own process and never sees the other's writes. This verifies both independently.

    It 'reports ok when every chain is intact' {
        $pathA = Join-Path ([System.IO.Path]::GetTempPath()) "azsentry-multi-a-$([guid]::NewGuid().ToString('N')).jsonl"
        $pathB = Join-Path ([System.IO.Path]::GetTempPath()) "azsentry-multi-b-$([guid]::NewGuid().ToString('N')).jsonl"
        try {
            Initialize-AuditLog -Path $pathA | Out-Null
            Write-AuditEvent -Agent 'DashboardApi' -Action 'Evaluate' | Out-Null
            Initialize-AuditLog -Path $pathB | Out-Null
            Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'UnattendedGrant' | Out-Null

            $r = Test-AuditChainIntegrityMulti -Chains @(
                @{ Name = 'dashboard'; Path = $pathA }
                @{ Name = 'poller'; Path = $pathB }
            )
            $r.ok | Should -BeTrue
            $r.chains.Count | Should -Be 2
            ($r.chains | Where-Object { $_.chain -eq 'dashboard' }).ok | Should -BeTrue
            ($r.chains | Where-Object { $_.chain -eq 'poller' }).ok | Should -BeTrue
        }
        finally {
            Remove-Item $pathA, $pathB -Force -ErrorAction SilentlyContinue
        }
    }

    It 'reports not-ok overall when only ONE chain is broken, and names which one' {
        $pathA = Join-Path ([System.IO.Path]::GetTempPath()) "azsentry-multi-c-$([guid]::NewGuid().ToString('N')).jsonl"
        $pathB = Join-Path ([System.IO.Path]::GetTempPath()) "azsentry-multi-d-$([guid]::NewGuid().ToString('N')).jsonl"
        try {
            Initialize-AuditLog -Path $pathA | Out-Null
            Write-AuditEvent -Agent 'DashboardApi' -Action 'Evaluate' | Out-Null
            Initialize-AuditLog -Path $pathB | Out-Null
            Write-AuditEvent -Agent 'TicketPollerAgent' -Action 'UnattendedGrant' -Actor 'honest' | Out-Null
            $lines = @(Get-Content $pathB)
            $lines[0] = $lines[0].Replace('honest', 'forged')
            Set-Content -Path $pathB -Value $lines -Encoding UTF8

            $r = Test-AuditChainIntegrityMulti -Chains @(
                @{ Name = 'dashboard'; Path = $pathA }
                @{ Name = 'poller'; Path = $pathB }
            )
            $r.ok | Should -BeFalse
            ($r.chains | Where-Object { $_.chain -eq 'dashboard' }).ok | Should -BeTrue
            ($r.chains | Where-Object { $_.chain -eq 'poller' }).ok | Should -BeFalse
        }
        finally {
            Remove-Item $pathA, $pathB -Force -ErrorAction SilentlyContinue
        }
    }

    It 'reports ok for a chain file that does not exist yet' {
        $pathA = Join-Path ([System.IO.Path]::GetTempPath()) "azsentry-multi-e-$([guid]::NewGuid().ToString('N')).jsonl"
        $missing = Join-Path ([System.IO.Path]::GetTempPath()) "azsentry-multi-missing-$([guid]::NewGuid().ToString('N')).jsonl"
        try {
            Initialize-AuditLog -Path $pathA | Out-Null
            Write-AuditEvent -Agent 'DashboardApi' -Action 'Evaluate' | Out-Null

            $r = Test-AuditChainIntegrityMulti -Chains @(
                @{ Name = 'dashboard'; Path = $pathA }
                @{ Name = 'poller'; Path = $missing }
            )
            $r.ok | Should -BeTrue
        }
        finally {
            Remove-Item $pathA -Force -ErrorAction SilentlyContinue
        }
    }
}

Describe 'Invoke-Agent — FR3 audited agent runs' {
    BeforeEach { Reset-TestAuditLog }
    AfterEach { Remove-TestAuditLog }

    It 'exposes a registry of discrete agents' {
        $registry = Get-AgentRegistry
        @($registry).Count | Should -BeGreaterThan 4
        @($registry.Name) | Should -Contain 'AccessProvisioningAgent'
        @($registry.Name) | Should -Contain 'SummarizationAgent'
    }

    It 'registers TicketPollerAgent -- the only agent that writes with no human in the loop (I5)' {
        $agent = Get-AgentDefinition -Name 'TicketPollerAgent'
        $agent.Writes | Should -BeTrue
        $agent.Kind | Should -Be 'Deterministic'
        @($agent.Permissions).Count | Should -BeGreaterThan 0
        @(Get-AgentRegistry).Name | Should -Contain 'TicketPollerAgent'
    }

    It 'answers the framework question — both deterministic and LLM agents exist' {
        $kinds = @(Get-AgentRegistry | ForEach-Object { $_.Kind } | Sort-Object -Unique)
        $kinds | Should -Contain 'Deterministic'
        $kinds | Should -Contain 'Llm'
        $kinds | Should -Contain 'Hybrid'
    }

    It 'rejects an unregistered agent name' {
        { Get-AgentDefinition -Name 'NotAnAgent' } | Should -Throw
    }

    It 'emits a Started and a terminal audit event for one run' {
        Invoke-Agent -Name 'DecisionAgent' -Action 'Evaluate' -Body { param($run) return 42 } | Out-Null
        $events = @(Get-AuditEvents -Agent 'DecisionAgent')
        @($events).Count | Should -Be 2
        @($events.outcome) | Should -Contain 'Started'
        @($events.outcome) | Should -Contain 'Success'
    }

    It 'correlates both events with one run id' {
        $r = Invoke-Agent -Name 'DecisionAgent' -Action 'Evaluate' -Body { param($run) return 1 }
        $events = @(Get-AuditEvents -Agent 'DecisionAgent')
        @($events | Where-Object { $_.runId -eq $r.RunId }).Count | Should -Be 2
    }

    It 'returns the body result and records duration' {
        $r = Invoke-Agent -Name 'DecisionAgent' -Action 'Evaluate' -Body { param($run) return 'payload' }
        $r.Result | Should -Be 'payload'
        $r.Outcome | Should -Be 'Success'
        $r.DurationMs | Should -BeGreaterOrEqual 0
    }

    It 'lets the body record before/after state and a custom outcome' {
        Invoke-Agent -Name 'AccessProvisioningAgent' -Action 'Test' -Body {
            param($run)
            $run.Before = @{ environment = '' }
            $run.After = @{ environment = 'Sandbox' }
            $run.Outcome = 'DryRun'
            $run.Reason = 'dry run only'
        } | Out-Null

        $terminal = @(Get-AuditEvents -Agent 'AccessProvisioningAgent' | Where-Object { $_.outcome -ne 'Started' })[0]
        $terminal.outcome | Should -Be 'DryRun'
        $terminal.before.environment | Should -Be ''
        $terminal.after.environment | Should -Be 'Sandbox'
        $terminal.reason | Should -Be 'dry run only'
        # A dry run is never counted as a write, even for a write-capable agent.
        $terminal.isWrite | Should -BeFalse
    }

    It 'records a failure and rethrows by default' {
        { Invoke-Agent -Name 'DecisionAgent' -Action 'Boom' -Body { param($run) throw 'kaboom' } } | Should -Throw
        $terminal = @(Get-AuditEvents -Agent 'DecisionAgent' -Outcome 'Failed')
        @($terminal).Count | Should -Be 1
        $terminal[0].reason | Should -Match 'kaboom'
    }

    It 'returns the failure instead of throwing with -SwallowErrors' {
        $r = Invoke-Agent -Name 'DecisionAgent' -Action 'Boom' -Body { param($run) throw 'kaboom' } -SwallowErrors
        $r.Outcome | Should -Be 'Failed'
        $r.Error | Should -Match 'kaboom'
    }

    It 'marks a successful write-capable agent run as a write' {
        Invoke-Agent -Name 'AccessProvisioningAgent' -Action 'Grant' -Body { param($run) return $true } | Out-Null
        $terminal = @(Get-AuditEvents -Agent 'AccessProvisioningAgent' | Where-Object { $_.outcome -ne 'Started' })[0]
        $terminal.isWrite | Should -BeTrue
    }

    It 'never marks a read-only agent run as a write' {
        Invoke-Agent -Name 'SummarizationAgent' -Action 'Summarize' -Body { param($run) return 'text' } | Out-Null
        $terminal = @(Get-AuditEvents -Agent 'SummarizationAgent' | Where-Object { $_.outcome -ne 'Started' })[0]
        $terminal.isWrite | Should -BeFalse
    }
}
