BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')
}

Describe 'Get-RbacGroupRoleSuffix' {
    It 'maps Reader to readers' {
        Get-RbacGroupRoleSuffix -RoleName 'Reader' | Should -Be 'readers'
    }
    It 'maps Contributor and Writer to contributors' {
        Get-RbacGroupRoleSuffix -RoleName 'Contributor' | Should -Be 'contributors'
        Get-RbacGroupRoleSuffix -RoleName 'Writer' | Should -Be 'contributors'
    }
}

Describe 'Get-NormalizedSubscriptionSlug' {
    It 'lowercases and hyphenates' {
        Get-NormalizedSubscriptionSlug -SubscriptionName 'Jira Conf Prod' | Should -Be 'jira-conf-prod'
    }
}

Describe 'Get-CanonicalRbacGroupDisplayName' {
    It 'builds sg-ceo-sub-application-contributors' {
        Get-CanonicalRbacGroupDisplayName -SubscriptionName 'ceo-sub-application' -RoleName 'Contributor' |
            Should -Be 'sg-ceo-sub-application-contributors'
    }
    It 'builds sg-platform-sandbox-readers' {
        Get-CanonicalRbacGroupDisplayName -SubscriptionName 'platform-sandbox' -RoleName 'Reader' |
            Should -Be 'sg-platform-sandbox-readers'
    }
}

Describe 'Select-RbacGroupMatch' {
    It 'matches sg-jira-conf-prod-uaen-contributors when env present' {
        $groups = @(
            [pscustomobject]@{ id = 'g1'; displayName = 'sg-jira-conf-prod-uaen-contributors' }
        )
        $r = Select-RbacGroupMatch -Groups $groups -SubscriptionName 'jira-conf-prod' -RoleName 'Contributor'
        $r.Status | Should -Be 'Matched'
        $r.Group.id | Should -Be 'g1'
    }

    It 'falls back without inventing env when no env segment' {
        $groups = @(
            [pscustomobject]@{ id = 'g2'; displayName = 'sg-azure-labs-contributors' }
        )
        $r = Select-RbacGroupMatch -Groups $groups -SubscriptionName 'Azure-Labs' -RoleName 'Contributor'
        $r.Status | Should -Be 'Matched'
        $r.Group.id | Should -Be 'g2'
    }

    It 'returns None when no match' {
        $r = Select-RbacGroupMatch -Groups @() -SubscriptionName 'jira-conf-prod' -RoleName 'Reader'
        $r.Status | Should -Be 'None'
    }

    It 'returns Ambiguous when multiple match' {
        $groups = @(
            [pscustomobject]@{ id = 'a'; displayName = 'sg-jira-conf-prod-uaen-contributors' },
            [pscustomobject]@{ id = 'b'; displayName = 'sg-jira-conf-prod-eu-contributors' }
        )
        $r = Select-RbacGroupMatch -Groups $groups -SubscriptionName 'jira-conf-prod' -RoleName 'Contributor'
        $r.Status | Should -Be 'Ambiguous'
        $r.Candidates.Count | Should -Be 2
    }
}
