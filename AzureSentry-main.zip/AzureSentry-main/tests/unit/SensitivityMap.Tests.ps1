BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

    $script:SandboxSub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'   # mapped Sandbox
    $script:SensitiveSub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' # mapped Production
    $script:UnmappedSub = 'cccccccc-cccc-cccc-cccc-cccccccccccc'
    $script:Allowlist = @($script:SandboxSub, $script:SensitiveSub, $script:UnmappedSub)

    # Temp sensitivity maps (self-contained; independent of the committed data file).
    $script:MapTicketDefault = Join-Path $env:TEMP "azsentry-sens-ticket-$([guid]::NewGuid()).json"
    $script:MapProdDefault = Join-Path $env:TEMP "azsentry-sens-prod-$([guid]::NewGuid()).json"
    $subs = @{
        subscriptions = @{
            $script:SandboxSub   = @{ environment = 'Sandbox' }
            $script:SensitiveSub = @{ environment = 'Production' }
        }
    }
    (@{ default = 'ticket' } + $subs)     | ConvertTo-Json -Depth 6 | Set-Content -Path $script:MapTicketDefault -Encoding UTF8
    (@{ default = 'Production' } + $subs) | ConvertTo-Json -Depth 6 | Set-Content -Path $script:MapProdDefault -Encoding UTF8

    function New-Ticket {
        param([string]$Sub, [string]$Environment = 'Sandbox', [string]$Role = 'Reader')
        @{
            TicketId = [guid]::NewGuid().ToString(); Role = $Role; Environment = $Environment
            SubscriptionId = $Sub; ResourceScope = "/subscriptions/$Sub"; DurationDays = 7; Priority = 'P3'
            RequesterUpn = 'test.user@contoso.com'; SubmitterUpn = 'test.user@contoso.com'
            Justification = 'Sensitivity map regression test — at least twenty chars'
        }
    }
}

AfterAll {
    Remove-Item $script:MapTicketDefault, $script:MapProdDefault -ErrorAction SilentlyContinue
}

Describe 'Get-EffectiveEnvironment' {
    It 'escalates a Sandbox-labelled ticket on a Production-mapped subscription' {
        Get-EffectiveEnvironment -SubscriptionId $script:SensitiveSub -ClaimedEnvironment 'Sandbox' -MapPath $script:MapTicketDefault |
            Should -Be 'Production'
    }
    It 'keeps a Sandbox-mapped subscription as Sandbox' {
        Get-EffectiveEnvironment -SubscriptionId $script:SandboxSub -ClaimedEnvironment 'Sandbox' -MapPath $script:MapTicketDefault |
            Should -Be 'Sandbox'
    }
    It 'never downgrades an explicit Production request on a Sandbox-mapped subscription' {
        Get-EffectiveEnvironment -SubscriptionId $script:SandboxSub -ClaimedEnvironment 'Production' -MapPath $script:MapTicketDefault |
            Should -Be 'Production'
    }
    It 'trusts the ticket for an unmapped subscription when default = ticket' {
        Get-EffectiveEnvironment -SubscriptionId $script:UnmappedSub -ClaimedEnvironment 'Sandbox' -MapPath $script:MapTicketDefault |
            Should -Be 'Sandbox'
    }
    It 'fails safe (Production) for an unmapped subscription when default = Production' {
        Get-EffectiveEnvironment -SubscriptionId $script:UnmappedSub -ClaimedEnvironment 'Sandbox' -MapPath $script:MapProdDefault |
            Should -Be 'Production'
    }
}

Describe 'Resolve-RbacDecision — sensitivity override' {
    It 'a Sandbox-labelled Contributor request on a sensitive sub becomes Eligible (approval-gated)' {
        $d = Resolve-RbacDecision -Ticket (New-Ticket -Sub $script:SensitiveSub -Environment 'Sandbox' -Role 'Contributor') `
            -SubscriptionAllowlist $script:Allowlist -SensitivityMapPath $script:MapTicketDefault
        $d.Action | Should -Be 'Eligible'
        $d.EnvironmentOverridden | Should -BeTrue
        $d.ClaimedEnvironment | Should -Be 'Sandbox'
        $d.EffectiveEnvironment | Should -Be 'Production'
    }
    It 'a genuine sandbox subscription still auto-grants' {
        $d = Resolve-RbacDecision -Ticket (New-Ticket -Sub $script:SandboxSub -Environment 'Sandbox' -Role 'Reader') `
            -SubscriptionAllowlist $script:Allowlist -SensitivityMapPath $script:MapTicketDefault
        $d.Action | Should -Be 'Grant'
        $d.EnvironmentOverridden | Should -BeFalse
    }
}
