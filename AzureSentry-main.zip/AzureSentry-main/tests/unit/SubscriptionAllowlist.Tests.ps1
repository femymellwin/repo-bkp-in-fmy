BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\SubscriptionAllowlist.ps1')
    . (Join-Path $repoRoot 'src\Agents\PollerGate.ps1')
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

    function Reset-AllowlistTestState {
        $script:AllowlistCache = $null
    }

    $script:OrigTenant = $env:AZURE_TENANT_ID
    $script:OrigClientId = $env:AZURE_CLIENT_ID
    $script:OrigClientSecret = $env:AZURE_CLIENT_SECRET

    function Set-FakeSpnEnv {
        $env:AZURE_TENANT_ID = 'tenant-guid'
        $env:AZURE_CLIENT_ID = 'client-guid'
        $env:AZURE_CLIENT_SECRET = 'fake-secret'
    }

    function Restore-SpnEnv {
        [System.Environment]::SetEnvironmentVariable('AZURE_TENANT_ID', $script:OrigTenant, 'Process')
        [System.Environment]::SetEnvironmentVariable('AZURE_CLIENT_ID', $script:OrigClientId, 'Process')
        [System.Environment]::SetEnvironmentVariable('AZURE_CLIENT_SECRET', $script:OrigClientSecret, 'Process')
    }

    function New-TestConfig {
        param(
            [string]$Source = 'managementGroup',
            [string]$MgId = 'mg-test',
            [string[]]$Exclusions = @(),
            [bool]$EnabledOnly = $true,
            [int]$CacheMinutes = 10,
            [string[]]$StaticAllowlist = @('static-sub-1', 'static-sub-2')
        )
        [pscustomobject]@{
            subscriptionAllowlist = $StaticAllowlist
            allowlist              = [pscustomobject]@{
                source            = $Source
                managementGroupId = $MgId
                cacheMinutes      = $CacheMinutes
                enabledOnly       = $EnabledOnly
                exclusions        = $Exclusions
            }
        }
    }

    function Mock-ArmToken {
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'login.microsoftonline.com' } -MockWith {
            [pscustomobject]@{ access_token = 'fake-arm-token'; expires_in = 3600 }
        }
    }

    function Mock-ArmDescendants {
        param([Parameter(Mandatory)][array]$Entries)
        # .GetNewClosure() -- Pester's -MockWith scriptblock does not otherwise reliably
        # retain the outer $Entries variable, causing an unrelated-looking "array index
        # evaluated to null" from inside Resolve-ManagementGroupAllowlist when it read the
        # (silently empty) response.
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'managementGroups.*descendants' } -MockWith {
            [pscustomobject]@{
                value    = @($Entries | ForEach-Object {
                        [pscustomobject]@{
                            type       = 'Microsoft.Management/managementGroups/subscriptions'
                            name       = $_.id
                            properties = [pscustomobject]@{ displayName = $_.name }
                        }
                    })
                nextLink = $null
            }
        }.GetNewClosure()
    }

    function Mock-ArmSubscriptionStates {
        param([Parameter(Mandatory)][hashtable]$States)
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match '/subscriptions\?api-version' } -MockWith {
            [pscustomobject]@{
                value = @($States.Keys | ForEach-Object {
                        [pscustomobject]@{ subscriptionId = $_; state = $States[$_] }
                    })
            }
        }.GetNewClosure()
    }
}

AfterAll {
    Restore-SpnEnv
}

Describe 'Get-AllowlistConfig' {
    It 'defaults to static with no allowlist block at all (back-compat)' {
        $cfg = Get-AllowlistConfig -Config ([pscustomobject]@{ subscriptionAllowlist = @('a') })
        $cfg.source | Should -Be 'static'
        $cfg.managementGroupId | Should -BeNullOrEmpty
        $cfg.cacheMinutes | Should -Be 10
        $cfg.enabledOnly | Should -BeTrue
        @($cfg.exclusions).Count | Should -Be 0
    }

    It 'defaults to static with a null Config (poller with no config.json)' {
        (Get-AllowlistConfig -Config $null).source | Should -Be 'static'
    }

    It 'reads every field of a fully specified allowlist block' {
        $cfg = Get-AllowlistConfig -Config (New-TestConfig -MgId 'mg-incep-sandbox' -Exclusions @('excluded-sub') -EnabledOnly $false -CacheMinutes 5)
        $cfg.source | Should -Be 'managementGroup'
        $cfg.managementGroupId | Should -Be 'mg-incep-sandbox'
        $cfg.cacheMinutes | Should -Be 5
        $cfg.enabledOnly | Should -BeFalse
        @($cfg.exclusions) | Should -Be @('excluded-sub')
    }
}

Describe 'Get-EffectiveAllowlist -- static source' {
    BeforeEach { Reset-AllowlistTestState }

    It 'returns the static subscriptionAllowlist array unchanged when source is static' {
        $cfg = New-TestConfig -Source 'static'
        $eff = Get-EffectiveAllowlist -Config $cfg
        $eff.Source | Should -Be 'static'
        $eff.Degraded | Should -BeFalse
        @($eff.Subs) | Should -Be @('static-sub-1', 'static-sub-2')
    }

    It 'never calls Azure for the static source' {
        Mock -CommandName Invoke-RestMethod -MockWith { throw 'must not be called' }
        $cfg = New-TestConfig -Source 'static'
        Get-EffectiveAllowlist -Config $cfg | Out-Null
        Should -Invoke -CommandName Invoke-RestMethod -Times 0
    }
}

Describe 'Get-EffectiveAllowlist -- management-group source (dashboard behaviour, shared)' {
    BeforeEach { Reset-AllowlistTestState; Set-FakeSpnEnv }
    AfterEach { Restore-SpnEnv }

    It 'derives the allowlist live from the management group' {
        Mock-ArmToken
        Mock-ArmDescendants -Entries @(
            @{ id = 'sub-a'; name = 'Alpha' }, @{ id = 'sub-b'; name = 'Beta' }
        )
        Mock-ArmSubscriptionStates -States @{ 'sub-a' = 'Enabled'; 'sub-b' = 'Enabled' }

        $eff = Get-EffectiveAllowlist -Config (New-TestConfig)
        $eff.Source | Should -Be 'managementGroup:mg-test'
        $eff.Degraded | Should -BeFalse
        @($eff.Subs | Sort-Object) | Should -Be @('sub-a', 'sub-b')
        (@($eff.Details) | Where-Object { $_.id -eq 'sub-a' }).name | Should -Be 'Alpha'
    }

    It 'honours exclusions against a management-group result' {
        Mock-ArmToken
        Mock-ArmDescendants -Entries @(
            @{ id = 'sub-a'; name = 'Alpha' }, @{ id = 'sub-b'; name = 'Beta' }, @{ id = 'sub-c'; name = 'Gamma' }
        )
        Mock-ArmSubscriptionStates -States @{ 'sub-a' = 'Enabled'; 'sub-b' = 'Enabled'; 'sub-c' = 'Enabled' }

        $eff = Get-EffectiveAllowlist -Config (New-TestConfig -Exclusions @('sub-b'))
        @($eff.Subs) | Should -Not -Contain 'sub-b'
        @($eff.Subs | Sort-Object) | Should -Be @('sub-a', 'sub-c')
        @($eff.Details.id) | Should -Not -Contain 'sub-b'
    }

    It 'drops a disabled subscription when enabledOnly is true' {
        Mock-ArmToken
        Mock-ArmDescendants -Entries @(@{ id = 'sub-a'; name = 'Alpha' }, @{ id = 'sub-b'; name = 'Beta' })
        Mock-ArmSubscriptionStates -States @{ 'sub-a' = 'Enabled'; 'sub-b' = 'Disabled' }

        $eff = Get-EffectiveAllowlist -Config (New-TestConfig -EnabledOnly $true)
        @($eff.Subs) | Should -Be @('sub-a')
    }

    It 'keeps a disabled subscription when enabledOnly is false' {
        Mock-ArmToken
        Mock-ArmDescendants -Entries @(@{ id = 'sub-a'; name = 'Alpha' }, @{ id = 'sub-b'; name = 'Beta' })
        Mock-ArmSubscriptionStates -States @{ 'sub-a' = 'Enabled'; 'sub-b' = 'Disabled' }

        $eff = Get-EffectiveAllowlist -Config (New-TestConfig -EnabledOnly $false)
        @($eff.Subs | Sort-Object) | Should -Be @('sub-a', 'sub-b')
    }

    It 'caches the resolved list within cacheMinutes -- one ARM round trip for two calls' {
        Mock-ArmToken
        Mock-ArmDescendants -Entries @(@{ id = 'sub-a'; name = 'Alpha' })
        Mock-ArmSubscriptionStates -States @{ 'sub-a' = 'Enabled' }

        $cfg = New-TestConfig -CacheMinutes 10
        Get-EffectiveAllowlist -Config $cfg | Out-Null
        Get-EffectiveAllowlist -Config $cfg | Out-Null
        Should -Invoke -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'descendants' } -Times 1
    }

    It 'bypasses the cache with -ForceRefresh' {
        Mock-ArmToken
        Mock-ArmDescendants -Entries @(@{ id = 'sub-a'; name = 'Alpha' })
        Mock-ArmSubscriptionStates -States @{ 'sub-a' = 'Enabled' }

        $cfg = New-TestConfig -CacheMinutes 10
        Get-EffectiveAllowlist -Config $cfg | Out-Null
        Get-EffectiveAllowlist -Config $cfg -ForceRefresh | Out-Null
        Should -Invoke -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'descendants' } -Times 2
    }
}

Describe 'Get-EffectiveAllowlist -- fails CLOSED on any ARM error' {
    BeforeEach { Reset-AllowlistTestState; Set-FakeSpnEnv }
    AfterEach { Restore-SpnEnv }

    It 'falls back to the static list when the management-group query throws, and does not throw itself' {
        Mock-ArmToken
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'managementGroups.*descendants' } -MockWith {
            throw 'simulated ARM outage'
        }
        $cfg = New-TestConfig -StaticAllowlist @('static-sub-1', 'static-sub-2')
        { $script:Eff = Get-EffectiveAllowlist -Config $cfg -WarningAction SilentlyContinue } | Should -Not -Throw
        $script:Eff.Source | Should -Be 'static-fallback'
        $script:Eff.Degraded | Should -BeTrue
        @($script:Eff.Subs) | Should -Be @('static-sub-1', 'static-sub-2')
    }

    It 'falls back to the static list when the SPN token cannot be acquired (missing creds)' {
        Restore-SpnEnv
        [System.Environment]::SetEnvironmentVariable('AZURE_TENANT_ID', $null, 'Process')
        [System.Environment]::SetEnvironmentVariable('AZURE_CLIENT_ID', $null, 'Process')
        [System.Environment]::SetEnvironmentVariable('AZURE_CLIENT_SECRET', $null, 'Process')
        $cfg = New-TestConfig -StaticAllowlist @('static-sub-1')
        $eff = Get-EffectiveAllowlist -Config $cfg -WarningAction SilentlyContinue
        $eff.Source | Should -Be 'static-fallback'
        @($eff.Subs) | Should -Be @('static-sub-1')
    }

    It 'falls back to the static list on an empty/malformed ARM response, never to an unbounded list' {
        Mock-ArmToken
        Mock -CommandName Invoke-RestMethod -ParameterFilter { $Uri -match 'managementGroups.*descendants' } -MockWith {
            throw 'simulated malformed response'
        }
        $cfg = New-TestConfig -StaticAllowlist @('static-sub-1')
        $eff = Get-EffectiveAllowlist -Config $cfg -WarningAction SilentlyContinue
        # The critical fail-closed assertion: NOT "everything", specifically the known-good
        # static list -- see the mutation-discrimination note in the allowlist alignment
        # report for how this test was proven to actually catch a fail-OPEN regression.
        @($eff.Subs) | Should -Be @('static-sub-1')
        $eff.Degraded | Should -BeTrue
    }
}

Describe 'Management-group allowlist stays bounded by the other poller gates' {
    # This is the blast-radius check the alignment explicitly calls for: going from a
    # 2-subscription static list to an ~18-subscription management-group list only ever
    # widens WHICH subscriptions reach the gate, never what the gate itself allows. A
    # subscription the management group returns, that the sensitivity map independently
    # raises to Production, must still be refused for unattended auto-grant -- exactly as
    # if it had been on the static list all along.
    BeforeEach { Reset-AllowlistTestState; Set-FakeSpnEnv }
    AfterEach { Restore-SpnEnv }

    It 'refuses a subscription the management group returns but sensitivity raises to Production' {
        $sensitiveButListed = 'dddddddd-dddd-dddd-dddd-dddddddddddd'
        $genuineSandbox = 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee'

        Mock-ArmToken
        Mock-ArmDescendants -Entries @(
            @{ id = $sensitiveButListed; name = 'looks-like-sandbox-but-isnt' },
            @{ id = $genuineSandbox; name = 'actually-sandbox' }
        )
        Mock-ArmSubscriptionStates -States @{ $sensitiveButListed = 'Enabled'; $genuineSandbox = 'Enabled' }

        $eff = Get-EffectiveAllowlist -Config (New-TestConfig)
        @($eff.Subs) | Should -Contain $sensitiveButListed

        # Self-contained sensitivity map (independent of the committed data file), same
        # approach as SensitivityMap.Tests.ps1.
        $mapPath = Join-Path $env:TEMP "azsentry-sens-mg-$([guid]::NewGuid()).json"
        @{
            default       = 'ticket'
            subscriptions = @{
                $sensitiveButListed = @{ environment = 'Production' }
                $genuineSandbox     = @{ environment = 'Sandbox' }
            }
        } | ConvertTo-Json -Depth 6 | Set-Content -Path $mapPath -Encoding UTF8
        try {
            $ticket = @{
                TicketId = [guid]::NewGuid().ToString(); Role = 'Reader'; Environment = 'Sandbox'
                SubscriptionId = $sensitiveButListed; ResourceScope = "/subscriptions/$sensitiveButListed"
                DurationDays = 7; Priority = 'P3'
                RequesterUpn = 'test.user@contoso.com'; SubmitterUpn = 'test.user@contoso.com'
                Justification = 'MG-derived allowlist blast-radius regression test'
            }
            $decision = Resolve-RbacDecision -Ticket $ticket -SubscriptionAllowlist @($eff.Subs) -SensitivityMapPath $mapPath
            # The ticket claimed Sandbox; the sensitivity map still wins.
            $decision.EffectiveEnvironment | Should -Be 'Production'

            $mapping = [pscustomobject]@{ Complete = $true; Warnings = @(); Ticket = [pscustomobject]@{ Role = 'Reader' } }
            $gate = Test-PollerAutoEligible -Decision $decision -Mapping $mapping -TemplateAllowed $true
            $gate.Eligible | Should -BeFalse
            $gate.Reason | Should -Match 'Production'

            # And the genuinely sandboxed sibling on the SAME management-group-derived list
            # still auto-grants -- proves the refusal above is about sensitivity, not the
            # allowlist source. A fresh hashtable, not a clone of $ticket: Resolve-RbacDecision
            # mutates its -Ticket hashtable's Environment in place (the sensitivity override),
            # so $ticket itself already reads 'Production' by this point.
            $sandboxTicket = @{
                TicketId = [guid]::NewGuid().ToString(); Role = 'Reader'; Environment = 'Sandbox'
                SubscriptionId = $genuineSandbox; ResourceScope = "/subscriptions/$genuineSandbox"
                DurationDays = 7; Priority = 'P3'
                RequesterUpn = 'test.user@contoso.com'; SubmitterUpn = 'test.user@contoso.com'
                Justification = 'MG-derived allowlist blast-radius regression test'
            }
            $sandboxDecision = Resolve-RbacDecision -Ticket $sandboxTicket -SubscriptionAllowlist @($eff.Subs) -SensitivityMapPath $mapPath
            $sandboxDecision.EffectiveEnvironment | Should -Be 'Sandbox'
            (Test-PollerAutoEligible -Decision $sandboxDecision -Mapping $mapping -TemplateAllowed $true).Eligible | Should -BeTrue
        }
        finally {
            Remove-Item $mapPath -ErrorAction SilentlyContinue
        }
    }
}
