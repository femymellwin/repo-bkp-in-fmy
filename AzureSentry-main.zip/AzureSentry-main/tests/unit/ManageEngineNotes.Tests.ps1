BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'dashboard\api\DashboardHelpers.ps1')
    . (Join-Path $repoRoot 'dashboard\api\ManageEngineNotes.ps1')

    function New-NoteConfig {
        param(
            [string]$BaseUrl = 'https://sdp.contoso.com',
            [string]$ApiKey = 'test-token',
            [object]$ClosureFields = $null
        )
        $me = [pscustomobject]@{ baseUrl = $BaseUrl; apiKey = $ApiKey }
        if ($ClosureFields) {
            $me | Add-Member -NotePropertyName closureFields -NotePropertyValue $ClosureFields
        }
        [pscustomobject]@{
            manageEngine      = $me
            subscriptionLabels = [pscustomobject]@{ 'sub-1' = 'my-subscription' }
        }
    }

    $script:TicketInput = @{
        Role = 'Reader'; Environment = 'Sandbox'; SubscriptionId = 'sub-1'; DurationDays = 7
    }
}

Describe 'Get-ManageEngineClosureFields' {
    It 'falls back to the documented unverified defaults when Config is $null' {
        $f = Get-ManageEngineClosureFields -Config $null
        $f.UdfFields['udf_pick_3713'] | Should -Be 'Yes'
        $f.UdfFields['udf_pick_3722'] | Should -Be 'Access Granted'
        $f.ResolutionContent | Should -Match 'AzureSentry unattended ticket poller'
    }

    It 'falls back to the defaults when manageEngine has no closureFields block' {
        $config = [pscustomobject]@{ manageEngine = [pscustomobject]@{ baseUrl = 'https://x' } }
        $f = Get-ManageEngineClosureFields -Config $config
        $f.UdfFields['udf_pick_3713'] | Should -Be 'Yes'
    }

    It 'honours a fully overridden udfFields map and drops the built-in defaults' {
        $config = New-NoteConfig -ClosureFields ([pscustomobject]@{
                udfFields = [pscustomobject]@{ udf_pick_9999 = 'Confirmed' }
            })
        $f = Get-ManageEngineClosureFields -Config $config
        $f.UdfFields.Count | Should -Be 1
        $f.UdfFields['udf_pick_9999'] | Should -Be 'Confirmed'
        $f.UdfFields.Contains('udf_pick_3713') | Should -BeFalse
    }

    It 'ignores underscore-prefixed documentation/label keys inside udfFields' {
        $config = New-NoteConfig -ClosureFields ([pscustomobject]@{
                udfFields = [pscustomobject]@{
                    udf_pick_3713          = 'No'
                    _udf_pick_3713_label   = 'Vendor Compliance'
                }
            })
        $f = Get-ManageEngineClosureFields -Config $config
        $f.UdfFields.Count | Should -Be 1
        $f.UdfFields['udf_pick_3713'] | Should -Be 'No'
    }

    It 'honours an overridden resolutionContent' {
        $config = New-NoteConfig -ClosureFields ([pscustomobject]@{ resolutionContent = 'Custom close text.' })
        (Get-ManageEngineClosureFields -Config $config).ResolutionContent | Should -Be 'Custom close text.'
    }
}

Describe 'Send-ManageEngineProcessNote -- configuration guard' {
    It 'returns an error and makes no network call when ManageEngine is not configured' {
        Mock -CommandName Invoke-RestMethod -MockWith { throw 'must not be called' }
        $config = New-NoteConfig -BaseUrl '' -ApiKey ''
        $r = Send-ManageEngineProcessNote -MeTicketId '1001' -TicketInput $script:TicketInput `
            -Decision @{ Action = 'Grant'; Path = 'auto' } -Config $config
        $r.error | Should -Be 'ManageEngine not configured'
        Should -Invoke -CommandName Invoke-RestMethod -Times 0
    }
}

Describe 'Send-ManageEngineProcessNote -- success path (Config parameter, not script-scope $config)' {
    It 'posts a note and reports notifyRequester true' {
        Mock -CommandName Invoke-RestMethod -MockWith { return @{ request = @{ id = '1001' } } }
        $config = New-NoteConfig
        $r = Send-ManageEngineProcessNote -MeTicketId '1001' -TicketInput $script:TicketInput `
            -Decision @{ Action = 'Grant'; Path = 'auto' } `
            -Execution @{ Success = $true; AssignmentType = 'GroupMembership' } -Config $config
        $r.error | Should -BeNullOrEmpty
        $r.notifyRequester | Should -BeTrue
        Should -Invoke -CommandName Invoke-RestMethod -Times 1 -ParameterFilter { $Method -eq 'Post' -and $Uri -match '/notes$' }
    }
}

Describe 'Send-ManageEngineProcessNote -- failure note (Get-ManageEngineNoteKind Failed branch)' {
    It 'writes an honest failure note that never implies access was granted' {
        $captured = $null
        Mock -CommandName Invoke-RestMethod -MockWith {
            $script:captured = $Body
            return @{ ok = $true }
        }
        $config = New-NoteConfig
        $r = Send-ManageEngineProcessNote -MeTicketId '1001' -TicketInput $script:TicketInput `
            -Decision @{ Action = 'Grant'; Path = 'auto' } `
            -Execution @{ Success = $false; Error = 'ARM returned 403' } -Config $config
        $r.error | Should -BeNullOrEmpty

        # The description is urlencoded inside input_data=... -- decode to inspect it.
        $encoded = $script:captured -replace '^input_data=', ''
        $decoded = [System.Uri]::UnescapeDataString($encoded)
        $decoded | Should -Match 'could not be automatically provisioned'
        $decoded | Should -Match 'No Azure access has been granted'
        $decoded | Should -Match 'A human will verify'
        $decoded | Should -Not -Match 'access is active and time-bound'
        $decoded | Should -Not -Match 'AzureSentry access update'
        $decoded | Should -Match 'ARM returned 403'
    }

    It 'classifies as Failed via Get-ManageEngineNoteKind, not Revoke, when Execution.Success is explicitly false' {
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Grant' } -Execution @{ Success = $false }
        $kind.Kind | Should -Be 'Failed'
    }

    It 'does not classify as Failed merely because Execution has no Success property at all' {
        # Every existing dashboard call site only calls this once success is already
        # known -- Execution.Success being ABSENT must not be confused with FALSE.
        $kind = Get-ManageEngineNoteKind -Decision @{ Action = 'Grant' } -Execution @{ AssignmentType = 'GroupMembership' }
        $kind.Kind | Should -Be 'GroupMembership'
    }
}

Describe 'Set-ManageEngineTicketResolved -- configuration guard' {
    It 'returns an error and makes no network call when ManageEngine is not configured' {
        Mock -CommandName Invoke-RestMethod -MockWith { throw 'must not be called' }
        $config = New-NoteConfig -BaseUrl '' -ApiKey ''
        $r = Set-ManageEngineTicketResolved -MeTicketId '1001' -Config $config
        $r.error | Should -Be 'ManageEngine not configured'
        Should -Invoke -CommandName Invoke-RestMethod -Times 0
    }
}

Describe 'Set-ManageEngineTicketResolved -- success path' {
    It 'PUTs status Resolved, resolution.content, and the configured udf closure fields' {
        $captured = $null
        Mock -CommandName Invoke-RestMethod -MockWith {
            $script:captured = $Body
            return @{ request = @{ id = '1001' } }
        }
        $config = New-NoteConfig
        $r = Set-ManageEngineTicketResolved -MeTicketId '1001' -Config $config
        $r.success | Should -BeTrue
        $r.error | Should -BeNullOrEmpty

        $encoded = $script:captured -replace '^input_data=', ''
        $decoded = [System.Uri]::UnescapeDataString($encoded)
        $decoded | Should -Match '"name":"Resolved"'
        $decoded | Should -Match 'udf_pick_3713'
        $decoded | Should -Match 'udf_pick_3722'
        $decoded | Should -Match 'Access Granted'

        Should -Invoke -CommandName Invoke-RestMethod -Times 1 -ParameterFilter {
            $Method -eq 'Put' -and $Uri -match '/api/v3/requests/1001$'
        }
    }

    It 'writes the config-overridden closure fields, not the built-in defaults, when overridden' {
        $captured = $null
        Mock -CommandName Invoke-RestMethod -MockWith {
            $script:captured = $Body
            return @{ ok = $true }
        }
        $config = New-NoteConfig -ClosureFields ([pscustomobject]@{
                udfFields = [pscustomobject]@{ udf_pick_1234 = 'Confirmed' }
                resolutionContent = 'Verified manually against a real ticket.'
            })
        Set-ManageEngineTicketResolved -MeTicketId '2002' -Config $config | Out-Null
        $decoded = [System.Uri]::UnescapeDataString(($script:captured -replace '^input_data=', ''))
        $decoded | Should -Match 'udf_pick_1234'
        $decoded | Should -Not -Match 'udf_pick_3713'
        $decoded | Should -Match 'Verified manually against a real ticket'
    }
}

Describe 'Set-ManageEngineTicketResolved -- never throws (non-fatal by contract)' {
    It 'returns success=false with the error text when the REST call throws' {
        Mock -CommandName Invoke-RestMethod -MockWith { throw 'ManageEngine timed out' }
        $config = New-NoteConfig
        { Set-ManageEngineTicketResolved -MeTicketId '3003' -Config $config } | Should -Not -Throw
        $r = Set-ManageEngineTicketResolved -MeTicketId '3003' -Config $config
        $r.success | Should -BeFalse
        $r.error | Should -Match 'ManageEngine timed out'
    }
}
