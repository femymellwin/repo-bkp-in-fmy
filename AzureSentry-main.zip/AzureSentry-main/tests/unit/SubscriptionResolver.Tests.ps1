﻿BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\SubscriptionResolver.ps1')

    $script:Pool = @(
        [pscustomobject]@{ id = 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'; label = 'inception-ai-Sandbox' }
        [pscustomobject]@{ id = '5a23842e-609d-42d4-bae5-e48e00e5b28d'; label = 'inception-internal-product' }
        [pscustomobject]@{ id = '1f0eb417-e64c-4f97-9b12-261157d44b6d'; label = 'shared-applications' }
        [pscustomobject]@{ id = '11111111-1111-1111-1111-111111111111'; label = 'payments-sandbox' }
        [pscustomobject]@{ id = '22222222-2222-2222-2222-222222222222'; label = 'payments-prod' }
    )
}

Describe 'Get-SubscriptionEnvironmentFromName' {
    It 'classifies sandbox names' {
        Get-SubscriptionEnvironmentFromName -Name 'inception-ai-Sandbox' | Should -Be 'Sandbox'
        Get-SubscriptionEnvironmentFromName -Name 'foo-sbx-01' | Should -Be 'Sandbox'
    }

    It 'classifies non-prod names, including dev and test' {
        Get-SubscriptionEnvironmentFromName -Name 'app-nonprod' | Should -Be 'NonProd'
        Get-SubscriptionEnvironmentFromName -Name 'app-dev' | Should -Be 'NonProd'
        Get-SubscriptionEnvironmentFromName -Name 'app-uat' | Should -Be 'NonProd'
        Get-SubscriptionEnvironmentFromName -Name 'app-test' | Should -Be 'NonProd'
    }

    It 'does not read non-prod as Production' {
        Get-SubscriptionEnvironmentFromName -Name 'payments-non-prod' | Should -Be 'NonProd'
    }

    It 'returns Unknown rather than guessing Production' {
        Get-SubscriptionEnvironmentFromName -Name 'shared-applications' | Should -Be 'Unknown'
        Get-SubscriptionEnvironmentFromName -Name '' | Should -Be 'Unknown'
    }
}

Describe 'Resolve-TicketSubscription — FR3 multi-subscription disambiguation' {

    Context 'exact matches' {
        It 'resolves an allowlisted subscription id' {
            $r = Resolve-TicketSubscription -Reference 'efae0e0e-09ab-4c17-82db-d2d1f4382d66' -Subscriptions $script:Pool
            $r.Status | Should -Be 'Resolved'
            $r.MatchType | Should -Be 'ExactId'
            $r.SubscriptionId | Should -Be 'efae0e0e-09ab-4c17-82db-d2d1f4382d66'
        }

        It 'rejects a well-formed id that is not allowlisted' {
            $r = Resolve-TicketSubscription -Reference '99999999-9999-9999-9999-999999999999' -Subscriptions $script:Pool
            $r.Status | Should -Be 'NotFound'
            $r.Reason | Should -Match 'not on the effective allowlist'
        }

        It 'resolves an exact name case-insensitively' {
            $r = Resolve-TicketSubscription -Reference 'INCEPTION-AI-SANDBOX' -Subscriptions $script:Pool
            $r.Status | Should -Be 'Resolved'
            $r.MatchType | Should -Be 'ExactName'
        }
    }

    Context 'keyword matches' {
        It 'resolves a keyword that matches exactly one subscription' {
            $r = Resolve-TicketSubscription -Reference 'shared-applications' -Subscriptions $script:Pool
            $r.Status | Should -Be 'Resolved'
            $r.SubscriptionId | Should -Be '1f0eb417-e64c-4f97-9b12-261157d44b6d'
        }

        It 'tolerates extra words around the subscription name' {
            $r = Resolve-TicketSubscription -Reference 'shared applications' -Subscriptions $script:Pool
            $r.Status | Should -Be 'Resolved'
        }
    }

    Context 'ambiguity — the behaviour the review asked to define' {
        It 'never resolves when a keyword matches several subscriptions' {
            $r = Resolve-TicketSubscription -Reference 'payments' -Subscriptions $script:Pool
            $r.Status | Should -Be 'NeedsHumanChoice'
            $r.SubscriptionId | Should -BeNullOrEmpty
        }

        It 'returns every candidate so an operator can choose' {
            $r = Resolve-TicketSubscription -Reference 'payments' -Subscriptions $script:Pool
            @($r.Candidates).Count | Should -Be 2
            @($r.Candidates.label) | Should -Contain 'payments-sandbox'
            @($r.Candidates.label) | Should -Contain 'payments-prod'
        }

        It 'says explicitly that it will not grant across all matches' {
            $r = Resolve-TicketSubscription -Reference 'payments' -Subscriptions $script:Pool
            $r.Reason | Should -Match 'will not grant across all matches'
        }

        It 'uses the requested environment to break the tie when it leaves exactly one' {
            $r = Resolve-TicketSubscription -Reference 'payments' -Subscriptions $script:Pool -Environment 'Sandbox'
            $r.Status | Should -Be 'Resolved'
            $r.MatchType | Should -Be 'EnvironmentFilter'
            $r.Label | Should -Be 'payments-sandbox'
        }

        It 'still asks for a human when the environment filter matches none of the candidates' {
            $r = Resolve-TicketSubscription -Reference 'payments' -Subscriptions $script:Pool -Environment 'NonProd'
            $r.Status | Should -Be 'NeedsHumanChoice'
        }

        It 'still asks for a human when the environment filter leaves more than one' {
            $pool = @(
                [pscustomobject]@{ id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; label = 'core-sandbox-eu' }
                [pscustomobject]@{ id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'; label = 'core-sandbox-us' }
            )
            $r = Resolve-TicketSubscription -Reference 'core' -Subscriptions $pool -Environment 'Sandbox'
            $r.Status | Should -Be 'NeedsHumanChoice'
            @($r.Candidates).Count | Should -Be 2
        }
    }

    Context 'missing or unmatched references' {
        It 'reports a missing subscription reference as NotFound' {
            $r = Resolve-TicketSubscription -Reference '' -Subscriptions $script:Pool
            $r.Status | Should -Be 'NotFound'
            $r.Reason | Should -Match 'did not name a subscription'
        }

        It 'reports an unmatched keyword as NotFound' {
            $r = Resolve-TicketSubscription -Reference 'totally-unrelated-thing' -Subscriptions $script:Pool
            $r.Status | Should -Be 'NotFound'
        }

        It 'reports NotFound against an empty pool' {
            (Resolve-TicketSubscription -Reference 'payments' -Subscriptions @()).Status | Should -Be 'NotFound'
        }
    }
}
