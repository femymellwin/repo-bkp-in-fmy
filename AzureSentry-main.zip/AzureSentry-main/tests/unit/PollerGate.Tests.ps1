BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    . (Join-Path $repoRoot 'src\Agents\PollerGate.ps1')

    function New-Decision {
        param([string]$Action = 'Grant', [string]$EffectiveEnvironment = 'Sandbox')
        [pscustomobject]@{ Action = $Action; EffectiveEnvironment = $EffectiveEnvironment; Path = 'test' }
    }

    function New-Mapping {
        param([bool]$Complete = $true, [string[]]$Warnings = @())
        [pscustomobject]@{ Complete = $Complete; Warnings = $Warnings; Ticket = [pscustomobject]@{ Role = 'Reader' } }
    }
}

Describe 'Test-PollerAutoEligible -- the unattended gate' {

    It 'allows Grant on Sandbox' {
        (Test-PollerAutoEligible -Decision (New-Decision) -Mapping (New-Mapping) -TemplateAllowed $true).Eligible |
            Should -BeTrue
    }

    It 'allows Grant on NonProd' {
        (Test-PollerAutoEligible -Decision (New-Decision -EffectiveEnvironment 'NonProd') -Mapping (New-Mapping) -TemplateAllowed $true).Eligible |
            Should -BeTrue
    }

    It 'refuses Grant on Production even though the matrix marks prod-reader as Grant' {
        # prod-reader-standard / prod-reader-expedited are action=Grant with no approver.
        # Read-only, but still unattended Production access -- excluded by decision.
        $r = Test-PollerAutoEligible -Decision (New-Decision -EffectiveEnvironment 'Production') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'Production'
    }

    It 'refuses Eligible -- its approval gate is the operator click in the dashboard' {
        $r = Test-PollerAutoEligible -Decision (New-Decision -Action 'Eligible' -EffectiveEnvironment 'NonProd') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'Eligible'
    }

    It 'refuses Hold, Reject and BreakGlass' {
        foreach ($action in @('Hold', 'Reject', 'BreakGlass')) {
            $r = Test-PollerAutoEligible -Decision (New-Decision -Action $action) -Mapping (New-Mapping) -TemplateAllowed $true
            $r.Eligible | Should -BeFalse
        }
    }

    It 'refuses an incomplete mapping' {
        $r = Test-PollerAutoEligible -Decision (New-Decision) -Mapping (New-Mapping -Complete $false -Warnings @('Environment dropdown is not set.')) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'Environment dropdown'
    }

    It 'refuses a non-grant template' {
        $r = Test-PollerAutoEligible -Decision (New-Decision) -Mapping (New-Mapping) -TemplateAllowed $false
        $r.Eligible | Should -BeFalse
        $r.Reason | Should -Match 'template'
    }

    It 'refuses when the effective environment is missing rather than assuming it is safe' {
        $r = Test-PollerAutoEligible -Decision (New-Decision -EffectiveEnvironment '') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Eligible | Should -BeFalse
    }

    It 'gives a reason on every refusal' {
        $r = Test-PollerAutoEligible -Decision (New-Decision -Action 'Reject') -Mapping (New-Mapping) -TemplateAllowed $true
        $r.Reason | Should -Not -BeNullOrEmpty
    }
}

Describe 'Resolve-PollerStatusView -- final-review C3' {

    BeforeAll {
        function New-Cycle {
            param(
                [string]$Mode = 'enforce',
                [bool]$Halted = $false,
                [string]$HaltReason = '',
                [string]$RanAt = ([datetime]::UtcNow.ToString('o'))
            )
            [pscustomobject]@{ mode = $Mode; halted = $Halted; haltReason = $HaltReason; ranAt = $RanAt }
        }
    }

    It 'reports enforce from the status file regardless of this process''s own env vars' {
        # The whole point of C3: simulate the dashboard process having stale/contradictory
        # env vars of its own -- the view must still say what the POLLER last reported.
        $old = @{ e = $env:AZURESENTRY_POLLER_ENABLED; m = $env:AZURESENTRY_POLLER_MODE }
        try {
            $env:AZURESENTRY_POLLER_ENABLED = 'false'
            $env:AZURESENTRY_POLLER_MODE = 'shadow'
            $view = Resolve-PollerStatusView -LastCycle (New-Cycle -Mode 'enforce')
            $view.Enabled | Should -BeTrue
            $view.Mode | Should -Be 'enforce'
            $view.Stale | Should -BeFalse
        }
        finally {
            if ($null -ne $old.e) { $env:AZURESENTRY_POLLER_ENABLED = $old.e } else { Remove-Item Env:\AZURESENTRY_POLLER_ENABLED -ErrorAction SilentlyContinue }
            if ($null -ne $old.m) { $env:AZURESENTRY_POLLER_MODE = $old.m } else { Remove-Item Env:\AZURESENTRY_POLLER_MODE -ErrorAction SilentlyContinue }
        }
    }

    It 'reports disabled only when halted for the specific enabled-kill-switch reason' {
        $view = Resolve-PollerStatusView -LastCycle (New-Cycle -Halted $true -HaltReason 'AZURESENTRY_POLLER_ENABLED is not true.')
        $view.Enabled | Should -BeFalse
    }

    It 'reports enabled when halted for a DIFFERENT reason (stop sentinel)' {
        # A halt is not automatically "disabled" -- only the enabled-kill-switch reason is.
        $view = Resolve-PollerStatusView -LastCycle (New-Cycle -Halted $true -HaltReason 'Stop sentinel present at /opt/azuresentry/dashboard/api/poller.stop.')
        $view.Enabled | Should -BeTrue
    }

    It 'reports unknown (nulls, Stale) when no status has ever been recorded' {
        $view = Resolve-PollerStatusView -LastCycle $null
        $view.Enabled | Should -BeNullOrEmpty
        $view.Mode | Should -BeNullOrEmpty
        $view.Stale | Should -BeTrue
    }

    It 'reports unknown rather than a confident Off for a stale status file' {
        $view = Resolve-PollerStatusView -LastCycle (New-Cycle -RanAt ([datetime]::UtcNow.AddHours(-2).ToString('o'))) -StaleAfterMinutes 15
        $view.Enabled | Should -BeNullOrEmpty
        $view.Stale | Should -BeTrue
    }

    It 'reports unknown for an unparseable ranAt rather than assuming freshness' {
        $view = Resolve-PollerStatusView -LastCycle (New-Cycle -RanAt 'not-a-date')
        $view.Stale | Should -BeTrue
        $view.Enabled | Should -BeNullOrEmpty
    }

    It 'treats a cycle just inside the staleness window as fresh' {
        $view = Resolve-PollerStatusView -LastCycle (New-Cycle -RanAt ([datetime]::UtcNow.AddMinutes(-10).ToString('o'))) -StaleAfterMinutes 15
        $view.Stale | Should -BeFalse
        $view.Enabled | Should -BeTrue
    }
}
