BeforeAll {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    $script:Runbook = Join-Path $repoRoot 'src\Runbooks\Runbook-Prod-PIM.ps1'

    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force

    $script:SandboxSub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    $script:ProdSub = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    $script:Allowlist = @($script:SandboxSub, $script:ProdSub)

    function New-TestTicket {
        param(
            [string]$Environment = 'Production',
            [string]$Role = 'Reader',
            [string]$Priority = 'P3',
            [int]$DurationDays = 7,
            [string]$Justification = '',
            [hashtable]$Extra = @{}
        )

        $ticket = @{
            TicketId       = [guid]::NewGuid().ToString()
            Role           = $Role
            Environment    = $Environment
            SubscriptionId = if ($Environment -eq 'Sandbox') { $script:SandboxSub } else { $script:ProdSub }
            ResourceScope  = "/subscriptions/$(if ($Environment -eq 'Sandbox') { $script:SandboxSub } else { $script:ProdSub })"
            DurationDays   = $DurationDays
            Priority       = $Priority
            RequesterUpn   = 'test.user@contoso.com'
            SubmitterUpn   = 'test.user@contoso.com'
            SubscriptionName = if ($Environment -eq 'Sandbox') { 'platform-sandbox' } else { 'platform-prod' }
            Justification  = $Justification
        }
        foreach ($k in $Extra.Keys) { $ticket[$k] = $Extra[$k] }
        if ($Environment -eq 'Production' -and [string]::IsNullOrWhiteSpace($ticket.Justification)) {
            $ticket.Justification = 'Production access for sprint work item 12345'
        }
        return $ticket
    }

    function Invoke-ProdRunbook {
        param([hashtable]$Ticket)
        return & $script:Runbook -Ticket $Ticket -SubscriptionAllowlist $script:Allowlist `
            -PimClientImplementation 'Mock'
    }
}

Describe 'Runbook-Prod-PIM - eligible PIM path (interim: native PIM approval gates fulfilment)' {
    BeforeEach {
        Reset-MockPimState
        Mock Import-Module {}
    }

    It 'creates an Eligible PIM request for Contributor, gated on native PIM approval' {
        $result = Invoke-ProdRunbook -Ticket (New-TestTicket -Role Contributor -Priority P2)

        $result.Success | Should -Be $true
        $result.RequestId | Should -Not -BeNullOrEmpty
        $result.AssignmentType | Should -Be 'Eligible'
        $result.RequiresApproval | Should -Be $true
        $result.ApproverTier | Should -Be 'Primary'
    }

    It 'resolves the requester UPN to the mock object id' {
        $result = Invoke-ProdRunbook -Ticket (New-TestTicket -Role Contributor -Priority P3)
        $result.Success | Should -Be $true
        $result.UserId | Should -Be '11111111-1111-1111-1111-111111111111'
    }

    It 'keeps Owner on eligible PIM with dual approval and MFA' {
        $result = Invoke-ProdRunbook -Ticket (New-TestTicket -Role Owner -Priority P3)

        $result.Success | Should -Be $true
        $result.RequestId | Should -Not -BeNullOrEmpty
        $result.AssignmentType | Should -Be 'Eligible'
        $result.RequiresApproval | Should -Be $true
        $result.ApproverTier | Should -Be 'Dual'
        $result.MfaRequired | Should -Be $true
    }

    It 'surfaces the SLA hours from the decision record' {
        $result = Invoke-ProdRunbook -Ticket (New-TestTicket -Role Contributor -Priority P3)
        $result.Success | Should -Be $true
        $result.SlaHours | Should -Be 24
    }

    It 'reports the Mock client implementation' {
        $result = Invoke-ProdRunbook -Ticket (New-TestTicket -Role Contributor -Priority P3)
        $result.PimClient | Should -Be 'Mock'
    }
}

Describe 'Runbook-Prod-PIM - non-Eligible decisions fail closed' {
    It 'sandbox-owner - policy block, Success false' {
        $result = Invoke-ProdRunbook -Ticket (New-TestTicket -Environment Sandbox -Role Owner -Priority P3)
        $result.Success | Should -Be $false
        $result.Decision.Action | Should -Be 'Reject'
        $result.Decision.Path | Should -Be 'Policy-Block'
        $result.Message | Should -Not -BeNullOrEmpty
    }

    It 'custom-role - governance Hold, Success false' {
        $result = Invoke-ProdRunbook -Ticket (New-TestTicket -Role Custom -Priority P3)
        $result.Success | Should -Be $false
        $result.Decision.Action | Should -Be 'Hold'
        $result.Decision.Path | Should -Be 'Governance-Review'
        $result.Message | Should -Not -BeNullOrEmpty
    }

    It 'subscription off allowlist - reject, Success false' {
        $ticket = New-TestTicket -Role Reader -Priority P3
        $ticket.SubscriptionId = 'ffffffff-ffff-ffff-ffff-ffffffffffff'
        $ticket.ResourceScope = '/subscriptions/ffffffff-ffff-ffff-ffff-ffffffffffff'
        $result = Invoke-ProdRunbook -Ticket $ticket
        $result.Success | Should -Be $false
        $result.Decision.Path | Should -Be 'Allowlist-Reject'
    }
}
