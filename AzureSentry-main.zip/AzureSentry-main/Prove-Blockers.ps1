<#
.SYNOPSIS
    Demonstrates, on real Azure, the two access dependencies that block the
    AzureSentry production/emergency runbooks and ManageEngine webhook from
    being deployed and operated. Prints a clean BLOCKED / PASS summary.

.DESCRIPTION
    Run this in front of (or capture and send to) the cloud admin team. It runs
    three read-mostly checks against the signed-in Azure CLI session:

      1. Can I create RBAC role assignments?  (needs Owner / User Access Administrator)
      2. Do I hold an Entra admin role?        (needs Global Admin / Privileged Role Admin)
      3. Can I read org licensing / P2 SKUs?   (standard members are denied)

    Check 1 attempts a role assignment that Azure denies under Contributor - it
    is a denied no-op, nothing is created. If it unexpectedly succeeds, the
    script deletes what it made.

.PARAMETER Subscription
    Target subscription ID (defaults to inception-internal-product).
#>
[CmdletBinding()]
param(
    [string]$Subscription = '5a23842e-609d-42d4-bae5-e48e00e5b28d'
)

$ErrorActionPreference = 'Continue'
$results = [System.Collections.ArrayList]@()

function Add-Result {
    param([string]$Name, [bool]$Blocked, [string]$Detail, [string]$Needs)
    [void]$results.Add([PSCustomObject]@{ Name = $Name; Blocked = $Blocked; Detail = $Detail; Needs = $Needs })
}

Write-Host "`n=== AzureSentry - Access Blocker Proof ===`n" -ForegroundColor Cyan

$me  = az account show --query user.name -o tsv 2>$null
$oid = az ad signed-in-user show --query id -o tsv 2>$null
if ([string]::IsNullOrWhiteSpace($oid)) {
    Write-Host "Not signed in to Azure CLI. Run: az login" -ForegroundColor Red
    exit 1
}
Write-Host ("Signed in as : {0}" -f $me)
Write-Host ("Object ID    : {0}" -f $oid)
Write-Host ("Subscription : {0}`n" -f $Subscription)

# --- Check 1: RBAC role-assignment write -----------------------------------
$out = az role assignment create --assignee-object-id $oid --assignee-principal-type User `
    --role 'Reader' --scope "/subscriptions/$Subscription" 2>&1 | Out-String
if ($out -match 'AuthorizationFailed') {
    Add-Result 'Create RBAC role assignments' $true 'AuthorizationFailed on Microsoft.Authorization/roleAssignments/write' 'Owner / User Access Administrator'
}
elseif ($out -match '"id"\s*:' -or $out -match 'roleDefinitionId') {
    # Unexpected success - clean up the assignment we just created.
    az role assignment delete --assignee-object-id $oid --role 'Reader' --scope "/subscriptions/$Subscription" 2>&1 | Out-Null
    Add-Result 'Create RBAC role assignments' $false 'UNEXPECTED: assignment created (you DO have this access) - removed it' 'Owner / User Access Administrator'
}
else {
    $first = ($out -split "`r?`n" | Where-Object { $_ -match '\S' } | Select-Object -First 1)
    Add-Result 'Create RBAC role assignments' $true ("Denied: $first") 'Owner / User Access Administrator'
}

# --- Check 2: Entra admin (directory) role ---------------------------------
$roles = (az rest --method get --url 'https://graph.microsoft.com/v1.0/me/memberOf/microsoft.graph.directoryRole' --query 'value[].displayName' -o tsv 2>&1 | Out-String).Trim()
if ([string]::IsNullOrWhiteSpace($roles) -or $roles -match 'Forbidden|RequestDenied') {
    Add-Result 'Hold an Entra admin role' $true 'No directory roles assigned (standard member)' 'Global Admin / Privileged Role Administrator'
}
else {
    Add-Result 'Hold an Entra admin role' $false ("Has roles: " + (($roles -split "`r?`n") -join ', ')) 'Global Admin / Privileged Role Administrator'
}

# --- Check 3: Read org licensing / P2 SKUs ---------------------------------
$sku = az rest --method get --url 'https://graph.microsoft.com/v1.0/subscribedSkus' 2>&1 | Out-String
if ($sku -match 'Forbidden|Authorization_RequestDenied|Insufficient privileges') {
    Add-Result 'Read org licensing / confirm P2 SKUs' $true 'Forbidden (Authorization_RequestDenied)' 'Global Admin / Privileged Role Administrator'
}
else {
    Add-Result 'Read org licensing / confirm P2 SKUs' $false 'Can read subscribedSkus' 'Global Admin / Privileged Role Administrator'
}

# --- Summary ---------------------------------------------------------------
foreach ($r in $results) {
    if ($r.Blocked) {
        Write-Host ("[BLOCKED] {0}" -f $r.Name) -ForegroundColor Red
        Write-Host ("          {0}" -f $r.Detail) -ForegroundColor DarkGray
        Write-Host ("          needs: {0}" -f $r.Needs) -ForegroundColor DarkGray
    }
    else {
        Write-Host ("[ PASS  ] {0}" -f $r.Name) -ForegroundColor Green
        Write-Host ("          {0}" -f $r.Detail) -ForegroundColor DarkGray
    }
}

$blocked = @($results | Where-Object { $_.Blocked }).Count
Write-Host ""
if ($blocked -gt 0) {
    Write-Host ("$blocked of $($results.Count) checks BLOCKED - admin grants required to proceed:" ) -ForegroundColor Yellow
    Write-Host "  - User Access Administrator (to apply the platform's RBAC role assignments)" -ForegroundColor Yellow
    Write-Host "  - Global Admin / Privileged Role Admin (to consent the Automation identity's Graph permissions; confirm Entra P2)" -ForegroundColor Yellow
}
else {
    Write-Host "No blockers detected - you have the access needed to proceed." -ForegroundColor Green
}
Write-Host ""

# The denials above are the expected proof; exit clean so the script itself
# does not look like it errored.
exit 0
