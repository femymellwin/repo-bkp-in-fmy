$privateScripts = @(Get-ChildItem -Path (Join-Path $PSScriptRoot 'Private') -Filter '*.ps1' -ErrorAction SilentlyContinue)
foreach ($script in $privateScripts) {
    . $script.FullName
}

$publicScripts = @(Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -ErrorAction SilentlyContinue)
foreach ($script in $publicScripts) {
    . $script.FullName
}

$publicNames = @(Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' | ForEach-Object { [System.IO.Path]::GetFileNameWithoutExtension($_.Name) })
# Get-RoleCatalogEntry / Get-RoleCatalogNames are private helpers but are part of the
# catalog contract consumed by PIM clients, runbooks, and tests.
Export-ModuleMember -Function ($publicNames + @('Get-RoleCatalogEntry', 'Get-RoleCatalogNames'))
