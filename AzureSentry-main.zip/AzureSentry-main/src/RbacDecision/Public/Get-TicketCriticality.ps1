﻿function Get-TicketCriticality {
    <#
    .SYNOPSIS
        FR1 — computes effective ticket criticality with ENVIRONMENT as the primary
        signal and requester-declared priority only as a tiebreaker.

    .DESCRIPTION
        The stakeholder rule this implements: a P1 claimed on Non-Prod must not
        outrank a Production ticket. So the ordering is:

            Production  ->  Non-Prod  ->  Sandbox  ->  Unknown
                 (then P0 .. P4 inside each environment band)

        Requester-declared priority stays a non-mandatory field with a P4 default —
        it is captured and used, but it can no longer jump the queue across
        environments. When someone claims P0/P1/P2 on a non-Production environment,
        the result carries PriorityDemoted plus a reason, so the demotion is visible
        rather than silent.

        Environment must be mandatory on new tickets (see the ManageEngine template
        change). Until the ~2000 existing tickets are backfilled, 'Unknown' sorts
        last and is flagged RequiresEnvironment so the Sentry Governance Agent's
        backfill queue is exactly the set of tickets that cannot be prioritized.

    .PARAMETER Environment
        Environment as claimed on the ticket: Sandbox | NonProd | Production | Unknown.

    .PARAMETER EffectiveEnvironment
        Environment after subscription-sensitivity escalation (Get-EffectiveEnvironment).
        When supplied it wins — a "sandbox" request against a sensitive subscription
        must be prioritized as the Production request it really is.

    .PARAMETER Priority
        P0 .. P4 as supplied by the requester. Blank/unrecognised defaults to P4.

    .OUTPUTS
        pscustomobject with Score (lower = more urgent), Tier, EnvironmentRank,
        PriorityRank, PriorityDemoted, RequiresEnvironment, Label, Reason.
    #>
    [CmdletBinding()]
    param(
        [string]$Environment,
        [string]$EffectiveEnvironment,
        [string]$Priority
    )

    # --- normalize environment -------------------------------------------------
    $claimed = ([string]$Environment).Trim()
    $effective = ([string]$EffectiveEnvironment).Trim()
    $envForRank = if ($effective) { $effective } else { $claimed }

    $envNorm = switch -Regex (([string]$envForRank).ToLowerInvariant()) {
        '^prod|^production$' { 'Production'; break }
        'non[\s_-]?prod|^nonprod$|pre[\s_-]?prod|^stag|^uat$|^qa$|^test$|^dev' { 'NonProd'; break }
        '^sandbox|^sbx$|^sand$' { 'Sandbox'; break }
        default { 'Unknown' }
    }

    $environmentRank = switch ($envNorm) {
        'Production' { 0 }
        'NonProd' { 1 }
        'Sandbox' { 2 }
        default { 3 }
    }

    # --- normalize priority ----------------------------------------------------
    $prioNorm = 'P4'
    if (([string]$Priority) -match '(?i)\bP([0-4])\b') { $prioNorm = "P$($Matches[1])" }
    $priorityRank = [int]($prioNorm.Substring(1))
    $prioritySupplied = -not [string]::IsNullOrWhiteSpace($Priority)

    # Composite: environment band dominates; priority orders within the band.
    # Multiplier > max priority rank so no priority can cross an environment boundary.
    $score = ($environmentRank * 10) + $priorityRank

    $tier = switch ($envNorm) {
        'Production' { 'Critical' }
        'NonProd' { 'High' }
        'Sandbox' { 'Standard' }
        default { 'Unclassified' }
    }

    $priorityDemoted = ($priorityRank -le 2 -and $envNorm -ne 'Production')
    $requiresEnvironment = ($envNorm -eq 'Unknown')

    $envLabel = if ($envNorm -eq 'NonProd') { 'Non-Prod' } else { $envNorm }
    $reasonParts = [System.Collections.Generic.List[string]]::new()
    $reasonParts.Add("Environment $envLabel sets the criticality band ($tier).")
    if ($effective -and $claimed -and $effective -ne $claimed) {
        $reasonParts.Add("Environment escalated from claimed '$claimed' to effective '$effective' by subscription sensitivity.")
    }
    if (-not $prioritySupplied) {
        $reasonParts.Add('No priority supplied; defaulted to P4 (secondary signal only).')
    }
    if ($priorityDemoted) {
        $reasonParts.Add("$prioNorm was claimed on $envLabel — priority orders within the $envLabel band only and cannot outrank a Production ticket.")
    }
    if ($requiresEnvironment) {
        $reasonParts.Add('Environment is untagged, so this ticket cannot be prioritized — queued for governance backfill.')
    }

    return [pscustomobject]@{
        Score                = $score
        Tier                 = $tier
        Environment          = $envNorm
        EnvironmentLabel     = $envLabel
        EnvironmentRank      = $environmentRank
        Priority             = $prioNorm
        PriorityRank         = $priorityRank
        PrioritySupplied     = $prioritySupplied
        PriorityDemoted      = $priorityDemoted
        RequiresEnvironment  = $requiresEnvironment
        Label                = "$envLabel / $prioNorm"
        Reason               = ($reasonParts -join ' ')
    }
}
