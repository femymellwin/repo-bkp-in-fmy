function Get-AssignableRoleDefinitionId {
    <#
    .SYNOPSIS
        Resolve a role's Azure role definition id, or $null when the role has none.
    .DESCRIPTION
        Roles routed to governance review (e.g. Custom) intentionally carry no
        roleDefinitionId and can never be PIM-assigned. Runbooks need to learn that
        WITHOUT an exception, because they must still let the decision engine return
        its Hold/Reject. Returns $null for such a role, and $null for a role absent
        from the catalog. Genuine catalog faults (missing or malformed catalog file)
        still throw, so they are not silently mistaken for an unassignable role.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyString()][string]$RoleName,
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($RoleName)) { return $null }

    # 'User Access Administrator' is Azure's display name; tickets use the short 'UAA'.
    $name = if ($RoleName -eq 'User Access Administrator') { 'UAA' } else { $RoleName }

    $entry = if ($PSBoundParameters.ContainsKey('Path') -and $Path) {
        Get-RoleCatalogEntry -RoleName $name -Path $Path
    }
    else {
        Get-RoleCatalogEntry -RoleName $name
    }

    if (-not $entry) { return $null }
    if ([string]::IsNullOrWhiteSpace([string]$entry.roleDefinitionId)) { return $null }
    return [string]$entry.roleDefinitionId
}
