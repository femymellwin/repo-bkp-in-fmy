function Get-EffectiveEnvironment {
    <#
    .SYNOPSIS
        Resolve the effective environment for a subscription, applying the
        subscription->sensitivity map. Escalate-only: returns the MORE restrictive of
        the mapped environment and the ticket's claimed environment
        (Production > NonProd > Sandbox), so a sensitive subscription is treated as
        Production even if the ticket says "sandbox", and an explicit Production
        request is never downgraded.
    .OUTPUTS
        The effective environment string (e.g. 'Sandbox' | 'NonProd' | 'Production').
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SubscriptionId,
        [string]$ClaimedEnvironment,
        [string]$MapPath = (Join-Path $PSScriptRoot '../Data/subscription-sensitivity.json')
    )

    $rank = @{ 'Sandbox' = 1; 'NonProd' = 2; 'Production' = 3 }

    $mapped = $null
    if ($MapPath -and (Test-Path $MapPath)) {
        try {
            $map = Get-Content -Raw -Path $MapPath | ConvertFrom-Json
            if ($map.subscriptions -and ($map.subscriptions.PSObject.Properties.Name -contains $SubscriptionId)) {
                $entry = $map.subscriptions.$SubscriptionId
                $mapped = if ($entry -is [string]) { $entry } else { $entry.environment }
            }
            elseif ($map.default -and $map.default -ne 'ticket') {
                $mapped = $map.default
            }
        }
        catch { $mapped = $null }
    }

    if (-not $mapped) { return $ClaimedEnvironment }
    if (-not $ClaimedEnvironment) { return $mapped }

    $mr = if ($rank.ContainsKey($mapped)) { $rank[$mapped] } else { 0 }
    $cr = if ($rank.ContainsKey($ClaimedEnvironment)) { $rank[$ClaimedEnvironment] } else { 0 }
    return $(if ($mr -ge $cr) { $mapped } else { $ClaimedEnvironment })
}
