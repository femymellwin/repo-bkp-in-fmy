function Get-RoleTier {
    <#
    .SYNOPSIS
        Resolve an Azure RBAC role name to its AzureSentry risk tier.
    .DESCRIPTION
        Returns 'Reader', 'Contributor', 'Owner', or 'Custom' from role-catalog.json.
        Returns $null for an unknown role so callers fail closed rather than guessing.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyString()][string]$RoleName,
        [string]$Path
    )

    $entry = if ($PSBoundParameters.ContainsKey('Path') -and $Path) {
        Get-RoleCatalogEntry -RoleName $RoleName -Path $Path
    }
    else {
        Get-RoleCatalogEntry -RoleName $RoleName
    }

    if (-not $entry) { return $null }
    return [string]$entry.tier
}
