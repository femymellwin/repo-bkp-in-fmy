function Resolve-RbacDecision {
    <#
    .SYNOPSIS
        Pure 7-step RBAC decision tree per scope §3.2.
    .DESCRIPTION
        Deterministic, fail-closed classification. No I/O. Step 7 duplicate check
        uses HasExistingAssignment input supplied by runbook after PIM query.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$Ticket,

        [Parameter(Mandatory)]
        [string[]]$SubscriptionAllowlist,

        [bool]$HasExistingAssignment = $false,

        [string]$ExistingAccessReason = 'Active assignment already exists for same user, role, and scope',

        [string]$MatrixPath = (Join-Path $PSScriptRoot '../Data/eligibility-matrix.json'),

        [string]$ApproverMappingPath = (Join-Path $PSScriptRoot '../Data/approver-mapping.json'),

        [string]$SensitivityMapPath = (Join-Path $PSScriptRoot '../Data/subscription-sensitivity.json'),

        [string]$RoleCatalogPath = (Join-Path $PSScriptRoot '../Data/role-catalog.json')
    )

    $matrix = Get-Content -Raw -Path $MatrixPath | ConvertFrom-Json
    $policy = $matrix.policyBlocks
    $slaTiers = @{}
    $matrix.slaTiers.PSObject.Properties | ForEach-Object { $slaTiers[$_.Name] = $_.Value }

    # Step 1 — Schema validation
    $schema = Test-TicketSchema -Ticket $Ticket -Policy $policy -RoleCatalogPath $RoleCatalogPath
    if (-not $schema.Valid) {
        return New-DecisionRecord -Action 'Reject' -Path 'Schema-Invalid' -Reason $schema.Reason
    }

    # Cross-subscription detection (G5) — evaluated before allowlist of primary sub
    $subscriptionIds = @()
    if ($Ticket -is [hashtable] -and $Ticket.ContainsKey('SubscriptionIds') -and $Ticket.SubscriptionIds) {
        $subscriptionIds = @($Ticket.SubscriptionIds)
    }
    elseif ($Ticket.PSObject.Properties.Name -contains 'SubscriptionIds' -and $Ticket.SubscriptionIds) {
        $subscriptionIds = @($Ticket.SubscriptionIds)
    }
    else {
        $subscriptionIds = @($Ticket.SubscriptionId)
    }

    $isCrossSubscription = $subscriptionIds.Count -gt 1
    foreach ($subId in $subscriptionIds) {
        $allow = Test-SubscriptionAllowlist -SubscriptionId $subId -Allowlist $SubscriptionAllowlist
        if (-not $allow.Valid) {
            return New-DecisionRecord -Action 'Reject' -Path 'Allowlist-Reject' -Reason $allow.Reason
        }
    }

    # Subscription sensitivity override — force the effective environment BEFORE role
    # eligibility/matrix classification, so a sensitive subscription is treated as
    # Production (approval-gated) even if the ticket labels it Sandbox. Escalate-only:
    # never downgrades an explicit Production request.
    $claimedEnvironment = $Ticket.Environment
    $effectiveEnvironment = $claimedEnvironment
    foreach ($subId in $subscriptionIds) {
        $effectiveEnvironment = Get-EffectiveEnvironment -SubscriptionId $subId `
            -ClaimedEnvironment $effectiveEnvironment -MapPath $SensitivityMapPath
    }
    if ($effectiveEnvironment -and $effectiveEnvironment -ne $claimedEnvironment) {
        if ($Ticket -is [hashtable]) { $Ticket['Environment'] = $effectiveEnvironment }
        else { $Ticket.Environment = $effectiveEnvironment }
    }

    # Step 3 — Role eligibility (Owner/UAA sandbox, Custom, Bulk)
    $roleCheck = Test-RoleEligibility -Ticket $Ticket -Policy $policy -RoleCatalogPath $RoleCatalogPath
    if (-not $roleCheck.Valid) {
        return New-DecisionRecord -Action $roleCheck.Action -Path $roleCheck.Path -Reason $roleCheck.Reason
    }

    $isBreakGlass = $false
    if ($Ticket -is [hashtable]) {
        if ($Ticket.ContainsKey('BreakGlass') -and $Ticket.BreakGlass) { $isBreakGlass = $true }
        if ($Ticket.ContainsKey('BreakGlassRequest') -and $Ticket.BreakGlassRequest) { $isBreakGlass = $true }
    }
    else {
        if ($Ticket.PSObject.Properties.Name -contains 'BreakGlass' -and $Ticket.BreakGlass) { $isBreakGlass = $true }
        if ($Ticket.PSObject.Properties.Name -contains 'BreakGlassRequest' -and $Ticket.BreakGlassRequest) { $isBreakGlass = $true }
    }

    # Steps 4–6 — Environment, priority, sensitivity via eligibility matrix
    $match = Get-EligibilityMatch -Ticket $Ticket -MatrixRows $matrix.rows `
        -RoleCatalogPath $RoleCatalogPath `
        -IsCrossSubscription:$isCrossSubscription -IsBreakGlass:$isBreakGlass

    if (-not $match) {
        return New-DecisionRecord -Action 'Reject' -Path 'Unclassified' -Reason 'Request type could not be classified'
    }

    if ($match.action -eq 'Reject') {
        return New-DecisionRecord -Action 'Reject' -Path $match.path -Reason $match.reason
    }

    if ($match.action -eq 'Hold') {
        return New-DecisionRecord -Action 'Hold' -Path $match.path -Reason $match.reason
    }

    # Step 7 — Duplicate / conflict (input from runbook PIM query)
    if ($HasExistingAssignment) {
        $dupReason = if (-not [string]::IsNullOrWhiteSpace($ExistingAccessReason)) {
            $ExistingAccessReason
        }
        else {
            'Active assignment already exists for same user, role, and scope'
        }
        return New-DecisionRecord -Action 'Reject' -Path 'Duplicate-Assignment' -Reason $dupReason
    }

    $sla = Get-SlaTier -Priority $Ticket.Priority -SlaTiers $slaTiers
    $slaHours = if ($match.PSObject.Properties.Name -contains 'slaHours') { [int]$match.slaHours } else { $sla.SlaHours }
    $escalateAt = if ($match.PSObject.Properties.Name -contains 'escalateAtHours') { [int]$match.escalateAtHours } else { $sla.EscalateAtHours }

    if ($Ticket.Priority -eq 'P1' -and $match.id -like 'prod-*-expedited') {
        $slaHours = $slaTiers['P1'].slaHours
        $escalateAt = $slaTiers['P1'].escalateAtHours
    }
    elseif ($Ticket.Priority -eq 'P2' -and $match.id -like 'prod-*-expedited') {
        $slaHours = $slaTiers['P2'].slaHours
        $escalateAt = $slaTiers['P2'].escalateAtHours
    }

    $mfaRequired = $false
    if ($match.PSObject.Properties.Name -contains 'mfaRequired') { $mfaRequired = [bool]$match.mfaRequired }

    $approverTier = $null
    if ($match.PSObject.Properties.Name -contains 'approverTier') { $approverTier = $match.approverTier }

    $runbook = $null
    if ($match.PSObject.Properties.Name -contains 'runbook') { $runbook = $match.runbook }

    $reviewHours = 0
    if ($match.PSObject.Properties.Name -contains 'reviewHours') { $reviewHours = [int]$match.reviewHours }

    # Resolve approver emails from mapping (§6.3). Exact role name wins; otherwise fall
    # back to the role's tier entry, so a new catalog role inherits its tier's approvers
    # instead of returning an approver-less Eligible decision.
    $approvers = @()
    if ($approverTier -and (Test-Path $ApproverMappingPath)) {
        $approverMap = Get-Content -Raw -Path $ApproverMappingPath | ConvertFrom-Json
        $primarySubId = $subscriptionIds[0]
        if ($approverMap.subscriptions.PSObject.Properties.Name -contains $primarySubId) {
            $subMapping = $approverMap.subscriptions.$primarySubId
            $role = [string]$Ticket.Role
            $lookupKeys = @($role)
            $roleTier = Get-RoleTier -RoleName $role -Path $RoleCatalogPath
            if ($roleTier -and $roleTier -ne $role) { $lookupKeys += $roleTier }

            foreach ($key in $lookupKeys) {
                if ($subMapping.roles.PSObject.Properties.Name -contains $key) {
                    $roleMapping = $subMapping.roles.$key
                    $approvers = @($roleMapping.primary)
                    if ($roleMapping.backup) { $approvers += @($roleMapping.backup) }
                    $approvers = @($approvers | Select-Object -Unique)
                    break
                }
            }
        }
    }

    $reason = 'Approved by validation checklist'
    if ($effectiveEnvironment -and $effectiveEnvironment -ne $claimedEnvironment) {
        $reason = "Approved by validation checklist (environment raised from $claimedEnvironment to $effectiveEnvironment based on subscription sensitivity)"
    }
    $record = New-DecisionRecord -Action $match.action -Path $match.path -Reason $reason `
        -Runbook $runbook -SlaHours $slaHours -EscalateAtHours $escalateAt `
        -MfaRequired $mfaRequired -ApproverTier $approverTier `
        -AssignmentType $match.assignmentType -NotifyOnCall:([bool]($match.PSObject.Properties.Name -contains 'notifyOnCall' -and $match.notifyOnCall)) `
        -ReviewHours $reviewHours `
        -ClaimedEnvironment $claimedEnvironment -EffectiveEnvironment $effectiveEnvironment
    $record.Approvers = $approvers
    return $record
}

function New-DecisionRecord {
    param(
        [string]$Action,
        [string]$Path,
        [string]$Reason,
        [string]$Runbook = $null,
        [int]$SlaHours = 0,
        [int]$EscalateAtHours = 0,
        [bool]$MfaRequired = $false,
        [string]$ApproverTier = $null,
        [string]$AssignmentType = $null,
        [bool]$NotifyOnCall = $false,
        [int]$ReviewHours = 0,
        [string]$ClaimedEnvironment = $null,
        [string]$EffectiveEnvironment = $null
    )

    [PSCustomObject]@{
        Action               = $Action
        Path                 = $Path
        Reason               = $Reason
        Runbook              = $Runbook
        SlaHours             = $SlaHours
        EscalateAt           = $EscalateAtHours
        MfaRequired          = $MfaRequired
        Approvers            = @()
        ApproverTier         = $ApproverTier
        AssignmentType       = $AssignmentType
        NotifyOnCall         = $NotifyOnCall
        ReviewHours          = $ReviewHours
        ClaimedEnvironment   = $ClaimedEnvironment
        EffectiveEnvironment = $EffectiveEnvironment
        EnvironmentOverridden = ($ClaimedEnvironment -and $EffectiveEnvironment -and ($ClaimedEnvironment -ne $EffectiveEnvironment))
    }
}
