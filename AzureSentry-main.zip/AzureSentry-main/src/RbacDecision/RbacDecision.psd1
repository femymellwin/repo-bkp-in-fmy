@{
    RootModule        = 'RbacDecision.psm1'
    ModuleVersion     = '0.1.0'
    GUID              = 'a3f8c2e1-9b4d-4f6a-8e2c-1d5b7a9c0e3f'
    Author            = 'AzureSentry'
    Description       = 'Deterministic RBAC/PIM decision engine (scope §3.2)'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Resolve-RbacDecision', 'Get-EffectiveEnvironment', 'Get-TicketCriticality', 'Get-RoleTier', 'Get-RoleCatalogEntry', 'Get-RoleCatalogNames', 'Get-AssignableRoleDefinitionId')
}
