function Test-TicketSchema {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$Ticket,

        [Parameter(Mandatory)]
        [object]$Policy,

        [string]$RoleCatalogPath
    )

    # Environment is optional on intake. All other checklist fields remain required.
    # When Environment is omitted, subscription sensitivity may still fill it later.
    $required = @('Role', 'SubscriptionId', 'ResourceScope', 'DurationDays', 'Priority', 'RequesterUpn')
    $missing = @($required | Where-Object {
            $name = $_
            $value = if ($Ticket -is [hashtable]) { $Ticket[$name] } else { $Ticket.$name }
            [string]::IsNullOrWhiteSpace([string]$value)
        })

    if ($missing.Count -gt 0) {
        return @{
            Valid  = $false
            Reason = "Missing required fields: $($missing -join ', ')"
        }
    }

    # Supported roles come from role-catalog.json — the single source of truth. Adding a
    # role there makes it requestable with no code change here.
    $catalogArgs = @{ RoleName = [string]$Ticket.Role }
    if ($RoleCatalogPath) { $catalogArgs['Path'] = $RoleCatalogPath }
    $roleEntry = Get-RoleCatalogEntry @catalogArgs
    if (-not $roleEntry) {
        return @{ Valid = $false; Reason = "Invalid role: $($Ticket.Role). Role is not present in role-catalog.json." }
    }

    # Promotion ladder: Sandbox → NonProd → Production. Empty/missing is allowed.
    $claimedEnvironment = if ($Ticket -is [hashtable]) { [string]$Ticket['Environment'] } else { [string]$Ticket.Environment }
    $validEnvironments = @('Sandbox', 'NonProd', 'Production')
    if (-not [string]::IsNullOrWhiteSpace($claimedEnvironment) -and $claimedEnvironment -notin $validEnvironments) {
        return @{ Valid = $false; Reason = "Invalid environment: $claimedEnvironment. Use Sandbox, NonProd, or Production." }
    }

    $validPriorities = @('P1', 'P2', 'P3', 'P4')
    if ($Ticket.Priority -notin $validPriorities) {
        return @{ Valid = $false; Reason = "Invalid priority: $($Ticket.Priority)" }
    }

    if ($Ticket.DurationDays -lt 1 -or $Ticket.DurationDays -gt $Policy.maxDurationDays) {
        return @{
            Valid  = $false
            Reason = "Duration must be between 1 and $($Policy.maxDurationDays) days"
        }
    }

    if ($Ticket.Environment -in @('Production', 'NonProd')) {
        $justification = [string]$Ticket.Justification
        $minLen = if ($Ticket.Environment -eq 'Production') { $Policy.minJustificationLength } else { [Math]::Min(10, $Policy.minJustificationLength) }
        if ([string]::IsNullOrWhiteSpace($justification) -or $justification.Length -lt $minLen) {
            return @{
                Valid  = $false
                Reason = "$($Ticket.Environment) requests require justification of at least $minLen characters"
            }
        }
    }

    if ($Ticket.ContainsKey) {
        if ($Ticket.ContainsKey('SubmitterUpn') -and -not [string]::IsNullOrWhiteSpace($Ticket.SubmitterUpn)) {
            if ($Ticket.RequesterUpn -ne $Ticket.SubmitterUpn) {
                return @{ Valid = $false; Reason = 'Requester UPN must match authenticated ticket submitter (G1)' }
            }
        }
    }
    elseif ($Ticket.PSObject.Properties.Name -contains 'SubmitterUpn' -and -not [string]::IsNullOrWhiteSpace($Ticket.SubmitterUpn)) {
        if ($Ticket.RequesterUpn -ne $Ticket.SubmitterUpn) {
            return @{ Valid = $false; Reason = 'Requester UPN must match authenticated ticket submitter (G1)' }
        }
    }

    # ResourceScope is the real grant target for resource-scoped roles, while the
    # allowlist and sensitivity map are keyed on the ticket's declared subscription id(s).
    # If the scope could name a different subscription, a request could be classified
    # against an approved sandbox sub and then granted in an unapproved one. Bind them.
    # ARM URLs are built by interpolating this scope, and System.Uri canonicalizes the
    # result before the request is sent. Any spelling that survives validation but
    # canonicalizes differently - '..', '%2e%2e', '.%2e', backslash separators - would be
    # validated against one subscription and granted in another. Blocklisting spellings
    # loses that race, so instead: restrict the scope to literal ARM characters, then
    # require it to be UNCHANGED by canonicalization. Anything else fails closed.
    $rawScope = [string]$Ticket.ResourceScope

    # PRIMARY CONTROL, deliberately first so it is the load-bearing check rather than a
    # backstop behind narrower ones: what we validate must be byte-identical to what ARM
    # receives. Every traversal spelling - '..', '%2e%2e', '.%2e', '\..\' - changes the
    # path during canonicalization and so fails here, including spellings not yet known.
    $canonicalScope = $null
    try {
        $canonicalScope = ([System.Uri]("https://management.azure.com" + $rawScope)).AbsolutePath
    }
    catch {
        return @{ Valid = $false; Reason = "Resource scope is not a valid URL path: $rawScope" }
    }
    if (-not $canonicalScope.Equals($rawScope, [System.StringComparison]::Ordinal)) {
        return @{
            Valid  = $false
            Reason = "Resource scope is not in canonical form - it would resolve to '$canonicalScope' when sent to Azure. Supply the exact resource id."
        }
    }

    # Defence in depth behind the canonical check, and clearer diagnostics. '%' and '\'
    # are the vehicles for the encoding/separator tricks.
    #
    # KNOWN LIMITATION: this class is ASCII-only, so a scope naming a resource group with
    # non-ASCII characters is rejected. That is not merely this class being conservative -
    # Uri.AbsolutePath percent-encodes non-ASCII, so such a scope can never satisfy the
    # canonical-form check above either. Widening the character class alone would not help;
    # supporting Unicode names would require comparing unescaped forms, which would weaken
    # the primary control. A legitimate Unicode-named target therefore fails closed (a
    # rejected request), never open. Revisit only if such subscriptions actually appear.
    if ($rawScope -match '[%\\]') {
        return @{ Valid = $false; Reason = "Resource scope must not contain '%' or '\' characters: $rawScope" }
    }
    if ($rawScope -notmatch '^[A-Za-z0-9._()\-/]+\z') {
        return @{ Valid = $false; Reason = "Resource scope contains characters that are not valid in an Azure resource id: $rawScope" }
    }
    $scopeSegments = @($rawScope -split '/')
    if (@($scopeSegments | Where-Object { $_ -and ($_ -match '^\.+\z') }).Count -gt 0) {
        return @{ Valid = $false; Reason = "Resource scope must not contain relative path segments ('.' or '..'): $rawScope" }
    }
    if ($rawScope -match '//' -or $rawScope.EndsWith('/')) {
        return @{ Valid = $false; Reason = "Resource scope must not contain empty or trailing path segments: $rawScope" }
    }

    # Anchor to a full subscription GUID so the captured segment cannot be a partial id or
    # any other token. Azure subscription ids are always GUIDs.
    $guid = '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'
    if (-not ([string]$Ticket.ResourceScope -match "^/subscriptions/($guid)(/|`$)")) {
        return @{ Valid = $false; Reason = 'Resource scope must start with /subscriptions/<subscriptionId>, where the id is a GUID' }
    }
    $scopeSubId = $Matches[1]

    $declaredSubIds = @()
    $pluralValue = if ($Ticket -is [hashtable]) {
        if ($Ticket.ContainsKey('SubscriptionIds')) { $Ticket['SubscriptionIds'] } else { $null }
    }
    elseif ($Ticket.PSObject.Properties.Name -contains 'SubscriptionIds') { $Ticket.SubscriptionIds }
    else { $null }
    if ($pluralValue) { $declaredSubIds = @($pluralValue) }
    if ($declaredSubIds.Count -eq 0) { $declaredSubIds = @([string]$Ticket.SubscriptionId) }
    $declaredSubIds = @($declaredSubIds | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim() })

    $scopeMatchesDeclared = @($declaredSubIds | Where-Object {
            $_.Equals($scopeSubId, [System.StringComparison]::OrdinalIgnoreCase)
        }).Count -gt 0
    if (-not $scopeMatchesDeclared) {
        return @{
            Valid  = $false
            Reason = "Resource scope subscription '$scopeSubId' is not among the ticket's declared subscription ids ($($declaredSubIds -join ', ')) - scope must be inside a requested subscription"
        }
    }

    # Resource-scoped roles (Storage data plane, AKS RBAC) are only meaningful on the
    # resource itself. Granting them at subscription scope would silently over-grant, so
    # require the scope to name the role's own resource type.
    if ($roleEntry.scopeType -eq 'resource') {
        $expected = [string]$roleEntry.resourceType
        if (-not $expected) {
            return @{ Valid = $false; Reason = "Role '$($Ticket.Role)' is resource-scoped but role-catalog.json defines no resourceType" }
        }
        $pattern = '/providers/' + [regex]::Escape($expected) + '/[^/]+'
        if (-not ([string]$Ticket.ResourceScope -match $pattern)) {
            return @{
                Valid  = $false
                Reason = "Role '$($Ticket.Role)' must be requested at a $expected scope (e.g. /subscriptions/<id>/resourceGroups/<rg>/providers/$expected/<name>), not '$($Ticket.ResourceScope)'"
            }
        }
    }

    return @{ Valid = $true; Reason = $null }
}
