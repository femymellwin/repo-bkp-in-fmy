function Get-SlaTier {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Priority,

        [Parameter(Mandatory)]
        [hashtable]$SlaTiers
    )

    if (-not $SlaTiers.ContainsKey($Priority)) {
        return @{ SlaHours = 24; EscalateAtHours = 20 }
    }

    $tier = $SlaTiers[$Priority]
    return @{
        SlaHours          = [int]$tier.slaHours
        EscalateAtHours   = [int]$tier.escalateAtHours
    }
}
