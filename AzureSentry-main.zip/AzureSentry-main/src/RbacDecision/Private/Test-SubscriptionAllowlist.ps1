function Test-SubscriptionAllowlist {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,

        [Parameter(Mandatory)]
        [string[]]$Allowlist
    )

    $normalized = $SubscriptionId.ToLowerInvariant()
    $allowed = @($Allowlist | ForEach-Object { $_.ToLowerInvariant() })

    if ($normalized -notin $allowed) {
        return @{
            Valid  = $false
            Reason = "Subscription ID '$SubscriptionId' is not on the approved allowlist"
        }
    }

    return @{ Valid = $true; Reason = $null }
}
