function Test-RoleEligibility {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$Ticket,

        [Parameter(Mandatory)]
        [object]$Policy,

        [string]$RoleCatalogPath
    )

    if ($Ticket.Role -eq 'Custom') {
        return @{
            Valid  = $false
            Action = 'Hold'
            Reason = 'Custom roles require Cloud Governance review'
            Path   = 'Governance-Review'
        }
    }

    $userCount = 1
    if ($Ticket -is [hashtable] -and $Ticket.ContainsKey('UserCount')) { $userCount = [int]$Ticket.UserCount }
    elseif ($Ticket.PSObject.Properties.Name -contains 'UserCount') { $userCount = [int]$Ticket.UserCount }
    if ($userCount -gt $Policy.bulkUserThreshold) {
        return @{
            Valid  = $false
            Action = 'Hold'
            Reason = "Bulk request ($userCount users) exceeds threshold of $($Policy.bulkUserThreshold)"
            Path   = 'Governance-Review'
        }
    }

    $tierArgs = @{ RoleName = [string]$Ticket.Role }
    if ($RoleCatalogPath) { $tierArgs['Path'] = $RoleCatalogPath }
    $tier = Get-RoleTier @tierArgs
    if (-not $tier) {
        # Fail closed: an unknown role must never reach the matrix.
        return @{
            Valid  = $false
            Action = 'Reject'
            Reason = "Role '$($Ticket.Role)' is not present in role-catalog.json"
            Path   = 'Schema-Invalid'
        }
    }

    $sandboxBlockedTiers = if ($Policy.PSObject.Properties.Name -contains 'sandboxBlockedTiers') {
        @($Policy.sandboxBlockedTiers)
    } else { @('Owner') }
    if ($Ticket.Environment -eq 'Sandbox' -and $tier -in $sandboxBlockedTiers) {
        return @{
            Valid  = $false
            Action = 'Reject'
            Reason = "$($Ticket.Role) ($tier tier) blocked on Sandbox by Azure Policy"
            Path   = 'Policy-Block'
        }
    }

    $nonProdBlockedTiers = if ($Policy.PSObject.Properties.Name -contains 'nonProdBlockedTiers') {
        @($Policy.nonProdBlockedTiers)
    } else { @('Owner') }
    if ($Ticket.Environment -eq 'NonProd' -and $tier -in $nonProdBlockedTiers) {
        return @{
            Valid  = $false
            Action = 'Reject'
            Reason = "$($Ticket.Role) ($tier tier) blocked on NonProd - use Production dual-approval for privileged access"
            Path   = 'Policy-Block'
        }
    }

    return @{ Valid = $true; Reason = $null }
}
