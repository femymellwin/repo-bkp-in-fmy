function Get-EligibilityMatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$Ticket,

        [Parameter(Mandatory)]
        [array]$MatrixRows,

        [string]$RoleCatalogPath,

        [switch]$IsCrossSubscription,

        [switch]$IsBreakGlass
    )

    if ($IsCrossSubscription -and $Ticket.Environment -eq 'Production') {
        return $MatrixRows | Where-Object { $_.id -eq 'cross-subscription-prod' } | Select-Object -First 1
    }

    if ($Ticket.Role -eq 'Custom') {
        return $MatrixRows | Where-Object { $_.id -eq 'custom-role-hold' } | Select-Object -First 1
    }

    $userCount = 1
    if ($Ticket -is [hashtable] -and $Ticket.ContainsKey('UserCount')) { $userCount = [int]$Ticket.UserCount }
    elseif ($Ticket.PSObject.Properties.Name -contains 'UserCount') { $userCount = [int]$Ticket.UserCount }
    if ($userCount -gt 5) {
        return $MatrixRows | Where-Object { $_.id -eq 'bulk-request-hold' } | Select-Object -First 1
    }

    # Routing is by risk tier, not role name: every role in a tier shares one matrix row,
    # so adding a role to role-catalog.json needs no new rows and no change here.
    $tierArgs = @{ RoleName = [string]$Ticket.Role }
    if ($RoleCatalogPath) { $tierArgs['Path'] = $RoleCatalogPath }
    $tier = Get-RoleTier @tierArgs
    if (-not $tier) { return $null }   # fail closed on an unknown role

    # Defensive: a future catalog entry with tier 'Custom' but a different role name
    # must still reach governance review rather than falling through to Unclassified.
    if ($tier -eq 'Custom') {
        return $MatrixRows | Where-Object { $_.id -eq 'custom-role-hold' } | Select-Object -First 1
    }

    if ($IsBreakGlass -and $Ticket.Environment -eq 'Production' -and $Ticket.Priority -eq 'P1') {
        if ($tier -eq 'Owner') {
            return $MatrixRows | Where-Object { $_.id -eq 'emergency-owner-p1-reject' } | Select-Object -First 1
        }
        if ($tier -eq 'Contributor') {
            return $MatrixRows | Where-Object { $_.id -eq 'emergency-contributor-p1' } | Select-Object -First 1
        }
    }

    if ($Ticket.Environment -eq 'Sandbox') {
        $sandboxId = switch ($tier) {
            'Reader'      { 'sandbox-reader' }
            'Contributor' { 'sandbox-contributor' }
            'Owner'       { 'sandbox-owner-reject' }
            default       { $null }
        }
        if ($sandboxId) {
            return $MatrixRows | Where-Object { $_.id -eq $sandboxId } | Select-Object -First 1
        }
    }

    # NonProd sits between Sandbox and Production: auto-grant Reader tier, gate Contributor
    # tier behind approval, block Owner tier.
    if ($Ticket.Environment -eq 'NonProd') {
        $nonProdId = switch ($tier) {
            'Reader'      { 'nonprod-reader' }
            'Contributor' { 'nonprod-contributor' }
            'Owner'       { 'nonprod-owner-reject' }
            default       { $null }
        }
        if ($nonProdId) {
            return $MatrixRows | Where-Object { $_.id -eq $nonProdId } | Select-Object -First 1
        }
    }

    if ($Ticket.Environment -eq 'Production') {
        if ($tier -eq 'Owner') {
            # Owner and UAA have distinct rows for audit clarity; both are Owner tier.
            $dualId = if ($Ticket.Role -eq 'UAA') { 'prod-uaa-dual' } else { 'prod-owner-dual' }
            return $MatrixRows | Where-Object { $_.id -eq $dualId } | Select-Object -First 1
        }

        $isExpedited = $Ticket.Priority -in @('P1', 'P2')
        $suffix = if ($isExpedited) { 'expedited' } else { 'standard' }
        $matchId = "prod-$($tier.ToLowerInvariant())-$suffix"
        return $MatrixRows | Where-Object { $_.id -eq $matchId } | Select-Object -First 1
    }

    return $null
}
