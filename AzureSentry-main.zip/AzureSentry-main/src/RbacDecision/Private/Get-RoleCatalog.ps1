# Role catalog loader. The catalog is the single source of truth for which roles
# are requestable and how each is classified; see the 2026-08-19 role expansion spec.

$script:RoleCatalogCache = @{}

function Get-DefaultRoleCatalogPath {
    return (Join-Path $PSScriptRoot '../Data/role-catalog.json')
}

function Get-RoleCatalog {
    [CmdletBinding()]
    param(
        [string]$Path = (Get-DefaultRoleCatalogPath)
    )

    $key = try { (Resolve-Path -Path $Path -ErrorAction Stop).Path } catch { $Path }
    if ($script:RoleCatalogCache.ContainsKey($key)) {
        return $script:RoleCatalogCache[$key]
    }

    if (-not (Test-Path $Path)) {
        throw "Role catalog not found: $Path"
    }

    $json = Get-Content -Raw -Path $Path | ConvertFrom-Json

    # Case-insensitive lookup so ticket text like 'storage blob data reader' resolves.
    $catalog = New-Object 'System.Collections.Hashtable' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($prop in $json.PSObject.Properties) {
        if ($prop.Name.StartsWith('_')) { continue }   # _comment / _source metadata
        $catalog[$prop.Name] = $prop.Value
    }

    $script:RoleCatalogCache[$key] = $catalog
    return $catalog
}

function Get-RoleCatalogEntry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyString()][string]$RoleName,
        [string]$Path = (Get-DefaultRoleCatalogPath)
    )

    if ([string]::IsNullOrWhiteSpace($RoleName)) { return $null }

    $catalog = Get-RoleCatalog -Path $Path
    $name = $RoleName.Trim()
    if (-not $catalog.ContainsKey($name)) { return $null }

    $entry = $catalog[$name]

    # aliasOf supplies the tier from the aliased role (Writer -> Contributor) while the
    # requesting role keeps its own scope metadata.
    if ($entry.PSObject.Properties.Name -contains 'aliasOf' -and $entry.aliasOf) {
        if ($catalog.ContainsKey($entry.aliasOf)) {
            $target = $catalog[$entry.aliasOf]
            $merged = $entry.PSObject.Copy()
            $merged.tier = $target.tier
            return $merged
        }
    }

    return $entry
}

function Get-RoleCatalogNames {
    [CmdletBinding()]
    param([string]$Path = (Get-DefaultRoleCatalogPath))
    return @((Get-RoleCatalog -Path $Path).Keys)
}
