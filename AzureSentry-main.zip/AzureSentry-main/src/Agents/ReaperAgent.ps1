<#
.SYNOPSIS
    One reaper cycle: scan the processed-ticket store and revoke grants whose recorded
    (tracked) expiry has passed.

.DESCRIPTION
    The safety case for the unattended ticket poller (src/Agents/TicketPollerAgent.ps1)
    depends on its grants being self-healing: a wrong grant should evaporate on its own
    rather than persist until a human notices. Group-fulfilment grants (the poller's
    normal path for Reader/Contributor) have no Azure-enforced timer at all -- see
    Get-GrantExpiryTimestamp (dashboard/api/DashboardHelpers.ps1) -- so nothing in Azure
    ever ends that access by itself. This agent is that "something": it is the sole
    enforcer of the tracked expiry recorded on a group grant.

    Every external dependency is injected through the -Context hashtable so the whole
    cycle is testable with no ManageEngine, Graph or ARM I/O -- same convention as
    TicketPollerAgent.ps1. scripts/Invoke-ReaperCycle.ps1 builds the real context.

    Default posture is off and shadow. Shadow reports exactly what it would have revoked
    and writes nothing -- same WouldGrant-not-"skipped" reasoning as the poller's shadow
    mode: a successful dry run must not read identically to a failure.

    Only ever revokes a record Test-GrantRevocable says this platform granted and
    recorded (an assignmentId, or Group fulfilment with a stored groupId) and that is
    not already marked revoked. A revocation must never be more aggressive than that --
    this agent has no mechanism to touch anything it did not itself grant and record.
#>

function Get-ExpiredUnrevokedCount {
    <#
    .SYNOPSIS
      Count of processed-ticket records whose recorded expiry has passed but that have
      NOT been revoked -- access outliving its own authorisation, the single most
      dangerous state this platform can be in.
    .DESCRIPTION
      Deliberately a standalone scan, not a byproduct of the main revoke loop below: it
      is computed unconditionally, before the enabled/stop-sentinel gates, so this
      number is visible in reaper-status.json even on a cycle that is disabled or
      halted. A reassuring "0 examined" from a disabled reaper must never be mistaken
      for "nothing is overdue" -- see the .DESCRIPTION on Invoke-ReaperCycle below and
      Resolve-ReaperStatusView's staleness handling for the companion "is the reaper
      even still running" signal.

      Same eligibility gate as the revoke loop (Test-GrantRevocable) and the same
      lenient parse-or-skip on expiresAt: a record with no recorded expiry, or an
      unparseable one, is not counted here either -- this function counts overdue
      access, not data problems.
    #>
    param(
        [Parameter(Mandatory)]$Store,
        [Parameter(Mandatory)][datetime]$Now
    )

    $count = 0
    foreach ($id in @($Store.Keys)) {
        $prior = $Store[$id]
        if (-not (Test-GrantRevocable -Prior $prior)) { continue }

        $expiresAtRaw = [string]$prior.expiresAt
        if ([string]::IsNullOrWhiteSpace($expiresAtRaw)) { continue }

        $expiresAt = [datetime]::MinValue
        if (-not [datetime]::TryParse(
                $expiresAtRaw, [System.Globalization.CultureInfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal,
                [ref]$expiresAt)) {
            continue
        }

        if ($expiresAt -le $Now) { $count++ }
    }
    return $count
}

function Resolve-ReaperStatusView {
    <#
    .SYNOPSIS
      Reaper counterpart to Resolve-PollerStatusView (src/Agents/PollerGate.ps1) --
      same reasoning, same shape, different process to trust.
    .DESCRIPTION
      The reaper is the sole enforcer of a Group grant's tracked expiry (see
      Get-GrantExpiryTimestamp, dashboard/api/DashboardHelpers.ps1): if it stops running
      -- crashed, disabled, the VM is down -- overdue group access does not evaporate on
      its own. That makes "is the reaper still actually cycling" a safety-relevant
      question the dashboard must be able to answer at a glance, distinct from "it ran
      recently and found nothing to do".

      A status file that is missing, unparseable, or older than StaleAfterMinutes
      resolves to Enabled=$null / Mode=$null / Stale=$true -- "unknown", not a
      reassuring "Off". StaleAfterMinutes defaults to 75: the reaper's own timer
      (infra/systemd/azuresentry-reaper.timer) runs every 30 minutes, so 75 is comfortably
      more than double that cadence, mirroring the poller's "more than double the cadence"
      margin without misreporting a single slow cycle as stale.
    #>
    param(
        [object]$LastCycle,
        [datetime]$Now = [datetime]::UtcNow,
        [int]$StaleAfterMinutes = 75
    )

    $view = [pscustomobject]@{ Enabled = $null; Mode = $null; Stale = $false }
    if (-not $LastCycle) {
        $view.Stale = $true
        return $view
    }

    $ranAt = [datetime]::MinValue
    $ranAtRaw = [string]$LastCycle.ranAt
    if (-not $ranAtRaw -or -not [datetime]::TryParse(
            $ranAtRaw, [System.Globalization.CultureInfo]::InvariantCulture,
            [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal,
            [ref]$ranAt)) {
        $view.Stale = $true
        return $view
    }
    if (($Now - $ranAt).TotalMinutes -gt $StaleAfterMinutes) {
        $view.Stale = $true
        return $view
    }

    $mode = [string]$LastCycle.mode
    $view.Mode = if ($mode -eq 'enforce') { 'enforce' } else { 'shadow' }

    # Get-ReaperConfig's disabled halt reason is the fixed literal string
    # 'AZURESENTRY_REAPER_ENABLED is not true.' -- only THAT halt means "disabled"; any
    # other halt (stop sentinel, GetProcessedTickets threw) still means the reaper is
    # enabled and would run the moment the real blocker clears.
    $halted = [bool]$LastCycle.halted
    $haltReason = [string]$LastCycle.haltReason
    $view.Enabled = -not ($halted -and $haltReason -like '*AZURESENTRY_REAPER_ENABLED*')
    return $view
}

function Get-ReaperConfig {
    <#
    .SYNOPSIS
      Read the reaper's operating envelope from the environment.
    .DESCRIPTION
      Mirrors Get-PollerConfig (TicketPollerAgent.ps1) exactly: both the kill switch and
      the mode require an exact string match, so a typo in AZURESENTRY_REAPER_ENABLED
      must leave the reaper off, and a typo in AZURESENTRY_REAPER_MODE must leave it in
      shadow -- never the other way round.

      StopFilePath resolves the same way the poller's does: the explicit
      -StopFilePath argument, then AZURESENTRY_REAPER_STOP_FILE, then a default next to
      wherever the processed store lives, then the current directory.

      ModeOverrideFilePath mirrors the poller's mode-override file exactly (see
      Get-PollerConfig's .DESCRIPTION for the full reasoning): the dashboard's Enforce
      Mode toggle for the reaper (POST /api/reaper/mode) writes this file because the
      dashboard API cannot set AZURESENTRY_REAPER_MODE for the reaper -- a separate
      process, re-reading /etc/azuresentry.env fresh on every cycle. When present, its
      content decides ahead of the environment variable; content that is not exactly
      'enforce' (after trim + lowercase) resolves to 'shadow', the same fail-closed
      contract as the env var, never a silent fall-through to trusting it instead.
    #>
    param(
        [string]$StopFilePath = '',
        [string]$ModeOverrideFilePath = '',
        [string]$EnabledOverrideFilePath = '',
        [string]$CapsOverrideFilePath = ''
    )

    $enabled = ([string]$env:AZURESENTRY_REAPER_ENABLED).Trim().ToLowerInvariant() -eq 'true'
    $envMode = if (([string]$env:AZURESENTRY_REAPER_MODE).Trim().ToLowerInvariant() -eq 'enforce') { 'enforce' } else { 'shadow' }

    $asInt = {
        param([string]$Value, [int]$Default)
        $n = 0
        if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
        return $Default
    }

    $defaultDir = {
        $storeDir = $null
        if (Get-Command -Name Get-ProcessedStoreDir -ErrorAction SilentlyContinue) {
            try { $storeDir = Get-ProcessedStoreDir } catch { $storeDir = $null }
        }
        if (-not $storeDir) { $storeDir = (Get-Location).Path }
        return $storeDir
    }

    $stopFile = ([string]$StopFilePath).Trim()
    if (-not $stopFile) { $stopFile = ([string]$env:AZURESENTRY_REAPER_STOP_FILE).Trim() }
    if (-not $stopFile) { $stopFile = Join-Path (& $defaultDir) 'reaper.stop' }

    $modeFile = ([string]$ModeOverrideFilePath).Trim()
    if (-not $modeFile) { $modeFile = ([string]$env:AZURESENTRY_REAPER_MODE_FILE).Trim() }
    if (-not $modeFile) { $modeFile = Join-Path (& $defaultDir) 'reaper.mode' }

    $enabledFile = ([string]$EnabledOverrideFilePath).Trim()
    if (-not $enabledFile) { $enabledFile = ([string]$env:AZURESENTRY_REAPER_ENABLED_FILE).Trim() }
    if (-not $enabledFile) { $enabledFile = Join-Path (& $defaultDir) 'reaper.enabled' }

    $capsFile = ([string]$CapsOverrideFilePath).Trim()
    if (-not $capsFile) { $capsFile = ([string]$env:AZURESENTRY_REAPER_CAPS_FILE).Trim() }
    if (-not $capsFile) { $capsFile = Join-Path (& $defaultDir) 'reaper.caps.json' }

    $modeSource = 'env'
    $mode = $envMode
    if (Test-Path -LiteralPath $modeFile) {
        $modeSource = 'override'
        $override = ''
        try { $override = (Get-Content -Raw -LiteralPath $modeFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $override = '' }
        $mode = if ($override -eq 'enforce') { 'enforce' } else { 'shadow' }
    }

    $enabledSource = 'env'
    if (Test-Path -LiteralPath $enabledFile) {
        $enabledSource = 'override'
        $enabledOverride = ''
        try { $enabledOverride = (Get-Content -Raw -LiteralPath $enabledFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $enabledOverride = '' }
        $enabled = ($enabledOverride -eq 'true')
    }

    $maxRevokesSource = 'env'
    $maxRevokes = (& $asInt $env:AZURESENTRY_REAPER_MAX_REVOKES 25)
    if (Test-Path -LiteralPath $capsFile) {
        $capsJson = $null
        try { $capsJson = Get-Content -Raw -LiteralPath $capsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { $capsJson = $null }
        if ($capsJson -and ($capsJson.PSObject.Properties.Name -contains 'maxRevokes')) {
            $n = 0
            if ([int]::TryParse([string]$capsJson.maxRevokes, [ref]$n) -and $n -gt 0) { $maxRevokes = $n; $maxRevokesSource = 'override' }
        }
    }

    return [pscustomobject]@{
        Enabled                  = $enabled
        EnabledSource            = $enabledSource
        EnabledOverrideFilePath  = $enabledFile
        Mode                     = $mode
        ModeSource               = $modeSource
        ModeOverrideFilePath     = $modeFile
        # Blast-radius bound on the number of revocations a single cycle can perform --
        # same role MaxGrantsPerCycle plays for the poller. 25 is generous relative to
        # the reaper's own interval (see infra/systemd/azuresentry-reaper.timer): a cycle
        # that would otherwise revoke more than this in one pass almost certainly
        # indicates something systemic worth a human looking at before it continues.
        MaxRevokesPerCycle    = $maxRevokes
        MaxRevokesSource      = $maxRevokesSource
        CapsOverrideFilePath  = $capsFile
        StopFilePath          = $stopFile
    }
}

function Invoke-ReaperCycle {
    <#
    .SYNOPSIS
      Run exactly one reaper cycle.
    .PARAMETER Context
      Hashtable:
        Config              Get-ReaperConfig result
        Now                 [datetime] the cycle treats as "now"
        GetProcessedTickets () -> hashtable of ticketId -> processed-ticket record
        RevokeGrant         ($TicketId, $Prior) -> @{ ok = [bool]; error = [string] }
                            Performs the real revoke (via Invoke-GrantRevocationAction,
                            GrantRevocation.ps1) AND persists the updated record. Only
                            ever called in enforce mode.
        RunId               optional; generated via New-AgentRunId when absent
    .OUTPUTS
      pscustomobject with RunId, Mode, Examined, Revoked, WouldRevoke, Deferred, Failed,
      Stopped, Halted, Entries.
    #>
    param([Parameter(Mandatory)][hashtable]$Context)

    $config = $Context.Config
    $runId = if ($Context.ContainsKey('RunId') -and $Context.RunId) {
        [string]$Context.RunId
    } elseif (Get-Command -Name New-AgentRunId -ErrorAction SilentlyContinue) {
        New-AgentRunId -Agent 'reaper'
    } else {
        "reap-$([guid]::NewGuid().ToString('N').Substring(0, 12))"
    }

    $entries = [System.Collections.Generic.List[object]]::new()
    $tally = @{ Examined = 0; Revoked = 0; WouldRevoke = 0; Deferred = 0; Failed = 0; Stopped = $false }
    $expiredUnrevokedCount = 0

    # camelCase: serialized straight to reaper-status.json for the dashboard, same
    # convention as poller-status.json (Invoke-TicketPollerCycle.ps1).
    $result = {
        param([bool]$Halted, [string]$HaltReason)
        [pscustomobject]@{
            runId             = $runId
            mode              = [string]$config.Mode
            examined          = $tally.Examined
            revoked           = $tally.Revoked
            wouldRevoke       = $tally.WouldRevoke
            deferred          = $tally.Deferred
            failed            = $tally.Failed
            stopped           = $tally.Stopped
            halted            = $Halted
            haltReason        = $HaltReason
            # The dangerous-state count (Get-ExpiredUnrevokedCount above): access whose
            # authorisation has already lapsed but that nothing has yet revoked. Present
            # on EVERY result this function returns, including a disabled or halted
            # cycle -- see that function's own comment for why.
            expiredUnrevoked  = $expiredUnrevokedCount
            entries           = @($entries)
            ranAt             = $Context.Now.ToString('o')
        }
    }

    # Store fetch and the expiredUnrevoked scan happen BEFORE the enabled/stop-sentinel
    # gates below, deliberately: this danger signal is a fact about the store, not about
    # whether this particular cycle was allowed to act on it. An operator who has turned
    # the reaper off (or hit the stop sentinel) still needs to see overdue access
    # accumulating in reaper-status.json, not a reassuring blank because the cycle
    # returned early.
    $store = $null
    try { $store = & $Context.GetProcessedTickets }
    catch {
        return & $result $true "GetProcessedTickets threw: $($_.Exception.Message)"
    }
    if (-not $store) { $store = @{} }
    $expiredUnrevokedCount = Get-ExpiredUnrevokedCount -Store $store -Now $Context.Now

    if (-not $config.Enabled) {
        $haltReason = 'AZURESENTRY_REAPER_ENABLED is not true.'
        if ($config.EnabledSource -eq 'override') {
            $haltReason += ' (source: reaper.enabled override file, not the env var)'
        }
        return & $result $true $haltReason
    }
    if ($config.StopFilePath -and (Test-Path -LiteralPath $config.StopFilePath)) {
        return & $result $true "Stop sentinel present at $($config.StopFilePath)."
    }

    # Sorted so entries (and test assertions on them) have a deterministic order --
    # hashtable enumeration order is not guaranteed.
    $ids = @($store.Keys | Sort-Object)

    $haltedMidCycle = $false
    $haltReasonMidCycle = ''

    foreach ($id in $ids) {
        if ($tally.Stopped) { break }
        # Re-checked every iteration, not just once before the loop -- a sentinel
        # dropped mid-run must stop the NEXT record, not wait for the cycle to finish.
        if ($config.StopFilePath -and (Test-Path -LiteralPath $config.StopFilePath)) {
            $tally.Stopped = $true
            $haltedMidCycle = $true
            $haltReasonMidCycle = "Stop sentinel present at $($config.StopFilePath)."
            break
        }

        $prior = $store[$id]

        # Policy invariant: never revoke a record this platform did not itself grant and
        # record, and never revoke an already-revoked record. Same gate the dashboard's
        # own revoke route uses (Test-GrantRevocable, DashboardHelpers.ps1) and that
        # Invoke-GrantRevocationAction re-checks on its own -- belt and suspenders, since
        # this is the one rule a revocation-automation agent must never get wrong.
        if (-not (Test-GrantRevocable -Prior $prior)) { continue }

        $expiresAtRaw = [string]$prior.expiresAt
        # No recorded expiry at all -- e.g. a record written before this feature shipped,
        # or a PIM-fallback grant whose expiry field failed to write for some other
        # reason. Nothing to reap here; do not guess a deadline that was never recorded.
        if ([string]::IsNullOrWhiteSpace($expiresAtRaw)) { continue }

        $expiresAt = [datetime]::MinValue
        if (-not [datetime]::TryParse(
                $expiresAtRaw, [System.Globalization.CultureInfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal,
                [ref]$expiresAt)) {
            # Unparseable expiry: fail closed by leaving it alone, not by guessing it is
            # expired. A malformed timestamp is a data problem for a human, not licence
            # to revoke.
            continue
        }

        # THE expiry test. Deliberately the one comparison this whole function exists to
        # get right: a grant still inside its window (expiresAt in the future) must be
        # left alone; only a grant whose recorded deadline has already passed is a
        # candidate. See ReaperAgent.Tests.ps1's mutation test, which flips this operator
        # and confirms the suite catches it.
        if ($expiresAt -gt $Context.Now) { continue }

        $tally.Examined++

        # Common audit fields for every entry below -- "for whom, on what scope, how it
        # was fulfilled, how long overdue" (the reaper's own revocation audit must carry
        # all four, not just ticketId/outcome). Computed once per record rather than
        # repeated per branch.
        $overdueHours = [math]::Round(($Context.Now - $expiresAt).TotalHours, 2)
        $requesterUpn = [string]$prior.requesterUpn
        $role = [string]$prior.role
        $subscriptionId = [string]$prior.subscriptionId
        $scope = if ($subscriptionId) { "/subscriptions/$subscriptionId" } else { '' }

        # Compare against Revoked + WouldRevoke, not Revoked alone -- same reasoning as
        # the poller's MaxGrantsPerCycle check: shadow mode never increments Revoked, so
        # a Revoked-only check would let a shadow run's preview blow past the cap while
        # enforce would have stopped there, defeating the point of previewing blast radius.
        if (($tally.Revoked + $tally.WouldRevoke) -ge [int]$config.MaxRevokesPerCycle) {
            $tally.Deferred++
            $entries.Add([pscustomobject]@{
                    ticketId       = $id; outcome = 'Deferred'
                    reason         = "Per-cycle revoke cap of $($config.MaxRevokesPerCycle) reached; deferred to the next cycle."
                    fulfilment     = [string]$prior.fulfilment
                    expiresAt      = $expiresAtRaw
                    requesterUpn   = $requesterUpn
                    role           = $role
                    subscriptionId = $subscriptionId
                    scope          = $scope
                    overdueHours   = $overdueHours
                })
            continue
        }

        if ($config.Mode -ne 'enforce') {
            $tally.WouldRevoke++
            $entries.Add([pscustomobject]@{
                    ticketId       = $id; outcome = 'WouldRevoke'
                    reason         = "Recorded expiry $expiresAtRaw has passed."
                    fulfilment     = [string]$prior.fulfilment
                    expiresAt      = $expiresAtRaw
                    requesterUpn   = $requesterUpn
                    role           = $role
                    subscriptionId = $subscriptionId
                    scope          = $scope
                    overdueHours   = $overdueHours
                })
            continue
        }

        # --- enforce: the only branch that writes ---
        $errorText = $null
        $rev = $null
        try { $rev = & $Context.RevokeGrant $id $prior }
        catch { $errorText = $_.Exception.Message }

        $ok = ($null -ne $rev) -and [bool]$rev.ok
        if (-not $ok -and -not $errorText) {
            $errorText = if ($rev -and $rev.error) { [string]$rev.error } else { 'Revoke reported failure without a reason.' }
        }

        if ($ok) {
            $tally.Revoked++
            $entries.Add([pscustomobject]@{
                    ticketId       = $id; outcome = 'Revoked'
                    reason         = "Recorded expiry $expiresAtRaw has passed."
                    fulfilment     = [string]$prior.fulfilment
                    expiresAt      = $expiresAtRaw
                    requesterUpn   = $requesterUpn
                    role           = $role
                    subscriptionId = $subscriptionId
                    scope          = $scope
                    overdueHours   = $overdueHours
                })
        }
        else {
            # Fail closed: stop the cycle rather than walking into the next expired
            # grant with an unexplained failure behind us. Later records are left
            # completely untouched -- RevokeGrant is never invoked for them.
            $tally.Failed++
            $tally.Stopped = $true
            $entries.Add([pscustomobject]@{
                    ticketId       = $id; outcome = 'Failed'; reason = $errorText
                    fulfilment     = [string]$prior.fulfilment
                    expiresAt      = $expiresAtRaw
                    requesterUpn   = $requesterUpn
                    role           = $role
                    subscriptionId = $subscriptionId
                    scope          = $scope
                    overdueHours   = $overdueHours
                })
            $haltedMidCycle = $true
            $haltReasonMidCycle = "Revoke failed for ticket $id : $errorText"
            break
        }
    }

    if ($haltedMidCycle) {
        return & $result $true $haltReasonMidCycle
    }
    return & $result $false ''
}
