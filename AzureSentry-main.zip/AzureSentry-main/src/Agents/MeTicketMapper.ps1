<#
.SYNOPSIS
    Maps ManageEngine structured template fields to a canonical decision-engine ticket.

.DESCRIPTION
    The dashboard UI has a much richer mapper (parseTicket in TicketsView.tsx) that falls
    back to parsing free text when the ME dropdowns are blank. That fallback exists to help
    a human triage a vague ticket; it must not decide unattended privilege, and duplicating
    it here would create two implementations of privilege-determining logic that drift.

    So this mapper is deliberately narrow: structured dropdowns only, exact subscription
    matching, and an explicit Complete verdict. Anything it cannot resolve without guessing
    is reported incomplete and queues for a human, where the UI's full mapper applies.

    Role and environment canonicalisation intentionally mirrors mapMeAzureRole and
    mapMeEnvironment in dashboard/web/src/extractMeAccessFields.ts. Keep them in step.
#>

function Get-CanonicalAzureRole {
    <#
    .SYNOPSIS
      ME "Azure Role" dropdown label to platform role. Empty when unrecognised.
    .DESCRIPTION
      Returns '' rather than echoing the raw label (which the UI does, so an operator can
      see what was asked for). Unattended, an unrecognised role must not reach the decision
      engine at all.
    #>
    param([string]$Raw)

    $v = ([string]$Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($v)) { return '' }

    $n = ($v.ToLowerInvariant() -replace '[_-]+', ' ') -replace '\s+', ' '
    $n = $n.Trim()

    if ($n -match 'user access admin|\buaa\b') { return 'UAA' }
    if ($n -match '\bowner\b') { return 'Owner' }
    if ($n -match '\bwriter\b|write access') { return 'Writer' }
    if ($n -match '\bcontrib') { return 'Contributor' }
    if ($n -match '\breader\b|\bread only\b') { return 'Reader' }
    # Anything else -- custom / AKS / other catalog roles -- is passed through verbatim
    # rather than discarded, mirroring mapMeAzureRole's contract exactly: "keep the label
    # so operators [and the role-catalog lookup] can see what was requested." Resolve-
    # MeTicketMapping is what turns an unrecognised label into a warning; this function's
    # only job is not to silently erase a valid role-catalog name (e.g. "Azure Kubernetes
    # Service RBAC Admin") that just doesn't match one of the five coarse buckets above.
    return $v
}

function Get-CanonicalEnvironment {
    <#
    .SYNOPSIS
      ME "Environment" dropdown label to Sandbox / NonProd / Production. Empty otherwise.
    .DESCRIPTION
      This mapper feeds an unattended granter, so it must never be MORE permissive than
      mapMeEnvironment in dashboard/web/src/extractMeAccessFields.ts: resolving to an
      auto-grantable environment (Sandbox/NonProd) where the UI leaves the value unmapped
      would mean the poller grants access a human would have been asked to confirm.
      Drifting the other way -- this mapper queuing something the UI would resolve -- is
      fine. Do not "fix" divergences from the UI list without re-checking this rule.
    #>
    param([string]$Raw)

    $n = ([string]$Raw).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($n)) { return '' }

    # Order matters: non-prod terms are tested before a bare 'prod' so "non-prod" is
    # never read as Production.
    if ($n -match '\bsandbox\b|\bsbx\b|\blab\b') { return 'Sandbox' }
    # \bstage\b is deliberately NOT included: the UI only matches \bstaging\b, so "Stage"
    # is unmapped there. Matching it here would auto-grant NonProd where the UI would
    # have queued for a human -- the permissive direction this mapper must not drift in.
    # \bshared\b and \bdr\b are deliberately NOT included either, even though the UI's
    # NonProd branch has both: both would make the poller auto-grant NonProd, and "DR"
    # (disaster recovery) is production-adjacent and must never be auto-granted. This
    # mapper is intentionally stricter than the UI here.
    if ($n -match 'non[\s_-]?prod|\bstaging\b|\buat\b|\bqa\b|\bdev(?:elopment)?\b|\btest(?:ing)?\b|pre[\s_-]?prod|\btraining\b') { return 'NonProd' }
    # \bprd\b is kept even though the UI does not match it. This is safe -- not a drift
    # into the permissive direction -- because Production is excluded from unattended
    # grants entirely, so "PRD" queues for a human either way. Classifying it correctly
    # here just makes the queued reason legible ("Production") instead of "did not map".
    if ($n -match '\bproduction\b|\bprod\b|\bprd\b') { return 'Production' }
    return ''
}

function Resolve-AllowlistSubscriptionId {
    <#
    .SYNOPSIS
      Exact-match an ME subscription value against the effective allowlist.
    .DESCRIPTION
      Exact (case-insensitive, trimmed) only. The UI substring-matches to be forgiving for
      an operator who can see and correct the result; unattended that is unsafe, because a
      value like "Sandbox" can match several subscriptions and the wrong one would receive
      a real grant. A bare GUID is accepted only if it is itself on the allowlist.
    #>
    param(
        [string]$Name,
        [object[]]$AllowlistDetails = @()
    )

    $needle = ([string]$Name).Trim()
    if ([string]::IsNullOrWhiteSpace($needle)) { return '' }

    foreach ($entry in $AllowlistDetails) {
        $id = [string]$entry.id
        if ($id -and $id.Equals($needle, [System.StringComparison]::OrdinalIgnoreCase)) { return $id }
    }
    foreach ($entry in $AllowlistDetails) {
        $name = [string]$entry.name
        if ($name -and $name.Trim().Equals($needle, [System.StringComparison]::OrdinalIgnoreCase)) {
            return [string]$entry.id
        }
    }
    return ''
}

function Resolve-MeTicketMapping {
    <#
    .SYNOPSIS
      Build a canonical ticket from ME structured fields, with a Complete verdict.
    .OUTPUTS
      pscustomobject with Complete (bool), Warnings (string[]), Ticket (pscustomobject|$null).
    #>
    param(
        [Parameter(Mandatory)][object]$AccessFields,
        [Parameter(Mandatory)][object]$MeTicket,
        [object[]]$AllowlistDetails = @(),
        [int]$DurationDays = 7
    )

    $warnings = [System.Collections.Generic.List[string]]::new()

    $rawSub = [string]$AccessFields.Subscription
    $rawRole = [string]$AccessFields.AzureRole
    $rawEnv = [string]$AccessFields.Environment

    $role = Get-CanonicalAzureRole -Raw $rawRole
    # Get-CanonicalAzureRole now passes an unrecognised-but-non-blank label through
    # verbatim (see its own comment) so a valid role-catalog name that isn't one of the
    # five coarse buckets -- e.g. an AKS RBAC role -- can still resolve here. But a
    # pass-through is not itself proof the label is a real role: confirm it against
    # role-catalog.json (the single source of truth for what's requestable) before
    # treating it as mapped. A genuinely unknown label (typo, decommissioned role) still
    # queues for a human exactly as before.
    $roleEntry = if ($role) { Get-RoleCatalogEntry -RoleName $role } else { $null }
    if ([string]::IsNullOrWhiteSpace($rawRole)) {
        $warnings.Add('Azure Role dropdown is not set on the ManageEngine ticket.')
    }
    elseif (-not $role -or -not $roleEntry) {
        $warnings.Add("Azure Role '$rawRole' did not map to a platform role.")
        $role = ''
        $roleEntry = $null
    }

    $environment = Get-CanonicalEnvironment -Raw $rawEnv
    if ([string]::IsNullOrWhiteSpace($rawEnv)) {
        $warnings.Add('Environment dropdown is not set on the ManageEngine ticket.')
    }
    elseif (-not $environment) {
        $warnings.Add("Environment '$rawEnv' did not map to Sandbox / NonProd / Production.")
    }

    $subscriptionId = Resolve-AllowlistSubscriptionId -Name $rawSub -AllowlistDetails $AllowlistDetails
    if ([string]::IsNullOrWhiteSpace($rawSub)) {
        $warnings.Add('Subscription dropdown is not set on the ManageEngine ticket.')
    }
    elseif (-not $subscriptionId) {
        $warnings.Add("Subscription '$rawSub' is not on the allowlist by exact name.")
    }

    # Resource-scoped roles (AKS RBAC, Storage data plane) are only meaningful on the
    # specific resource, never the whole subscription -- Test-TicketSchema.ps1 rejects a
    # subscription-only scope for one of these to prevent silently over-granting (e.g.
    # cluster-admin on every AKS cluster in the subscription when one was intended). The
    # ME "Azure Subscription" template has no dedicated cluster field yet; until one is
    # added and its UDF key configured (manageEngine.udfFields.targetResourceId), this
    # raw value is always blank and every resource-scoped role queues for a human below --
    # which is the correct, fail-closed default, not a bug.
    $resourceScope = if ($subscriptionId) { "/subscriptions/$subscriptionId" } else { '' }
    if ($roleEntry -and [string]$roleEntry.scopeType -eq 'resource') {
        $expectedType = [string]$roleEntry.resourceType
        $rawResourceId = ([string]$AccessFields.TargetResourceId).Trim()
        if ([string]::IsNullOrWhiteSpace($rawResourceId)) {
            $warnings.Add("Role '$role' is resource-scoped (a specific $expectedType) but the ManageEngine ticket names no target resource. Add the resource's Azure resource id to the ticket.")
        }
        elseif ($expectedType -and ($rawResourceId -notmatch ('/providers/' + [regex]::Escape($expectedType) + '/[^/]+'))) {
            $warnings.Add("The target resource on the ManageEngine ticket does not look like a $expectedType resource id: $rawResourceId")
        }
        else {
            # Full validation (subscription match, char safety, no relative segments) is
            # Test-TicketSchema.ps1's job -- deliberately not duplicated here, so there is
            # exactly one place that owns the authoritative rule. This is a legibility
            # pass only: a value that is well-formed enough to be worth passing on.
            $resourceScope = $rawResourceId
        }
    }

    $requesterUpn = ''
    if ($MeTicket.requester) {
        $requesterUpn = [string]$MeTicket.requester.email_id
    }
    if ([string]::IsNullOrWhiteSpace($requesterUpn)) {
        $warnings.Add('ManageEngine ticket has no requester email to resolve to an object id.')
    }

    $priority = 'P3'
    if ($MeTicket.priority -and $MeTicket.priority.name) {
        $p = ([string]$MeTicket.priority.name).Trim().ToUpperInvariant()
        if ($p -match '^P[1-4]$') { $priority = $p }
    }

    $subscriptionName = ''
    if ($subscriptionId) {
        $hit = @($AllowlistDetails | Where-Object { [string]$_.id -eq $subscriptionId } | Select-Object -First 1)
        if ($hit.Count -gt 0 -and $hit[0].name) { $subscriptionName = [string]$hit[0].name }
    }

    $complete = ($warnings.Count -eq 0)
    $ticket = $null
    if ($complete) {
        $ticket = [pscustomobject]@{
            TicketId         = [string]$MeTicket.id
            Role             = $role
            Environment      = $environment
            SubscriptionId   = $subscriptionId
            SubscriptionName = $subscriptionName
            RequesterUpn     = $requesterUpn
            SubmitterUpn     = $requesterUpn
            Priority         = $priority
            DurationDays     = $DurationDays
            ResourceScope    = $resourceScope
            Justification    = "Unattended grant from ManageEngine ticket #$([string]$MeTicket.id): $([string]$MeTicket.subject)"
        }
    }

    return [pscustomobject]@{
        Complete = $complete
        Warnings = @($warnings)
        Ticket   = $ticket
    }
}
