﻿<#
.SYNOPSIS
    Shared LLM step for AzureSentry agents — provider-agnostic JSON completions.

.DESCRIPTION
    §5 decision: an agent is BOTH a deterministic API caller and an LLM step. This
    is the LLM half, factored out so every agent that needs inference (environment
    backfill, ticket categorization) uses one code path with one error contract.

    Providers: core42 (default, OpenAI-compatible), azure-openai, openai.
    Configuration comes from environment variables (loaded from dashboard/api/llm.env)
    so no key is ever passed on a command line or written to the audit trail.

    The existing Help Desk summarization agent keeps its own in-API implementation;
    this client is the one new agents build on.
#>

function ConvertTo-LlmSafeText {
    <#
    .SYNOPSIS
      Strips raw control characters that Windows PowerShell 5.1's ConvertTo-Json
      (JavaScriptSerializer) fails to escape, before that text goes into an LLM request.

    .DESCRIPTION
      RFC 8259 requires every control character (U+0000-U+001F) inside a JSON string to
      be escaped. JavaScriptSerializer only escapes \t \n \r \b \f — anything else in
      that range (a stray 0x01, 0x1F, DEL 0x7F, etc.) is written to the output byte-for-
      byte. Ticket text pasted from email or rich text can carry exactly these bytes,
      producing a request body that LOOKS fine in PowerShell but is invalid JSON on the
      wire — a strict server-side parser then rejects the whole request with a generic
      "Invalid json request", and because that happens per-batch, it can silently take
      out every ticket batched alongside the one bad ticket.

      Normal whitespace (tab/newline/CR/FF/VT) is left alone here since callers already
      collapse it with `-replace '\s+', ' '`; this only removes the ones that survive
      that step.
    #>
    param([string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return $Text }
    return $Text -replace '[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', ''
}

function Get-LlmSettings {
    <#
    .SYNOPSIS
      Resolves effective LLM settings from environment variables.
    .OUTPUTS
      pscustomobject with Provider, BaseUrl, Endpoint, ApiKey, Model, ApiVersion, Configured.
    #>
    [CmdletBinding()]
    param()

    $provider = if ($env:LLM_PROVIDER) { $env:LLM_PROVIDER } else { 'core42' }
    $baseUrl = if ($env:LLM_BASE_URL) { $env:LLM_BASE_URL } else { 'https://api.core42.ai/v1' }
    $endpoint = [string]$env:AZURE_OPENAI_ENDPOINT
    $apiVersion = if ($env:AZURE_OPENAI_API_VERSION) { $env:AZURE_OPENAI_API_VERSION } else { '2024-08-01-preview' }

    $model = 'gpt-5.1'
    if ($env:LLM_MODEL) { $model = $env:LLM_MODEL }
    if ($env:AZURE_OPENAI_DEPLOYMENT) { $model = $env:AZURE_OPENAI_DEPLOYMENT }
    if ($env:OPENAI_MODEL) { $model = $env:OPENAI_MODEL }

    $apiKey = ''
    foreach ($candidate in @($env:LLM_API_KEY, $env:CORE42_API_KEY, $env:AZURE_OPENAI_API_KEY, $env:AZURE_OPENAI_KEY, $env:OPENAI_API_KEY)) {
        if ($candidate -and $candidate -notmatch 'PASTE_YOUR_') { $apiKey = [string]$candidate; break }
    }

    if ($provider -eq 'core42' -and $endpoint -match 'openai\.azure\.com|cognitiveservices\.azure\.com') {
        $provider = 'azure-openai'
    }

    $enabled = $true
    if ($env:AZURESENTRY_LLM_ENABLED) { $enabled = ($env:AZURESENTRY_LLM_ENABLED -match '^(1|true|yes)$') }

    return [pscustomobject]@{
        Provider   = $provider
        BaseUrl    = $baseUrl
        Endpoint   = $endpoint
        ApiKey     = $apiKey
        Model      = $model
        ApiVersion = $apiVersion
        Enabled    = $enabled
        Configured = ($enabled -and -not [string]::IsNullOrWhiteSpace($apiKey))
    }
}

function Invoke-LlmJsonCompletion {
    <#
    .SYNOPSIS
      Sends a system+user prompt and returns the parsed JSON object the model replied with.

    .DESCRIPTION
      Returns $null on any failure and sets -ErrorVariableName in the caller's scope
      is NOT used; instead the failure reason is returned on the .error property of a
      wrapper. Callers decide whether to fall back to deterministic rules.

    .OUTPUTS
      pscustomobject: @{ ok = $true; data = <parsed>; provider = '...' }
                   or @{ ok = $false; error = '<reason>' }
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$System,
        [Parameter(Mandatory)][string]$User,
        [int]$MaxTokens = 1200,
        [double]$Temperature = 0.1,
        [int]$Retries = 1,
        [int]$TimeoutSec = 90
    )

    $s = Get-LlmSettings
    if (-not $s.Enabled) {
        return [pscustomobject]@{ ok = $false; error = 'LLM is disabled (AZURESENTRY_LLM_ENABLED=false).' }
    }
    if (-not $s.Configured) {
        return [pscustomobject]@{ ok = $false; error = 'No LLM API key configured. Set LLM_API_KEY in dashboard/api/llm.env.' }
    }

    $messages = @(
        @{ role = 'system'; content = $System },
        @{ role = 'user'; content = $User }
    )
    $providerNorm = ([string]$s.Provider).ToLowerInvariant()

    if ($providerNorm -in @('azure-openai', 'azure')) {
        if ([string]::IsNullOrWhiteSpace($s.Endpoint)) {
            return [pscustomobject]@{ ok = $false; error = 'Azure OpenAI selected but AZURE_OPENAI_ENDPOINT is empty.' }
        }
        $uri = "$($s.Endpoint.TrimEnd('/'))/openai/deployments/$([uri]::EscapeDataString($s.Model))/chat/completions?api-version=$([uri]::EscapeDataString($s.ApiVersion))"
        $payloadObj = @{ messages = $messages; temperature = $Temperature; max_tokens = $MaxTokens; response_format = @{ type = 'json_object' } }
        $headers = @{ 'api-key' = $s.ApiKey; 'Content-Type' = 'application/json' }
    }
    elseif ($providerNorm -eq 'openai') {
        $uri = 'https://api.openai.com/v1/chat/completions'
        $payloadObj = @{ model = $s.Model; messages = $messages; temperature = $Temperature; max_tokens = $MaxTokens; response_format = @{ type = 'json_object' } }
        $headers = @{ 'Authorization' = "Bearer $($s.ApiKey)"; 'Content-Type' = 'application/json' }
    }
    else {
        # Core42 / OpenAI-compatible. gpt-5* rejects max_tokens in favour of max_completion_tokens.
        $uri = "$($s.BaseUrl.TrimEnd('/'))/chat/completions"
        $payloadObj = @{ model = $s.Model; messages = $messages; temperature = $Temperature; response_format = @{ type = 'json_object' } }
        if ($s.Model -match '^gpt-5') { $payloadObj.max_completion_tokens = $MaxTokens }
        else { $payloadObj.max_tokens = $MaxTokens }
        $headers = @{ 'api-key' = $s.ApiKey; 'Authorization' = "Bearer $($s.ApiKey)"; 'Content-Type' = 'application/json' }
    }

    $lastError = 'unknown error'
    for ($attempt = 1; $attempt -le ([Math]::Max(1, $Retries + 1)); $attempt++) {
        try {
            $payload = $payloadObj | ConvertTo-Json -Depth 10 -Compress
            # PowerShell 5.1 unrolls a single-element array; make sure messages stayed an array.
            if ($payload -notmatch '"messages"\s*:\s*\[') {
                $payloadObj.messages = @($messages)
                $payload = $payloadObj | ConvertTo-Json -Depth 10 -Compress
            }
            $resp = Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $payload -TimeoutSec $TimeoutSec -ErrorAction Stop
            $content = [string]$resp.choices[0].message.content
            if ([string]::IsNullOrWhiteSpace($content)) { throw 'LLM returned an empty completion.' }
            $jsonText = if ($content -match '(?s)\{.*\}') { $Matches[0] } else { $content }
            $parsed = $jsonText | ConvertFrom-Json -ErrorAction Stop
            return [pscustomobject]@{ ok = $true; data = $parsed; provider = $providerNorm; model = $s.Model }
        }
        catch {
            $lastError = $_.Exception.Message
            if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $lastError = $_.ErrorDetails.Message }
            # A quota / entitlement denial will not fix itself on retry.
            if ($lastError -match '(?i)quota|access to use this model|invalid api key|unauthorized') { break }
            if ($attempt -lt ($Retries + 1)) { Start-Sleep -Milliseconds 500 }
        }
    }

    $friendly = if ($lastError -match '(?i)quota|access to use this model') {
        'LLM inference unavailable: the Core42 account has no enabled chat-model quota. Contact compass.support@core42.ai to enable model access.'
    }
    elseif ($lastError -match '(?i)invalid api key|unauthorized') {
        'LLM inference unavailable: the configured API key was rejected.'
    }
    else {
        "LLM inference failed: $lastError"
    }
    return [pscustomobject]@{ ok = $false; error = $friendly }
}
