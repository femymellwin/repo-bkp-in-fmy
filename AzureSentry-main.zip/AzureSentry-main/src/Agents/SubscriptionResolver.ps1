﻿<#
.SYNOPSIS
    FR3 / §5 — resolves the multi-subscription ambiguity problem.

.DESCRIPTION
    Closes the open question "when a keyword resolves to more than one subscription,
    what happens?". The rule implemented here, in strict order:

      1. Exact subscription id (GUID)                    -> Resolved
      2. Exact subscription name (case-insensitive)      -> Resolved
      3. Exactly one fuzzy/slug candidate                -> Resolved
      4. Several candidates, exactly one in the requested
         environment                                     -> Resolved (environment filter)
      5. Still several candidates                        -> NeedsHumanChoice
      6. No candidates                                   -> NotFound

    It NEVER returns more than one subscription as resolved, so a keyword can never
    silently fan a grant out across subscriptions. Steps 4-6 are surfaced to the
    operator with the full candidate list and the reason the machine stopped.
#>

function Get-SubscriptionEnvironmentFromName {
    <#
    .SYNOPSIS
      Best-effort environment classification of a subscription from its name.
      Deliberately conservative: anything unrecognised is 'Unknown', never 'Production',
      so the environment filter can only ever narrow on positive evidence.
    #>
    param([string]$Name)

    $n = ([string]$Name).ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($n)) { return 'Unknown' }
    # Order matters: sandbox and non-prod are checked before a bare 'prod'.
    if ($n -match 'sandbox|\bsbx\b|\bsand\b|\blab\b') { return 'Sandbox' }
    if ($n -match 'non[\s_-]?prod|\bnonprod\b|\bstag(e|ing)\b|\buat\b|\bqa\b|\btest\b|\bdev\b|\bdevelopment\b|pre[\s_-]?prod') { return 'NonProd' }
    if ($n -match '\bprod\b|\bproduction\b|\bprd\b|\blive\b') { return 'Production' }
    return 'Unknown'
}

function Get-SubscriptionSlug {
    param([string]$Text)
    return (([string]$Text).ToLowerInvariant() -replace '[^a-z0-9]+', '-').Trim('-')
}

function Resolve-TicketSubscription {
    <#
    .SYNOPSIS
      Resolves a free-text subscription reference from a ticket to exactly one
      subscription, or explicitly asks for a human.

    .PARAMETER Reference
      Whatever the ticket said — a GUID, a full name, or a keyword.

    .PARAMETER Subscriptions
      Candidate pool: array of objects with .id and .label (the effective allowlist).

    .PARAMETER Environment
      Requested environment (Sandbox / NonProd / Production). Used only to break ties.

    .OUTPUTS
      pscustomobject:
        Status          Resolved | NeedsHumanChoice | NotFound
        SubscriptionId  set only when Status = Resolved
        Label
        MatchType       ExactId | ExactName | UniqueKeyword | EnvironmentFilter
        Candidates      full candidate list (id/label/environment) when ambiguous
        Reason          operator-facing explanation
    #>
    [CmdletBinding()]
    param(
        [string]$Reference,
        [object[]]$Subscriptions = @(),
        [string]$Environment
    )

    $pool = @($Subscriptions | Where-Object { $_ -and $_.id })
    $ref = ([string]$Reference).Trim()

    $describe = {
        param($s)
        [pscustomobject]@{
            id          = [string]$s.id
            label       = [string]$s.label
            environment = Get-SubscriptionEnvironmentFromName -Name ([string]$s.label)
        }
    }

    if ([string]::IsNullOrWhiteSpace($ref)) {
        return [pscustomobject]@{
            Status         = 'NotFound'
            SubscriptionId = $null
            Label          = $null
            MatchType      = $null
            Candidates     = @()
            Reason         = 'The ticket did not name a subscription. Requester must supply the Subscription field.'
        }
    }

    # 1 — exact id
    if ($ref -match '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') {
        $hit = @($pool | Where-Object { [string]$_.id -eq $ref.ToLowerInvariant() -or [string]$_.id -ieq $ref })
        if ($hit.Count -eq 1) {
            return [pscustomobject]@{
                Status         = 'Resolved'
                SubscriptionId = [string]$hit[0].id
                Label          = [string]$hit[0].label
                MatchType      = 'ExactId'
                Candidates     = @(& $describe $hit[0])
                Reason         = 'Ticket supplied an allowlisted subscription id.'
            }
        }
        return [pscustomobject]@{
            Status         = 'NotFound'
            SubscriptionId = $null
            Label          = $null
            MatchType      = $null
            Candidates     = @()
            Reason         = "Subscription id '$ref' is not on the effective allowlist."
        }
    }

    # 2 — exact name
    $exactName = @($pool | Where-Object { [string]$_.label -ieq $ref })
    if ($exactName.Count -eq 1) {
        return [pscustomobject]@{
            Status         = 'Resolved'
            SubscriptionId = [string]$exactName[0].id
            Label          = [string]$exactName[0].label
            MatchType      = 'ExactName'
            Candidates     = @(& $describe $exactName[0])
            Reason         = 'Ticket named the subscription exactly.'
        }
    }

    # 3 — slug / keyword candidates
    $refSlug = Get-SubscriptionSlug -Text $ref
    $candidates = @($pool | Where-Object {
            $labelSlug = Get-SubscriptionSlug -Text ([string]$_.label)
            $labelSlug -and $refSlug -and ($labelSlug -like "*$refSlug*" -or $refSlug -like "*$labelSlug*")
        })

    if ($candidates.Count -eq 0) {
        # Fall back to token overlap so "AI Sandbox sub" still finds "inception-ai-Sandbox".
        $tokens = @($refSlug -split '-' | Where-Object { $_.Length -ge 3 })
        if ($tokens.Count -gt 0) {
            $candidates = @($pool | Where-Object {
                    $labelSlug = Get-SubscriptionSlug -Text ([string]$_.label)
                    $matched = @($tokens | Where-Object { $labelSlug -like "*$_*" })
                    $matched.Count -eq $tokens.Count
                })
        }
    }

    if ($candidates.Count -eq 0) {
        return [pscustomobject]@{
            Status         = 'NotFound'
            SubscriptionId = $null
            Label          = $null
            MatchType      = $null
            Candidates     = @()
            Reason         = "No allowlisted subscription matches '$ref'."
        }
    }

    if ($candidates.Count -eq 1) {
        return [pscustomobject]@{
            Status         = 'Resolved'
            SubscriptionId = [string]$candidates[0].id
            Label          = [string]$candidates[0].label
            MatchType      = 'UniqueKeyword'
            Candidates     = @(& $describe $candidates[0])
            Reason         = "'$ref' matched exactly one allowlisted subscription."
        }
    }

    # 4 — environment filter as tiebreaker
    $described = @($candidates | ForEach-Object { & $describe $_ })
    if ($Environment) {
        $envMatches = @($described | Where-Object { $_.environment -eq $Environment })
        if ($envMatches.Count -eq 1) {
            return [pscustomobject]@{
                Status         = 'Resolved'
                SubscriptionId = $envMatches[0].id
                Label          = $envMatches[0].label
                MatchType      = 'EnvironmentFilter'
                Candidates     = $described
                Reason         = "'$ref' matched $($candidates.Count) subscriptions; the $Environment environment filter left exactly one."
            }
        }
    }

    # 5 — genuinely ambiguous: a human picks. Never grant all.
    return [pscustomobject]@{
        Status         = 'NeedsHumanChoice'
        SubscriptionId = $null
        Label          = $null
        MatchType      = $null
        Candidates     = $described
        Reason         = "'$ref' matches $($candidates.Count) allowlisted subscriptions$(if ($Environment) { " and the $Environment filter did not narrow it to one" }). An operator must choose the subscription — the agent will not grant across all matches."
    }
}
