﻿<#
.SYNOPSIS
    FR4 — categorizes tickets by agent-actionable work type so department scope
    expansion (IDAM/IDM -> Infrastructure) is measured rather than guessed.

.DESCRIPTION
    The target from the review: of ~480 Infrastructure tickets, identify roughly
    300-400 an agent can action. This agent produces that number and shows its work.

    Two-stage, same pattern as environment inference:
      1. Deterministic rules on subject/description/template. Cheap, explainable,
         and it handles the bulk of Infrastructure tickets, which are formulaic.
      2. LLM step for whatever the rules leave as 'Unclassified'. Flagged as inferred
         with a confidence, never silently merged with rule-matched results.

    Read-only. Nothing here grants anything — it produces the categorization report
    that decides which work types get automated next.
#>

# Agent-actionable work types. `actionable` means an agent could carry it out today or
# with a well-understood API call; `humanAudit` means it still needs a human check
# before or after, which is the default for anything that mints a credential.
$script:WorkTypeCatalog = [ordered]@{
    'AccessGrant'          = [pscustomobject]@{
        Key = 'AccessGrant'; DisplayName = 'Subscription / RBAC access grant'
        Actionable = $true; HumanAudit = $false
        Description = 'Reader / Contributor / role grant at subscription or resource-group scope — the existing IDM path.'
    }
    'AppRegistration'      = [pscustomobject]@{
        Key = 'AppRegistration'; DisplayName = 'App registration creation'
        Actionable = $true; HumanAudit = $true
        Description = 'Create an Entra application registration (+ service principal). Graph Application.ReadWrite.OwnedBy.'
    }
    'ClientSecret'         = [pscustomobject]@{
        Key = 'ClientSecret'; DisplayName = 'Client secret / credential creation'
        Actionable = $true; HumanAudit = $true
        Description = 'Add or rotate a client secret or certificate on an existing app registration. Always human-audited — it mints a credential.'
    }
    'GroupMembership'      = [pscustomobject]@{
        Key = 'GroupMembership'; DisplayName = 'Entra group membership change'
        Actionable = $true; HumanAudit = $false
        Description = 'Add or remove a user from a security group — already implemented by the group-based RBAC path.'
    }
    'ResourceProvisioning' = [pscustomobject]@{
        Key = 'ResourceProvisioning'; DisplayName = 'Resource / resource-group provisioning'
        Actionable = $true; HumanAudit = $true
        Description = 'Create a resource group, VM, storage account or similar from a templated request.'
    }
    'QuotaIncrease'        = [pscustomobject]@{
        Key = 'QuotaIncrease'; DisplayName = 'Quota / limit increase'
        Actionable = $true; HumanAudit = $true
        Description = 'Raise a subscription quota via the ARM quota API. Cost-bearing, so human-audited.'
    }
    'KeyVaultAccess'       = [pscustomobject]@{
        Key = 'KeyVaultAccess'; DisplayName = 'Key Vault access / secret request'
        Actionable = $true; HumanAudit = $true
        Description = 'Grant Key Vault data-plane access or provision a secret reference.'
    }
    'Troubleshooting'      = [pscustomobject]@{
        Key = 'Troubleshooting'; DisplayName = 'Troubleshooting / incident'
        Actionable = $false; HumanAudit = $true
        Description = 'Diagnosis of a broken system. Needs an engineer; an agent can gather context but not resolve it.'
    }
    'NetworkChange'        = [pscustomobject]@{
        Key = 'NetworkChange'; DisplayName = 'Networking change'
        Actionable = $false; HumanAudit = $true
        Description = 'VNet / NSG / firewall / DNS / VPN change. Out of scope — owned by another team.'
    }
    'Advisory'             = [pscustomobject]@{
        Key = 'Advisory'; DisplayName = 'Question / advisory'
        Actionable = $false; HumanAudit = $true
        Description = 'A question or guidance request with no change to make.'
    }
    'Unclassified'         = [pscustomobject]@{
        Key = 'Unclassified'; DisplayName = 'Unclassified'
        Actionable = $false; HumanAudit = $true
        Description = 'Neither rules nor inference could place this ticket. Needs a human read.'
    }
}

function Get-WorkTypeCatalog {
    return @($script:WorkTypeCatalog.Values)
}

function Get-SafeTruncatedText {
    <#
    .SYNOPSIS
      Truncates text without ever splitting a UTF-16 surrogate pair -- a hard
      Substring(0, N) can land mid-pair (emoji, some rich-text symbols) and the
      lone surrogate that results is invalid UTF-16, which breaks JSON
      serialization of the LLM request. This agent keeps its own copy rather
      than sharing one: it was previously duplicated with the now-removed
      src/Agents/EnvironmentInferenceAgent.ps1, and that agent's LLM-inference
      half was deleted, so this is the only copy left.
    #>
    param([string]$Text, [int]$MaxLength)
    if ([string]::IsNullOrEmpty($Text) -or $Text.Length -le $MaxLength) { return $Text }
    $cut = $MaxLength
    if ($cut -gt 0 -and [char]::IsHighSurrogate($Text[$cut - 1])) { $cut-- }
    return $Text.Substring(0, $cut)
}

function Get-RuleBasedWorkType {
    <#
    .SYNOPSIS
      Deterministic work-type classification from ticket text.
      Ordered most-specific first: a "create a secret for app X" ticket must land on
      ClientSecret, not AppRegistration, and not AccessGrant.
    .DESCRIPTION
      KeywordMatch reports whether a deterministic pattern actually matched the ticket
      text. It mirrors Get-RuleBasedEnvironment: a phrase the requester wrote is direct
      evidence of what the ticket is, so it does not need a human to confirm the
      classification.
    .OUTPUTS
      pscustomobject with WorkType, Confidence, KeywordMatch, Rationale.
    #>
    param([string]$Text)

    $t = ([string]$Text).ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($t)) {
        return [pscustomobject]@{ WorkType = 'Unclassified'; Confidence = 0.0; KeywordMatch = $false; Rationale = 'No ticket text to classify.' }
    }

    $rules = @(
        @{ Type = 'ClientSecret'; Pattern = 'client secret|clientsecret|app secret|secret expir|rotate (the )?(secret|credential)|new secret|certificate for (the )?app|add credential'; Why = 'mentions a client secret or app credential' }
        @{ Type = 'AppRegistration'; Pattern = 'app registration|app-registration|register (an|a|new) app|service principal creation|create (a )?(new )?(service principal|spn|enterprise app)|aad app'; Why = 'mentions creating an app registration or service principal' }
        @{ Type = 'KeyVaultAccess'; Pattern = 'key ?vault|keyvault|access policy for vault|secret from vault'; Why = 'mentions Key Vault' }
        @{ Type = 'QuotaIncrease'; Pattern = 'quota|vcpu limit|core limit|increase (the )?limit|capacity increase|sku availability'; Why = 'mentions a quota or limit increase' }
        @{ Type = 'GroupMembership'; Pattern = 'add (me|him|her|them|user).{0,30}(to|into) (the )?group|security group member|group membership|remove.{0,20}from (the )?group|\bsg-'; Why = 'mentions a security-group membership change' }
        @{ Type = 'AccessGrant'; Pattern = 'contributor|reader access|\brbac\b|\bpim\b|role assignment|user access administrator|\buaa\b|owner access|grant.{0,20}access|access to (the )?subscription|elevate|privileged access'; Why = 'mentions an Azure role or access grant' }
        @{ Type = 'ResourceProvisioning'; Pattern = 'create (a )?(resource group|vm|virtual machine|storage account|app service|aks|database|container registry)|provision|new subscription|deploy (a )?(new )?(vm|resource)'; Why = 'mentions provisioning a resource' }
        @{ Type = 'NetworkChange'; Pattern = '\bvnet\b|\bnsg\b|firewall|\bdns\b|\bvpn\b|subnet|peering|private endpoint|load balancer|application gateway|open (a )?port'; Why = 'mentions a networking change' }
        @{ Type = 'Troubleshooting'; Pattern = 'not working|unable to|cannot |can not |error|failed|failure|issue with|broken|outage|down|troubleshoot|degraded|timeout|denied'; Why = 'describes something failing' }
        @{ Type = 'Advisory'; Pattern = '\bhow (do|to|can)\b|\bquestion\b|clarification|please advise|guidance|documentation|is it possible'; Why = 'asks a question rather than requesting a change' }
    )

    foreach ($rule in $rules) {
        if ($t -match $rule.Pattern) {
            return [pscustomobject]@{
                WorkType   = $rule.Type
                # High but not certain: rules are precise on Infrastructure phrasing but
                # not infallible, and the report shows the source either way.
                Confidence = 0.8
                KeywordMatch = $true
                Rationale  = "Rule match — $($rule.Why)."
            }
        }
    }
    return [pscustomobject]@{ WorkType = 'Unclassified'; Confidence = 0.0; KeywordMatch = $false; Rationale = 'No deterministic rule matched.' }
}

function Get-WorkTypeClassificationPrompt {
    $types = ($script:WorkTypeCatalog.Values | Where-Object { $_.Key -ne 'Unclassified' } |
            ForEach-Object { "  `"$($_.Key)`" - $($_.Description)" }) -join "`n"
    return @"
You classify IT infrastructure help-desk tickets by the kind of work they ask for.

Allowed work types:
$types
  "Unclassified" - genuinely cannot be placed in any of the above.

Rules:
1. Reply with JSON only. No markdown fences.
2. Shape exactly: {"results":[{"id":"<ticket id as given>","workType":"<one of the keys above>","confidence":0.0,"rationale":"one short sentence"}]}
3. One result per input ticket, same ids.
4. Pick the PRIMARY work type. A ticket asking to create an app registration AND its
   secret is "AppRegistration"; a ticket about an existing app's expiring secret is "ClientSecret".
5. confidence is your calibrated probability, 0.0 to 1.0. Do not inflate it.
6. A ticket describing something broken is "Troubleshooting" even if it mentions a role or resource.
7. Use "Unclassified" rather than forcing a poor fit.
"@
}

function Invoke-TicketCategorizationAgent {
    <#
    .SYNOPSIS
      Classifies tickets by agent-actionable work type and reports how much of the
      queue an agent could take on.

    .PARAMETER Tickets
      Array of objects with: id, subject, description (optional), department (optional),
      ticketType (optional ME template name).

    .PARAMETER NoLlm
      Rules only. Used by tests and for an offline first pass.

    .OUTPUTS
      pscustomobject with Results, Summary (counts + actionable totals), LlmUsed, LlmError.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object[]]$Tickets,
        [int]$LlmBatchSize = 10,
        [switch]$NoLlm
    )

    $results = [System.Collections.Generic.List[object]]::new()
    $unmatched = [System.Collections.Generic.List[object]]::new()
    $ruleByTicket = @{}

    foreach ($t in $Tickets) {
        $text = @([string]$t.subject, [string]$t.ticketType, [string]$t.description) -join ' '
        $text = ($text -replace '<[^>]+>', ' ') -replace '\s+', ' '
        $rule = Get-RuleBasedWorkType -Text $text
        $ruleByTicket[[string]$t.id] = $rule
        if ($rule.WorkType -eq 'Unclassified') { $unmatched.Add($t) }
    }

    # --- LLM pass over what the rules could not place --------------------------
    $llmUsed = $false
    $llmError = $null
    $llmByTicket = @{}

    if ($unmatched.Count -gt 0 -and -not $NoLlm) {
        if (-not (Get-Command -Name Invoke-LlmJsonCompletion -ErrorAction SilentlyContinue)) {
            $llmError = 'LLM client not loaded (src/Agents/LlmClient.ps1). Unmatched tickets stay Unclassified.'
        }
        else {
            $system = Get-WorkTypeClassificationPrompt
            for ($i = 0; $i -lt $unmatched.Count; $i += $LlmBatchSize) {
                $slice = @($unmatched[$i..([Math]::Min($i + $LlmBatchSize - 1, $unmatched.Count - 1))])
                $lines = foreach ($t in $slice) {
                    $desc = [string]$t.description
                    $desc = ($desc -replace '<[^>]+>', ' ') -replace '\s+', ' '
                    $desc = Get-SafeTruncatedText -Text $desc -MaxLength 800
                    # Remove raw control bytes PowerShell 5.1's JSON serializer would
                    # leave unescaped — see ConvertTo-LlmSafeText for why this matters.
                    $desc = ConvertTo-LlmSafeText -Text $desc
                    $safeSubject = ConvertTo-LlmSafeText -Text ([string]$t.subject)
                    $safeTicketType = ConvertTo-LlmSafeText -Text ([string]$t.ticketType)
                    @"
- id: $($t.id)
  ticket_type: $safeTicketType
  subject: $safeSubject
  description: $($desc.Trim())
"@
                }
                # Retries = 2 (3 attempts total): "Invalid json request" and similar failures
                # observed against this gateway are intermittent/transient, not tied to
                # specific ticket content (confirmed by re-running identical failing batches
                # with zero repeat failures) — a couple of extra attempts meaningfully cuts
                # how often a rare hiccup survives to become a batch-level fallback.
                $resp = Invoke-LlmJsonCompletion -System $system -User "Classify these tickets:`n`n$($lines -join "`n")" -MaxTokens 2500 -Temperature 0.0 -Retries 2
                if (-not $resp.ok) {
                    # Keep going — one bad batch must not take down every batch after it.
                    $llmError = $resp.error
                    continue
                }
                $llmUsed = $true
                foreach ($r in @($resp.data.results)) {
                    if ($r -and $r.id) { $llmByTicket[[string]$r.id] = $r }
                }
            }
        }
    }

    foreach ($t in $Tickets) {
        $id = [string]$t.id
        $rule = $ruleByTicket[$id]
        $workType = $rule.WorkType
        $confidence = $rule.Confidence
        $source = 'Rules'
        $rationale = $rule.Rationale
        $keywordMatch = [bool]$rule.KeywordMatch

        if ($workType -eq 'Unclassified' -and $llmByTicket.ContainsKey($id)) {
            $r = $llmByTicket[$id]
            $candidate = [string]$r.workType
            if ($script:WorkTypeCatalog.Contains($candidate)) {
                $workType = $candidate
                $confidence = [Math]::Round([double]$r.confidence, 3)
                if ($confidence -gt 1) { $confidence = 1.0 }
                if ($confidence -lt 0) { $confidence = 0.0 }
                $source = 'Llm'
                $rationale = [string]$r.rationale
                # An LLM label is a judgement, not a matched phrase.
                $keywordMatch = $false
            }
        }
        elseif ($workType -eq 'Unclassified' -and $llmError) {
            $rationale = "$rationale (LLM unavailable: $llmError)"
        }

        $catalog = $script:WorkTypeCatalog[$workType]

        # Operator decision (2026-08-19): a deterministic keyword match settles the row, so
        # it is not held back for a human read. policyHumanAudit keeps the work type's
        # standing audit posture on the row so the report still shows what was cleared and
        # by what evidence — the count moves, the policy stays legible and reversible.
        #
        # Scope: this report is read-only and grants nothing. humanAudit here has no
        # consumer outside this report's own counts and table (verified repo-wide), so
        # clearing it changes how work is characterised, not what any agent is permitted
        # to do. Any future write path must read policyHumanAudit, never humanAudit.
        # Only actionable work is cleared. On non-actionable work (Troubleshooting,
        # NetworkChange, Advisory) the flag is not review burden at all — it says an
        # engineer has to do the job — so clearing it there would assert the opposite.
        $policyHumanAudit = [bool]$catalog.HumanAudit
        $humanAudit = $policyHumanAudit
        if ($keywordMatch -and $policyHumanAudit -and $catalog.Actionable) {
            $humanAudit = $false
            $rationale = "$rationale Classification is a deterministic keyword match, so no human read is required to confirm it; '$($catalog.DisplayName)' carries a standing audit posture (policyHumanAudit) for the action itself."
        }

        $results.Add([pscustomobject]@{
                id               = $id
                subject          = [string]$t.subject
                department       = [string]$t.department
                ticketType       = [string]$t.ticketType
                workType         = $workType
                displayName      = $catalog.DisplayName
                actionable       = [bool]$catalog.Actionable
                humanAudit       = $humanAudit
                policyHumanAudit = $policyHumanAudit
                confidence       = $confidence
                source           = $source
                keywordMatch     = $keywordMatch
                inferred         = ($source -eq 'Llm')
                rationale        = $rationale
            })
    }

    $all = @($results)
    $byWorkType = [ordered]@{}
    foreach ($key in $script:WorkTypeCatalog.Keys) {
        $count = @($all | Where-Object { $_.workType -eq $key }).Count
        if ($count -gt 0) { $byWorkType[$key] = $count }
    }

    $actionable = @($all | Where-Object { $_.actionable })
    return [pscustomobject]@{
        Results     = $all
        Summary     = [pscustomobject]@{
            total                = $all.Count
            actionable           = $actionable.Count
            notActionable        = $all.Count - $actionable.Count
            actionableRate       = $(if ($all.Count) { [Math]::Round($actionable.Count / [double]$all.Count, 4) } else { 0 })
            actionableWithAudit  = @($actionable | Where-Object { $_.humanAudit }).Count
            actionableFullyAuto  = @($actionable | Where-Object { -not $_.humanAudit }).Count
            unclassified         = @($all | Where-Object { $_.workType -eq 'Unclassified' }).Count
            fromRules            = @($all | Where-Object { $_.source -eq 'Rules' }).Count
            fromKeywordMatch     = @($all | Where-Object { $_.keywordMatch }).Count
            fromLlm              = @($all | Where-Object { $_.source -eq 'Llm' }).Count
            # Rows whose standing audit posture was cleared by a keyword match. Keeps the
            # drop in actionableWithAudit attributable instead of unexplained.
            auditClearedByKeyword = @($all | Where-Object { $_.keywordMatch -and $_.policyHumanAudit -and -not $_.humanAudit }).Count
            # What actionableWithAudit would be on standing policy alone, for comparison.
            actionableWithAuditByPolicy = @($actionable | Where-Object { $_.policyHumanAudit }).Count
            byWorkType           = [pscustomobject]$byWorkType
        }
        Catalog     = Get-WorkTypeCatalog
        LlmUsed     = $llmUsed
        LlmError    = $llmError
        GeneratedAt = (Get-Date).ToUniversalTime().ToString('o')
    }
}
