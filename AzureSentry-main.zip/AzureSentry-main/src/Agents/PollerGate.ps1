<#
.SYNOPSIS
    The one place that decides whether a ticket may be granted with no human involved.

.DESCRIPTION
    Kept free of ME and Azure I/O so the policy boundary can be tested exhaustively.
    Four conditions, all required; any failure queues the ticket for a human.
#>

# Actions the poller may execute unattended. Deliberately excludes:
#   Eligible   - its approval gate is currently the operator clicking Provide Access in
#                the dashboard. Auto-executing it would delete the only approval for
#                prod Contributor / Owner / UAA.
#   BreakGlass - P1 emergency access.
#   Hold/Reject- no write by definition.
$script:PollerAutoActions = @('Grant')

# Environments the poller may write to. Production is excluded even for Reader, which the
# eligibility matrix marks as Grant with no approver: read-only, but still unattended
# Production access.
$script:PollerAutoEnvironments = @('Sandbox', 'NonProd')

function Test-PollerAutoEligible {
    <#
    .OUTPUTS
      pscustomobject with Eligible (bool) and Reason (string).
    #>
    param(
        [Parameter(Mandatory)][object]$Decision,
        [Parameter(Mandatory)][object]$Mapping,
        [bool]$TemplateAllowed = $false
    )

    $deny = {
        param([string]$Reason)
        [pscustomobject]@{ Eligible = $false; Reason = $Reason }
    }

    if (-not $TemplateAllowed) {
        return & $deny 'ManageEngine template is not an azure-subscription-grant template.'
    }

    if (-not $Mapping.Complete) {
        $detail = if (@($Mapping.Warnings).Count -gt 0) { (@($Mapping.Warnings) -join ' ') } else { 'mapping incomplete' }
        return & $deny "Structured ME fields are incomplete: $detail"
    }

    $action = [string]$Decision.Action
    if ($script:PollerAutoActions -notcontains $action) {
        return & $deny "Decision action '$action' is not auto-executable; only $($script:PollerAutoActions -join '/') is."
    }

    # Read the EFFECTIVE environment, never the ticket's claim: Resolve-RbacDecision raises
    # environment from subscription sensitivity, so a ticket claiming Sandbox against a
    # sensitive subscription becomes Production and must fall out here.
    $effective = [string]$Decision.EffectiveEnvironment
    if ([string]::IsNullOrWhiteSpace($effective)) {
        return & $deny 'Decision carried no effective environment; refusing to assume it is safe.'
    }
    if ($script:PollerAutoEnvironments -notcontains $effective) {
        return & $deny "Effective environment '$effective' is excluded from unattended writes (allowed: $($script:PollerAutoEnvironments -join '/'))."
    }

    return [pscustomobject]@{
        Eligible = $true
        Reason   = "Action $action on $effective from complete structured ME fields."
    }
}

function Resolve-PollerStatusView {
    <#
    .SYNOPSIS
      Derive the dashboard safety panel's enabled/mode from the poller's OWN last
      reported cycle, never from this (dashboard) process's environment.
    .DESCRIPTION
      final-review C3. The poller is a separate pwsh process, started fresh every 5
      minutes from /etc/azuresentry.env; the dashboard is a long-running process that is
      never restarted when the poller's enable/mode env vars change (the runbook's
      enable steps restart only the poller timer). Reading $env:AZURESENTRY_POLLER_ENABLED
      / _MODE in the dashboard process reports whatever was true when the DASHBOARD last
      started, which silently drifts from what the poller is actually doing -- exactly
      backwards for the operator's primary safety readout on an unattended granter that
      writes real Azure RBAC. Ground truth is what the poller last actually reported
      about itself, in poller-status.json.

      A status file that is missing, unparseable, or stale (its ranAt older than
      StaleAfterMinutes -- more than double the 5-minute poller cadence, so one merely
      slow cycle is not misreported) resolves to Enabled=$null / Mode=$null / Stale=$true,
      i.e. "unknown". The risk of a false, reassuring "Off" while enforce silently grants
      is worse than an "unknown" prompting an operator to go check directly.
    #>
    param(
        [object]$LastCycle,
        [datetime]$Now = [datetime]::UtcNow,
        [int]$StaleAfterMinutes = 15
    )

    $view = [pscustomobject]@{ Enabled = $null; Mode = $null; Stale = $false }
    if (-not $LastCycle) {
        $view.Stale = $true
        return $view
    }

    $ranAt = [datetime]::MinValue
    $ranAtRaw = [string]$LastCycle.ranAt
    if (-not $ranAtRaw -or -not [datetime]::TryParse(
            $ranAtRaw, [System.Globalization.CultureInfo]::InvariantCulture,
            [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal,
            [ref]$ranAt)) {
        # No parseable timestamp at all -- cannot vouch for freshness either way.
        $view.Stale = $true
        return $view
    }
    if (($Now - $ranAt).TotalMinutes -gt $StaleAfterMinutes) {
        $view.Stale = $true
        return $view
    }

    $mode = [string]$LastCycle.mode
    $view.Mode = if ($mode -eq 'enforce') { 'enforce' } else { 'shadow' }

    # Get-PollerConfig's disabled halt reason is the fixed literal string
    # 'AZURESENTRY_POLLER_ENABLED is not true.' (TicketPollerAgent.ps1). Only THAT
    # specific halt means "disabled" -- any other halt (stop sentinel, FetchTickets
    # threw) still means the poller is enabled and would run the moment the real
    # blocker clears; conflating them would misreport "Off" for a poller that is not.
    $halted = [bool]$LastCycle.halted
    $haltReason = [string]$LastCycle.haltReason
    $view.Enabled = -not ($halted -and $haltReason -like '*AZURESENTRY_POLLER_ENABLED*')
    return $view
}
