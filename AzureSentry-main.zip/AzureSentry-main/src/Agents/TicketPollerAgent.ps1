<#
.SYNOPSIS
    One unattended poll cycle: select ME tickets, decide, and (in enforce mode) grant.

.DESCRIPTION
    Every external dependency is injected through the -Context hashtable so the whole
    cycle is testable with no ManageEngine or Azure I/O. scripts/Invoke-TicketPollerCycle.ps1
    builds the real context.

    Default posture is off and shadow. Shadow records exactly what it would have granted
    and writes nothing -- deliberately reporting WouldGrant rather than "skipped", which in
    the environment backfill made a successful dry run read identically to a failure.
#>

function Get-PollerConfig {
    <#
    .SYNOPSIS
      Read the poller's operating envelope from the environment.
    .DESCRIPTION
      Both the kill switch and the mode require an exact string match. A typo in
      AZURESENTRY_POLLER_ENABLED must leave the poller off, and a typo in
      AZURESENTRY_POLLER_MODE must leave it in shadow -- never the other way round.

      StopFilePath resolves in this order: the explicit -StopFilePath argument, then
      AZURESENTRY_POLLER_STOP_FILE, then a default next to wherever the processed store
      lives (when ProcessedStore.ps1 has already been dot-sourced and initialized by the
      caller), then the current directory. Without this fallback chain, a caller that
      forgets to wire a path silently has no kill file at all -- the documented "drop a
      file, halt the poller" promise must hold without a config edit.

      ModeOverrideFilePath resolves the same way (explicit arg, then
      AZURESENTRY_POLLER_MODE_FILE, then the same default directory as the stop file),
      naming 'poller.mode'. This is the dashboard's Enforce Mode toggle
      (POST /api/poller/mode): the API process cannot set AZURESENTRY_POLLER_MODE for
      the poller (a separate process, re-reading /etc/azuresentry.env fresh on every
      cycle), so it writes this file instead, and this function checks it FIRST, ahead
      of the environment variable. Same fail-closed contract as the env var: content is
      significant only when it is exactly 'enforce' (after trim + lowercase) -- anything
      else present in the file (garbage, blank, even the literal word 'shadow') resolves
      to 'shadow', never silently falls through to trusting the environment variable
      instead. When the file does not exist at all, behaviour is unchanged from before
      this override existed: the environment variable alone decides.
    #>
    param(
        [string]$StopFilePath = '',
        [string]$ModeOverrideFilePath = '',
        [string]$EnabledOverrideFilePath = '',
        [string]$CapsOverrideFilePath = ''
    )

    $enabled = ([string]$env:AZURESENTRY_POLLER_ENABLED).Trim().ToLowerInvariant() -eq 'true'
    $envMode = if (([string]$env:AZURESENTRY_POLLER_MODE).Trim().ToLowerInvariant() -eq 'enforce') { 'enforce' } else { 'shadow' }

    $asInt = {
        param([string]$Value, [int]$Default)
        $n = 0
        if ([int]::TryParse(([string]$Value).Trim(), [ref]$n) -and $n -gt 0) { return $n }
        return $Default
    }

    $defaultDir = {
        $storeDir = $null
        if (Get-Command -Name Get-ProcessedStoreDir -ErrorAction SilentlyContinue) {
            try { $storeDir = Get-ProcessedStoreDir } catch { $storeDir = $null }
        }
        if (-not $storeDir) { $storeDir = (Get-Location).Path }
        return $storeDir
    }

    $stopFile = ([string]$StopFilePath).Trim()
    if (-not $stopFile) { $stopFile = ([string]$env:AZURESENTRY_POLLER_STOP_FILE).Trim() }
    if (-not $stopFile) { $stopFile = Join-Path (& $defaultDir) 'poller.stop' }

    $modeFile = ([string]$ModeOverrideFilePath).Trim()
    if (-not $modeFile) { $modeFile = ([string]$env:AZURESENTRY_POLLER_MODE_FILE).Trim() }
    if (-not $modeFile) { $modeFile = Join-Path (& $defaultDir) 'poller.mode' }

    $enabledFile = ([string]$EnabledOverrideFilePath).Trim()
    if (-not $enabledFile) { $enabledFile = ([string]$env:AZURESENTRY_POLLER_ENABLED_FILE).Trim() }
    if (-not $enabledFile) { $enabledFile = Join-Path (& $defaultDir) 'poller.enabled' }

    $capsFile = ([string]$CapsOverrideFilePath).Trim()
    if (-not $capsFile) { $capsFile = ([string]$env:AZURESENTRY_POLLER_CAPS_FILE).Trim() }
    if (-not $capsFile) { $capsFile = Join-Path (& $defaultDir) 'poller.caps.json' }

    $modeSource = 'env'
    $mode = $envMode
    if (Test-Path -LiteralPath $modeFile) {
        $modeSource = 'override'
        $override = ''
        try { $override = (Get-Content -Raw -LiteralPath $modeFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $override = '' }
        $mode = if ($override -eq 'enforce') { 'enforce' } else { 'shadow' }
    }

    $enabledSource = 'env'
    if (Test-Path -LiteralPath $enabledFile) {
        $enabledSource = 'override'
        $enabledOverride = ''
        try { $enabledOverride = (Get-Content -Raw -LiteralPath $enabledFile -ErrorAction Stop).Trim().ToLowerInvariant() } catch { $enabledOverride = '' }
        $enabled = ($enabledOverride -eq 'true')
    }

    $maxTicketsSource = 'env'
    $maxGrantsSource = 'env'
    $maxAgeDaysSource = 'env'
    $maxTickets = (& $asInt $env:AZURESENTRY_POLLER_MAX_TICKETS 100)
    $maxGrants = (& $asInt $env:AZURESENTRY_POLLER_MAX_GRANTS 5)
    $maxAgeDays = (& $asInt $env:AZURESENTRY_POLLER_MAX_AGE_DAYS 7)
    if (Test-Path -LiteralPath $capsFile) {
        $capsJson = $null
        try { $capsJson = Get-Content -Raw -LiteralPath $capsFile -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { $capsJson = $null }
        if ($capsJson) {
            if ($capsJson.PSObject.Properties.Name -contains 'maxTickets') {
                $n = 0
                if ([int]::TryParse([string]$capsJson.maxTickets, [ref]$n) -and $n -gt 0) { $maxTickets = $n; $maxTicketsSource = 'override' }
            }
            if ($capsJson.PSObject.Properties.Name -contains 'maxGrants') {
                $n = 0
                if ([int]::TryParse([string]$capsJson.maxGrants, [ref]$n) -and $n -gt 0) { $maxGrants = $n; $maxGrantsSource = 'override' }
            }
            if ($capsJson.PSObject.Properties.Name -contains 'maxAgeDays') {
                $n = 0
                if ([int]::TryParse([string]$capsJson.maxAgeDays, [ref]$n) -and $n -gt 0) { $maxAgeDays = $n; $maxAgeDaysSource = 'override' }
            }
        }
    }

    return [pscustomobject]@{
        Enabled                  = $enabled
        EnabledSource            = $enabledSource
        EnabledOverrideFilePath  = $enabledFile
        Mode                     = $mode
        ModeSource               = $modeSource
        ModeOverrideFilePath     = $modeFile
        # I2 (2026-08-20 final review): this is a runaway guard, not the safety bound.
        # FetchTickets requests row_count 100 sorted newest-first; a cap below that
        # starves the queue permanently -- queued tickets are never recorded as
        # processed, so they are re-examined and re-skipped every single cycle, and
        # anything past the cap (e.g. ticket #26 when the fetch returns 100) is never
        # reached at all. The real blast-radius bound is MaxGrantsPerCycle: deciding and
        # queuing are cheap, local, and non-writing; only the grant is expensive and
        # risky, and it already has its own cap below. Default matches the fetch size so
        # nothing in-window is permanently unreachable.
        MaxTicketsPerCycle    = $maxTickets
        MaxTicketsSource      = $maxTicketsSource
        MaxGrantsPerCycle     = $maxGrants
        MaxGrantsSource       = $maxGrantsSource
        MaxTicketAgeDays      = $maxAgeDays
        MaxAgeDaysSource      = $maxAgeDaysSource
        CapsOverrideFilePath  = $capsFile
        StopFilePath          = $stopFile
    }
}

function Get-MeTicketCreatedUtc {
    <#
    .SYNOPSIS
      ME created_time to UTC datetime, or $null when unparseable.
    .DESCRIPTION
      SDP returns epoch milliseconds, usually wrapped as @{ value = '...' }. That wrapper
      can arrive as either a [pscustomobject] (the normal ConvertFrom-Json shape) or a
      [Hashtable] (ConvertFrom-Json -AsHashtable, used by pwsh 7 callers) -- a Hashtable's
      adapted properties are Keys/Values/Count, not 'value', so PSObject.Properties alone
      would miss it and every ticket would silently read as unparseable. IDictionary is
      checked explicitly so both shapes work.
    #>
    param([object]$MeTicket)

    $raw = $null
    if ($MeTicket.created_time) {
        $ct = $MeTicket.created_time
        if ($ct -is [System.Collections.IDictionary]) {
            $raw = if ($ct.Contains('value')) { [string]$ct['value'] } else { [string]$ct }
        }
        elseif ($ct.PSObject.Properties.Name -contains 'value') {
            $raw = [string]$ct.value
        }
        else {
            $raw = [string]$ct
        }
    }
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }

    # Upper bound is epoch-ms for 9999-12-31T23:59:59.999Z (DateTime's own max). Without
    # it, any positive int64 that overflows DateTime -- epoch microseconds or nanoseconds
    # are the common real-world case -- reaches AddMilliseconds and throws
    # ArgumentOutOfRangeException uncaught, killing the whole poll cycle rather than just
    # this one ticket. The try/catch is a second line of defense for any other overflow
    # shape the range check does not anticipate; either way this must return $null, never
    # let the exception escape.
    $ms = 0L
    if ([int64]::TryParse($raw, [ref]$ms) -and $ms -gt 0 -and $ms -le 253402300799999) {
        try {
            return ([datetime]'1970-01-01').AddMilliseconds($ms)
        }
        catch {
            return $null
        }
    }
    $parsed = [datetime]::MinValue
    if ([datetime]::TryParse($raw, [ref]$parsed)) { return $parsed.ToUniversalTime() }
    return $null
}

function Test-PollerTicketInWindow {
    <#
    .SYNOPSIS
      True when the ticket is recent enough to consider.
    .DESCRIPTION
      Bounds the cold start: without this, a first run would attempt the entire open
      historical backlog. A ticket with no parseable created_time is refused rather than
      assumed new.

      Also bounds the future side (one day of clock-skew tolerance): the window exists to
      fail closed, and a purely past-side check fails open for a clock-skewed or corrupt
      created_time -- a single such ticket would otherwise bypass the window forever,
      since "in the future" never ages out.
    #>
    param(
        [Parameter(Mandatory)][object]$MeTicket,
        [int]$MaxAgeDays = 7,
        [datetime]$Now = [datetime]::UtcNow
    )

    $created = Get-MeTicketCreatedUtc -MeTicket $MeTicket
    if ($null -eq $created) { return $false }
    $lowerBound = $Now.AddDays(-1 * [Math]::Abs($MaxAgeDays))
    $upperBound = $Now.AddDays(1)
    return ($created -ge $lowerBound) -and ($created -le $upperBound)
}

function Invoke-TicketPollerCycle {
    <#
    .SYNOPSIS
      Run exactly one poll cycle.
    .DESCRIPTION
      ManageEngine write-back (Context.PostTicketNote / Context.ResolveTicket) only ever
      fires from the two enforce-mode outcomes that actually did something to Azure:
      Granted posts a success note then resolves the ticket; a grant Failure posts a
      failure note and does NOT resolve (the ticket must stay open for a human, and the
      note must not imply access was granted). Every Queued outcome -- whatever the
      reason -- deliberately posts no note. Queued tickets (other than the duplicate-grant
      case, which IS recorded) are NOT written to the processed store, precisely so a
      ticket that only needs e.g. a backfilled ME dropdown gets re-examined on the next
      cycle rather than stuck forever; if Queued posted a note too, every re-examination
      would post ANOTHER note, spamming the requester's ticket once per cycle indefinitely.
      Shadow mode (WouldGrant) never calls either hook -- shadow's contract is to write
      nothing, ManageEngine included; do not add a shadow-mode note "preview" here.
    .OUTPUTS
      pscustomobject with RunId, Mode, Examined, WouldGrant, Granted, Queued, Failed,
      Stopped, Halted, Entries.
    #>
    param([Parameter(Mandatory)][hashtable]$Context)

    $config = $Context.Config
    # The entry script (scripts/Invoke-TicketPollerCycle.ps1) generates a run id up front
    # and threads it through Context.RunId so the SAME id lands both in this cycle's
    # result and in whatever ExecuteGrant persists to the processed store -- without this,
    # the two would drift, and a grant record's runId would not correlate with the cycle
    # that produced it. Callers that do not supply one (every existing test context) keep
    # the old self-generated behaviour unchanged.
    $runId = if ($Context.ContainsKey('RunId') -and $Context.RunId) {
        [string]$Context.RunId
    } elseif (Get-Command -Name New-AgentRunId -ErrorAction SilentlyContinue) {
        New-AgentRunId
    } else {
        "poll-$([guid]::NewGuid().ToString('N').Substring(0, 12))"
    }

    $entries = [System.Collections.Generic.List[object]]::new()
    $tally = @{ Examined = 0; WouldGrant = 0; Granted = 0; Queued = 0; Failed = 0; Stopped = $false }

    # Property names are camelCase because this object is serialized straight to
    # poller-status.json and read by the dashboard, and the rest of the API's JSON is
    # camelCase. PowerShell member access is case-insensitive, so callers and tests can
    # still write $result.WouldGrant.
    $result = {
        param([bool]$Halted, [string]$HaltReason)
        [pscustomobject]@{
            runId      = $runId
            mode       = [string]$config.Mode
            examined   = $tally.Examined
            wouldGrant = $tally.WouldGrant
            granted    = $tally.Granted
            queued     = $tally.Queued
            failed     = $tally.Failed
            stopped    = $tally.Stopped
            halted     = $Halted
            haltReason = $HaltReason
            entries    = @($entries)
            ranAt      = $Context.Now.ToString('o')
        }
    }

    if (-not $config.Enabled) {
        $haltReason = 'AZURESENTRY_POLLER_ENABLED is not true.'
        if ($config.EnabledSource -eq 'override') {
            $haltReason += ' (source: poller.enabled override file, not the env var)'
        }
        return & $result $true $haltReason
    }
    # -LiteralPath: a plain Test-Path treats '[' / ']' in the path as wildcard syntax, so a
    # sentinel at a path containing either character would silently never match -- failing
    # OPEN on a halt check, which is exactly backwards for a kill switch.
    if ($config.StopFilePath -and (Test-Path -LiteralPath $config.StopFilePath)) {
        return & $result $true "Stop sentinel present at $($config.StopFilePath)."
    }

    $candidates = @()
    try {
        $candidates = @(& $Context.FetchTickets)
    }
    catch {
        # A throwing dependency must not take the whole cycle down with no result object
        # -- see Invoke-TicketPollerCycle.OUTPUTS. There is no ticket to blame this on yet,
        # so this is a halt (examined stays 0), not a per-ticket Failed entry.
        return & $result $true "FetchTickets threw: $($_.Exception.Message)"
    }

    $haltedMidCycle = $false
    $haltReasonMidCycle = ''

    foreach ($me in $candidates) {
        if ($tally.Examined -ge [int]$config.MaxTicketsPerCycle) { break }
        if ($tally.Stopped) { break }
        # Re-checked every iteration, not just once before the loop: a sentinel dropped
        # while an enforce cycle is already mid-run must stop the NEXT ticket, not wait
        # for the cycle to finish on its own. A stale $config.StopFilePath check taken
        # only once before the loop cannot see a file that appears during the run.
        if ($config.StopFilePath -and (Test-Path -LiteralPath $config.StopFilePath)) {
            $tally.Stopped = $true
            $haltedMidCycle = $true
            $haltReasonMidCycle = "Stop sentinel present at $($config.StopFilePath)."
            break
        }

        $id = [string]$me.id
        if (& $Context.IsProcessed $id) { continue }
        if (-not (Test-PollerTicketInWindow -MeTicket $me -MaxAgeDays $config.MaxTicketAgeDays -Now $Context.Now)) { continue }

        $tally.Examined++

        # FetchTickets aside, everything that decides this ticket (IsTemplateAllowed,
        # GetAccessFields, Resolve-MeTicketMapping, Decide, Test-PollerAutoEligible) is
        # wrapped together: a throw anywhere in here must count the ticket as Failed and
        # stop the cycle rather than unwinding past this function with no result object at
        # all -- safe with respect to granting (nothing here writes), but a bare unwind
        # contradicts the stated fail-closed intent.
        $templateAllowed = $false
        $accessFields = $null
        $mapping = $null
        $decision = $null
        $gate = $null
        $promo = $null
        $detailFetchError = $null
        try {
            $templateAllowed = [bool](& $Context.IsTemplateAllowed $me)

            # ManageEngine's LIST endpoint (what FetchTickets calls) returns udf_fields
            # EMPTY even when udf_fields is explicitly named in fields_required -- only
            # the DETAIL endpoint (GET /api/v3/requests/{id}) actually populates them.
            # Verified against live ManageEngine: the same ticket via LIST reported 0
            # populated udf keys; via DETAIL, 7. Reading udf_fields off the list ticket
            # (as an earlier version of this code did) makes every ticket look like it
            # has no Subscription/Role/Environment set, which silently and permanently
            # queues everything -- wouldGrant stuck at 0 forever. Do NOT "optimize" this
            # back to reading $me.udf_fields directly; that is exactly this bug.
            #
            # Fetched only here -- after the ticket has already survived the cheap
            # processed-store check, the age window (both above), and the template gate
            # (just above) -- never for all ~100 tickets FetchTickets returns each cycle.
            # A ticket whose template is not an azure-subscription-grant template can
            # never produce a decision regardless of its field values, so there is
            # nothing to gain fetching its detail; skipping it saves a real HTTP
            # round-trip against a production ITSM system for every such ticket.
            $meForFields = $me
            if ($templateAllowed -and $Context.ContainsKey('FetchTicketDetail') -and $Context.FetchTicketDetail) {
                try {
                    $detail = & $Context.FetchTicketDetail $id
                    if ($null -ne $detail) { $meForFields = $detail }
                }
                catch {
                    # A detail fetch failing for ONE ticket must not take the whole cycle
                    # down (that is what the outer catch below does -- Failed + Stopped).
                    # Routed instead into the ordinary "cannot map" / Queued path with a
                    # reason an operator can act on, so one flaky ME response does not
                    # halt every ticket behind it in this cycle.
                    $detailFetchError = $_.Exception.Message
                }
            }

            # I1: use the duration the entry script derived from config.azure.defaultDurationHours
            # (mirroring the dashboard's human path) when supplied; Resolve-MeTicketMapping's
            # own default of 7 only survives for callers (existing tests) that wire no
            # DurationDays into the context at all.
            $mappingDurationDays = if ($Context.ContainsKey('DurationDays') -and $Context.DurationDays) {
                [int]$Context.DurationDays
            } else { 7 }

            if ($detailFetchError) {
                $mapping = [pscustomobject]@{
                    Complete = $false
                    Warnings = @("Could not fetch ManageEngine ticket detail: $detailFetchError")
                    Ticket   = $null
                }
            }
            else {
                $accessFields = & $Context.GetAccessFields $meForFields
                $mapping = Resolve-MeTicketMapping -AccessFields $accessFields -MeTicket $meForFields -AllowlistDetails $Context.AllowlistDetails -DurationDays $mappingDurationDays
            }

            # Only ask the decision engine about tickets that mapped cleanly. An incomplete
            # mapping has no trustworthy role/subscription to decide on.
            if ($mapping.Complete -and $templateAllowed) {
                $decision = & $Context.Decide $mapping.Ticket
            }

            if ($null -ne $decision) {
                $gate = Test-PollerAutoEligible -Decision $decision -Mapping $mapping -TemplateAllowed $templateAllowed
            }

            # Mirrors the same Sandbox -> NonProd -> Production ladder the dashboard
            # enforces on its human grant path (Test-AccessPromotionLadder). The
            # unattended path must never be MORE permissive than the human one -- without
            # this, a requester who has never held Sandbox access could get NonProd
            # granted unattended while the identical ticket clicked through the dashboard
            # is refused. Only evaluated once the gate has already said this ticket would
            # otherwise be granted, so a ticket that is Queued for some other reason does
            # not also pay for a store read. CheckPromotionLadder is optional so existing
            # callers that never wire one (no ladder concept) are unaffected.
            if ($gate -and $gate.Eligible -and $Context.ContainsKey('CheckPromotionLadder') -and $Context.CheckPromotionLadder) {
                $promo = & $Context.CheckPromotionLadder $mapping.Ticket $decision
            }
        }
        catch {
            $tally.Failed++
            $tally.Stopped = $true
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Failed'; reason = "Unhandled error deciding this ticket: $($_.Exception.Message)"
                    action = $null; effectiveEnvironment = $null; applied = $false
                })
            break
        }

        if ($null -eq $decision) {
            $reason = if (-not $templateAllowed) {
                'ManageEngine template is not an azure-subscription-grant template.'
            } else {
                "Structured ME fields are incomplete: $((@($mapping.Warnings)) -join ' ')"
            }
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'; reason = $reason
                    action = $null; effectiveEnvironment = $null; applied = $false
                })
            continue
        }

        if (-not $gate.Eligible) {
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'; reason = $gate.Reason
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                })
            continue
        }

        # A ladder refusal queues the ticket for a human rather than granting -- the
        # unattended path must fail no less strictly than the dashboard's own promotion
        # check on the identical ticket.
        if ($promo -and -not $promo.Ok) {
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'; reason = $promo.Reason
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                })
            continue
        }

        # Compare against Granted + WouldGrant, not Granted alone: shadow mode never
        # increments Granted, so a Granted-only check lets shadow's preview
        # (wouldGrant) blow straight past the cap while enforce would have stopped
        # granting at it. That mismatch defeats the point of shadow mode -- an operator
        # reviewing a shadow run must see the same blast radius enforce would produce.
        if (($tally.Granted + $tally.WouldGrant) -ge [int]$config.MaxGrantsPerCycle) {
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'
                    reason = "Per-cycle grant cap of $($config.MaxGrantsPerCycle) reached; deferred to the next cycle."
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                })
            continue
        }

        if ($config.Mode -ne 'enforce') {
            $tally.WouldGrant++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'WouldGrant'; reason = $gate.Reason
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    role = [string]$mapping.Ticket.Role
                    subscriptionId = [string]$mapping.Ticket.SubscriptionId
                    requesterUpn = [string]$mapping.Ticket.RequesterUpn
                    applied = $false
                })
            continue
        }

        # --- enforce: the only branch that writes ---
        $errorText = $null
        $exec = $null
        try { $exec = & $Context.ExecuteGrant $mapping.Ticket }
        catch { $errorText = $_.Exception.Message }

        $ok = ($null -ne $exec) -and [bool]$exec.ok
        # A duplicate (final-review C1: an existing group-derived assignment invisible
        # to the direct Azure duplicate check) is not a system error -- it is caught on
        # purpose. It must never report Granted, but it must also not stop the cycle:
        # halting later tickets over an access that already exists would defeat the
        # point of catching it.
        $isDuplicate = ($null -ne $exec) -and [bool]$exec.duplicate
        if (-not $ok -and -not $isDuplicate -and -not $errorText) {
            $errorText = if ($exec -and $exec.error) { [string]$exec.error } else { 'Grant reported failure without a reason.' }
        }

        if ($ok) {
            $tally.Granted++
            & $Context.RecordProcessed $id ([pscustomobject]@{
                    ticketId = $id; action = [string]$decision.Action
                    role = [string]$mapping.Ticket.Role
                    subscriptionId = [string]$mapping.Ticket.SubscriptionId
                    requesterUpn = [string]$mapping.Ticket.RequesterUpn
                    assignmentId = [string]$exec.assignmentId
                    runId = $runId; actor = 'poller'
                    processedAt = $Context.Now.ToString('o')
                })

            # Requester-visible ManageEngine write-back: post the success note, then
            # resolve. Both hooks are optional -- existing callers/tests that wire
            # neither behave exactly as before this feature (notePosted/ticketResolved
            # simply stay false). A resolve failure is deliberately NON-FATAL: the Azure
            # grant already happened above (RecordProcessed already committed the claim),
            # so resolution is bookkeeping only -- it must not fail the cycle, must not
            # trigger a re-grant, and must not release the claim. Recorded on the entry
            # and the cycle carries on to the next ticket.
            $notePosted = $false
            $noteError = ''
            if ($Context.ContainsKey('PostTicketNote') -and $Context.PostTicketNote) {
                try {
                    $noteResult = & $Context.PostTicketNote $id $mapping.Ticket $decision (@{
                            Success        = $true
                            AssignmentId   = [string]$exec.assignmentId
                            AssignmentType = if ([string]$exec.fulfilment -eq 'PimFallback') { 'Active' } else { 'GroupMembership' }
                        })
                    $notePosted = [bool]($noteResult -and -not $noteResult.error)
                    if ($noteResult -and $noteResult.error) { $noteError = [string]$noteResult.error }
                }
                catch { $noteError = $_.Exception.Message }
            }

            $ticketResolved = $false
            $resolveError = ''
            if ($Context.ContainsKey('ResolveTicket') -and $Context.ResolveTicket) {
                try {
                    $resolveResult = & $Context.ResolveTicket $id
                    $ticketResolved = [bool]($resolveResult -and $resolveResult.success)
                    if ($resolveResult -and $resolveResult.error) { $resolveError = [string]$resolveResult.error }
                }
                catch {
                    # Non-fatal by design -- see the block comment above.
                    $resolveError = $_.Exception.Message
                }
            }

            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Granted'; reason = $gate.Reason
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    role = [string]$mapping.Ticket.Role
                    subscriptionId = [string]$mapping.Ticket.SubscriptionId
                    requesterUpn = [string]$mapping.Ticket.RequesterUpn
                    assignmentId = [string]$exec.assignmentId
                    # Carried onto the entry (not just written to the processed-ticket
                    # store) so the UnattendedGrant audit event built from this entry
                    # (Invoke-TicketPollerCycle.ps1) records the expiry AND which kind it
                    # is -- an auditor must be able to tell Azure-enforced (PimFallback)
                    # from tracked-only (Group) from the audit record alone.
                    fulfilment = [string]$exec.fulfilment
                    expiresAt = [string]$exec.expiresAt
                    applied = $true
                    notePosted = $notePosted
                    noteError = $noteError
                    ticketResolved = $ticketResolved
                    resolveError = $resolveError
                })
        }
        elseif ($isDuplicate) {
            $tally.Queued++
            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Queued'; reason = [string]$exec.error
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                })
        }
        else {
            # Fail closed: stop the cycle rather than walking into the next ticket with an
            # unexplained failure behind us.
            $tally.Failed++
            $tally.Stopped = $true

            # Requester-visible failure note (Get-ManageEngineNoteKind's Failed branch):
            # what was requested, that automated provisioning did not complete, and that
            # a human will verify. Deliberately never resolves on a failure -- the ticket
            # must stay open for a human, and the note must not imply access was granted.
            $notePosted = $false
            $noteError = ''
            if ($Context.ContainsKey('PostTicketNote') -and $Context.PostTicketNote) {
                try {
                    $noteResult = & $Context.PostTicketNote $id $mapping.Ticket $decision (@{
                            Success = $false
                            Error   = $errorText
                        })
                    $notePosted = [bool]($noteResult -and -not $noteResult.error)
                    if ($noteResult -and $noteResult.error) { $noteError = [string]$noteResult.error }
                }
                catch { $noteError = $_.Exception.Message }
            }

            $entries.Add([pscustomobject]@{
                    ticketId = $id; outcome = 'Failed'; reason = $errorText
                    action = [string]$decision.Action
                    effectiveEnvironment = [string]$decision.EffectiveEnvironment
                    applied = $false
                    notePosted = $notePosted
                    noteError = $noteError
                    ticketResolved = $false
                })
        }
    }

    if ($haltedMidCycle) {
        return & $result $true $haltReasonMidCycle
    }
    return & $result $false ''
}
