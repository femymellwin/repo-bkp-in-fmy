﻿<#
.SYNOPSIS
    FR3 / §2 — the agent runtime. Turns every platform action into a discrete,
    named, independently-invocable agent run with its own run id and audit trail.

.DESCRIPTION
    The review's central requirement: AzureSentry must be agent-driven, not a UI
    wrapper over the Azure CLI. This runtime is what makes "agent" a real thing
    rather than a label:

      * A registry of discrete agents, each with one job, its own runtime kind
        (deterministic API calls, an LLM step, or hybrid), and its own least-privilege
        surface (§NFR4).
      * Invoke-Agent wraps every action so it emits Started + terminal audit events,
        carries a RunId that correlates all of its work, records duration, and never
        silently swallows a failure.
      * Answer to the open question in §5: agents are BOTH deterministic API callers
        and LLM steps. Kind='Deterministic' agents only call APIs; Kind='Llm' agents
        only reason over text; Kind='Hybrid' agents use an LLM step to decide and a
        deterministic step to act — and the audit record shows which part did what.

    Dot-source this file. It expects Write-AuditEvent (dashboard/api/AuditLog.ps1)
    to be available; if it is not, runs still execute and are reported, just not
    persisted — the runtime must never be the reason a grant fails.
#>

# ---------------------------------------------------------------------------
# Agent registry
# ---------------------------------------------------------------------------

$script:AgentRegistry = [ordered]@{

    'TicketIngestionAgent'      = [pscustomobject]@{
        Name         = 'TicketIngestionAgent'
        DisplayName  = 'Ticket Ingestion Agent'
        Kind         = 'Deterministic'
        Purpose      = 'Reads ManageEngine help-desk tickets and normalizes them into the platform ticket schema.'
        Writes       = $false
        Systems      = @('ManageEngine ServiceDesk Plus (REST)')
        Permissions  = @('ME technician API key — read requests')
    }

    'SummarizationAgent'        = [pscustomobject]@{
        Name         = 'SummarizationAgent'
        DisplayName  = 'LLM Summarization Agent'
        Kind         = 'Llm'
        Purpose      = 'Reads ticket highlights and produces a business-facing access-request summary for operators.'
        Writes       = $false
        Systems      = @('Core42 / Azure OpenAI (chat completions)')
        Permissions  = @('LLM API key only — no Azure or ME write scope')
    }

    'DecisionAgent'             = [pscustomobject]@{
        Name         = 'DecisionAgent'
        DisplayName  = 'Access Decision Agent'
        Kind         = 'Deterministic'
        Purpose      = 'Runs the 7-step validation tree (schema, allowlist, eligibility, sensitivity, promotion ladder, duplicate, approval) and returns Grant / Eligible / Reject / Hold / BreakGlass.'
        Writes       = $false
        Systems      = @('RbacDecision module', 'eligibility-matrix.json', 'subscription-sensitivity.json', 'approver-mapping.json')
        Permissions  = @('none — pure evaluation')
    }

    'AccessProvisioningAgent'   = [pscustomobject]@{
        Name         = 'AccessProvisioningAgent'
        DisplayName  = 'Access Provisioning Agent'
        Kind         = 'Deterministic'
        Purpose      = 'Grants and revokes Azure access by calling ARM RBAC / PIM and Microsoft Graph group APIs directly. No CLI shell-out.'
        Writes       = $true
        Systems      = @('ARM roleAssignments / roleEligibilityScheduleRequests / roleAssignmentScheduleRequests', 'Microsoft Graph groups + members')
        Permissions  = @('User Access Administrator scoped to the managed subscriptions (PIM-eligible where available)', 'Graph Group.ReadWrite.All (application)')
    }

    'SubscriptionResolverAgent' = [pscustomobject]@{
        Name         = 'SubscriptionResolverAgent'
        DisplayName  = 'Subscription Resolver Agent'
        Kind         = 'Deterministic'
        Purpose      = 'Resolves a ticket''s subscription reference to exactly one subscription: exact match, then environment filter, then hand to a human. Never silently expands to every match.'
        Writes       = $false
        Systems      = @('ARM subscriptions / management group descendants')
        Permissions  = @('Reader on the management group')
    }

    # SentryGovernanceAgent (Environment tag infer/backfill/rollback) was removed:
    # Environment is now a mandatory dropdown field on every structured template, so
    # there is no backlog left to infer or backfill. Its four deterministic helper
    # functions survive in dashboard/api/EnvironmentResolution.ps1, but as shared
    # read-only helpers with no write, no LLM step and no audit-worthy action of
    # their own -- not a registry-worthy agent. See that file's header.

    'TicketCategorizationAgent' = [pscustomobject]@{
        Name         = 'TicketCategorizationAgent'
        DisplayName  = 'Ticket Categorization Agent'
        Kind         = 'Hybrid'
        Purpose      = 'Classifies tickets by agent-actionable work type (app registration, client secret, access grant, ...) so department scope expansion is measured, not guessed.'
        Writes       = $false
        Systems      = @('ManageEngine (read)', 'Core42 / Azure OpenAI for classification')
        Permissions  = @('ME technician API key — read requests')
    }

    'TicketPollerAgent'         = [pscustomobject]@{
        Name         = 'TicketPollerAgent'
        DisplayName  = 'Unattended Ticket Poller Agent'
        Kind         = 'Deterministic'
        Purpose      = 'Runs one unattended poll cycle every 5 minutes (systemd timer): selects ManageEngine Azure Subscription tickets, decides via the same RbacDecision engine as the human path, and -- only for sandbox-reader / sandbox-contributor / nonprod-reader, with no human click -- grants. Everything else queues for a human. The only agent that writes with no human in the loop; ships inert (AZURESENTRY_POLLER_ENABLED, AZURESENTRY_POLLER_MODE) and never more permissive than the dashboard''s human grant path.'
        Writes       = $true
        Systems      = @('ManageEngine ServiceDesk Plus (REST, read)', 'Microsoft Graph groups + members', 'ARM roleAssignments / roleEligibilityScheduleRequests (PIM fallback)')
        Permissions  = @('ME technician API key -- read requests only', 'Graph Group.ReadWrite.All (application), scoped to sandbox/nonprod RBAC groups', 'User Access Administrator on the managed subscriptions, PIM-fallback route only', 'Excludes Production and the Eligible/BreakGlass actions entirely -- see src/Agents/PollerGate.ps1')
    }

    'GrantReaperAgent'         = [pscustomobject]@{
        Name         = 'GrantReaperAgent'
        DisplayName  = 'Grant Expiry Reaper Agent'
        Kind         = 'Deterministic'
        Purpose      = 'Runs on a systemd timer: scans the processed-ticket store for grants whose RECORDED expiry has passed and revokes them -- Entra group membership removal for Group fulfilment (a TRACKED expiry this platform enforces itself, since Entra has no native group-membership timer), PIM assignment removal for the PimFallback route (which Azure also enforces on its own). Makes every unattended poller grant self-healing rather than permanent. Only ever revokes a record this platform itself granted and recorded (Test-GrantRevocable), and never an already-revoked one. Ships inert (AZURESENTRY_REAPER_ENABLED, AZURESENTRY_REAPER_MODE) and defaults to shadow -- see src/Agents/ReaperAgent.ps1.'
        Writes       = $true
        Systems      = @('Microsoft Graph groups + members', 'ARM roleAssignments / roleEligibilityScheduleRequests (PIM fallback revoke)')
        Permissions  = @('Graph Group.ReadWrite.All (application), scoped to sandbox/nonprod RBAC groups', 'User Access Administrator on the managed subscriptions, PIM-fallback revoke route only', 'No ManageEngine access -- operates entirely on the local processed-ticket store')
    }
}

function Get-AgentRegistry {
    <#
    .SYNOPSIS
      Returns every registered agent. Used by the dashboard to show what the
      platform actually consists of, and by docs/LLD.md generation.
    #>
    return @($script:AgentRegistry.Values)
}

function Get-AgentDefinition {
    param([Parameter(Mandatory)][string]$Name)
    if (-not $script:AgentRegistry.Contains($Name)) {
        throw "Unknown agent '$Name'. Registered: $(($script:AgentRegistry.Keys) -join ', ')"
    }
    return $script:AgentRegistry[$Name]
}

function New-AgentRunId {
    param([string]$Agent = 'agent')
    $short = ($Agent -replace '[^A-Za-z]', '')
    if ($short.Length -gt 6) { $short = $short.Substring(0, 6) }
    return "$($short.ToLowerInvariant())-$((Get-Date).ToUniversalTime().ToString('yyyyMMddHHmmss'))-$([guid]::NewGuid().ToString('N').Substring(0, 6))"
}

# ---------------------------------------------------------------------------
# Invocation
# ---------------------------------------------------------------------------

function Invoke-Agent {
    <#
    .SYNOPSIS
      Runs one agent action as a discrete, audited agent run.

    .DESCRIPTION
      Emits a 'Started' audit event, runs the body, then emits a terminal event
      (Success / Failed / Blocked / DryRun) carrying before/after state. The body
      receives a $Run context hashtable it can enrich:

        $Run.RunId          correlate everything this run did
        $Run.Before         state snapshot before the change (set it)
        $Run.After          state snapshot after the change (set it)
        $Run.Outcome        override the terminal outcome, e.g. 'Blocked' / 'DryRun'
        $Run.Reason         human-readable why
        $Run.Detail         hashtable of structured extras

      A throwing body is recorded as Failed and re-thrown, so callers keep their
      existing error handling. Audit failure never masks the agent result.

    .OUTPUTS
      pscustomobject with RunId, Agent, Action, Outcome, DurationMs, Result, Error.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Action,
        [Parameter(Mandatory)][scriptblock]$Body,
        [string]$Actor = 'system',
        [string]$TicketId,
        [string]$CorrelationId,
        [hashtable]$Target,
        [hashtable]$Detail,
        # Suppress the 'Started' event for high-frequency read-only agents.
        [switch]$NoStartEvent,
        # Do not rethrow; return the failure in .Error instead.
        [switch]$SwallowErrors
    )

    $def = Get-AgentDefinition -Name $Name
    $runId = New-AgentRunId -Agent $Name
    $correlation = if ($CorrelationId) { $CorrelationId } else { $runId }

    $run = @{
        RunId         = $runId
        Agent         = $Name
        Action        = $Action
        Actor         = $Actor
        TicketId      = $TicketId
        CorrelationId = $correlation
        Target        = $Target
        Before        = $null
        After         = $null
        Outcome       = $null
        Reason        = $null
        Detail        = if ($Detail) { $Detail.Clone() } else { @{} }
    }
    $run.Detail['agentKind'] = $def.Kind

    $canAudit = [bool](Get-Command -Name Write-AuditEvent -ErrorAction SilentlyContinue)

    if ($canAudit -and -not $NoStartEvent) {
        Write-AuditEvent -Agent $Name -Action $Action -Actor $Actor -RunId $runId `
            -CorrelationId $correlation -TicketId $TicketId -Target $Target `
            -Outcome 'Started' -Detail $run.Detail -IsWrite:$false | Out-Null
    }

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $result = $null
    $errorMessage = $null
    $outcome = 'Success'

    try {
        $result = & $Body $run
        if ($run.Outcome) { $outcome = $run.Outcome }
    }
    catch {
        $outcome = 'Failed'
        $errorMessage = $_.Exception.Message
        if (-not $run.Reason) { $run.Reason = $errorMessage }
    }
    finally {
        $sw.Stop()
    }

    $run.Detail['durationMs'] = [int]$sw.ElapsedMilliseconds
    if ($errorMessage) { $run.Detail['error'] = $errorMessage }

    if ($canAudit) {
        # A DryRun never counts as a write, even for a write-capable agent.
        $isWrite = $def.Writes -and $outcome -eq 'Success'
        Write-AuditEvent -Agent $Name -Action $Action -Actor $Actor -RunId $runId `
            -CorrelationId $correlation -TicketId $TicketId -Target $run.Target `
            -Before $run.Before -After $run.After -Outcome $outcome `
            -Reason $run.Reason -Detail $run.Detail -IsWrite $isWrite | Out-Null
    }

    $envelope = [pscustomobject]@{
        RunId         = $runId
        Agent         = $Name
        AgentKind     = $def.Kind
        Action        = $Action
        Actor         = $Actor
        TicketId      = $TicketId
        CorrelationId = $correlation
        Outcome       = $outcome
        Reason        = $run.Reason
        DurationMs    = [int]$sw.ElapsedMilliseconds
        Result        = $result
        Error         = $errorMessage
    }

    if ($errorMessage -and -not $SwallowErrors) { throw $errorMessage }
    return $envelope
}
