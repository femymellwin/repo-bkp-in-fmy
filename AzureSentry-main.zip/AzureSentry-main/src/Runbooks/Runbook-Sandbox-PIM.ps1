<#
.SYNOPSIS
    Sandbox full-auto PIM path — active assignment via GraphPimClient (scope §4.1).
.DESCRIPTION
    Production default: GraphPimClient. Set $env:AZURESENTRY_PIM_CLIENT=Mock for offline tests.
    Secrets (ManageEngine token) from Key Vault via MI — never hardcoded.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [hashtable]$Ticket,

    [Parameter(Mandatory)]
    [string[]]$SubscriptionAllowlist,

    [string]$PimClientImplementation = $(if ($env:AZURESENTRY_PIM_CLIENT) { $env:AZURESENTRY_PIM_CLIENT } else { 'Graph' })
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

if ($PimClientImplementation -eq 'Mock') {
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
    $pimClient = New-MockPimClient
}
else {
    Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
    $pimClient = New-GraphPimClient -TenantId $env:AZURE_TENANT_ID
}
. (Join-Path $repoRoot 'src\PimClient\GroupRbac.ps1')

# Roles routed to governance review (e.g. Custom) intentionally have no assignable
# role definition id. Resolve via the catalog-aware helper (returns $null rather than
# throwing) so the decision engine can return its Hold/Reject instead of this runbook
# throwing before the decision is even made.
$roleDefId = Get-AssignableRoleDefinitionId -RoleName $Ticket.Role

$userId = Resolve-UpnToObjectId -Client $pimClient -Upn $Ticket.RequesterUpn

# No assignable role id means no PIM assignment can exist, so there is no duplicate.
$hasDuplicate = $false
if ($roleDefId) {
    $existing = Get-ActiveAssignments -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId -Scope $Ticket.ResourceScope
    $hasDuplicate = $existing.Count -gt 0
}

$decision = Resolve-RbacDecision -Ticket $Ticket -SubscriptionAllowlist $SubscriptionAllowlist -HasExistingAssignment:$hasDuplicate

if ($decision.Action -ne 'Grant') {
    return [PSCustomObject]@{
        Success  = $false
        Decision = $decision
        Message  = $decision.Reason
    }
}

if (-not $roleDefId) {
    throw "Role '$($Ticket.Role)' has no assignable Azure role definition id; it cannot be fulfilled by this runbook."
}

# Group-based fulfilment only makes sense for subscription-scoped roles: the RBAC groups
# hold a role at subscription scope. Resource-scoped roles (Storage data plane, AKS RBAC)
# take a direct time-bound PIM assignment at the resource itself instead.
$roleEntry = Get-RoleCatalogEntry -RoleName $Ticket.Role
if (-not $roleEntry) {
    throw "Granted role '$($Ticket.Role)' is not present in role-catalog.json."
}
$useGroupPath = ($roleEntry.scopeType -eq 'subscription')

$subId = if ($Ticket.SubscriptionId) {
    $Ticket.SubscriptionId
}
elseif ($Ticket.ResourceScope -match '^/subscriptions/([^/]+)') {
    $Matches[1]
}
else {
    $null
}

$grant = if ($useGroupPath) {
    Invoke-GroupOrPimGrant -Client $pimClient -UserId $userId -RoleName $Ticket.Role `
        -SubscriptionId $subId -SubscriptionName $Ticket.SubscriptionName `
        -ResourceScope $Ticket.ResourceScope -DurationDays ([int]$Ticket.DurationDays) `
        -Justification ([string]$Ticket.Justification)
}
else {
    $assignment = New-ActiveAssignment -Client $pimClient -UserId $userId `
        -RoleDefinitionId $roleDefId -Scope $Ticket.ResourceScope `
        -DurationDays ([int]$Ticket.DurationDays) `
        -Justification ([string]$Ticket.Justification)

    [pscustomobject]@{
        Success                = $true
        Fulfilment             = 'DirectPim'
        GroupId                = $null
        GroupName              = $null
        GroupCreated           = $false
        RoleAssignmentCreated  = $false
        AssignmentId           = $assignment.id
        EngineerActionRequired = $false
        EngineerActionReason   = $null
        Message                = "Granted $($Ticket.Role) at $($Ticket.ResourceScope) via direct PIM assignment (resource-scoped role)."
    }
}

return [PSCustomObject]@{
    Success                = $grant.Success
    Decision               = $decision
    Fulfilment             = $grant.Fulfilment
    AssignmentType         = if ($grant.Fulfilment -eq 'Group') { 'GroupMembership' } else { 'Active' }
    GroupId                = $grant.GroupId
    GroupName              = $grant.GroupName
    GroupCreated           = $grant.GroupCreated
    RoleAssignmentCreated  = $grant.RoleAssignmentCreated
    AssignmentId           = $grant.AssignmentId
    UserId                 = $userId
    Role                   = $Ticket.Role
    Scope                  = $Ticket.ResourceScope
    EngineerActionRequired = $grant.EngineerActionRequired
    EngineerActionReason   = $grant.EngineerActionReason
    ExpiresAt              = if ($grant.Fulfilment -in @('PimFallback', 'DirectPim')) {
        (Get-Date).AddDays([int]$Ticket.DurationDays).ToUniversalTime()
    }
    else {
        $null
    }
    PimClient              = $PimClientImplementation
    Message                = $grant.Message
}
