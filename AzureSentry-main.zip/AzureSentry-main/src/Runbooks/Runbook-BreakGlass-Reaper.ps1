<#
.SYNOPSIS
    G3 break-glass reaper - scheduled sweep that revokes expired break-glass grants (scope Sec. 5.4).
.DESCRIPTION
    Break-glass auto-grants (Emergency Access, P1 Contributor) create an Active PIM
    assignment immediately and bypass the standard approval gate. Per scope Sec. 5.4 they
    carry a mandatory post-hoc async review that must be completed by Cloud Governance
    within 4 hours; failure to complete that review within the window triggers automatic
    revocation of the grant.

    This G3 scheduled runbook performs that enforcement. For each tracked break-glass
    grant it computes the review deadline (GrantedAt + ReviewHours, default 4h). Any grant
    whose deadline has elapsed relative to $Now is revoked via Remove-PimAssignment and
    recorded as reaped. Reaped grants that were never reviewed are additionally flagged as
    review breaches for the security/governance report. Grants still inside their review
    window are kept untouched.

    Production default: GraphPimClient. Set $env:AZURESENTRY_PIM_CLIENT=Mock for offline tests.
    Authoring only - no az calls, no deployment, no cost.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [AllowNull()]
    [AllowEmptyCollection()]
    [object[]]$TrackedGrants,

    [string]$PimClientImplementation = $(if ($env:AZURESENTRY_PIM_CLIENT) { $env:AZURESENTRY_PIM_CLIENT } else { 'Graph' }),

    [datetime]$Now = ([datetime]::UtcNow)
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

if ($PimClientImplementation -eq 'Mock') {
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
    $client = New-MockPimClient
}
else {
    Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
    $client = New-GraphPimClient -TenantId $env:AZURE_TENANT_ID
}

# Defensive: treat empty/null input as nothing to sweep.
$grants = @()
if ($TrackedGrants) {
    $grants = @($TrackedGrants)
}

$reaped = @()
$breaches = @()
$kept = @()

foreach ($g in $grants) {
    if (-not $g) { continue }

    # ReviewHours defaults to 4 when missing or zero (scope Sec. 5.4).
    $reviewHours = 4
    if ($g.ReviewHours) {
        $rh = [int]$g.ReviewHours
        if ($rh -gt 0) { $reviewHours = $rh }
    }

    $reviewed = $false
    if ($g.Reviewed) { $reviewed = [bool]$g.Reviewed }

    # Normalize GrantedAt to UTC robustly. A timezone-naive string (DateTimeKind
    # Unspecified) must be treated as UTC, not host-local, or the review deadline
    # would skew by the host's UTC offset (Sec. 5.4 enforcement is time-sensitive).
    $ga = $g.GrantedAt
    if ($ga -is [datetime]) {
        if ($ga.Kind -eq [System.DateTimeKind]::Unspecified) {
            $gaUtc = [datetime]::SpecifyKind($ga, [System.DateTimeKind]::Utc)
        }
        else {
            $gaUtc = $ga.ToUniversalTime()
        }
    }
    else {
        $gaUtc = [datetime]::Parse([string]$ga, [cultureinfo]::InvariantCulture,
            ([System.Globalization.DateTimeStyles]::AssumeUniversal -bor [System.Globalization.DateTimeStyles]::AdjustToUniversal))
    }

    $deadline = $gaUtc.AddHours($reviewHours)

    if ($Now -gt $deadline) {
        Remove-PimAssignment -Client $client -AssignmentId $g.AssignmentId -Scope $g.Scope | Out-Null

        $record = [PSCustomObject]@{
            AssignmentId     = $g.AssignmentId
            Scope            = $g.Scope
            PrincipalId      = $g.PrincipalId
            RoleDefinitionId = $g.RoleDefinitionId
            GrantedAt        = $gaUtc
            Deadline         = $deadline
            ReviewHours      = $reviewHours
            Reviewed         = $reviewed
        }
        $reaped += $record

        if (-not $reviewed) {
            $breaches += $record
        }
    }
    else {
        $kept += [PSCustomObject]@{
            AssignmentId     = $g.AssignmentId
            Scope            = $g.Scope
            PrincipalId      = $g.PrincipalId
            RoleDefinitionId = $g.RoleDefinitionId
            GrantedAt        = $gaUtc
            Deadline         = $deadline
            ReviewHours      = $reviewHours
            Reviewed         = $reviewed
        }
    }
}

[PSCustomObject]@{
    Examined        = $grants.Count
    Reaped          = @($reaped)
    ReviewBreaches  = @($breaches)
    Kept            = @($kept)
    PimClient       = $PimClientImplementation
    SweptAt         = $Now.ToUniversalTime()
}
