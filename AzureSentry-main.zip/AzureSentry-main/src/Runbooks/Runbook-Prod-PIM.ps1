<#
.SYNOPSIS
    Production approval path - creates an Eligible PIM assignment.
.DESCRIPTION
    Handles the Production-Standard, Production-Expedited, and Production-DualApproval
    paths (scope Sec. 2.2 eligibility matrix; Sec. 9 Approval Integrity / Dual Approval).
    All roles that reach this runbook (Reader, Contributor, Writer, Owner, User Access
    Administrator) receive a PIM eligible assignment; PIM's own native approval-and-
    activation flow is the approval mechanism (see final-review C2 — group fulfilment
    for Eligible roles is deferred as a follow-up, tracked separately from this interim).
    Group-first fulfilment is only used on the Grant path (Runbook-Sandbox-PIM).

    Production default: GraphPimClient. Set $env:AZURESENTRY_PIM_CLIENT=Mock for offline tests.
    Secrets (ManageEngine token) from Key Vault via MI - never hardcoded.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [hashtable]$Ticket,

    [Parameter(Mandatory)]
    [string[]]$SubscriptionAllowlist,

    [string]$PimClientImplementation = $(if ($env:AZURESENTRY_PIM_CLIENT) { $env:AZURESENTRY_PIM_CLIENT } else { 'Graph' })
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

if ($PimClientImplementation -eq 'Mock') {
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
    $pimClient = New-MockPimClient
}
else {
    Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
    $pimClient = New-GraphPimClient -TenantId $env:AZURE_TENANT_ID
}

# Roles routed to governance review (e.g. Custom) intentionally have no assignable
# role definition id. Resolve via the catalog-aware helper (returns $null rather than
# throwing) so the decision engine can return its Hold/Reject instead of this runbook
# throwing before the decision is even made.
$roleDefId = Get-AssignableRoleDefinitionId -RoleName $Ticket.Role

$userId = Resolve-UpnToObjectId -Client $pimClient -Upn $Ticket.RequesterUpn

# No assignable role id means no PIM assignment can exist, so there is no duplicate.
$hasDuplicate = $false
if ($roleDefId) {
    $existing = Get-ActiveAssignments -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId -Scope $Ticket.ResourceScope
    $hasDuplicate = $existing.Count -gt 0
}

$decision = Resolve-RbacDecision -Ticket $Ticket -SubscriptionAllowlist $SubscriptionAllowlist -HasExistingAssignment:$hasDuplicate

if ($decision.Action -ne 'Eligible') {
    return [PSCustomObject]@{
        Success  = $false
        Decision = $decision
        Message  = $decision.Reason
    }
}

if (-not $roleDefId) {
    throw "Role '$($Ticket.Role)' has no assignable Azure role definition id; it cannot be fulfilled by this runbook."
}

$request = New-EligibleAssignment -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId `
    -Scope $Ticket.ResourceScope -DurationDays ([int]$Ticket.DurationDays) `
    -Justification ([string]$Ticket.Justification)

[PSCustomObject]@{
    Success         = $true
    Decision        = $decision
    RequestId       = $request.id
    UserId          = $userId
    Role            = $Ticket.Role
    Scope           = $Ticket.ResourceScope
    AssignmentType  = 'Eligible'
    RequiresApproval = $true
    ApproverTier    = $decision.ApproverTier
    Approvers       = $decision.Approvers
    SlaHours        = $decision.SlaHours
    EscalateAt      = $decision.EscalateAt
    MfaRequired     = $decision.MfaRequired
    NotifyOnCall    = $decision.NotifyOnCall
    PimClient       = $PimClientImplementation
}
