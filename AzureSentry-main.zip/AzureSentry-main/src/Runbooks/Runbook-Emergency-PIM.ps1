<#
.SYNOPSIS
    Emergency break-glass PIM path - creates an ACTIVE assignment immediately and
    raises a security alert (scope Sec. 5.4 Emergency Break-Glass Flow; Deliverable #4).
.DESCRIPTION
    Implements the P1 Contributor break-glass flow (scope Sec. 5.4). Unlike the
    Production runbook (Eligible, pending approval) or the Sandbox runbook (Active
    full-auto), the Emergency runbook auto-grants an ACTIVE assignment without prior
    approval, then immediately raises a security alert and flags the grant for
    mandatory async review (Deliverable #4: security alert + async review flag).

    HARD CONSTRAINT - P1 Contributor ONLY:
    The decision tree (Get-EligibilityMatch / eligibility-matrix.json) only returns
    Action='BreakGlass' for Environment=Production, Role=Contributor, Priority=P1 with
    the BreakGlass flag set. Owner break-glass requests are REJECTED UPSTREAM by the
    decision tree (row emergency-owner-p1-reject, path Emergency-Escalate) and routed
    to an incident bridge - they never reach the New-ActiveAssignment call here. Any
    non-BreakGlass decision (e.g. a non-P1 contributor that falls through to the
    standard/expedited Eligible path) is failed closed below.

    The review window is propagated from the decision engine: the matrix row
    emergency-contributor-p1 carries reviewHours=4, surfaced as $decision.ReviewHours.
    Failure to complete async review within that window triggers automatic revocation
    downstream (scope Sec. 5.4; the reaper / Status Updater runbook).

    Production default: GraphPimClient. Set $env:AZURESENTRY_PIM_CLIENT=Mock for offline tests.
    Secrets (ManageEngine token) from Key Vault via MI - never hardcoded.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [hashtable]$Ticket,

    [Parameter(Mandatory)]
    [string[]]$SubscriptionAllowlist,

    [string]$PimClientImplementation = $(if ($env:AZURESENTRY_PIM_CLIENT) { $env:AZURESENTRY_PIM_CLIENT } else { 'Graph' })
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force

if ($PimClientImplementation -eq 'Mock') {
    Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
    $pimClient = New-MockPimClient
}
else {
    Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
    $pimClient = New-GraphPimClient -TenantId $env:AZURE_TENANT_ID
}

# Roles routed to governance review (e.g. Custom) intentionally have no assignable
# role definition id. Resolve via the catalog-aware helper (returns $null rather than
# throwing) so the decision engine can return its Hold/Reject instead of this runbook
# throwing before the decision is even made.
$roleDefId = Get-AssignableRoleDefinitionId -RoleName $Ticket.Role

$userId = Resolve-UpnToObjectId -Client $pimClient -Upn $Ticket.RequesterUpn

# No assignable role id means no PIM assignment can exist, so there is no duplicate.
$hasDuplicate = $false
if ($roleDefId) {
    $existing = Get-ActiveAssignments -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId -Scope $Ticket.ResourceScope
    $hasDuplicate = $existing.Count -gt 0
}

$decision = Resolve-RbacDecision -Ticket $Ticket -SubscriptionAllowlist $SubscriptionAllowlist -HasExistingAssignment:$hasDuplicate

# Fail closed: anything other than a break-glass decision is rejected here. Owner
# emergency requests are already rejected upstream (Emergency-Escalate / incident bridge).
if ($decision.Action -ne 'BreakGlass') {
    return [PSCustomObject]@{
        Success  = $false
        Decision = $decision
        Message  = $decision.Reason
    }
}

if (-not $roleDefId) {
    throw "Role '$($Ticket.Role)' has no assignable Azure role definition id; it cannot be fulfilled by this runbook."
}

# Break-glass auto-grant: ACTIVE assignment, no prior approval (scope Sec. 5.4).
$assignment = New-ActiveAssignment -Client $pimClient -UserId $userId -RoleDefinitionId $roleDefId `
    -Scope $Ticket.ResourceScope -DurationDays ([int]$Ticket.DurationDays) `
    -Justification ([string]$Ticket.Justification)

# Review window propagated from the decision engine (matrix reviewHours=4). Default
# to 4 hours if the decision did not carry an explicit value (scope Sec. 5.4).
$reviewHours = [int]$decision.ReviewHours
if ($reviewHours -le 0) { $reviewHours = 4 }
$reviewBy = (Get-Date).ToUniversalTime().AddHours($reviewHours)

[PSCustomObject]@{
    Success             = $true
    Decision            = $decision
    AssignmentId        = $assignment.id
    UserId              = $userId
    Role                = $Ticket.Role
    Scope               = $Ticket.ResourceScope
    AssignmentType      = 'Active'
    BreakGlass          = $true
    SecurityAlertRaised = $true
    AlertTargets        = @('Cloud Security Team', 'On-Call Manager')
    ReviewHours         = $reviewHours
    ReviewBy            = $reviewBy.ToString('o')
    PimClient           = $PimClientImplementation
}
