<#
.SYNOPSIS
    Entry-point runbook dispatched by the Logic App orchestrator (F1).
.DESCRIPTION
    Receives TicketJson from Logic App, runs the full 7-step decision tree, then
    dispatches to the appropriate specialised runbook. This keeps all business logic
    in PowerShell and the Logic App workflow thin (D1).

    In Azure Automation: dispatches child jobs via Start-AzAutomationRunbook.
    In local dev/test: invokes the runbook script directly (same-process).

    Set $env:AZURESENTRY_PIM_CLIENT=Mock to use MockPimClient (CI without P2).
    Set $env:AZURESENTRY_AA_NAME / _AA_RG / _SUBSCRIPTION_ID for child dispatch.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$TicketJson,

    [string]$SubscriptionAllowlist = $env:AZURESENTRY_SUBSCRIPTION_ALLOWLIST
)

$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------------
# Module import — repo-relative in local dev; uploaded in Automation
# ------------------------------------------------------------------
$isAutomation = $null -ne $env:AUTOMATION_RUNBOOK_NAME
if ($isAutomation) {
    Import-Module RbacDecision  -Force
    Import-Module GraphPimClient -Force -ErrorAction SilentlyContinue
    Import-Module MockPimClient  -Force -ErrorAction SilentlyContinue
}
else {
    $repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    Import-Module (Join-Path $repoRoot 'src\RbacDecision\RbacDecision.psd1') -Force
    $clientImpl = if ($env:AZURESENTRY_PIM_CLIENT) { $env:AZURESENTRY_PIM_CLIENT } else { 'Graph' }
    if ($clientImpl -eq 'Mock') {
        Import-Module (Join-Path $repoRoot 'src\PimClient\MockPimClient.psm1') -Force
    }
    else {
        Import-Module (Join-Path $repoRoot 'src\PimClient\GraphPimClient.psm1') -Force
    }
}

# ------------------------------------------------------------------
# Parse ticket
# ------------------------------------------------------------------
# ConvertFrom-Json -AsHashtable requires PS 6+; convert manually for PS 5.1 compatibility
$ticketObj = $TicketJson | ConvertFrom-Json
$ticket = @{}
$ticketObj.PSObject.Properties | ForEach-Object { $ticket[$_.Name] = $_.Value }

# Allowlist: parameter (comma-separated string) or env var
$allowlist = @()
if ($SubscriptionAllowlist) {
    $allowlist = @($SubscriptionAllowlist -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

# ------------------------------------------------------------------
# PIM client — dedup check before decision tree (step 7 input)
# ------------------------------------------------------------------
$clientImpl = if ($env:AZURESENTRY_PIM_CLIENT) { $env:AZURESENTRY_PIM_CLIENT } else { 'Graph' }
$pimClient  = if ($clientImpl -eq 'Mock') { New-MockPimClient } else { New-GraphPimClient -TenantId $env:AZURE_TENANT_ID }

# Roles routed to governance review (e.g. Custom) intentionally have no assignable
# role definition id. Resolve via the catalog-aware helper (returns $null rather than
# throwing) so the decision engine can return its Hold/Reject instead of this router
# throwing before the decision is even made.
$roleDefId     = Get-AssignableRoleDefinitionId -RoleName $ticket.Role
$userId        = Resolve-UpnToObjectId -Client $pimClient -Upn $ticket.RequesterUpn

# No assignable role id means no PIM assignment can exist, so there is no duplicate.
$hasDuplicate  = $false
if ($roleDefId) {
    $existing     = Get-ActiveAssignments -Client $pimClient -UserId $userId `
                        -RoleDefinitionId $roleDefId -Scope $ticket.ResourceScope
    $hasDuplicate = $existing.Count -gt 0
}

# ------------------------------------------------------------------
# Decision tree (pure — no I/O)
# ------------------------------------------------------------------
$decision = Resolve-RbacDecision `
    -Ticket $ticket `
    -SubscriptionAllowlist $allowlist `
    -HasExistingAssignment:$hasDuplicate

# Reject / Hold — return immediately, no PIM call
if ($decision.Action -in @('Reject', 'Hold')) {
    return [PSCustomObject]@{
        Dispatched = $false
        Decision   = $decision
        Message    = $decision.Reason
        TicketId   = $ticket.TicketId
    }
}

if (-not $decision.Runbook) {
    throw "Decision engine returned action '$($decision.Action)' with no target runbook (path: $($decision.Path))"
}

# Fail closed: an actionable decision (Eligible/Grant/BreakGlass) requires an
# assignable role definition id. A role with none (e.g. Custom) must never have
# reached this point, since such roles route to Reject/Hold above; this guards
# against a decision-engine defect that would otherwise dispatch an un-fulfillable grant.
if (-not $roleDefId) {
    throw "Role '$($ticket.Role)' has no assignable Azure role definition id; it cannot be dispatched for fulfilment."
}

# ------------------------------------------------------------------
# Dispatch to specialised runbook
# ------------------------------------------------------------------
$aaName = $env:AZURESENTRY_AA_NAME
$aaRg   = $env:AZURESENTRY_AA_RG
$subId  = $env:AZURESENTRY_SUBSCRIPTION_ID

if ($isAutomation -and $aaName -and $aaRg -and $subId) {
    # Azure Automation child job — async, fire-and-forget; Logic App polls status separately
    $childParams = @{
        TicketJson            = $TicketJson
        SubscriptionAllowlist = $SubscriptionAllowlist
    }
    $job = Start-AzAutomationRunbook `
        -AutomationAccountName $aaName `
        -ResourceGroupName     $aaRg `
        -Name                  $decision.Runbook `
        -Parameters            $childParams

    return [PSCustomObject]@{
        Dispatched = $true
        JobId      = $job.JobId
        Runbook    = $decision.Runbook
        Decision   = $decision
        TicketId   = $ticket.TicketId
    }
}

# Local dev / test — invoke the runbook script directly in-process
$runbookPath = Join-Path $PSScriptRoot "$($decision.Runbook).ps1"
if (-not (Test-Path $runbookPath)) {
    # Runbook not yet implemented (M5-M6) — return decision only
    return [PSCustomObject]@{
        Dispatched = $false
        Runbook    = $decision.Runbook
        Decision   = $decision
        Message    = "Runbook '$($decision.Runbook)' not yet implemented (pending M5-M6)"
        TicketId   = $ticket.TicketId
    }
}

$result = & $runbookPath `
    -Ticket               $ticket `
    -SubscriptionAllowlist $allowlist `
    -PimClientImplementation $clientImpl

return [PSCustomObject]@{
    Dispatched = $true
    Runbook    = $decision.Runbook
    Decision   = $decision
    Result     = $result
    TicketId   = $ticket.TicketId
}
