<#
.SYNOPSIS
    Closes the loop by updating the originating ManageEngine ticket status after a
    decision or grant (scope Sec. 8.1 Orchestrator step 10 / Sec. 8.2 step 6).
.DESCRIPTION
    This runbook is invoked by the Logic App orchestrator (not dispatched per-decision
    like the specialised PIM runbooks). After a decision is rendered or a PIM
    assignment is created/approved, the orchestrator calls this runbook with the
    ManageEngine ticket id and the new status (for example 'Resolved',
    'Pending Approval', 'Rejected') plus an optional human-readable note.

    SCOPE: PIM approval polling (GET roleEligibilityScheduleRequests, every 5 min) is
    performed by the Logic App orchestrator's recurrence trigger (scope Sec. 8.1); this
    runbook is the ManageEngine write-back half of that loop, kept standalone and
    idempotent so the orchestrator can call it on every status transition.

    The runbook updates the ManageEngine ServiceDesk Plus request via the v3 REST
    API: PUT $baseUrl/api/v3/requests/$TicketId. The ME API auth token is passed in
    the 'authtoken' header.

    SECRET HANDLING:
    In production the ManageEngine API token is retrieved from Azure Key Vault via
    the Automation Account managed identity and surfaced to this runbook through the
    AZURESENTRY_ME_TOKEN environment variable - it is NEVER hardcoded in source. The
    API base url is likewise configuration (AZURESENTRY_ME_BASEURL).

    MOCK MODE:
    For offline unit tests / CI there is no ManageEngine endpoint reachable. When
    $Implementation is 'Mock', OR when no API base url is configured
    (AZURESENTRY_ME_BASEURL is empty), the helper short-circuits and makes NO HTTP
    call - it returns a deterministic success record with Mode='Mock'. This keeps
    the runbook fully testable without network access or live credentials.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$TicketId,

    [Parameter(Mandatory)]
    [string]$Status,

    [string]$Message = '',

    [string]$Implementation = $(if ($env:AZURESENTRY_MANAGEENGINE) { $env:AZURESENTRY_MANAGEENGINE } else { 'Live' })
)

$ErrorActionPreference = 'Stop'

function Update-ManageEngineTicket {
    <#
    .SYNOPSIS
        Updates a single ManageEngine ServiceDesk Plus request's status.
    .DESCRIPTION
        Live mode performs an authenticated PUT to the ME v3 requests endpoint and
        maps the supplied status onto the ME request 'status' field, attaching the
        optional message as a description note. Mock mode (or absent base url)
        returns a deterministic record without any network I/O.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$TicketId,

        [Parameter(Mandatory)]
        [string]$Status,

        [string]$Message = '',

        [string]$Implementation = 'Live'
    )

    $baseUrl = $env:AZURESENTRY_ME_BASEURL

    # Mock / offline path: no endpoint configured, or explicitly requested. No HTTP.
    if ($Implementation -eq 'Mock' -or [string]::IsNullOrWhiteSpace($baseUrl)) {
        return [PSCustomObject]@{
            Success  = $true
            TicketId = $TicketId
            Status   = $Status
            Mode     = 'Mock'
            Message  = $Message
        }
    }

    # Live path: PUT the status update to ManageEngine ServiceDesk Plus v3 API.
    $baseUrl = $baseUrl.TrimEnd('/')
    $uri = "$baseUrl/api/v3/requests/$TicketId"

    # ME v3 wraps the resource under a top-level 'request' object. Status maps to the
    # request 'status.name' field; the optional message is appended as a description.
    $requestBody = @{
        status = @{ name = $Status }
    }
    if (-not [string]::IsNullOrWhiteSpace($Message)) {
        $requestBody['description'] = $Message
    }

    $payload = @{ request = $requestBody } | ConvertTo-Json -Depth 6 -Compress

    $headers = @{
        'authtoken' = $env:AZURESENTRY_ME_TOKEN
        'Accept'    = 'application/vnd.manageengine.sdp.v3+json'
    }

    try {
        $response = Invoke-RestMethod -Method Put -Uri $uri -Headers $headers `
            -Body @{ input_data = $payload } -ContentType 'application/x-www-form-urlencoded'

        return [PSCustomObject]@{
            Success  = $true
            TicketId = $TicketId
            Status   = $Status
            Mode     = 'Live'
            Message  = $Message
            Response = $response
        }
    }
    catch {
        return [PSCustomObject]@{
            Success  = $false
            TicketId = $TicketId
            Status   = $Status
            Mode     = 'Live'
            Message  = $Message
            Error    = $_.Exception.Message
        }
    }
}

Update-ManageEngineTicket -TicketId $TicketId -Status $Status -Message $Message -Implementation $Implementation
