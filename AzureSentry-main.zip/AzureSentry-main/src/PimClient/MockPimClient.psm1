# MockPimClient - deterministic fixtures for offline unit/contract tests only.
# Production runbooks use GraphPimClient (config: PimClientImplementation = Graph).

$script:MockState = @{
    Users             = @{}
    Assignments       = @()
    Requests          = @{}
    NextId            = 1
    Groups            = @()
    RoleAssignments   = @()
    GroupMembers      = @{}
    SubscriptionNames = @{}
}

if (-not (Get-Command Get-RoleCatalogEntry -ErrorAction SilentlyContinue)) {
    Import-Module (Join-Path $PSScriptRoot '../RbacDecision/RbacDecision.psd1') -Force -Global
}

function Reset-MockPimState {
    $script:MockState.Users = @{}
    $script:MockState.Assignments = @()
    $script:MockState.Requests = @{}
    $script:MockState.NextId = 1
    $script:MockState.Groups = @()
    $script:MockState.RoleAssignments = @()
    $script:MockState.GroupMembers = @{}
    $script:MockState.SubscriptionNames = @{}
}

function New-MockPimClient {
    [CmdletBinding()]
    param(
        [hashtable]$Users = @{ 'test.user@contoso.com' = '11111111-1111-1111-1111-111111111111' },
        [array]$ExistingAssignments = @(),
        [string]$ApprovalOutcome = 'Approved',
        [array]$Groups = @(),
        [array]$RoleAssignments = @(),
        [hashtable]$GroupMembers = @{},
        [hashtable]$SubscriptionNames = @{}
    )

    Reset-MockPimState
    $script:MockState.Users = $Users
    $script:MockState.Assignments = @($ExistingAssignments)
    $script:MockState.ApprovalOutcome = $ApprovalOutcome
    $script:MockState.Groups = @($Groups)
    $script:MockState.RoleAssignments = @($RoleAssignments)
    $script:MockState.GroupMembers = @{}
    foreach ($key in $GroupMembers.Keys) {
        $script:MockState.GroupMembers[$key] = [System.Collections.Generic.HashSet[string]]::new([string[]]$GroupMembers[$key])
    }
    $script:MockState.SubscriptionNames = @{}
    foreach ($key in $SubscriptionNames.Keys) {
        $script:MockState.SubscriptionNames[$key] = $SubscriptionNames[$key]
    }

    return [PSCustomObject]@{
        PSTypeName = 'AzureSentry.MockPimClient'
        Mode       = 'Mock'
    }
}

function Resolve-UpnToObjectId {
    param([object]$Client, [string]$Upn)
    if (-not $script:MockState.Users.ContainsKey($Upn)) {
        throw "User not found: $Upn"
    }
    return $script:MockState.Users[$Upn]
}

function Get-ActiveAssignments {
    param([object]$Client, [string]$UserId, [string]$RoleDefinitionId, [string]$Scope)
    return @($script:MockState.Assignments | Where-Object {
            $_.principalId -eq $UserId -and $_.roleDefinitionId -eq $RoleDefinitionId -and $_.scope -eq $Scope -and
            (-not $_.assignmentType -or $_.assignmentType -eq 'Active')
        })
}

function Get-EligibleAssignments {
    param([object]$Client, [string]$UserId, [string]$RoleDefinitionId, [string]$Scope)
    return @($script:MockState.Assignments | Where-Object {
            $_.principalId -eq $UserId -and $_.roleDefinitionId -eq $RoleDefinitionId -and $_.scope -eq $Scope -and
            $_.assignmentType -eq 'Eligible'
        })
}

function New-ActiveAssignment {
    param(
        [object]$Client, [string]$UserId, [string]$RoleDefinitionId,
        [string]$Scope, [int]$DurationDays, [string]$Justification = 'mock'
    )
    $id = "mock-active-$($script:MockState.NextId)"
    $script:MockState.NextId++
    $assignment = [PSCustomObject]@{
        id               = $id
        principalId      = $UserId
        roleDefinitionId = $RoleDefinitionId
        scope            = $Scope
        status           = 'Granted'
        assignmentType   = 'Active'
        expiration       = (Get-Date).AddDays($DurationDays)
    }
    $script:MockState.Assignments += $assignment
    return $assignment
}

function New-EligibleAssignment {
    param(
        [object]$Client, [string]$UserId, [string]$RoleDefinitionId,
        [string]$Scope, [int]$DurationDays, [string]$Justification
    )
    $id = "mock-eligible-$($script:MockState.NextId)"
    $script:MockState.NextId++
    $request = [PSCustomObject]@{
        id               = $id
        principalId      = $UserId
        roleDefinitionId = $RoleDefinitionId
        scope            = $Scope
        status           = 'PendingApproval'
        assignmentType   = 'Eligible'
    }
    $script:MockState.Requests[$id] = $request
    # Also track as an eligible assignment so revoke/lookup can resolve it after approval simulation.
    $script:MockState.Assignments += $request
    return $request
}

function Get-ApprovalDecision {
    param([object]$Client, [string]$RequestId)
    if (-not $script:MockState.Requests.ContainsKey($RequestId)) {
        throw "Request not found: $RequestId"
    }
    $outcome = $script:MockState.ApprovalOutcome
    return [PSCustomObject]@{
        Status   = $outcome
        Request  = $script:MockState.Requests[$RequestId]
        Reviewer = 'mock.reviewer@contoso.com'
    }
}

function Remove-PimAssignment {
    param(
        [object]$Client,
        [string]$AssignmentId,
        [string]$Scope,
        [string]$UserId,
        [string]$RoleDefinitionId,
        [ValidateSet('Active', 'Eligible')]
        [string]$AssignmentType = 'Active'
    )

    $isSentinel = [string]::IsNullOrWhiteSpace($AssignmentId) -or ($AssignmentId -match '^(?i)existing-assignment$')
    if ($isSentinel) {
        $before = @($script:MockState.Assignments)
        $script:MockState.Assignments = @($script:MockState.Assignments | Where-Object {
                -not (
                    $_.principalId -eq $UserId -and
                    $_.roleDefinitionId -eq $RoleDefinitionId -and
                    $_.scope -eq $Scope -and
                    (
                        ($AssignmentType -eq 'Eligible' -and $_.assignmentType -eq 'Eligible') -or
                        ($AssignmentType -eq 'Active' -and (-not $_.assignmentType -or $_.assignmentType -eq 'Active'))
                    )
                )
            })
        $removed = $before.Count - $script:MockState.Assignments.Count
        return [PSCustomObject]@{
            id             = "mock-revoke-resolved"
            status         = $(if ($removed -gt 0) { 'Revoked' } else { 'NotFound' })
            AlreadyRevoked = ($removed -eq 0)
        }
    }

    $script:MockState.Assignments = @($script:MockState.Assignments | Where-Object { $_.id -ne $AssignmentId })
    return [PSCustomObject]@{ id = "mock-revoke-$AssignmentId"; status = 'Revoked' }
}

function Get-RoleDefinitionId {
    param([Parameter(Mandatory)][string]$RoleName)

    # Mirrors GraphPimClient exactly — both read role-catalog.json so they cannot drift.
    $name = if ($RoleName -eq 'User Access Administrator') { 'UAA' } else { $RoleName }

    $entry = Get-RoleCatalogEntry -RoleName $name
    if (-not $entry -or -not $entry.roleDefinitionId) {
        throw "Unknown role: $RoleName"
    }
    return [string]$entry.roleDefinitionId
}

function Get-SubscriptionDisplayName {
    param([object]$Client, [Parameter(Mandatory)][string]$SubscriptionId)
    if ($script:MockState.SubscriptionNames.ContainsKey($SubscriptionId)) {
        return $script:MockState.SubscriptionNames[$SubscriptionId]
    }
    return $SubscriptionId
}

function Find-EntraRbacGroups {
    param([object]$Client, [Parameter(Mandatory)][string]$DisplayNamePrefix)
    $p = $DisplayNamePrefix.ToLowerInvariant()
    return @($script:MockState.Groups | Where-Object { $_.displayName.ToLowerInvariant().StartsWith($p) })
}

function Test-GroupHasSubscriptionRole {
    param(
        [object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$SubscriptionId,
        [Parameter(Mandatory)][string]$RoleDefinitionId
    )
    $scope = "/subscriptions/$SubscriptionId"
    return [bool]@($script:MockState.RoleAssignments | Where-Object {
            $_.principalId -eq $GroupId -and $_.roleDefinitionId -eq $RoleDefinitionId -and $_.scope -eq $scope
        }).Count
}

function Add-EntraGroupMember {
    param([object]$Client, [Parameter(Mandatory)][string]$GroupId, [Parameter(Mandatory)][string]$UserId)
    if (-not $script:MockState.GroupMembers.ContainsKey($GroupId)) {
        $script:MockState.GroupMembers[$GroupId] = New-Object 'System.Collections.Generic.HashSet[string]'
    }
    $added = $script:MockState.GroupMembers[$GroupId].Add($UserId)
    return [pscustomobject]@{ AlreadyMember = (-not $added); GroupId = $GroupId; UserId = $UserId }
}

function Get-EntraGroupMembers {
    param([object]$Client, [Parameter(Mandatory)][string]$GroupId)
    if (-not $script:MockState.GroupMembers.ContainsKey($GroupId)) {
        return @()
    }
    return @($script:MockState.GroupMembers[$GroupId])
}

function Test-EntraGroupMember {
    param([object]$Client, [Parameter(Mandatory)][string]$GroupId, [Parameter(Mandatory)][string]$UserId)
    if (-not $script:MockState.GroupMembers.ContainsKey($GroupId)) {
        return $false
    }
    return [bool]$script:MockState.GroupMembers[$GroupId].Contains($UserId)
}

function Remove-EntraGroupMember {
    param([object]$Client, [Parameter(Mandatory)][string]$GroupId, [Parameter(Mandatory)][string]$UserId)
    if ($script:MockState.GroupMembers.ContainsKey($GroupId)) {
        [void]$script:MockState.GroupMembers[$GroupId].Remove($UserId)
    }
    return [pscustomobject]@{ GroupId = $GroupId; UserId = $UserId; Removed = $true }
}

function New-EntraRbacGroup {
    param([object]$Client, [Parameter(Mandatory)][string]$DisplayName)
    $existing = @($script:MockState.Groups | Where-Object {
            $_.displayName -and $_.displayName.Equals($DisplayName, [System.StringComparison]::OrdinalIgnoreCase)
        })
    if ($existing.Count -gt 0) {
        return [pscustomobject]@{
            id             = $existing[0].id
            displayName    = $existing[0].displayName
            AlreadyExisted = $true
        }
    }
    $id = [guid]::NewGuid().ToString()
    $group = [pscustomobject]@{ id = $id; displayName = $DisplayName }
    $script:MockState.Groups += $group
    return [pscustomobject]@{
        id             = $id
        displayName    = $DisplayName
        AlreadyExisted = $false
    }
}

function New-GroupSubscriptionRoleAssignment {
    param(
        [object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$SubscriptionId,
        [Parameter(Mandatory)][string]$RoleDefinitionId
    )
    $scope = "/subscriptions/$SubscriptionId"
    if (Test-GroupHasSubscriptionRole -Client $Client -GroupId $GroupId -SubscriptionId $SubscriptionId -RoleDefinitionId $RoleDefinitionId) {
        return [pscustomobject]@{
            id               = 'existing'
            principalId      = $GroupId
            roleDefinitionId = $RoleDefinitionId
            scope            = $scope
            AlreadyExisted   = $true
        }
    }
    $assignment = [pscustomobject]@{
        id               = "mock-ra-$($script:MockState.NextId)"
        principalId      = $GroupId
        roleDefinitionId = $RoleDefinitionId
        scope            = $scope
        AlreadyExisted   = $false
    }
    $script:MockState.NextId++
    $script:MockState.RoleAssignments += $assignment
    return $assignment
}

Export-ModuleMember -Function @(
    'New-MockPimClient',
    'Reset-MockPimState',
    'Resolve-UpnToObjectId',
    'Get-ActiveAssignments',
    'Get-EligibleAssignments',
    'New-ActiveAssignment',
    'New-EligibleAssignment',
    'Get-ApprovalDecision',
    'Remove-PimAssignment',
    'Get-RoleDefinitionId',
    'Get-SubscriptionDisplayName',
    'Find-EntraRbacGroups',
    'Test-GroupHasSubscriptionRole',
    'Add-EntraGroupMember',
    'Get-EntraGroupMembers',
    'Test-EntraGroupMember',
    'Remove-EntraGroupMember',
    'New-EntraRbacGroup',
    'New-GroupSubscriptionRoleAssignment'
)
