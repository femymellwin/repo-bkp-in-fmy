# GraphPimClient - real Microsoft Graph PIM API implementation (scope Sec. 8.2)
#
# Two authentication modes:
#   1. ClientSecret (SPN / app-only) - raw OAuth2 client-credentials + Invoke-RestMethod.
#      Works on Windows PowerShell 5.1 with NO Graph SDK installed. Used for local runs
#      where the automation service principal already holds the consented app permissions.
#   2. SDK (delegated / managed identity) - Connect-MgGraph + Invoke-MgGraphRequest.
#      Used where Microsoft.Graph.Beta is available (e.g. Automation Account / VM).
#
# Secrets are never written to disk or logged; the client secret is held only in the
# in-memory client object for the life of the process.

# Role GUIDs come from RbacDecision's role-catalog.json — the single source of truth.
# Imported here (rather than duplicated) so the clients cannot drift from the decision engine.
if (-not (Get-Command Get-RoleCatalogEntry -ErrorAction SilentlyContinue)) {
    Import-Module (Join-Path $PSScriptRoot '../RbacDecision/RbacDecision.psd1') -Force -Global
}

# Azure resource role assignments (subscription/RG scope) are NOT a Microsoft Graph
# feature - Graph's roleManagement/azureResources segment does not exist. They are
# managed via the ARM "PIM for Azure resources" API (management.azure.com). Directory
# (Entra) roles still go through Graph. Scope prefixed with /subscriptions -> ARM.
$script:ArmPimApiVersion = '2020-10-01'

function Get-GraphSpnToken {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$TenantId,
        [Parameter(Mandatory)][string]$ClientId,
        [Parameter(Mandatory)][string]$ClientSecret,
        [string]$Resource = 'https://graph.microsoft.com'
    )
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $body = @{
        grant_type    = 'client_credentials'
        client_id     = $ClientId
        client_secret = $ClientSecret
        scope         = "$Resource/.default"
    }
    $uri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
    $resp = Invoke-RestMethod -Method Post -Uri $uri -Body $body -ContentType 'application/x-www-form-urlencoded'
    return [PSCustomObject]@{
        Token     = $resp.access_token
        ExpiresOn = (Get-Date).AddSeconds([int]$resp.expires_in)
    }
}

function New-GraphPimClient {
    [CmdletBinding()]
    param(
        [Parameter()][string]$TenantId,
        [Parameter()][string]$ClientId,
        [Parameter()][string]$ClientSecret,
        [Parameter()][object]$GraphClient
    )

    # --- Mode 1: SPN client-credentials (no SDK required) ---
    if ($ClientId -and $ClientSecret) {
        if (-not $TenantId) { throw 'TenantId is required for client-secret (SPN) authentication.' }
        $tok = Get-GraphSpnToken -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret
        return [PSCustomObject]@{
            PSTypeName      = 'AzureSentry.GraphPimClient'
            AuthMode        = 'ClientSecret'
            TenantId        = $TenantId
            ClientId        = $ClientId
            ClientSecret    = $ClientSecret
            GraphToken      = $tok.Token
            TokenExpires    = $tok.ExpiresOn
            ArmToken        = $null   # acquired lazily on first ARM call
            ArmTokenExpires = [datetime]::MinValue
            GraphReady      = $true
        }
    }

    # --- Mode 2: SDK (delegated / managed identity) ---
    if (-not $GraphClient) {
        if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Beta)) {
            throw 'Microsoft.Graph.Beta module required for SDK-mode GraphPimClient. Install it, or use ClientId/ClientSecret for SPN mode.'
        }
        Import-Module Microsoft.Graph.Beta -ErrorAction Stop

        # Group.Read.All supports RBAC-group discovery; GroupMember.ReadWrite.All
        # supports membership changes. SPN mode uses pre-consented app permissions.
        $connectParams = @{
            Scopes = @(
                'RoleManagement.ReadWrite.Directory',
                'User.Read.All',
                'Group.Read.All',
                'GroupMember.ReadWrite.All'
            )
        }
        if ($TenantId) { $connectParams['TenantId'] = $TenantId }

        Connect-MgGraph @connectParams -NoWelcome | Out-Null
        $GraphClient = $true
    }

    return [PSCustomObject]@{
        PSTypeName = 'AzureSentry.GraphPimClient'
        AuthMode   = 'Sdk'
        TenantId   = $TenantId
        GraphReady = [bool]$GraphClient
    }
}

# Unified Graph call - routes to raw REST (SPN mode) or the SDK (Invoke-MgGraphRequest).
function Get-RestErrorBody {
    param($ErrorRecord)
    try {
        if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
            return [string]$ErrorRecord.ErrorDetails.Message
        }
        $resp = $ErrorRecord.Exception.Response
        if ($resp -and $resp.GetResponseStream) {
            $stream = $resp.GetResponseStream()
            if ($stream) {
                $reader = New-Object System.IO.StreamReader($stream)
                return $reader.ReadToEnd()
            }
        }
    }
    catch { }
    return $null
}

function Invoke-GraphApi {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$Uri,
        [object]$Body,
        [string]$ContentType = 'application/json'
    )

    if ($Client.AuthMode -eq 'ClientSecret') {
        # Refresh the token if it is within 2 minutes of expiry.
        if ((Get-Date) -ge $Client.TokenExpires.AddMinutes(-2)) {
            $tok = Get-GraphSpnToken -TenantId $Client.TenantId -ClientId $Client.ClientId -ClientSecret $Client.ClientSecret
            $Client.GraphToken   = $tok.Token
            $Client.TokenExpires = $tok.ExpiresOn
        }
        $headers = @{ Authorization = "Bearer $($Client.GraphToken)" }
        $params = @{ Method = $Method; Uri = $Uri; Headers = $headers }
        if ($Body) {
            $params['Body'] = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 8 }
            $params['ContentType'] = $ContentType
        }
        try {
            return Invoke-RestMethod @params
        }
        catch {
            $detail = Get-RestErrorBody -ErrorRecord $_
            $hint = ''
            if ("$detail$($_.Exception.Message)" -match 'Authorization_RequestDenied|Insufficient privileges|403') {
                if ($Uri -match '/groups') {
                    $hint = ' SPN needs Microsoft Graph application permission Group.ReadWrite.All (admin consent) to find/create groups and manage members.'
                }
            }
            $msg = $_.Exception.Message
            if ($detail) { $msg = "$msg | $detail" }
            if ($hint) { $msg = "$msg |$hint" }
            throw $msg
        }
    }

    # SDK mode
    $params = @{ Method = $Method; Uri = $Uri; OutputType = 'PSObject' }
    if ($Body) {
        $params['Body'] = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 8 }
        $params['ContentType'] = $ContentType
    }
    return Invoke-MgGraphRequest @params
}

# ARM call (management.azure.com) for Azure-resource-scoped PIM. Client-secret mode only.
function Invoke-ArmApi {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$Uri,
        [object]$Body
    )
    if ($Client.AuthMode -ne 'ClientSecret') {
        throw 'ARM (Azure resource) PIM calls require client-secret (SPN) authentication.'
    }
    if (-not $Client.ArmToken -or (Get-Date) -ge $Client.ArmTokenExpires.AddMinutes(-2)) {
        $tok = Get-GraphSpnToken -TenantId $Client.TenantId -ClientId $Client.ClientId `
            -ClientSecret $Client.ClientSecret -Resource 'https://management.azure.com'
        $Client.ArmToken        = $tok.Token
        $Client.ArmTokenExpires = $tok.ExpiresOn
    }
    $params = @{ Method = $Method; Uri = $Uri; Headers = @{ Authorization = "Bearer $($Client.ArmToken)" } }
    if ($Body) {
        $params['Body'] = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 8 }
        $params['ContentType'] = 'application/json'
    }
    try {
        return Invoke-RestMethod @params
    }
    catch {
        $detail = Get-RestErrorBody -ErrorRecord $_
        $msg = $_.Exception.Message
        if ($detail) { $msg = "$msg | $detail" }
        throw $msg
    }
}

function Format-EntraObjectId {
    <#
    .SYNOPSIS
      Normalize an Entra object id to a dashed GUID (ARM rejects hyphenless principals).
    #>
    param([string]$Id)
    if ([string]::IsNullOrWhiteSpace($Id)) { return $Id }
    $guid = [guid]::Empty
    if ([guid]::TryParse($Id.Trim(), [ref]$guid)) {
        return $guid.ToString('D')
    }
    return $Id.Trim()
}

# Build the ARM PIM schedule-request body + URL for a subscription/RG-scoped grant.
function New-ArmPimRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$Kind,   # 'roleAssignmentScheduleRequests' | 'roleEligibilityScheduleRequests'
        [Parameter(Mandatory)][string]$PrincipalId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$Scope,
        [Parameter(Mandatory)][int]$DurationDays,
        [string]$Justification = 'AzureSentry automated grant'
    )
    $requestName = [guid]::NewGuid().ToString()
    $body = @{
        properties = @{
            principalId      = $PrincipalId
            roleDefinitionId = "$Scope/providers/Microsoft.Authorization/roleDefinitions/$RoleDefinitionId"
            requestType      = 'AdminAssign'
            justification    = $Justification
            scheduleInfo     = @{
                startDateTime = (Get-Date).ToUniversalTime().ToString('o')
                expiration    = @{ type = 'AfterDuration'; duration = "P${DurationDays}D" }
            }
        }
    }
    $uri = "https://management.azure.com$Scope/providers/Microsoft.Authorization/$Kind/$requestName`?api-version=$script:ArmPimApiVersion"
    return Invoke-ArmApi -Client $Client -Method PUT -Uri $uri -Body $body
}

function Select-GraphUserMatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object[]]$Matches,
        [Parameter(Mandatory)][string]$RequestedAddress
    )

    if ($Matches.Count -eq 0) {
        throw "User not found for '$RequestedAddress' (tried UPN, mail, and aliases)."
    }
    if ($Matches.Count -eq 1) { return $Matches[0].id }

    # Ignore disabled duplicates first. If aliases still collide, prefer the sole
    # enabled account with a real primary mail address over test/service accounts
    # that merely reuse the address in otherMails.
    $enabled = @($Matches | Where-Object { $_.accountEnabled -ne $false })
    if ($enabled.Count -eq 1) { return $enabled[0].id }

    $withPrimaryMail = @($enabled | Where-Object {
            -not [string]::IsNullOrWhiteSpace([string]$_.mail)
        })
    if ($withPrimaryMail.Count -eq 1) { return $withPrimaryMail[0].id }

    throw "Ambiguous requester '$RequestedAddress' - $($Matches.Count) users match; supply the exact UPN."
}

function Resolve-UpnToObjectId {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$Upn
    )
    # Direct lookup works for members whose UPN == the supplied value.
    try {
        $user = Invoke-GraphApi -Client $Client -Method GET `
            -Uri "https://graph.microsoft.com/v1.0/users/$([uri]::EscapeDataString($Upn))"
        return $user.id
    }
    catch {
        # Guests/externals: the ticket usually carries the person's mail, not their
        # #EXT# UPN, so the direct lookup 404s. Resolve by primary mail/UPN first;
        # only fall back to otherMails (aliases) if nothing matches, to avoid catching
        # unrelated accounts that merely list this address as an alias.
        $sel = "&`$select=id,userPrincipalName,mail,accountEnabled&`$top=10"
        $primary = "mail eq '$Upn' or userPrincipalName eq '$Upn'"
        $resp = Invoke-GraphApi -Client $Client -Method GET `
            -Uri "https://graph.microsoft.com/v1.0/users?`$filter=$([uri]::EscapeDataString($primary))$sel"
        $matches = @($resp.value)
        if ($matches.Count -eq 0) {
            $alias = "otherMails/any(x:x eq '$Upn')"
            $resp2 = Invoke-GraphApi -Client $Client -Method GET `
                -Uri "https://graph.microsoft.com/v1.0/users?`$filter=$([uri]::EscapeDataString($alias))$sel"
            $matches = @($resp2.value)
        }
        return Select-GraphUserMatch -Matches $matches -RequestedAddress $Upn
    }
}

function Get-ActiveAssignments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$Scope
    )

    # Azure resource scope -> ARM PIM instances. Directory scope -> Graph.
    if ($Scope -match '^/subscriptions/') {
        $filter = [uri]::EscapeDataString("principalId eq '$UserId'")
        $armUri = "https://management.azure.com$Scope/providers/Microsoft.Authorization/roleAssignmentScheduleInstances?api-version=$script:ArmPimApiVersion&`$filter=$filter"
        $armResp = Invoke-ArmApi -Client $Client -Method GET -Uri $armUri
        return @($armResp.value | Where-Object {
                ($_.properties.roleDefinitionId -split '/')[-1] -eq $RoleDefinitionId -and
                $_.properties.scope -eq $Scope
            })
    }

    $filter = "principalId eq '$UserId' and roleDefinitionId eq '$RoleDefinitionId'"
    $uri = "https://graph.microsoft.com/beta/roleManagement/directory/roleAssignmentScheduleInstances?`$filter=$filter"
    $response = Invoke-GraphApi -Client $Client -Method GET -Uri $uri
    return @(@($response.value) | Where-Object { $_.scopeId -eq $Scope -or $_.scope -eq $Scope })
}

function Get-EligibleAssignments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$Scope
    )

    if ($Scope -match '^/subscriptions/') {
        $filter = [uri]::EscapeDataString("principalId eq '$UserId'")
        $armUri = "https://management.azure.com$Scope/providers/Microsoft.Authorization/roleEligibilityScheduleInstances?api-version=$script:ArmPimApiVersion&`$filter=$filter"
        $armResp = Invoke-ArmApi -Client $Client -Method GET -Uri $armUri
        return @($armResp.value | Where-Object {
                ($_.properties.roleDefinitionId -split '/')[-1] -eq $RoleDefinitionId -and
                ($_.properties.scope -eq $Scope -or -not $_.properties.scope)
            })
    }

    $filter = "principalId eq '$UserId' and roleDefinitionId eq '$RoleDefinitionId'"
    $uri = "https://graph.microsoft.com/beta/roleManagement/directory/roleEligibilityScheduleInstances?`$filter=$filter"
    $response = Invoke-GraphApi -Client $Client -Method GET -Uri $uri
    return @(@($response.value) | Where-Object { $_.scopeId -eq $Scope -or $_.scope -eq $Scope })
}

function New-ActiveAssignment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$Scope,
        [Parameter(Mandatory)][int]$DurationDays,
        [string]$Justification = 'AzureSentry automated grant'
    )

    # Azure resource scope -> ARM PIM (management.azure.com). Directory scope -> Graph.
    if ($Scope -match '^/subscriptions/') {
        return New-ArmPimRequest -Client $Client -Kind 'roleAssignmentScheduleRequests' `
            -PrincipalId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope `
            -DurationDays $DurationDays -Justification $Justification
    }

    $body = @{
        action           = 'adminAssign'
        principalId      = $UserId
        roleDefinitionId = $RoleDefinitionId
        directoryScopeId = '/'
        scheduleInfo     = @{
            startDateTime = (Get-Date).ToUniversalTime().ToString('o')
            expiration    = @{ type = 'AfterDuration'; duration = "P${DurationDays}D" }
        }
        justification    = $Justification
    }
    $uri = 'https://graph.microsoft.com/beta/roleManagement/directory/roleAssignmentScheduleRequests'
    return Invoke-GraphApi -Client $Client -Method POST -Uri $uri -Body ($body | ConvertTo-Json -Depth 6) -ContentType 'application/json'
}

function New-EligibleAssignment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$Scope,
        [Parameter(Mandatory)][int]$DurationDays,
        [string]$Justification
    )

    if ($Scope -match '^/subscriptions/') {
        return New-ArmPimRequest -Client $Client -Kind 'roleEligibilityScheduleRequests' `
            -PrincipalId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope `
            -DurationDays $DurationDays -Justification $Justification
    }

    $body = @{
        action           = 'adminAssign'
        principalId      = $UserId
        roleDefinitionId = $RoleDefinitionId
        directoryScopeId = '/'
        scheduleInfo     = @{
            startDateTime = (Get-Date).ToUniversalTime().ToString('o')
            expiration    = @{ type = 'AfterDuration'; duration = "P${DurationDays}D" }
        }
        justification    = $Justification
    }
    $uri = 'https://graph.microsoft.com/beta/roleManagement/directory/roleEligibilityScheduleRequests'
    return Invoke-GraphApi -Client $Client -Method POST -Uri $uri -Body ($body | ConvertTo-Json -Depth 6) -ContentType 'application/json'
}

function Get-ApprovalDecision {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$RequestId
    )

    $uri = "https://graph.microsoft.com/beta/roleManagement/directory/roleEligibilityScheduleRequests/$RequestId"
    try {
        $request = Invoke-GraphApi -Client $Client -Method GET -Uri $uri
    }
    catch {
        $uri = "https://graph.microsoft.com/beta/roleManagement/azureResources/roleEligibilityScheduleRequests/$RequestId"
        $request = Invoke-GraphApi -Client $Client -Method GET -Uri $uri
    }

    $status = switch ($request.status) {
        'Granted' { 'Approved' }
        'Denied' { 'Denied' }
        'Canceled' { 'Expired' }
        default { 'Pending' }
    }

    $reviewer = $null
    if ($request.completedBy -and $request.completedBy.user) {
        $reviewer = $request.completedBy.user.userPrincipalName
    }

    return [PSCustomObject]@{
        Status   = $status
        Request  = $request
        Reviewer = $reviewer
    }
}

function Test-PimAssignmentIdSentinel {
    param([string]$AssignmentId)
    if ([string]::IsNullOrWhiteSpace($AssignmentId)) { return $true }
    return ($AssignmentId -match '^(?i)existing-assignment$')
}

function Remove-PimAssignment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [string]$AssignmentId,
        [Parameter(Mandatory)][string]$Scope,
        [string]$UserId,
        [string]$RoleDefinitionId,
        [ValidateSet('Active', 'Eligible')]
        [string]$AssignmentType = 'Active'
    )

    if ($Scope -match '^/subscriptions/') {
        $isEligible = ($AssignmentType -eq 'Eligible') -or
            ($AssignmentId -match 'roleEligibilitySchedule')
        $requestKind = if ($isEligible) {
            'roleEligibilityScheduleRequests'
        }
        else {
            'roleAssignmentScheduleRequests'
        }

        # Prefer live instance lookup when we can - covers sentinel IDs, already-revoked
        # grants, and mismatched stored AssignmentType vs request kind.
        if ($UserId -and $RoleDefinitionId) {
            $live = if ($isEligible) {
                @(Get-EligibleAssignments -Client $Client -UserId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope)
            }
            else {
                @(Get-ActiveAssignments -Client $Client -UserId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope)
            }
            # If typed Active but id was eligibility (or vice versa), also check the other kind.
            if ($live.Count -eq 0) {
                $other = if ($isEligible) {
                    @(Get-ActiveAssignments -Client $Client -UserId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope)
                }
                else {
                    @(Get-EligibleAssignments -Client $Client -UserId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope)
                }
                if ($other.Count -gt 0) {
                    $live = $other
                    $isEligible = -not $isEligible
                    $requestKind = if ($isEligible) {
                        'roleEligibilityScheduleRequests'
                    }
                    else {
                        'roleAssignmentScheduleRequests'
                    }
                }
            }
            if ($live.Count -eq 0) {
                return [pscustomobject]@{
                    AlreadyRevoked = $true
                    status         = 'NotFound'
                    Message        = 'No active or eligible PIM assignment found to revoke.'
                }
            }
            # Force resolve-from-instance path below.
            $AssignmentId = 'existing-assignment'
        }

        $principalId = $null
        $roleDefFull = $null
        $targetScheduleId = $null
        $targetInstanceId = $null

        if (Test-PimAssignmentIdSentinel -AssignmentId $AssignmentId) {
            if (-not $UserId -or -not $RoleDefinitionId) {
                throw "Cannot revoke sentinel/unknown assignment id '$AssignmentId' without UserId and RoleDefinitionId."
            }
            $instances = if ($isEligible) {
                @(Get-EligibleAssignments -Client $Client -UserId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope)
            }
            else {
                @(Get-ActiveAssignments -Client $Client -UserId $UserId -RoleDefinitionId $RoleDefinitionId -Scope $Scope)
            }
            if ($instances.Count -eq 0) {
                return [pscustomobject]@{
                    AlreadyRevoked = $true
                    status         = 'NotFound'
                    Message        = "No $($AssignmentType.ToLowerInvariant()) PIM assignment found to revoke."
                }
            }
            $inst = $instances[0]
            $principalId = [string]$inst.properties.principalId
            $roleDefFull = [string]$inst.properties.roleDefinitionId
            if ($isEligible) {
                $targetScheduleId = [string]$inst.properties.roleEligibilityScheduleId
            }
            else {
                $targetScheduleId = [string]$inst.properties.roleAssignmentScheduleId
            }
            if ($inst.id) { $targetInstanceId = [string]$inst.id }
        }
        elseif ($AssignmentId -match 'ScheduleInstances/') {
            $instUri = "https://management.azure.com$AssignmentId`?api-version=$script:ArmPimApiVersion"
            $inst = Invoke-ArmApi -Client $Client -Method GET -Uri $instUri
            if (-not $inst.properties.principalId -or -not $inst.properties.roleDefinitionId) {
                throw "PIM schedule instance is missing principal or role data: $AssignmentId"
            }
            $principalId = [string]$inst.properties.principalId
            $roleDefFull = [string]$inst.properties.roleDefinitionId
            $targetInstanceId = [string]$AssignmentId
            if ($isEligible) {
                $targetScheduleId = [string]$inst.properties.roleEligibilityScheduleId
            }
            else {
                $targetScheduleId = [string]$inst.properties.roleAssignmentScheduleId
            }
        }
        elseif ($AssignmentId -match '^/subscriptions/') {
            $grantUri = "https://management.azure.com$AssignmentId`?api-version=$script:ArmPimApiVersion"
            $grant = Invoke-ArmApi -Client $Client -Method GET -Uri $grantUri
            if (-not $grant.properties.principalId -or -not $grant.properties.roleDefinitionId) {
                throw "Original PIM grant is missing principal or role data: $AssignmentId"
            }
            $principalId = [string]$grant.properties.principalId
            $roleDefFull = [string]$grant.properties.roleDefinitionId
            if ($isEligible) {
                if ($grant.properties.targetRoleEligibilityScheduleId) {
                    $targetScheduleId = [string]$grant.properties.targetRoleEligibilityScheduleId
                }
                elseif ($grant.properties.roleEligibilityScheduleId) {
                    $targetScheduleId = [string]$grant.properties.roleEligibilityScheduleId
                }
            }
            else {
                if ($grant.properties.targetRoleAssignmentScheduleId) {
                    $targetScheduleId = [string]$grant.properties.targetRoleAssignmentScheduleId
                }
                if ($grant.properties.targetRoleAssignmentScheduleInstanceId) {
                    $targetInstanceId = [string]$grant.properties.targetRoleAssignmentScheduleInstanceId
                }
            }
        }
        else {
            # Bare GUID / short name — treat as a schedule request under the matching kind.
            $grantRequestId = "$Scope/providers/Microsoft.Authorization/$requestKind/$AssignmentId"
            $grantUri = "https://management.azure.com$grantRequestId`?api-version=$script:ArmPimApiVersion"
            $grant = Invoke-ArmApi -Client $Client -Method GET -Uri $grantUri
            if (-not $grant.properties.principalId -or -not $grant.properties.roleDefinitionId) {
                throw "Original PIM grant request is missing principal or role data: $grantRequestId"
            }
            $principalId = [string]$grant.properties.principalId
            $roleDefFull = [string]$grant.properties.roleDefinitionId
            if ($isEligible) {
                if ($grant.properties.targetRoleEligibilityScheduleId) {
                    $targetScheduleId = [string]$grant.properties.targetRoleEligibilityScheduleId
                }
            }
            else {
                if ($grant.properties.targetRoleAssignmentScheduleId) {
                    $targetScheduleId = [string]$grant.properties.targetRoleAssignmentScheduleId
                }
                if ($grant.properties.targetRoleAssignmentScheduleInstanceId) {
                    $targetInstanceId = [string]$grant.properties.targetRoleAssignmentScheduleInstanceId
                }
            }
        }

        $removeProperties = @{
            principalId      = $principalId
            roleDefinitionId = $roleDefFull
            requestType      = 'AdminRemove'
            justification    = 'AzureSentry access revocation'
            scheduleInfo     = @{
                startDateTime = (Get-Date).ToUniversalTime().ToString('o')
                expiration    = @{ type = 'AfterDuration'; duration = 'PT1H' }
            }
        }
        if ($isEligible) {
            if ($targetScheduleId) {
                $removeProperties.targetRoleEligibilityScheduleId = $targetScheduleId
            }
        }
        else {
            if ($targetScheduleId) {
                $removeProperties.targetRoleAssignmentScheduleId = $targetScheduleId
            }
            if ($targetInstanceId) {
                $removeProperties.targetRoleAssignmentScheduleInstanceId = $targetInstanceId
            }
        }

        $removeName = [guid]::NewGuid().ToString()
        $removeUri = "https://management.azure.com$Scope/providers/Microsoft.Authorization/$requestKind/$removeName`?api-version=$script:ArmPimApiVersion"
        try {
            return Invoke-ArmApi -Client $Client -Method PUT -Uri $removeUri -Body @{
                properties = $removeProperties
            }
        }
        catch {
            $detail = "$($_.Exception.Message) $(if ($_.ErrorDetails) { $_.ErrorDetails.Message })"
            if ($detail -match 'RoleAssignmentDoesNotExist|RoleEligibilityScheduleRequestDoesNotExist|NotFound|does not exist') {
                return [pscustomobject]@{
                    AlreadyRevoked = $true
                    status         = 'NotFound'
                    Message        = "PIM assignment already absent ($detail)."
                }
            }
            throw
        }
    }

    $body = @{
        action                   = 'adminRemove'
        roleAssignmentScheduleId = $AssignmentId
        directoryScopeId         = $Scope
        justification            = 'AzureSentry access revocation'
    }
    $uri = 'https://graph.microsoft.com/beta/roleManagement/directory/roleAssignmentScheduleRequests'
    return Invoke-GraphApi -Client $Client -Method POST -Uri $uri `
        -Body ($body | ConvertTo-Json -Depth 4) -ContentType 'application/json'
}

function Get-RoleDefinitionId {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$RoleName)

    # 'User Access Administrator' is the Azure display name; tickets use the short 'UAA'.
    $name = if ($RoleName -eq 'User Access Administrator') { 'UAA' } else { $RoleName }

    $entry = Get-RoleCatalogEntry -RoleName $name
    if (-not $entry -or -not $entry.roleDefinitionId) {
        throw "Unknown role: $RoleName"
    }
    return [string]$entry.roleDefinitionId
}

function Get-SubscriptionDisplayName {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$SubscriptionId
    )

    $uri = "https://management.azure.com/subscriptions/$SubscriptionId`?api-version=2022-12-01"
    $subscription = Invoke-ArmApi -Client $Client -Method GET -Uri $uri
    return $subscription.displayName
}

function Find-EntraRbacGroups {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$DisplayNamePrefix
    )

    $escapedPrefix = $DisplayNamePrefix.Replace("'", "''")
    $filter = [uri]::EscapeDataString("startswith(displayName,'$escapedPrefix')")
    $uri = "https://graph.microsoft.com/v1.0/groups?`$filter=$filter"
    $response = Invoke-GraphApi -Client $Client -Method GET -Uri $uri
    return @($response.value)
}

function Test-GroupHasSubscriptionRole {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$SubscriptionId,
        [Parameter(Mandatory)][string]$RoleDefinitionId
    )

    $GroupId = Format-EntraObjectId -Id $GroupId
    $filter = [uri]::EscapeDataString("principalId eq '$GroupId'")
    $uri = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01&`$filter=$filter"
    $expectedScope = "/subscriptions/$SubscriptionId"
    $response = Invoke-ArmApi -Client $Client -Method GET -Uri $uri
    return [bool]@($response.value | Where-Object {
            [string]$roleDefinitionPath = $_.properties.roleDefinitionId
            [string]$assignmentScope = $_.properties.scope
            $assignmentScope.Equals($expectedScope, [System.StringComparison]::OrdinalIgnoreCase) -and
                $roleDefinitionPath.EndsWith($RoleDefinitionId, [System.StringComparison]::OrdinalIgnoreCase)
        }).Count
}

function Add-EntraGroupMember {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$UserId
    )

    $uri = "https://graph.microsoft.com/v1.0/groups/$GroupId/members/`$ref"
    $body = @{
        '@odata.id' = "https://graph.microsoft.com/v1.0/directoryObjects/$UserId"
    }
    try {
        Invoke-GraphApi -Client $Client -Method POST -Uri $uri -Body $body | Out-Null
        return [pscustomobject]@{
            AlreadyMember = $false
            GroupId       = $GroupId
            UserId        = $UserId
        }
    }
    catch {
        $statusCode = if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
            [int]$_.Exception.Response.StatusCode
        }
        else {
            $null
        }
        $errorText = "$($_.Exception.Message) $($_.ErrorDetails.Message)"
        $isBadRequest = $statusCode -eq 400 -or $errorText -match 'Request_BadRequest'
        if ($isBadRequest -and $errorText -match 'already exist') {
            return [pscustomobject]@{
                AlreadyMember = $true
                GroupId       = $GroupId
                UserId        = $UserId
            }
        }
        throw
    }
}

function Get-EntraGroupMembers {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$GroupId
    )

    $uri = "https://graph.microsoft.com/v1.0/groups/$GroupId/members"
    $response = Invoke-GraphApi -Client $Client -Method GET -Uri $uri
    return @($response.value)
}

function Test-EntraGroupMember {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$UserId
    )

    $GroupId = Format-EntraObjectId -Id $GroupId
    $UserId = Format-EntraObjectId -Id $UserId
    $uri = "https://graph.microsoft.com/v1.0/groups/$GroupId/members/$UserId"
    try {
        Invoke-GraphApi -Client $Client -Method GET -Uri $uri | Out-Null
        return $true
    }
    catch {
        $errorText = "$_"
        if ($errorText -match 'Request_ResourceNotFound|404|does not exist|NotFound') {
            return $false
        }
        throw
    }
}

function Remove-EntraGroupMember {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$UserId
    )

    $uri = "https://graph.microsoft.com/v1.0/groups/$GroupId/members/$UserId/`$ref"
    try {
        Invoke-GraphApi -Client $Client -Method DELETE -Uri $uri | Out-Null
        return [pscustomobject]@{
            GroupId       = $GroupId
            UserId        = $UserId
            Removed       = $true
            AlreadyAbsent = $false
        }
    }
    catch {
        $statusCode = if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
            [int]$_.Exception.Response.StatusCode
        }
        else {
            $null
        }
        $errorText = "$($_.Exception.Message) $($_.ErrorDetails.Message)"
        # Graph returns 404 when the user is already not a member — treat as idempotent success.
        if ($statusCode -eq 404 -or $errorText -match 'Request_ResourceNotFound|does not exist') {
            return [pscustomobject]@{
                GroupId       = $GroupId
                UserId        = $UserId
                Removed       = $false
                AlreadyAbsent = $true
            }
        }
        throw
    }
}

function New-EntraRbacGroup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$DisplayName
    )

    $escaped = $DisplayName.Replace("'", "''")
    $filter = [uri]::EscapeDataString("displayName eq '$escaped'")
    $existingUri = "https://graph.microsoft.com/v1.0/groups?`$filter=$filter&`$select=id,displayName"

    $existing = Invoke-GraphApi -Client $Client -Method GET -Uri $existingUri
    if ($existing.value -and @($existing.value).Count -gt 0) {
        $g = @($existing.value)[0]
        return [pscustomobject]@{ id = $g.id; displayName = $g.displayName; AlreadyExisted = $true }
    }

    # mailNickname: alphanumeric only, max 64 chars (Graph requirement for security groups).
    $nick = ($DisplayName -replace '[^A-Za-z0-9]', '')
    if ([string]::IsNullOrWhiteSpace($nick)) { $nick = 'sgroup' }
    if ($nick.Length -gt 64) { $nick = $nick.Substring(0, 64) }

    $body = @{
        displayName     = $DisplayName
        mailEnabled     = $false
        mailNickname    = $nick
        securityEnabled = $true
        description     = 'AzureSentry managed subscription RBAC group'
    }
    try {
        $created = Invoke-GraphApi -Client $Client -Method POST -Uri 'https://graph.microsoft.com/v1.0/groups' -Body $body
        return [pscustomobject]@{ id = $created.id; displayName = $created.displayName; AlreadyExisted = $false }
    }
    catch {
        $detail = "$($_.Exception.Message) $(if ($_.ErrorDetails) { $_.ErrorDetails.Message })"
        # Concurrent create or nickname/displayName collision - treat as existing group.
        if ($detail -match 'already exist|ObjectConflict|another object with the same value|duplicate') {
            $retry = Invoke-GraphApi -Client $Client -Method GET -Uri $existingUri
            if ($retry.value -and @($retry.value).Count -gt 0) {
                $g = @($retry.value)[0]
                return [pscustomobject]@{ id = $g.id; displayName = $g.displayName; AlreadyExisted = $true }
            }
        }
        throw
    }
}

function New-GroupSubscriptionRoleAssignment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$SubscriptionId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [int]$MaxAttempts = 5,
        [int]$RetryDelaySeconds = 3
    )

    # ARM looks up the principal in Entra. Hyphenless Graph ids and create→assign
    # replication both surface as PrincipalNotFound; dashed GUID + principalType Group
    # + retries are the documented mitigation (https://aka.ms/docs-principaltype).
    $GroupId = Format-EntraObjectId -Id $GroupId
    if ($MaxAttempts -lt 1) { $MaxAttempts = 1 }

    if (Test-GroupHasSubscriptionRole -Client $Client -GroupId $GroupId -SubscriptionId $SubscriptionId -RoleDefinitionId $RoleDefinitionId) {
        return [pscustomobject]@{
            id               = 'existing'
            principalId      = $GroupId
            roleDefinitionId = $RoleDefinitionId
            scope            = "/subscriptions/$SubscriptionId"
            AlreadyExisted   = $true
        }
    }

    $assignmentName = [guid]::NewGuid().ToString()
    $scope = "/subscriptions/$SubscriptionId"
    $uri = "https://management.azure.com$scope/providers/Microsoft.Authorization/roleAssignments/$assignmentName`?api-version=2022-04-01"
    $body = @{
        properties = @{
            roleDefinitionId = "$scope/providers/Microsoft.Authorization/roleDefinitions/$RoleDefinitionId"
            principalId      = $GroupId
            principalType    = 'Group'
        }
    }

    $attempt = 0
    while ($attempt -lt $MaxAttempts) {
        $attempt++
        try {
            $created = Invoke-ArmApi -Client $Client -Method PUT -Uri $uri -Body $body
            return [pscustomobject]@{
                id               = $created.name
                principalId      = $GroupId
                roleDefinitionId = $RoleDefinitionId
                scope            = $scope
                AlreadyExisted   = $false
            }
        }
        catch {
            $detail = "$($_.Exception.Message) $(if ($_.ErrorDetails) { $_.ErrorDetails.Message })"
            if ($detail -match 'RoleAssignmentExists|already exists') {
                return [pscustomobject]@{
                    id               = 'existing'
                    principalId      = $GroupId
                    roleDefinitionId = $RoleDefinitionId
                    scope            = $scope
                    AlreadyExisted   = $true
                }
            }
            $isReplication = $detail -match 'PrincipalNotFound'
            if ($isReplication -and $attempt -lt $MaxAttempts) {
                if ($RetryDelaySeconds -gt 0) {
                    Start-Sleep -Seconds $RetryDelaySeconds
                }
                continue
            }
            throw
        }
    }
}

Export-ModuleMember -Function @(
    'New-GraphPimClient',
    'Resolve-UpnToObjectId',
    'Get-ActiveAssignments',
    'Get-EligibleAssignments',
    'New-ActiveAssignment',
    'New-EligibleAssignment',
    'Get-ApprovalDecision',
    'Remove-PimAssignment',
    'Get-RoleDefinitionId',
    'Get-SubscriptionDisplayName',
    'Find-EntraRbacGroups',
    'Test-GroupHasSubscriptionRole',
    'Add-EntraGroupMember',
    'Get-EntraGroupMembers',
    'Test-EntraGroupMember',
    'Remove-EntraGroupMember',
    'New-EntraRbacGroup',
    'New-GroupSubscriptionRoleAssignment'
)
