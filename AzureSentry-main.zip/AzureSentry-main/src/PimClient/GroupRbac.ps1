# Group-based RBAC helpers (naming + grant orchestration). Dot-source only.

function Get-RbacGroupRoleSuffix {
    param([Parameter(Mandatory)][string]$RoleName)
    switch -Regex ($RoleName) {
        '^(?i)reader$' { return 'readers' }
        '^(?i)contributor$|^(?i)writer$' { return 'contributors' }
        default { throw "Role '$RoleName' is not supported on the group RBAC path." }
    }
}

function Get-NormalizedSubscriptionSlug {
    param([Parameter(Mandatory)][string]$SubscriptionName)
    $s = $SubscriptionName.Trim().ToLowerInvariant() -replace '[_\s]+', '-'
    $s = $s -replace '-{2,}', '-'
    return $s.Trim('-')
}

function Get-EnvironmentTokenFromSlug {
    param([Parameter(Mandatory)][string]$Slug)
    $tokens = @{
        'production' = 'prod'; 'prod' = 'prod'; 'preprod' = 'preprod'
        'nonprod' = 'nonprod'; 'staging' = 'staging'; 'sandbox' = 'sandbox'
        'uat' = 'uat'; 'qa' = 'qa'; 'dev' = 'dev'
    }
    foreach ($part in ($Slug -split '-')) {
        if ($tokens.ContainsKey($part)) { return $tokens[$part] }
    }
    return $null
}

function Get-RbacGroupSearchPrefix {
    param(
        [Parameter(Mandatory)][string]$SubscriptionName,
        [bool]$IncludeEnvironment = $true
    )
    $slug = Get-NormalizedSubscriptionSlug -SubscriptionName $SubscriptionName
    if (-not $IncludeEnvironment) {
        return "sg-$slug"
    }
    $envTok = Get-EnvironmentTokenFromSlug -Slug $slug
    if (-not $envTok) { return "sg-$slug" }
    return "sg-$slug"
}

function Get-CanonicalRbacGroupDisplayName {
    param(
        [Parameter(Mandatory)][string]$SubscriptionName,
        [Parameter(Mandatory)][string]$RoleName
    )
    $prefix = Get-RbacGroupSearchPrefix -SubscriptionName $SubscriptionName -IncludeEnvironment:$false
    $suffix = Get-RbacGroupRoleSuffix -RoleName $RoleName
    return "$prefix-$suffix"
}

function Test-RbacGroupNameMatch {
    param(
        [Parameter(Mandatory)][string]$GroupDisplayName,
        [Parameter(Mandatory)][string]$Prefix,
        [Parameter(Mandatory)][string]$Suffix
    )
    $n = $GroupDisplayName.ToLowerInvariant()
    $p = $Prefix.ToLowerInvariant()
    $s = ('-' + $Suffix.TrimStart('-')).ToLowerInvariant()
    return ($n.StartsWith($p) -and $n.EndsWith($s))
}

function Select-RbacGroupMatch {
    param(
        [object[]]$Groups = @(),
        [Parameter(Mandatory)][string]$SubscriptionName,
        [Parameter(Mandatory)][string]$RoleName
    )
    $suffix = Get-RbacGroupRoleSuffix -RoleName $RoleName
    $patterns = New-Object System.Collections.Generic.List[string]
    $slug = Get-NormalizedSubscriptionSlug -SubscriptionName $SubscriptionName
    $envTok = Get-EnvironmentTokenFromSlug -Slug $slug

    $tryPrefixes = New-Object System.Collections.Generic.List[string]
    if ($envTok) { [void]$tryPrefixes.Add((Get-RbacGroupSearchPrefix -SubscriptionName $SubscriptionName -IncludeEnvironment:$true)) }
    $fallback = Get-RbacGroupSearchPrefix -SubscriptionName $SubscriptionName -IncludeEnvironment:$false
    if (-not $tryPrefixes.Contains($fallback)) { [void]$tryPrefixes.Add($fallback) }

    foreach ($prefix in $tryPrefixes) {
        $patterns.Add("$prefix-*-$suffix")
        $hits = @($Groups | Where-Object { Test-RbacGroupNameMatch -GroupDisplayName $_.displayName -Prefix $prefix -Suffix $suffix })
        if ($hits.Count -eq 1) {
            return [pscustomobject]@{ Status = 'Matched'; Group = $hits[0]; Candidates = $hits; PatternsTried = $patterns.ToArray() }
        }
        if ($hits.Count -gt 1) {
            return [pscustomobject]@{ Status = 'Ambiguous'; Group = $null; Candidates = $hits; PatternsTried = $patterns.ToArray() }
        }
    }
    return [pscustomobject]@{ Status = 'None'; Group = $null; Candidates = @(); PatternsTried = $patterns.ToArray() }
}

function Test-GroupRbacDuplicateAccess {
    <#
    .SYNOPSIS
      True when the matching Entra RBAC group already exists AND the requester is a member.
      A different user on the same group is not a duplicate — they should still be added.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleName,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [string]$ResourceScope
    )

    $none = {
        param($GroupId, $GroupName)
        return [pscustomobject]@{
            Duplicate     = $false
            AlreadyMember = $false
            GroupId       = $GroupId
            GroupName     = $GroupName
            Reason        = $null
        }
    }

    try {
        [void](Get-RbacGroupRoleSuffix -RoleName $RoleName)
    }
    catch {
        return & $none $null $null
    }

    if (-not $SubscriptionId -and $ResourceScope -match '^/subscriptions/([^/]+)') {
        $SubscriptionId = $Matches[1]
    }
    if (-not $SubscriptionId) {
        return & $none $null $null
    }
    if (-not $SubscriptionName) {
        try {
            $SubscriptionName = Get-SubscriptionDisplayName -Client $Client -SubscriptionId $SubscriptionId
        }
        catch {
            return & $none $null $null
        }
    }

    try {
        $prefix = Get-RbacGroupSearchPrefix -SubscriptionName $SubscriptionName
        $groups = @(Find-EntraRbacGroups -Client $Client -DisplayNamePrefix $prefix |
                Where-Object { $_ -and $_.displayName })
        $match = Select-RbacGroupMatch -Groups $groups -SubscriptionName $SubscriptionName -RoleName $RoleName
        if ($match.Status -ne 'Matched' -or -not $match.Group) {
            return & $none $null $null
        }

        $group = $match.Group
        $already = [bool](Test-EntraGroupMember -Client $Client -GroupId $group.id -UserId $UserId)
        if ($already) {
            return [pscustomobject]@{
                Duplicate     = $true
                AlreadyMember = $true
                GroupId       = $group.id
                GroupName     = $group.displayName
                Reason        = "Requester is already a member of Entra group '$($group.displayName)' for this subscription and role. This is a duplicate access request."
            }
        }
        return & $none $group.id $group.displayName
    }
    catch {
        $err = "$_"
        if ($err -match 'Authorization_RequestDenied|Insufficient privileges|403|Forbidden') {
            return & $none $null $null
        }
        throw
    }
}

function New-GroupOrPimFallbackResult {
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$ResourceScope,
        [Parameter(Mandatory)][int]$DurationDays,
        [Parameter(Mandatory)][string]$Justification,
        [ValidateSet('Active', 'Eligible')]
        [string]$PimFallbackAssignmentType = 'Active',
        [Parameter(Mandatory)][string]$Reason,
        [string[]]$PatternsTried = @(),
        [Parameter(Mandatory)][string]$Message,
        $GroupId = $null,
        $GroupName = $null
    )

    $assignment = if ($PimFallbackAssignmentType -eq 'Eligible') {
        New-EligibleAssignment -Client $Client -UserId $UserId `
            -RoleDefinitionId $RoleDefinitionId -Scope $ResourceScope `
            -DurationDays $DurationDays -Justification $Justification
    }
    else {
        New-ActiveAssignment -Client $Client -UserId $UserId `
            -RoleDefinitionId $RoleDefinitionId -Scope $ResourceScope `
            -DurationDays $DurationDays -Justification $Justification
    }

    return [pscustomobject]@{
        Success                = $true
        Fulfilment             = 'PimFallback'
        GroupId                = $GroupId
        GroupName              = $GroupName
        AssignmentId           = $assignment.id
        GroupCreated           = $false
        RoleAssignmentCreated  = $false
        EngineerActionRequired = $true
        EngineerActionReason   = $Reason
        PatternsTried          = $PatternsTried
        Message                = $Message
    }
}

function Invoke-GroupOrPimGrant {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Client,
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$RoleName,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [Parameter(Mandatory)][string]$ResourceScope,
        [Parameter(Mandatory)][int]$DurationDays,
        [Parameter(Mandatory)][string]$Justification,
        [ValidateSet('Active', 'Eligible')]
        [string]$PimFallbackAssignmentType = 'Active'
    )

    # Validate that callers only use the group path for supported roles.
    [void](Get-RbacGroupRoleSuffix -RoleName $RoleName)

    if (-not $SubscriptionId -and $ResourceScope -match '^/subscriptions/([^/]+)') {
        $SubscriptionId = $Matches[1]
    }
    if (-not $SubscriptionId) {
        throw "SubscriptionId is required or must be present in ResourceScope."
    }
    if (-not $SubscriptionName) {
        $SubscriptionName = Get-SubscriptionDisplayName -Client $Client -SubscriptionId $SubscriptionId
    }

    $roleDefinitionId = Get-RoleDefinitionId -RoleName $RoleName
    $match = $null

    try {
        $prefix = Get-RbacGroupSearchPrefix -SubscriptionName $SubscriptionName
        $groups = @(Find-EntraRbacGroups -Client $Client -DisplayNamePrefix $prefix |
                Where-Object { $_ -and $_.displayName })
        $match = Select-RbacGroupMatch -Groups $groups -SubscriptionName $SubscriptionName -RoleName $RoleName
    }
    catch {
        $err = "$_"
        if ($err -match 'Authorization_RequestDenied|Insufficient privileges|403|Forbidden') {
            return New-GroupOrPimFallbackResult -Client $Client -UserId $UserId `
                -RoleDefinitionId $roleDefinitionId -ResourceScope $ResourceScope `
                -DurationDays $DurationDays -Justification $Justification `
                -PimFallbackAssignmentType $PimFallbackAssignmentType `
                -Reason "Graph group APIs forbidden for automation SPN - grant and admin-consent Group.ReadWrite.All (Application) on the SPN. Detail: $err" `
                -Message 'PIM assignment granted because the automation identity cannot read/create Entra groups yet.' `
                -PatternsTried @()
        }
        throw
    }

    # Ambiguous names are unsafe to auto-create against - keep PIM fallback + engineer flag.
    if ($match.Status -eq 'Ambiguous') {
        $patterns = [string[]]$match.PatternsTried
        $reason = "Group setup missing or ambiguous - engineer manual check required. Status=Ambiguous. PatternsTried=$($patterns -join ', ')."
        return New-GroupOrPimFallbackResult -Client $Client -UserId $UserId `
            -RoleDefinitionId $roleDefinitionId -ResourceScope $ResourceScope `
            -DurationDays $DurationDays -Justification $Justification `
            -PimFallbackAssignmentType $PimFallbackAssignmentType `
            -Reason $reason -PatternsTried $patterns `
            -Message 'PIM assignment granted because multiple matching RBAC groups were found.'
    }

    $group = $null
    $groupCreated = $false
    $groupAlreadyExisted = $false
    $roleAssignmentCreated = $false
    $memberResult = $null

    try {
        if ($match.Status -eq 'Matched') {
            $group = $match.Group
            $groupAlreadyExisted = $true
        }
        else {
            # No matching group - create the canonical sg-<slug>-contributors|readers group.
            $canonicalName = Get-CanonicalRbacGroupDisplayName -SubscriptionName $SubscriptionName -RoleName $RoleName
            $created = New-EntraRbacGroup -Client $Client -DisplayName $canonicalName
            $group = $created
            if ($created.AlreadyExisted) {
                $groupAlreadyExisted = $true
                $groupCreated = $false
            }
            else {
                $groupCreated = $true
            }
        }

        $iamReady = Test-GroupHasSubscriptionRole -Client $Client -GroupId $group.id `
            -SubscriptionId $SubscriptionId -RoleDefinitionId $roleDefinitionId
        if (-not $iamReady) {
            $ra = New-GroupSubscriptionRoleAssignment -Client $Client -GroupId $group.id `
                -SubscriptionId $SubscriptionId -RoleDefinitionId $roleDefinitionId
            $roleAssignmentCreated = -not [bool]$ra.AlreadyExisted
        }

        $memberResult = Add-EntraGroupMember -Client $Client -GroupId $group.id -UserId $UserId
    }
    catch {
        $err = "$_"
        if ($err -match 'Authorization_RequestDenied|Insufficient privileges|403|Forbidden') {
            return New-GroupOrPimFallbackResult -Client $Client -UserId $UserId `
                -RoleDefinitionId $roleDefinitionId -ResourceScope $ResourceScope `
                -DurationDays $DurationDays -Justification $Justification `
                -PimFallbackAssignmentType $PimFallbackAssignmentType `
                -Reason "Graph group write forbidden for automation SPN - grant and admin-consent Group.ReadWrite.All (Application) on the SPN. Detail: $err" `
                -Message 'PIM assignment granted because the automation identity cannot create groups or add members yet.' `
                -PatternsTried ([string[]]$match.PatternsTried) `
                -GroupId $(if ($group) { $group.id } else { $null }) `
                -GroupName $(if ($group) { $group.displayName } else { $null })
        }
        throw
    }

    $msgParts = New-Object System.Collections.Generic.List[string]
    if ($groupAlreadyExisted) {
        [void]$msgParts.Add("Entra group '$($group.displayName)' already exists.")
    }
    elseif ($groupCreated) {
        [void]$msgParts.Add("Created Entra group '$($group.displayName)'.")
    }
    if ($roleAssignmentCreated) { [void]$msgParts.Add('Assigned the role to the group at subscription scope.') }
    if ($memberResult -and $memberResult.AlreadyMember) {
        [void]$msgParts.Add("User was already a member of '$($group.displayName)'.")
    }
    else {
        [void]$msgParts.Add("User added to Entra RBAC group '$($group.displayName)'.")
    }

    return [pscustomobject]@{
        Success                = $true
        Fulfilment             = 'Group'
        GroupId                = $group.id
        GroupName              = $group.displayName
        AssignmentId           = $null
        GroupCreated           = $groupCreated
        GroupAlreadyExisted    = $groupAlreadyExisted
        RoleAssignmentCreated  = $roleAssignmentCreated
        EngineerActionRequired = $false
        EngineerActionReason   = $null
        PatternsTried          = [string[]]$match.PatternsTried
        Message                = ($msgParts -join ' ')
    }
}
