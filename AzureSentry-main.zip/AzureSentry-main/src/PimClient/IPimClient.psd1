# IPimClient contract — methods required by runbooks (scope §8.2, BUILD_PLAN §5.2)
# Implementations: GraphPimClient (production), MockPimClient (tests only)

@{
    ContractVersion = '1.0'
    Methods         = @(
        @{
            Name        = 'ResolveUpnToObjectId'
            Parameters  = @('Upn')
            Returns     = 'string (Entra object ID)'
            Description = 'GET /users/{upn}'
        },
        @{
            Name        = 'GetActiveAssignments'
            Parameters  = @('UserId', 'RoleDefinitionId', 'Scope')
            Returns     = 'array of assignment objects'
            Description = 'Query active PIM assignments for dedup (§4.1 step 5)'
        },
        @{
            Name        = 'CreateActiveAssignment'
            Parameters  = @('UserId', 'RoleDefinitionId', 'Scope', 'DurationDays', 'Justification')
            Returns     = 'assignment request object with Id'
            Description = 'POST /roleAssignmentScheduleRequests (Activated)'
        },
        @{
            Name        = 'CreateEligibleAssignment'
            Parameters  = @('UserId', 'RoleDefinitionId', 'Scope', 'DurationDays', 'Justification')
            Returns     = 'eligibility request object with Id'
            Description = 'POST /roleEligibilityScheduleRequests (AdminAssign)'
        },
        @{
            Name        = 'GetApprovalDecision'
            Parameters  = @('RequestId')
            Returns     = 'Pending|Approved|Denied|Expired + reviewer metadata'
            Description = 'GET /roleEligibilityScheduleRequests/{id}'
        },
        @{
            Name        = 'RevokeAssignment'
            Parameters  = @('AssignmentId', 'Scope')
            Returns     = 'revocation request object'
            Description = 'POST role assignment schedule revoke (break-glass reaper G3)'
        }
    )
}
