# AzureSentry — Progress Tracker

> **Last updated:** 2026-08-21  
> **Authority:** `docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md` §13  
> **Governance review:** `docs/AzureSentry_Governance-Feedback.md` — status in the [Governance review](#governance-review-implementation-status) section  
> **Plan:** `docs/BUILD_PLAN.md` (§7 phases, §12 dashboard roadmap, deploy commands)  
> **Low-level design:** `docs/LLD.md` — agent architecture, eligibility matrix, prioritization model, audit design (moved out of the app per FR5)  
> **Superseded:** `.azure/deployment-plan.md` — deploy detail folded into BUILD_PLAN §7 Phase 3 and §9

---

## Executive summary


| Metric                          | Value                                                                                                                                                                                                                                                                                                                                                                        |
| ------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Current phase (operational)** | **Phase 3** — Build Core exit **not met**                                                                                                                                                                                                                                                                                                                                    |
| **Code readiness**              | Phases 3–4 runbooks **authored**; decision engine **complete**; Help Desk process/revoke path **live with Graph/ARM SPN**; **group Reader/Contributor fulfilment**; **per-template ME field schemas** (UI + `templatePayload` + grant gate — Azure Subscription only grants today); **unattended poller + grant reaper shipped inert** (see [Unattended access provisioning](#unattended-access-provisioning--poller--reaper-2026-08-19--2026-08-21)) |
| **Tests**                       | **562/562 Pester PASS** (2026-08-21) on **both PS 5.1 and pwsh 7**; `tsc --noEmit` clean; `npm run build` succeeds. Mock E2E 5/5. Safety-critical paths are mutation-tested, not just asserted |
| **Unattended granting**         | **Built, not enabled.** Poller + reaper both require their env switch set to exactly `true` and both default to `shadow`. Live shadow: `examined=53 wouldGrant=0` — every requested subscription is outside `mg-incep-sandbox`, which is a governance decision, not a code gap |
| **Deployed to Azure**           | **No** — infra, runbooks, policy, ME webhook all pending; local dashboard + optional VM host documented                                                                                                                                                                                                                                                                      |
| **ManageEngine integration**    | **Live** — Identity Management / IDAM Team queues; process + revoke; **ticket type** + **schema-driven request fields** per ME template name; Azure Subscription grant path; other templates → structured intake + audit (`TemplateIntake`); requester-visible notes |
| **Next critical path**          | ~~Graph consent (B1)~~ resolved via SPN → ~~sandbox + §6.1 (B3)~~ → **2.1 P2 written confirm** → deploy infra (B2) → live Sandbox Automation E2E                                                                                                                                                                                                                             |


---

## Governance review implementation status

Source: `docs/AzureSentry_Governance-Feedback.md` (stakeholder review). Implemented 2026-08-17.
Design detail for everything below is in `docs/LLD.md`.


| Req      | Ask                                                                                                                                                                  | Status                                                                   | Where                                                                                                                                                                                                                                                                                     |
| -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **FR1**  | Environment mandatory; prioritization keys off environment, not declared priority                                                                                    | ✅ **Code complete**                                                      | `Get-TicketCriticality` (env band dominates, priority is a within-band tiebreaker only, `PriorityDemoted` flag); Execution Hub checklist blocks evaluate/grant without an environment; Dashboard queue sorted by criticality. **ME template dropdown change still owned by Siva/IT Ops.** |
| **FR2**  | Environment backfill: deterministic for dropdown, LLM for free text (flagged inferred), split report for Siva, batched writes, Sandbox+NonProd only, rollback        | ➖ **Obsoleted 2026-08-21 — page removed**                     | Environment is now MANDATORY on all four structured ME templates and is populated on 22/22 tickets created since 2026-08-18, so inference/backfill no longer applies to new tickets. The Execution Hub page was removed 2026-08-19                                 |
| **FR3**  | Provisioning as an agent calling APIs; multi-subscription disambiguation; NonProd enabled, Prod gated                                                                | ✅ **Agent runtime + disambiguation complete**; ⏳ live demo grant pending | `AgentRuntime.ps1` (7-agent registry, run ids, audit); `Resolve-TicketSubscription` (exact → env filter → human, never all matches); provisioning already ARM/Graph REST, now routed and audited as `AccessProvisioningAgent`. **Live end-to-end sign-off demo still outstanding.**       |
| **FR4**  | Expand scope to Infrastructure; categorize ~480 tickets by actionable type                                                                                           | ✅ **Run against live data 2026-08-19**; ⏳ Infrastructure provisioning not enabled | 447 live Infrastructure tickets categorized: **257 actionable (57.5%)** — 112 fully automatable, 145 need a human audit (credential/resource-minting work types), 11 unclassified. **Below the review's 300-400 target range** — largest non-actionable buckets are NetworkChange (91, out of scope by design) and Troubleshooting (54, needs an engineer). Detail: `docs/infrastructure-categorization-2026-08-19.csv`. `TicketCategorizationAgent` (11 work types, actionable + human-audit flags); Execution Hub → Department Scope; `config.departmentScope` bands |
| **FR5**  | Rename to Execution Hub; Audit Logs view; 3 core menus; Coming Soon; matrix/architecture → LLD; donut chart; dedupe dept charts; remove dummy data; Inception42 logo | ✅ **Complete**                                                           | `App.tsx` nav (Dashboard / Execution Hub / Audit Logs); `AuditLogsView`; `docs/LLD.md`; donut + volume charts were already deduped and were already a donut; `demoSeed.enabled=false`; `inception42-logo.svg`                                                                             |
| **FR6**  | Every agent action audited with who/what/when + before/after; human validation before bulk commit; rollback; Log Analytics + KQL dashboards                          | ✅ **Local trail complete**; ✅ **LA code/infra complete 2026-08-19, not deployed** | `AuditLog.ps1` — append-only JSONL, SHA-256 hash chain, `Test-AuditChainIntegrity`; wired into decision, provision, revoke, summarize, governance writes and rollbacks. `LogAnalyticsClient.ps1` (DCR Logs Ingestion API, fail-open) + `loganalytics-audit-dcr.bicep` (table/DCE/DCR + KQL Workbook) — bicep-validated, blocked on **B2** infra deploy to go live |
| **NFR1** | Deploy to Azure VM                                                                                                                                                   | ❌ **Not started** — final step by design (B2)                            | `docs/vm-provisioning-plan.md`                                                                                                                                                                                                                                                            |
| **NFR2** | Seed/log every run; batched writes with checkpoints; rollback tested before first bulk run                                                                           | ✅ **Code + tests**                                                       | Governance journal checkpoints; rollback covered by unit tests (order, idempotency, single-ticket, compensating audit entry)                                                                                                                                                              |
| **NFR3** | Immutable append-only audit trail                                                                                                                                    | ✅ **Complete**                                                           | Hash-chained JSONL; tamper and gap detection tested                                                                                                                                                                                                                                       |
| **NFR4** | Least privilege per agent                                                                                                                                            | ✅ **Documented + structural**                                            | Registry records each agent's systems and permissions; LLM agents hold no Azure/ME scope; the ME write is injected as a scriptblock so the governance agent never holds ME credentials                                                                                                    |


### Open questions from the review — where they now stand


| Question                                                  | Resolution                                                                                                                                                                                                                                                                                      |
| --------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Multi-subscription ambiguity logic undefined              | **Resolved.** exact id → exact name → unique keyword → environment filter → `NeedsHumanChoice`. Never resolves to more than one. Verified live: "sandbox" matched 3 real subscriptions and the agent refused to choose.                                                                         |
| LLM environment-inference accuracy: no target/eval        | **Resolved 2026-08-19.** Labelled 48 `Azure Subscription`/LLM-sourced tickets (Rules-sourced results needed no correction). Baseline accuracy 37.5% — model over-guessed Unknown. Root-caused against the actual misses and encoded 4 new prompt rules (VPN-only → Unknown; revoke/offboard → Unknown, not the onboarding default; generic onboarding/access-grant → NonProd; onboarding or "working on" a **named project** → Production). Approved by Abdulla. **Re-run and re-score before the first bulk batch** to confirm the accuracy lift on a fresh sample. |
| The ~1165 'unknown' tickets — inferable or left untagged? | **Mechanism ready, decision still with the stakeholder.** They are inferred and reported with confidence; anything below threshold lands in `NeedsReview` rather than the write queue, so the decision is now per-ticket data rather than a blanket call.                                       |
| Priority + environment composite not formalized           | **Resolved.** `score = environmentRank*10 + priorityRank`; the multiplier exceeds max priority rank so priority provably cannot cross an environment boundary.                                                                                                                                  |
| All-department breadth                                    | **Resolved 2026-08-19 — real number now exists.** 257 of 447 live Infrastructure tickets (57.5%) are agent-actionable, below the review's 300-400 estimate. Worth a look before committing to Infrastructure expansion: NetworkChange (91) and Troubleshooting (54) make up most of the non-actionable set and are structurally out of scope, not a categorization miss. SOC/Networking remain out of scope in `config.departmentScope`.                                                                                                                              |
| Agent framework/runtime — biggest architecture decision   | **Resolved as "both".** Registry marks each agent `Deterministic` / `Llm` / `Hybrid`. Every Azure write is on a Deterministic agent, so a grant is never contingent on model output.                                                                                                            |


### Still blocked on people, not code


| Item                                                                                      | Owner                 |
| ----------------------------------------------------------------------------------------- | --------------------- |
| Make **Environment** a mandatory dropdown on the ManageEngine Azure Subscription template | Siva / IT Ops         |
| Validate the environment split report, then authorise batch 1 (`validatedBy`)             | Siva                  |
| Explicit go-ahead before any **Production** environment tagging or Prod provisioning      | Stakeholder           |
| One live end-to-end Contributor grant demoed for sign-off                                 | Abdulla + stakeholder |
| Deploy to Azure VM (NFR1)                                                                 | Abdulla               |


---

## Phase status dashboard


| Phase | Name             | Exit gate met? | Code                     | Live / tenant                                                                                                                      |
| ----- | ---------------- | -------------- | ------------------------ | ---------------------------------------------------------------------------------------------------------------------------------- |
| **1** | Design           | ✅ **Met**      | Docs ✅                   | Design signed off 2026-07-09 (`docs/phase1-signoff.md`); approver mapping done; 1.5/1.7/1.8 carried forward                        |
| **2** | PIM Config       | ⚠️ Near        | IaC ✅                    | §6.1 Role Settings **applied + verified** on sandbox (`inception-ai-Sandbox`); only P2 written confirmation (2.1) remains for exit |
| **3** | Build Core       | ❌ No           | ~95%                     | **Not deployed**; mock E2E only; group create/ensure + Eligible Provide Access coded                                               |
| **4** | Build Extended   | ❌ No           | ~60%                     | Runbooks coded; LA/ME integration missing                                                                                          |
| **5** | Integration Test | ❌ No           | ~40%                     | Mock tests only; no `tests/e2e/`                                                                                                   |
| **6** | UAT              | ❌ No           | 0%                       | —                                                                                                                                  |
| **7** | Prod Go-Live     | ❌ No           | 0%                       | —                                                                                                                                  |
| **8** | Handover         | ❌ No           | ~40% dashboard prototype | KQL workbook + training guide still missing                                                                                        |


---

## Active blockers (cross-phase)


| ID     | Blocker                                                                                | Owner                          | Blocks phases | Notes                                                                                                                                                                                                                                                                                    |
| ------ | -------------------------------------------------------------------------------------- | ------------------------------ | ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **B1** | ~~Graph admin consent (`PrivilegedAccess.ReadWrite.AzureResources`, `User.Read.All`)~~ | Global Admin / PRA             | 3, 5          | ✅ **Largely resolved 2026-07-08.** SPN `e2455957-…` has `User.Read.All` + UAA + ARM PIM write (verified real grant). `PrivilegedAccess.ReadWrite.AzureResources` is **not needed** — Azure resource PIM is ARM+UAA, not Graph. Only relevant if Entra *directory*-role PIM is ever added |
| **B2** | Infra not deployed (`deployRbac=false` then `true`)                                    | Cloud Engineer + cost approval | 3, 4          | Bicep validated; RG does not exist yet                                                                                                                                                                                                                                                   |
| **B3** | ~~Target sandbox subscription under `mg-incep-sandbox`~~                               | Cloud Team                     | 3 exit        | ✅ **Resolved 2026-07-09** — sandbox = `inception-ai-Sandbox` (`efae0e0e-09ab-4c17-82db-d2d1f4382d66`); §6.1 Role Settings applied                                                                                                                                                        |
| **B4** | Automation SP credentials / deployed MI for runbook execution                          | Phase 3 deploy                 | 3, 4          | SP obj `4e51d30b-…` exists; Automation Account MI not wired                                                                                                                                                                                                                              |
| **B5** | ~~Approver mapping (§6.3)~~                                                            | Cloud Governance               | 2, 6, 7       | ✅ **Resolved** — `docs/approver-mapping.md` filled; `approver-mapping.json` wired into decision engine                                                                                                                                                                                   |
| **B6** | ManageEngine webhook + ticket template                                                 | IT Ops                         | 4 exit        | Logic App testable via manual HTTP until then                                                                                                                                                                                                                                            |
| **B7** | P2 licensing confirmation in writing                                                   | IT / Procurement               | 2 formal gate | PIM appears to work in tenant                                                                                                                                                                                                                                                            |
| **B8** | Break-glass process + Security sign-off                                                | Governance + Security          | 7 emergency   | Emergency runbook coded; not enabled                                                                                                                                                                                                                                                     |


---

## Dependency chain (what unlocks what)

```
B1 Graph consent ──────────────┐
B2 Infra deploy ───────────────┼──► Phase 3 EXIT (Sandbox live E2E)
B3 Sandbox sub ID ─────────────┘
                                        │
B6 ME webhook ──────────────────────────┼──► Phase 4 EXIT (full ticket loop)
1.4 Approver mapping ──► Phase 2 ─────┼──► Prod approval meaningful
                                        │
                                        ▼
                               Phase 5 live e2e suite
                                        │
                               Phase 6 UAT sign-off
                                        │
                               Phase 7 (20 prod tickets)
                                        │
                               Phase 8 handover
```

**Parallel work:** Track A (B1–B4, deploy, wire LA) can proceed while Track B (B5–B8, governance) runs independently.

---

## Phase 1 — Design

**Exit criteria:** Scope signed off; approver mapping complete.  
**Status:** ✅ **MET / CLOSED (2026-07-09)** — stakeholders signed off on the design (see `docs/phase1-signoff.md`); approver mapping complete. 1.5/1.7/1.8 carried forward to their consuming phases.


| #    | Item                                 | Status | Blocker?                                                                       |
| ---- | ------------------------------------ | ------ | ------------------------------------------------------------------------------ |
| 1.1  | Scope doc in repo                    | ✅      | —                                                                              |
| 1.2  | BUILD_PLAN + progress aligned to §13 | ✅      | —                                                                              |
| 1.3  | Stakeholder sign-off (§16)           | ✅      | Signed off 2026-07-09 — `docs/phase1-signoff.md`                               |
| 1.4  | Approver mapping complete            | ✅      | `docs/approver-mapping.md` + `src/RbacDecision/Data/approver-mapping.json`     |
| 1.5  | Production allowlist finalized       | ⏭️     | **Carried forward** → Phase 2-prod / Phase 7 (Cloud Governance)                |
| 1.6  | Sandbox allowlist finalized          | ✅      | `inception-ai-Sandbox` (`efae0e0e`) confirmed 2026-07-09                       |
| 1.7  | Break-glass authorization process    | ⏭️     | **Carried forward** → Phase 7 (needs Security & Compliance Lead approval, §16) |
| 1.8  | ME ticket template + webhook schema  | ⏭️     | **Carried forward** → Phase 4                                                  |
| 1.9  | D1 deviation sign-off                | ✅      | Covered by design sign-off 2026-07-09                                          |
| 1.10 | Gap resolutions G3–G6 accepted       | ✅      | Approach accepted in sign-off; G3/G4 *implementation* continues in Phase 4     |


---

## Phase 2 — PIM Config

**Exit criteria:** PIM policies active in non-prod; P2 confirmed.  
**Scope note (2026-07-09):** assessed for **local-only deployment**. "PIM policies active in non-prod" ✅ done (2.7). Sole remaining gate = **2.1 P2 written confirmation** (functionally proven; evidence memo `docs/phase2-p2-evidence.md`). **2.6** (Automation MI) is N/A locally — the SPN is the local automation identity. **2.8–2.10** gate production go-live (Phase 6–7), not the non-prod/local close.  
**Status:** ⚠️ **Local/non-prod close pending only 2.1 (P2 written confirmation).**


| #    | Item                                                      | Status         | Notes                                                                                                                                                                           |
| ---- | --------------------------------------------------------- | -------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 2.1  | P2 licensing confirmed                                    | ⚠️             | Functionally proven (active + eligible PIM grants + role-settings PATCH all succeeded → P2 active). Written confirm pending IT/Procurement — memo: `docs/phase2-p2-evidence.md` |
| 2.2  | Automation SP created                                     | ✅              | **Canonical = `e2455957-63ef-41e9-bf10-9cfd2f625aea`** (obj `eabb6fe0-…`) — has UAA + `User.Read.All`, performed all grants. Legacy `d68581f3-…` superseded                     |
| 2.3  | UAA @ `mg-incep-sandbox`                                  | ✅              | Verified; SPN `e2455957` has UAA on sandbox + live subs                                                                                                                         |
| 2.4  | Graph consent `PrivilegedAccess.ReadWrite.AzureResources` | ✅ N/A          | **Obsolete** — Azure resource PIM uses **ARM + UAA**, not Graph `azureResources` (segment doesn't exist)                                                                        |
| 2.5  | Graph consent `User.Read.All`                             | ✅              | Verified PASS on SPN `e2455957` (guest-aware resolver)                                                                                                                          |
| 2.6  | Automation MI credentials (post-deploy)                   | ⏭️ N/A (local) | Locally the **SPN `e2455957`** is the automation identity. A deployed Automation Account MI is only needed for the Azure deploy → deferred to Phase 3 (B4)                      |
| 2.7  | Sandbox PIM Role Settings                                 | ✅              | **Applied 2026-07-09** to `inception-ai-Sandbox` (`efae0e0e`): no permanent active + 90-day cap, Reader+Contributor. Verified live                                              |
| 2.8  | Production PIM Role Settings                              | ⏭️             | **Out of scope for local/non-prod close** — gates prod go-live (Phase 6–7). IaC ready                                                                                           |
| 2.9  | Approvers assigned in PIM                                 | ⏭️             | **Out of scope for local/non-prod close** — prod go-live. Data ready; `-SetApprovers` populates                                                                                 |
| 2.10 | Role Settings peer review                                 | ⏭️             | **Out of scope for local/non-prod close** — Cloud Governance sign-off for prod                                                                                                  |
| 2.11 | `pim-rolesettings` IaC in repo                            | ✅              | `infra/pim/` — config JSON (§6.1/§6.2) + `Set-PimRoleSettings.ps1` + README                                                                                                     |


---

## Phase 3 — Build Core

**Exit criteria:** Sandbox auto-assign working end-to-end in dev.  
**Status:** ❌ **Not met** — strongest code phase; weakest operational phase

### Done (code + mock verification)


| Deliverable                   | Path                                    | Verified                                                          |
| ----------------------------- | --------------------------------------- | ----------------------------------------------------------------- |
| Decision engine (7-step tree) | `src/RbacDecision/`                     | Unit tests in `RbacDecision.Tests.ps1`                            |
| §2.2 eligibility matrix       | `Data/eligibility-matrix.json`          | Prod Reader → Grant (no approval); NonProd Contributor → Eligible |
| Graph + Mock PIM clients      | `src/PimClient/`                        | Contract tests incl. ARM AdminRemove + group IAM/membership       |
| Group-based RBAC fulfilment   | `GroupRbac.ps1` + runbooks + Help Desk  | Group-first Grant; PIM fallback + engineer flag; group revoke     |
| Sandbox / Grant runbook       | `Runbook-Sandbox-PIM.ps1`               | Mock: group add or PIM fallback                                   |
| Prod runbook                  | `Runbook-Prod-PIM.ps1`                  | Eligible PIM (native approval); Owner/UAA unchanged               |
| Decision router               | `Runbook-Decision-Router.ps1`           | 5-path E2E                                                        |
| Logic App skeleton            | `logicapp/workflows/orchestrator/`      | G2 secret check                                                   |
| Platform Bicep                | `infra/main.bicep` + modules            | build/lint clean                                                  |
| Azure Policy                  | `infra/policy/sandbox-guardrails.bicep` | compile clean                                                     |
| Mock E2E harness              | `tests/Run-LocalE2E.ps1`                | 5/5 PASS                                                          |


### Remaining (ordered — exit gate)


| #   | Item                                      | Depends on              | Status     |
| --- | ----------------------------------------- | ----------------------- | ---------- |
| 3.1 | Deploy infra (`deployRbac=false`)         | Cost approval           | ❌ **B2**   |
| 3.2 | Apply platform RBAC (`deployRbac=true`)   | 3.1, UAA on deployer    | ❌          |
| 3.3 | Upload runbooks                           | 3.1                     | ❌          |
| 3.4 | Deploy Logic App workflow                 | 3.1                     | ❌          |
| 3.5 | Key Vault secrets                         | 3.1                     | ❌          |
| 3.6 | Deploy sandbox policy                     | 2.3                     | ❌          |
| 3.7 | **Live Sandbox Reader/Contributor grant** | **B1**, 3.1–3.3, **B3** | ❌ **EXIT** |
| 3.8 | Ticket update after grant                 | Status-Updater wiring   | ❌          |
| 3.9 | Log Analytics decision events             | 3.1                     | ❌          |


### Deploy commands

See `docs/BUILD_PLAN.md` §7 Phase 3 and §9.

---

## Phase 4 — Build Extended

**Exit criteria:** All runbooks deployed; webhook connected to Logic App.  
**Status:** ❌ **Not met**


| #    | Item                            | Status                 |
| ---- | ------------------------------- | ---------------------- |
| 4.1  | Emergency runbook               | ✅ Authored + 8 tests   |
| 4.2  | Status-Updater runbook          | ✅ Authored + 6 tests   |
| 4.3  | BreakGlass-Reaper runbook       | ✅ Authored + 10 tests  |
| 4.4  | All runbooks in Automation      | ❌ Needs 3.3            |
| 4.5  | ME webhook → Logic App          | ❌ **B6**               |
| 4.6  | Logic App PIM polling (5 min)   | ❌ Not in workflow.json |
| 4.7  | Status-Updater on approve/deny  | ❌ Not wired            |
| 4.8  | Reaper schedule + grant store   | ✅ **Shipped 2026-08-21** — `GrantReaperAgent` + systemd timer (30 min); group grants now carry a tracked expiry (previously permanent); revocation shared with the dashboard via `GrantRevocation.ps1`. Ships inert (`AZURESENTRY_REAPER_ENABLED`), shadow by default |
| 4.9  | P1 on-call notifications        | ❌ Flags only           |
| 4.10 | LA error handling / concurrency | ❌                      |
| 4.11 | ME config guide (§11 #9)        | ❌ Missing              |
| 4.12 | KQL workbook (§11 #10)          | ❌ `kql/` missing       |


### Engine change (2026-06-27)

`Resolve-RbacDecision` propagates `ReviewHours` from matrix for break-glass (4h window).

---

## Phase 5 — Integration Test

**Exit criteria:** All test cases pass; zero P1 defects.  
**Status:** ❌ **Not met**


| Suite                         | Result                                                                                                                                     | Gap                    |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------- |
| Pester unit + contract        | Key suites **57/57** PASS (GroupOrPimGrant + PimClient + DashboardHelpers, 2026-08-17); full suite last recorded **120/120** on 2026-08-12 | —                      |
| Mock local E2E                | **5/5 PASS**                                                                                                                               | —                      |
| Live Azure e2e (`tests/e2e/`) | Missing                                                                                                                                    | §11 full scenario list |
| CI pipeline                   | Missing                                                                                                                                    | `pipelines/`           |


---

## Phases 6–8


| Phase          | Exit criteria                              | Status                                                                        |
| -------------- | ------------------------------------------ | ----------------------------------------------------------------------------- |
| **6 UAT**      | Sign-off from Governance, IT Ops, Security | ❌ Not started — needs Phase 5 + 1.3                                           |
| **7 Go-Live**  | 20 prod tickets without manual grants      | ❌ Not started — needs 2.8, 1.5, 6                                             |
| **8 Handover** | Training + dashboards + docs               | ❌ Dashboard prototype shipped; official KQL workbook + training guide missing |


---

## Unattended access provisioning — poller + reaper (2026-08-19 → 2026-08-21)

Everything in this section is **in the codebase and committed**. Nothing here is a plan.
Both agents ship **inert**: each requires its own env switch set to exactly `true`, and each
defaults to `shadow` (decide + record, write nothing).

### TicketPollerAgent — grants without a human click

`src/Agents/TicketPollerAgent.ps1`, `src/Agents/PollerGate.ps1`,
`src/Agents/MeTicketMapper.ps1`, entry `scripts/Invoke-TicketPollerCycle.ps1`,
units `infra/systemd/azuresentry-poller.{service,timer}`.

One cycle per invocation (systemd timer, 5 min): select ME tickets → map structured
dropdown fields → `Resolve-RbacDecision` (the **same** engine as the human path) → gate →
grant. All external calls are injected via a `-Context` hashtable, so the cycle is unit
testable with no live ManageEngine or Azure.

The gate (`Test-PollerAutoEligible`) requires **all four**: grant template, complete
structured mapping, `Action -eq 'Grant'`, and **effective** environment in Sandbox/NonProd.
It reads the decision's *effective* environment, not the ticket's claim, so subscription
sensitivity raising an environment to Production correctly drops the ticket out.

Deliberately **never** auto-executed: `Eligible` (its approval gate is the operator's
click in the dashboard), Production even for Reader (the matrix marks `prod-reader-*` as
`Grant` with no approver), `Hold`, `Reject`, `BreakGlass`.

Safety envelope: kill switch, shadow/enforce, per-cycle grant cap, ticket-age window
(bounds cold start), a `poller.stop` sentinel re-checked per iteration, and fail-closed on
the first execution error. Shadow's preview counts `granted + wouldGrant` against the cap
so the preview matches what enforce would actually do.

**Enforce Mode dashboard toggle (2026-08-23).** `Get-PollerConfig` gained
`-ModeOverrideFilePath`: when `dashboard/api/poller.mode` exists, its content (`enforce` /
`shadow`) decides ahead of `AZURESENTRY_POLLER_MODE`, checked fresh every cycle — a typo or
half-written file fails closed to shadow, same contract the env var already has. New
`POST`/`DELETE /api/poller/mode` (`Start-DashboardApi.ps1`, ≥4-char justification required
to switch to enforce, both actions audited as `SetModeOverride`/`ClearModeOverride`) and an
**Enforce Mode** control on the Poller Status panel (`PollerStatusPanel.tsx`) — inline
confirm, states the change applies to the poller's *next* cycle, not immediately, since the
poller is a separate process. Does **not** touch the `AZURESENTRY_POLLER_ENABLED` kill
switch, which stays server-side only. `scripts/Deploy-ToVm.ps1` excludes `poller.mode` the
same way it already excludes `poller.stop`. 6 new Pester cases in
`TicketPollerAgent.Tests.ps1` (568/568 total). Docs:
`docs/ticket-poller-runbook.md` § "Toggle Enforce Mode from the dashboard",
`docs/DEMO_GUIDE.md` §8.4.

ManageEngine write-back (`dashboard/api/ManageEngineNotes.ps1`): note + ticket resolve on
success, failure note on failure (no resolve), nothing in shadow. Closure field keys live
in `config.json` under `manageEngine.closureFields` and are **operator-unverified** — the
`_help` there says so.

### GrantReaperAgent — expiry and self-healing revocation

`src/Agents/ReaperAgent.ps1`, entry `scripts/Invoke-ReaperCycle.ps1`, units
`infra/systemd/azuresentry-reaper.{service,timer}` (30 min).

Group-fulfilment grants previously recorded `expiresAt = $null` — Entra group membership
has no native timer — so every unattended grant was **permanent**. Both grant paths now
record an expiry via `Get-GrantExpiryTimestamp`, and the reaper revokes what has passed it.

The distinction is load-bearing and is recorded on every grant audit event:

| Fulfilment | Expiry kind | Meaning |
| --- | --- | --- |
| PimFallback | `AzureEnforced` | ARM times the assignment out itself, even if this platform is entirely down |
| Group | `TrackedOnly` | Nothing in Azure enforces it. **The reaper is the only thing that will act.** |

Consequence worth planning around: reaper uptime is an availability requirement for group
grants, not a nicety. `Get-ExpiredUnrevokedCount` is computed **before** the enabled/stop
gates so a disabled reaper cannot report a reassuring `0`; it surfaces as
`expiredUnrevoked` in `reaper-status.json` and on the Overview.

Revocation logic is shared with the dashboard's revoke route via
`dashboard/api/GrantRevocation.ps1` — one implementation, not two.

**Enforce Mode dashboard toggle (2026-08-23), mirrors the poller's.** `Get-ReaperConfig`
gained `-ModeOverrideFilePath`; `POST`/`DELETE /api/reaper/mode` write/clear
`dashboard/api/reaper.mode`, checked ahead of `AZURESENTRY_REAPER_MODE`, same fail-closed
contract, same ≥4-char justification, same audit events
(`GrantReaperAgent`/`SetModeOverride`/`ClearModeOverride`), same "next cycle, not
immediately" caveat rendered on `ReaperStatusPanel.tsx`. Kill switch
(`AZURESENTRY_REAPER_ENABLED`) stays server-side only. `Deploy-ToVm.ps1` excludes
`reaper.mode`. 6 new Pester cases (574/574 total).

### Modules extracted from `Start-DashboardApi.ps1`

That script starts an `HttpListener` at top level, so it cannot be dot-sourced. Anything
the poller/reaper needed had to become a sourceable module rather than a second copy:

`ProcessedStore.ps1` · `MeAccessFields.ps1` · `AccessPromotion.ps1` ·
`ManageEngineNotes.ps1` · `GrantRevocation.ps1` · `SubscriptionAllowlist.ps1`

### Processed-ticket store — redesigned

One JSON file forced read-modify-write, which forced a cross-process lock. Two lock
designs (named mutex, then `O_EXCL` lockfile) each produced Critical defects under review.
The store is now **one file per ticket, with no lock**: `Request-ProcessedTicketClaim` uses
a single atomic `File.Open(CreateNew)` as the mutual-exclusion primitive. The poller claims
a ticket **before** granting and does the slow work outside any exclusive section.

Filenames are the sanitised ticket id plus a **SHA1** suffix (never `GetHashCode()`, which
is per-process randomised on .NET Core); the original id lives inside each file.

### Policy change (2026-08-21, operator decision)

`nonprod-contributor`: `Eligible` → **`Grant`**. Contributor is the bulk of Non-Prod demand
(of 28 sampled Azure Subscription tickets, nearly all Contributor, a handful Reader), so
with it gated behind an approver the unattended path could act on roughly 1 ticket in 28.
The reaper is what makes this defensible — a wrong grant now self-revokes.

**This matches the Contributor _tier_**, so `Azure Kubernetes Service RBAC Writer` is
auto-granted in NonProd too. Pinned by a test in `RbacDecision.Tests.ps1`. Production
Contributor stays `Eligible`; Owner/UAA stay excluded.

### Removed

- **Request Simulator page** — ran the real decision engine on one button but hardcoded
  `AZURESENTRY_PIM_CLIENT=Mock` on the other, so "Simulate Full Grant" could never touch
  real PIM regardless of configuration. Page, `/api/simulate`, and the mock-grant branch
  in `Invoke-TicketEvaluate` all removed. `/api/evaluate` is unchanged.
- **Environment Governance — page and backend** (UI removed 2026-08-19, backend
  2026-08-21). Environment is now mandatory on all four structured ME templates and is
  populated on **22/22 tickets created since 2026-08-18**, so inference/backfill no longer
  applies to new tickets. Gone: `SentryGovernanceAgent.ps1` (plan/apply/rollback/status +
  governance journal), the LLM-inference half of `EnvironmentInferenceAgent.ps1`, the
  `/api/governance/environment/*` routes, the registry entry, and the two labeling-sample
  operator scripts that called them.

  **Deliberately kept:** the four *deterministic* helpers the Overview and Execution Hub
  use to resolve each ticket's environment (`Test-IsStructuredEnvironmentTemplate`,
  `Get-CanonicalEnvironmentFromDropdown`, `Get-RuleBasedEnvironment`,
  `Test-IsGitHubEnterpriseTemplate`) — moved unchanged into
  `dashboard/api/EnvironmentResolution.ps1` rather than left orphaned in a file named
  after a deleted agent. Deleting that file outright would have silently broken the
  Overview's `environment` / `environmentSource` display. Verified after removal against
  live ME: `/api/manageengine/analytics` returns 2000 tickets, all still carrying a
  resolved environment and source. `/api/governance/categorize` also stays — Department
  Scope uses it.

  **Trade accepted:** this removes the only tooling for backfilling the pre-2026-08-18
  backlog. Those tickets keep whatever Environment they have and queue for a human.

### Bugs found and fixed during this work

- **ME `udf_fields` are empty on the list endpoint.** Only `GET /api/v3/requests/{id}`
  populates them, even when `udf_fields` is named in `fields_required`. The poller read
  them off the list response, so **every** ticket mapped as "dropdowns blank" and
  `wouldGrant` was structurally pinned at 0. Verified on ticket 4868: list → 0 populated
  keys; detail → 7, including `Environment = Development`.
- **Poller read the wrong `.env`** (`dashboard/api/.env`, which does not exist) while the
  dashboard reads repo-root `.env`. Every run silently had no credentials.
- **Poller grants were unrevocable.** The group path returns `Fulfilment`/`GroupId` with
  `AssignmentId` unset; the poller dropped `groupId`, so `Test-GrantRevocable` returned
  false and Revoke gave HTTP 404.
- **Poller bypassed the promotion ladder** the dashboard enforces (`enforceLadder: true`),
  making the unattended path *more permissive* than the human path.
- **Deploy shipped developer state** — `.env`, `llm.env`, and `audit-log.jsonl` (which
  would have overwritten the VM's tamper-evident chain on every deploy). Also never
  shipped `scripts/` or `infra/`, so the poller could not have run on the VM at all.
- **`theme.ts` used MUI v5 combined `styleOverrides` keys** absent in MUI v9, so
  `npm run build` failed and `dist/` never regenerated.

### Current live state (read-only shadow, 2026-08-20/21)

```
examined=53  wouldGrant=0  granted=0  queued=53  failed=0
  50x  template is Cortex / GitHub Enterprise / ADO -- no grant handler (out of scope by design)
   3x  subscription is outside mg-incep-sandbox entirely
```

Nothing is blocked on code. Of 28 Azure Subscription tickets sampled, the requested
subscriptions (`aegis-dev`, `koreai-preprd`, `koreai-prod`, `incp-inalpha-dev`,
`ceo-sub-application`, …) are **not** under `mg-incep-sandbox`, so neither the dashboard
nor the poller can grant them. That is an Azure governance decision, not an engineering one.

### Tests

**562/562 Pester pass on Windows PowerShell 5.1 _and_ pwsh 7**; `tsc --noEmit` clean;
`npm run build` succeeds. Suites added: `ProcessedStore`, `MeAccessFields`,
`MeTicketMapper`, `PollerGate`, `TicketPollerAgent`, `ReaperAgent`, `AccessPromotion`,
`GrantRevocation`, `ManageEngineNotes`, `SubscriptionAllowlist`.

Safety-critical behaviour is **mutation-tested**, not merely asserted — repeatedly during
this work a passing test proved not to fail when the behaviour it named was removed.
Verified to fail on mutation: the atomic write, the claim primitive, the grant cap
(`-ge`→`-gt`), the fail-closed guard, the ticket-age window, the expiry comparison, and
both `Eligible`/`Production` exclusions in the gate.

---

## Verification commands (no deploy)

```powershell
# Full unit + contract suite (562 tests; passes on PS 5.1 and pwsh 7)
powershell -File tests\Run-Pester.ps1

# Mock end-to-end — all 5 decision paths
powershell -File tests\Run-LocalE2E.ps1

# Single-ticket router test
$env:AZURESENTRY_PIM_CLIENT = 'Mock'
$ticket = @{
    ticketId = 'TEST-001'; role = 'Reader'; environment = 'Sandbox'
    subscriptionId = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    resourceScope = '/subscriptions/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    durationDays = 7; priority = 'P3'
    requesterUpn = 'test.user@contoso.com'
    submitterUpn = 'test.user@contoso.com'
    justification = 'Test access'
}
& src/Runbooks/Runbook-Decision-Router.ps1 `
    -TicketJson ($ticket | ConvertTo-Json -Compress) `
    -SubscriptionAllowlist 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
```

Mock seeded user: `test.user@contoso.com` → `11111111-1111-1111-1111-111111111111`

---

## Dashboard — current progress

The dashboard evolved from a **decision-engine demo** into a **monitoring + live-operation tool**. It is **not** the production observability stack (that is Deliverable #10 — KQL workbook in Log Analytics) but is the working prototype stakeholders have seen in demos.

### Status summary


| Area                        | Status            | Notes                                                                                                                                |
| --------------------------- | ----------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| Decision engine integration | ✅ **Real**        | Calls `Resolve-RbacDecision` — same module as runbooks                                                                               |
| Mock PIM simulation         | ➖ **Removed 2026-08-19** | The Request Simulator page hardcoded `AZURESENTRY_PIM_CLIENT=Mock`, so its "Simulate Full Grant" could never reach real PIM whatever the config said. `MockPimClient` survives for unit/contract tests only |
| Live PIM (Azure)            | ✅ **Proven**      | ARM token path on `inception-internal-product`                                                                                       |
| Monitoring views            | ❌ **Coming Soon**, except Expiry | Seed data removed (`demoSeed.enabled=false`). SLA / Break-Glass stay disabled until Log Analytics is wired (D1–D3). **Expiry Tracking shipped live 2026-08-23** — reads `dashboard/api/processed-tickets/` (durable, cross-process with the poller) instead of seed data |
| Log Analytics backend       | ✅ **Code + infra complete 2026-08-19; not yet deployed** | `LogAnalyticsClient.ps1` forwards every audit event via the DCR Logs Ingestion API (fail-open, no-op until configured); `infra/modules/loganalytics-audit-dcr.bicep` provisions the custom table/DCE/DCR + `Microsoft.Insights/workbooks` KQL dashboard (`kql/azuresentry-workbook.json`, 5 `.kql` files); RBAC-wired for the automation SPN. `az bicep build` clean. Blocked on **B2** (infra deploy) to actually go live — the local append-only trail (`AuditLog.ps1`) remains the system of record regardless. Diagnostic: `scripts/Test-LogAnalyticsAccess.ps1` |
| ManageEngine integration    | ✅ **Live**        | Tickets fetched, evaluated, processed/revoked (Graph/ARM SPN); requester notes + email via ME public-note rules                      |


### Views shipped (all present in `dashboard/web`)

Restructured 2026-08-17 to the FR5 information architecture — three core menus, no dummy data.


| View                                       | Tab id                    | Data source                                                                                                         | Notes                                                                                         |
| ------------------------------------------ | ------------------------- | ------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| **Dashboard**                              | `overview`                | Live ME analytics: department, category, environment, ticket type, **criticality band**, **environment tag health** | Core. Queue ordered by environment-first criticality                                          |
| **Execution Hub** → Ticket Queue           | `tickets` / `queue`       | **Live ManageEngine API**                                                                                           | Core. Intake, decision, group/PIM grant, revoke. Environment now a required selection         |
| **Execution Hub** → Department Scope       | `tickets` / `scope`       | Live ME + categorization agent                                                                                      | Core. FR4 actionability report + agent registry                                               |
| **Audit Logs**                             | `audit`                   | **Live append-only audit trail**                                                                                    | Core. Replaces the old seed-backed "Access Audit" view; includes chain-integrity verification |
| Poller status panel                        | `overview`                | Live `poller-status.json`                                                                                           | Read-only view of the last unattended cycle: mode, would-grant vs granted, per-ticket queue reasons |
| Reaper status panel                        | `overview`                | Live `reaper-status.json`                                                                                           | Read-only. Surfaces staleness and the expired-but-unrevoked count |
| Live PIM (Azure)                           | `livepim`                 | **Real ARM PIM APIs**                                                                                               | Engineering tool                                                                              |
| SLA Compliance                             | `sla`                     | —                                                                                                                   | **Coming Soon** (disabled). Was seed-only; returns with Log Analytics (D1–D3)                 |
| Expiry Tracking                            | `expiry`                  | **Live `dashboard/api/processed-tickets/`** (`Get-AssignmentRecords`, `DashboardHelpers.ps1`) | **Shipped 2026-08-23**. Every non-revoked grant with a recorded expiry, from both the human path and the poller; durable across API restarts. Enforcement column distinguishes Azure-enforced (PimFallback) from reaper-tracked (Group, no native Azure expiry) — inferred for pre-`fulfilment`-field legacy records from `assignmentId`/`groupId` presence |
| Break-Glass                                | `breakglass`              | —                                                                                                                   | **Coming Soon** (disabled). Was seed-only                                                     |
| ~~Eligibility Matrix~~                     | —                         | —                                                                                                                   | **Removed from the app** → `docs/LLD.md` §2                                                   |
| ~~Architecture~~                           | —                         | —                                                                                                                   | **Removed from the app** → `docs/LLD.md` §1                                                   |


### Live Azure PIM integration (real — not mock)

Implemented 2026-06-25 / extended 2026-06-26:

- `**dashboard/api/AzurePim.ps1`** — live PIM client using signed-in `az` session token against ARM PIM endpoints (`roleEligibilityScheduleInstances`, `roleAssignmentScheduleInstances`, `roleAssignmentScheduleRequests`). No service principal / Graph app registration required for the demo operator.
- **API routes** (`Start-DashboardApi.ps1`): `/api/pim/status`, `/eligible`, `/active`, `/activate`, `/deactivate`.
- **Decision-gated activation:** `/api/pim/activate` runs the real 7-step `Resolve-RbacDecision` first; only `Grant` / `Eligible` / `BreakGlass` proceed to a real PIM call. `Reject` / `Hold` / `Schema-Invalid` are blocked with **no Azure call** (verified).
- `**dashboard/web/src/views/LivePimView.tsx`** — session banner, eligible-role activation form, two-step confirm, decision + result panel, live assignments table with deactivate.
- `**dashboard/api/config.json**` — `azure` block (real subscription) + `pimClient: Mock` toggle for simulator-only paths.

### Verified live (2026-06-25)

A real **1-hour Contributor activation** on `inception-internal-product` succeeded end-to-end (no MFA block on activation). Confirmed independently via ARM `roleAssignments` query — concrete Contributor assignment at activation time. The activation appeared in the dashboard live table as `ACTIVATED` with countdown and a working **Deactivate** control, and in the Access Audit log (`mode=live`).

**Bug fixed:** React key collision in `ExpiryView` (mock path reused `mock-active-1`).

### ManageEngine integration (2026-07-01 to 2026-08-17)

End-to-end ticket processing flow via ManageEngine ServiceDesk Plus:

- `**dashboard/web/src/views/TicketsView.tsx`** — Help Desk Tickets tab. Fetches identity-queue tickets, shows **ticket type** chip (ME template name: Azure Subscription, Infrastructure, ADO, GitHub Enterprise, …), and a **schema-driven Request fields** panel (not always Azure Subscription). Read-only fields preserve audit trail; grant controls only for Azure Subscription.
- **Resolved/closed tickets hidden by default (2026-08-23).** `/api/manageengine/requests` fetches every ticket with no status filter (by design — the API still needs to serve a resolved ticket's history on request); the Status dropdown defaulted to "All" and reset on every reload, so the queue always showed its full history including Resolved/Closed/Cancelled tickets with no lasting way to hide them. Now defaults to open-only, hiding the same three statuses (`Resolved`, `Closed`, `Cancelled`) the unattended poller's own fetch already treats as done (`scripts/Invoke-TicketPollerCycle.ps1`), with an explicit "All statuses" option and a per-status picker still available, plus a "N resolved/closed/cancelled hidden" caption when any are hidden. Confirmed against live data: 4 of 11 fetched IDM/IDAM tickets were `Resolved` and are now hidden by default.
- **Per-template schemas (2026-08-17):** Spec `docs/ticket-templates.md` / design `docs/superpowers/specs/2026-08-17-ticket-templates-design.md`. Registry in `ticketTemplateSchemas.ts` + `TicketTemplates.ps1`. Label-based UDF extraction → `templatePayload` on detail GET. Non–Azure Subscription → structured intake + `TemplateIntake` audit; evaluate/process gated (`Unsupported-Template`).
- **ME field parsing (2026-08-17):** Azure Subscription template → **Subscription** (`udf_pick_3728`), **Azure Role** (`udf_pick_3729`), **Environment** (`udf_pick_3719`) as fast-path overrides; other schema fields via labels. Does **not** use legacy **Environments Required** (`udf_sline_3715`). Maps Development/Test → NonProd, Sandbox/Production accordingly.
- **Priority (current):** Help Desk soft-defaults Priority to **P4** when ManageEngine priority is missing/unclear (`guessPriority`). Operators are **not required** to select Priority in the validation checklist today. Scope §7 treats Priority as a required ME dropdown that drives SLA/escalation; full **Priority Classification** (§3.2 step 5) is tracked as future work (D11).
- **Queues:** Identity Management (`IDM`) and Identity and Access Management Team (`IDAM Team`) — UI shows full names; filter matches both abbreviations.
- `**POST /api/manageengine/process`** — Evaluates via the 7-step tree, then **group-first Grant** (`Invoke-GroupOrPimGrant`) or Eligible PIM. Posts a **requester-visible** ME note (`show_to_requester=true`; email via ME “Note has been added” rules). Group grants: permanent membership, group name, no false expiry. PIM fallback: engineer-action note. Idempotent re-process can backfill notify (persists `Fulfilment` / `GroupId`).
- **Duplicate access (group path, 2026-08-13):** If matching `sg-…` group **exists** and the **requester is already a member** → `Duplicate-Assignment` + warning banner; **Provide Access blocked**. If the group exists but the requester is **not** a member → process and **add them** (second person on same subscription/role is allowed).
- `**POST /api/manageengine/revoke`** — Removes PIM assignment **or** Entra group membership (`Remove-EntraGroupMember` when `Fulfilment=Group`). Persists `revoked`, posts a revoke note/email. UI Revoke control also appears for group grants (`groupId`).
- `**GET /api/manageengine/analytics`** — Overview counts (all ME tickets) + **ticket type** column/filter on drill-down. **Fixed 2026-07-29:** epoch-ms `created_time` parsing + month boundary at midnight (Today / This Month were stuck at 0).
- **Processed-state refresh fix (2026-07-29):** ME serializes ticket `id` as a string; UI now normalizes to number so processed grants survive page refresh (`normalizeManageEngineTickets`).
- **Requester disambiguation:** `Select-GraphUserMatch` prefers enabled users with primary mail when `otherMails` aliases collide (e.g. ticket #3806).
- **ARM revoke (2026-07-29):** Azure-resource PIM revoke uses ARM `AdminRemove` (not obsolete Graph `azureResources`); contract test covers the path.
- **Approver mapping (section 6.3):** `approver-mapping.json` wired into `Resolve-RbacDecision`.
- **API access diagnostic:** `scripts/Test-ApiAccess.ps1` / `scripts/Test-SpnAccess.ps1`.

**Demo verified:** Ticket #2858 (2026-07-01, Mock then real path); ticket #3806 Contributor on `inception-ai-Sandbox` processed with Graph SPN + ME notify (2026-07-29); group create/join paths exercised on later Help Desk tickets (e.g. #4441 IAM race fixed).

**Mock vs Real:** Default Mock; `-Mode Real` / `AZURESENTRY_PIM_CLIENT=Graph` uses SPN for live grants/revokes. Mock Grant path is seeded with demo `sg-…` groups (`Get-DemoGroupRbacSeed`) so the simulator can hit the group happy path.

### Group-based RBAC fulfilment (2026-08-10; updated 2026-08-17)

Shipped on `main` (fast-forward merge of `feature/group-based-rbac`). Spec: `docs/superpowers/specs/2026-08-10-group-based-rbac-design.md`. Source: `docs/Group-based-RBAC.md`.


| Behaviour                             | Implementation                                                                                                                                                                                      |
| ------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Find Entra group by name              | `sg-<subscription-slug>-…-readers|contributors` (env token optional; extras like region allowed)                                                                                                    |
| Verify / ensure IAM                   | Group has Reader/Contributor **at subscription scope**; missing IAM is created                                                                                                                      |
| Happy path                            | Add user to group (**permanent**); `AssignmentType=GroupMembership`                                                                                                                                 |
| Missing group                         | Create canonical `sg-<slug>-contributors|readers`, assign IAM, add member                                                                                                                           |
| Group already exists (new user)       | Add member; UI may note group already existed                                                                                                                                                       |
| Same user already a member            | **Duplicate** — reject / warning banner; do not re-process                                                                                                                                          |
| Create→IAM race (`PrincipalNotFound`) | Dashed GUID + `principalType=Group` + retries (up to 5 × 3s)                                                                                                                                        |
| Ambiguous matches                     | Per-user PIM + `EngineerActionRequired`                                                                                                                                                             |
| Graph group APIs forbidden (403)      | PIM fallback + engineer flag asking for `Group.ReadWrite.All` admin consent                                                                                                                         |
| Roles                                 | Reader + Contributor (Writer → Contributor). Owner/UAA unchanged                                                                                                                                    |
| Approval                              | Sandbox + Reader: auto Grant. NonProd/Prod Contributor: Eligible decision; **Provide Access** fulfils via group path (D12)                                                                          |
| Break-glass                           | Stays active PIM (not group-first)                                                                                                                                                                  |
| Revoke                                | Group path → `Remove-EntraGroupMember`; PIM path → ARM AdminRemove (Active/Eligible; sentinel/`existing-assignment` resolves by user+role; already-gone = success). Re-process allowed after revoke |


**Live tenant Graph app permissions on automation SPN `spn-automation-infra` (`e2455957-…`):** `User.Read.All` (have) + `**Group.ReadWrite.All`** (Application, admin consent — required for find/create/member). Documented in `docs/graph-consent-request.md`. ARM UAA still required for subscription role assignments.

### Demo tooling


| Asset               | Path                                 | Purpose                                                                                                           |
| ------------------- | ------------------------------------ | ----------------------------------------------------------------------------------------------------------------- |
| Run-of-show guide   | `docs/DEMO_GUIDE.md`                 | ManageEngine-ticket-driven demo (real PIM grant); updated 2026-07-09                                              |
| **Scenario runner** | `dashboard/Invoke-DemoScenario.ps1`  | Narrated E2E: intake → evaluate → real grant → idempotency → verify → resolve → cleanup, for a given ME ticket id |
| Local launcher      | `dashboard/Start-Local.ps1`          | One-command run; Mock default / `-Mode Real` for real grants                                                      |
| Preflight script    | `dashboard/Invoke-DemoPreflight.ps1` | Azure session, eligible role, API/UI health, decision-gate check (legacy Live-PIM demo)                           |
| SPN access check    | `scripts/Test-SpnAccess.ps1`         | Verifies the SPN can do real PIM (4/4)                                                                            |
| Quick start         | `dashboard/README.md`                | Local dev (`npm run dev` → [http://localhost:5173](http://localhost:5173))                                        |


### Dashboard caveat (important for phase planning)

The dashboard **Live PIM** path uses the **operator's ARM delegated token** (`az login`). Production runbooks and Help Desk Graph mode use the **automation SP / GraphPimClient** path. Azure-resource PIM is ARM+UAA (B1 resolved). **Group membership** needs Graph `**Group.ReadWrite.All`** (Application + admin consent) on that SPN for live find/create/member.

---

## Dashboard — future build plan

Ordered roadmap to evolve the prototype into Deliverable #10 and operational tooling. Mapped to scope phases.


| #   | Item                                                                                                                                                                                                                                                           | Target phase | Depends on                                  | Status                                                                          |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------ | ------------------------------------------- | ------------------------------------------------------------------------------- |
| D1  | Wire monitoring views to **Log Analytics** (replace seed data)                                                                                                                                                                                                 | 4 / 8        | 3.9 LA events, 3.2 deploy                   | ⏳ **Ingestion pipeline built** (`LogAnalyticsClient.ps1`); dashboard views still read the local trail/seed until deployed |
| D2  | Export KQL queries from dashboard views → `kql/` workbook                                                                                                                                                                                                      | 4 / 8        | D1, 4.12                                    | ✅ **Done 2026-08-19** — `kql/*.kql` (5 queries) + `kql/azuresentry-workbook.json`, deployed via `loganalytics-audit-dcr.bicep` as `Microsoft.Insights/workbooks` |
| D3  | Publish as **Azure Monitor Workbook** (replace localhost prototype)                                                                                                                                                                                            | 8            | D2, Phase 7 stable                          | ❌ Planned                                                                       |
| D4  | Live **break-glass feed** from reaper + emergency runbook output                                                                                                                                                                                               | 4            | 4.8 grant store                             | ❌ Planned                                                                       |
| D5  | Live **SLA compliance** from PIM approval timestamps + ticket IDs                                                                                                                                                                                              | 4 / 5        | 4.6 polling, ME integration                 | ❌ Planned                                                                       |
| D6  | **Ticket simulator** → POST to Logic App webhook (dev) instead of direct API                                                                                                                                                                                   | 4            | 4.5 ME webhook or LA test endpoint          | ❌ Planned                                                                       |
| D7  | Session banner shows **automation identity** when Graph path available                                                                                                                                                                                         | 5            | B1, runbooks live                           | ❌ Planned                                                                       |
| D8  | Preflight checks **GraphPimClient** path (not only ARM)                                                                                                                                                                                                        | 5            | B1                                          | ❌ Planned                                                                       |
| D9  | Update `DEMO_GUIDE.md` — prod/emergency runbooks now built (mock); clarify live vs Automation path                                                                                                                                                             | 3            | —                                           | ⚠️ Guide still says M5–M6 not built                                             |
| D10 | Role Settings / approver mapping **read-only** panel from PIM Graph                                                                                                                                                                                            | 2            | 1.4, 2.8                                    | ❌ Planned                                                                       |
| D11 | **Priority Classification** (scope §3.2 step 5 / §3.3 / §7) — make Priority a **mandatory** ManageEngine/checklist selection (P1–P4, no silent P4 default); wire P1/P2 → Expedited path + on-call SLA, P3/P4 → Standard path; align break-glass to **P1 only** | 4 / 5        | ME template Priority field, decision matrix | ❌ Planned — currently UI defaults to P4 and does not require operator selection |
| D12 | **Post-approval group fulfilment** — Eligible Reader/Contributor Provide Access uses group create/ensure + membership (not native PIM Eligible)                                                                                                                | 4 / 5        | Operator Provide Access = approval signal   | ✅ Done 2026-08-12                                                               |


**Intent:** Keep the dashboard as a **safe demo and engineering smoke tool** through Phase 3–5; promote D1–D3 to the official observability deliverable in Phase 8 handover.

---

## Platform engineering — session history (retained)

### Fixes applied (F1–F4, 2026-06-24)


| Fix                                         | File(s)                            | What changed                                                                                           |
| ------------------------------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------ |
| **F1** — Missing Decision Router            | `Runbook-Decision-Router.ps1`      | Entry-point runbook; decision tree + dedup; dispatches via `Start-AzAutomationRunbook` or local invoke |
| **F3** — Logic App `$connections` undefined | `workflow.json`                    | `ApiConnection` → `Http` + MSI to Automation Jobs API; G2 webhook secret check                         |
| **F4** — Logic App missing runtime files    | `host.json`, `connections.json`    | Workflows extension bundle                                                                             |
| **Bicep wiring**                            | `logicapp.bicep`, `platform.bicep` | AA name/RG/subscriptionId → Logic App app settings                                                     |
| **PS 5.1 compat**                           | `Runbook-Decision-Router.ps1`      | Manual PSObject→hashtable (no `-AsHashtable`)                                                          |


### Pre-deployment audit (2026-06-24)

Readiness audit → **GO-WITH-CAVEATS** via split deploy:

- `**deployRbac` flag** (default `false`) gates RBAC module — infra deploys under Contributor; RBAC applied separately under UAA/Owner.
- **Bug fix:** Log Analytics Contributor GUID in `rbac-platform-identities.bicep` corrected to `92aaf0da-9dab-42b6-94a3-d43ce8d16293`.
- What-if with `deployRbac=false`: 7 Create / 0 Unsupported. Est. cost ~USD 215–290/mo (WS1-dominated).

### Dependency diagnosis (2026-06-26) — can the dev self-serve?


| Dependency                  | Finding                                                    | Needs                                                       |
| --------------------------- | ---------------------------------------------------------- | ----------------------------------------------------------- |
| RBAC apply (Owner/UAA)      | Eligible at sub = Contributor only; no mgmt-group eligible | Admin to grant **UAA eligibility** or run `deployRbac=true` |
| Automation MI Graph consent | User has no Entra admin roles; `subscribedSkus` = 403      | **Global Admin / PRA** for Graph consent (**B1**)           |


P2 capability appears present (dashboard PIM activation works). Request email drafted for Azure admin.

### Phase 2 unblock verification (2026-06-27)


| Claim                                  | Result                           |
| -------------------------------------- | -------------------------------- |
| Automation SP obj `4e51d30b-…` exists  | ✅                                |
| UAA @ `mg-incep-sandbox`               | ✅ inherits to child subs         |
| User account unchanged (Guest, no UAA) | ✅ expected — platform runs as SP |


### Phase 3–4 authoring burst (2026-06-27)

- `Runbook-Prod-PIM.ps1` + `infra/policy/sandbox-guardrails.bicep` + Contributor GUID fix → tests 38/38.
- `Runbook-Emergency-PIM.ps1`, `Runbook-Status-Updater.ps1`, `Runbook-BreakGlass-Reaper.ps1` + `ReviewHours` engine change → tests **62/62**, `Run-LocalE2E.ps1` **5/5**.

### How to verify (no deploy)

```powershell
powershell -File tests\Run-Pester.ps1            # 562/562
powershell -File tests\Run-LocalE2E.ps1           # 5/5 mock paths
.\scripts\Test-ApiAccess.ps1                       # API access diagnostic (PASS/BLOCKED)
.\dashboard\Invoke-DemoPreflight.ps1               # demo readiness
```

**Real data (no Automation deploy):** Dashboard **Live PIM** tab → P1 + Contributor + Production + BreakGlass flag → real active activation on `inception-internal-product` (ARM path; same decision engine as runbooks).

---

## Azure quick reference


| Resource                           | Value                                                                                                        |
| ---------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Tenant                             | `5ac4936b-1ac4-4e57-9e2b-48673491865e`                                                                       |
| Deploy subscription                | `inception-internal-product` (`5a23842e-609d-42d4-bae5-e48e00e5b28d`)                                        |
| Sandbox MG (UAA scope)             | `mg-incep-sandbox`                                                                                           |
| Region                             | `uaenorth`                                                                                                   |
| Resource group                     | `rg-azuresentry-dev-incp-uaen-001` (not created yet)                                                         |
| Automation SP (canonical)          | app `e2455957-63ef-41e9-bf10-9cfd2f625aea`, obj `eabb6fe0-f45b-4221-85df-ef1feb8d4838` (UAA + User.Read.All) |
| Automation SP (legacy, superseded) | app `d68581f3-…`, obj `4e51d30b-552c-4e80-8467-ccfb0f42981d`                                                 |



| Platform resource | Name                    |
| ----------------- | ----------------------- |
| Logic App         | `la-azsentry-dev-uaen`  |
| Automation        | `aa-azsentry-dev-uaen`  |
| Key Vault         | `kv-azsentry-dev-uaen`  |
| Log Analytics     | `log-azsentry-dev-uaen` |
| App Service Plan  | `asp-azsentry-dev-uaen` |


---

## Changelog (recent)


| Date       | Change                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 2026-08-26 | **Poller/reaper Automation controls simplified: Off/Rehearse/Live + UI-editable per-cycle limits. Merged to `main` (`feature/poller-automation-controls`, `bb3b454..c43a343`), branch deleted.** Replaced the three-layer gating (systemd timer + env-only kill switch + separate Enforce Mode toggle) with one dashboard control per agent. `Get-PollerConfig`/`Get-ReaperConfig` gained `-EnabledOverrideFilePath`/`-CapsOverrideFilePath` (same checked-before-env, fail-closed pattern `*.mode` already had); new routes `POST`/`DELETE /api/{poller,reaper}/{enabled,caps}`; `poller.mode`/`reaper.mode` left untouched. Executed via 8-task SDD plan (spec: `docs/superpowers/specs/2026-08-26-poller-reaper-automation-controls-design.md`), each task independently reviewed, one in-loop fix round (Task 3: `POST /api/poller/caps` was backfilling untouched fields from env and writing them as fake overrides — fixed to only ever persist genuinely-overridden/newly-provided keys), one final whole-branch review with a real security finding (the kill switch is now reachable by any unauthenticated request on the LAN — the dashboard API has no auth at all; **accepted as-is** for this single-operator, trusted-network deployment, not gated) plus 6 Important fixes (stale banner state, partial-override UI rendering, `[bool]` string-coercion on the enabled routes, the poller caps form silently re-triggering the Task-3 bug at the UI layer, a misleading halt-reason string, three now-false runbook claims). **Live end-to-end demo (browser, both panels, Real PIM mode) then found one more real bug the reviews missed:** clicking Rehearse always failed — `POST /api/{poller,reaper}/enabled` wrongly required a justification for any `enabled:true`, but Rehearse calls it with none by design (the safe no-write state). Fixed by moving the escalation gate onto `mode=enforce` alone, where it already correctly lived; Live is unaffected since it still sets both. Re-verified live: Off/Rehearse/Live, the justification gates (missing → rejected, present → accepted) for both Live and cap-raises, and per-field cap independence all confirmed working in the actual browser UI on both panels. 21 new Pester tests, 618/618 total. Docs updated: `Hand-Over.md`, `ticket-poller-runbook.md`, `DEMO_GUIDE.md` §8.4. |
| 2026-08-26 | **AKS RBAC roles now auto-grantable end-to-end by the poller.** Two bugs, both fixed: (1) `Get-CanonicalAzureRole` (`MeTicketMapper.ps1`) discarded any ME role label it didn't recognize (5 hardcoded buckets) to `''`, so an AKS role name never reached the decision engine even though `role-catalog.json`/`eligibility-matrix.json` already fully supported it (tier `Contributor`, Grant on Sandbox/NonProd) — its TypeScript twin `mapMeAzureRole` already passed unrecognized labels through verbatim; now `Get-CanonicalAzureRole` does too, and `Resolve-MeTicketMapping` confirms the pass-through against `Get-RoleCatalogEntry` before treating it as mapped. (2) AKS roles are `scopeType:"resource"` (tied to one cluster) — `Test-TicketSchema.ps1` requires a matching `ResourceScope` or Rejects, to prevent over-granting cluster-admin subscription-wide; the mapper now reads a new `TargetResourceId` field and uses it as `Ticket.ResourceScope` when the role is resource-scoped. ME admin added the field as **"Destination Resource ID"** (`udf_sline_3738`, confirmed structurally via ticket #5023 vs #5127, not guessed) to the Azure Subscription template — not marked mandatory on the ME side, enforced conditionally in the mapper instead. Wired into `config.json`. Also discovered live: ME's Environment dropdown now includes a literal **Sandbox** option (contradicts `DEMO_GUIDE.md` §8.2's stale claim), which is auto-grantable with no promotion-ladder prerequisite. New `docs/poller-eligibility-matrix.md` (full Grant/Eligible/Reject table). Merged via `feature/aks-rbac-poller-autogrant`. 11 new tests, 597/597 total at merge. |
| 2026-08-23 | **Help Desk Tickets defaults to hiding Resolved/Closed/Cancelled.** `/api/manageengine/requests` fetches every ticket with no status filter by design; the Status dropdown defaulted to "All" and reset on every reload, so the queue always showed its full history. `TicketsView.tsx` now defaults to open-only (same three statuses `Invoke-TicketPollerCycle.ps1`'s own fetch already treats as done), with an explicit "All statuses" option, a per-status picker, and a "N hidden" caption. Confirmed against live data: 4 of 11 fetched IDM/IDAM tickets were `Resolved`. |
| 2026-08-23 | **Audit chain verification fixed — three confirmed, real cross-host bugs, not tampering.** "Verify chain" reported false breaks on this project's own local audit log. Root-caused all three by recomputing specific real records under both Windows PowerShell 5.1 and pwsh 7 and diffing byte-for-byte: (1) `ConvertTo-Json` escapes `'` on PS 5.1 but not pwsh 7; (2) `Get-Content` without `-Encoding UTF8` defaults to the system ANSI code page on PS 5.1 for a BOM-less file, mojibaking non-ASCII text (a real zero-width space in a ticket description became `â€‹`); (3) PowerShell's `switch` statement compares string case labels **culture-aware, not ordinal** — `switch ([char]0x200B) { "`b" {...} }` matched the backspace case under pwsh 7 (silently corrupting a ZWSP into a literal backspace escape) but correctly fell through under PS 5.1. Fixed with a new `ConvertTo-CanonicalJsonValue`/`ConvertTo-CanonicalJsonString` (`AuditLog.ps1`) — a from-scratch canonical JSON serializer that never calls `ConvertTo-Json`, sorts every object's keys ordinally at every depth, and classifies characters by `[int]` codepoint comparison only, never `switch`/`-eq` on a `[char]`/`[string]`. Used by both `Write-AuditEvent` (the disk-write line itself, not just hashing) and `Get-AuditCanonicalBody`. All four `Get-Content` call sites in `AuditLog.ps1` gained explicit `-Encoding UTF8`. Because the algorithm changed, every existing hash is invalidated by construction (cryptographically bound to the old algorithm) — new one-time migration `scripts/Repair-AuditChainCanonicalization.ps1` backs up each of the three local `.jsonl` files, then re-derives `id`/`prevHash`/`hash` for every record under the new algorithm without touching any content field; safe to re-run (idempotent). Ran against all three local files; verified `Chain intact` under **both** hosts afterward, including a fresh append (apostrophe + real ZWSP) written under pwsh 7 and re-verified under PS 5.1. 14 new tests in `AuditLog.Tests.ps1` (588/588 total), including a cross-host hash pin as a regression tripwire. **Production note:** the VM only ever runs pwsh 7, so it never hit bugs 1–3 from host-mixing — but the algorithm change still invalidates its existing chain the same way; the migration script must be run there too before/when this fix deploys, or `/api/audit/integrity` will report a false break on the VM's first real record. `.gitignore` gained a pattern for the migration's backup files. |
| 2026-08-23 | **Cross-panel Enforce Mode mismatch warning.** New `EnforceModeMismatchBanner.tsx` on the Overview: warns when the poller is effectively enforcing (override if present, else last-reported mode) and the reaper is not -- the one dangerous combination, since Group grants have no native Azure expiry and only an enforcing reaper reclaims them. Deliberately silent on the reverse (reaper enforcing, poller in shadow), which is a safe, arguably recommended posture. Considered and rejected combining the two switches into one -- see `docs/ticket-poller-runbook.md` reasoning; kept independent so reaper-enforce-first rollout stays possible. `PollerStatusPanel`/`ReaperStatusPanel` gained an `onModeChanged` callback (mirrors `LivePimView`'s existing `onChanged` prop) so the banner refreshes immediately after either toggle, not on its own next poll. |
| 2026-08-23 | **Enforce Mode dashboard toggle, extended to the reaper.** Same mechanism as the poller's toggle (below): `POST`/`DELETE /api/reaper/mode` write/clear `dashboard/api/reaper.mode`, `Get-ReaperConfig` checks it ahead of `AZURESENTRY_REAPER_MODE`, ≥4-char justification to enforce, both directions audited, `AZURESENTRY_REAPER_ENABLED` untouched. New Enforce Mode control on `ReaperStatusPanel.tsx`. `Deploy-ToVm.ps1` excludes `reaper.mode`. 6 new tests, 574/574 total. |
| 2026-08-23 | **Enforce Mode dashboard toggle.** `POST`/`DELETE /api/poller/mode` write/clear `dashboard/api/poller.mode`, which `Get-PollerConfig` now checks ahead of `AZURESENTRY_POLLER_MODE` (fail-closed to shadow on unrecognised content). New Enforce Mode control on the Poller Status panel — inline confirm + ≥4-char justification to switch to enforce, both directions audited. Kill switch (`AZURESENTRY_POLLER_ENABLED`) untouched by design. `Invoke-TicketPollerCycle.ps1` and the dashboard resolve the override file to the identical explicit path (`dashboard/api/poller.mode`), not `Get-PollerConfig`'s own internal default (which lives inside `processed-tickets/` instead) — verified cross-process. `Deploy-ToVm.ps1` excludes it from shipped state. 6 new tests, 568/568 total. |
| 2026-08-23 | **Expiry Tracking view shipped.** `Get-AssignmentRecords` moved from `DemoData.ps1` (in-memory `$script:ActivityLog` — capped 200, restart-volatile, never written by the poller) to `DashboardHelpers.ps1`, rebuilt to read `dashboard/api/processed-tickets/` directly: durable, and the one store both the dashboard's human grant path and the poller write to. Excludes revoked records and records with no recorded expiry. New `expiryEnforcement` field (`AzureEnforced` / `TrackedOnly`, via `Get-GrantExpiryEnforcement`) surfaced as an Enforcement column; inferred from `assignmentId`/`groupId` presence for the 6 legacy records written before the `fulfilment` field existed (verified against the live store — all 6 carry a real ARM `assignmentId` and were misreporting `TrackedOnly` before the inference was added). Nav item un-flagged `comingSoon`; `ExpiryView.tsx` converted from a prop-fed to a self-fetching component (`api.assignments()`, matching `AuditLogsView`'s pattern) with a manual refresh button. |
| 2026-08-17 | **Ticket template schemas.** Help Desk no longer assumes every ticket is Azure Subscription. Schema registry by ME template name; label-based UDF → `templatePayload`; UI **Request fields** panel; grant only for Azure Subscription; other templates → intake + `TemplateIntake` audit; evaluate/process blocked with `Unsupported-Template`. Spec/plan under `docs/superpowers/`. Tests: `ticketTemplateSchemas` / `buildTemplatePayload` (node) + `TicketTemplates.Tests.ps1` (11). Merged via `feat/ticket-template-schemas`. |
| 2026-08-17 | **Governance review implemented (FR1–FR6, NFR2–NFR4).** New `src/Agents/` layer: `AgentRuntime` (7-agent registry, run ids, per-run audit), `LlmClient` (provider-agnostic JSON completions), `SubscriptionResolver` (multi-sub disambiguation), `EnvironmentInferenceAgent` (+ accuracy harness), `SentryGovernanceAgent` (batched env backfill, dry-run default, Production hard-excluded, rollback journal), `TicketCategorizationAgent` (11 work types). New `dashboard/api/AuditLog.ps1` — append-only hash-chained trail wired into every agent action. New `Get-TicketCriticality` — environment-first prioritization. Dashboard IA: Dashboard / Execution Hub / Audit Logs, Execution Hub sub-tabs (Queue / Environment Governance / Department Scope), dummy seed data off by default, Coming Soon markers, Inception42 logo, matrix + architecture moved to `docs/LLD.md`. New endpoints: `/api/agents`, `/api/audit`, `/api/audit/integrity`, `/api/governance/environment/{analyze,report,apply,rollback,status}`, `/api/governance/categorize`, `/api/subscriptions/resolve`. Tests **269/269** (137 new), mock E2E **5/5**, dashboard `tsc -b` + `vite build` clean, 6/6 node suites pass. |
| 2026-08-17 | **ME Environment field:** parse template **Environment** (`udf_pick_3719`); stop using **Environments Required** (`udf_sline_3715`). Checklist + API + probe script aligned.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| 2026-08-13 | **Ticket type placeholder:** every Help Desk row + Overview drill-down shows ME template name (General Access, ADO, GitHub Enterprise, Infrastructure, Azure Subscription, …); filter/search by type.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| 2026-08-13 | **Group membership duplicate check:** group exists + requester already member → `Duplicate-Assignment` warning banner, Provide Access blocked; different user on same group still processed and added.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2026-08-13 | **ARM PrincipalNotFound hardening:** after creating an Entra group, IAM assignment uses dashed GUID + `principalType=Group` and retries on replication delay (ticket #4441).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| 2026-08-12 | **Group RBAC hardening (live Help Desk):** auto-create/ensure `sg-…` + IAM; Eligible Provide Access on group path (D12); Graph 403 → PIM fallback + `Group.ReadWrite.All` ask; revoke fixes (sentinel/`existing-assignment`, Eligible vs Active mismatch, already-gone = success); re-process after revoke; existing-group idempotent UI (“already existed”); Prod justification min **4** chars. Tests **120/120**.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 2026-08-12 | **Group auto-create:** missing `sg-<slug>-contributors|readers` is created, subscription IAM ensured, user added. Eligible Provide Access uses the same group path (D12). Ambiguous matches still PIM+flag.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| 2026-07-30 | **Help Desk / revoke / Overview hardening committed.** IDM→Identity Management & IDAM Team→Identity and Access Management Team labels; Overview Today/This Month date-parse fix; processed state survives refresh (string→number ticket IDs); revoke uses ARM AdminRemove + visible UI revoke states; ME revoke note/email; Graph alias disambiguation; PIM contract 12/12                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| 2026-07-09 | **Allowlist → dynamic by default; ceo-sub included.** Per direction, `allowlist.source` set to `managementGroup` (live from Azure) and `exclusions` emptied — `ceo-sub-application` is now allowlisted via `mg-incep-sandbox` (earlier keep-out decision reversed). The sensitivity map now guards it: a "sandbox" ceo-sub request → `Eligible/Production` (approval-gated), not auto-grant. API reordered (decision before step-trace) so the escalation records truthfully (claimed=Sandbox→effective=Production). Verified: 9 subs incl. ceo-sub.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 2026-07-09 | **Subscription sensitivity map.** New `src/RbacDecision/Data/subscription-sensitivity.json` + `Get-EffectiveEnvironment`; the decision engine now escalates the environment (more-restrictive of mapped vs claimed) so a sensitive sub (ceo-sub, inception-internal-product) is Production/approval-gated even if the ticket says "sandbox" — never downgrades an explicit Production request. Decision record carries Claimed/Effective/Overridden. Applies to all paths (dashboard/CLI/runbooks). Tests **69/69** (7 new). Docs: `docs/allowlist.md`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2026-07-09 | **Dynamic allowlist (management-group sourced).** `allowlist.source=managementGroup` derives the allowlist live from Azure (recursive MG descendants via the SPN), auto-expanding as subs are added; `exclusions` keep sensitive subs out (ceo-sub), `enabledOnly` drops disabled, cached, **fail-closed** to the static list on error. New `GET /api/allowlist`. Committed default stays `static` (testing). Verified: static, MG (8 subs, ceo-sub excluded), decision-engine usage, fail-closed. Docs: `docs/allowlist.md`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| 2026-07-09 | **Bug fix: dashboard ignored the requested role.** `defaultMapping` hardcoded Role=Reader (+ fixed sub/env) and never read the ticket body; the `/requests` endpoint also omitted `description`. Fixed both: endpoint now requests `description` via `fields_required`; new `parseTicket()` extracts Role/Subscription/Environment from subject+body (typo-tolerant), warns when a field can't be read. Verified on #3089 (requested Contributor → now parses Contributor, was showing Reader)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 2026-07-09 | **Demo refreshed to real capabilities.** `docs/DEMO_GUIDE.md` rewritten around the live ManageEngine-ticket flow (requester raises → agent grants real time-bound PIM). New `dashboard/Invoke-DemoScenario.ps1` narrated E2E runner (intake→evaluate→grant→idempotency→verify→resolve→cleanup). Sandbox `inception-ai-Sandbox` (`efae0e0e`) added to allowlist (legit sandbox, §6.1 applied)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| 2026-07-09 | **Phase 2 scoped for local close.** Canonical automation SP set to `e2455957` (legacy `d68581f3` superseded). 2.6 (MI) reclassified N/A-local; 2.8–2.10 scoped out (prod go-live). P2 evidence memo `docs/phase2-p2-evidence.md` drafted — sole remaining gate is 2.1 (IT/Procurement written confirm)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2026-07-09 | **Phase 1 (Design) CLOSED** — stakeholders signed off on the design; exit criteria met (`docs/phase1-signoff.md`). 1.3/1.6/1.9/1.10 ✅; 1.5/1.7/1.8 carried forward to Phase 2-prod/4/7                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2026-07-09 | **Eligible (Production approval-gated) path proven** end-to-end on real ARM: decision `Eligible/Production-Standard` → real `roleEligibilityScheduleRequests` created a 7-day eligible Contributor for a test account (`vpntest`) on `shared-applications`, verified as eligible-not-active, then cleaned up (AdminRemove). Both PIM paths (Sandbox active + Production eligible) now validated live                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 2026-07-09 | **Local app hardening.** Idempotency on `/manageengine/process` (ticket-level short-circuit + PIM duplicate check → decision step-7 `Reject/Duplicate-Assignment`) — verified no double grants. `dashboard/Start-Local.ps1` (Mock default / `-Mode Real` with SPN preflight + port-conflict cleanup). Browser data path verified end-to-end via Vite proxy (UI, live tickets, processed-hydrate, evaluate). Run guide `docs/LOCAL_RUN.md`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| 2026-07-09 | **§6.1 Sandbox PIM Role Settings applied** to `inception-ai-Sandbox` (`efae0e0e`) — Reader+Contributor: no permanent active (isExpirationRequired), 90-day cap (P90D). Verified live. B3 resolved; 2.7 done; only 2.1 (P2 written confirm) left for non-prod exit                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| 2026-07-08 | **Phase 2 engineering complete.** SPN `e2455957` verified (`User.Read.All` + UAA + ARM PIM write); real time-bound Contributor grant executed for ticket #2858 and ticket resolved. B1 reframed/resolved (resource PIM = ARM+UAA, not Graph). `pim-rolesettings` IaC authored (`infra/pim/`); SPN proven able to PATCH Role Settings (2.7/2.8 self-serviceable). GraphPimClient: SPN client-secret auth + ARM routing + guest resolver; corrected UAA role id. Dashboard: durable processed-ticket persistence                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 2026-07-03 | ManageEngine integration: TicketsView, process endpoint, ME note posting, API access diagnostic script                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2026-07-01 | Approver mapping (section 6.3) wired into decision engine; ticket #2858 demo processed end-to-end                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| 2026-06-27 | Phase 3-4 runbooks authored; policy Bicep; tests **62/62**; local E2E **5/5**; BUILD_PLAN + progress restructured to section 13                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| 2026-06-27 | Phase 2 partial: automation SP UAA @ `mg-incep-sandbox` verified                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| 2026-06-26 | Dashboard live PIM + monitoring views (SLA, expiry, break-glass, audit); `AzurePim.ps1`; dependency diagnosis                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| 2026-06-25 | Live Contributor activation verified on `inception-internal-product`; ExpiryView key fix                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| 2026-06-24 | F1–F4 fixes (Decision Router, Logic App HTTP+MSI, runtime files); mock E2E proven; `deployRbac` flag; pre-deploy audit                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |


---

## Next actions (strict order for Phase 3 exit)

1. ~~**B1** Graph consent~~ — resolved via SPN `e2455957` (verify with `scripts\Test-SpnAccess.ps1` → 4/4 PASS).
2. ~~**B3** sandbox sub + §6.1 apply~~ — done 2026-07-09: `inception-ai-Sandbox` (`efae0e0e`), Role Settings applied + verified (clears 2.7).
3. **B2** — Deploy infra (`deployRbac=false`); apply RBAC (`deployRbac=true`); upload runbooks; zip-deploy Logic App.
4. Run **live Sandbox Reader grant** via Automation — Phase 3 exit.
5. In parallel: **B6** ME webhook with IT Ops; and reconcile canonical automation SP (`d68581f3` vs `e2455957`).

**Completed since last update:** **Ticket template schemas** (2026-08-17) — per-template Request fields + grant gate; ME **Environment** UDF (2026-08-17); ticket-type labels + Overview filter (2026-08-13); group membership duplicate vs second-user join; ARM PrincipalNotFound retry for new groups; Group RBAC live hardening (2026-08-12) — auto-create/ensure, D12 Eligible Provide Access, revoke/idempotent existing-group UX, Graph `Group.ReadWrite.All` consent doc; earlier group Grant path (2026-08-10); Help Desk process/revoke + Overview analytics (2026-07-29/30); B1 resolved via SPN; real grant (#2858); `pim-rolesettings` IaC.

Full ordered checklists: `docs/BUILD_PLAN.md`.