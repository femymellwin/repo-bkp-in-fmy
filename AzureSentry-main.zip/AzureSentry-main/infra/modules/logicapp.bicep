@description('Azure region')
param location string

@description('Logic App Standard site name')
param logicAppName string

@description('App Service Plan name')
param appServicePlanName string

@description('Storage account name for Logic App runtime')
param storageAccountName string

@description('Automation Account name — injected as app setting for workflow parameter defaults')
param automationAccountName string = ''

@description('Automation Account resource group — injected as app setting for workflow parameter defaults')
param automationResourceGroup string = ''

@description('Subscription ID — injected as app setting for workflow parameter defaults')
param subscriptionId string = ''

@description('Resource tags')
param tags object = {}

resource appServicePlan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: appServicePlanName
  location: location
  tags: tags
  sku: {
    name: 'WS1'
    tier: 'WorkflowStandard'
  }
  kind: 'elastic'
  properties: {
    maximumElasticWorkerCount: 20
  }
}

resource storageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageAccountName
  location: location
  tags: tags
  sku: {
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    supportsHttpsTrafficOnly: true
    allowBlobPublicAccess: false
  }
}

resource logicApp 'Microsoft.Web/sites@2023-12-01' = {
  name: logicAppName
  location: location
  tags: tags
  kind: 'functionapp,workflowapp'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: appServicePlan.id
    httpsOnly: true
    siteConfig: {
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      appSettings: [
        {
          name: 'AzureWebJobsStorage'
          value: 'DefaultEndpointsProtocol=https;AccountName=${storageAccount.name};EndpointSuffix=${environment().suffixes.storage};AccountKey=${storageAccount.listKeys().keys[0].value}'
        }
        {
          name: 'WEBSITE_CONTENTAZUREFILECONNECTIONSTRING'
          value: 'DefaultEndpointsProtocol=https;AccountName=${storageAccount.name};EndpointSuffix=${environment().suffixes.storage};AccountKey=${storageAccount.listKeys().keys[0].value}'
        }
        {
          name: 'WEBSITE_CONTENTSHARE'
          value: toLower(logicAppName)
        }
        {
          name: 'FUNCTIONS_EXTENSION_VERSION'
          value: '~4'
        }
        {
          name: 'FUNCTIONS_WORKER_RUNTIME'
          value: 'node'
        }
        {
          name: 'AZURESENTRY_AA_NAME'
          value: automationAccountName
        }
        {
          name: 'AZURESENTRY_AA_RG'
          value: automationResourceGroup
        }
        {
          name: 'AZURESENTRY_SUBSCRIPTION_ID'
          value: subscriptionId
        }
      ]
    }
  }
}

output id string = logicApp.id
output name string = logicApp.name
output principalId string = logicApp.identity.principalId
output defaultHostName string = logicApp.properties.defaultHostName
