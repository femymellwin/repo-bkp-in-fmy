// Platform least-privilege RBAC for AzureSentry (azure-rbac skill)
// Uses existing resource references for correct scoped role assignments.
// Prerequisites: deployer needs User Access Administrator on the target scope.

@description('Automation Account system-assigned principal ID')
param automationPrincipalId string

@description('Logic App Standard system-assigned principal ID')
param logicAppPrincipalId string

@description('Key Vault name in this resource group')
param keyVaultName string

@description('Log Analytics workspace name in this resource group')
param logAnalyticsWorkspaceName string

@description('Automation Account name in this resource group')
param automationAccountName string

@description('FR6/NFR3 — Data Collection Rule name for the audit trail ingestion pipeline (loganalytics-audit-dcr.bicep)')
param auditDcrName string = ''

var keyVaultSecretsUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'
var logAnalyticsContributorRoleId = '92aaf0da-9dab-42b6-94a3-d43ce8d16293'
var automationJobOperatorRoleId = '4fe576fe-1146-4730-92eb-48519fa6bf9f'
// Required by the Logs Ingestion API (DCR-based) — see dashboard/api/LogAnalyticsClient.ps1.
var monitoringMetricsPublisherRoleId = '3913510d-42f4-4e42-8a64-420c390055eb'

resource keyVault 'Microsoft.KeyVault/vaults@2024-11-01' existing = {
  name: keyVaultName
}

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2025-02-01' existing = {
  name: logAnalyticsWorkspaceName
}

resource automationAccount 'Microsoft.Automation/automationAccounts@2024-10-23' existing = {
  name: automationAccountName
}

resource auditDcr 'Microsoft.Insights/dataCollectionRules@2023-03-11' existing = if (!empty(auditDcrName)) {
  name: auditDcrName
}

resource automationKvSecretsUser 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, automationPrincipalId, keyVaultSecretsUserRoleId)
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', keyVaultSecretsUserRoleId)
    principalId: automationPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource automationLogAnalyticsContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(logAnalytics.id, automationPrincipalId, logAnalyticsContributorRoleId)
  scope: logAnalytics
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', logAnalyticsContributorRoleId)
    principalId: automationPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource logicAppKvSecretsUser 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, logicAppPrincipalId, keyVaultSecretsUserRoleId)
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', keyVaultSecretsUserRoleId)
    principalId: logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource logicAppAutomationJobOperator 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(automationAccount.id, logicAppPrincipalId, automationJobOperatorRoleId)
  scope: automationAccount
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', automationJobOperatorRoleId)
    principalId: logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource automationAuditDcrPublisher 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (!empty(auditDcrName)) {
  name: guid(auditDcr.id, automationPrincipalId, monitoringMetricsPublisherRoleId)
  scope: auditDcr
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', monitoringMetricsPublisherRoleId)
    principalId: automationPrincipalId
    principalType: 'ServicePrincipal'
  }
}

output roleAssignmentIds array = concat([
  automationKvSecretsUser.id
  automationLogAnalyticsContributor.id
  logicAppKvSecretsUser.id
  logicAppAutomationJobOperator.id
], empty(auditDcrName) ? [] : [automationAuditDcrPublisher.id])
