// AzureSentry FR6/NFR3 — Log Analytics ingestion pipeline for the agent audit trail.
//
// Provisions:
//   - a custom table (AzureSentryAudit_CL) matching the AuditLog.ps1 event schema
//   - a Data Collection Endpoint (DCE) for logs ingestion
//   - a Data Collection Rule (DCR) mapping the "Custom-AzureSentryAuditLog_CL" stream
//     onto that table (passthrough transform — the shape already matches)
//
// The DCR-based Logs Ingestion API is used instead of the legacy HTTP Data Collector
// API (retiring) — see dashboard/api/LogAnalyticsClient.ps1 for the sending side.
// Once deployed, the caller (that client) authenticates as an app registration/SPN
// with the "Monitoring Metrics Publisher" role on this DCR (assigned separately —
// this module does not assign roles, matching the deployRbac-gated pattern used
// elsewhere in this platform).

@description('Azure region')
param location string

@description('Existing Log Analytics workspace resource ID to attach the table to')
param workspaceResourceId string

@description('Existing Log Analytics workspace name (for the table sub-resource)')
param workspaceName string

@description('Data Collection Endpoint name')
param dceName string = 'dce-azsentry-audit-uaen'

@description('Data Collection Rule name')
param dcrName string = 'dcr-azsentry-audit-uaen'

@description('Custom table name — must end in _CL')
param tableName string = 'AzureSentryAudit_CL'

@description('Resource tags')
param tags object = {}

// Column set mirrors the audit event body in dashboard/api/AuditLog.ps1
// (Get-AuditCanonicalBody) plus the envelope fields (id, hash, prevHash).
var auditColumns = [
  { name: 'TimeGenerated', type: 'datetime' }
  { name: 'seq_d', type: 'long' }
  { name: 'id_s', type: 'string' }
  { name: 'agent_s', type: 'string' }
  { name: 'action_s', type: 'string' }
  { name: 'actor_s', type: 'string' }
  { name: 'runId_g', type: 'string' }
  { name: 'correlationId_g', type: 'string' }
  { name: 'ticketId_s', type: 'string' }
  { name: 'target_s', type: 'string' }
  { name: 'before_s', type: 'string' }
  { name: 'after_s', type: 'string' }
  { name: 'outcome_s', type: 'string' }
  { name: 'reason_s', type: 'string' }
  { name: 'detail_s', type: 'string' }
  { name: 'correctsEventId_s', type: 'string' }
  { name: 'isWrite_b', type: 'boolean' }
  { name: 'hash_s', type: 'string' }
  { name: 'prevHash_s', type: 'string' }
]

resource workspaceRef 'Microsoft.OperationalInsights/workspaces@2025-02-01' existing = {
  name: workspaceName
}

resource auditTable 'Microsoft.OperationalInsights/workspaces/tables@2025-02-01' = {
  parent: workspaceRef
  name: tableName
  properties: {
    totalRetentionInDays: 90
    schema: {
      name: tableName
      columns: auditColumns
    }
  }
}

resource dce 'Microsoft.Insights/dataCollectionEndpoints@2023-03-11' = {
  name: dceName
  location: location
  tags: tags
  properties: {
    networkAcls: {
      publicNetworkAccess: 'Enabled'
    }
  }
}

resource dcr 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: dcrName
  location: location
  tags: tags
  dependsOn: [
    auditTable
  ]
  properties: {
    dataCollectionEndpointId: dce.id
    streamDeclarations: {
      'Custom-AzureSentryAuditLog_CL': {
        columns: auditColumns
      }
    }
    destinations: {
      logAnalytics: [
        {
          workspaceResourceId: workspaceResourceId
          name: 'auditWorkspace'
        }
      ]
    }
    dataFlows: [
      {
        streams: [
          'Custom-AzureSentryAuditLog_CL'
        ]
        destinations: [
          'auditWorkspace'
        ]
        outputStream: 'Custom-${tableName}'
        transformKql: 'source'
      }
    ]
  }
}

// Deliverable #10 — the actual KQL dashboard, deployed as an Azure Monitor Workbook
// pointed at this workspace. Source of truth for its content is kql/azuresentry-workbook.json
// (also kept there so it can be reviewed/edited without a deployment, and re-imported
// via the Portal if preferred over Bicep).
resource auditWorkbook 'Microsoft.Insights/workbooks@2022-04-01' = {
  name: guid(workspaceResourceId, 'azuresentry-audit-workbook')
  location: location
  tags: tags
  kind: 'shared'
  properties: {
    displayName: 'AzureSentry Audit & Governance'
    serializedData: loadTextContent('../../kql/azuresentry-workbook.json')
    category: 'workbook'
    sourceId: workspaceResourceId
  }
}

output dceLogsIngestionEndpoint string = dce.properties.logsIngestion.endpoint
output dcrImmutableId string = dcr.properties.immutableId
output dcrName string = dcr.name
output streamName string = 'Custom-AzureSentryAuditLog_CL'
output tableName string = tableName
output workbookId string = auditWorkbook.id
