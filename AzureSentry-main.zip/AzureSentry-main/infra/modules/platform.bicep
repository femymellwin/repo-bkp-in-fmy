// AzureSentry M3 platform stack — Key Vault, Log Analytics, Automation, Logic App Standard + RBAC

@description('Azure region')
param location string

@description('Entra tenant ID')
param tenantId string

@description('Key Vault name')
param keyVaultName string

@description('Log Analytics workspace name')
param logAnalyticsWorkspaceName string

@description('Automation Account name')
param automationAccountName string

@description('Logic App Standard site name')
param logicAppName string

@description('App Service Plan name')
param appServicePlanName string

@description('Storage account name for Logic App runtime')
param storageAccountName string

@description('Resource tags')
param tags object = {}

@description('Deploy the platform RBAC role assignments. Requires the deployer to hold Owner or User Access Administrator. Set false to deploy infra under Contributor and apply RBAC separately once elevated.')
param deployRbac bool = false

module keyVault './keyvault.bicep' = {
  params: {
    location: location
    keyVaultName: keyVaultName
    tenantId: tenantId
    tags: tags
  }
}

module logAnalytics './loganalytics.bicep' = {
  params: {
    location: location
    workspaceName: logAnalyticsWorkspaceName
    tags: tags
  }
}

module automation './automation.bicep' = {
  params: {
    location: location
    automationAccountName: automationAccountName
    tags: tags
  }
}

module logicApp './logicapp.bicep' = {
  params: {
    location: location
    logicAppName: logicAppName
    appServicePlanName: appServicePlanName
    storageAccountName: storageAccountName
    automationAccountName: automationAccountName
    automationResourceGroup: resourceGroup().name
    subscriptionId: subscription().subscriptionId
    tags: tags
  }
}

// FR6/NFR3 — audit trail ingestion (custom table + DCE + DCR). The automation SPN
// still needs the "Monitoring Metrics Publisher" role on the DCR before it can send
// (assigned below via rbac-platform-identities.bicep once deployRbac=true).
module auditIngestion './loganalytics-audit-dcr.bicep' = {
  params: {
    location: location
    workspaceResourceId: logAnalytics.outputs.id
    workspaceName: logAnalytics.outputs.name
    tags: tags
  }
}

module rbac './rbac-platform-identities.bicep' = if (deployRbac) {
  params: {
    automationPrincipalId: automation.outputs.principalId
    logicAppPrincipalId: logicApp.outputs.principalId
    keyVaultName: keyVault.outputs.name
    logAnalyticsWorkspaceName: logAnalytics.outputs.name
    automationAccountName: automation.outputs.name
    auditDcrName: auditIngestion.outputs.dcrName
  }
}

output keyVaultId string = keyVault.outputs.id
output logAnalyticsWorkspaceId string = logAnalytics.outputs.id
output automationAccountId string = automation.outputs.id
output logicAppId string = logicApp.outputs.id
output logicAppHostName string = logicApp.outputs.defaultHostName
output roleAssignmentIds array = rbac.?outputs.roleAssignmentIds ?? []
output auditDceLogsIngestionEndpoint string = auditIngestion.outputs.dceLogsIngestionEndpoint
output auditDcrImmutableId string = auditIngestion.outputs.dcrImmutableId
output auditStreamName string = auditIngestion.outputs.streamName
output auditTableName string = auditIngestion.outputs.tableName
