@description('Azure region')
param location string

@description('Automation Account name')
param automationAccountName string

@description('Resource tags')
param tags object = {}

resource automationAccount 'Microsoft.Automation/automationAccounts@2024-10-23' = {
  name: automationAccountName
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    sku: {
      name: 'Basic'
    }
    publicNetworkAccess: true
  }
}

output id string = automationAccount.id
output name string = automationAccount.name
output principalId string = automationAccount.identity.principalId
