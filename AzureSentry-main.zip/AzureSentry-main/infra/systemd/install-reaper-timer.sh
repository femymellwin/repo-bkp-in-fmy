#!/usr/bin/env bash
# Install/refresh the reaper timer on vm-incp-uaen-001-sentry. Run as root.
#
# Installing the timer does NOT enable the reaper: AZURESENTRY_REAPER_ENABLED in
# /etc/azuresentry.env still gates every action, and it defaults to off. So it is safe
# to install this before you intend to write anything.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v pwsh >/dev/null 2>&1; then
  echo "pwsh not found on PATH; the reaper unit needs it at /usr/bin/pwsh" >&2
  exit 1
fi

install -m 0644 "$SRC/azuresentry-reaper.service" /etc/systemd/system/
install -m 0644 "$SRC/azuresentry-reaper.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now azuresentry-reaper.timer

echo "--- timer status ---"
systemctl list-timers azuresentry-reaper.timer --no-pager || true
echo
echo "Installed. The reaper stays inert until AZURESENTRY_REAPER_ENABLED=true in /etc/azuresentry.env."
echo "Run one cycle by hand with:  systemctl start azuresentry-reaper.service && journalctl -u azuresentry-reaper -n 50 --no-pager"
