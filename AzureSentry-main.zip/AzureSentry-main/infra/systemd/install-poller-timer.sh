#!/usr/bin/env bash
# Install/refresh the poller timer on vm-incp-uaen-001-sentry. Run as root.
#
# Installing the timer does NOT enable the poller: AZURESENTRY_POLLER_ENABLED in
# /etc/azuresentry.env still gates every action, and it defaults to off. So it is safe
# to install this before you intend to write anything.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v pwsh >/dev/null 2>&1; then
  echo "pwsh not found on PATH; the poller unit needs it at /usr/bin/pwsh" >&2
  exit 1
fi

install -m 0644 "$SRC/azuresentry-poller.service" /etc/systemd/system/
install -m 0644 "$SRC/azuresentry-poller.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now azuresentry-poller.timer

echo "--- timer status ---"
systemctl list-timers azuresentry-poller.timer --no-pager || true
echo
echo "Installed. The poller stays inert until AZURESENTRY_POLLER_ENABLED=true in /etc/azuresentry.env."
echo "Run one cycle by hand with:  systemctl start azuresentry-poller.service && journalctl -u azuresentry-poller -n 50 --no-pager"
