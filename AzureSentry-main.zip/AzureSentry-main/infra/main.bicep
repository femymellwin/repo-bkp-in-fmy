targetScope = 'subscription'

@description('Azure region for the AzureSentry resource group')
param location string = 'uaenorth'

@description('Resource group name for AzureSentry platform resources')
param resourceGroupName string = 'rg-azuresentry-dev-incp-uaen-001'

@description('Entra tenant ID')
param tenantId string

@description('Key Vault name (3-24 chars)')
param keyVaultName string = 'kv-azsentry-dev-uaen'

@description('Log Analytics workspace name')
param logAnalyticsWorkspaceName string = 'log-azsentry-dev-uaen'

@description('Automation Account name')
param automationAccountName string = 'aa-azsentry-dev-uaen'

@description('Logic App Standard site name')
param logicAppName string = 'la-azsentry-dev-uaen'

@description('App Service Plan name')
param appServicePlanName string = 'asp-azsentry-dev-uaen'

@description('Storage account name for Logic App runtime (3-24 lowercase alphanumeric)')
param storageAccountName string = 'stazsentrydev001'

@description('Environment tag value')
param environmentTag string = 'dev'

@description('Deploy platform RBAC role assignments. Requires deployer to hold Owner/User Access Administrator. Leave false to deploy infra under Contributor, then apply RBAC separately once elevated.')
param deployRbac bool = false

var tags = {
  application: 'AzureSentry'
  environment: environmentTag
  managedBy: 'bicep'
}

resource resourceGroup 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: resourceGroupName
  location: location
  tags: tags
}

module platform './modules/platform.bicep' = {
  name: 'azuresentry-platform'
  scope: resourceGroup
  params: {
    location: location
    tenantId: tenantId
    keyVaultName: keyVaultName
    logAnalyticsWorkspaceName: logAnalyticsWorkspaceName
    automationAccountName: automationAccountName
    logicAppName: logicAppName
    appServicePlanName: appServicePlanName
    storageAccountName: storageAccountName
    deployRbac: deployRbac
    tags: tags
  }
}

output resourceGroupName string = resourceGroup.name
output keyVaultId string = platform.outputs.keyVaultId
output logAnalyticsWorkspaceId string = platform.outputs.logAnalyticsWorkspaceId
output automationAccountId string = platform.outputs.automationAccountId
output logicAppId string = platform.outputs.logicAppId
output logicAppHostName string = platform.outputs.logicAppHostName
// FR6/NFR3 — feed these into dashboard/api/.env (or App Settings) as
// AZURESENTRY_LA_DCE_ENDPOINT / AZURESENTRY_LA_DCR_IMMUTABLE_ID / AZURESENTRY_LA_STREAM_NAME
// once deployed, to switch the audit trail on to Log Analytics.
output auditDceLogsIngestionEndpoint string = platform.outputs.auditDceLogsIngestionEndpoint
output auditDcrImmutableId string = platform.outputs.auditDcrImmutableId
output auditStreamName string = platform.outputs.auditStreamName
output auditTableName string = platform.outputs.auditTableName
