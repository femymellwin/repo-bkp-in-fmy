# AzureSentry - Sandbox Azure Policy Guardrails (Deliverable #8)

Management-group-scoped Azure Policy guardrails for the Sandbox environment.

- Template: `sandbox-guardrails.bicep` (`targetScope = 'managementGroup'`)
- Target scope: `mg-incep-sandbox`
- Spec refs: Section 9, line ~299 ("Azure Policy DenyAction blocks Owner/UAA from Sandbox
  subscriptions"); Deliverable #8, line ~335 ("Duration enforcement, permanent assignment
  block, Owner/UAA Sandbox block").

The automation service principal (object id `4e51d30b-552c-4e80-8467-ccfb0f42981d`) holds
**User Access Administrator** at `mg-incep-sandbox`, which is sufficient to define and assign
policy at this management group.

## What each policy does

| # | Policy (definition + assignment) | Effect (default) | What it does |
|---|---|---|---|
| 1 | `deny-owner-uaa-sandbox` | `Deny` (parameterized) | Denies creation of any `Microsoft.Authorization/roleAssignments` whose `roleDefinitionId` resolves to **Owner** (`8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d`) or **User Access Administrator** (`18d7d88d-d35e-4fb5-a5c3-a3a032941232`) anywhere under the Sandbox management group. This is the real resource-plane enforcement point. |
| 2 | `deny-permanent-privileged-assignment` | `Audit` (parameterized) | Audits classic **standing (permanent)** Owner/UAA role assignments created directly at the resource plane (outside PIM), so PIM-only provisioning is verifiable. Audit only - see division of responsibility below. |
| 3 | `audit-long-duration-assignment` | `Audit` (parameterized) | Companion audit for duration governance. Flags standing (no-expiry) Contributor assignments created at the resource plane rather than as time-bound PIM grants. Audit only - see below. |

All three definitions carry metadata `category: AzureSentry`. All three assignments use
`identity: None` (no remediation tasks for Deny/Audit) and a parameterized `enforcementMode`
(default `Default`).

## Division of responsibility: Azure Policy vs PIM Role Settings

Only **policy #1** is genuinely expressible at the Azure resource plane. A role assignment is
an ARM resource, so Azure Policy can deny its creation by matching `roleDefinitionId`.

**Duration limits and the permanent vs time-bound distinction are NOT resource-plane concepts.**
They live in **Microsoft Entra PIM Role Settings** (Cloud Governance, Phase 2 - Deliverable #6):

- The 90-day maximum assignment duration is enforced in PIM Role Settings and pre-validated by
  the agent runbook before the PIM API call.
- "No permanent / standing assignment" is enforced by PIM Role Settings (Active-only with
  mandatory expiry; permanent eligible/active not allowed).
- PIM eligibility/active **schedules** and their `endDateTime` are governed via Microsoft Graph.
  Azure Policy at the resource plane **cannot read a PIM schedule's lifecycle or expiry**.

Because of that, policies **#2** and **#3** are honest **audit companions** only - they make
resource-plane (non-PIM) standing grants visible for Cloud Governance follow-up. They are not,
and cannot be, the authoritative duration/permanent-block enforcer. **PIM Role Settings is.**

## Parameters

| Parameter | Default | Notes |
|---|---|---|
| `managementGroupId` | `mg-incep-sandbox` | Used in displayNames/descriptions; assignments scope to the deployment management group. |
| `ownerUaaBlockEffect` | `Deny` | Effect for policy #1 (`Deny` / `Audit` / `Disabled`). |
| `permanentAssignmentEffect` | `Audit` | Effect for policy #2 (`Audit` / `Disabled` - no Deny by design). |
| `longDurationEffect` | `Audit` | Effect for policy #3 (`Audit` / `Disabled` - no Deny by design). |
| `enforcementMode` | `Default` | `Default` applies effects; `DoNotEnforce` evaluates/reports without enforcing (dry-run). |

## Deploy

Authoring only - deployment is gated on Cloud Governance sign-off (Deliverable #8 dependency).

```
az deployment mg create --management-group-id mg-incep-sandbox --location uaenorth --template-file infra/policy/sandbox-guardrails.bicep
```

Dry-run first (recommended): add `--what-if`, or assign with `enforcementMode=DoNotEnforce`
to evaluate compliance before turning on the `Deny` effect.

## Validate the template

```
az bicep build --file infra/policy/sandbox-guardrails.bicep --stdout
```
