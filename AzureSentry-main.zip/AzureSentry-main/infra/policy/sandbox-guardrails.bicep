// AzureSentry Deliverable #8 - Azure Policy guardrails for the Sandbox management group.
// Spec refs: Section 9 (line ~299) "Azure Policy DenyAction blocks Owner/UAA from Sandbox
// subscriptions"; Deliverable #8 (line ~335) "Duration enforcement, permanent assignment
// block, Owner/UAA Sandbox block".
//
// Division of responsibility (READ THIS BEFORE EXTENDING):
//   - Only the Owner/UAA role-assignment block is genuinely expressible at the Azure resource
//     plane (a roleAssignment is an ARM resource, so Azure Policy can deny its creation).
//   - Duration limits and the permanent (standing) vs time-bound (PIM) distinction live in
//     Microsoft Entra PIM Role Settings, NOT in ARM. PIM eligibility/active schedules and their
//     expiry are governed by Graph (Cloud Governance, Phase 2 - Deliverable #6). Azure Policy
//     cannot read a PIM schedule's endDateTime, so policies (2) and (3) below are resource-plane
//     AUDIT companions only - the authoritative enforcer is PIM Role Settings.
//
// The automation service principal (object id 4e51d30b-552c-4e80-8467-ccfb0f42981d) holds
// User Access Administrator at this management group, which is sufficient to define and assign
// policy here.
//
// Deploy (do NOT run as part of any other pipeline without Cloud Governance sign-off):
//   az deployment mg create --management-group-id mg-incep-sandbox --location uaenorth \
//     --template-file infra/policy/sandbox-guardrails.bicep

targetScope = 'managementGroup'

@description('Sandbox management group id. The automation SP holds User Access Administrator here. Used in displayNames and assignment scoping.')
param managementGroupId string = 'mg-incep-sandbox'

@description('Effect for the Owner/UAA role-assignment block policy. Default Deny stops the assignment at the resource plane.')
@allowed([
  'Deny'
  'Audit'
  'Disabled'
])
param ownerUaaBlockEffect string = 'Deny'

@description('Effect for the permanent (standing) privileged assignment audit policy. Audit only - hard block is owned by PIM Role Settings.')
@allowed([
  'Audit'
  'Disabled'
])
param permanentAssignmentEffect string = 'Audit'

@description('Effect for the long-duration assignment audit policy. Audit only - authoritative duration enforcement is owned by PIM Role Settings.')
@allowed([
  'Audit'
  'Disabled'
])
param longDurationEffect string = 'Audit'

@description('Policy assignment enforcement mode. Default actually applies the effect; DoNotEnforce evaluates and reports without enforcing (useful for dry-run / what-if).')
@allowed([
  'Default'
  'DoNotEnforce'
])
param enforcementMode string = 'Default'

// Built-in Azure role definition GUIDs (the two privileged roles blocked on Sandbox).
var ownerRoleDefinitionId = '8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d'
var userAccessAdministratorRoleDefinitionId = '18d7d88d-d35e-4fb5-a5c3-a3a032941232'

// A roleAssignment's roleDefinitionId can be written tenant-scoped
// (/providers/Microsoft.Authorization/roleDefinitions/<guid>) or subscription-scoped
// (/subscriptions/<id>/providers/.../roleDefinitions/<guid>). Both forms END in the role
// GUID, so we match on the GUID suffix with 'like' '*<guid>' rather than an exact resource id.
// Matching one exact form would let an Owner/UAA assignment created in the other form (the
// Azure CLI, the portal, and this repo's own rbac-platform-identities.bicep all emit the
// subscription-scoped form) silently bypass the block.

var policyCategory = 'AzureSentry'

// ---------------------------------------------------------------------------
// (1) deny-owner-uaa-sandbox - the genuinely resource-plane-expressible guardrail.
// Denies creation of any Microsoft.Authorization/roleAssignments whose roleDefinitionId
// resolves to Owner or User Access Administrator anywhere under the Sandbox management group.
// ---------------------------------------------------------------------------
resource denyOwnerUaaSandboxDefinition 'Microsoft.Authorization/policyDefinitions@2025-03-01' = {
  name: 'deny-owner-uaa-sandbox'
  properties: {
    policyType: 'Custom'
    mode: 'All'
    displayName: 'AzureSentry - Block Owner/UAA role assignments on Sandbox (${managementGroupId})'
    description: 'Denies creation of role assignments granting Owner or User Access Administrator anywhere under the Sandbox management group. Implements the Sandbox Owner/UAA role cap (spec Section 9 / Deliverable #8). This is the resource-plane enforcement point; the agent runbook also rejects these requests before the PIM API call.'
    metadata: {
      category: policyCategory
      version: '1.0.0'
    }
    parameters: {
      effect: {
        type: 'String'
        metadata: {
          displayName: 'Effect'
          description: 'Deny blocks the assignment; Audit reports it; Disabled turns the policy off.'
        }
        allowedValues: [
          'Deny'
          'Audit'
          'Disabled'
        ]
        defaultValue: 'Deny'
      }
    }
    policyRule: {
      if: {
        allOf: [
          {
            field: 'type'
            equals: 'Microsoft.Authorization/roleAssignments'
          }
          {
            anyOf: [
              {
                field: 'Microsoft.Authorization/roleAssignments/roleDefinitionId'
                like: '*${ownerRoleDefinitionId}'
              }
              {
                field: 'Microsoft.Authorization/roleAssignments/roleDefinitionId'
                like: '*${userAccessAdministratorRoleDefinitionId}'
              }
            ]
          }
        ]
      }
      then: {
        effect: '[parameters(\'effect\')]'
      }
    }
  }
}

// ---------------------------------------------------------------------------
// (2) deny-permanent-privileged-assignment - resource-plane AUDIT companion.
// NOTE ON RESPONSIBILITY: hard duration/permanent-block enforcement is owned by PIM Role
// Settings (Cloud Governance, Phase 2 - Deliverable #6). Azure Policy cannot inspect a PIM
// schedule's lifecycle, so this policy only AUDITS classic (standing) privileged role
// assignments created directly at the resource plane, so PIM-only provisioning is verifiable.
// ---------------------------------------------------------------------------
resource denyPermanentPrivilegedAssignmentDefinition 'Microsoft.Authorization/policyDefinitions@2025-03-01' = {
  name: 'deny-permanent-privileged-assignment'
  properties: {
    policyType: 'Custom'
    mode: 'All'
    displayName: 'AzureSentry - Audit standing (permanent) privileged role assignments on Sandbox (${managementGroupId})'
    description: 'Audits classic standing role assignments to Owner or User Access Administrator created directly at the resource plane (i.e. outside PIM). Authoritative "no permanent assignment" enforcement lives in PIM Role Settings (Cloud Governance, Phase 2). This policy is the resource-plane companion/audit so PIM-only provisioning can be verified.'
    metadata: {
      category: policyCategory
      version: '1.0.0'
    }
    parameters: {
      effect: {
        type: 'String'
        metadata: {
          displayName: 'Effect'
          description: 'Audit reports standing privileged assignments; Disabled turns the policy off. No Deny - PIM Role Settings is the authoritative enforcer.'
        }
        allowedValues: [
          'Audit'
          'Disabled'
        ]
        defaultValue: 'Audit'
      }
    }
    policyRule: {
      if: {
        allOf: [
          {
            field: 'type'
            equals: 'Microsoft.Authorization/roleAssignments'
          }
          {
            anyOf: [
              {
                field: 'Microsoft.Authorization/roleAssignments/roleDefinitionId'
                like: '*${ownerRoleDefinitionId}'
              }
              {
                field: 'Microsoft.Authorization/roleAssignments/roleDefinitionId'
                like: '*${userAccessAdministratorRoleDefinitionId}'
              }
            ]
          }
        ]
      }
      then: {
        effect: '[parameters(\'effect\')]'
      }
    }
  }
}

// ---------------------------------------------------------------------------
// (3) audit-long-duration-assignment - companion audit for duration governance.
// SAME HONEST CAVEAT: PIM Role Settings is the authoritative duration enforcer (90-day cap,
// expiry, no-permanent). Azure Policy at the resource plane cannot read a PIM schedule's
// endDateTime, so this policy AUDITS resource-plane Contributor assignments (the role the
// Sandbox agent auto-provisions) so any standing - i.e. non-PIM, no-expiry - grant is flagged
// for Cloud Governance follow-up.
// ---------------------------------------------------------------------------
var contributorRoleDefinitionId = 'b24988ac-6180-42a0-ab88-20f7382dd24c'

resource auditLongDurationAssignmentDefinition 'Microsoft.Authorization/policyDefinitions@2025-03-01' = {
  name: 'audit-long-duration-assignment'
  properties: {
    policyType: 'Custom'
    mode: 'All'
    displayName: 'AzureSentry - Audit standing Contributor assignments for duration governance on Sandbox (${managementGroupId})'
    description: 'Companion audit for duration governance. Flags standing (no-expiry) Contributor role assignments created directly at the resource plane rather than as time-bound PIM grants. The authoritative duration enforcer (90-day cap, expiry, no-permanent) is PIM Role Settings (Cloud Governance, Phase 2 - Deliverable #6); Azure Policy cannot read a PIM schedule endDateTime, so this is an audit-only companion.'
    metadata: {
      category: policyCategory
      version: '1.0.0'
    }
    parameters: {
      effect: {
        type: 'String'
        metadata: {
          displayName: 'Effect'
          description: 'Audit reports standing Contributor assignments; Disabled turns the policy off. No Deny - PIM Role Settings is the authoritative duration enforcer.'
        }
        allowedValues: [
          'Audit'
          'Disabled'
        ]
        defaultValue: 'Audit'
      }
    }
    policyRule: {
      if: {
        allOf: [
          {
            field: 'type'
            equals: 'Microsoft.Authorization/roleAssignments'
          }
          {
            field: 'Microsoft.Authorization/roleAssignments/roleDefinitionId'
            like: '*${contributorRoleDefinitionId}'
          }
        ]
      }
      then: {
        effect: '[parameters(\'effect\')]'
      }
    }
  }
}

// ---------------------------------------------------------------------------
// Assignments - all scoped to this (the Sandbox) management group, identity none
// (no remediation tasks needed for Deny/Audit), enforcementMode parameterized.
// ---------------------------------------------------------------------------
resource denyOwnerUaaSandboxAssignment 'Microsoft.Authorization/policyAssignments@2025-03-01' = {
  name: 'deny-owner-uaa-sandbox'
  identity: {
    type: 'None'
  }
  location: deployment().location
  properties: {
    displayName: 'AzureSentry - Block Owner/UAA on Sandbox (${managementGroupId})'
    description: 'Assigns the Owner/UAA role-assignment block at the Sandbox management group.'
    policyDefinitionId: denyOwnerUaaSandboxDefinition.id
    enforcementMode: enforcementMode
    parameters: {
      effect: {
        value: ownerUaaBlockEffect
      }
    }
  }
}

resource denyPermanentPrivilegedAssignmentAssignment 'Microsoft.Authorization/policyAssignments@2025-03-01' = {
  name: 'audit-permanent-priv'
  identity: {
    type: 'None'
  }
  location: deployment().location
  properties: {
    displayName: 'AzureSentry - Audit standing privileged assignments on Sandbox (${managementGroupId})'
    description: 'Assigns the standing privileged-assignment audit at the Sandbox management group. Authoritative permanent-block is PIM Role Settings.'
    policyDefinitionId: denyPermanentPrivilegedAssignmentDefinition.id
    enforcementMode: enforcementMode
    parameters: {
      effect: {
        value: permanentAssignmentEffect
      }
    }
  }
}

resource auditLongDurationAssignmentAssignment 'Microsoft.Authorization/policyAssignments@2025-03-01' = {
  name: 'audit-long-duration'
  identity: {
    type: 'None'
  }
  location: deployment().location
  properties: {
    displayName: 'AzureSentry - Audit duration governance on Sandbox (${managementGroupId})'
    description: 'Assigns the duration-governance audit at the Sandbox management group. Authoritative duration enforcement is PIM Role Settings.'
    policyDefinitionId: auditLongDurationAssignmentDefinition.id
    enforcementMode: enforcementMode
    parameters: {
      effect: {
        value: longDurationEffect
      }
    }
  }
}

output denyOwnerUaaSandboxDefinitionId string = denyOwnerUaaSandboxDefinition.id
output denyPermanentPrivilegedAssignmentDefinitionId string = denyPermanentPrivilegedAssignmentDefinition.id
output auditLongDurationAssignmentDefinitionId string = auditLongDurationAssignmentDefinition.id
output denyOwnerUaaSandboxAssignmentId string = denyOwnerUaaSandboxAssignment.id
output denyPermanentPrivilegedAssignmentAssignmentId string = denyPermanentPrivilegedAssignmentAssignment.id
output auditLongDurationAssignmentAssignmentId string = auditLongDurationAssignmentAssignment.id
