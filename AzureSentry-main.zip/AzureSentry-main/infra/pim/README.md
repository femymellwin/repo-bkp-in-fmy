# PIM Role Settings — IaC (Phase 2, item 2.11)

Repeatable configuration of Azure PIM **Role Settings** per the scope doc §6.1 (Sandbox)
and §6.2 (Production). Satisfies Phase 2 checklist item **2.11** and is the mechanism for
**2.7 / 2.8** ("PIM policies active").

## Why this is a script, not Bicep

PIM Role Settings for **Azure resources** are ARM objects
(`Microsoft.Authorization/roleManagementPolicies`), configured by **updating** the
auto-provisioned policy for each `{scope, role}` pair — there is nothing to *create*, so a
declarative Bicep resource is awkward. The natural shape is read-modify-write against ARM,
which is what `Set-PimRoleSettings.ps1` does. The desired values live declaratively in the
`rolesettings.*.json` files.

## Key finding (2026-07-08)

Configuring these policies requires `Microsoft.Authorization/*` — i.e. **User Access
Administrator** or Owner at the scope. AzureSentry's automation SPN already holds UAA, and
a write probe confirmed it can `PATCH` these policies (HTTP 200). **So Role Settings can be
applied by engineering with the SPN — they are not gated on a Privileged Role Admin.**

## Files

| File | Purpose |
|------|---------|
| `rolesettings.sandbox.json` | §6.1 desired values (Reader, Contributor) |
| `rolesettings.production.json` | §6.2 desired values (Reader → UAA) |
| `Set-PimRoleSettings.ps1` | Applies a config to a subscription via ARM (dry-run by default) |

## Usage

Auth: uses the SPN in `.env` (`AZURE_TENANT_ID` / `AZURE_CLIENT_ID` / `AZURE_CLIENT_SECRET`);
falls back to a delegated `az account get-access-token` session if those are absent.

```powershell
# Dry-run (shows the diff, writes nothing) — DEFAULT
./Set-PimRoleSettings.ps1 -SubscriptionId <sandbox-sub> -Environment Sandbox

# Apply §6.1 Sandbox settings
./Set-PimRoleSettings.ps1 -SubscriptionId <sandbox-sub> -Environment Sandbox -Apply

# Apply §6.2 Production settings + populate approvers from approver-mapping.json
./Set-PimRoleSettings.ps1 -SubscriptionId <prod-sub> -Environment Production -SetApprovers -Apply
```

Requires the **sandbox subscription id** (blocker B3) to target the correct scope for §6.1.

## What maps to PIM vs. what the platform enforces

Some spec requirements have **no** ARM policy field and are enforced by AzureSentry itself
(recorded under `platformEnforced` in the JSON):

- **Justification ≥ 20 chars** — PIM only has a justification-required boolean; the length
  minimum is enforced by `Runbook-Prod-PIM` / decision-engine schema validation.
- **Per-priority approval SLA** (P1 4h/2h, P2 8h/4h, P3–P4 24h) — no per-priority timeout in
  PIM policy; tracked by the decision engine (`SlaHours`/`EscalateAt`) and `Runbook-Status-Updater`.
- **Owner/Sandbox block** — enforced by Azure Policy (`infra/policy/sandbox-guardrails.bicep`),
  which is why the sandbox config only touches Reader/Contributor.

## Dual approval (Owner / UAA)

With `-SetApprovers`, roles in `dualApprovalRoles` are configured as a **Serial** two-stage
approval (both approvers must approve; denial by either terminates), matching §5.3. Approver
identities are resolved from `src/RbacDecision/Data/approver-mapping.json`.
