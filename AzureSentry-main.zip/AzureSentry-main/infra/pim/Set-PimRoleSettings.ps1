<#
.SYNOPSIS
    Applies AzureSentry PIM Role Settings (§6.1 Sandbox / §6.2 Production) to a
    subscription via the ARM roleManagementPolicies API. Repeatable "IaC" for Phase 2
    item 2.11; satisfies 2.7/2.8 ("PIM policies active").

.DESCRIPTION
    PIM Role Settings for Azure resources are ARM (management.azure.com) objects, not
    Microsoft Graph. Configuring them requires Microsoft.Authorization/* (User Access
    Administrator or Owner) at the target scope - the same right AzureSentry's automation
    SPN already holds. So this runs with the SPN (client-credentials from .env) or, if
    those are absent, a delegated 'az' token.

    Read-modify-write: for each role it locates the live roleManagementPolicy, mutates
    only the fields named in the environment config JSON, and PATCHes the changed rules.
    Everything else in the policy is left untouched.

    SAFE BY DEFAULT: performs a dry-run (diff only) unless -Apply is passed.

.EXAMPLE
    ./Set-PimRoleSettings.ps1 -SubscriptionId <sandbox-sub> -Environment Sandbox
    # dry-run: shows what would change

.EXAMPLE
    ./Set-PimRoleSettings.ps1 -SubscriptionId <sandbox-sub> -Environment Sandbox -Apply
    # applies §6.1 sandbox settings

.EXAMPLE
    ./Set-PimRoleSettings.ps1 -SubscriptionId <prod-sub> -Environment Production -SetApprovers -Apply
    # applies §6.2 + populates approvers from docs approver-mapping.json
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SubscriptionId,
    [Parameter(Mandatory)][ValidateSet('Sandbox', 'Production')][string]$Environment,
    [string[]]$Roles,
    [switch]$SetApprovers,
    [switch]$Apply
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$scriptDir = $PSScriptRoot
$repoRoot  = Split-Path (Split-Path $scriptDir -Parent) -Parent
$armApiVersion = '2020-10-01'

$RoleIds = @{
    'Reader'                      = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'
    'Contributor'                 = 'b24988ac-6180-42a0-ab88-20f7382dd24c'
    'Owner'                       = '8e3af657-a8ff-443c-a5c2-8af0e3fd3e6d'
    'User Access Administrator'   = '18d7d88d-d35e-4fb5-a5c3-7773c20a72d9'
}

# --- Load .env (for SPN creds) ---
$envFile = Join-Path $repoRoot '.env'
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)\s*$') {
            [Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], 'Process')
        }
    }
}

function Get-Token {
    param([string]$Resource)
    if ($env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET) {
        $r = Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$($env:AZURE_TENANT_ID)/oauth2/v2.0/token" `
            -Body @{ grant_type='client_credentials'; client_id=$env:AZURE_CLIENT_ID; client_secret=$env:AZURE_CLIENT_SECRET; scope="$Resource/.default" } `
            -ContentType 'application/x-www-form-urlencoded'
        return $r.access_token
    }
    # Fallback: delegated az session
    $t = az account get-access-token --resource $Resource --query accessToken -o tsv 2>$null
    if (-not $t) { throw "No SPN creds in .env and 'az account get-access-token' failed. Run az login or set AZURE_CLIENT_ID/SECRET/TENANT_ID." }
    return $t
}

function Invoke-Arm {
    param([string]$Method, [string]$Uri, [object]$Body, [string]$Token)
    $p = @{ Method = $Method; Uri = $Uri; Headers = @{ Authorization = "Bearer $Token" } }
    if ($Body) { $p['Body'] = ($Body | ConvertTo-Json -Depth 20); $p['ContentType'] = 'application/json' }
    return Invoke-RestMethod @p
}

function Resolve-ApproverIds {
    param([string[]]$Upns, [string]$GraphToken)
    $ids = @()
    foreach ($upn in $Upns) {
        if (-not $upn) { continue }
        try {
            $u = Invoke-RestMethod -Headers @{ Authorization = "Bearer $GraphToken" } `
                -Uri "https://graph.microsoft.com/v1.0/users/$([uri]::EscapeDataString($upn))?`$select=id,displayName"
            $ids += @{ id = $u.id; description = $u.displayName; isBackup = $false; userType = 'User' }
        }
        catch {
            $f = [uri]::EscapeDataString("mail eq '$upn' or userPrincipalName eq '$upn'")
            $res = Invoke-RestMethod -Headers @{ Authorization = "Bearer $GraphToken" } `
                -Uri "https://graph.microsoft.com/v1.0/users?`$filter=$f&`$select=id,displayName&`$top=1"
            if ($res.value.Count -ge 1) { $ids += @{ id = $res.value[0].id; description = $res.value[0].displayName; isBackup = $false; userType = 'User' } }
            else { Write-Warning "Approver not resolved: $upn" }
        }
    }
    return $ids
}

# --- Load environment config ---
$cfgFile = Join-Path $scriptDir "rolesettings.$($Environment.ToLower()).json"
if (-not (Test-Path $cfgFile)) { throw "Config not found: $cfgFile" }
$cfg = Get-Content -Raw $cfgFile | ConvertFrom-Json
$targetRoles = if ($Roles) { $Roles } else { @($cfg.roles) }

$armToken = Get-Token -Resource 'https://management.azure.com'
$graphToken = $null
if ($SetApprovers) { $graphToken = Get-Token -Resource 'https://graph.microsoft.com' }

$approverMap = $null
$approverPath = Join-Path $repoRoot 'src/RbacDecision/Data/approver-mapping.json'
if ($SetApprovers -and (Test-Path $approverPath)) { $approverMap = Get-Content -Raw $approverPath | ConvertFrom-Json }

$scope = "/subscriptions/$SubscriptionId"
Write-Host ''
Write-Host "AzureSentry PIM Role Settings - $Environment ($($cfg.specRef))" -ForegroundColor Cyan
Write-Host "Scope : $scope" -ForegroundColor Cyan
Write-Host "Mode  : $(if ($Apply) { 'APPLY' } else { 'DRY-RUN (use -Apply to write)' })" -ForegroundColor $(if ($Apply) { 'Yellow' } else { 'Green' })
Write-Host ''

foreach ($roleName in $targetRoles) {
    if (-not $RoleIds.ContainsKey($roleName)) { Write-Warning "Unknown role '$roleName' - skipped"; continue }
    $roleId = $RoleIds[$roleName]
    $rdFull = "$scope/providers/Microsoft.Authorization/roleDefinitions/$roleId"

    Write-Host "[$roleName]" -ForegroundColor White
    try {
        $pa = Invoke-Arm -Method GET -Token $armToken `
            -Uri ("https://management.azure.com$scope/providers/Microsoft.Authorization/roleManagementPolicyAssignments?api-version=$armApiVersion&`$filter=" + [uri]::EscapeDataString("roleDefinitionId eq '$rdFull'"))
        if (-not $pa.value -or $pa.value.Count -eq 0) { Write-Warning "  No policy assignment found for $roleName"; continue }
        $policyId = $pa.value[0].properties.policyId
        $policy = Invoke-Arm -Method GET -Token $armToken -Uri "https://management.azure.com$policyId`?api-version=$armApiVersion"

        $changed = @()
        foreach ($ruleId in $cfg.rules.PSObject.Properties.Name) {
            $desired = $cfg.rules.$ruleId
            $rule = $policy.properties.rules | Where-Object { $_.id -eq $ruleId }
            if (-not $rule) { Write-Warning "  Rule $ruleId not present on policy - skipped"; continue }

            foreach ($prop in $desired.PSObject.Properties.Name) {
                if ($prop.StartsWith('_')) { continue }
                $val = $desired.$prop
                if ($ruleId -eq 'Approval_EndUser_Assignment') {
                    # These fields live under .setting
                    $rule.setting.$prop = $val
                    Write-Host "  $ruleId.setting.$prop -> $val"
                }
                else {
                    if ($val -is [System.Array]) { $rule.$prop = @($val) } else { $rule.$prop = $val }
                    Write-Host "  $ruleId.$prop -> $($val -join ', ')"
                }
            }

            # Dual-approval + approver population (Production only)
            if ($ruleId -eq 'Approval_EndUser_Assignment' -and $SetApprovers -and $approverMap) {
                $isDual = @($cfg.dualApprovalRoles) -contains $roleName
                $subMap = $approverMap.subscriptions.$SubscriptionId
                $upns = @()
                if ($subMap -and $subMap.roles.PSObject.Properties.Name -contains $roleName) {
                    $rm = $subMap.roles.$roleName
                    if ($rm.primary) { $upns += $rm.primary }
                    if ($rm.backup)  { $upns += $rm.backup }
                }
                if ($upns.Count -gt 0) {
                    $approvers = Resolve-ApproverIds -Upns $upns -GraphToken $graphToken
                    if ($isDual -and $approvers.Count -ge 2) {
                        $rule.setting.approvalMode = 'Serial'
                        $rule.setting.approvalStages = @(
                            @{ approvalStageTimeOutInDays=1; isApproverJustificationRequired=$true; escalationTimeInMinutes=0; isEscalationEnabled=$false; primaryApprovers=@($approvers[0]) },
                            @{ approvalStageTimeOutInDays=1; isApproverJustificationRequired=$true; escalationTimeInMinutes=0; isEscalationEnabled=$false; primaryApprovers=@($approvers[1]) }
                        )
                        Write-Host "  Approval mode -> Serial (dual approver): $($approvers.description -join ', ')"
                    }
                    else {
                        $rule.setting.approvalMode = 'SingleStage'
                        $rule.setting.approvalStages = @(
                            @{ approvalStageTimeOutInDays=1; isApproverJustificationRequired=$true; escalationTimeInMinutes=0; isEscalationEnabled=$false; primaryApprovers=$approvers }
                        )
                        Write-Host "  Approvers -> $($approvers.description -join ', ')"
                    }
                }
                else { Write-Warning "  No approver mapping for $roleName on $SubscriptionId - approval required but approvers not set" }
            }

            $changed += $rule
        }

        if ($changed.Count -eq 0) { Write-Host "  (no applicable rules)"; continue }

        if ($Apply) {
            $body = @{ properties = @{ rules = $changed } }
            $null = Invoke-Arm -Method PATCH -Token $armToken -Uri "https://management.azure.com$policyId`?api-version=$armApiVersion" -Body $body
            Write-Host "  APPLIED ($($changed.Count) rule(s))" -ForegroundColor Green
        }
        else {
            Write-Host "  would PATCH $($changed.Count) rule(s) [dry-run]" -ForegroundColor DarkGray
        }
    }
    catch {
        $code = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
        $detail = if ($_.ErrorDetails.Message) { $_.ErrorDetails.Message } else { $_.Exception.Message }
        Write-Host "  ERROR (HTTP $code): $detail" -ForegroundColor Red
    }
    Write-Host ''
}

Write-Host 'Done.' -ForegroundColor Cyan
if (-not $Apply) { Write-Host 'Re-run with -Apply to write these settings.' -ForegroundColor Yellow }
