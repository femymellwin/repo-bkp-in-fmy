# AzureSentry — Deployment Plan

> **⚠ SUPERSEDED (2026-06-27):** This file is retained for Azure-plugin history only.  
> **Use instead:** `docs/BUILD_PLAN.md` (§7 Phase 3, §9 deploy reference) and `progress.md` (live blockers + phase status).  
> Deploy commands, validation proof, and phase dependencies are maintained there.

> **Status:** Validated — ready for `azure-deploy` (see RBAC caveat below)

**Prepared by:** Azure plugin (`azure-prepare` + `azure-rbac` + `azure-validate`)
**Generated:** 2026-06-22
**Last validated:** 2026-06-24 (F1–F4 fixes + local end-to-end mock test)

---

## 1. Project Overview

**Goal:** RBAC/PIM agentic automation platform — Logic App Standard orchestrator, Automation Account runbooks, Key Vault secrets, Log Analytics audit trail.

**Path:** New Project (M3 infrastructure scaffold complete)

**Companion docs:** `docs/Azure_RBAC_PIM_Agentic_Platform_Scope_v3.md`, `docs/BUILD_PLAN.md`

---

## 2. Requirements

| Attribute | Value |
|-----------|-------|
| Classification | Development (GraphPimClient primary; MockPimClient for offline tests) |
| Scale | Small (single RG, platform identities) |
| Budget | Cost-Optimized |
| **Subscription** | `inception-internal-product` (`5a23842e-609d-42d4-bae5-e48e00e5b28d`) — re-targeted 2026-06-24 (was `github`) per PIM Contributor eligibility |
| **Location** | `uaenorth` |
| **Target resource group** | `rg-azuresentry-dev-incp-uaen-001` (created by deployment) |

---

## 3. Components Detected

| Component | Type | Technology | Path |
|-----------|------|------------|------|
| Platform stack | Infrastructure | Bicep (subscription scope) | `infra/main.bicep` |
| Key Vault | Infrastructure | Bicep module | `infra/modules/keyvault.bicep` |
| Log Analytics | Infrastructure | Bicep module | `infra/modules/loganalytics.bicep` |
| Automation Account | Infrastructure | Bicep module | `infra/modules/automation.bicep` |
| Logic App Standard | Infrastructure | Bicep module | `infra/modules/logicapp.bicep` |
| Platform RBAC | Infrastructure | Bicep module | `infra/modules/rbac-platform-identities.bicep` |
| Decision engine | Worker | PowerShell module | `src/RbacDecision/` |
| PIM client (Graph) | Worker | PowerShell module | `src/PimClient/GraphPimClient.psm1` |
| PIM client (Mock) | Test | PowerShell module | `src/PimClient/MockPimClient.psm1` |
| Decision Router runbook | Worker | Automation runbook | `src/Runbooks/Runbook-Decision-Router.ps1` |
| Sandbox runbook | Worker | Automation runbook | `src/Runbooks/Runbook-Sandbox-PIM.ps1` |
| Logic App runtime | Orchestration | host.json + connections.json | `logicapp/host.json`, `logicapp/connections.json` |
| Orchestrator workflow | Orchestration | Logic App Standard JSON | `logicapp/workflows/orchestrator/workflow.json` |
| Unit tests | Test | Pester | `tests/unit/RbacDecision.Tests.ps1` |
| Contract tests | Test | Pester | `tests/contract/PimClient.Tests.ps1` |

---

## 4. Recipe Selection

**Selected:** Bicep (subscription-scoped deployment per BUILD_PLAN D4)

**Rationale:** Creates RG + modular platform stack; validated locally with `az bicep build/lint`. Live ARM validate/what-if require subscription deploy permissions (see blockers).

---

## 5. Architecture

**Stack:** Serverless orchestration + Automation runbooks

### Service Mapping

| Component | Azure Service | SKU / Name |
|-----------|---------------|------------|
| Orchestrator | Logic App Standard | `la-azsentry-dev-uaen` on `asp-azsentry-dev-uaen` (WS1) |
| Runbooks | Automation Account | `aa-azsentry-dev-uaen` (Basic) |
| Secrets | Key Vault | `kv-azsentry-dev-uaen` (RBAC auth) |
| Audit | Log Analytics workspace | `log-azsentry-dev-uaen` (PerGB2018) |
| Runtime storage | Storage Account | `stazsentrydev001` |

---

## RBAC decisions (least privilege)

| Identity | Role | Scope | Rationale |
|----------|------|-------|-----------|
| Automation Account MI | Key Vault Secrets User | Key Vault | Read ManageEngine token + webhook secret |
| Automation Account MI | Log Analytics Contributor | Log Analytics workspace | Emit audit records |
| Logic App MI | Automation Job Operator | Automation Account | Start runbook jobs only |
| Logic App MI | Key Vault Secrets User | Key Vault | Fetch webhook shared secret (G2) |

**Bicep:** `infra/modules/rbac-platform-identities.bicep` (resource-scoped assignments)

**Deployer prerequisite:** User Access Administrator (or Owner) on target RG for role assignment deployment.

### Role Assignment Verification (static code review)

- **Status:** Verified
- **Identities checked:** Automation Account MI, Logic App Standard MI
- **Roles confirmed:**
  - Automation → Key Vault Secrets User (data-plane secret read)
  - Automation → Log Analytics Contributor (audit write)
  - Logic App → Key Vault Secrets User (webhook secret fetch — used in G2 comparison)
  - Logic App → Automation Job Operator (start jobs, not edit runbooks)
- **Scope:** Each role scoped to specific resource (not RG/subscription)
- **Issues:** None — no generic Reader/Contributor used for data-plane access

---

## 6. Provisioning Limit Checklist

| Resource Type | Number to Deploy | Current in Sub (uaenorth) | Limit/Quota | Notes |
|---------------|------------------|---------------------------|-------------|-------|
| Microsoft.KeyVault/vaults | 1 | 0 (graph) | 1000 per sub | Within limit |
| Microsoft.OperationalInsights/workspaces | 1 | 0 (graph) | 50 per region | Within limit |
| Microsoft.Automation/automationAccounts | 1 | 0 (graph) | 10 per sub | Within limit |
| Microsoft.Web/sites | 1 | 0 (graph) | 100 per plan region | Within limit |
| Microsoft.Web/serverfarms | 1 | 0 (graph) | WS1 WorkflowStandard | Within limit |
| Microsoft.Storage/storageAccounts | 1 | 0 (graph) | 250 per region | Within limit |

**Status:** All resources within documented limits.

---

## 7. Execution Checklist

### Phase 1: Planning
- [x] Analyze workspace
- [x] Select recipe (Bicep)
- [x] Plan architecture + RBAC matrix
- [x] Confirm subscription and location (re-targeted to `inception-internal-product` / `uaenorth`)
- [x] User approved this plan (proceeding with dev scaffold)

### Phase 2: Execution
- [x] Key Vault module
- [x] Log Analytics module
- [x] Automation Account module
- [x] Logic App Standard module
- [x] Platform RBAC module (resource-scoped assignments)
- [x] `infra/main.bicep` + `infra/main.parameters.json`
- [x] Decision engine (`src/RbacDecision/`) + eligibility matrix data
- [x] GraphPimClient + MockPimClient (`src/PimClient/`)
- [x] Sandbox runbook (`Runbook-Sandbox-PIM.ps1`)
- [x] **Decision Router runbook (`Runbook-Decision-Router.ps1`)** — F1 fix
- [x] **Logic App runtime files (`logicapp/host.json`, `logicapp/connections.json`)** — F4 fix
- [x] **Orchestrator workflow — HTTP action + G2 secret check** — F3 fix
- [x] **Bicep app settings for Automation Account context** — Bicep wiring fix
- [x] Pester unit + contract tests (30/30 pass)
- [x] Update plan status to **Ready for Validation**

### Phase 3: Validation
- [x] Plan status = Ready for Validation
- [x] All local validation checks pass
  - [x] Live Azure inventory (`group_list`)
  - [x] Bicep schema validation (6 resource types)
  - [x] Static RBAC review
  - [x] Bicep compilation (`az bicep build`)
  - [x] Bicep lint (`az bicep lint`)
  - [x] Authentication (`az account show`)
  - [x] Pester unit + contract tests (30/30 pass)
  - [x] **Local end-to-end mock test (Sandbox path)** — 2026-06-24
  - [x] **Template validation (`az deployment sub validate`)** — Succeeded, no errors — 2026-06-24 (F6 resolved via PIM Contributor on `inception-internal-product`)
  - [x] **What-if preview** — Succeeded — 7 resources to Create; 4 role assignments report `Unsupported` (WhatIfUnidentifiableResource — benign, principalId not known until deploy) — 2026-06-24
- [x] Plan status = **Validated** (live ARM validate + what-if pass)

### Phase 4: Deployment
- [ ] Invoke azure-deploy (after Validated + what-if)
- [ ] Upload runbooks to Automation Account
- [ ] Deploy Logic App workflow (zip deploy `logicapp/` folder)
- [ ] Configure Key Vault secrets (ManageEngine-WebhookSecret, ManageEngine API token)
- [ ] Grant Automation MI Graph permissions (requires Entra P2)
- [ ] Update plan status to **Deployed**

---

## 8. Validation Proof

| Check | Command / Tool | Result | Timestamp |
|-------|----------------|--------|-----------|
| Live Azure inventory | MCP `group_list` | Pass — 27 RGs; no target RG yet | 2026-06-22 |
| Bicep schema — Key Vault | MCP `bicepschema_get` | Pass | 2026-06-22 |
| Bicep schema — Log Analytics | MCP `bicepschema_get` | Pass | 2026-06-22 |
| Bicep schema — Automation | MCP `bicepschema_get` | Pass | 2026-06-22 |
| Bicep schema — Logic App | MCP `bicepschema_get` | Pass | 2026-06-22 |
| Bicep schema — Role assignments | MCP `bicepschema_get` | Pass | 2026-06-22 |
| Authentication | `az account show` | Pass — `abdulla.alfalasi@inceptionai.ai` on sub `github` | 2026-06-22 |
| Bicep compilation | `az bicep build --file infra/main.bicep` | Pass (post F1–F4 changes) | 2026-06-24 |
| Bicep lint | `az bicep lint --file infra/main.bicep` | Pass (post F1–F4 changes) | 2026-06-24 |
| Pester — decision engine | `tests/unit/RbacDecision.Tests.ps1` | Pass — 21/21 | 2026-06-22 |
| Pester — PIM contract | `tests/contract/PimClient.Tests.ps1` | Pass — 9/9 | 2026-06-22 |
| Static RBAC review | Code review of `rbac-platform-identities.bicep` | Pass — least privilege, resource-scoped | 2026-06-22 |
| **Local e2e mock test** | `& src/Runbooks/Runbook-Decision-Router.ps1` with MockPimClient | **Pass** — Sandbox Reader→Grant, AssignmentId=mock-active-1 | **2026-06-24** |
| Template validate | `az deployment sub validate ...` | **Pass** — `provisioningState: Succeeded`, no errors | 2026-06-24 |
| What-if preview | `az deployment sub what-if ...` | **Pass** — `status: Succeeded`; 7 Create, 4 role assignments `Unsupported` (benign) | 2026-06-24 |

### Blocker — live ARM validate / what-if (F6)

Identity needs deployment-validate permission on the target subscription. Resolution: activate **PIM Contributor** on `inception-internal-product` (`5a23842e-…`) via portal (My roles → Azure resources), then set the CLI to that subscription and run:

```powershell
az account set --subscription 5a23842e-609d-42d4-bae5-e48e00e5b28d

az deployment sub validate `
  --location uaenorth `
  --template-file infra/main.bicep `
  --parameters infra/main.parameters.json

az deployment sub what-if `
  --location uaenorth `
  --template-file infra/main.bicep `
  --parameters infra/main.parameters.json
```

After both pass, set status to **Validated** and proceed to **azure-deploy**.

---

## 9. Azure Context

| Setting | Value |
|---------|-------|
| Subscription | `inception-internal-product` (`5a23842e-609d-42d4-bae5-e48e00e5b28d`) |
| Tenant | `5ac4936b-1ac4-4e57-9e2b-48673491865e` |
| Default region | `uaenorth` |
| Auth | `az login` as `abdulla.alfalasi@inceptionai.ai` |

---

## 10. Files

| File | Purpose | Status |
|------|---------|--------|
| `.azure/deployment-plan.md` | This plan | Done |
| `infra/main.bicep` | Subscription deployment root (added `deployRbac` flag) | Done |
| `infra/main.parameters.json` | Deployment parameters | Done |
| `infra/modules/platform.bicep` | Module composition (passes AA context to Logic App; RBAC module gated by `deployRbac`) | Done |
| `infra/modules/keyvault.bicep` | Key Vault | Done |
| `infra/modules/loganalytics.bicep` | Log Analytics | Done |
| `infra/modules/automation.bicep` | Automation Account | Done |
| `infra/modules/logicapp.bicep` | Logic App Standard + plan + storage (updated: AA app settings) | Done |
| `infra/modules/rbac-platform-identities.bicep` | Platform RBAC (**fixed Log Analytics Contributor role GUID**) | Done |
| `src/RbacDecision/` | Decision engine module (M1) | Done |
| `src/PimClient/GraphPimClient.psm1` | Real Graph PIM client | Done |
| `src/PimClient/MockPimClient.psm1` | Offline test client | Done |
| `src/Runbooks/Runbook-Decision-Router.ps1` | **Entry-point router (F1 — new)** | Done |
| `src/Runbooks/Runbook-Sandbox-PIM.ps1` | Sandbox full-auto runbook | Done |
| `src/Runbooks/Runbook-Prod-PIM.ps1` | Production approval runbook | **Pending M5** |
| `src/Runbooks/Runbook-Emergency-PIM.ps1` | Break-glass runbook | **Pending M6** |
| `src/Runbooks/Runbook-Status-Updater.ps1` | PIM polling + ticket update | **Pending M5** |
| `src/Runbooks/Runbook-BreakGlass-Reaper.ps1` | G3 auto-revocation | **Pending M6** |
| `logicapp/host.json` | **Logic App Standard runtime config (F4 — new)** | Done |
| `logicapp/connections.json` | **Logic App managed connections (F4 — new)** | Done |
| `logicapp/workflows/orchestrator/workflow.json` | **Thin orchestrator — HTTP action + G2 secret check (F3 — updated)** | Done |
| `tests/unit/RbacDecision.Tests.ps1` | §2.2 matrix + reject paths | Done |
| `tests/contract/PimClient.Tests.ps1` | IPimClient contract tests | Done |

---

## 11. Pre-Deployment Audit (2026-06-24)

A parallel readiness audit (4 dimensions, adversarially verified) was run before any `az deployment sub create`. **Verdict: GO-WITH-CAVEATS** via a split (RBAC-deferred) deploy.

**Confirmed blockers/fixes (already applied):**
- **RBAC under Contributor** — Contributor's `notActions` deny `Microsoft.Authorization/*/Write`, so the 4 platform role assignments cannot be created by the current identity (verified: deployer holds only Contributor + Billing Reader). **Resolution:** added `deployRbac` bool param (default `false`) threaded `main.bicep → platform.bicep`, gating the RBAC module. Infra now deploys green under Contributor; RBAC applied separately once UAA/Owner is PIM-activated.
- **Wrong Log Analytics Contributor role GUID (bug)** — `rbac-platform-identities.bicep` had `92aaf0da-…-b43a6c6c8a3f`, which resolves to **no role**. **Fixed** to `92aaf0da-9dab-42b6-94a3-d43ce8d16293` (verified live).

**Confirmed clear:**
- WS1 Workflow Standard **is available** in `uaenorth` (not a blocker).
- All global names available: `stazsentrydev001`, `kv-azsentry-dev-uaen` (no soft-deleted collision); target RG absent (greenfield, no destructive changes).
- What-if with `deployRbac=false`: **7 Create, 0 Unsupported** — fully analyzable, additive plan.

**Dev-acceptable notes (document before prod):** KV `publicNetworkAccess=Enabled` (no ACLs); Log Analytics public ingestion+query Enabled; Storage internet-open data plane + Logic App uses embedded account keys; Automation `publicNetworkAccess=true`; KV soft-delete 7d, no purge protection. Ballpark dev cost **~USD 215–290/mo**, ~80–90% from the always-on WS1 plan.

---

## 12. Next Steps

1. ✅ F6 resolved — PIM Contributor active on `inception-internal-product`; validate + what-if pass.
2. **Deploy infra (RBAC gated off) under Contributor:**
   ```powershell
   az deployment sub create `
     --name azuresentry-infra-20260624 `
     --location uaenorth `
     --template-file infra/main.bicep `
     --parameters infra/main.parameters.json deployRbac=false
   ```
3. **PIM-activate User Access Administrator (or Owner)** on the subscription/RG.
4. **Apply RBAC** as a standalone run (idempotent — names use `guid(scope,principalId,roleId)`):
   ```powershell
   az deployment sub create `
     --name azuresentry-rbac-20260624 `
     --location uaenorth `
     --template-file infra/main.bicep `
     --parameters infra/main.parameters.json deployRbac=true
   ```
   Then verify: `az role assignment list --scope <kvId>/<laId>/<aaId>` (expect 4 assignments).
5. Upload runbooks to Automation Account; set `AZURESENTRY_AA_NAME`, `AZURESENTRY_AA_RG`, `AZURESENTRY_SUBSCRIPTION_ID` as Automation Account variables.
6. Zip deploy `logicapp/` folder to Logic App `la-azsentry-dev-uaen`.
7. Configure Key Vault secrets: `ManageEngine-WebhookSecret` + ManageEngine API token.
8. Grant Automation MI Graph permissions: `PrivilegedAccess.ReadWrite.AzureResources` + `User.Read.All` (requires Entra P2).
9. Implement M5–M6 runbooks: Prod-PIM, Emergency-PIM, Status-Updater, BreakGlass-Reaper.
10. Live GraphPimClient smoke test against P2 tenant (M4).
