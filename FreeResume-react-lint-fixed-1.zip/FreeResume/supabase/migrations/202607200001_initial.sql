-- FreeResume initial schema
-- Apply with: supabase db push

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 160),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.resumes (
  id text not null check (char_length(id) between 1 and 120 and id ~ '^[A-Za-z0-9_-]+$'),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  template_id text not null check (template_id in ('modern', 'minimal', 'professional', 'executive', 'creative')),
  data jsonb not null check (jsonb_typeof(data) = 'object' and pg_column_size(data) <= 2000000),
  settings jsonb not null check (jsonb_typeof(settings) = 'object' and pg_column_size(settings) <= 50000),
  sections jsonb not null check (jsonb_typeof(sections) = 'array' and jsonb_array_length(sections) <= 50 and pg_column_size(sections) <= 100000),
  version integer not null default 1 check (version > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

create index if not exists resumes_user_updated_idx on public.resumes (user_id, updated_at desc);

create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  email text not null check (char_length(email) between 3 and 254),
  category text not null check (category in ('feedback', 'bug', 'feature', 'privacy', 'other')),
  message text not null check (char_length(message) between 10 and 5000),
  created_at timestamptz not null default now()
);

create index if not exists feedback_created_idx on public.feedback (created_at desc);

create table if not exists public.ai_usage (
  subject_hash text not null check (char_length(subject_hash) = 64),
  usage_date date not null default current_date,
  request_count integer not null default 0 check (request_count >= 0),
  updated_at timestamptz not null default now(),
  primary key (subject_hash, usage_date)
);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists resumes_set_updated_at on public.resumes;
create trigger resumes_set_updated_at before update on public.resumes
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, nullif(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.resumes enable row level security;
alter table public.feedback enable row level security;
alter table public.ai_usage enable row level security;

create policy "Users can view their profile"
on public.profiles for select
to authenticated
using ((select auth.uid()) = id);

create policy "Users can update their profile"
on public.profiles for update
to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

create policy "Users can view their resumes"
on public.resumes for select
to authenticated
using ((select auth.uid()) = user_id);

create policy "Users can create their resumes"
on public.resumes for insert
to authenticated
with check ((select auth.uid()) = user_id);

create policy "Users can update their resumes"
on public.resumes for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "Users can delete their resumes"
on public.resumes for delete
to authenticated
using ((select auth.uid()) = user_id);

-- Minimize browser grants. RLS remains the final authorization boundary.
revoke all on public.profiles, public.resumes, public.feedback, public.ai_usage from anon;
revoke all on public.feedback, public.ai_usage from authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.resumes to authenticated;
grant all on public.profiles, public.resumes, public.feedback, public.ai_usage to service_role;

create or replace function public.consume_ai_quota(
  p_subject_hash text,
  p_daily_limit integer
)
returns table (allowed boolean, remaining integer)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_count integer;
begin
  if p_subject_hash is null or char_length(p_subject_hash) <> 64 then
    raise exception 'Invalid subject hash';
  end if;
  if p_daily_limit < 1 or p_daily_limit > 1000 then
    raise exception 'Invalid daily limit';
  end if;

  insert into public.ai_usage (subject_hash, usage_date, request_count, updated_at)
  values (p_subject_hash, current_date, 1, now())
  on conflict (subject_hash, usage_date)
  do update set
    request_count = public.ai_usage.request_count + 1,
    updated_at = now()
  where public.ai_usage.request_count < p_daily_limit
  returning request_count into v_count;

  -- When the row is already at the limit, the conflict update's WHERE clause
  -- prevents an increment and RETURNING yields no row.
  if not found then
    return query select false, 0;
    return;
  end if;

  return query select true, greatest(p_daily_limit - v_count, 0);
end;
$$;

revoke all on function public.consume_ai_quota(text, integer) from public, anon, authenticated;
grant execute on function public.consume_ai_quota(text, integer) to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'resume-assets',
  'resume-assets',
  false,
  2000000,
  array['image/jpeg', 'image/png', 'image/webp']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy "Users can view their resume assets"
on storage.objects for select
to authenticated
using (
  bucket_id = 'resume-assets'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "Users can upload their resume assets"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'resume-assets'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "Users can update their resume assets"
on storage.objects for update
to authenticated
using (
  bucket_id = 'resume-assets'
  and (storage.foldername(name))[1] = (select auth.uid())::text
)
with check (
  bucket_id = 'resume-assets'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "Users can delete their resume assets"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'resume-assets'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);
