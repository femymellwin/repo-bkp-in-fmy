-- Run after applying migrations:
-- psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/schema_smoke.sql

begin;

-- Verify that every sensitive public table has row-level security enabled.
do $$
declare
  missing_tables text;
begin
  select string_agg(c.relname, ', ' order by c.relname)
  into missing_tables
  from pg_class c
  join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public'
    and c.relname in ('profiles', 'resumes', 'feedback', 'ai_usage')
    and not c.relrowsecurity;

  if missing_tables is not null then
    raise exception 'RLS is not enabled for: %', missing_tables;
  end if;
end;
$$;

-- Verify exact quota behavior: two allowed calls, then rejection.
do $$
declare
  test_hash text := repeat('a', 64);
  first_allowed boolean;
  first_remaining integer;
  second_allowed boolean;
  second_remaining integer;
  third_allowed boolean;
  third_remaining integer;
begin
  delete from public.ai_usage where subject_hash = test_hash and usage_date = current_date;

  select allowed, remaining into first_allowed, first_remaining
  from public.consume_ai_quota(test_hash, 2);
  select allowed, remaining into second_allowed, second_remaining
  from public.consume_ai_quota(test_hash, 2);
  select allowed, remaining into third_allowed, third_remaining
  from public.consume_ai_quota(test_hash, 2);

  if first_allowed is not true or first_remaining <> 1 then
    raise exception 'Unexpected first quota result: %, %', first_allowed, first_remaining;
  end if;
  if second_allowed is not true or second_remaining <> 0 then
    raise exception 'Unexpected second quota result: %, %', second_allowed, second_remaining;
  end if;
  if third_allowed is not false or third_remaining <> 0 then
    raise exception 'Quota did not reject at the limit: %, %', third_allowed, third_remaining;
  end if;
end;
$$;

rollback;
