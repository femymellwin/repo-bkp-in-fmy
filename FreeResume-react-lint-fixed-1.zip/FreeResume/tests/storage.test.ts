import { beforeEach, describe, expect, it } from "vitest";
import { createBlankResume } from "@/lib/resume/sample";
import { deleteLocalResume, getLocalResume, readLocalResumes, saveLocalResume } from "@/lib/resume/storage";

describe("local resume storage", () => {
  beforeEach(() => window.localStorage.clear());

  it("creates and reads a resume", () => {
    const resume = createBlankResume();
    saveLocalResume(resume);
    expect(readLocalResumes()).toHaveLength(1);
    expect(getLocalResume(resume.id)?.name).toBe("Untitled Resume");
  });

  it("updates an existing resume without duplicating it", () => {
    const resume = createBlankResume();
    saveLocalResume(resume);
    saveLocalResume({ ...resume, name: "Updated name" });
    expect(readLocalResumes()).toHaveLength(1);
    expect(getLocalResume(resume.id)?.name).toBe("Updated name");
  });

  it("deletes a resume", () => {
    const resume = createBlankResume();
    saveLocalResume(resume);
    deleteLocalResume(resume.id);
    expect(readLocalResumes()).toEqual([]);
  });

  it("keeps valid resumes when another stored record is malformed", () => {
    const resume = createBlankResume();
    window.localStorage.setItem("freeresume:resumes:v1", JSON.stringify([resume, { id: "unsafe/path" }]));
    expect(readLocalResumes()).toHaveLength(1);
    expect(readLocalResumes()[0]?.id).toBe(resume.id);
  });

  it("fails closed when storage data is corrupt", () => {
    window.localStorage.setItem("freeresume:resumes:v1", "not-json");
    expect(readLocalResumes()).toEqual([]);
  });
});
