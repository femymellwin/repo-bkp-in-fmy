import { describe, expect, it } from "vitest";
import { createBlankResume, createSampleResume } from "@/lib/resume/sample";
import { resumeDocumentSchema } from "@/lib/resume/schema";
import { resumeTemplates } from "@/lib/resume/templates";

describe("resume schema", () => {
  it("accepts the realistic sample resume", () => {
    expect(resumeDocumentSchema.safeParse(createSampleResume()).success).toBe(true);
  });

  it("accepts a blank resume", () => {
    expect(resumeDocumentSchema.safeParse(createBlankResume()).success).toBe(true);
  });

  it("ships five templates with at least three strict ATS layouts", () => {
    expect(resumeTemplates).toHaveLength(5);
    expect(resumeTemplates.filter((template) => template.atsFriendly && template.layout === "single-column").length).toBeGreaterThanOrEqual(3);
  });

  it("rejects IDs with path separators or markup characters", () => {
    const resume = createSampleResume();
    resume.id = "../../unsafe";
    expect(resumeDocumentSchema.safeParse(resume).success).toBe(false);
  });

  it("rejects executable or unsupported profile-image data URLs", () => {
    const resume = createSampleResume();
    resume.data.personal.photoUrl = "data:image/svg+xml;base64,PHN2Zy8+";
    expect(resumeDocumentSchema.safeParse(resume).success).toBe(false);
  });

  it("rejects malformed embedded-image base64", () => {
    const resume = createSampleResume();
    resume.data.personal.photoUrl = "data:image/png;base64,not valid base64";
    expect(resumeDocumentSchema.safeParse(resume).success).toBe(false);
  });

  it("rejects arbitrary remote profile-image URLs", () => {
    const resume = createSampleResume();
    resume.data.personal.photoUrl = "https://tracker.example/pixel.png";
    expect(resumeDocumentSchema.safeParse(resume).success).toBe(false);
  });

  it("accepts approved embedded profile-image formats", () => {
    const resume = createSampleResume();
    resume.data.personal.photoUrl = "data:image/png;base64,iVBORw0KGgo=";
    expect(resumeDocumentSchema.safeParse(resume).success).toBe(true);
  });

  it("rejects unknown template identifiers", () => {
    const resume = createSampleResume();
    const malformed = { ...resume, settings: { ...resume.settings, templateId: "unknown" } };
    expect(resumeDocumentSchema.safeParse(malformed).success).toBe(false);
  });

  it("rejects invalid accent colors", () => {
    const resume = createSampleResume();
    resume.settings.accentColor = "javascript:alert(1)";
    expect(resumeDocumentSchema.safeParse(resume).success).toBe(false);
  });
});
