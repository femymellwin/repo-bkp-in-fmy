import { describe, expect, it } from "vitest";
import { buildAiPrompt } from "@/lib/ai/prompts";

describe("AI prompt safety", () => {
  it("instructs the provider not to invent facts", () => {
    const prompt = buildAiPrompt({ action: "improve_bullet", content: "Managed a team", jobDescription: "" });
    expect(prompt.instructions.toLowerCase()).toContain("never invent");
    expect(prompt.input).toContain("Managed a team");
  });
});
