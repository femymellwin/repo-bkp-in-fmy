import { describe, expect, it } from "vitest";
import { mailto, moveItem, safeExternalUrl, safeInternalPath, tel } from "@/lib/utils";

describe("URL safety", () => {
  it("adds HTTPS to a normal domain or host with a port", () => {
    expect(safeExternalUrl("example.com")).toBe("https://example.com/");
    expect(safeExternalUrl("localhost:3000/path")).toBe("https://localhost:3000/path");
  });

  it("rejects executable URL schemes", () => {
    expect(safeExternalUrl("javascript:alert(1)")).toBeUndefined();
    expect(safeExternalUrl("data:text/html,hello")).toBeUndefined();
  });

  it("accepts only same-origin relative redirect paths", () => {
    expect(safeInternalPath("/builder/resume-1?tab=design")).toBe("/builder/resume-1?tab=design");
    expect(safeInternalPath("//evil.example/path")).toBe("/dashboard");
    expect(safeInternalPath("https://evil.example/path")).toBe("/dashboard");
    expect(safeInternalPath("/\\evil.example/path")).toBe("/dashboard");
  });

  it("normalizes email and telephone links", () => {
    expect(mailto("person@example.com")).toBe("mailto:person%40example.com");
    expect(tel("+971 50 123 4567")).toBe("tel:+971501234567");
  });
});

describe("moveItem", () => {
  it("moves an item while preserving the others", () => {
    expect(moveItem(["a", "b", "c"], 2, 0)).toEqual(["c", "a", "b"]);
  });
});
