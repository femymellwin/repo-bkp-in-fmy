import type { AiRequest } from "@/lib/resume/schema";

const instructions = `You are a precise resume-writing assistant. Write truthful, concise, ATS-compatible content. Never invent employers, degrees, metrics, certifications, tools, dates, or achievements. When a measurable result is missing, suggest a bracketed placeholder such as [X%] rather than fabricating a number. Use plain text only. Do not use markdown headings unless the request is for a cover letter or comparison report.`;

const tasks: Record<AiRequest["action"], string> = {
  generate_summary: "Create a 2–4 sentence professional summary based only on the supplied facts. Emphasize role, experience, specialism, and demonstrated outcomes.",
  improve_bullet: "Rewrite the supplied experience bullet as one concise achievement-oriented bullet. Start with a strong action verb and preserve all facts.",
  stronger_action_verbs: "Rewrite the supplied resume text with specific, varied action verbs. Preserve meaning and facts. Return only the revised text.",
  correct_grammar: "Correct grammar, spelling, punctuation, and clarity while preserving the writer's meaning and tone. Return only the corrected text.",
  suggest_achievements: "Suggest 5 evidence prompts the user can answer to turn this responsibility into measurable achievements. Use bracketed placeholders and do not invent results.",
  suggest_skills: "Suggest a focused list of ATS-relevant skills for the supplied role and background. Separate skills with commas and avoid unsupported claims that imply proficiency.",
  compare_job: "Compare the resume content with the job description. Return: strongest matches, important gaps, keywords to consider, and 5 specific truthful tailoring actions.",
  generate_cover_letter: "Write a concise, professional cover letter based only on the supplied resume facts and job description. Use a neutral greeting when the hiring manager is unknown. Do not fabricate claims.",
};

export function buildAiPrompt(request: AiRequest) {
  return {
    instructions,
    input: `${tasks[request.action]}\n\nRESUME OR SOURCE CONTENT:\n${request.content}${request.jobDescription ? `\n\nJOB DESCRIPTION:\n${request.jobDescription}` : ""}`,
  };
}
