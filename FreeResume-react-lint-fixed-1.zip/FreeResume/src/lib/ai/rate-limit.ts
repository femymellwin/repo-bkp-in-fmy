import { createHash } from "node:crypto";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";

const memory = new Map<string, { date: string; count: number }>();

export function hashRateLimitSubject(subject: string) {
  const configuredSecret = process.env.AI_RATE_LIMIT_SECRET;
  if (!configuredSecret && process.env.NODE_ENV === "production") {
    throw new Error("AI_RATE_LIMIT_SECRET is required in production.");
  }
  const secret = configuredSecret || "development-only-secret";
  return createHash("sha256").update(`${secret}:${subject}`).digest("hex");
}

export async function consumeAiQuota(subjectHash: string, dailyLimit: number) {
  const admin = createAdminSupabaseClient();
  if (admin) {
    const { data, error } = await admin.rpc("consume_ai_quota", {
      p_subject_hash: subjectHash,
      p_daily_limit: dailyLimit,
    });
    if (error) throw error;
    const result = data?.[0];
    return { allowed: Boolean(result?.allowed), remaining: Number(result?.remaining ?? 0) };
  }

  if (process.env.NODE_ENV === "production") {
    throw new Error("AI rate limiting requires SUPABASE_SERVICE_ROLE_KEY in production.");
  }
  const date = new Date().toISOString().slice(0, 10);
  const current = memory.get(subjectHash);
  const count = current?.date === date ? current.count : 0;
  if (count >= dailyLimit) return { allowed: false, remaining: 0 };
  memory.set(subjectHash, { date, count: count + 1 });
  return { allowed: true, remaining: Math.max(0, dailyLimit - count - 1) };
}
