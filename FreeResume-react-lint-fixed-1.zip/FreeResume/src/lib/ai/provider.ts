import type { AiRequest } from "@/lib/resume/schema";
import { buildAiPrompt } from "@/lib/ai/prompts";

type OpenAIResponse = {
  output_text?: string;
  output?: Array<{ content?: Array<{ type?: string; text?: string }> }>;
  error?: { message?: string };
};

function extractOutput(data: OpenAIResponse) {
  if (data.output_text?.trim()) return data.output_text.trim();
  const text = data.output
    ?.flatMap((item) => item.content ?? [])
    .filter((item) => item.type === "output_text" && item.text)
    .map((item) => item.text)
    .join("\n")
    .trim();
  return text || "";
}

export async function generateAiText(request: AiRequest) {
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL;
  if (!apiKey || !model) throw new Error("AI provider is not configured. Set OPENAI_API_KEY and OPENAI_MODEL.");
  const prompt = buildAiPrompt(request);
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model,
      instructions: prompt.instructions,
      input: prompt.input,
      max_output_tokens: request.action === "generate_cover_letter" ? 1200 : 800,
    }),
    signal: AbortSignal.timeout(45_000),
  });
  const data = await response.json() as OpenAIResponse;
  if (!response.ok) throw new Error(data.error?.message || `AI provider returned ${response.status}.`);
  const output = extractOutput(data);
  if (!output) throw new Error("The AI provider returned an empty response.");
  return output.slice(0, 12_000);
}
