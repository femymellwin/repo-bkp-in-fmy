export const appConfig = {
  name: process.env.NEXT_PUBLIC_APP_NAME || "FreeResume",
  url: (process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000").replace(/\/$/, ""),
  supportEmail: process.env.NEXT_PUBLIC_SUPPORT_EMAIL || "support@example.com",
  description:
    "Create an ATS-friendly professional resume for free. No watermark, no hidden payment, and no account required.",
  aiEnabled: process.env.NEXT_PUBLIC_AI_ENABLED === "true",
} as const;

export function hasPublicSupabaseConfig() {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
      process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
  );
}
