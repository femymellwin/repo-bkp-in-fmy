import { z } from "zod";

const shortText = z.string().trim().max(160);
const mediumText = z.string().trim().max(600);
const longText = z.string().trim().max(5000);
const optionalUrlText = z.string().trim().max(500);
const dateText = z.string().trim().max(30);
const id = z.string().min(1).max(120).regex(/^[A-Za-z0-9_-]+$/);
const photoUrl = z.string().max(3_000_000).refine((value) => {
  if (!value) return true;
  const embedded = value.match(/^data:image\/(?:jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/i);
  if (embedded) return embedded[1].length % 4 === 0;
  try {
    const url = new URL(value);
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    if (!supabaseUrl) return false;
    const allowedOrigin = new URL(supabaseUrl).origin;
    return (url.protocol === "http:" || url.protocol === "https:")
      && url.origin === allowedOrigin
      && url.pathname.startsWith("/storage/v1/object/sign/resume-assets/");
  } catch {
    return false;
  }
}, "Use an embedded JPEG, PNG, or WebP image.");

export const personalSchema = z.object({
  fullName: shortText,
  jobTitle: shortText,
  photoUrl: photoUrl.optional().default(""),
  photoPath: z.string().max(500).regex(/^(?:[A-Za-z0-9_-]+\/){2}profile\.(?:jpg|png|webp)$|^$/).optional().default(""),
});

export const contactSchema = z.object({
  email: z.string().trim().max(254),
  phone: z.string().trim().max(50),
  location: shortText,
  website: optionalUrlText,
  linkedin: optionalUrlText,
  portfolio: optionalUrlText,
});

export const experienceSchema = z.object({
  id,
  company: shortText,
  role: shortText,
  location: shortText,
  startDate: dateText,
  endDate: dateText,
  current: z.boolean().default(false),
  description: mediumText,
  highlights: z.array(mediumText).max(20),
});

export const educationSchema = z.object({
  id,
  institution: shortText,
  degree: shortText,
  field: shortText,
  location: shortText,
  startDate: dateText,
  endDate: dateText,
  score: shortText,
  description: mediumText,
});

export const skillGroupSchema = z.object({
  id,
  name: shortText,
  skills: z.array(shortText).max(50),
});

export const projectSchema = z.object({
  id,
  name: shortText,
  role: shortText,
  url: optionalUrlText,
  startDate: dateText,
  endDate: dateText,
  description: mediumText,
  highlights: z.array(mediumText).max(20),
});

export const certificationSchema = z.object({
  id,
  name: shortText,
  issuer: shortText,
  date: dateText,
  url: optionalUrlText,
});

export const languageSchema = z.object({
  id,
  name: shortText,
  proficiency: shortText,
});

export const awardSchema = z.object({
  id,
  title: shortText,
  issuer: shortText,
  date: dateText,
  description: mediumText,
});

export const publicationSchema = z.object({
  id,
  title: shortText,
  publisher: shortText,
  date: dateText,
  url: optionalUrlText,
  description: mediumText,
});

export const volunteerSchema = z.object({
  id,
  organization: shortText,
  role: shortText,
  startDate: dateText,
  endDate: dateText,
  description: mediumText,
  highlights: z.array(mediumText).max(20),
});

export const referenceSchema = z.object({
  id,
  name: shortText,
  relationship: shortText,
  email: z.string().trim().max(254),
  phone: z.string().trim().max(50),
});

export const customItemSchema = z.object({
  id,
  heading: shortText,
  subheading: shortText,
  date: dateText,
  description: mediumText,
  highlights: z.array(mediumText).max(20),
});

export const customSectionSchema = z.object({
  id,
  title: shortText,
  items: z.array(customItemSchema).max(100),
});

export const resumeDataSchema = z.object({
  personal: personalSchema,
  contact: contactSchema,
  summary: longText,
  experience: z.array(experienceSchema).max(100),
  education: z.array(educationSchema).max(100),
  skills: z.array(skillGroupSchema).max(100),
  projects: z.array(projectSchema).max(100),
  certifications: z.array(certificationSchema).max(100),
  languages: z.array(languageSchema).max(100),
  awards: z.array(awardSchema).max(100),
  publications: z.array(publicationSchema).max(100),
  volunteer: z.array(volunteerSchema).max(100),
  references: z.array(referenceSchema).max(100),
  customSections: z.array(customSectionSchema).max(30),
});

export const builtInSectionIdSchema = z.enum([
  "personal",
  "contact",
  "summary",
  "experience",
  "education",
  "skills",
  "projects",
  "certifications",
  "languages",
  "awards",
  "publications",
  "volunteer",
  "references",
]);

export const sectionConfigSchema = z.object({
  id,
  title: shortText,
  visible: z.boolean(),
});

export const templateIdSchema = z.enum([
  "modern",
  "minimal",
  "professional",
  "executive",
  "creative",
]);

export const resumeSettingsSchema = z.object({
  templateId: templateIdSchema,
  fontFamily: z.enum(["inter", "source-sans", "merriweather", "georgia"]),
  fontSize: z.number().min(8).max(14),
  lineHeight: z.number().min(1.1).max(1.8),
  accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  headingStyle: z.enum(["uppercase", "title", "underline"]),
  pageMargin: z.number().min(8).max(30),
  showPhoto: z.boolean(),
  showPageBreaks: z.boolean(),
});

export const resumeDocumentSchema = z.object({
  id,
  name: z.string().trim().min(1).max(120),
  data: resumeDataSchema,
  sections: z.array(sectionConfigSchema).min(1).max(50),
  settings: resumeSettingsSchema,
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  version: z.literal(1),
});

export const feedbackSchema = z.object({
  email: z.string().trim().email().max(254),
  category: z.enum(["feedback", "bug", "feature", "privacy", "other"]),
  message: z.string().trim().min(10).max(5000),
  website: z.string().max(0).optional().default(""),
});

export const aiRequestSchema = z.object({
  action: z.enum([
    "generate_summary",
    "improve_bullet",
    "stronger_action_verbs",
    "correct_grammar",
    "suggest_achievements",
    "suggest_skills",
    "compare_job",
    "generate_cover_letter",
  ]),
  content: z.string().trim().min(3).max(12_000),
  jobDescription: z.string().trim().max(20_000).optional().default(""),
});

export type ResumeData = z.infer<typeof resumeDataSchema>;
export type ResumeDocument = z.infer<typeof resumeDocumentSchema>;
export type ResumeSettings = z.infer<typeof resumeSettingsSchema>;
export type SectionConfig = z.infer<typeof sectionConfigSchema>;
export type TemplateId = z.infer<typeof templateIdSchema>;
export type Experience = z.infer<typeof experienceSchema>;
export type Education = z.infer<typeof educationSchema>;
export type SkillGroup = z.infer<typeof skillGroupSchema>;
export type Project = z.infer<typeof projectSchema>;
export type Certification = z.infer<typeof certificationSchema>;
export type Language = z.infer<typeof languageSchema>;
export type Award = z.infer<typeof awardSchema>;
export type Publication = z.infer<typeof publicationSchema>;
export type Volunteer = z.infer<typeof volunteerSchema>;
export type Reference = z.infer<typeof referenceSchema>;
export type CustomSection = z.infer<typeof customSectionSchema>;
export type CustomItem = z.infer<typeof customItemSchema>;
export type AiRequest = z.infer<typeof aiRequestSchema>;
