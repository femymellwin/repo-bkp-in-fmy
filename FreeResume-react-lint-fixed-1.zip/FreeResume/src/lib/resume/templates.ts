import type { TemplateId } from "@/lib/resume/schema";

export type ResumeTemplateDefinition = {
  id: TemplateId;
  name: string;
  description: string;
  atsFriendly: boolean;
  layout: "single-column" | "enhanced-single-column";
  defaultAccent: string;
  fontFamily: "inter" | "source-sans" | "merriweather" | "georgia";
};

export const resumeTemplates: ResumeTemplateDefinition[] = [
  {
    id: "modern",
    name: "Modern",
    description: "Clean hierarchy, restrained accent rules, and generous spacing.",
    atsFriendly: true,
    layout: "single-column",
    defaultAccent: "#0f766e",
    fontFamily: "inter",
  },
  {
    id: "minimal",
    name: "Minimal",
    description: "A highly scannable single-column layout with almost no decoration.",
    atsFriendly: true,
    layout: "single-column",
    defaultAccent: "#334155",
    fontFamily: "source-sans",
  },
  {
    id: "professional",
    name: "Professional",
    description: "Conservative typography and dividers suited to corporate applications.",
    atsFriendly: true,
    layout: "single-column",
    defaultAccent: "#1d4ed8",
    fontFamily: "source-sans",
  },
  {
    id: "executive",
    name: "Executive",
    description: "Serif-led, authoritative styling for senior and leadership profiles.",
    atsFriendly: true,
    layout: "single-column",
    defaultAccent: "#7c2d12",
    fontFamily: "merriweather",
  },
  {
    id: "creative",
    name: "Creative",
    description: "A more expressive header and compact skill treatments while retaining text flow.",
    atsFriendly: false,
    layout: "enhanced-single-column",
    defaultAccent: "#7c3aed",
    fontFamily: "inter",
  },
];

export function getTemplate(id: TemplateId) {
  return resumeTemplates.find((template) => template.id === id) ?? resumeTemplates[0];
}

export const fontStacks = {
  inter: 'var(--font-inter), ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  "source-sans": 'var(--font-source-sans), ui-sans-serif, system-ui, sans-serif',
  merriweather: 'var(--font-merriweather), Georgia, "Times New Roman", serif',
  georgia: 'Georgia, "Times New Roman", serif',
} as const;
