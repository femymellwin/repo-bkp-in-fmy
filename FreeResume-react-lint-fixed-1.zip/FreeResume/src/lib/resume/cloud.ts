import type { SupabaseClient, User } from "@supabase/supabase-js";
import type { Database, Json } from "@/lib/supabase/database.types";
import { resumeDocumentSchema, type ResumeDocument } from "@/lib/resume/schema";

function dataUrlToBlob(dataUrl: string) {
  const [header, encoded] = dataUrl.split(",");
  const mime = header.match(/data:([^;]+)/)?.[1] || "image/jpeg";
  const bytes = atob(encoded || "");
  const array = new Uint8Array(bytes.length);
  for (let index = 0; index < bytes.length; index += 1) array[index] = bytes.charCodeAt(index);
  return new Blob([array], { type: mime });
}

async function preparePhoto(client: SupabaseClient<Database>, user: User, resume: ResumeDocument) {
  const next = structuredClone(resume);
  const { photoUrl, photoPath } = next.data.personal;
  if (!photoUrl?.startsWith("data:") || photoPath) return next;

  const blob = dataUrlToBlob(photoUrl);
  const extension = blob.type === "image/png" ? "png" : blob.type === "image/webp" ? "webp" : "jpg";
  const path = `${user.id}/${resume.id}/profile.${extension}`;
  const { error } = await client.storage.from("resume-assets").upload(path, blob, {
    upsert: true,
    cacheControl: "3600",
    contentType: blob.type,
  });
  if (error) throw error;
  next.data.personal.photoPath = path;
  // Keep the original data URL in this browser. Only the private object path is
  // written to PostgreSQL; cloud-only loads receive a short-lived signed URL.
  return next;
}

function getStoredPhotoPath(value: Json | null | undefined) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return "";
  const personal = value.personal;
  if (!personal || typeof personal !== "object" || Array.isArray(personal)) return "";
  return typeof personal.photoPath === "string" ? personal.photoPath : "";
}

export async function syncResumeToCloud(client: SupabaseClient<Database>, user: User, resume: ResumeDocument) {
  const { data: existing, error: existingError } = await client
    .from("resumes")
    .select("data")
    .eq("user_id", user.id)
    .eq("id", resume.id)
    .maybeSingle();
  if (existingError) throw existingError;
  const previousPhotoPath = getStoredPhotoPath(existing?.data);

  const hydrated = await preparePhoto(client, user, resume);
  const storedData = structuredClone(hydrated.data);
  if (storedData.personal.photoPath) storedData.personal.photoUrl = "";
  const { data: saved, error } = await client.from("resumes").upsert({
    id: hydrated.id,
    user_id: user.id,
    name: hydrated.name,
    template_id: hydrated.settings.templateId,
    data: storedData as unknown as Json,
    settings: hydrated.settings as unknown as Json,
    sections: hydrated.sections as unknown as Json,
    version: hydrated.version,
    created_at: hydrated.createdAt,
    updated_at: new Date().toISOString(),
  }, { onConflict: "user_id,id" }).select("updated_at").single();
  if (error) throw error;
  if (!saved) throw new Error("Cloud resume sync returned no record.");
  hydrated.updatedAt = saved.updated_at;
  if (previousPhotoPath && previousPhotoPath !== storedData.personal.photoPath) {
    const { error: removeError } = await client.storage.from("resume-assets").remove([previousPhotoPath]);
    if (removeError) console.warn("Cloud resume synced, but the replaced profile photo could not be removed.", removeError);
  }
  return hydrated;
}

export async function loadCloudResumes(client: SupabaseClient<Database>) {
  const { data, error } = await client.from("resumes").select("*").order("updated_at", { ascending: false });
  if (error) throw error;

  const results: ResumeDocument[] = [];
  for (const row of data) {
    const candidate = resumeDocumentSchema.safeParse({
      id: row.id,
      name: row.name,
      data: row.data,
      settings: row.settings,
      sections: row.sections,
      version: 1,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    });
    if (!candidate.success) continue;
    const resume = candidate.data;
    if (resume.data.personal.photoPath) {
      const { data: signed } = await client.storage.from("resume-assets").createSignedUrl(resume.data.personal.photoPath, 3600);
      resume.data.personal.photoUrl = signed?.signedUrl || "";
    }
    results.push(resume);
  }
  return results;
}

export async function deleteCloudResume(client: SupabaseClient<Database>, resume: ResumeDocument) {
  if (resume.data.personal.photoPath) {
    const { error: assetError } = await client.storage.from("resume-assets").remove([resume.data.personal.photoPath]);
    if (assetError) throw assetError;
  }
  const { error } = await client.from("resumes").delete().eq("id", resume.id);
  if (error) throw error;
}
