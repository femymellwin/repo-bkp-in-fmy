import { createId } from "@/lib/utils";
import type { ResumeDocument, TemplateId } from "@/lib/resume/schema";
import { getTemplate } from "@/lib/resume/templates";

export const builtInSections = [
  { id: "personal", title: "Personal information", visible: true },
  { id: "contact", title: "Contact details", visible: true },
  { id: "summary", title: "Professional summary", visible: true },
  { id: "experience", title: "Work experience", visible: true },
  { id: "education", title: "Education", visible: true },
  { id: "skills", title: "Skills", visible: true },
  { id: "projects", title: "Projects", visible: true },
  { id: "certifications", title: "Certifications", visible: true },
  { id: "languages", title: "Languages", visible: true },
  { id: "awards", title: "Awards", visible: false },
  { id: "publications", title: "Publications", visible: false },
  { id: "volunteer", title: "Volunteer experience", visible: false },
  { id: "references", title: "References", visible: false },
] as const;

export function createSampleResume(templateId: TemplateId = "modern"): ResumeDocument {
  const now = new Date().toISOString();
  const template = getTemplate(templateId);
  return {
    id: createId("resume"),
    name: "Product Designer Resume",
    version: 1,
    createdAt: now,
    updatedAt: now,
    settings: {
      templateId,
      fontFamily: template.fontFamily,
      fontSize: 10.5,
      lineHeight: 1.4,
      accentColor: template.defaultAccent,
      headingStyle: "uppercase",
      pageMargin: 18,
      showPhoto: false,
      showPageBreaks: true,
    },
    sections: builtInSections.map((section) => ({ ...section })),
    data: {
      personal: {
        fullName: "Maya Chen",
        jobTitle: "Senior Product Designer",
        photoUrl: "",
        photoPath: "",
      },
      contact: {
        email: "maya.chen@example.com",
        phone: "+971 50 123 4567",
        location: "Dubai, UAE",
        website: "mayachen.design",
        linkedin: "linkedin.com/in/mayachen",
        portfolio: "portfolio.mayachen.design",
      },
      summary:
        "Product designer with 8+ years of experience translating complex workflows into clear, accessible digital products. Led cross-functional discovery and design initiatives that improved activation, reduced support demand, and established scalable design systems.",
      experience: [
        {
          id: createId("experience"),
          company: "Northstar Labs",
          role: "Senior Product Designer",
          location: "Dubai, UAE",
          startDate: "2022",
          endDate: "Present",
          current: true,
          description: "Own end-to-end product design for a B2B analytics platform used by regional operations teams.",
          highlights: [
            "Redesigned onboarding around role-based tasks, increasing first-week activation from 58% to 76%.",
            "Built a reusable component and content system that cut design-to-development handoff time by 35%.",
            "Partnered with research and data teams to validate roadmap decisions across 40+ customer interviews.",
          ],
        },
        {
          id: createId("experience"),
          company: "Juniper Digital",
          role: "Product Designer",
          location: "Singapore",
          startDate: "2018",
          endDate: "2022",
          current: false,
          description: "Designed customer-facing financial wellness experiences across web and mobile.",
          highlights: [
            "Simplified a multi-step application flow, improving completion by 22% without increasing risk exceptions.",
            "Introduced moderated usability testing and a monthly insight review adopted by three product squads.",
          ],
        },
      ],
      education: [
        {
          id: createId("education"),
          institution: "National University of Singapore",
          degree: "Bachelor of Arts",
          field: "Industrial Design",
          location: "Singapore",
          startDate: "2014",
          endDate: "2018",
          score: "Honours",
          description: "Focused on human-centred design, interaction design, and service systems.",
        },
      ],
      skills: [
        {
          id: createId("skills"),
          name: "Product design",
          skills: ["Discovery", "Interaction design", "Prototyping", "Design systems", "Accessibility"],
        },
        {
          id: createId("skills"),
          name: "Tools",
          skills: ["Figma", "FigJam", "Maze", "Dovetail", "Notion"],
        },
      ],
      projects: [
        {
          id: createId("project"),
          name: "Accessible Data Visualization Toolkit",
          role: "Design lead",
          url: "github.com/example/accessible-charts",
          startDate: "2024",
          endDate: "2025",
          description: "An internal pattern library for inclusive chart selection, annotation, and keyboard interaction.",
          highlights: ["Adopted across six product teams and documented with tested code examples."],
        },
      ],
      certifications: [
        {
          id: createId("certification"),
          name: "IAAP Certified Professional in Accessibility Core Competencies",
          issuer: "IAAP",
          date: "2025",
          url: "",
        },
      ],
      languages: [
        { id: createId("language"), name: "English", proficiency: "Fluent" },
        { id: createId("language"), name: "Mandarin", proficiency: "Native" },
      ],
      awards: [],
      publications: [],
      volunteer: [],
      references: [],
      customSections: [],
    },
  };
}

export function createBlankResume(templateId: TemplateId = "modern"): ResumeDocument {
  const resume = createSampleResume(templateId);
  resume.name = "Untitled Resume";
  resume.data.personal = { fullName: "", jobTitle: "", photoUrl: "", photoPath: "" };
  resume.data.contact = { email: "", phone: "", location: "", website: "", linkedin: "", portfolio: "" };
  resume.data.summary = "";
  resume.data.experience = [];
  resume.data.education = [];
  resume.data.skills = [];
  resume.data.projects = [];
  resume.data.certifications = [];
  resume.data.languages = [];
  resume.createdAt = new Date().toISOString();
  resume.updatedAt = resume.createdAt;
  return resume;
}
