import { resumeDocumentSchema, type ResumeDocument } from "@/lib/resume/schema";

const STORAGE_KEY = "freeresume:resumes:v1";
const LAST_OPENED_KEY = "freeresume:last-opened:v1";

function canUseStorage() {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

export function readLocalResumes(): ResumeDocument[] {
  if (!canUseStorage()) return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((value) => resumeDocumentSchema.safeParse(value))
      .filter((result) => result.success)
      .map((result) => result.data)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  } catch {
    return [];
  }
}

export function writeLocalResumes(resumes: ResumeDocument[]) {
  if (!canUseStorage()) return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(resumes));
}

export function getLocalResume(id: string) {
  return readLocalResumes().find((resume) => resume.id === id);
}

export function saveLocalResume(resume: ResumeDocument) {
  const validated = resumeDocumentSchema.parse(resume);
  const resumes = readLocalResumes();
  const index = resumes.findIndex((item) => item.id === validated.id);
  if (index === -1) resumes.unshift(validated);
  else resumes[index] = validated;
  writeLocalResumes(resumes);
  setLastOpenedResume(validated.id);
  return validated;
}

export function deleteLocalResume(id: string) {
  writeLocalResumes(readLocalResumes().filter((resume) => resume.id !== id));
}

export function setLastOpenedResume(id: string) {
  if (canUseStorage()) window.localStorage.setItem(LAST_OPENED_KEY, id);
}

export function getLastOpenedResume() {
  return canUseStorage() ? window.localStorage.getItem(LAST_OPENED_KEY) : null;
}

export function importResumeFromJson(value: unknown) {
  return resumeDocumentSchema.parse(value);
}
