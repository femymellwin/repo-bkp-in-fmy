export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: { id: string; display_name: string | null; created_at: string; updated_at: string };
        Insert: { id: string; display_name?: string | null; created_at?: string; updated_at?: string };
        Update: { display_name?: string | null; updated_at?: string };
        Relationships: [];
      };
      resumes: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          template_id: string;
          data: Json;
          settings: Json;
          sections: Json;
          version: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          user_id: string;
          name: string;
          template_id: string;
          data: Json;
          settings: Json;
          sections: Json;
          version?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          name?: string;
          template_id?: string;
          data?: Json;
          settings?: Json;
          sections?: Json;
          version?: number;
          updated_at?: string;
        };
        Relationships: [];
      };
      feedback: {
        Row: {
          id: string;
          user_id: string | null;
          email: string;
          category: string;
          message: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          email: string;
          category: string;
          message: string;
          created_at?: string;
        };
        Update: never;
        Relationships: [];
      };
      ai_usage: {
        Row: { subject_hash: string; usage_date: string; request_count: number; updated_at: string };
        Insert: { subject_hash: string; usage_date?: string; request_count?: number; updated_at?: string };
        Update: { request_count?: number; updated_at?: string };
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: {
      consume_ai_quota: {
        Args: { p_subject_hash: string; p_daily_limit: number };
        Returns: { allowed: boolean; remaining: number }[];
      };
    };
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};
