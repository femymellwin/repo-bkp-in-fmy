"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { User } from "@supabase/supabase-js";
import { Cloud, CloudOff, Copy, FilePlus2, FileText, LoaderCircle, MoreHorizontal, Pencil, Search, Trash2 } from "lucide-react";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  Input,
  Label,
  Select,
  Skeleton,
  useToast,
} from "@/components/ui";
import { ConfirmationDialog } from "@/components/confirmation-dialog";
import { createBlankResume } from "@/lib/resume/sample";
import { deleteCloudResume, loadCloudResumes, syncResumeToCloud } from "@/lib/resume/cloud";
import { deleteLocalResume, readLocalResumes, saveLocalResume, writeLocalResumes } from "@/lib/resume/storage";
import type { ResumeDocument } from "@/lib/resume/schema";
import { getTemplate } from "@/lib/resume/templates";
import { createBrowserSupabaseClient } from "@/lib/supabase/client";
import { createId, formatDateTime } from "@/lib/utils";

type Source = "local" | "cloud" | "synced";
type DashboardResume = { resume: ResumeDocument; source: Source };
type SortMode = "updated" | "created" | "name";

function mergeResumes(local: ResumeDocument[], cloud: ResumeDocument[]) {
  const map = new Map<string, DashboardResume>();
  local.forEach((resume) => map.set(resume.id, { resume, source: "local" }));
  cloud.forEach((resume) => {
    const existing = map.get(resume.id);
    if (!existing) {
      map.set(resume.id, { resume, source: "cloud" });
      return;
    }
    const sameVersionNeedsFreshPhoto =
      resume.updatedAt === existing.resume.updatedAt &&
      Boolean(resume.data.personal.photoPath) &&
      !existing.resume.data.personal.photoUrl.startsWith("data:");
    const preferCloud = resume.updatedAt > existing.resume.updatedAt || sameVersionNeedsFreshPhoto;
    map.set(resume.id, { resume: preferCloud ? resume : existing.resume, source: "synced" });
  });
  return Array.from(map.values());
}

export function Dashboard() {
  const [local, setLocal] = React.useState<ResumeDocument[]>([]);
  const [cloud, setCloud] = React.useState<ResumeDocument[]>([]);
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [cloudLoading, setCloudLoading] = React.useState(false);
  const [cloudError, setCloudError] = React.useState("");
  const [query, setQuery] = React.useState("");
  const [sort, setSort] = React.useState<SortMode>("updated");
  const [renameTarget, setRenameTarget] = React.useState<DashboardResume | null>(null);
  const [renameValue, setRenameValue] = React.useState("");
  const [deleteTarget, setDeleteTarget] = React.useState<DashboardResume | null>(null);
  const [deleteAccountOpen, setDeleteAccountOpen] = React.useState(false);
  const [busyId, setBusyId] = React.useState("");
  const router = useRouter();
  const { toast } = useToast();

  const refreshLocal = React.useCallback(() => setLocal(readLocalResumes()), []);
  const refreshCloud = React.useCallback(async () => {
    const client = createBrowserSupabaseClient();
    if (!client) return;
    setCloudLoading(true);
    setCloudError("");
    try { setCloud(await loadCloudResumes(client)); }
    catch (error) { setCloudError(error instanceof Error ? error.message : "Cloud resumes could not be loaded."); }
    finally { setCloudLoading(false); }
  }, []);

  React.useEffect(() => {
    let active = true;
    const localTimer = window.setTimeout(() => {
      if (active) refreshLocal();
    }, 0);
    const client = createBrowserSupabaseClient();

    if (!client) {
      const loadingTimer = window.setTimeout(() => {
        if (active) setLoading(false);
      }, 0);
      return () => {
        active = false;
        window.clearTimeout(localTimer);
        window.clearTimeout(loadingTimer);
      };
    }

    void client.auth.getUser().then(
      ({ data }) => {
        if (!active) return;
        setUser(data.user);
        setLoading(false);
        if (data.user) void refreshCloud();
      },
      () => {
        if (active) setLoading(false);
      },
    );

    const { data } = client.auth.onAuthStateChange((_event, session) => {
      if (!active) return;
      setUser(session?.user ?? null);
      if (session?.user) void refreshCloud();
      else setCloud([]);
    });

    return () => {
      active = false;
      window.clearTimeout(localTimer);
      data.subscription.unsubscribe();
    };
  }, [refreshCloud, refreshLocal]);

  const items = React.useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return mergeResumes(local, cloud)
      .filter(({ resume }) => !normalized || resume.name.toLowerCase().includes(normalized) || resume.data.personal.fullName.toLowerCase().includes(normalized) || resume.data.personal.jobTitle.toLowerCase().includes(normalized))
      .sort((a, b) => sort === "name" ? a.resume.name.localeCompare(b.resume.name) : sort === "created" ? b.resume.createdAt.localeCompare(a.resume.createdAt) : b.resume.updatedAt.localeCompare(a.resume.updatedAt));
  }, [cloud, local, query, sort]);

  function createResume() {
    const resume = createBlankResume();
    try {
      saveLocalResume(resume);
      router.push(`/builder/${resume.id}`);
    } catch {
      toast({
        title: "Could not create resume",
        description: "Browser storage may be full. Remove an old resume or a large profile photo and try again.",
        variant: "error",
      });
    }
  }

  function openResume(item: DashboardResume) {
    try {
      saveLocalResume(item.resume);
      router.push(`/builder/${item.resume.id}`);
    } catch {
      toast({
        title: "Could not save this resume on the device",
        description: "Browser storage may be full. Free some local resume storage before opening this cloud copy.",
        variant: "error",
      });
    }
  }

  function duplicate(item: DashboardResume) {
    const now = new Date().toISOString();
    const copy: ResumeDocument = { ...structuredClone(item.resume), id: createId("resume"), name: `${item.resume.name} Copy`, createdAt: now, updatedAt: now };
    try {
      saveLocalResume(copy);
      refreshLocal();
      toast({ title: "Resume duplicated", variant: "success" });
    } catch {
      toast({
        title: "Could not duplicate resume",
        description: "Browser storage may be full. Remove an old resume or a large profile photo and try again.",
        variant: "error",
      });
    }
  }

  async function rename() {
    if (!renameTarget || !renameValue.trim()) return;
    const updated = { ...renameTarget.resume, name: renameValue.trim(), updatedAt: new Date().toISOString() };
    try {
      saveLocalResume(updated);
      refreshLocal();
    } catch {
      toast({
        title: "Rename could not be saved locally",
        description: "Browser storage may be full. Free some space and try again.",
        variant: "error",
      });
      return;
    }
    if ((renameTarget.source === "cloud" || renameTarget.source === "synced") && user) {
      const client = createBrowserSupabaseClient();
      if (client) {
        try { await syncResumeToCloud(client, user, updated); await refreshCloud(); }
        catch (error) { toast({ title: "Renamed locally, but cloud sync failed", description: error instanceof Error ? error.message : undefined, variant: "error" }); }
      }
    }
    setRenameTarget(null);
  }

  async function remove() {
    if (!deleteTarget) return;
    setBusyId(deleteTarget.resume.id);
    try {
      if (deleteTarget.source === "local" || deleteTarget.source === "synced") deleteLocalResume(deleteTarget.resume.id);
      if ((deleteTarget.source === "cloud" || deleteTarget.source === "synced") && user) {
        const client = createBrowserSupabaseClient();
        if (client) await deleteCloudResume(client, deleteTarget.resume);
      }
      refreshLocal();
      if (user) await refreshCloud();
      toast({ title: "Resume deleted", variant: "success" });
    } catch (error) {
      toast({ title: "Delete failed", description: error instanceof Error ? error.message : undefined, variant: "error" });
    } finally { setBusyId(""); setDeleteTarget(null); }
  }

  async function sync(item: DashboardResume) {
    const client = createBrowserSupabaseClient();
    if (!client || !user) { router.push("/login?next=/dashboard"); return; }
    setBusyId(item.resume.id);
    try {
      const synced = await syncResumeToCloud(client, user, item.resume);
      await refreshCloud();
      try {
        saveLocalResume(synced);
        refreshLocal();
        toast({ title: "Resume synced", variant: "success" });
      } catch {
        toast({
          title: "Cloud sync succeeded",
          description: "The cloud copy is current, but browser storage is full and the local copy could not be updated.",
          variant: "error",
        });
      }
    } catch (error) { toast({ title: "Sync failed", description: error instanceof Error ? error.message : undefined, variant: "error" }); }
    finally { setBusyId(""); }
  }

  async function deleteAccount() {
    const response = await fetch("/api/account", { method: "DELETE" });
    const data = await response.json() as { error?: string };
    if (!response.ok) { toast({ title: "Account deletion failed", description: data.error, variant: "error" }); return; }
    const client = createBrowserSupabaseClient();
    await client?.auth.signOut();
    setUser(null); setCloud([]);
    toast({ title: "Account deleted", description: "Cloud data was deleted. Local resumes remain on this device.", variant: "success" });
    router.push("/");
  }

  function clearLocalDevice() {
    try {
      writeLocalResumes([]);
      refreshLocal();
      toast({ title: "Local resumes removed", variant: "success" });
    } catch {
      toast({ title: "Local data could not be cleared", description: "Check this browser's site-storage permissions and try again.", variant: "error" });
    }
  }

  if (loading) return <div className="mx-auto max-w-7xl space-y-5 p-4 sm:p-6 lg:p-8"><Skeleton className="h-20" /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"><Skeleton className="h-56" /><Skeleton className="h-56" /><Skeleton className="h-56" /></div></div>;

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-sm font-semibold text-teal-700">Resume dashboard</p><h1 className="mt-1 text-3xl font-bold tracking-tight text-slate-950">Your resumes</h1><p className="mt-2 text-sm text-slate-600">Guest resumes live on this device. Sign in only when you want private cloud sync.</p></div><Button onClick={createResume}><FilePlus2 className="size-4" />Create resume</Button></div>
      {!user ? <div className="mt-6 flex flex-col gap-3 rounded-xl border border-teal-200 bg-teal-50 p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold text-teal-950">Using guest mode</p><p className="text-sm text-teal-800">PDF export and local saving are available without an account.</p></div><Button asChild variant="outline"><Link href="/login?next=/dashboard"><Cloud className="size-4" />Sign in for cloud sync</Link></Button></div> : null}
      {cloudError ? <div className="mt-4 flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900"><CloudOff className="size-4" />{cloudError}</div> : null}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search resumes" aria-label="Search resumes" className="pl-9" /></div><Select value={sort} onChange={(event) => setSort(event.target.value as SortMode)} aria-label="Sort resumes" className="sm:w-48"><option value="updated">Recently updated</option><option value="created">Date created</option><option value="name">Alphabetical</option></Select></div>
      {cloudLoading ? <p className="mt-4 flex items-center gap-2 text-sm text-slate-500"><LoaderCircle className="size-4 animate-spin" />Loading cloud resumes</p> : null}
      {items.length ? <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{items.map((item) => { const template = getTemplate(item.resume.settings.templateId); return <Card key={item.resume.id} className="group overflow-hidden"><button type="button" onClick={() => openResume(item)} className="block w-full text-left"><div className="h-28 border-b border-slate-200 bg-slate-50 p-5"><div className="h-2 w-2/3 rounded" style={{ background: item.resume.settings.accentColor }} /><div className="mt-3 h-1.5 w-1/2 rounded bg-slate-300" /><div className="mt-4 space-y-1.5"><div className="h-1.5 w-full rounded bg-slate-200" /><div className="h-1.5 w-5/6 rounded bg-slate-200" /><div className="h-1.5 w-3/4 rounded bg-slate-200" /></div></div></button><CardHeader className="pb-3"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><CardTitle className="truncate text-base">{item.resume.name}</CardTitle><CardDescription className="mt-1 truncate">{item.resume.data.personal.fullName || "No name yet"}{item.resume.data.personal.jobTitle ? ` • ${item.resume.data.personal.jobTitle}` : ""}</CardDescription></div><DropdownMenu><DropdownMenuTrigger asChild><Button variant="ghost" size="icon-sm" aria-label={`Actions for ${item.resume.name}`}><MoreHorizontal className="size-4" /></Button></DropdownMenuTrigger><DropdownMenuContent align="end"><DropdownMenuItem onSelect={() => openResume(item)}><FileText className="size-4" />Open</DropdownMenuItem><DropdownMenuItem onSelect={() => { setRenameTarget(item); setRenameValue(item.resume.name); }}><Pencil className="size-4" />Rename</DropdownMenuItem><DropdownMenuItem onSelect={() => duplicate(item)}><Copy className="size-4" />Duplicate</DropdownMenuItem>{item.source !== "synced" ? <DropdownMenuItem onSelect={() => void sync(item)} disabled={busyId === item.resume.id}><Cloud className="size-4" />{item.source === "cloud" ? "Save on this device" : "Sync to cloud"}</DropdownMenuItem> : null}<DropdownMenuSeparator /><DropdownMenuItem className="text-red-600 focus:text-red-700" onSelect={() => setDeleteTarget(item)}><Trash2 className="size-4" />Delete</DropdownMenuItem></DropdownMenuContent></DropdownMenu></div></CardHeader><CardContent className="flex items-end justify-between gap-3"><div className="space-y-1 text-xs text-slate-500"><p>{template.name} template</p><p>Updated {formatDateTime(item.resume.updatedAt)}</p></div><Badge variant={item.source === "synced" ? "success" : "secondary"}>{item.source === "synced" ? "Synced" : item.source === "cloud" ? "Cloud" : "This device"}</Badge></CardContent></Card>; })}</div> : <div className="mt-8 rounded-xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center"><FileText className="mx-auto size-10 text-slate-300" /><h2 className="mt-4 text-lg font-semibold text-slate-950">{query ? "No matching resumes" : "Create your first resume"}</h2><p className="mx-auto mt-2 max-w-md text-sm text-slate-600">{query ? "Try a different search term." : "Start in guest mode, save automatically in this browser, and download a PDF without registration."}</p>{!query ? <Button className="mt-5" onClick={createResume}><FilePlus2 className="size-4" />Create resume</Button> : null}</div>}
      <section id="account" className="mt-12 scroll-mt-20 border-t border-slate-200 pt-8"><h2 className="text-xl font-bold text-slate-950">Account and privacy</h2>{user ? <div className="mt-4 rounded-xl border border-slate-200 bg-white p-5"><p className="text-sm text-slate-600">Signed in as <strong className="text-slate-900">{user.email}</strong>.</p><p className="mt-2 text-sm text-slate-600">Deleting your account removes private cloud resumes, profile data, and uploaded resume assets. Resumes stored only in this browser are separate.</p><Button className="mt-4" variant="destructive" onClick={() => setDeleteAccountOpen(true)}>Delete account and cloud data</Button></div> : <div className="mt-4 rounded-xl border border-slate-200 bg-white p-5"><p className="text-sm text-slate-600">No account is connected. Local resume data remains in this browser&apos;s storage.</p><Button className="mt-4" variant="outline" onClick={clearLocalDevice} disabled={!local.length}>Remove all local resumes from this device</Button></div>}</section>
      <Dialog open={Boolean(renameTarget)} onOpenChange={(open) => !open && setRenameTarget(null)}><DialogContent><DialogHeader><DialogTitle>Rename resume</DialogTitle><DialogDescription>Choose a name that helps distinguish the target role or version.</DialogDescription></DialogHeader><div><Label htmlFor="dashboard-rename">Resume name</Label><Input id="dashboard-rename" value={renameValue} onChange={(event) => setRenameValue(event.target.value)} maxLength={120} onKeyDown={(event) => { if (event.key === "Enter") void rename(); }} /></div><DialogFooter><Button variant="outline" onClick={() => setRenameTarget(null)}>Cancel</Button><Button onClick={() => void rename()} disabled={!renameValue.trim()}>Save</Button></DialogFooter></DialogContent></Dialog>
      <ConfirmationDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)} title="Delete this resume?" description={`“${deleteTarget?.resume.name || "This resume"}” will be removed from ${deleteTarget?.source === "synced" ? "this device and the cloud" : deleteTarget?.source === "cloud" ? "the cloud" : "this device"}. This cannot be undone.`} confirmLabel="Delete resume" destructive onConfirm={remove} />
      <ConfirmationDialog open={deleteAccountOpen} onOpenChange={setDeleteAccountOpen} title="Permanently delete your account?" description="This deletes your Supabase account, cloud resume records, and uploaded resume assets. Local browser data is not automatically deleted." confirmLabel="Delete account" destructive onConfirm={deleteAccount} />
    </main>
  );
}
