"use client";

import * as React from "react";
import { CheckCircle2, CircleAlert, X } from "lucide-react";
import { cn, createId } from "@/lib/utils";

type Toast = { id: string; title: string; description?: string; variant?: "default" | "success" | "error" };
type ToastContextValue = { toast: (toast: Omit<Toast, "id">) => void };
const ToastContext = React.createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = React.useState<Toast[]>([]);
  const dismiss = React.useCallback((id: string) => setToasts((items) => items.filter((item) => item.id !== id)), []);
  const toast = React.useCallback((value: Omit<Toast, "id">) => {
    const item = { ...value, id: createId("toast") };
    setToasts((items) => [...items, item]);
    window.setTimeout(() => dismiss(item.id), 4500);
  }, [dismiss]);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-4 right-4 z-[100] flex w-[calc(100%-2rem)] max-w-sm flex-col gap-2" aria-live="polite" aria-relevant="additions">
        {toasts.map((item) => (
          <div key={item.id} className={cn("flex gap-3 rounded-xl border bg-white p-4 shadow-lg", item.variant === "error" && "border-red-200", item.variant === "success" && "border-emerald-200")}>
            {item.variant === "error" ? <CircleAlert className="mt-0.5 size-5 shrink-0 text-red-600" /> : <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-emerald-600" />}
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-slate-950">{item.title}</p>
              {item.description ? <p className="mt-1 text-sm text-slate-600">{item.description}</p> : null}
            </div>
            <button type="button" onClick={() => dismiss(item.id)} className="rounded p-1 text-slate-500 hover:bg-slate-100" aria-label="Dismiss notification"><X className="size-4" /></button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = React.useContext(ToastContext);
  if (!context) throw new Error("useToast must be used within ToastProvider");
  return context;
}
