"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { FileText, Menu, X } from "lucide-react";
import * as React from "react";
import { Button } from "@/components/ui";
import { cn } from "@/lib/utils";

const links = [
  { href: "/templates", label: "Templates" },
  { href: "/dashboard", label: "My resumes" },
  { href: "/contact", label: "Contact" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [openPath, setOpenPath] = React.useState<string | null>(null);
  const open = openPath === pathname;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/90 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/85">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2 rounded-md font-semibold text-slate-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600">
          <span className="flex size-9 items-center justify-center rounded-lg bg-teal-700 text-white"><FileText className="size-5" /></span>
          <span>FreeResume</span>
        </Link>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Primary navigation">
          {links.map((link) => (
            <Link key={link.href} href={link.href} className={cn("rounded-md px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-950", pathname === link.href && "text-teal-800")}>{link.label}</Link>
          ))}
          <Button asChild className="ml-3"><Link href="/builder/new">Build my resume</Link></Button>
        </nav>
        <button type="button" className="rounded-md p-2 text-slate-700 hover:bg-slate-100 md:hidden" onClick={() => setOpenPath(open ? null : pathname)} aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? "Close menu" : "Open menu"}>
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>
      {open ? (
        <nav id="mobile-menu" className="border-t border-slate-200 bg-white px-4 py-4 md:hidden" aria-label="Mobile navigation">
          <div className="flex flex-col gap-1">
            {links.map((link) => <Link key={link.href} href={link.href} onClick={() => setOpenPath(null)} className="rounded-md px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100">{link.label}</Link>)}
            <Button asChild className="mt-2"><Link href="/builder/new" onClick={() => setOpenPath(null)}>Build my resume</Link></Button>
          </div>
        </nav>
      ) : null}
    </header>
  );
}
