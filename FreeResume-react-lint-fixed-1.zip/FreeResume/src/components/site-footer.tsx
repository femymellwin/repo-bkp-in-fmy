import Link from "next/link";
import { FileText } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-[1fr_auto] lg:px-8">
        <div>
          <Link href="/" className="inline-flex items-center gap-2 font-semibold text-slate-950"><FileText className="size-5 text-teal-700" />FreeResume</Link>
          <p className="mt-3 max-w-md text-sm leading-6 text-slate-600">A transparent, local-first resume builder with free PDF export and no watermark.</p>
        </div>
        <nav className="grid grid-cols-2 gap-x-10 gap-y-3 text-sm" aria-label="Footer navigation">
          <Link className="text-slate-600 hover:text-slate-950" href="/templates">Templates</Link>
          <Link className="text-slate-600 hover:text-slate-950" href="/dashboard">Dashboard</Link>
          <Link className="text-slate-600 hover:text-slate-950" href="/privacy">Privacy</Link>
          <Link className="text-slate-600 hover:text-slate-950" href="/terms">Terms</Link>
          <Link className="text-slate-600 hover:text-slate-950" href="/contact">Contact</Link>
          <Link className="text-slate-600 hover:text-slate-950" href="/login">Sign in</Link>
        </nav>
      </div>
      <div className="border-t border-slate-200 px-4 py-5 text-center text-xs text-slate-500">© {new Date().getFullYear()} FreeResume. Open-source under the MIT License.</div>
    </footer>
  );
}
