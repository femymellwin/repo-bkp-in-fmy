"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { LoaderCircle, Send } from "lucide-react";
import { Button, Input, Label, Select, Textarea, useToast } from "@/components/ui";
import { feedbackSchema } from "@/lib/resume/schema";
import { z } from "zod";

type Feedback = z.infer<typeof feedbackSchema>;

export function ContactForm() {
  const [loading, setLoading] = React.useState(false);
  const { toast } = useToast();
  const form = useForm<Feedback>({ resolver: zodResolver(feedbackSchema), defaultValues: { email: "", category: "feedback", message: "", website: "" } });
  async function submit(values: Feedback) {
    setLoading(true);
    try {
      const response = await fetch("/api/feedback", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(values) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Feedback could not be sent.");
      form.reset();
      toast({ title: "Message sent", description: "Thank you for helping improve FreeResume.", variant: "success" });
    } catch (error) { toast({ title: "Message not sent", description: error instanceof Error ? error.message : "Try again.", variant: "error" }); }
    finally { setLoading(false); }
  }
  return <form onSubmit={form.handleSubmit(submit)} className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm"><div className="hidden" aria-hidden><Label htmlFor="website">Website</Label><Input id="website" tabIndex={-1} autoComplete="off" {...form.register("website")} /></div><div><Label htmlFor="contact-email">Email</Label><Input id="contact-email" type="email" autoComplete="email" {...form.register("email")} />{form.formState.errors.email ? <p className="mt-1 text-xs text-red-600">Enter a valid email address.</p> : null}</div><div><Label htmlFor="category">Topic</Label><Select id="category" {...form.register("category")}><option value="feedback">General feedback</option><option value="bug">Report a bug</option><option value="feature">Feature request</option><option value="privacy">Privacy request</option><option value="other">Other</option></Select></div><div><Label htmlFor="message">Message</Label><Textarea id="message" rows={9} maxLength={5000} placeholder="Describe your feedback or issue…" {...form.register("message")} />{form.formState.errors.message ? <p className="mt-1 text-xs text-red-600">Use between 10 and 5,000 characters.</p> : null}</div><Button type="submit" disabled={loading}>{loading ? <LoaderCircle className="size-4 animate-spin" /> : <Send className="size-4" />}{loading ? "Sending" : "Send message"}</Button></form>;
}
