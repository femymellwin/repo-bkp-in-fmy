"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { LoaderCircle } from "lucide-react";
import { z } from "zod";
import { Button, Input, Label, useToast } from "@/components/ui";
import { createBrowserSupabaseClient } from "@/lib/supabase/client";

const credentialsSchema = z.object({
  email: z.string().trim().email("Enter a valid email address."),
  password: z.string().min(8, "Use at least 8 characters.").max(128),
});
type Credentials = z.infer<typeof credentialsSchema>;

export function CredentialsForm({ mode, nextPath = "/dashboard" }: { mode: "login" | "register"; nextPath?: string }) {
  const [loading, setLoading] = React.useState(false);
  const router = useRouter();
  const { toast } = useToast();
  const form = useForm<Credentials>({ resolver: zodResolver(credentialsSchema), defaultValues: { email: "", password: "" } });

  async function submit(values: Credentials) {
    const client = createBrowserSupabaseClient();
    if (!client) {
      toast({ title: "Authentication is not configured", description: "Add the public Supabase environment variables.", variant: "error" });
      return;
    }
    setLoading(true);
    try {
      if (mode === "register") {
        const { data, error } = await client.auth.signUp({
          email: values.email,
          password: values.password,
          options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(nextPath)}` },
        });
        if (error) throw error;
        if (data.session) {
          router.push(nextPath);
          router.refresh();
        } else {
          toast({ title: "Check your email", description: "Open the verification link to finish creating your account.", variant: "success" });
        }
      } else {
        const { error } = await client.auth.signInWithPassword(values);
        if (error) throw error;
        router.push(nextPath);
        router.refresh();
      }
    } catch (error) {
      toast({ title: mode === "login" ? "Sign-in failed" : "Registration failed", description: error instanceof Error ? error.message : "Try again.", variant: "error" });
    } finally {
      setLoading(false);
    }
  }

  async function google() {
    const client = createBrowserSupabaseClient();
    if (!client) {
      toast({ title: "Authentication is not configured", description: "Add the public Supabase environment variables.", variant: "error" });
      return;
    }
    const { error } = await client.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(nextPath)}` },
    });
    if (error) toast({ title: "Google sign-in failed", description: error.message, variant: "error" });
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <div className="text-center"><h1 className="text-2xl font-bold text-slate-950">{mode === "login" ? "Sign in" : "Create your account"}</h1><p className="mt-2 text-sm text-slate-600">{mode === "login" ? "Access resumes you synced to the cloud." : "An account is optional and used only for cloud sync."}</p></div>
      <Button type="button" variant="outline" className="mt-6 w-full" onClick={() => void google()}>Continue with Google</Button>
      <div className="my-5 flex items-center gap-3"><div className="h-px flex-1 bg-slate-200" /><span className="text-xs uppercase tracking-wider text-slate-400">or</span><div className="h-px flex-1 bg-slate-200" /></div>
      <form onSubmit={form.handleSubmit(submit)} className="space-y-4">
        <div><Label htmlFor="email">Email</Label><Input id="email" type="email" autoComplete="email" {...form.register("email")} />{form.formState.errors.email ? <p className="mt-1 text-xs text-red-600">{form.formState.errors.email.message}</p> : null}</div>
        <div><div className="flex items-center justify-between"><Label htmlFor="password">Password</Label>{mode === "login" ? <Link href="/reset-password" className="text-xs font-medium text-teal-700 hover:underline">Forgot password?</Link> : null}</div><Input id="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} {...form.register("password")} />{form.formState.errors.password ? <p className="mt-1 text-xs text-red-600">{form.formState.errors.password.message}</p> : null}</div>
        <Button type="submit" className="w-full" disabled={loading}>{loading ? <LoaderCircle className="size-4 animate-spin motion-reduce:animate-none" /> : null}{mode === "login" ? "Sign in" : "Create account"}</Button>
      </form>
      <p className="mt-5 text-center text-sm text-slate-600">{mode === "login" ? <>New here? <Link href={`/register?next=${encodeURIComponent(nextPath)}`} className="font-medium text-teal-700 hover:underline">Create an account</Link></> : <>Already registered? <Link href={`/login?next=${encodeURIComponent(nextPath)}`} className="font-medium text-teal-700 hover:underline">Sign in</Link></>}</p>
      <p className="mt-3 text-center text-xs text-slate-500"><Link href="/builder/new" className="hover:underline">Continue as a guest instead</Link></p>
    </div>
  );
}

const emailSchema = z.object({ email: z.string().trim().email() });
const passwordSchema = z.object({ password: z.string().min(8).max(128), confirm: z.string().min(8).max(128) }).refine((value) => value.password === value.confirm, { path: ["confirm"], message: "Passwords do not match." });

export function ResetPasswordForm() {
  const [hasSession, setHasSession] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const { toast } = useToast();
  const router = useRouter();
  const emailForm = useForm<z.infer<typeof emailSchema>>({ resolver: zodResolver(emailSchema), defaultValues: { email: "" } });
  const passwordForm = useForm<z.infer<typeof passwordSchema>>({ resolver: zodResolver(passwordSchema), defaultValues: { password: "", confirm: "" } });

  React.useEffect(() => {
    const client = createBrowserSupabaseClient();
    if (!client) return;
    void client.auth.getSession().then(({ data }) => setHasSession(Boolean(data.session)));
    const { data } = client.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || session) setHasSession(true);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function sendReset(values: z.infer<typeof emailSchema>) {
    const client = createBrowserSupabaseClient();
    if (!client) return toast({ title: "Authentication is not configured", variant: "error" });
    setLoading(true);
    const { error } = await client.auth.resetPasswordForEmail(values.email, { redirectTo: `${window.location.origin}/auth/callback?next=/reset-password` });
    setLoading(false);
    if (error) toast({ title: "Reset email failed", description: error.message, variant: "error" });
    else toast({ title: "Check your email", description: "Use the recovery link to choose a new password.", variant: "success" });
  }

  async function updatePassword(values: z.infer<typeof passwordSchema>) {
    const client = createBrowserSupabaseClient();
    if (!client) return toast({ title: "Authentication is not configured", variant: "error" });
    setLoading(true);
    const { error } = await client.auth.updateUser({ password: values.password });
    setLoading(false);
    if (error) toast({ title: "Password update failed", description: error.message, variant: "error" });
    else { toast({ title: "Password updated", variant: "success" }); router.push("/dashboard"); router.refresh(); }
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <h1 className="text-center text-2xl font-bold text-slate-950">{hasSession ? "Choose a new password" : "Reset your password"}</h1>
      <p className="mt-2 text-center text-sm text-slate-600">{hasSession ? "Use at least eight characters." : "We will send a secure recovery link to your email."}</p>
      {hasSession ? <form onSubmit={passwordForm.handleSubmit(updatePassword)} className="mt-6 space-y-4"><div><Label htmlFor="new-password">New password</Label><Input id="new-password" type="password" autoComplete="new-password" {...passwordForm.register("password")} />{passwordForm.formState.errors.password ? <p className="mt-1 text-xs text-red-600">{passwordForm.formState.errors.password.message}</p> : null}</div><div><Label htmlFor="confirm-password">Confirm password</Label><Input id="confirm-password" type="password" autoComplete="new-password" {...passwordForm.register("confirm")} />{passwordForm.formState.errors.confirm ? <p className="mt-1 text-xs text-red-600">{passwordForm.formState.errors.confirm.message}</p> : null}</div><Button className="w-full" disabled={loading}>{loading ? <LoaderCircle className="size-4 animate-spin" /> : null}Update password</Button></form> : <form onSubmit={emailForm.handleSubmit(sendReset)} className="mt-6 space-y-4"><div><Label htmlFor="reset-email">Email</Label><Input id="reset-email" type="email" autoComplete="email" {...emailForm.register("email")} />{emailForm.formState.errors.email ? <p className="mt-1 text-xs text-red-600">Enter a valid email.</p> : null}</div><Button className="w-full" disabled={loading}>{loading ? <LoaderCircle className="size-4 animate-spin" /> : null}Send recovery link</Button></form>}
      <p className="mt-5 text-center text-sm"><Link href="/login" className="font-medium text-teal-700 hover:underline">Back to sign in</Link></p>
    </div>
  );
}
