"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { CircleUserRound, FileText, LogOut, Settings } from "lucide-react";
import * as React from "react";
import type { User } from "@supabase/supabase-js";
import { Button, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger, useToast } from "@/components/ui";
import { createBrowserSupabaseClient } from "@/lib/supabase/client";

export function AppHeader() {
  const [user, setUser] = React.useState<User | null>(null);
  const router = useRouter();
  const { toast } = useToast();

  React.useEffect(() => {
    const client = createBrowserSupabaseClient();
    if (!client) return;
    void client.auth.getUser().then(({ data }) => setUser(data.user));
    const { data } = client.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);

  async function signOut() {
    const client = createBrowserSupabaseClient();
    if (!client) return;
    await client.auth.signOut();
    toast({ title: "Signed out", description: "Your local resumes remain on this device.", variant: "success" });
    router.push("/");
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white">
      <div className="flex h-14 items-center justify-between px-3 sm:px-5">
        <div className="flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2 font-semibold text-slate-950"><span className="flex size-8 items-center justify-center rounded-lg bg-teal-700 text-white"><FileText className="size-4" /></span><span className="hidden sm:inline">FreeResume</span></Link>
          <nav className="flex items-center gap-1 text-sm" aria-label="Application navigation">
            <Link href="/dashboard" className="rounded-md px-3 py-2 text-slate-600 hover:bg-slate-100 hover:text-slate-950">Dashboard</Link>
            <Link href="/templates" className="hidden rounded-md px-3 py-2 text-slate-600 hover:bg-slate-100 hover:text-slate-950 sm:block">Templates</Link>
          </nav>
        </div>
        {user ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><CircleUserRound className="size-4" /><span className="hidden max-w-40 truncate sm:inline">{user.email}</span></Button></DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild><Link href="/dashboard#account"><Settings className="size-4" />Account settings</Link></DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => void signOut()}><LogOut className="size-4" />Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Button asChild variant="outline" size="sm"><Link href="/login">Sign in for cloud sync</Link></Button>
        )}
      </div>
    </header>
  );
}
