"use client";

import * as React from "react";
import {
  closestCenter,
  DndContext,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ArrowDown, ArrowUp, GripVertical, Pencil, Plus, Trash2 } from "lucide-react";
import {
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  Input,
  Label,
  Switch,
} from "@/components/ui";
import type { ResumeDocument, SectionConfig } from "@/lib/resume/schema";
import { cn, createId, moveItem } from "@/lib/utils";

function SortableSection({
  section,
  index,
  total,
  selected,
  onSelect,
  onToggle,
  onMove,
  onRename,
  onRemove,
}: {
  section: SectionConfig;
  index: number;
  total: number;
  selected: boolean;
  onSelect: () => void;
  onToggle: (visible: boolean) => void;
  onMove: (direction: -1 | 1) => void;
  onRename: () => void;
  onRemove?: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: section.id });
  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={cn("flex items-center gap-1 rounded-lg border bg-white p-2 shadow-sm", selected ? "border-teal-500 ring-1 ring-teal-500/30" : "border-slate-200", isDragging && "z-10 opacity-70 shadow-lg")}
    >
      <button type="button" {...attributes} {...listeners} className="cursor-grab rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 active:cursor-grabbing" aria-label={`Drag ${section.title}`}><GripVertical className="size-4" /></button>
      <button type="button" onClick={onSelect} className="min-w-0 flex-1 rounded px-2 py-1 text-left"><span className={cn("block truncate text-sm font-medium", section.visible ? "text-slate-900" : "text-slate-400")}>{section.title}</span></button>
      <div className="flex items-center gap-0.5">
        <Button type="button" variant="ghost" size="icon-sm" disabled={index === 0} onClick={() => onMove(-1)} aria-label={`Move ${section.title} up`}><ArrowUp className="size-3.5" /></Button>
        <Button type="button" variant="ghost" size="icon-sm" disabled={index === total - 1} onClick={() => onMove(1)} aria-label={`Move ${section.title} down`}><ArrowDown className="size-3.5" /></Button>
        <Button type="button" variant="ghost" size="icon-sm" onClick={onRename} aria-label={`Rename ${section.title}`}><Pencil className="size-3.5" /></Button>
        {onRemove ? <Button type="button" variant="ghost" size="icon-sm" onClick={onRemove} className="text-red-600 hover:bg-red-50 hover:text-red-700" aria-label={`Remove ${section.title}`}><Trash2 className="size-3.5" /></Button> : null}
        <Switch checked={section.visible} onCheckedChange={onToggle} aria-label={`${section.visible ? "Hide" : "Show"} ${section.title}`} className="ml-1 scale-90" />
      </div>
    </div>
  );
}

export function SectionList({
  resume,
  selectedId,
  onSelect,
  onChange,
}: {
  resume: ResumeDocument;
  selectedId: string;
  onSelect: (id: string) => void;
  onChange: (resume: ResumeDocument) => void;
}) {
  const [dialog, setDialog] = React.useState<{ mode: "add" | "rename"; sectionId?: string } | null>(null);
  const [title, setTitle] = React.useState("");
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  function updateSections(sections: SectionConfig[]) {
    onChange({ ...resume, sections });
  }

  function onDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = resume.sections.findIndex((section) => section.id === active.id);
    const newIndex = resume.sections.findIndex((section) => section.id === over.id);
    updateSections(arrayMove(resume.sections, oldIndex, newIndex));
  }

  function openAdd() {
    setTitle("");
    setDialog({ mode: "add" });
  }

  function openRename(section: SectionConfig) {
    setTitle(section.title);
    setDialog({ mode: "rename", sectionId: section.id });
  }

  function saveDialog() {
    const clean = title.trim();
    if (!clean) return;
    if (dialog?.mode === "rename" && dialog.sectionId) {
      onChange({
        ...resume,
        sections: resume.sections.map((section) => section.id === dialog.sectionId ? { ...section, title: clean } : section),
        data: {
          ...resume.data,
          customSections: resume.data.customSections.map((section) => `custom-${section.id}` === dialog.sectionId ? { ...section, title: clean } : section),
        },
      });
    } else {
      const customId = createId("section");
      const sectionId = `custom-${customId}`;
      onChange({
        ...resume,
        sections: [...resume.sections, { id: sectionId, title: clean, visible: true }],
        data: { ...resume.data, customSections: [...resume.data.customSections, { id: customId, title: clean, items: [] }] },
      });
      onSelect(sectionId);
    }
    setDialog(null);
  }

  function removeCustom(section: SectionConfig) {
    const customId = section.id.slice("custom-".length);
    const sections = resume.sections.filter((item) => item.id !== section.id);
    onChange({ ...resume, sections, data: { ...resume.data, customSections: resume.data.customSections.filter((item) => item.id !== customId) } });
    if (selectedId === section.id) onSelect(sections[0]?.id || "personal");
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between"><div><h2 className="text-sm font-semibold text-slate-950">Resume sections</h2><p className="text-xs text-slate-500">Drag, use arrow buttons, or use the keyboard.</p></div><Button type="button" variant="outline" size="sm" onClick={openAdd}><Plus className="size-4" />Custom</Button></div>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
        <SortableContext items={resume.sections.map((section) => section.id)} strategy={verticalListSortingStrategy}>
          <div className="space-y-2">
            {resume.sections.map((section, index) => (
              <SortableSection
                key={section.id}
                section={section}
                index={index}
                total={resume.sections.length}
                selected={selectedId === section.id}
                onSelect={() => onSelect(section.id)}
                onToggle={(visible) => updateSections(resume.sections.map((item) => item.id === section.id ? { ...item, visible } : item))}
                onMove={(direction) => updateSections(moveItem(resume.sections, index, index + direction))}
                onRename={() => openRename(section)}
                onRemove={section.id.startsWith("custom-") ? () => removeCustom(section) : undefined}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
      <Dialog open={Boolean(dialog)} onOpenChange={(open) => !open && setDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{dialog?.mode === "add" ? "Add custom section" : "Rename section"}</DialogTitle><DialogDescription>Choose a concise heading that a recruiter can understand immediately.</DialogDescription></DialogHeader>
          <div><Label htmlFor="section-title">Section title</Label><Input id="section-title" value={title} onChange={(event) => setTitle(event.target.value)} maxLength={160} placeholder="Professional memberships" onKeyDown={(event) => { if (event.key === "Enter") saveDialog(); }} /></div>
          <DialogFooter><Button type="button" variant="outline" onClick={() => setDialog(null)}>Cancel</Button><Button type="button" onClick={saveDialog} disabled={!title.trim()}>{dialog?.mode === "add" ? "Add section" : "Save title"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
