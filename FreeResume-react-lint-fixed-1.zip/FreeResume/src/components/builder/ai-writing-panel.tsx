"use client";

import * as React from "react";
import { Check, Copy, LoaderCircle, Sparkles } from "lucide-react";
import { Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Label, Select, Textarea, useToast } from "@/components/ui";
import type { AiRequest, ResumeDocument } from "@/lib/resume/schema";

const actions: Array<{ value: AiRequest["action"]; label: string; needsJob?: boolean }> = [
  { value: "generate_summary", label: "Generate professional summary" },
  { value: "improve_bullet", label: "Improve an experience bullet" },
  { value: "stronger_action_verbs", label: "Rewrite with stronger action verbs" },
  { value: "correct_grammar", label: "Correct grammar and clarity" },
  { value: "suggest_achievements", label: "Suggest measurable achievement prompts" },
  { value: "suggest_skills", label: "Suggest skills for a role" },
  { value: "compare_job", label: "Compare resume with a job", needsJob: true },
  { value: "generate_cover_letter", label: "Generate cover letter", needsJob: true },
];

function compactResume(resume: ResumeDocument) {
  return [
    `Name: ${resume.data.personal.fullName}`,
    `Target role: ${resume.data.personal.jobTitle}`,
    `Summary: ${resume.data.summary}`,
    `Experience:\n${resume.data.experience.map((entry) => `${entry.role} at ${entry.company}: ${entry.description}; ${entry.highlights.join("; ")}`).join("\n")}`,
    `Skills: ${resume.data.skills.map((group) => `${group.name}: ${group.skills.join(", ")}`).join(" | ")}`,
    `Education: ${resume.data.education.map((entry) => `${entry.degree} ${entry.field} at ${entry.institution}`).join(" | ")}`,
  ].filter((line) => !line.endsWith(": ")).join("\n");
}

function initialContent(action: AiRequest["action"], resume: ResumeDocument) {
  if (action === "improve_bullet") return resume.data.experience[0]?.highlights[0] || "";
  if (action === "correct_grammar" || action === "stronger_action_verbs") return resume.data.summary;
  if (action === "suggest_skills") return resume.data.personal.jobTitle || compactResume(resume);
  return compactResume(resume);
}

export function AiWritingPanel({ resume, onApplySummary }: { resume: ResumeDocument; onApplySummary: (summary: string) => void }) {
  const [action, setAction] = React.useState<AiRequest["action"]>("generate_summary");
  const [content, setContent] = React.useState(() => initialContent("generate_summary", resume));
  const [jobDescription, setJobDescription] = React.useState("");
  const [result, setResult] = React.useState("");
  const [remaining, setRemaining] = React.useState<number | null>(null);
  const [loading, setLoading] = React.useState(false);
  const { toast } = useToast();
  const selected = actions.find((item) => item.value === action)!;

  function changeAction(value: AiRequest["action"]) {
    setAction(value);
    setContent(initialContent(value, resume));
    setResult("");
  }

  async function generate() {
    setLoading(true);
    try {
      const response = await fetch("/api/ai/write", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, content, jobDescription }),
      });
      const data = await response.json() as { text?: string; error?: string; remaining?: number };
      if (!response.ok) throw new Error(data.error || "AI request failed.");
      setResult(data.text || "");
      setRemaining(data.remaining ?? null);
    } catch (error) {
      toast({ title: "AI writing failed", description: error instanceof Error ? error.message : "Try again.", variant: "error" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader><CardTitle className="flex items-center gap-2"><Sparkles className="size-5 text-teal-700" />AI writing assistant</CardTitle><CardDescription>Optional and rate-limited. The browser sends only the text shown below to the server route.</CardDescription></CardHeader>
      <CardContent className="space-y-4">
        <div><Label htmlFor="ai-action">Action</Label><Select id="ai-action" value={action} onChange={(event) => changeAction(event.target.value as AiRequest["action"])}>{actions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</Select></div>
        <div><Label htmlFor="ai-content">Source content</Label><Textarea id="ai-content" rows={10} value={content} onChange={(event) => setContent(event.target.value)} maxLength={12000} /></div>
        {selected.needsJob ? <div><Label htmlFor="job-description">Job description</Label><Textarea id="job-description" rows={8} value={jobDescription} onChange={(event) => setJobDescription(event.target.value)} maxLength={20000} placeholder="Paste the job description here." /></div> : null}
        <Button type="button" onClick={() => void generate()} disabled={loading || content.trim().length < 3 || (selected.needsJob && jobDescription.trim().length < 3)}>{loading ? <LoaderCircle className="size-4 animate-spin motion-reduce:animate-none" /> : <Sparkles className="size-4" />}{loading ? "Generating" : "Generate"}</Button>
        {remaining !== null ? <p className="text-xs text-slate-500">{remaining} free AI action{remaining === 1 ? "" : "s"} remaining today.</p> : null}
        {result ? <div className="space-y-2 border-t border-slate-200 pt-4"><Label htmlFor="ai-result">Result</Label><Textarea id="ai-result" rows={12} value={result} readOnly /><div className="flex flex-wrap gap-2"><Button type="button" variant="outline" size="sm" onClick={() => void navigator.clipboard.writeText(result).then(() => toast({ title: "Copied", variant: "success" })).catch(() => toast({ title: "Copy failed", description: "Select the result text and copy it manually.", variant: "error" }))}><Copy className="size-4" />Copy</Button>{action === "generate_summary" ? <Button type="button" size="sm" onClick={() => { onApplySummary(result); toast({ title: "Summary applied", variant: "success" }); }}><Check className="size-4" />Use as summary</Button> : null}</div></div> : null}
        <p className="text-xs leading-5 text-slate-500">Review every suggestion for accuracy. FreeResume instructs the provider not to invent facts, but generated text can still be incorrect.</p>
      </CardContent>
    </Card>
  );
}
