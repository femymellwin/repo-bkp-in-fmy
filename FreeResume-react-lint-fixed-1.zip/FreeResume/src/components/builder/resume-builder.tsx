"use client";

import * as React from "react";
import { FilePenLine, Palette, Sparkles } from "lucide-react";
import { Button, Skeleton, Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui";
import { BuilderToolbar } from "@/components/builder/builder-toolbar";
import { PreviewViewport } from "@/components/builder/preview-viewport";
import { SectionEditor } from "@/components/builder/section-editors";
import { SectionList } from "@/components/builder/section-list";
import { StylePanel } from "@/components/builder/style-panel";
import { useResumeEditor } from "@/components/builder/use-resume-editor";
import { AiWritingPanel } from "@/components/builder/ai-writing-panel";
import { appConfig } from "@/lib/config";
import type { ResumeData, TemplateId } from "@/lib/resume/schema";

export function ResumeBuilder({ routeId, initialTemplate }: { routeId: string; initialTemplate: TemplateId }) {
  const editor = useResumeEditor(routeId, initialTemplate);
  const [selectedId, setSelectedId] = React.useState("personal");
  const [mobileMode, setMobileMode] = React.useState<"edit" | "preview">("edit");
  const { resume, commit } = editor;

  const updateData = React.useCallback((updater: (data: ResumeData) => ResumeData) => {
    commit((current) => ({ ...current, data: updater(current.data) }));
  }, [commit]);

  if (!resume) {
    return <main className="p-4"><div className="mx-auto max-w-7xl space-y-4"><Skeleton className="h-16 w-full" /><div className="grid gap-4 lg:grid-cols-[480px_1fr]"><Skeleton className="h-[70vh]" /><Skeleton className="h-[70vh]" /></div></div></main>;
  }

  return (
    <main className="flex h-[calc(100dvh-3.5rem)] min-h-[600px] flex-col overflow-hidden">
      <BuilderToolbar
        resume={resume}
        saveStatus={editor.saveStatus}
        canUndo={editor.canUndo}
        canRedo={editor.canRedo}
        onUndo={editor.undo}
        onRedo={editor.redo}
        onRename={(name) => commit((current) => ({ ...current, name }))}
        onDuplicate={editor.duplicate}
        onClear={editor.clear}
        onLoadSample={editor.loadSample}
        onReplace={editor.replaceWithoutHistory}
      />
      <div className="flex items-center gap-2 border-b border-slate-200 bg-white px-3 py-2 lg:hidden print:hidden">
        <Button type="button" size="sm" variant={mobileMode === "edit" ? "default" : "outline"} onClick={() => setMobileMode("edit")}><FilePenLine className="size-4" />Edit</Button>
        <Button type="button" size="sm" variant={mobileMode === "preview" ? "default" : "outline"} onClick={() => setMobileMode("preview")}>Preview</Button>
      </div>
      <div className="grid min-h-0 flex-1 lg:grid-cols-[minmax(400px,520px)_1fr]">
        <section className={mobileMode === "edit" ? "min-h-0 overflow-y-auto border-r border-slate-200 bg-slate-50 p-3 sm:p-4" : "hidden min-h-0 overflow-y-auto border-r border-slate-200 bg-slate-50 p-3 sm:p-4 lg:block"} aria-label="Resume editor">
          <Tabs defaultValue="content">
            <TabsList className="grid w-full grid-cols-2 data-[ai=true]:grid-cols-3" data-ai={appConfig.aiEnabled}>
              <TabsTrigger value="content"><FilePenLine className="mr-1.5 size-4" />Content</TabsTrigger>
              <TabsTrigger value="design"><Palette className="mr-1.5 size-4" />Design</TabsTrigger>
              {appConfig.aiEnabled ? <TabsTrigger value="ai"><Sparkles className="mr-1.5 size-4" />AI</TabsTrigger> : null}
            </TabsList>
            <TabsContent value="content" className="space-y-4">
              <SectionList resume={resume} selectedId={selectedId} onSelect={setSelectedId} onChange={(next) => commit(() => next)} />
              <SectionEditor resume={resume} sectionId={selectedId} updateData={updateData} />
            </TabsContent>
            <TabsContent value="design"><StylePanel resume={resume} onChange={(settings) => commit((current) => ({ ...current, settings }))} /></TabsContent>
            {appConfig.aiEnabled ? <TabsContent value="ai"><AiWritingPanel resume={resume} onApplySummary={(summary) => updateData((data) => ({ ...data, summary }))} /></TabsContent> : null}
          </Tabs>
        </section>
        <section className={mobileMode === "preview" ? "min-h-0 overflow-hidden print:block" : "hidden min-h-0 overflow-hidden lg:block print:block"} aria-label="Resume preview">
          <PreviewViewport resume={resume} />
        </section>
      </div>
    </main>
  );
}
