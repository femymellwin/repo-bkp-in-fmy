"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { createBlankResume, createSampleResume } from "@/lib/resume/sample";
import { getLocalResume, saveLocalResume } from "@/lib/resume/storage";
import type { ResumeDocument, TemplateId } from "@/lib/resume/schema";
import { createId } from "@/lib/utils";

export type SaveStatus = "idle" | "saving" | "saved" | "error";

type EditorState = {
  resume: ResumeDocument | null;
  past: ResumeDocument[];
  future: ResumeDocument[];
  saveStatus: SaveStatus;
};

type EditorAction =
  | { type: "initialize"; resume: ResumeDocument; saveStatus: SaveStatus }
  | { type: "commit"; updater: (current: ResumeDocument) => ResumeDocument; timestamp: string }
  | { type: "commit-document"; resume: ResumeDocument; timestamp: string }
  | { type: "replace"; resume: ResumeDocument }
  | { type: "undo"; timestamp: string }
  | { type: "redo"; timestamp: string }
  | { type: "save-status"; id: string; updatedAt: string; saveStatus: SaveStatus };

const initialEditorState: EditorState = {
  resume: null,
  past: [],
  future: [],
  saveStatus: "idle",
};

function documentsMatch(current: ResumeDocument, candidate: ResumeDocument) {
  const comparable = { ...candidate, updatedAt: current.updatedAt };
  return JSON.stringify(comparable) === JSON.stringify(current);
}

function commitDocument(state: EditorState, candidate: ResumeDocument, timestamp: string): EditorState {
  const current = state.resume;
  if (!current || documentsMatch(current, candidate)) return state;

  return {
    resume: { ...candidate, updatedAt: timestamp },
    past: [...state.past.slice(-99), current],
    future: [],
    saveStatus: "saving",
  };
}

function editorReducer(state: EditorState, action: EditorAction): EditorState {
  switch (action.type) {
    case "initialize":
      return {
        resume: action.resume,
        past: [],
        future: [],
        saveStatus: action.saveStatus,
      };
    case "commit":
      return state.resume
        ? commitDocument(state, action.updater(state.resume), action.timestamp)
        : state;
    case "commit-document":
      return commitDocument(state, action.resume, action.timestamp);
    case "replace":
      return {
        resume: action.resume,
        past: [],
        future: [],
        saveStatus: "saving",
      };
    case "undo": {
      if (!state.resume || !state.past.length) return state;
      const previous = state.past[state.past.length - 1];
      return {
        resume: { ...previous, updatedAt: action.timestamp },
        past: state.past.slice(0, -1),
        future: [state.resume, ...state.future].slice(0, 100),
        saveStatus: "saving",
      };
    }
    case "redo": {
      if (!state.resume || !state.future.length) return state;
      const next = state.future[0];
      return {
        resume: { ...next, updatedAt: action.timestamp },
        past: [...state.past.slice(-99), state.resume],
        future: state.future.slice(1),
        saveStatus: "saving",
      };
    }
    case "save-status":
      if (
        !state.resume ||
        state.resume.id !== action.id ||
        state.resume.updatedAt !== action.updatedAt
      ) {
        return state;
      }
      return { ...state, saveStatus: action.saveStatus };
  }
}

function nowIso() {
  return new Date().toISOString();
}

export function useResumeEditor(routeId: string, initialTemplate: TemplateId = "modern") {
  const router = useRouter();
  const [state, dispatch] = React.useReducer(editorReducer, initialEditorState);

  React.useEffect(() => {
    let active = true;
    const timer = window.setTimeout(() => {
      if (!active) return;

      const existing = routeId !== "new" ? getLocalResume(routeId) : undefined;
      const initial = existing ?? createBlankResume(initialTemplate);
      let stored = true;
      let redirectTo: string | null = null;

      if (!existing) {
        const routeIdIsSafe = /^[A-Za-z0-9_-]{1,120}$/.test(routeId);
        if (routeId !== "new" && routeIdIsSafe) initial.id = routeId;

        try {
          saveLocalResume(initial);
          if (routeId === "new" || initial.id !== routeId) {
            redirectTo = `/builder/${initial.id}`;
          }
        } catch {
          // Keep the editor usable in memory when browser storage is blocked or full.
          stored = false;
        }
      }

      dispatch({
        type: "initialize",
        resume: initial,
        saveStatus: stored ? "saved" : "error",
      });
      if (redirectTo) router.replace(redirectTo);
    }, 0);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [routeId, initialTemplate, router]);

  const commit = React.useCallback(
    (updater: (current: ResumeDocument) => ResumeDocument) => {
      dispatch({ type: "commit", updater, timestamp: nowIso() });
    },
    [],
  );

  const replaceWithoutHistory = React.useCallback((resume: ResumeDocument) => {
    dispatch({ type: "replace", resume });
  }, []);

  const undo = React.useCallback(() => {
    dispatch({ type: "undo", timestamp: nowIso() });
  }, []);

  const redo = React.useCallback(() => {
    dispatch({ type: "redo", timestamp: nowIso() });
  }, []);

  React.useEffect(() => {
    const resumeToSave = state.resume;
    if (!resumeToSave) return;

    const timer = window.setTimeout(() => {
      try {
        saveLocalResume(resumeToSave);
        dispatch({
          type: "save-status",
          id: resumeToSave.id,
          updatedAt: resumeToSave.updatedAt,
          saveStatus: "saved",
        });
      } catch {
        dispatch({
          type: "save-status",
          id: resumeToSave.id,
          updatedAt: resumeToSave.updatedAt,
          saveStatus: "error",
        });
      }
    }, 500);

    return () => window.clearTimeout(timer);
  }, [state.resume]);

  const duplicate = React.useCallback(() => {
    const current = state.resume;
    if (!current) return null;

    const timestamp = nowIso();
    const copy: ResumeDocument = {
      ...structuredClone(current),
      id: createId("resume"),
      name: `${current.name} Copy`,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    try {
      saveLocalResume(copy);
      return copy;
    } catch {
      dispatch({
        type: "save-status",
        id: current.id,
        updatedAt: current.updatedAt,
        saveStatus: "error",
      });
      return null;
    }
  }, [state.resume]);

  const clear = React.useCallback(() => {
    const current = state.resume;
    if (!current) return;

    const blank = createBlankResume(current.settings.templateId);
    blank.id = current.id;
    blank.name = current.name;
    blank.createdAt = current.createdAt;
    blank.settings = current.settings;
    dispatch({ type: "commit-document", resume: blank, timestamp: nowIso() });
  }, [state.resume]);

  const loadSample = React.useCallback(() => {
    const current = state.resume;
    if (!current) return;

    const sample = createSampleResume(current.settings.templateId);
    sample.id = current.id;
    sample.name = current.name;
    sample.createdAt = current.createdAt;
    sample.settings = current.settings;
    dispatch({ type: "commit-document", resume: sample, timestamp: nowIso() });
  }, [state.resume]);

  return {
    resume: state.resume,
    commit,
    replaceWithoutHistory,
    undo,
    redo,
    canUndo: state.past.length > 0,
    canRedo: state.future.length > 0,
    saveStatus: state.saveStatus,
    duplicate,
    clear,
    loadSample,
  };
}
