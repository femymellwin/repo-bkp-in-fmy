"use client";

import * as React from "react";
import { Minus, Plus } from "lucide-react";
import { Button } from "@/components/ui";
import { ResumePreview } from "@/components/builder/resume-preview";
import type { ResumeDocument } from "@/lib/resume/schema";
import { clamp } from "@/lib/utils";

const A4_WIDTH_PX = 793.7;

export function PreviewViewport({ resume }: { resume: ResumeDocument }) {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const canvasRef = React.useRef<HTMLDivElement>(null);
  const [fitScale, setFitScale] = React.useState(0.8);
  const [zoomDelta, setZoomDelta] = React.useState(0);
  const [height, setHeight] = React.useState(1122);
  const scale = clamp(fitScale + zoomDelta, 0.35, 1.25);

  React.useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const update = () => setFitScale(clamp((container.clientWidth - 48) / A4_WIDTH_PX, 0.35, 1));
    update();
    const observer = new ResizeObserver(update);
    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const update = () => setHeight(canvas.scrollHeight);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(canvas);
    return () => observer.disconnect();
  }, [resume]);

  return (
    <div ref={containerRef} className="resume-preview-viewport relative h-full min-h-[70vh] overflow-auto bg-slate-200/70 p-4 sm:p-6">
      <div className="sticky right-3 top-3 z-20 ml-auto mb-3 flex w-fit items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 shadow-sm print:hidden">
        <Button type="button" variant="ghost" size="icon-sm" aria-label="Zoom out" onClick={() => setZoomDelta((value) => value - 0.1)}><Minus className="size-4" /></Button>
        <button type="button" className="min-w-14 rounded px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100" onClick={() => setZoomDelta(0)} aria-label="Reset preview zoom">{Math.round(scale * 100)}%</button>
        <Button type="button" variant="ghost" size="icon-sm" aria-label="Zoom in" onClick={() => setZoomDelta((value) => value + 0.1)}><Plus className="size-4" /></Button>
      </div>
      <div className="resume-preview-stage mx-auto" style={{ width: A4_WIDTH_PX * scale, height: height * scale }}>
        <div ref={canvasRef} className="resume-preview-canvas" style={{ width: A4_WIDTH_PX, transform: `scale(${scale})`, transformOrigin: "top left" }}>
          <ResumePreview resume={resume} />
        </div>
      </div>
    </div>
  );
}
