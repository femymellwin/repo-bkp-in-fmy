"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, type FieldValues, type Resolver, useForm, useWatch } from "react-hook-form";
import { ArrowDown, ArrowUp, ImagePlus, Pencil, Plus, Trash2 } from "lucide-react";
import { z } from "zod";
import {
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  Input,
  Label,
  Textarea,
  useToast,
} from "@/components/ui";
import {
  awardSchema,
  certificationSchema,
  contactSchema,
  customItemSchema,
  educationSchema,
  experienceSchema,
  languageSchema,
  personalSchema,
  projectSchema,
  publicationSchema,
  referenceSchema,
  skillGroupSchema,
  volunteerSchema,
  type ResumeDocument,
  type ResumeData,
} from "@/lib/resume/schema";
import { createId, moveItem } from "@/lib/utils";

type UpdateData = (updater: (data: ResumeData) => ResumeData) => void;

function FieldError({ message }: { message?: string }) {
  return message ? <p className="mt-1 text-xs text-red-600">{message}</p> : null;
}

function useLiveForm<T extends FieldValues>(schema: z.ZodType<T>, values: T, onChange: (value: T) => void) {
  const form = useForm<T>({
    resolver: zodResolver(schema) as Resolver<T>,
    values,
    mode: "onChange",
  });

  const { subscribe } = form;
  React.useEffect(
    () =>
      subscribe({
        formState: { values: true },
        callback: ({ values: next }) => {
          const parsed = schema.safeParse(next);
          if (parsed.success) onChange(parsed.data);
        },
      }),
    [onChange, schema, subscribe],
  );

  return form;
}

function fileAsImage(file: File) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(image);
    };
    image.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("The selected image could not be read."));
    };
    image.src = objectUrl;
  });
}

function blobAsDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("The optimized image could not be read."));
    reader.readAsDataURL(blob);
  });
}

async function optimizeProfilePhoto(file: File) {
  const image = await fileAsImage(file);
  const maximumDimension = 512;
  const scale = Math.min(1, maximumDimension / Math.max(image.naturalWidth, image.naturalHeight));
  const width = Math.max(1, Math.round(image.naturalWidth * scale));
  const height = Math.max(1, Math.round(image.naturalHeight * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("This browser cannot optimize the selected image.");
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, width, height);
  context.drawImage(image, 0, 0, width, height);
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.84));
  if (!blob) throw new Error("The selected image could not be optimized.");
  return blobAsDataUrl(blob);
}

function PersonalEditor({ resume, updateData }: { resume: ResumeDocument; updateData: UpdateData }) {
  const { toast } = useToast();
  const onChange = React.useCallback((personal: ResumeData["personal"]) => updateData((data) => ({ ...data, personal })), [updateData]);
  const form = useLiveForm(personalSchema, resume.data.personal, onChange);
  const photoUrl = useWatch({ control: form.control, name: "photoUrl" });

  async function uploadPhoto(event: React.ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 2_000_000) {
      toast({ title: "Photo not accepted", description: "Choose a JPG, PNG, or WebP image smaller than 2 MB.", variant: "error" });
      return;
    }
    try {
      const photoUrl = await optimizeProfilePhoto(file);
      form.setValue("photoUrl", photoUrl, { shouldDirty: true, shouldValidate: true });
      form.setValue("photoPath", "", { shouldDirty: true });
    } catch (error) {
      toast({ title: "Photo could not be processed", description: error instanceof Error ? error.message : "Choose another image.", variant: "error" });
    }
  }

  return (
    <Card>
      <CardHeader><CardTitle>Personal information</CardTitle><CardDescription>Your name, professional title, and optional profile photo.</CardDescription></CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label htmlFor="fullName">Full name</Label><Input id="fullName" placeholder="Maya Chen" maxLength={160} {...form.register("fullName")} /><FieldError message={form.formState.errors.fullName?.message} /></div>
          <div><Label htmlFor="jobTitle">Job title</Label><Input id="jobTitle" placeholder="Senior Product Designer" maxLength={160} {...form.register("jobTitle")} /><FieldError message={form.formState.errors.jobTitle?.message} /></div>
        </div>
        <div>
          <Label htmlFor="photo">Profile photo</Label>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            {photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element -- User photos may be data URLs or short-lived signed URLs.
              <img src={photoUrl} alt="Profile preview" className="size-16 rounded-full border border-slate-200 object-cover" />
            ) : <div className="grid size-16 place-items-center rounded-full border border-dashed border-slate-300 bg-slate-50"><ImagePlus className="size-5 text-slate-400" /></div>}
            <div className="flex gap-2">
              <Button asChild type="button" variant="outline" size="sm"><label htmlFor="photo" className="cursor-pointer">Choose photo<input id="photo" type="file" accept="image/png,image/jpeg,image/webp" onChange={(event) => void uploadPhoto(event)} className="sr-only" /></label></Button>
              {photoUrl ? <Button type="button" variant="ghost" size="sm" onClick={() => { form.setValue("photoUrl", "", { shouldDirty: true }); form.setValue("photoPath", "", { shouldDirty: true }); }}>Remove</Button> : null}
            </div>
          </div>
          <p className="mt-2 text-xs text-slate-500">Photos are optional and hidden by default. Guest photos stay in this browser until cloud sync is used.</p>
        </div>
      </CardContent>
    </Card>
  );
}

function ContactEditor({ resume, updateData }: { resume: ResumeDocument; updateData: UpdateData }) {
  const onChange = React.useCallback((contact: ResumeData["contact"]) => updateData((data) => ({ ...data, contact })), [updateData]);
  const form = useLiveForm(contactSchema, resume.data.contact, onChange);
  const fields: Array<{ name: keyof ResumeData["contact"]; label: string; type?: string; placeholder: string }> = [
    { name: "email", label: "Email", type: "email", placeholder: "maya@example.com" },
    { name: "phone", label: "Telephone", type: "tel", placeholder: "+971 50 123 4567" },
    { name: "location", label: "Location", placeholder: "Dubai, UAE" },
    { name: "website", label: "Website", type: "url", placeholder: "example.com" },
    { name: "linkedin", label: "LinkedIn", type: "url", placeholder: "linkedin.com/in/username" },
    { name: "portfolio", label: "Portfolio", type: "url", placeholder: "portfolio.example.com" },
  ];
  return <Card><CardHeader><CardTitle>Contact details</CardTitle><CardDescription>Links are preserved as clickable links in the PDF.</CardDescription></CardHeader><CardContent className="grid gap-4 sm:grid-cols-2">{fields.map((field) => <div key={field.name}><Label htmlFor={field.name}>{field.label}</Label><Input id={field.name} type={field.type} placeholder={field.placeholder} maxLength={500} {...form.register(field.name)} /><FieldError message={form.formState.errors[field.name]?.message} /></div>)}</CardContent></Card>;
}

function SummaryEditor({ resume, updateData }: { resume: ResumeDocument; updateData: UpdateData }) {
  const schema = React.useMemo(() => z.object({ summary: z.string().trim().max(5000) }), []);
  const onChange = React.useCallback((value: { summary: string }) => updateData((data) => ({ ...data, summary: value.summary })), [updateData]);
  const form = useLiveForm(schema, { summary: resume.data.summary }, onChange);
  const value = useWatch({ control: form.control, name: "summary" }) ?? "";
  return <Card><CardHeader><CardTitle>Professional summary</CardTitle><CardDescription>Use 2–4 concise sentences focused on role, scope, strengths, and outcomes.</CardDescription></CardHeader><CardContent><Label htmlFor="summary">Summary</Label><Textarea id="summary" rows={8} maxLength={5000} placeholder="Product designer with 8+ years…" {...form.register("summary")} /><div className="mt-1 flex justify-between text-xs text-slate-500"><FieldError message={form.formState.errors.summary?.message} /><span>{value.length}/5000</span></div></CardContent></Card>;
}

type FieldDefinition = {
  key: string;
  label: string;
  placeholder?: string;
  type?: "text" | "url" | "email" | "tel" | "textarea" | "list" | "checkbox";
  description?: string;
};

type CollectionConfig = {
  title: string;
  singular: string;
  description: string;
  schema: z.ZodTypeAny;
  fields: FieldDefinition[];
  create: () => Record<string, unknown>;
  summary: (item: Record<string, unknown>) => { title: string; subtitle?: string };
};

const collectionConfigs: Record<string, CollectionConfig> = {
  experience: {
    title: "Work experience", singular: "experience", description: "Add roles in reverse chronological order and lead with measurable achievements.", schema: experienceSchema,
    fields: [
      { key: "role", label: "Role", placeholder: "Senior Product Designer" }, { key: "company", label: "Company", placeholder: "Northstar Labs" }, { key: "location", label: "Location", placeholder: "Dubai, UAE" },
      { key: "startDate", label: "Start date", placeholder: "2022" }, { key: "endDate", label: "End date", placeholder: "Present" }, { key: "current", label: "I currently work here", type: "checkbox" },
      { key: "description", label: "Role overview", type: "textarea", placeholder: "One concise sentence describing your scope." }, { key: "highlights", label: "Achievements", type: "list", placeholder: "One achievement per line", description: "Use one line per bullet." },
    ],
    create: () => ({ id: createId("experience"), company: "", role: "", location: "", startDate: "", endDate: "", current: false, description: "", highlights: [] }),
    summary: (item) => ({ title: String(item.role || "Untitled role"), subtitle: [item.company, item.startDate, item.endDate].filter(Boolean).join(" • ") }),
  },
  education: {
    title: "Education", singular: "education entry", description: "Add degrees, diplomas, training, or relevant academic programs.", schema: educationSchema,
    fields: [
      { key: "institution", label: "Institution", placeholder: "National University" }, { key: "degree", label: "Degree", placeholder: "Bachelor of Arts" }, { key: "field", label: "Field", placeholder: "Industrial Design" },
      { key: "location", label: "Location", placeholder: "Singapore" }, { key: "startDate", label: "Start date", placeholder: "2014" }, { key: "endDate", label: "End date", placeholder: "2018" }, { key: "score", label: "Score or distinction", placeholder: "Honours" }, { key: "description", label: "Description", type: "textarea", placeholder: "Relevant coursework or focus." },
    ],
    create: () => ({ id: createId("education"), institution: "", degree: "", field: "", location: "", startDate: "", endDate: "", score: "", description: "" }),
    summary: (item) => ({ title: String(item.degree || item.institution || "Untitled education"), subtitle: [item.institution, item.endDate].filter(Boolean).join(" • ") }),
  },
  skills: {
    title: "Skills", singular: "skill group", description: "Group related skills so recruiters can scan them quickly.", schema: skillGroupSchema,
    fields: [{ key: "name", label: "Group name", placeholder: "Product design" }, { key: "skills", label: "Skills", type: "list", placeholder: "Discovery\nPrototyping\nAccessibility", description: "Use one skill per line." }],
    create: () => ({ id: createId("skills"), name: "", skills: [] }),
    summary: (item) => ({ title: String(item.name || "Skill group"), subtitle: Array.isArray(item.skills) ? item.skills.join(", ") : "" }),
  },
  projects: {
    title: "Projects", singular: "project", description: "Show relevant independent, internal, academic, or open-source work.", schema: projectSchema,
    fields: [{ key: "name", label: "Project name", placeholder: "Accessible Data Toolkit" }, { key: "role", label: "Your role", placeholder: "Design lead" }, { key: "url", label: "Project URL", type: "url", placeholder: "github.com/example/project" }, { key: "startDate", label: "Start date", placeholder: "2024" }, { key: "endDate", label: "End date", placeholder: "2025" }, { key: "description", label: "Description", type: "textarea" }, { key: "highlights", label: "Highlights", type: "list", description: "Use one highlight per line." }],
    create: () => ({ id: createId("project"), name: "", role: "", url: "", startDate: "", endDate: "", description: "", highlights: [] }),
    summary: (item) => ({ title: String(item.name || "Untitled project"), subtitle: [item.role, item.endDate].filter(Boolean).join(" • ") }),
  },
  certifications: {
    title: "Certifications", singular: "certification", description: "Add current, relevant credentials and licenses.", schema: certificationSchema,
    fields: [{ key: "name", label: "Certification", placeholder: "Accessibility Core Competencies" }, { key: "issuer", label: "Issuer", placeholder: "IAAP" }, { key: "date", label: "Date", placeholder: "2025" }, { key: "url", label: "Credential URL", type: "url" }],
    create: () => ({ id: createId("certification"), name: "", issuer: "", date: "", url: "" }),
    summary: (item) => ({ title: String(item.name || "Untitled certification"), subtitle: [item.issuer, item.date].filter(Boolean).join(" • ") }),
  },
  languages: {
    title: "Languages", singular: "language", description: "State proficiency accurately and consistently.", schema: languageSchema,
    fields: [{ key: "name", label: "Language", placeholder: "English" }, { key: "proficiency", label: "Proficiency", placeholder: "Fluent" }],
    create: () => ({ id: createId("language"), name: "", proficiency: "" }),
    summary: (item) => ({ title: String(item.name || "Language"), subtitle: String(item.proficiency || "") }),
  },
  awards: {
    title: "Awards", singular: "award", description: "Include selective recognition relevant to your target role.", schema: awardSchema,
    fields: [{ key: "title", label: "Award", placeholder: "Design Excellence Award" }, { key: "issuer", label: "Issuer" }, { key: "date", label: "Date", placeholder: "2025" }, { key: "description", label: "Description", type: "textarea" }],
    create: () => ({ id: createId("award"), title: "", issuer: "", date: "", description: "" }),
    summary: (item) => ({ title: String(item.title || "Untitled award"), subtitle: [item.issuer, item.date].filter(Boolean).join(" • ") }),
  },
  publications: {
    title: "Publications", singular: "publication", description: "Add authored articles, papers, books, or significant public writing.", schema: publicationSchema,
    fields: [{ key: "title", label: "Title" }, { key: "publisher", label: "Publisher" }, { key: "date", label: "Date" }, { key: "url", label: "URL", type: "url" }, { key: "description", label: "Description", type: "textarea" }],
    create: () => ({ id: createId("publication"), title: "", publisher: "", date: "", url: "", description: "" }),
    summary: (item) => ({ title: String(item.title || "Untitled publication"), subtitle: [item.publisher, item.date].filter(Boolean).join(" • ") }),
  },
  volunteer: {
    title: "Volunteer experience", singular: "volunteer role", description: "Show community contribution, leadership, and transferable outcomes.", schema: volunteerSchema,
    fields: [{ key: "organization", label: "Organization" }, { key: "role", label: "Role" }, { key: "startDate", label: "Start date" }, { key: "endDate", label: "End date" }, { key: "description", label: "Description", type: "textarea" }, { key: "highlights", label: "Highlights", type: "list", description: "Use one highlight per line." }],
    create: () => ({ id: createId("volunteer"), organization: "", role: "", startDate: "", endDate: "", description: "", highlights: [] }),
    summary: (item) => ({ title: String(item.role || item.organization || "Volunteer role"), subtitle: [item.organization, item.endDate].filter(Boolean).join(" • ") }),
  },
  references: {
    title: "References", singular: "reference", description: "Only include references when appropriate and with permission.", schema: referenceSchema,
    fields: [{ key: "name", label: "Name" }, { key: "relationship", label: "Relationship or title" }, { key: "email", label: "Email", type: "email" }, { key: "phone", label: "Phone", type: "tel" }],
    create: () => ({ id: createId("reference"), name: "", relationship: "", email: "", phone: "" }),
    summary: (item) => ({ title: String(item.name || "Reference"), subtitle: String(item.relationship || item.email || "") }),
  },
  custom: {
    title: "Custom section", singular: "custom entry", description: "Use a flexible entry for memberships, conferences, interests, or another relevant category.", schema: customItemSchema,
    fields: [{ key: "heading", label: "Heading" }, { key: "subheading", label: "Subheading" }, { key: "date", label: "Date" }, { key: "description", label: "Description", type: "textarea" }, { key: "highlights", label: "Highlights", type: "list", description: "Use one highlight per line." }],
    create: () => ({ id: createId("custom-item"), heading: "", subheading: "", date: "", description: "", highlights: [] }),
    summary: (item) => ({ title: String(item.heading || "Custom entry"), subtitle: [item.subheading, item.date].filter(Boolean).join(" • ") }),
  },
};

function EntryDialog({ open, onOpenChange, config, initial, editing, onSave }: { open: boolean; onOpenChange: (open: boolean) => void; config: CollectionConfig; initial: Record<string, unknown>; editing: boolean; onSave: (value: Record<string, unknown>) => void }) {
  const form = useForm<Record<string, unknown>>({ resolver: zodResolver(config.schema) as Resolver<Record<string, unknown>>, values: initial, mode: "onChange" });
  const submit = form.handleSubmit((value) => { onSave(config.schema.parse(value) as Record<string, unknown>); onOpenChange(false); });
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>{editing ? `Edit ${config.singular}` : `Add ${config.singular}`}</DialogTitle><DialogDescription>Changes appear in the preview after saving this entry.</DialogDescription></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            {config.fields.map((field) => {
              const error = form.formState.errors[field.key]?.message as string | undefined;
              if (field.type === "checkbox") return <Controller key={field.key} control={form.control} name={field.key} render={({ field: controller }) => <label className="flex items-center gap-2 rounded-md border border-slate-200 p-3 text-sm font-medium text-slate-800 sm:col-span-2"><input type="checkbox" checked={Boolean(controller.value)} onChange={controller.onChange} className="size-4 accent-teal-700" />{field.label}</label>} />;
              if (field.type === "textarea" || field.type === "list") return <div key={field.key} className="sm:col-span-2"><Label htmlFor={`entry-${field.key}`}>{field.label}</Label><Controller control={form.control} name={field.key} render={({ field: controller }) => <Textarea id={`entry-${field.key}`} rows={field.type === "list" ? 5 : 4} placeholder={field.placeholder} value={field.type === "list" ? (Array.isArray(controller.value) ? controller.value.join("\n") : "") : String(controller.value ?? "")} onChange={(event) => controller.onChange(field.type === "list" ? event.target.value.split("\n").map((line) => line.trim()).filter(Boolean) : event.target.value)} />} />{field.description ? <p className="mt-1 text-xs text-slate-500">{field.description}</p> : null}<FieldError message={error} /></div>;
              return <div key={field.key}><Label htmlFor={`entry-${field.key}`}>{field.label}</Label><Controller control={form.control} name={field.key} render={({ field: controller }) => <Input id={`entry-${field.key}`} type={field.type || "text"} placeholder={field.placeholder} value={String(controller.value ?? "")} onChange={controller.onChange} />} /><FieldError message={error} /></div>;
            })}
          </div>
          <DialogFooter><Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit">Save {config.singular}</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function CollectionEditor({ config, items, onChange }: { config: CollectionConfig; items: Record<string, unknown>[]; onChange: (items: Record<string, unknown>[]) => void }) {
  const [open, setOpen] = React.useState(false);
  const [editingIndex, setEditingIndex] = React.useState<number | null>(null);
  const initial = editingIndex === null ? config.create() : (items[editingIndex] ?? config.create());
  function save(value: Record<string, unknown>) {
    if (editingIndex === null) onChange([...items, value]);
    else onChange(items.map((item, index) => index === editingIndex ? value : item));
    setEditingIndex(null);
  }
  function add() { setEditingIndex(null); setOpen(true); }
  function edit(index: number) { setEditingIndex(index); setOpen(true); }
  return (
    <Card>
      <CardHeader className="flex-row items-start justify-between gap-4"><div><CardTitle>{config.title}</CardTitle><CardDescription className="mt-1">{config.description}</CardDescription></div><Button type="button" size="sm" onClick={add}><Plus className="size-4" />Add</Button></CardHeader>
      <CardContent>
        {items.length ? <div className="space-y-2">{items.map((item, index) => { const summary = config.summary(item); return <div key={String(item.id)} className="flex items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3"><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-slate-900">{summary.title}</p>{summary.subtitle ? <p className="truncate text-xs text-slate-500">{summary.subtitle}</p> : null}</div><div className="flex shrink-0 items-center"><Button type="button" size="icon-sm" variant="ghost" aria-label={`Move ${summary.title} up`} disabled={index === 0} onClick={() => onChange(moveItem(items, index, index - 1))}><ArrowUp className="size-4" /></Button><Button type="button" size="icon-sm" variant="ghost" aria-label={`Move ${summary.title} down`} disabled={index === items.length - 1} onClick={() => onChange(moveItem(items, index, index + 1))}><ArrowDown className="size-4" /></Button><Button type="button" size="icon-sm" variant="ghost" aria-label={`Edit ${summary.title}`} onClick={() => edit(index)}><Pencil className="size-4" /></Button><Button type="button" size="icon-sm" variant="ghost" className="text-red-600 hover:bg-red-50 hover:text-red-700" aria-label={`Delete ${summary.title}`} onClick={() => onChange(items.filter((_, itemIndex) => itemIndex !== index))}><Trash2 className="size-4" /></Button></div></div>; })}</div> : <button type="button" onClick={add} className="w-full rounded-lg border border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center text-sm text-slate-600 hover:border-teal-500 hover:bg-teal-50/40"><Plus className="mx-auto mb-2 size-5" />Add your first {config.singular}</button>}
      </CardContent>
      <EntryDialog open={open} onOpenChange={setOpen} config={config} initial={initial} editing={editingIndex !== null} onSave={save} />
    </Card>
  );
}

export function SectionEditor({ resume, sectionId, updateData }: { resume: ResumeDocument; sectionId: string; updateData: UpdateData }) {
  if (sectionId === "personal") return <PersonalEditor resume={resume} updateData={updateData} />;
  if (sectionId === "contact") return <ContactEditor resume={resume} updateData={updateData} />;
  if (sectionId === "summary") return <SummaryEditor resume={resume} updateData={updateData} />;
  if (sectionId.startsWith("custom-")) {
    const customId = sectionId.slice("custom-".length);
    const section = resume.data.customSections.find((item) => item.id === customId);
    if (!section) return null;
    return <CollectionEditor config={{ ...collectionConfigs.custom, title: section.title, description: `Entries shown under “${section.title}”.` }} items={section.items as unknown as Record<string, unknown>[]} onChange={(items) => updateData((data) => ({ ...data, customSections: data.customSections.map((item) => item.id === customId ? { ...item, items: items as ResumeData["customSections"][number]["items"] } : item) }))} />;
  }
  const config = collectionConfigs[sectionId];
  if (!config) return <Card><CardContent className="p-6 text-sm text-slate-600">This section is not available.</CardContent></Card>;
  const key = sectionId as Exclude<keyof ResumeData, "personal" | "contact" | "summary" | "customSections">;
  const items = resume.data[key] as unknown as Record<string, unknown>[];
  return <CollectionEditor config={config} items={items} onChange={(next) => updateData((data) => ({ ...data, [key]: next }) as ResumeData)} />;
}
