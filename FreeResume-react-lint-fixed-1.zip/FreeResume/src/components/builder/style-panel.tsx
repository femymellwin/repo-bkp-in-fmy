"use client";

import * as React from "react";
import { Badge, Card, CardContent, CardHeader, CardTitle, Label, Select, Switch } from "@/components/ui";
import type { ResumeDocument, ResumeSettings, TemplateId } from "@/lib/resume/schema";
import { resumeTemplates } from "@/lib/resume/templates";
import { cn } from "@/lib/utils";

function AccentColorControl({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const [draft, setDraft] = React.useState(value);

  function applyDraft() {
    if (/^#[0-9a-fA-F]{6}$/.test(draft)) onChange(draft.toLowerCase());
    else setDraft(value);
  }

  return (
    <div>
      <Label htmlFor="accent-color">Accent color</Label>
      <div className="mt-2 flex items-center gap-3">
        <input
          id="accent-color"
          type="color"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="h-10 w-14 cursor-pointer rounded border border-slate-300 bg-white p-1"
        />
        <input
          aria-label="Accent color hex value"
          value={draft}
          onChange={(event) => setDraft(event.target.value.slice(0, 7))}
          onBlur={applyDraft}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              applyDraft();
              event.currentTarget.blur();
            }
          }}
          spellCheck={false}
          className="h-10 flex-1 rounded-md border border-slate-300 px-3 text-sm uppercase"
        />
      </div>
    </div>
  );
}

export function StylePanel({ resume, onChange }: { resume: ResumeDocument; onChange: (settings: ResumeSettings) => void }) {
  const settings = resume.settings;
  const patch = <K extends keyof ResumeSettings>(key: K, value: ResumeSettings[K]) => onChange({ ...settings, [key]: value });
  return (
    <Card>
      <CardHeader><CardTitle>Design and layout</CardTitle></CardHeader>
      <CardContent className="space-y-6">
        <fieldset><legend className="text-sm font-medium text-slate-800">Template</legend><div className="mt-2 grid grid-cols-2 gap-2">{resumeTemplates.map((template) => <button key={template.id} type="button" onClick={() => patch("templateId", template.id as TemplateId)} className={cn("rounded-lg border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600", settings.templateId === template.id ? "border-teal-600 bg-teal-50" : "border-slate-200 bg-white hover:border-slate-300")}><span className="block text-sm font-semibold text-slate-900">{template.name}</span><Badge variant={template.atsFriendly ? "success" : "secondary"} className="mt-1">{template.atsFriendly ? "ATS-friendly" : "Visual"}</Badge></button>)}</div></fieldset>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label htmlFor="font-family">Font family</Label><Select id="font-family" value={settings.fontFamily} onChange={(event) => patch("fontFamily", event.target.value as ResumeSettings["fontFamily"])}><option value="inter">Inter / system sans</option><option value="source-sans">Source Sans</option><option value="merriweather">Merriweather / serif</option><option value="georgia">Georgia</option></Select></div>
          <div><Label htmlFor="heading-style">Heading style</Label><Select id="heading-style" value={settings.headingStyle} onChange={(event) => patch("headingStyle", event.target.value as ResumeSettings["headingStyle"])}><option value="uppercase">Uppercase</option><option value="title">Title case</option><option value="underline">Underlined</option></Select></div>
        </div>
        <div><div className="flex justify-between"><Label htmlFor="font-size">Font size</Label><span className="text-xs text-slate-500">{settings.fontSize.toFixed(1)} px</span></div><input id="font-size" type="range" min="8" max="14" step="0.5" value={settings.fontSize} onChange={(event) => patch("fontSize", Number(event.target.value))} className="mt-2 w-full accent-teal-700" /></div>
        <div><div className="flex justify-between"><Label htmlFor="line-height">Line spacing</Label><span className="text-xs text-slate-500">{settings.lineHeight.toFixed(2)}</span></div><input id="line-height" type="range" min="1.1" max="1.8" step="0.05" value={settings.lineHeight} onChange={(event) => patch("lineHeight", Number(event.target.value))} className="mt-2 w-full accent-teal-700" /></div>
        <div><div className="flex justify-between"><Label htmlFor="page-margin">Page margins</Label><span className="text-xs text-slate-500">{settings.pageMargin} mm</span></div><input id="page-margin" type="range" min="8" max="30" step="1" value={settings.pageMargin} onChange={(event) => patch("pageMargin", Number(event.target.value))} className="mt-2 w-full accent-teal-700" /></div>
        <AccentColorControl key={settings.accentColor} value={settings.accentColor} onChange={(value) => patch("accentColor", value)} />
        <div className="space-y-3 border-t border-slate-200 pt-4">
          <label className="flex items-center justify-between gap-4 text-sm font-medium text-slate-800"><span>Show profile photo</span><Switch checked={settings.showPhoto} onCheckedChange={(value) => patch("showPhoto", value)} /></label>
          <label className="flex items-center justify-between gap-4 text-sm font-medium text-slate-800"><span>Show page-break guides</span><Switch checked={settings.showPageBreaks} onCheckedChange={(value) => patch("showPageBreaks", value)} /></label>
        </div>
      </CardContent>
    </Card>
  );
}
