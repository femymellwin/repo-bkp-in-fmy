"use client";

import { PDFDownloadLink } from "@react-pdf/renderer";
import { Download, LoaderCircle } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { ResumePdfDocument } from "@/components/builder/resume-pdf-document";
import type { ResumeDocument } from "@/lib/resume/schema";
import { cn } from "@/lib/utils";

export function PdfLink({ resume, className }: { resume: ResumeDocument; className?: string }) {
  const filename = `${resume.name.trim().replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "") || "resume"}.pdf`;
  return (
    <PDFDownloadLink document={<ResumePdfDocument resume={resume} />} fileName={filename} className={cn(buttonVariants(), className)}>
      {({ loading, error }) => loading ? <><LoaderCircle className="size-4 animate-spin motion-reduce:animate-none" />Preparing PDF</> : error ? <>PDF unavailable</> : <><Download className="size-4" />Download PDF</>}
    </PDFDownloadLink>
  );
}
