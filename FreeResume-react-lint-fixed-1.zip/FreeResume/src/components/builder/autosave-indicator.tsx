import { Check, CloudOff, LoaderCircle } from "lucide-react";
import type { SaveStatus } from "@/components/builder/use-resume-editor";

export function AutosaveIndicator({ status }: { status: SaveStatus }) {
  if (status === "saving") return <span className="inline-flex items-center gap-1.5 text-xs text-slate-500" role="status"><LoaderCircle className="size-3.5 animate-spin motion-reduce:animate-none" />Saving locally</span>;
  if (status === "error") return <span className="inline-flex items-center gap-1.5 text-xs text-red-600" role="status"><CloudOff className="size-3.5" />Local save failed</span>;
  return <span className="inline-flex items-center gap-1.5 text-xs text-slate-500" role="status"><Check className="size-3.5 text-emerald-600" />Saved on this device</span>;
}
