/* eslint-disable jsx-a11y/alt-text -- @react-pdf/renderer Image is not a DOM image and has no alt prop. */
import * as React from "react";
import { Document, Image, Link, Page, StyleSheet, Text, View } from "@react-pdf/renderer";
import type { ResumeDocument, SectionConfig } from "@/lib/resume/schema";
import { mailto, safeExternalUrl, tel } from "@/lib/utils";

const mmToPt = (value: number) => value * 2.834645669;
const pdfFont = (font: ResumeDocument["settings"]["fontFamily"]) =>
  font === "merriweather" || font === "georgia" ? "Times-Roman" : "Helvetica";

function createStyles(resume: ResumeDocument) {
  const accent = resume.settings.accentColor;
  const fontSize = resume.settings.fontSize;
  return StyleSheet.create({
    page: {
      padding: mmToPt(resume.settings.pageMargin),
      color: "#172033",
      fontFamily: pdfFont(resume.settings.fontFamily),
      fontSize,
      lineHeight: resume.settings.lineHeight,
      backgroundColor: "#ffffff",
    },
    section: { marginBottom: fontSize * 1.25 },
    heading: {
      color: accent,
      fontFamily: pdfFont(resume.settings.fontFamily),
      fontWeight: 700,
      fontSize: fontSize * 1.08,
      letterSpacing: resume.settings.headingStyle === "uppercase" ? 1.05 : 0.35,
      textTransform: resume.settings.headingStyle === "uppercase" ? "uppercase" : "none",
      borderBottomWidth: resume.settings.headingStyle === "underline" ? 0.7 : 0,
      borderBottomColor: accent,
      paddingBottom: resume.settings.headingStyle === "underline" ? 2 : 0,
      marginBottom: fontSize * 0.55,
    },
    name: { color: accent, fontSize: fontSize * 2.3, fontWeight: 700, lineHeight: 1.08 },
    jobTitle: { marginTop: 3, color: "#526074", fontSize: fontSize * 1.18, fontWeight: 600 },
    headerCreative: { backgroundColor: accent, borderRadius: 4, padding: 12, color: "#ffffff" },
    contactRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, color: "#526074", fontSize: fontSize * 0.94 },
    link: { color: "#334155", textDecoration: "none" },
    entry: { marginBottom: fontSize * 0.75 },
    entryHeader: { flexDirection: "row", justifyContent: "space-between", gap: 10 },
    bold: { fontWeight: 700 },
    muted: { color: "#64748b" },
    small: { fontSize: fontSize * 0.92 },
    paragraph: { marginTop: 2 },
    bullets: { marginTop: 2, paddingLeft: 10 },
    bulletRow: { flexDirection: "row", gap: 5, marginBottom: 1 },
    bullet: { width: 4 },
    bulletText: { flex: 1 },
    photo: { width: 54, height: 54, borderRadius: 27, objectFit: "cover" },
    personalRow: { flexDirection: "row", justifyContent: "space-between", gap: 12 },
    flexOne: { flex: 1 },
    skillGrid: { flexDirection: "row", flexWrap: "wrap", gap: 4 },
    skillPill: { backgroundColor: "#f1f5f9", borderRadius: 3, paddingHorizontal: 4, paddingVertical: 2 },
    referenceGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
    reference: { width: "48%" },
  });
}

function PdfLink({ src, children, styles }: { src?: string; children: React.ReactNode; styles: ReturnType<typeof createStyles> }) {
  return src ? <Link src={src} style={styles.link}>{children}</Link> : <Text>{children}</Text>;
}

function PdfBullets({ items, styles }: { items: string[]; styles: ReturnType<typeof createStyles> }) {
  return items.filter(Boolean).length ? <View style={styles.bullets}>{items.filter(Boolean).map((item, index) => <View key={`${item}-${index}`} style={styles.bulletRow}><Text style={styles.bullet}>•</Text><Text style={styles.bulletText}>{item}</Text></View>)}</View> : null;
}

function range(start: string, end: string) {
  return [start, end].filter(Boolean).join(" – ");
}

function Heading({ title, styles }: { title: string; styles: ReturnType<typeof createStyles> }) {
  return <Text style={styles.heading}>{title}</Text>;
}

function PdfSection({ section, resume, styles }: { section: SectionConfig; resume: ResumeDocument; styles: ReturnType<typeof createStyles> }) {
  const { data } = resume;
  switch (section.id) {
    case "personal":
      if (!data.personal.fullName && !data.personal.jobTitle) return null;
      return <View style={[styles.section, resume.settings.templateId === "creative" ? styles.headerCreative : {}]} minPresenceAhead={40}><View style={styles.personalRow}><View style={styles.flexOne}><Text style={[styles.name, resume.settings.templateId === "creative" ? { color: "#ffffff" } : {}]}>{data.personal.fullName || "Your name"}</Text>{data.personal.jobTitle ? <Text style={[styles.jobTitle, resume.settings.templateId === "creative" ? { color: "#e2e8f0" } : {}]}>{data.personal.jobTitle}</Text> : null}</View>{resume.settings.showPhoto && data.personal.photoUrl ? <Image style={styles.photo} src={data.personal.photoUrl} /> : null}</View></View>;
    case "contact": {
      const contact = [
        data.contact.email ? { value: data.contact.email, href: mailto(data.contact.email) } : null,
        data.contact.phone ? { value: data.contact.phone, href: tel(data.contact.phone) } : null,
        data.contact.location ? { value: data.contact.location } : null,
        data.contact.website ? { value: data.contact.website, href: safeExternalUrl(data.contact.website) } : null,
        data.contact.linkedin ? { value: data.contact.linkedin, href: safeExternalUrl(data.contact.linkedin) } : null,
        data.contact.portfolio ? { value: data.contact.portfolio, href: safeExternalUrl(data.contact.portfolio) } : null,
      ].filter((item): item is { value: string; href?: string } => Boolean(item));
      if (!contact.length) return null;
      return <View style={[styles.section, styles.contactRow]}>{contact.map((item, index) => <React.Fragment key={`${item.value}-${index}`}>{index ? <Text> • </Text> : null}<PdfLink src={item.href} styles={styles}>{item.value}</PdfLink></React.Fragment>)}</View>;
    }
    case "summary":
      return data.summary ? <View style={styles.section} minPresenceAhead={45}><Heading title={section.title} styles={styles} /><Text>{data.summary}</Text></View> : null;
    case "experience":
      return data.experience.length ? <View style={styles.section}><Heading title={section.title} styles={styles} />{data.experience.map((entry) => <View key={entry.id} style={styles.entry} minPresenceAhead={55}><View style={styles.entryHeader}><Text style={styles.bold}>{entry.role}</Text><Text style={[styles.muted, styles.small]}>{range(entry.startDate, entry.current ? "Present" : entry.endDate)}</Text></View><View style={styles.entryHeader}><Text style={styles.muted}>{entry.company}</Text><Text style={[styles.muted, styles.small]}>{entry.location}</Text></View>{entry.description ? <Text style={styles.paragraph}>{entry.description}</Text> : null}<PdfBullets items={entry.highlights} styles={styles} /></View>)}</View> : null;
    case "education":
      return data.education.length ? <View style={styles.section}><Heading title={section.title} styles={styles} />{data.education.map((entry) => <View key={entry.id} style={styles.entry} minPresenceAhead={40}><View style={styles.entryHeader}><Text style={styles.bold}>{[entry.degree, entry.field].filter(Boolean).join(" in ")}</Text><Text style={[styles.muted, styles.small]}>{range(entry.startDate, entry.endDate)}</Text></View><View style={styles.entryHeader}><Text style={styles.muted}>{entry.institution}</Text><Text style={[styles.muted, styles.small]}>{entry.location}</Text></View>{entry.score ? <Text style={styles.muted}>{entry.score}</Text> : null}{entry.description ? <Text style={styles.paragraph}>{entry.description}</Text> : null}</View>)}</View> : null;
    case "skills":
      return data.skills.length ? <View style={styles.section} minPresenceAhead={35}><Heading title={section.title} styles={styles} />{data.skills.map((group) => <View key={group.id} style={[styles.entry, resume.settings.templateId === "creative" ? styles.skillGrid : {}]}><Text style={styles.bold}>{group.name ? `${group.name}: ` : ""}</Text>{group.skills.filter(Boolean).map((skill, index) => resume.settings.templateId === "creative" ? <Text key={`${skill}-${index}`} style={styles.skillPill}>{skill}</Text> : <Text key={`${skill}-${index}`}>{index ? `, ${skill}` : skill}</Text>)}</View>)}</View> : null;
    case "projects":
      return data.projects.length ? <View style={styles.section}><Heading title={section.title} styles={styles} />{data.projects.map((entry) => <View key={entry.id} style={styles.entry} minPresenceAhead={50}><View style={styles.entryHeader}><PdfLink src={safeExternalUrl(entry.url)} styles={styles}><Text style={styles.bold}>{entry.name}</Text></PdfLink><Text style={[styles.muted, styles.small]}>{range(entry.startDate, entry.endDate)}</Text></View>{entry.role ? <Text style={styles.muted}>{entry.role}</Text> : null}{entry.description ? <Text style={styles.paragraph}>{entry.description}</Text> : null}<PdfBullets items={entry.highlights} styles={styles} /></View>)}</View> : null;
    case "certifications":
      return data.certifications.length ? <View style={styles.section}><Heading title={section.title} styles={styles} />{data.certifications.map((entry) => <View key={entry.id} style={[styles.entryHeader, styles.entry]}><Text><PdfLink src={safeExternalUrl(entry.url)} styles={styles}><Text style={styles.bold}>{entry.name}</Text></PdfLink>{entry.issuer ? ` — ${entry.issuer}` : ""}</Text><Text style={[styles.muted, styles.small]}>{entry.date}</Text></View>)}</View> : null;
    case "languages":
      return data.languages.length ? <View style={styles.section} minPresenceAhead={30}><Heading title={section.title} styles={styles} /><Text>{data.languages.map((entry) => `${entry.name}${entry.proficiency ? ` (${entry.proficiency})` : ""}`).join(" • ")}</Text></View> : null;
    case "awards":
      return data.awards.length ? <View style={styles.section}><Heading title={section.title} styles={styles} />{data.awards.map((entry) => <View key={entry.id} style={styles.entry} minPresenceAhead={35}><View style={styles.entryHeader}><Text style={styles.bold}>{entry.title}</Text><Text style={[styles.muted, styles.small]}>{entry.date}</Text></View><Text style={styles.muted}>{entry.issuer}</Text>{entry.description ? <Text style={styles.paragraph}>{entry.description}</Text> : null}</View>)}</View> : null;
    case "publications":
      return data.publications.length ? <View style={styles.section}><Heading title={section.title} styles={styles} />{data.publications.map((entry) => <View key={entry.id} style={styles.entry} minPresenceAhead={35}><View style={styles.entryHeader}><PdfLink src={safeExternalUrl(entry.url)} styles={styles}><Text style={styles.bold}>{entry.title}</Text></PdfLink><Text style={[styles.muted, styles.small]}>{entry.date}</Text></View><Text style={styles.muted}>{entry.publisher}</Text>{entry.description ? <Text style={styles.paragraph}>{entry.description}</Text> : null}</View>)}</View> : null;
    case "volunteer":
      return data.volunteer.length ? <View style={styles.section}><Heading title={section.title} styles={styles} />{data.volunteer.map((entry) => <View key={entry.id} style={styles.entry} minPresenceAhead={45}><View style={styles.entryHeader}><Text style={styles.bold}>{entry.role}{entry.organization ? ` — ${entry.organization}` : ""}</Text><Text style={[styles.muted, styles.small]}>{range(entry.startDate, entry.endDate)}</Text></View>{entry.description ? <Text style={styles.paragraph}>{entry.description}</Text> : null}<PdfBullets items={entry.highlights} styles={styles} /></View>)}</View> : null;
    case "references":
      return data.references.length ? <View style={styles.section}><Heading title={section.title} styles={styles} /><View style={styles.referenceGrid}>{data.references.map((entry) => <View key={entry.id} style={[styles.entry, styles.reference]} minPresenceAhead={35}><Text style={styles.bold}>{entry.name}</Text><Text style={styles.muted}>{entry.relationship}</Text>{entry.email ? <PdfLink src={mailto(entry.email)} styles={styles}>{entry.email}</PdfLink> : null}{entry.phone ? <PdfLink src={tel(entry.phone)} styles={styles}>{entry.phone}</PdfLink> : null}</View>)}</View></View> : null;
    default: {
      const custom = data.customSections.find((item) => `custom-${item.id}` === section.id);
      return custom?.items.length ? <View style={styles.section}><Heading title={custom.title || section.title} styles={styles} />{custom.items.map((entry) => <View key={entry.id} style={styles.entry} minPresenceAhead={40}><View style={styles.entryHeader}><Text style={styles.bold}>{entry.heading}</Text><Text style={[styles.muted, styles.small]}>{entry.date}</Text></View>{entry.subheading ? <Text style={styles.muted}>{entry.subheading}</Text> : null}{entry.description ? <Text style={styles.paragraph}>{entry.description}</Text> : null}<PdfBullets items={entry.highlights} styles={styles} /></View>)}</View> : null;
    }
  }
}

export function ResumePdfDocument({ resume }: { resume: ResumeDocument }) {
  const styles = createStyles(resume);
  return (
    <Document title={resume.name} author={resume.data.personal.fullName || "FreeResume user"} subject="Resume" creator="FreeResume">
      <Page size="A4" style={styles.page} wrap>
        {resume.settings.templateId === "modern" ? <View fixed style={{ height: 4, backgroundColor: resume.settings.accentColor, position: "absolute", left: 0, right: 0, top: 0 }} /> : null}
        {resume.sections.filter((section) => section.visible).map((section) => <PdfSection key={section.id} section={section} resume={resume} styles={styles} />)}
      </Page>
    </Document>
  );
}
