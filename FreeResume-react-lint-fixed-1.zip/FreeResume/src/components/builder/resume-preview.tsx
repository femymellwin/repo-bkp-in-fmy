"use client";

import * as React from "react";
import type { ResumeDocument, SectionConfig } from "@/lib/resume/schema";
import { fontStacks } from "@/lib/resume/templates";
import { cn, mailto, safeExternalUrl, tel } from "@/lib/utils";

function joinRange(start: string, end: string) {
  return [start, end].filter(Boolean).join(" – ");
}

function SectionHeading({ title, resume }: { title: string; resume: ResumeDocument }) {
  const style = resume.settings.headingStyle;
  return (
    <h2
      className={cn(
        "mb-2 font-bold tracking-[0.12em] text-[var(--resume-accent)]",
        style === "uppercase" && "uppercase",
        style === "title" && "normal-case tracking-[0.04em]",
        style === "underline" && "border-b border-[var(--resume-accent)] pb-1 normal-case tracking-[0.04em]",
        resume.settings.templateId === "executive" && "tracking-[0.08em]",
      )}
      style={{ fontSize: "1.08em" }}
    >
      {title}
    </h2>
  );
}

function ContactLink({ href, children }: { href?: string; children: React.ReactNode }) {
  return href ? <a className="resume-link" href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer">{children}</a> : <span>{children}</span>;
}

function renderHighlights(items: string[]) {
  const values = items.filter(Boolean);
  return values.length ? (
    <ul className="mt-1 list-disc space-y-0.5 pl-[1.2em]">
      {values.map((item, index) => <li key={`${item}-${index}`}>{item}</li>)}
    </ul>
  ) : null;
}

function ResumeSectionContent({ section, resume }: { section: SectionConfig; resume: ResumeDocument }) {
  const { data } = resume;
  switch (section.id) {
    case "personal":
      if (!data.personal.fullName && !data.personal.jobTitle) return null;
      return (
        <section className={cn("resume-section", resume.settings.templateId === "professional" && "text-center", resume.settings.templateId === "creative" && "rounded-md bg-[var(--resume-accent)] p-4 text-white")}>
          <div className={cn("flex items-start gap-4", resume.settings.templateId === "professional" && "justify-center", resume.settings.templateId === "creative" && "items-center")}>
            <div className="min-w-0 flex-1">
              <h1 className={cn("font-bold leading-tight", resume.settings.templateId === "executive" ? "tracking-[0.04em]" : "tracking-tight")} style={{ fontSize: "2.35em", color: resume.settings.templateId === "creative" ? "white" : "var(--resume-accent)" }}>
                {data.personal.fullName || "Your name"}
              </h1>
              {data.personal.jobTitle ? <p className={cn("mt-1 font-medium", resume.settings.templateId === "creative" ? "text-white/90" : "text-slate-600")} style={{ fontSize: "1.2em" }}>{data.personal.jobTitle}</p> : null}
            </div>
            {resume.settings.showPhoto && data.personal.photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={data.personal.photoUrl} alt="" className="size-20 shrink-0 rounded-full border-2 border-white/80 object-cover" />
            ) : null}
          </div>
        </section>
      );
    case "contact": {
      const items = [
        data.contact.email && <ContactLink key="email" href={mailto(data.contact.email)}>{data.contact.email}</ContactLink>,
        data.contact.phone && <ContactLink key="phone" href={tel(data.contact.phone)}>{data.contact.phone}</ContactLink>,
        data.contact.location && <span key="location">{data.contact.location}</span>,
        data.contact.website && <ContactLink key="website" href={safeExternalUrl(data.contact.website)}>{data.contact.website}</ContactLink>,
        data.contact.linkedin && <ContactLink key="linkedin" href={safeExternalUrl(data.contact.linkedin)}>{data.contact.linkedin}</ContactLink>,
        data.contact.portfolio && <ContactLink key="portfolio" href={safeExternalUrl(data.contact.portfolio)}>{data.contact.portfolio}</ContactLink>,
      ].filter(Boolean);
      if (!items.length) return null;
      return <section className={cn("resume-section flex flex-wrap gap-x-3 gap-y-1 text-slate-600", resume.settings.templateId === "professional" && "justify-center")}>{items.map((item, index) => <React.Fragment key={index}>{index > 0 ? <span aria-hidden className="text-slate-300">•</span> : null}{item}</React.Fragment>)}</section>;
    }
    case "summary":
      if (!data.summary) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><p className="whitespace-pre-line">{data.summary}</p></section>;
    case "experience":
      if (!data.experience.length) return null;
      return (
        <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="space-y-3">{data.experience.map((entry) => (
          <article key={entry.id} className="resume-entry">
            <div className="flex items-baseline justify-between gap-4"><h3 className="font-bold" style={{ fontSize: "1.08em" }}>{entry.role}</h3><span className="shrink-0 text-slate-500">{joinRange(entry.startDate, entry.current ? "Present" : entry.endDate)}</span></div>
            <div className="flex items-baseline justify-between gap-4 text-slate-600"><p className="font-medium">{entry.company}</p><span>{entry.location}</span></div>
            {entry.description ? <p className="mt-1">{entry.description}</p> : null}{renderHighlights(entry.highlights)}
          </article>
        ))}</div></section>
      );
    case "education":
      if (!data.education.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="space-y-2.5">{data.education.map((entry) => <article key={entry.id} className="resume-entry"><div className="flex items-baseline justify-between gap-4"><h3 className="font-bold">{[entry.degree, entry.field].filter(Boolean).join(" in ")}</h3><span className="shrink-0 text-slate-500">{joinRange(entry.startDate, entry.endDate)}</span></div><div className="flex justify-between gap-4 text-slate-600"><p>{entry.institution}</p><span>{entry.location}</span></div>{entry.score ? <p className="text-slate-600">{entry.score}</p> : null}{entry.description ? <p className="mt-1">{entry.description}</p> : null}</article>)}</div></section>;
    case "skills":
      if (!data.skills.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className={cn("space-y-1.5", resume.settings.templateId === "creative" && "grid grid-cols-2 gap-x-4 gap-y-2 space-y-0")}>{data.skills.map((group) => <div key={group.id} className="resume-entry"><span className="font-semibold">{group.name}{group.name ? ": " : ""}</span><span className={cn(resume.settings.templateId === "creative" && "inline-flex flex-wrap gap-1")}>{group.skills.filter(Boolean).map((skill, index) => resume.settings.templateId === "creative" ? <span key={`${skill}-${index}`} className="inline-block rounded bg-slate-100 px-1.5 py-0.5">{skill}</span> : <React.Fragment key={`${skill}-${index}`}>{index ? ", " : ""}{skill}</React.Fragment>)}</span></div>)}</div></section>;
    case "projects":
      if (!data.projects.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="space-y-3">{data.projects.map((entry) => <article key={entry.id} className="resume-entry"><div className="flex items-baseline justify-between gap-4"><h3 className="font-bold">{entry.url ? <ContactLink href={safeExternalUrl(entry.url)}>{entry.name}</ContactLink> : entry.name}</h3><span className="shrink-0 text-slate-500">{joinRange(entry.startDate, entry.endDate)}</span></div>{entry.role ? <p className="text-slate-600">{entry.role}</p> : null}{entry.description ? <p className="mt-1">{entry.description}</p> : null}{renderHighlights(entry.highlights)}</article>)}</div></section>;
    case "certifications":
      if (!data.certifications.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="space-y-1.5">{data.certifications.map((entry) => <div key={entry.id} className="resume-entry flex justify-between gap-4"><p><span className="font-semibold">{entry.url ? <ContactLink href={safeExternalUrl(entry.url)}>{entry.name}</ContactLink> : entry.name}</span>{entry.issuer ? ` — ${entry.issuer}` : ""}</p><span className="shrink-0 text-slate-500">{entry.date}</span></div>)}</div></section>;
    case "languages":
      if (!data.languages.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><p>{data.languages.map((entry) => `${entry.name}${entry.proficiency ? ` (${entry.proficiency})` : ""}`).join(" • ")}</p></section>;
    case "awards":
      if (!data.awards.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="space-y-2">{data.awards.map((entry) => <article key={entry.id} className="resume-entry"><div className="flex justify-between gap-4"><h3 className="font-bold">{entry.title}</h3><span className="text-slate-500">{entry.date}</span></div><p className="text-slate-600">{entry.issuer}</p>{entry.description ? <p className="mt-1">{entry.description}</p> : null}</article>)}</div></section>;
    case "publications":
      if (!data.publications.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="space-y-2">{data.publications.map((entry) => <article key={entry.id} className="resume-entry"><div className="flex justify-between gap-4"><h3 className="font-bold">{entry.url ? <ContactLink href={safeExternalUrl(entry.url)}>{entry.title}</ContactLink> : entry.title}</h3><span className="text-slate-500">{entry.date}</span></div><p className="text-slate-600">{entry.publisher}</p>{entry.description ? <p className="mt-1">{entry.description}</p> : null}</article>)}</div></section>;
    case "volunteer":
      if (!data.volunteer.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="space-y-2">{data.volunteer.map((entry) => <article key={entry.id} className="resume-entry"><div className="flex justify-between gap-4"><h3 className="font-bold">{entry.role}{entry.organization ? ` — ${entry.organization}` : ""}</h3><span className="text-slate-500">{joinRange(entry.startDate, entry.endDate)}</span></div>{entry.description ? <p className="mt-1">{entry.description}</p> : null}{renderHighlights(entry.highlights)}</article>)}</div></section>;
    case "references":
      if (!data.references.length) return null;
      return <section className="resume-section"><SectionHeading title={section.title} resume={resume} /><div className="grid grid-cols-2 gap-3">{data.references.map((entry) => <article key={entry.id} className="resume-entry"><h3 className="font-bold">{entry.name}</h3><p className="text-slate-600">{entry.relationship}</p>{entry.email ? <p><ContactLink href={mailto(entry.email)}>{entry.email}</ContactLink></p> : null}{entry.phone ? <p><ContactLink href={tel(entry.phone)}>{entry.phone}</ContactLink></p> : null}</article>)}</div></section>;
    default: {
      if (!section.id.startsWith("custom-")) return null;
      const custom = data.customSections.find((item) => `custom-${item.id}` === section.id);
      if (!custom?.items.length) return null;
      return <section className="resume-section"><SectionHeading title={custom.title || section.title} resume={resume} /><div className="space-y-2.5">{custom.items.map((entry) => <article key={entry.id} className="resume-entry"><div className="flex justify-between gap-4"><h3 className="font-bold">{entry.heading}</h3><span className="text-slate-500">{entry.date}</span></div>{entry.subheading ? <p className="text-slate-600">{entry.subheading}</p> : null}{entry.description ? <p className="mt-1">{entry.description}</p> : null}{renderHighlights(entry.highlights)}</article>)}</div></section>;
    }
  }
}

export function ResumePreview({ resume, className, printRoot = true }: { resume: ResumeDocument; className?: string; printRoot?: boolean }) {
  const style = {
    "--resume-accent": resume.settings.accentColor,
    "--resume-font-size": `${resume.settings.fontSize}px`,
    "--resume-line-height": resume.settings.lineHeight,
    "--resume-margin": `${resume.settings.pageMargin}mm`,
    fontFamily: fontStacks[resume.settings.fontFamily],
  } as React.CSSProperties;

  return (
    <div data-print-root={printRoot ? "" : undefined} className={cn("resume-preview-root", className)}>
      <article
        className={cn(
          "resume-paper flex flex-col gap-4",
          resume.settings.showPageBreaks && "resume-page-breaks",
          resume.settings.templateId === "minimal" && "gap-3",
          resume.settings.templateId === "executive" && "gap-5",
          resume.settings.templateId === "modern" && "border-t-[5px] border-[var(--resume-accent)]",
          resume.settings.templateId === "professional" && "border-t-2 border-[var(--resume-accent)]",
        )}
        style={style}
        aria-label="Resume preview"
      >
        {resume.sections.filter((section) => section.visible).map((section) => <ResumeSectionContent key={section.id} section={section} resume={resume} />)}
      </article>
    </div>
  );
}
