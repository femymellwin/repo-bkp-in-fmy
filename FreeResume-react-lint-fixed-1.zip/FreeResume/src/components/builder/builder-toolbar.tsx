"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Cloud, Copy, FileJson, MoreHorizontal, Pencil, Printer, Redo2, RotateCcw, Trash2, Undo2, Upload } from "lucide-react";
import {
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  Input,
  Label,
  useToast,
} from "@/components/ui";
import { ConfirmationDialog } from "@/components/confirmation-dialog";
import { AutosaveIndicator } from "@/components/builder/autosave-indicator";
import { PdfDownloadButton } from "@/components/builder/pdf-download-button";
import type { SaveStatus } from "@/components/builder/use-resume-editor";
import { importResumeFromJson } from "@/lib/resume/storage";
import { syncResumeToCloud } from "@/lib/resume/cloud";
import type { ResumeDocument } from "@/lib/resume/schema";
import { createBrowserSupabaseClient } from "@/lib/supabase/client";
import { downloadJson } from "@/lib/utils";

export function BuilderToolbar({
  resume,
  saveStatus,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onRename,
  onDuplicate,
  onClear,
  onLoadSample,
  onReplace,
}: {
  resume: ResumeDocument;
  saveStatus: SaveStatus;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onRename: (name: string) => void;
  onDuplicate: () => ResumeDocument | null;
  onClear: () => void;
  onLoadSample: () => void;
  onReplace: (resume: ResumeDocument) => void;
}) {
  const [renameOpen, setRenameOpen] = React.useState(false);
  const [clearOpen, setClearOpen] = React.useState(false);
  const [sampleOpen, setSampleOpen] = React.useState(false);
  const [name, setName] = React.useState("");
  const [syncing, setSyncing] = React.useState(false);
  const fileRef = React.useRef<HTMLInputElement>(null);
  const router = useRouter();
  const { toast } = useToast();

  function openRenameDialog() {
    setName(resume.name);
    setRenameOpen(true);
  }

  function handleRenameOpenChange(open: boolean) {
    if (open) setName(resume.name);
    setRenameOpen(open);
  }

  function duplicate() {
    const copy = onDuplicate();
    if (copy) {
      toast({ title: "Resume duplicated", description: "The copy was saved on this device.", variant: "success" });
      router.push(`/builder/${copy.id}`);
      return;
    }
    toast({
      title: "Could not duplicate resume",
      description: "Browser storage may be full. Remove an old resume or a large profile photo and try again.",
      variant: "error",
    });
  }

  async function sync() {
    const client = createBrowserSupabaseClient();
    if (!client) {
      toast({ title: "Cloud sync is not configured", description: "Add the Supabase environment variables before using cloud features.", variant: "error" });
      return;
    }
    const { data } = await client.auth.getUser();
    if (!data.user) {
      router.push(`/login?next=${encodeURIComponent(`/builder/${resume.id}`)}`);
      return;
    }
    setSyncing(true);
    try {
      const hydrated = await syncResumeToCloud(client, data.user, resume);
      onReplace(hydrated);
      toast({ title: "Synced to cloud", description: "This resume is now available in your account.", variant: "success" });
    } catch (error) {
      toast({ title: "Cloud sync failed", description: error instanceof Error ? error.message : "Try again.", variant: "error" });
    } finally {
      setSyncing(false);
    }
  }

  async function importJson(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 5_000_000) {
      toast({ title: "Import failed", description: "Choose a FreeResume JSON file smaller than 5 MB.", variant: "error" });
      return;
    }
    try {
      const imported = importResumeFromJson(JSON.parse(await file.text()));
      onReplace({ ...imported, id: resume.id, createdAt: resume.createdAt, updatedAt: new Date().toISOString() });
      toast({ title: "Resume imported", description: "The imported data replaced the current resume.", variant: "success" });
    } catch {
      toast({ title: "Import failed", description: "Choose a valid FreeResume JSON export.", variant: "error" });
    }
  }

  return (
    <>
      <div className="flex min-h-16 flex-wrap items-center gap-2 border-b border-slate-200 bg-white px-3 py-2 sm:px-4">
        <button type="button" onClick={openRenameDialog} className="group min-w-0 max-w-64 rounded-md px-2 py-1 text-left hover:bg-slate-100" aria-label="Rename resume">
          <span className="flex items-center gap-2"><span className="truncate text-sm font-semibold text-slate-950">{resume.name}</span><Pencil className="size-3.5 shrink-0 text-slate-400 group-hover:text-slate-700" /></span>
          <AutosaveIndicator status={saveStatus} />
        </button>
        <div className="ml-auto flex items-center gap-1">
          <Button type="button" variant="ghost" size="icon-sm" onClick={onUndo} disabled={!canUndo} aria-label="Undo"><Undo2 className="size-4" /></Button>
          <Button type="button" variant="ghost" size="icon-sm" onClick={onRedo} disabled={!canRedo} aria-label="Redo"><Redo2 className="size-4" /></Button>
          <Button type="button" variant="outline" size="sm" onClick={() => void sync()} disabled={syncing}><Cloud className="size-4" />{syncing ? "Syncing" : "Sync"}</Button>
          <Button type="button" variant="outline" size="sm" onClick={() => window.print()} className="hidden sm:inline-flex"><Printer className="size-4" />Print</Button>
          <PdfDownloadButton resume={resume} className="hidden sm:inline-flex" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild><Button type="button" variant="ghost" size="icon" aria-label="More resume actions"><MoreHorizontal className="size-5" /></Button></DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onSelect={duplicate}><Copy className="size-4" />Duplicate resume</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => downloadJson(`${resume.name.replace(/\s+/g, "-").toLowerCase()}.json`, resume)}><FileJson className="size-4" />Export JSON</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => fileRef.current?.click()}><Upload className="size-4" />Import JSON</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setSampleOpen(true)}><RotateCcw className="size-4" />Load sample content</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => window.print()} className="sm:hidden"><Printer className="size-4" />Print</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => setClearOpen(true)} className="text-red-600 focus:text-red-700"><Trash2 className="size-4" />Clear resume</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <div className="sm:hidden"><PdfDownloadButton resume={resume} /></div>
        </div>
        <input ref={fileRef} type="file" accept="application/json,.json" onChange={(event) => void importJson(event)} className="sr-only" />
      </div>
      <Dialog open={renameOpen} onOpenChange={handleRenameOpenChange}>
        <DialogContent><DialogHeader><DialogTitle>Rename resume</DialogTitle><DialogDescription>This name is used in your dashboard and as the PDF filename.</DialogDescription></DialogHeader><div><Label htmlFor="resume-name">Resume name</Label><Input id="resume-name" value={name} onChange={(event) => setName(event.target.value)} maxLength={120} onKeyDown={(event) => { if (event.key === "Enter" && name.trim()) { onRename(name.trim()); setRenameOpen(false); } }} /></div><DialogFooter><Button variant="outline" onClick={() => setRenameOpen(false)}>Cancel</Button><Button onClick={() => { onRename(name.trim()); setRenameOpen(false); }} disabled={!name.trim()}>Save name</Button></DialogFooter></DialogContent>
      </Dialog>
      <ConfirmationDialog open={clearOpen} onOpenChange={setClearOpen} title="Clear all resume content?" description="This removes all entries and text from the current resume. You can undo immediately afterward." confirmLabel="Clear resume" destructive onConfirm={onClear} />
      <ConfirmationDialog open={sampleOpen} onOpenChange={setSampleOpen} title="Replace with sample content?" description="This replaces the current content with realistic sample data while keeping the resume ID and template. You can undo immediately afterward." confirmLabel="Load sample" onConfirm={onLoadSample} />
    </>
  );
}
