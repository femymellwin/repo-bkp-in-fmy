"use client";

import dynamic from "next/dynamic";
import { LoaderCircle } from "lucide-react";
import type { ResumeDocument } from "@/lib/resume/schema";
import { Button } from "@/components/ui";

const ClientPdfLink = dynamic(() => import("./pdf-link").then((module) => module.PdfLink), {
  ssr: false,
  loading: () => <Button disabled><LoaderCircle className="size-4 animate-spin motion-reduce:animate-none" />Loading PDF</Button>,
});

export function PdfDownloadButton({ resume, className }: { resume: ResumeDocument; className?: string }) {
  return <ClientPdfLink resume={resume} className={className} />;
}
