import { cn } from "@/lib/utils";
import type { ResumeTemplateDefinition } from "@/lib/resume/templates";

export function TemplateMiniPreview({ template }: { template: ResumeTemplateDefinition }) {
  return (
    <div className={cn("aspect-[210/297] w-full overflow-hidden rounded-md border border-slate-200 bg-white p-5 shadow-inner", template.id === "modern" && "border-t-4", template.id === "professional" && "border-t-2", template.id === "creative" && "pt-3")} style={{ borderTopColor: template.defaultAccent }} aria-hidden>
      <div className={cn("mb-3", template.id === "professional" && "text-center", template.id === "creative" && "rounded p-3 text-white")} style={template.id === "creative" ? { background: template.defaultAccent } : undefined}>
        <div className="h-3 w-2/3 rounded-sm" style={{ background: template.id === "creative" ? "rgba(255,255,255,.95)" : template.defaultAccent }} />
        <div className={cn("mt-1.5 h-1.5 w-1/2 rounded-sm bg-slate-300", template.id === "professional" && "mx-auto", template.id === "creative" && "bg-white/60")} />
      </div>
      <div className="mb-4 flex gap-1"><div className="h-1.5 w-1/5 rounded bg-slate-300" /><div className="h-1.5 w-1/4 rounded bg-slate-200" /><div className="h-1.5 w-1/5 rounded bg-slate-200" /></div>
      {[0, 1, 2].map((block) => <div key={block} className="mb-4"><div className="mb-2 h-1.5 w-1/3 rounded" style={{ background: template.defaultAccent }} /><div className="space-y-1.5"><div className="h-1.5 w-full rounded bg-slate-200" /><div className="h-1.5 w-11/12 rounded bg-slate-200" /><div className="h-1.5 w-4/5 rounded bg-slate-200" /></div></div>)}
    </div>
  );
}
