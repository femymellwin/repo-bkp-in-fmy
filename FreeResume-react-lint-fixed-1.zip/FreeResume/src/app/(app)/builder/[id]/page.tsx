import type { Metadata } from "next";
import { ResumeBuilder } from "@/components/builder/resume-builder";
import { templateIdSchema } from "@/lib/resume/schema";

export const metadata: Metadata = {
  title: "Resume builder",
  robots: { index: false, follow: false },
};

export default async function BuilderPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ template?: string }>;
}) {
  const { id } = await params;
  const query = await searchParams;
  const parsed = templateIdSchema.safeParse(query.template);
  return <ResumeBuilder routeId={id} initialTemplate={parsed.success ? parsed.data : "modern"} />;
}
