import { AppHeader } from "@/components/app-header";

export default function ApplicationLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-100">
      <AppHeader />
      {children}
    </div>
  );
}
