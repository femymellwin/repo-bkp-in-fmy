import type { Metadata } from "next";
import { CredentialsForm } from "@/components/auth-forms";
import { safeInternalPath } from "@/lib/utils";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const query = await searchParams;
  const nextPath = safeInternalPath(query.next);
  return <CredentialsForm mode="login" nextPath={nextPath} />;
}
