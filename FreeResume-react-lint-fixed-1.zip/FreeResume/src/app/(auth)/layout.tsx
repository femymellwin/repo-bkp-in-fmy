import Link from "next/link";
import { FileText } from "lucide-react";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="px-4 py-5 sm:px-6"><Link href="/" className="inline-flex items-center gap-2 font-semibold text-slate-950"><span className="flex size-9 items-center justify-center rounded-lg bg-teal-700 text-white"><FileText className="size-5" /></span>FreeResume</Link></header>
      <main className="mx-auto flex max-w-md flex-col px-4 pb-16 pt-8 sm:px-6">{children}</main>
    </div>
  );
}
