import type { Metadata } from "next";
import { ResetPasswordForm } from "@/components/auth-forms";

export const metadata: Metadata = { title: "Reset password", robots: { index: false } };
export default function ResetPasswordPage() { return <ResetPasswordForm />; }
