"use client";

import { Button } from "@/components/ui";

export default function ErrorBoundary({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="grid min-h-[70vh] place-items-center bg-slate-50 p-6" role="alert">
      <div className="max-w-md rounded-xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <p className="text-sm font-semibold text-red-700">Something went wrong</p>
        <h1 className="mt-2 text-2xl font-bold text-slate-950">The page could not be completed.</h1>
        <p className="mt-3 text-sm text-slate-600">Your locally saved resumes are not deleted. Try the action again.</p>
        {process.env.NODE_ENV === "development" ? <pre className="mt-4 overflow-auto rounded bg-slate-100 p-3 text-left text-xs">{error.message}</pre> : null}
        <Button onClick={reset} className="mt-6">Try again</Button>
      </div>
    </main>
  );
}
