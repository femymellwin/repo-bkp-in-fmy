import { NextResponse } from "next/server";
import type { SupabaseClient } from "@supabase/supabase-js";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import type { Database } from "@/lib/supabase/database.types";

async function removeUserAssets(admin: SupabaseClient<Database>, userId: string) {
  const bucket = admin.storage.from("resume-assets");

  async function listAll(prefix: string) {
    const items: Array<{ id: string | null; name: string }> = [];
    const pageSize = 100;
    for (let offset = 0; ; offset += pageSize) {
      const { data, error } = await bucket.list(prefix, { limit: pageSize, offset, sortBy: { column: "name", order: "asc" } });
      if (error) throw error;
      items.push(...(data || []));
      if (!data || data.length < pageSize) break;
    }
    return items;
  }

  const paths: string[] = [];
  const firstLevel = await listAll(userId);
  for (const item of firstLevel) {
    if (item.id) {
      paths.push(`${userId}/${item.name}`);
      continue;
    }
    const folder = `${userId}/${item.name}`;
    const children = await listAll(folder);
    for (const child of children) {
      if (child.id) paths.push(`${folder}/${child.name}`);
    }
  }

  for (let offset = 0; offset < paths.length; offset += 100) {
    const { error: removeError } = await bucket.remove(paths.slice(offset, offset + 100));
    if (removeError) throw removeError;
  }
}

export async function DELETE() {
  const supabase = await createServerSupabaseClient();
  const admin = createAdminSupabaseClient();
  if (!supabase || !admin) {
    return NextResponse.json({ error: "Account deletion is not configured." }, { status: 503 });
  }

  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) {
    return NextResponse.json({ error: "Authentication required." }, { status: 401 });
  }

  try {
    await removeUserAssets(admin, data.user.id);
    const { error: deleteError } = await admin.auth.admin.deleteUser(data.user.id);
    if (deleteError) throw deleteError;
    return NextResponse.json({ deleted: true });
  } catch (deleteError) {
    console.error("Account deletion failed", deleteError);
    return NextResponse.json({ error: "Account data could not be fully deleted. Please try again." }, { status: 500 });
  }
}
