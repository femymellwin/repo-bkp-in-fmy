import { NextResponse, type NextRequest } from "next/server";
import { feedbackSchema } from "@/lib/resume/schema";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { consumeAiQuota, hashRateLimitSubject } from "@/lib/ai/rate-limit";

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    const raw = await request.text();
    if (raw.length > 10_000) return NextResponse.json({ error: "Request is too large." }, { status: 413 });
    body = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const parsed = feedbackSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Check the form fields and try again." }, { status: 400 });
  if (parsed.data.website) return NextResponse.json({ accepted: true });
  const admin = createAdminSupabaseClient();
  if (!admin) return NextResponse.json({ error: "Feedback storage is not configured. Use the support email instead." }, { status: 503 });
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "anonymous";
  try {
    const quota = await consumeAiQuota(hashRateLimitSubject(`feedback:${ip}`), 10);
    if (!quota.allowed) return NextResponse.json({ error: "Too many messages today. Please use email." }, { status: 429 });
    const supabase = await createServerSupabaseClient();
    const { data: auth } = supabase ? await supabase.auth.getUser() : { data: { user: null } };
    const { error } = await admin.from("feedback").insert({ user_id: auth.user?.id ?? null, email: parsed.data.email, category: parsed.data.category, message: parsed.data.message });
    if (error) throw error;
    return NextResponse.json({ accepted: true });
  } catch (error) { console.error("Feedback submission failed", error); return NextResponse.json({ error: "Feedback could not be saved." }, { status: 500 }); }
}
