import { NextResponse, type NextRequest } from "next/server";
import { aiRequestSchema } from "@/lib/resume/schema";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { consumeAiQuota, hashRateLimitSubject } from "@/lib/ai/rate-limit";
import { generateAiText } from "@/lib/ai/provider";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  if (process.env.AI_ENABLED !== "true") {
    return NextResponse.json({ error: "AI writing is disabled." }, { status: 404 });
  }

  let body: unknown;
  try {
    const raw = await request.text();
    if (raw.length > 40_000) return NextResponse.json({ error: "Request is too large." }, { status: 413 });
    body = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const parsed = aiRequestSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid AI request.", details: parsed.error.flatten() }, { status: 400 });

  const supabase = await createServerSupabaseClient();
  const { data: userData } = supabase ? await supabase.auth.getUser() : { data: { user: null } };
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const subject = userData.user?.id || forwarded || request.headers.get("x-real-ip") || "anonymous";
  const configuredLimit = Number(process.env.AI_DAILY_FREE_LIMIT || 5);
  const dailyLimit = Number.isFinite(configuredLimit)
    ? Math.max(1, Math.min(100, Math.floor(configuredLimit)))
    : 5;

  try {
    const subjectHash = hashRateLimitSubject(subject);
    const quota = await consumeAiQuota(subjectHash, dailyLimit);
    if (!quota.allowed) return NextResponse.json({ error: "Daily free AI limit reached.", remaining: 0 }, { status: 429 });
    const text = await generateAiText(parsed.data);
    return NextResponse.json({ text, remaining: quota.remaining });
  } catch (error) {
    console.error("AI writing failed", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "AI writing failed." }, { status: 500 });
  }
}
