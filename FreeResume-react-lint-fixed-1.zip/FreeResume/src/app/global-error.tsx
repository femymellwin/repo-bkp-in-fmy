"use client";

import { Button } from "@/components/ui";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en">
      <body className="grid min-h-screen place-items-center bg-slate-50 p-6">
        <main className="max-w-md rounded-xl border border-slate-200 bg-white p-8 text-center shadow-sm" role="alert">
          <p className="text-sm font-semibold text-red-700">Application error</p>
          <h1 className="mt-2 text-2xl font-bold text-slate-950">FreeResume could not load.</h1>
          <p className="mt-3 text-sm text-slate-600">Resume data stored in your browser is not removed by this error.</p>
          {process.env.NODE_ENV === "development" ? <pre className="mt-4 overflow-auto rounded bg-slate-100 p-3 text-left text-xs">{error.message}</pre> : null}
          <Button onClick={reset} className="mt-6">Reload application</Button>
        </main>
      </body>
    </html>
  );
}
