import type { Metadata, Viewport } from "next";
import { Inter, Merriweather, Source_Sans_3 } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";
import { appConfig } from "@/lib/config";

const inter = Inter({ subsets: ["latin"], display: "swap", variable: "--font-inter" });
const sourceSans = Source_Sans_3({ subsets: ["latin"], display: "swap", variable: "--font-source-sans" });
const merriweather = Merriweather({ subsets: ["latin"], weight: ["400", "700"], display: "swap", variable: "--font-merriweather" });

export const metadata: Metadata = {
  metadataBase: new URL(appConfig.url),
  title: {
    default: "FreeResume — Free ATS-friendly resume builder",
    template: "%s | FreeResume",
  },
  description: appConfig.description,
  applicationName: appConfig.name,
  authors: [{ name: "FreeResume" }],
  creator: "FreeResume",
  category: "productivity",
  openGraph: {
    type: "website",
    url: "/",
    siteName: appConfig.name,
    title: "FreeResume — Free ATS-friendly resume builder",
    description: appConfig.description,
  },
  twitter: {
    card: "summary",
    title: "FreeResume — Free ATS-friendly resume builder",
    description: appConfig.description,
  },
  icons: { icon: "/favicon.svg" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0f766e",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${sourceSans.variable} ${merriweather.variable}`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
