import type { Metadata } from "next";
import { Mail } from "lucide-react";
import { ContactForm } from "@/components/contact-form";
import { appConfig } from "@/lib/config";

export const metadata: Metadata = { title: "Contact and feedback", description: "Contact the FreeResume team, report a bug, or request a feature." , alternates: { canonical: "/contact" } };
export default function ContactPage() { return <main className="bg-slate-50"><div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[.8fr_1.2fr] lg:px-8"><div><p className="text-sm font-semibold text-teal-700">Contact and feedback</p><h1 className="mt-2 text-4xl font-bold tracking-tight text-slate-950">Help make FreeResume better.</h1><p className="mt-4 text-lg leading-8 text-slate-600">Report an issue, request a feature, or ask a privacy question. Do not include sensitive resume content in this form.</p><div className="mt-8 flex items-start gap-3 rounded-lg border border-slate-200 bg-white p-4"><Mail className="mt-0.5 size-5 text-teal-700" /><div><p className="font-medium text-slate-950">Email</p><a href={`mailto:${appConfig.supportEmail}`} className="text-sm text-teal-700 hover:underline">{appConfig.supportEmail}</a></div></div></div><ContactForm /></div></main>; }
