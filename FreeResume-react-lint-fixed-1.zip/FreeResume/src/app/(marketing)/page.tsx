import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Check, Cloud, Download, EyeOff, FileCheck2, ShieldCheck, Sparkles, UserRoundX } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger, Badge, Button, Card, CardContent } from "@/components/ui";
import { TemplateMiniPreview } from "@/components/template-mini-preview";
import { appConfig } from "@/lib/config";
import { resumeTemplates } from "@/lib/resume/templates";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
};

const benefits = [
  { icon: UserRoundX, title: "No account required", text: "Start editing immediately. Guest resumes autosave in this browser." },
  { icon: Download, title: "Free PDF download", text: "Export searchable, selectable A4 PDFs without a watermark." },
  { icon: FileCheck2, title: "ATS-conscious layouts", text: "Four single-column templates prioritize readable text hierarchy and standard sections." },
  { icon: ShieldCheck, title: "Private by default", text: "Resumes are never public by default. Cloud sync is optional and protected by row-level policies." },
  { icon: EyeOff, title: "No hidden checkout", text: "Core creation, local saving, printing, and PDF export contain no payment gate." },
  { icon: Cloud, title: "Optional cloud sync", text: "Create an account only when you need resumes across devices." },
];

const faqs = [
  ["Is FreeResume really free?", "Yes. The core builder, local autosave, templates, printing, and PDF download are implemented without a payment gate or watermark."],
  ["Do I need to create an account?", "No. Guest mode stores resumes locally in your browser. An account is needed only for optional private cloud sync."],
  ["Are the PDFs ATS-friendly?", "The PDF uses real text rather than an image. Four templates use a straightforward single-column structure, but every employer's parsing software differs, so always review the extracted text before applying."],
  ["Where is my resume stored?", "Guest resumes remain in this browser's local storage. When you explicitly sync, the resume is stored in your Supabase project under your authenticated user ID."],
  ["Does the download include branding?", "No. The PDF document contains only the resume content you provide."],
  ["Can I use AI writing tools?", "The optional AI module is disabled by default. A deployment owner can enable server-side, rate-limited writing assistance after configuring a provider."],
];

export default function HomePage() {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: appConfig.name,
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    description: appConfig.description,
    offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
  };
  const structuredDataJson = JSON.stringify(structuredData).replace(/</g, "\\u003c");
  return (
    <main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: structuredDataJson }} />
      <section className="overflow-hidden bg-white">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 sm:py-24 lg:grid-cols-[1.05fr_.95fr] lg:px-8 lg:py-28">
          <div>
            <Badge variant="success"><Check className="mr-1 size-3" />Free PDF • No watermark</Badge>
            <h1 className="mt-6 max-w-3xl text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl lg:text-6xl">Create a professional resume without the paywall.</h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">Build an ATS-conscious resume, customize the design, save it on your device, and download a text-based PDF. No account, watermark, or surprise checkout.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row"><Button asChild size="lg"><Link href="/builder/new">Build my resume <ArrowRight className="size-4" /></Link></Button><Button asChild size="lg" variant="outline"><Link href="/templates">Browse templates</Link></Button></div>
            <ul className="mt-7 flex flex-wrap gap-x-5 gap-y-2 text-sm text-slate-600">{["No registration", "Local autosave", "Selectable PDF text", "Private cloud option"].map((item) => <li key={item} className="flex items-center gap-1.5"><Check className="size-4 text-teal-700" />{item}</li>)}</ul>
          </div>
          <div className="relative mx-auto w-full max-w-xl"><div className="absolute -inset-6 -z-10 rounded-[2rem] bg-teal-50" /><div className="grid grid-cols-2 gap-4"><div className="translate-y-7"><TemplateMiniPreview template={resumeTemplates[0]} /></div><TemplateMiniPreview template={resumeTemplates[2]} /></div><div className="absolute -bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-800 shadow-lg"><Sparkles className="size-4 text-teal-700" />Switch templates without losing data</div></div>
        </div>
      </section>

      <section className="border-y border-slate-200 bg-slate-50 py-16 sm:py-20"><div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"><div className="mx-auto max-w-2xl text-center"><p className="text-sm font-semibold text-teal-700">How it works</p><h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-950">A finished resume in three steps</h2></div><div className="mt-10 grid gap-5 md:grid-cols-3">{[["1", "Add your information", "Use structured sections for experience, education, skills, projects, and custom content."], ["2", "Choose your presentation", "Switch templates, typography, spacing, margins, headings, and accent color in real time."], ["3", "Download and apply", "Export a selectable-text A4 PDF, print it, or keep editing later on the same device."]].map(([number, title, text]) => <Card key={number}><CardContent className="p-6"><span className="grid size-9 place-items-center rounded-full bg-teal-100 text-sm font-bold text-teal-800">{number}</span><h3 className="mt-5 text-lg font-semibold text-slate-950">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{text}</p></CardContent></Card>)}</div></div></section>

      <section className="bg-white py-16 sm:py-24"><div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"><div className="max-w-2xl"><p className="text-sm font-semibold text-teal-700">Built for trust</p><h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-950">The essential features stay accessible.</h2><p className="mt-4 text-slate-600">FreeResume is deliberately simpler than a design suite and more transparent than subscription-first resume sites.</p></div><div className="mt-10 grid gap-x-8 gap-y-9 sm:grid-cols-2 lg:grid-cols-3">{benefits.map(({ icon: Icon, title, text }) => <div key={title} className="flex gap-4"><span className="grid size-11 shrink-0 place-items-center rounded-lg bg-teal-50 text-teal-700"><Icon className="size-5" /></span><div><h3 className="font-semibold text-slate-950">{title}</h3><p className="mt-1 text-sm leading-6 text-slate-600">{text}</p></div></div>)}</div></div></section>

      <section className="border-y border-slate-200 bg-slate-50 py-16 sm:py-20"><div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"><div className="flex items-end justify-between gap-6"><div><p className="text-sm font-semibold text-teal-700">Professional templates</p><h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-950">Start with structure, then make it yours.</h2></div><Button asChild variant="outline" className="hidden sm:inline-flex"><Link href="/templates">View all templates</Link></Button></div><div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{resumeTemplates.slice(0, 3).map((template) => <Card key={template.id} className="overflow-hidden"><div className="bg-slate-100 p-5"><TemplateMiniPreview template={template} /></div><CardContent className="flex items-center justify-between p-5"><div><h3 className="font-semibold text-slate-950">{template.name}</h3><p className="mt-1 text-xs text-slate-500">{template.atsFriendly ? "Single-column ATS layout" : "Enhanced visual layout"}</p></div><Button asChild size="sm"><Link href={`/builder/new?template=${template.id}`}>Use</Link></Button></CardContent></Card>)}</div></div></section>

      <section className="bg-white py-16 sm:py-20"><div className="mx-auto max-w-4xl px-4 sm:px-6"><div className="rounded-2xl border border-slate-200 bg-slate-50 p-8 text-center"><p className="text-sm font-semibold text-teal-700">Testimonials</p><h2 className="mt-2 text-2xl font-bold text-slate-950">Verified customer quotes will appear here.</h2><p className="mx-auto mt-3 max-w-2xl text-sm leading-6 text-slate-600">FreeResume does not publish invented endorsements. This production component is ready for verified, permissioned testimonials once real users provide them.</p></div></div></section>

      <section className="border-t border-slate-200 bg-slate-50 py-16 sm:py-20"><div className="mx-auto max-w-3xl px-4 sm:px-6"><div className="text-center"><p className="text-sm font-semibold text-teal-700">Frequently asked questions</p><h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-950">Clear answers before you begin</h2></div><Accordion type="single" collapsible className="mt-8 rounded-xl border border-slate-200 bg-white px-5">{faqs.map(([question, answer], index) => <AccordionItem key={question} value={`faq-${index}`}><AccordionTrigger>{question}</AccordionTrigger><AccordionContent>{answer}</AccordionContent></AccordionItem>)}</Accordion></div></section>

      <section className="bg-teal-800 py-16 text-white"><div className="mx-auto max-w-4xl px-4 text-center sm:px-6"><h2 className="text-3xl font-bold tracking-tight">Build the resume. Keep the PDF. Pay nothing.</h2><p className="mx-auto mt-4 max-w-2xl text-teal-100">Start as a guest and create a professional document without handing over your email or payment details.</p><Button asChild size="lg" className="mt-7 bg-white text-teal-900 hover:bg-teal-50"><Link href="/builder/new">Create my free resume <ArrowRight className="size-4" /></Link></Button></div></section>
    </main>
  );
}
