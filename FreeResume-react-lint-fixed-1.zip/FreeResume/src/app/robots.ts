import type { MetadataRoute } from "next";
import { appConfig } from "@/lib/config";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/builder/", "/api/"] }],
    sitemap: `${appConfig.url}/sitemap.xml`,
  };
}
