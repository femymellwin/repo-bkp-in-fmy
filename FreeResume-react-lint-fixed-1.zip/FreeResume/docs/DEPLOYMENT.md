# Deployment

## Pre-deployment gate

1. Create and review production Supabase resources.
2. Apply all migrations and run the database smoke test.
3. Configure email and OAuth redirect URLs for the exact production origin.
4. Set a real support email and identify the legal operator.
5. Keep AI disabled unless provider terms, privacy disclosures, quota secret, and monitoring are ready.
6. Run `npm run check`.
7. Complete the critical manual flows in `docs/TESTING.md` on a preview deployment.

## Vercel

1. Import the repository into Vercel.
2. Use the default Next.js framework preset.
3. Set production and preview environment variables. Public variables are embedded at build time, so they must be present before the build.
4. Set `NEXT_PUBLIC_APP_URL` to the canonical production origin in the production environment.
5. Deploy.
6. Add the deployed `/auth/callback` URL to Supabase Auth.
7. Repeat OAuth, PDF, cloud sync, feedback, and account deletion tests on the deployed origin.

Preview domains need explicit Supabase redirect entries when authentication must work on previews. Prefer a controlled preview hostname rather than an unrestricted wildcard.

## Docker

The multi-stage image builds Next.js standalone output and runs as a non-root user.

### Build

Public values needed during compilation are build arguments:

```bash
docker build \
  --build-arg NEXT_PUBLIC_APP_URL=https://resume.example.com \
  --build-arg NEXT_PUBLIC_APP_NAME=FreeResume \
  --build-arg NEXT_PUBLIC_SUPPORT_EMAIL=support@example.com \
  --build-arg NEXT_PUBLIC_SUPABASE_URL="$NEXT_PUBLIC_SUPABASE_URL" \
  --build-arg NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY="$NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY" \
  --build-arg NEXT_PUBLIC_AI_ENABLED=false \
  -t freeresume:latest .
```

### Run

Pass server-only values at runtime:

```bash
docker run --rm -p 3000:3000 \
  -e SUPABASE_SERVICE_ROLE_KEY="$SUPABASE_SERVICE_ROLE_KEY" \
  -e AI_ENABLED=false \
  -e AI_RATE_LIMIT_SECRET="$AI_RATE_LIMIT_SECRET" \
  -e OPENAI_API_KEY="$OPENAI_API_KEY" \
  -e OPENAI_MODEL="$OPENAI_MODEL" \
  freeresume:latest
```

When AI is disabled, provider variables may be omitted. Feedback/account deletion still require the service-role key.

## Generic Node.js platform

```bash
npm install
npm run build
npm run start
```

The platform must support Node.js 20.9 or newer, persistent environment configuration, outbound HTTPS to Supabase and the optional AI provider, and enough memory for Next.js and client-side bundle generation.

## Supabase production migration

```bash
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Then run the smoke test using a direct PostgreSQL connection string. Keep the service-role key out of CI logs and browser-visible configuration.

## Secrets and rotation

- Rotate the service-role key immediately if exposed; it bypasses RLS.
- Rotate the AI key according to provider policy.
- Rotate `AI_RATE_LIMIT_SECRET` only with awareness that existing daily hashes will no longer match; this is generally harmless but resets that day's effective counters.
- Store secrets in the hosting platform's encrypted secret manager.

## Observability

At minimum monitor:

- HTTP 5xx rates for `/api/account`, `/api/feedback`, and `/api/ai/write`;
- Supabase auth failures and database/storage errors;
- account deletion failures requiring operator follow-up;
- AI provider latency, errors, and spend;
- local-save failure reports and PDF-generation errors.

Do not log resume content, job descriptions, access tokens, service-role keys, or full provider responses.

## Backups and retention

Configure Supabase backups appropriate to the operating plan. Document how long backups, feedback, quota rows, and operational logs are retained. Account-deletion disclosures should accurately describe backup expiry.

A periodic maintenance task should remove old `ai_usage` rows and feedback records according to the published policy.

## Rollback

Application rollback is a normal redeploy of the previous image/build. Database rollback should use a forward migration whenever possible. Never drop user data automatically during an application rollback. Before a destructive schema migration, take a verified backup and rehearse restoration in a non-production project.
