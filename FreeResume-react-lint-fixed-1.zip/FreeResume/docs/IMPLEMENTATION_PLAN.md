# Implementation Plan and Acceptance Criteria

The repository was organized in the requested dependency order so later capabilities do not compromise the free guest flow.

## Phase 1 — Foundation and design system

**Delivered**

- Next.js App Router, TypeScript strict mode, Tailwind CSS, reusable shadcn-style components.
- Global metadata, navigation, footer, notifications, dialogs, responsive layout, accessibility baseline, security headers, and error boundaries.
- One canonical Zod resume schema and realistic sample data.

**Acceptance criteria**

- Every route has a stable layout and meaningful metadata.
- Form controls have labels and visible focus styles.
- The application can run with no Supabase or AI environment values.

## Phase 2 — Complete non-AI guest builder

**Delivered**

- All required built-in and custom sections.
- Live two-panel desktop builder and mobile edit/preview switch.
- Section and entry CRUD, hide/show, rename, pointer/keyboard reorder, and entry move buttons.
- Typography, size, line spacing, margin, heading, color, template, photo, and page-guide settings.
- Undo/redo, autosave, duplicate, rename, clear, sample content, JSON import/export, print.
- Five templates sharing one data model.
- Searchable/selectable A4 PDF with links and multipage wrapping.

**Acceptance criteria**

- No account is requested before creation or PDF download.
- A refresh restores the local resume.
- Switching any template preserves every field.
- Exported PDF text can be selected and copied.
- No watermark or FreeResume branding appears inside the resume document.

## Phase 3 — Dashboard and cloud synchronization

**Delivered**

- Local/cloud/synced dashboard cards, search, sorting, create/open/duplicate/rename/delete, loading and empty states.
- Supabase SSR clients, proxy-based session refresh, email/password, Google OAuth callback, verification and password recovery flows.
- Private PostgreSQL resume rows and private profile-photo objects.
- Explicit sync rather than automatic account coercion.
- Individual cloud deletion and complete account deletion.

**Acceptance criteria**

- Guest records remain usable while signed out.
- A signed-in user cannot select, modify, delete, or sign URLs for another user's data.
- A cloud-only resume is copied locally before the builder opens it.
- Account deletion removes Storage assets and cascades database records.

## Phase 4 — Optional AI module

**Delivered**

- Provider-neutral prompt builder and server-only OpenAI Responses API adapter.
- Summary, bullet, action-verb, grammar, achievement, skill, job comparison, and cover-letter actions.
- Public UI flag plus independent private API flag.
- Bounded inputs, validation, truthfulness instructions, hashed subjects, atomic daily quota, and client remaining-count display.

**Acceptance criteria**

- AI UI is absent by default.
- The provider key never appears in browser JavaScript or network requests.
- The configured limit permits exactly N successful quota reservations per subject/day and rejects request N+1.
- Generated content is never written into the resume without an explicit user action.

## Phase 5 — Hardening and delivery

**Delivered**

- Unit tests, database smoke test, CI, Docker standalone build, setup/testing/deployment/database documentation.
- Same-origin auth redirect validation, request-size limits, photo replacement cleanup, RLS, restricted grants, privacy disclosures, and legal-review notices.

**Launch gate**

A production owner should not launch until all of the following pass on the deployment origin:

1. `npm run check`.
2. Database smoke test.
3. Manual guest build/download/refresh flow.
4. Cross-account RLS tests using two real test users.
5. PDF text extraction and link testing in at least two PDF readers.
6. Mobile keyboard and screen-reader smoke tests.
7. Auth verification, OAuth, recovery, sign-out, and account deletion.
8. Support identity, privacy policy, terms, retention, and provider agreements reviewed for the operating jurisdiction.
