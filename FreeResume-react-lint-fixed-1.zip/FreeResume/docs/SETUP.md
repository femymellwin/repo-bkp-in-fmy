# Local and Hosted Setup

## 1. Install prerequisites

Use Node.js 20.9 or newer. Node.js 22 matches CI and Docker.

Install the Supabase CLI when local auth/database/storage development is needed. PostgreSQL's `psql` client is optional but required for the included database smoke test.

## 2. Install JavaScript dependencies

```bash
npm install
```

The delivered environment could not access the npm registry, so no generated lockfile is included. After the first successful install, commit `package-lock.json` and change CI/Docker installs to `npm ci` for reproducible builds.

## 3. Configure environment values

```bash
cp .env.example .env.local
```

Guest mode requires no additional values. Keep the public URL as `http://localhost:3000` during local development.

## 4. Run guest mode

```bash
npm run dev
```

Verify:

- `/builder/new` redirects to a generated resume ID;
- editing changes the live preview;
- refreshing restores the document;
- PDF download does not ask for an account.

## 5. Start local Supabase

```bash
supabase start
supabase db reset
```

Use the CLI output to populate:

```dotenv
NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=<local anon/publishable key>
SUPABASE_SERVICE_ROLE_KEY=<local service-role key>
```

Restart the Next.js development server after changing environment variables.

## 6. Configure a hosted Supabase project

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

In Supabase Auth URL configuration:

- set the production Site URL to the exact application origin;
- add `<origin>/auth/callback` for local, preview, and production origins;
- do not add wildcard domains unless the risk is understood and controlled.

### Email verification

Enable email confirmations. Customize verification and recovery templates as needed. Both flows return through `/auth/callback`; the application exchanges the code and accepts only a same-origin relative `next` path.

### Google OAuth

1. Create a Google OAuth client for the application.
2. Add the Supabase provider callback URL shown in the Supabase dashboard to Google.
3. Add the Google client ID/secret to Supabase Auth Providers.
4. Ensure the application `/auth/callback` URL is allowed by Supabase.

## 7. Configure feedback

The contact API requires Supabase and `SUPABASE_SERVICE_ROLE_KEY`. Set a real `NEXT_PUBLIC_SUPPORT_EMAIL`; the page presents email as a fallback when database storage is unavailable.

Set a unique production salt:

```bash
openssl rand -hex 32
```

Place the result in `AI_RATE_LIMIT_SECRET`. The same salted quota infrastructure protects feedback and optional AI requests.

## 8. Enable AI intentionally

Keep AI disabled until provider/privacy configuration is complete.

```dotenv
NEXT_PUBLIC_AI_ENABLED=true
AI_ENABLED=true
AI_DAILY_FREE_LIMIT=5
AI_RATE_LIMIT_SECRET=<at-least-32-random-characters>
OPENAI_API_KEY=<server-only-key>
OPENAI_MODEL=<explicit-model-id>
```

Both flags are required: the public flag shows the UI; the private flag enables the route. Never place `OPENAI_API_KEY` in a public environment variable.

## 9. Validate the setup

```bash
npm run check
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/schema_smoke.sql
```

Then complete the manual matrix in `docs/TESTING.md`.
