# Database and Row Level Security

## Migration

The initial migration is:

```text
supabase/migrations/202607200001_initial.sql
```

Apply it with `supabase db reset` locally or `supabase db push` against a linked hosted project.

## Tables

### `public.profiles`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid` | PK and FK to `auth.users(id)`, cascade delete |
| `display_name` | `text` | Optional, maximum 160 characters |
| `created_at` | `timestamptz` | Defaults to `now()` |
| `updated_at` | `timestamptz` | Updated by trigger |

An auth trigger creates a profile row after a new user is inserted.

### `public.resumes`

| Column | Type | Notes |
|---|---|---|
| `id` | `text` | Client-generated UUID-prefixed identifier, PK |
| `user_id` | `uuid` | FK to `auth.users`, cascade delete |
| `name` | `text` | 1–120 characters |
| `template_id` | `text` | Checked against five built-in templates |
| `data` | `jsonb` | Structured resume content |
| `settings` | `jsonb` | Typography, spacing, color, template, photo/page-guide flags |
| `sections` | `jsonb` | Ordered section configuration array |
| `version` | `integer` | Data format version |
| `created_at` | `timestamptz` | Original creation time |
| `updated_at` | `timestamptz` | Indexed per owner and refreshed by trigger |

The application validates each JSONB field with Zod before it is used. PostgreSQL constraints also require the expected top-level JSON types.

### `public.feedback`

Server-only contact submissions. Browser roles have all privileges revoked. The service-role API route inserts email, category, message, optional authenticated user ID, and timestamp.

### `public.ai_usage`

Stores only a 64-character salted SHA-256 subject hash, date, request count, and update time. It does not store a raw IP address. The same mechanism rate-limits feedback using a separately prefixed subject.

## Atomic quota function

`public.consume_ai_quota(subject_hash, daily_limit)` performs an insert-or-increment in one statement. The conflict update is permitted only while the current count is below the limit. When the limit has already been reached, `RETURNING` produces no row and the function returns `(false, 0)` without incrementing.

Execution is revoked from public browser roles and granted to `service_role` only.

## RLS policies

### Profiles

- Authenticated users can select only `id = auth.uid()`.
- Authenticated users can update only `id = auth.uid()`.

### Resumes

- Select/delete require `user_id = auth.uid()`.
- Insert requires the new `user_id = auth.uid()`.
- Update requires both the existing and resulting `user_id = auth.uid()`.

### Feedback and AI usage

RLS is enabled, but browser table privileges are revoked and no browser policies are created. Only the server-side service role accesses these tables.

## Storage

The private `resume-assets` bucket enforces:

- maximum object size: 2 MiB;
- allowed MIME types: JPEG, PNG, and WebP;
- no public access;
- select/insert/update/delete only when the first path segment equals the authenticated user ID.

Object paths use:

```text
<user-id>/<resume-id>/profile.<extension>
```

## Smoke test

After applying migrations:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/schema_smoke.sql
```

The test runs in a transaction and rolls back. It verifies that RLS is enabled on all sensitive public tables and that a two-action quota allows exactly two requests and rejects the third.

## Production operations

- Schedule deletion of old `ai_usage` rows, for example records older than 90 days.
- Monitor failed account-deletion logs and retry Storage cleanup before closing a privacy request.
- Generate TypeScript database types from the deployed project after schema changes and compare them with `src/lib/supabase/database.types.ts`.
- Add every schema change as a new migration; do not edit an already-applied production migration.
