# Testing

## Automated application checks

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Or run all checks in sequence:

```bash
npm run check
```

### Included Vitest coverage

- Complete blank/sample document validation.
- Invalid template and malformed document rejection.
- Local create/update/delete behavior and corrupt-storage fail-closed behavior.
- Safe external URL, email, phone, and same-origin redirect normalization.
- Array move behavior.
- AI prompt selection and anti-fabrication instructions.

Add component interaction tests for business-specific customizations before launch.

## Database smoke test

Apply the migration first, then run:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/schema_smoke.sql
```

The transaction verifies RLS flags and exact quota enforcement, then rolls back.

## Two-user RLS test

Use two non-production test accounts, A and B.

1. Sign in as A and sync a resume with a photo.
2. Record A's resume ID and Storage object path.
3. Sign in as B in a separate browser profile.
4. Confirm B cannot select/update/delete A's row through the Supabase client.
5. Confirm B cannot create a signed URL, overwrite, or delete A's Storage path.
6. Confirm A can still read and update its own objects.

Do not test RLS only with the service-role key; service role bypasses policies.

## Manual product matrix

### Guest and persistence

- Create a resume without signing in.
- Fill every built-in section and at least two custom sections.
- Refresh, close/reopen the tab, and reopen from the dashboard.
- Verify autosave failure is visible when browser storage is intentionally blocked.
- Export JSON, clear content, import JSON, and compare all fields.
- Duplicate and rename; confirm IDs and creation timestamps differ appropriately.

### Editing and accessibility

- Reorder sections by pointer drag.
- Reorder with the dnd-kit keyboard interaction.
- Reorder with explicit up/down buttons.
- Navigate all controls using Tab/Shift+Tab and activate them using keyboard controls.
- Confirm dialogs announce title/description and return focus correctly.
- Use a screen reader to verify labels, headings, status messages, and mobile mode controls.
- Enable reduced motion at OS level and verify nonessential animation is suppressed.

### Templates and styling

- Switch through all five templates after populating every section.
- Confirm no content disappears or mutates.
- Exercise min/max font size, line spacing, and margins.
- Enter valid and invalid hex colors.
- Toggle photos and page-break guides.

### PDF and printing

- Produce a one-page and a three-page resume.
- Select/copy PDF text into a plain-text editor.
- Search the PDF for the candidate name and an experience bullet.
- Open email, phone, website, LinkedIn, portfolio, project, publication, and certification links.
- Verify no content is clipped at page boundaries.
- Verify no watermark or product branding appears in the document body.
- Print to A4 and inspect browser print preview.

### Authentication and cloud

- Register with email confirmation enabled.
- Sign in/out and confirm local data survives.
- Complete Google authentication.
- Complete password recovery and update.
- Sync a local resume and open it in a second browser/device.
- Replace and remove a profile photo, then confirm obsolete Storage objects are deleted.
- Delete a cloud resume and confirm it disappears after refresh.
- Delete an account and confirm auth, database, and Storage data are gone while local-only data remains.

### AI, when enabled

- Verify the tab is absent when either intended deployment flag is off.
- Exercise all eight actions.
- Confirm requests are server-bound and the provider key is absent from browser assets/network headers.
- Confirm action N is allowed and action N+1 receives HTTP 429.
- Force a provider error and verify no invented/partial result is applied automatically.

### Responsive and browser coverage

Test current stable versions of Chromium, Firefox, and Safari, plus iOS Safari and Android Chrome. At minimum cover 320 px, 768 px, 1024 px, and wide desktop layouts.

## Performance checks

- Run Lighthouse on `/`, `/templates`, `/dashboard`, and a populated builder route.
- Confirm React-pdf loads only when download UI is requested.
- Profile typing in long resumes; the editor should not trigger network requests.
- Test with 100 entries in a repeatable section, the schema maximum, to identify deployment-specific limits.
