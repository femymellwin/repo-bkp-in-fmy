# Architecture

## System context

FreeResume is a Next.js App Router application with three deliberately separated operating modes:

1. **Guest/local mode** — all core resume creation and PDF functions run in the browser and persist to `localStorage`.
2. **Authenticated cloud mode** — a user explicitly synchronizes a local resume to Supabase PostgreSQL and private Storage.
3. **Optional AI mode** — selected text is sent to a server route only when both AI feature flags are enabled.

Guest mode is not a degraded trial. It is the primary product flow and contains no registration or payment gate.

## Data model invariant

`src/lib/resume/schema.ts` defines `ResumeDocument` and all nested Zod schemas. Every boundary uses the same model:

```text
Editor form
  -> ResumeDocument state
  -> localStorage validation
  -> live HTML preview
  -> React-pdf document
  -> JSON import/export
  -> Supabase JSONB record
```

Templates never own content. They read `ResumeDocument.data`, `sections`, and `settings`, so template switching changes presentation only.

## Client-side modules

### `use-resume-editor.ts`

Owns the active document, a bounded 100-state undo/redo history, timestamped commits, 500 ms debounced local autosave, duplication, clearing, and sample loading.

### `section-list.tsx`

Owns section order/visibility/title controls. dnd-kit provides pointer and keyboard drag sensors; explicit up/down buttons ensure a non-drag keyboard alternative. Custom section creation updates the section configuration and matching custom data atomically.

### `section-editors.tsx`

Uses React Hook Form and Zod for personal/contact/summary live editing and reusable collection dialogs for repeated entries. The collection configuration maps fields, schemas, summaries, and defaults without duplicating section-control logic.

### `resume-preview.tsx`

Renders the browser preview from the canonical document. Template-specific differences are limited to typography, spacing, headings, borders, and creative header/skill treatments.

### `resume-pdf-document.tsx`

Renders an independent A4 document tree using React-pdf `Document`, `Page`, `Text`, `View`, `Link`, and `Image` nodes. It does not screenshot the browser preview. Page wrapping and `minPresenceAhead` hints reduce stranded headings and clipped entries.

### `dashboard.tsx`

Merges local and cloud records by ID. A record present in both sources is labeled synced, and the most recently updated representation is displayed. Cloud-only records are saved locally before opening so the builder remains local-first.

## Server-side modules

### Supabase SSR

- Browser client: `src/lib/supabase/client.ts`
- Server client using request cookies: `src/lib/supabase/server.ts`
- Session refresh proxy: `src/lib/supabase/proxy.ts` and `src/proxy.ts`
- Service-role client: `src/lib/supabase/admin.ts`

The service-role client is imported only by server modules. It is never exposed through a `NEXT_PUBLIC_` variable.

### API routes

- `POST /api/feedback` — bounded JSON body, honeypot, validation, hashed daily abuse quota, server-only insert.
- `POST /api/ai/write` — disabled by default, bounded JSON body, Zod validation, user/IP subject hashing, atomic quota, server-side provider request.
- `DELETE /api/account` — verifies the authenticated user, deletes private Storage objects, then deletes the auth user; database rows cascade.

### Authentication callback

`/auth/callback` exchanges an OAuth/PKCE code for a session. Redirect destinations are normalized by `safeInternalPath`; scheme-relative, absolute, and backslash-based external redirects are rejected.

## Persistence flows

### Guest save

```text
Form change
 -> validated form value
 -> immutable ResumeDocument commit
 -> preview re-render
 -> 500 ms debounce
 -> Zod validation
 -> localStorage write
```

A local-save failure is surfaced by the autosave indicator rather than silently reported as saved.

### Cloud sync

```text
Authenticated user clicks Sync
 -> inspect existing cloud photo path
 -> upload new data-URL photo when necessary
 -> strip signed/data URL from database payload
 -> upsert owner-scoped resume row
 -> remove replaced private photo object
 -> save hydrated result locally
```

Cloud-loaded private photos receive short-lived signed URLs. A guest-originated photo remains as a local data URL after its private object path is uploaded, avoiding an immediately expiring local representation.

### Account deletion

```text
Authenticated DELETE request
 -> list user Storage folders
 -> delete all profile-photo objects
 -> delete Supabase auth user
 -> FK cascades profiles/resumes
```

The operation reports failure if Storage cleanup or user deletion fails.

## Security boundaries

- Zod validates local imports, API payloads, resume documents, and feedback.
- External resume links allow only HTTP/HTTPS; email and phone links are normalized separately.
- Auth callback destinations must be same-origin relative paths.
- RLS scopes profile and resume records to `auth.uid()`.
- Storage policies require the first object-path segment to equal `auth.uid()`.
- Feedback and quota tables are revoked from `anon` and `authenticated`; service role is required.
- AI and feedback abuse identifiers are SHA-256 hashes salted with `AI_RATE_LIMIT_SECRET`.
- AI keys and the service-role key remain server-only.
- API routes read bounded request text before JSON parsing.
- Security headers disable framing, MIME sniffing, sensitive browser permissions, and unnecessary DNS prefetching.

## Extensibility

### Add a template

1. Add an ID to `templateIdSchema`.
2. Add a definition to `resumeTemplates`.
3. Add preview/PDF presentation conditions.
4. Add the ID to the database `template_id` check constraint in a new migration.
5. Add tests ensuring the sample document validates and renders.

### Add a section

1. Define its Zod schema and TypeScript inference.
2. Add it to `ResumeData` and blank/sample data.
3. Add a default `SectionConfig`.
4. Add an editor collection configuration.
5. Add HTML and PDF render cases.
6. Add import/storage tests.

### Add an AI provider

Keep `AiRequest` and prompt construction provider-neutral. Implement another server-only adapter with the same `generateAiText` contract and select it through a server environment variable. Do not move provider calls to the browser.
