# FreeResume

> Create an ATS-friendly professional resume for free. No watermark, no hidden payment, and no account required.

FreeResume is a local-first resume builder built with Next.js, React, TypeScript, Tailwind CSS, shadcn-style Radix UI primitives, React Hook Form, Zod, Supabase, and React-pdf. A guest can create, autosave, print, import/export, and download a resume without registering. Authentication is required only for private cloud synchronization.

## What is implemented

- Responsive landing page, template gallery, builder, dashboard, authentication, privacy, terms, and contact pages.
- Five switchable templates: Modern, Minimal, Professional, Executive, and Creative.
- Four single-column ATS-conscious templates.
- One structured Zod-validated data model shared by every editor, template, local record, cloud record, JSON export, and PDF.
- All requested built-in sections plus reorderable custom sections.
- Drag-and-drop section ordering with keyboard sensors and explicit move buttons.
- Add, edit, delete, hide, rename, and reorder controls for sections and entries.
- Undo and redo history, browser autosave, duplicate, rename, clear, sample data, JSON import/export, print, and responsive edit/preview modes.
- A4 PDF export rendered by React-pdf with searchable/selectable text, clickable links, page wrapping, optional photos, no watermark, and no in-document branding.
- Optional Supabase email/password and Google authentication, email verification flow, password recovery, private cloud sync, private Storage assets, and account deletion.
- Row Level Security policies restricting profiles, resumes, and storage objects to their owner.
- Optional server-only AI writing module behind two feature flags, with Zod validation and an atomic daily quota.
- SEO metadata, canonical URLs, Open Graph metadata, JSON-LD, sitemap, robots, web manifest, error boundaries, loading states, empty states, and accessible focus behavior.
- Vitest unit tests, a PostgreSQL schema smoke test, GitHub Actions CI, a production Dockerfile, and deployment documentation.

The legal pages are deployment templates, not jurisdiction-specific legal advice. Replace the operator identity, support address, and policy language after legal review.

## Architecture at a glance

```text
FreeResume/
├── .github/workflows/ci.yml
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DATABASE.md
│   ├── DEPLOYMENT.md
│   ├── IMPLEMENTATION_PLAN.md
│   ├── SETUP.md
│   └── TESTING.md
├── public/
│   └── favicon.svg
├── src/
│   ├── app/
│   │   ├── (app)/
│   │   │   ├── builder/[id]/page.tsx
│   │   │   └── dashboard/page.tsx
│   │   ├── (auth)/
│   │   │   ├── login/page.tsx
│   │   │   ├── register/page.tsx
│   │   │   └── reset-password/page.tsx
│   │   ├── (marketing)/
│   │   │   ├── contact/page.tsx
│   │   │   ├── privacy/page.tsx
│   │   │   ├── templates/page.tsx
│   │   │   ├── terms/page.tsx
│   │   │   └── page.tsx
│   │   ├── api/
│   │   │   ├── account/route.ts
│   │   │   ├── ai/write/route.ts
│   │   │   └── feedback/route.ts
│   │   ├── auth/callback/route.ts
│   │   ├── error.tsx
│   │   ├── global-error.tsx
│   │   ├── layout.tsx
│   │   ├── manifest.ts
│   │   ├── robots.ts
│   │   └── sitemap.ts
│   ├── components/
│   │   ├── builder/
│   │   │   ├── resume-builder.tsx
│   │   │   ├── resume-preview.tsx
│   │   │   ├── resume-pdf-document.tsx
│   │   │   ├── section-editors.tsx
│   │   │   ├── section-list.tsx
│   │   │   ├── style-panel.tsx
│   │   │   └── use-resume-editor.ts
│   │   └── ui/                 # shadcn-style reusable primitives
│   ├── lib/
│   │   ├── ai/
│   │   ├── resume/
│   │   │   ├── cloud.ts
│   │   │   ├── sample.ts
│   │   │   ├── schema.ts
│   │   │   ├── storage.ts
│   │   │   └── templates.ts
│   │   └── supabase/
│   └── proxy.ts
├── supabase/
│   ├── migrations/202607200001_initial.sql
│   └── tests/schema_smoke.sql
├── tests/
├── .env.example
├── Dockerfile
├── next.config.ts
├── package.json
└── vitest.config.ts
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for component boundaries and data flows.

## Database schema

| Object | Purpose | Important controls |
|---|---|---|
| `profiles` | Optional user display profile | Primary key references `auth.users`; own-row select/update RLS |
| `resumes` | Private cloud resume documents | Owner ID, JSONB data/settings/sections, template/version, timestamps; own-row CRUD RLS |
| `feedback` | Contact form submissions | Server-only grants; no browser table access |
| `ai_usage` | Hashed subject/day request counters | Server-only grants; atomic `consume_ai_quota` function |
| `resume-assets` | Private profile photos | 2 MiB limit, JPEG/PNG/WebP only, user-ID folder policies |

The complete migration, triggers, indexes, grants, RLS policies, Storage policies, and quota function are in `supabase/migrations/202607200001_initial.sql`. See [docs/DATABASE.md](docs/DATABASE.md).

## Quick start

### Prerequisites

- Node.js 20.9 or newer; Node.js 22 is recommended for local development and matches the Docker/CI configuration.
- npm.
- A Supabase project or the Supabase CLI for local auth, PostgreSQL, and Storage.
- Optional: an OpenAI API key when the disabled-by-default AI module is intentionally enabled.

### Install and run the guest builder

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`. The guest builder works without Supabase values.

### Configure Supabase

For local Supabase:

```bash
supabase start
supabase db reset
```

Copy the local project URL and publishable/anon key into `.env.local`, then add the local service-role key for server-only account deletion, feedback storage, and quota enforcement.

For a hosted project:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Set the Site URL and allowed redirect URLs in Supabase Auth. At minimum, allow:

```text
http://localhost:3000/auth/callback
https://your-domain.example/auth/callback
```

Enable email confirmations and configure the Google provider when Google authentication is required.

Detailed steps are in [docs/SETUP.md](docs/SETUP.md).

## Environment variables

| Variable | Browser-visible | Required | Purpose |
|---|---:|---:|---|
| `NEXT_PUBLIC_APP_URL` | Yes | Production | Canonical application origin without a trailing slash |
| `NEXT_PUBLIC_APP_NAME` | Yes | No | Product name |
| `NEXT_PUBLIC_SUPPORT_EMAIL` | Yes | Production | Contact and legal-policy address |
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | Cloud features | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Yes | Cloud features | Supabase publishable key |
| `SUPABASE_SERVICE_ROLE_KEY` | No | Server operations | Account deletion, feedback insert, quota RPC |
| `NEXT_PUBLIC_AI_ENABLED` | Yes | AI UI | Shows the AI tab when `true` |
| `AI_ENABLED` | No | AI API | Enables the AI route when `true` |
| `AI_DAILY_FREE_LIMIT` | No | AI | Daily allowance, clamped to 1–100 |
| `AI_RATE_LIMIT_SECRET` | No | Production AI/feedback | Secret salt for hashed abuse identifiers |
| `OPENAI_API_KEY` | No | AI | Server-side provider credential |
| `OPENAI_MODEL` | No | AI | Explicit provider model identifier |

Never prefix a service-role key or provider API key with `NEXT_PUBLIC_`.

## Commands

```bash
npm run dev        # development server
npm run lint       # ESLint and Next.js rules
npm run typecheck  # strict TypeScript check
npm run test       # Vitest unit tests
npm run build      # optimized production build
npm run check      # lint + typecheck + test + build
npm run start      # run a completed production build
```

Database smoke test after migrations:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/schema_smoke.sql
```

See [docs/TESTING.md](docs/TESTING.md) for the manual quality-assurance matrix.

## Deployment

The repository supports:

- Vercel or another Next.js-compatible platform.
- A standalone multi-stage Docker image.
- Any Node.js platform capable of running the Next.js standalone server.

Before production traffic:

1. Apply the Supabase migration.
2. configure Auth URLs and providers;
3. set all production environment variables;
4. replace placeholder support/operator details and obtain legal review;
5. run `npm run check` and the database smoke test;
6. test guest autosave, cloud RLS, PDF text extraction, account deletion, and mobile editing on the deployed origin.

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for exact Vercel and Docker procedures.

## Core design decisions

- **Local-first:** creating or downloading a resume never depends on authentication or network availability.
- **Single canonical schema:** templates are views over one `ResumeDocument`; switching templates cannot discard fields.
- **Real PDF text:** React-pdf renders text and links directly rather than capturing the preview as an image.
- **Private cloud by default:** there is no public-resume route; RLS and private Storage policies scope data to the authenticated owner.
- **Server-only AI:** browser code never receives the provider key; the route is disabled unless the public and private feature flags are intentionally set.
- **No fabricated social proof:** the landing page does not ship with invented customer quotations.

## Implementation plan

The staged implementation and acceptance criteria are documented in [docs/IMPLEMENTATION_PLAN.md](docs/IMPLEMENTATION_PLAN.md). The repository follows the requested order: the complete non-AI guest flow first, optional authentication/cloud sync second, and modular AI last.

## Verification status of this delivered archive

The source tree has been parser-checked across all TypeScript/TSX files and checked for unresolved local imports. This execution environment could not resolve the npm registry, so dependencies could not be installed here and the full `npm run check` pipeline could not be executed inside the delivery environment. Run `npm install && npm run check` after extraction; CI performs the same quality pipeline on every push and pull request.

## License

MIT. See [LICENSE](LICENSE).
