# GitHub GEI migration-gap inventory v3

This program inventories migration-sensitive data in GitHub Enterprise Server and creates a structured Excel workbook for GHES-to-GHEC planning.

## What changed in v3

- Interactive setup wizard when run in a terminal.
- Automatic discovery of all active organizations visible to the PAT.
- Detects whether the authenticated user is an organization owner or member.
- Ignores an old `GITHUB_ORGS` environment variable unless `--use-env-orgs` is explicitly supplied.
- Scans multiple organizations concurrently.
- Shows organization and repository progress, API-call totals, rate-limit status, and elapsed scan time.
- Stops an endpoint group after three repeated `404 Not Found` responses by default, avoiding hundreds of identical failed calls.
- Skips organization-admin endpoints when the token owner is known not to have the required role.
- Skips Codespaces source endpoints automatically on GHES.
- Consolidates repeated failures in the **API Errors** worksheet and explains the likely cause and corrective action.
- Writes one row per organization to **Org Summary** and all object-level findings to separate detail worksheets.

## Virtual-environment setup

Run these commands from the directory containing the downloaded files:

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-gei-migration-gap-inventory-v3.txt
```

Set the GHES PAT without putting it in the command history:

```bash
export GH_PAT="YOUR_GHES_PAT"
```

For a complete classic-PAT inventory, the recommended scopes are:

```text
repo
admin:org
```

The PAT must also be SSO-authorized where required. The token owner must have the role required by each endpoint; organization-level secrets, variables, runners, runner groups, rulesets, webhooks, and app settings generally require organization-owner or equivalent administrative access.

## Recommended interactive run

```bash
python github_gei_migration_gap_inventory_v3.py
```

The wizard asks for:

1. GHES API URL, such as `https://github.int.inceptionai.ai/api/v3`
2. Output Excel filename
3. Scan profile
4. Parallel organization-worker count
5. Automatic organization discovery
6. TLS certificate verification
7. Confirmation before starting

### Scan profiles

- **Quick**: faster first pass. Skips webhooks, app installations, teams, Dependabot/Codespaces probes, and selected-repository expansion.
- **Standard**: recommended complete planning scan with targeted CI/workflow-file detection.
- **Deep**: scans all YAML, JSON, TOML, and Groovy-like files. Use only when the standard targeted file scan is insufficient.

## Non-interactive run

```bash
python github_gei_migration_gap_inventory_v3.py \
  --non-interactive \
  --api-url "https://github.int.inceptionai.ai/api/v3" \
  --output "github_gei_migration_gap_inventory.xlsx" \
  --profile standard \
  --workers 6
```

There must be no blank line after a shell continuation backslash.

A safe one-line equivalent is:

```bash
python github_gei_migration_gap_inventory_v3.py --non-interactive --api-url "https://github.int.inceptionai.ai/api/v3" --output "github_gei_migration_gap_inventory.xlsx" --profile standard --workers 6
```

## Faster diagnostic first pass

Use this before a full scan to validate access and endpoint compatibility:

```bash
python github_gei_migration_gap_inventory_v3.py \
  --non-interactive \
  --api-url "https://github.int.inceptionai.ai/api/v3" \
  --output "github_gei_quick_inventory.xlsx" \
  --profile quick \
  --workers 8
```

## Internal certificate authority

Prefer providing your internal CA certificate:

```bash
export REQUESTS_CA_BUNDLE="/path/to/company-ca-bundle.pem"
```

Use `--no-ssl-verify` only for temporary diagnosis because it disables TLS certificate validation.

## Organization discovery behavior

By default, the script discovers active organizations using the authenticated user's organization memberships. An existing `GITHUB_ORGS` value is deliberately ignored to prevent stale organization lists from affecting a run.

To use an explicit list:

```bash
python github_gei_migration_gap_inventory_v3.py \
  --non-interactive \
  --api-url "https://github.int.inceptionai.ai/api/v3" \
  --orgs "ORG1,ORG2,ORG3"
```

To deliberately reuse `GITHUB_ORGS`:

```bash
python github_gei_migration_gap_inventory_v3.py --use-env-orgs
```

## Understanding `404 Not Found`

GitHub can return `404` for a private or administrative endpoint when the resource exists but the token is missing a required scope, SSO authorization, organization-owner role, repository-admin role, or when the endpoint is unavailable in the installed GHES version.

Version 3 performs access preflight checks and adds these columns to **API Errors**:

- Severity
- Classification
- Likely cause
- Recommended action
- Occurrences

Identical repository-level 404s are consolidated. After three identical failures for an endpoint group within an organization, remaining calls in that group are skipped and marked unverified. Change the threshold only when needed:

```bash
--repeated-404-limit 5
```

## Excel workbook

The workbook contains:

- Run Info
- Org Summary
- Repo Details
- Secrets
- Variables
- Workflow References
- Workflow Files
- Environments
- Runners
- Runner Groups
- Rulesets
- Webhooks
- App Installations
- Teams
- Migration Gaps
- API Errors

The workflow scanner identifies GitHub Actions references such as `secrets.NAME` and `vars.NAME`, and also detects likely references in Azure DevOps, GitLab CI, Jenkins, CircleCI, Travis CI, Drone, Buildkite, Bitbucket Pipelines, and other likely CI files.

GitHub's API does not return secret values. The workbook records secret names, scope, metadata, and references only. Variable values are excluded by default; use `--include-variable-values` only when explicitly required.

## Resume after leaving the shell

```bash
cd /path/to/the/files
source venv/bin/activate
export GH_PAT="YOUR_GHES_PAT"
python github_gei_migration_gap_inventory_v3.py
```
