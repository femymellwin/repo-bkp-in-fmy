#!/usr/bin/env python3
"""
GitHub Enterprise Importer (GEI) migration gap inventory for GHES -> GHEC.

This script inventories GitHub data that needs manual remediation because it is not
fully migrated by GEI, with focus on:
  - GitHub Actions secrets and variables at org, repo, and environment scope
  - Dependabot and Codespaces org/repo secrets where the API is available
  - Environments and environment protection metadata
  - Self-hosted runners and runner groups
  - Organization and repository rulesets
  - Webhooks and GitHub App installations
  - CI/workflow files that reference secrets or variables, including GitHub Actions,
    Azure DevOps, GitLab CI, Jenkins, CircleCI, Travis, Drone, Buildkite and more

The workbook output is intentionally simple:
  - Org Summary: one row per organization
  - Detail sheets: one row per relevant object or finding

Secrets values are never exported because the GitHub REST API does not return them.
Variables values are hidden by default; use --include-variable-values only when you
intentionally want non-secret variable values in the workbook.
"""

from __future__ import annotations

import argparse
import base64
import getpass
import datetime as dt
import json
import os
import re
import sys
import time
import threading
import urllib.parse
from collections import defaultdict, Counter
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, DefaultDict, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import requests
from requests.adapters import HTTPAdapter
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

try:
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
except Exception:  # pragma: no cover
    ILLEGAL_CHARACTERS_RE = re.compile(r"[\000-\010]|[\013-\014]|[\016-\037]")


SCRIPT_VERSION = "3.0"
DEFAULT_API_VERSION = "2022-11-28"
DOCS_GEI_DATA_URL = (
    "https://docs.github.com/en/migrations/using-github-enterprise-importer/"
    "migrating-between-github-products/about-migrations-between-github-products"
)
DOCS_ACTIONS_SECRETS_URL = "https://docs.github.com/en/rest/actions/secrets"
DOCS_ACTIONS_VARIABLES_URL = "https://docs.github.com/en/rest/actions/variables"
DOCS_ACTIONS_RUNNERS_URL = "https://docs.github.com/en/rest/actions/self-hosted-runners"
DOCS_RULESETS_URL = "https://docs.github.com/en/rest/orgs/rules"
DOCS_CODESPACES_SECRETS_URL = "https://docs.github.com/en/rest/codespaces/organization-secrets"
DOCS_DEPENDABOT_SECRETS_URL = "https://docs.github.com/en/rest/dependabot/secrets"


PRINT_LOCK = threading.Lock()
ISSUE_LOCK = threading.Lock()
ISSUE_INDEX: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
CIRCUIT_LOCK = threading.Lock()
CIRCUIT_404_COUNTS: Counter = Counter()
CIRCUIT_OPEN: Set[Tuple[int, str, str]] = set()
CIRCUIT_THRESHOLD = 3
CIRCUIT_GROUPS = {
    "Actions repo secrets",
    "Actions repo variables",
    "Dependabot repo secrets",
    "Codespaces repo secrets",
    "Environment secrets",
    "Environment variables",
    "Repo self-hosted runners",
    "Repo rulesets",
    "Repo ruleset details",
    "Repo webhooks",
}


ORG_ADMIN_GROUPS = {
    "Actions org secrets",
    "Actions org secret selected repositories",
    "Actions org variables",
    "Actions org variable selected repositories",
    "Dependabot org secrets",
    "Dependabot org secret selected repositories",
    "Codespaces org secrets",
    "Codespaces org secret selected repositories",
    "Org self-hosted runners",
    "Runner groups",
    "Runner group selected repositories",
    "Org rulesets",
    "Org ruleset details",
    "Org webhooks",
    "GitHub App installations",
}


def product_preflight_skip(client: "GitHubClient", errors: List[Dict[str, Any]], org: str, repo: str, endpoint_group: str, endpoint: str) -> bool:
    if getattr(client, "skip_codespaces", False) and "Codespaces" in endpoint_group:
        add_error(
            errors,
            org=org,
            repo="",
            endpoint_group=endpoint_group,
            endpoint="[product capability preflight]",
            note="Skipped because the source is GHES and Codespaces is a GitHub Enterprise Cloud service. Use --force-codespaces only for a cloud source.",
        )
        return True
    return False


def org_admin_preflight_skip(client: "GitHubClient", errors: List[Dict[str, Any]], org: str, repo: str, endpoint_group: str, endpoint: str) -> bool:
    if not org or repo or endpoint_group not in ORG_ADMIN_GROUPS:
        return False
    role = getattr(client, "org_roles", {}).get(org, "unknown")
    scopes = getattr(client, "token_scopes", set())
    scope_header_present = bool(getattr(client, "scope_header_present", False))
    reasons: List[str] = []
    if role == "member":
        reasons.append("authenticated user is an organization member, not an owner")
    if scope_header_present and "admin:org" not in scopes:
        reasons.append("classic PAT does not advertise admin:org")
    if not reasons:
        return False
    add_error(
        errors,
        org=org,
        repo="",
        endpoint_group=endpoint_group,
        endpoint=endpoint,
        note="Skipped before request because " + " and ".join(reasons) + ". Counts for this endpoint are unverified.",
    )
    return True


def circuit_key(errors: List[Dict[str, Any]], org: str, endpoint_group: str) -> Tuple[int, str, str]:
    return (id(errors), org, endpoint_group)


def circuit_is_open(errors: List[Dict[str, Any]], org: str, endpoint_group: str) -> bool:
    if endpoint_group not in CIRCUIT_GROUPS or not org:
        return False
    with CIRCUIT_LOCK:
        return circuit_key(errors, org, endpoint_group) in CIRCUIT_OPEN


def circuit_record_404(errors: List[Dict[str, Any]], org: str, endpoint_group: str) -> bool:
    if endpoint_group not in CIRCUIT_GROUPS or not org:
        return False
    key = circuit_key(errors, org, endpoint_group)
    with CIRCUIT_LOCK:
        CIRCUIT_404_COUNTS[key] += 1
        if CIRCUIT_404_COUNTS[key] >= CIRCUIT_THRESHOLD and key not in CIRCUIT_OPEN:
            CIRCUIT_OPEN.add(key)
            return True
    return False


def log(message: str) -> None:
    with PRINT_LOCK:
        print(message, flush=True)


def classify_api_issue(status_code: int, endpoint_group: str, message: str) -> Tuple[str, str, str, str]:
    group = endpoint_group.lower()
    lower_message = (message or "").lower()
    if "skipped because the source is ghes" in lower_message and "codespaces" in group:
        return (
            "Info",
            "Product capability",
            "Codespaces is not part of the GHES source inventory.",
            "No action is required for the GHES source. Use --force-codespaces only when scanning GitHub Enterprise Cloud.",
        )
    if lower_message.startswith("skipped before request"):
        return (
            "Error",
            "Access preflight",
            "The token owner or classic PAT scope cannot access this organization-admin endpoint.",
            "Use a classic PAT with repo and admin:org, authorize it for SSO, and use a token owned by an owner of the organization.",
        )
    if lower_message.startswith("stopped calling this endpoint group"):
        return (
            "Warning",
            "Repeated 404 circuit breaker",
            "The same endpoint returned 404 repeatedly, so additional calls were skipped to reduce runtime.",
            "Review the representative 404 row, token scopes, owner/admin rights, and GHES endpoint support.",
        )
    if status_code == 404:
        if "codespaces" in group:
            return (
                "Warning",
                "Unavailable",
                "Codespaces endpoints are unavailable on this product or the token is not authorized.",
                "Do not treat the zero count as confirmed unless the source is GHES; otherwise check token permissions.",
            )
        if any(term in group for term in ("ruleset", "runner group", "app installation")):
            return (
                "Warning",
                "Unavailable or unauthorized",
                "The GHES version may not expose this endpoint, or the token owner lacks the required organization/repository administration permission.",
                "Check the GHES version and token-owner role. A zero count is not considered verified.",
            )
        return (
            "Error",
            "Authorization or visibility",
            "GitHub returns 404 for private resources when authentication, PAT scopes, SSO authorization, or owner/admin permissions are insufficient.",
            "Use a classic PAT with repo and admin:org, authorize it for SSO, and ensure the token owner has the required organization/repository role.",
        )
    if status_code in (401, 403):
        return (
            "Error",
            "Authorization",
            "The token is invalid, expired, rate-limited, or lacks an endpoint permission.",
            "Review PAT scopes, SSO authorization, organization role, repository administration access, and rate-limit headers.",
        )
    if status_code == 0:
        return ("Error", "Connection", "The API request did not complete.", "Check DNS, VPN, proxy, TLS trust, and the GHES API URL.")
    if status_code >= 500:
        return ("Warning", "Server", "GHES returned a server-side failure.", "Retry later and review GHES health/support logs if it persists.")
    return ("Warning", "API", message or "Unexpected REST API response.", "Review the endpoint response in this sheet.")


class ApiError(Exception):
    def __init__(self, method: str, url: str, status_code: int, message: str, response_text: str = ""):
        self.method = method
        self.url = url
        self.status_code = status_code
        self.message = message
        self.response_text = response_text
        super().__init__(f"{method} {url} -> HTTP {status_code}: {message}")


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def clean_cell(value: Any, max_len: int = 32000) -> Any:
    """Return a value safe for Excel cells."""
    if value is None:
        return ""
    if isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, (list, tuple, set)):
        value = ", ".join(str(v) for v in value)
    elif isinstance(value, dict):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True)
    else:
        value = str(value)
    value = ILLEGAL_CHARACTERS_RE.sub("", value)
    if len(value) > max_len:
        return value[: max_len - 20] + " ...[truncated]"
    return value


def csv_join(values: Iterable[Any], max_items: int = 200, max_len: int = 32000) -> str:
    vals = [str(v) for v in values if v is not None and str(v) != ""]
    if not vals:
        return ""
    more = ""
    if len(vals) > max_items:
        more = f", ... (+{len(vals) - max_items} more)"
        vals = vals[:max_items]
    out = ", ".join(vals) + more
    if len(out) > max_len:
        out = out[: max_len - 20] + " ...[truncated]"
    return out


def json_compact(value: Any, max_len: int = 32000) -> str:
    if value in (None, ""):
        return ""
    try:
        text = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except Exception:
        text = str(value)
    if len(text) > max_len:
        return text[: max_len - 20] + " ...[truncated]"
    return text


def normalize_api_url(api_url: str) -> str:
    api_url = api_url.strip().rstrip("/")
    if not api_url:
        raise ValueError("API URL cannot be empty")
    return api_url


def quote_path_part(value: str) -> str:
    return urllib.parse.quote(str(value), safe="")


def quote_repo_path(path: str) -> str:
    # Path parameter may include slashes, but special characters still need encoding.
    return urllib.parse.quote(path, safe="/")


def parse_link_header(link_header: str) -> Dict[str, str]:
    links: Dict[str, str] = {}
    if not link_header:
        return links
    for part in link_header.split(","):
        sections = part.split(";")
        if len(sections) < 2:
            continue
        url = sections[0].strip()
        if url.startswith("<") and url.endswith(">"):
            url = url[1:-1]
        rel = ""
        for section in sections[1:]:
            section = section.strip()
            if section.startswith('rel="') and section.endswith('"'):
                rel = section[5:-1]
                break
        if rel:
            links[rel] = url
    return links


class GitHubClient:
    def __init__(
        self,
        api_url: str,
        token: str,
        api_version: Optional[str] = DEFAULT_API_VERSION,
        verify_ssl: bool = True,
        timeout: int = 30,
        auth_scheme: str = "bearer",
        rate_limit_sleep_max: int = 60,
        verbose: bool = False,
    ) -> None:
        self.api_url = normalize_api_url(api_url)
        self.token = token
        self.api_version = api_version
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.auth_scheme = auth_scheme.lower()
        self.rate_limit_sleep_max = max(0, rate_limit_sleep_max)
        self.verbose = verbose
        self._thread_local = threading.local()
        self._counter_lock = threading.Lock()
        self.request_count = 0
        self.last_rate_remaining = ""
        self.last_rate_limit = ""
        self.last_rate_reset = ""
        self.org_roles: Dict[str, str] = {}
        self.token_scopes: Set[str] = set()
        self.scope_header_present = False
        self.skip_codespaces = False
        scheme = "token" if self.auth_scheme == "token" else "Bearer"
        self._headers = {
            "Authorization": f"{scheme} {self.token}",
            "Accept": "application/vnd.github+json",
            "User-Agent": f"gei-migration-gap-inventory/{SCRIPT_VERSION}",
        }
        if api_version:
            self._headers["X-GitHub-Api-Version"] = api_version

    def _session(self) -> requests.Session:
        session = getattr(self._thread_local, "session", None)
        if session is None:
            session = requests.Session()
            session.headers.update(self._headers)
            adapter = HTTPAdapter(pool_connections=20, pool_maxsize=20, max_retries=0)
            session.mount("https://", adapter)
            session.mount("http://", adapter)
            self._thread_local.session = session
        return session

    def stats(self) -> Dict[str, Any]:
        with self._counter_lock:
            return {
                "requests": self.request_count,
                "rate_remaining": self.last_rate_remaining,
                "rate_limit": self.last_rate_limit,
                "rate_reset": self.last_rate_reset,
            }

    def url(self, path_or_url: str) -> str:
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            return path_or_url
        if not path_or_url.startswith("/"):
            path_or_url = "/" + path_or_url
        return self.api_url + path_or_url

    def request(
        self,
        method: str,
        path_or_url: str,
        params: Optional[Dict[str, Any]] = None,
        expected: Sequence[int] = (200,),
        context: str = "",
    ) -> Tuple[Any, requests.Response]:
        url = self.url(path_or_url)
        attempts = 0
        backoff = 2
        while True:
            attempts += 1
            if self.verbose:
                print(f"[DEBUG] {method.upper()} {url}", file=sys.stderr)
            try:
                resp = self._session().request(
                    method.upper(),
                    url,
                    params=params,
                    timeout=self.timeout,
                    verify=self.verify_ssl,
                )
                with self._counter_lock:
                    self.request_count += 1
                    self.last_rate_remaining = resp.headers.get("X-RateLimit-Remaining", self.last_rate_remaining)
                    self.last_rate_limit = resp.headers.get("X-RateLimit-Limit", self.last_rate_limit)
                    self.last_rate_reset = resp.headers.get("X-RateLimit-Reset", self.last_rate_reset)
            except requests.RequestException as exc:
                if attempts < 3:
                    time.sleep(backoff)
                    backoff *= 2
                    continue
                raise ApiError(method.upper(), url, 0, f"Request failed: {exc}") from exc

            if resp.status_code in expected:
                if resp.status_code == 204:
                    return None, resp
                if not resp.content:
                    return None, resp
                try:
                    return resp.json(), resp
                except ValueError:
                    return resp.text, resp

            # Handle transient server-side failures.
            if resp.status_code >= 500 and attempts < 3:
                time.sleep(backoff)
                backoff *= 2
                continue

            # Handle rate limit if possible, but do not sleep for a very long time.
            if resp.status_code in (403, 429):
                message_for_rate = ""
                try:
                    message_for_rate = resp.json().get("message", "")
                except Exception:
                    message_for_rate = resp.text[:500]
                if "rate limit" in message_for_rate.lower() and attempts < 3:
                    reset_header = resp.headers.get("X-RateLimit-Reset")
                    sleep_seconds = backoff
                    if reset_header and reset_header.isdigit():
                        sleep_seconds = max(1, int(reset_header) - int(time.time()) + 1)
                    sleep_seconds = min(sleep_seconds, self.rate_limit_sleep_max)
                    if sleep_seconds > 0:
                        log(f"[WARN] Rate limit hit; sleeping {sleep_seconds}s: {context or url}")
                        time.sleep(sleep_seconds)
                    backoff *= 2
                    continue

            message = ""
            response_text = resp.text[:2000] if resp.text else ""
            try:
                payload = resp.json()
                if isinstance(payload, dict):
                    message = payload.get("message") or json.dumps(payload)[:1000]
                else:
                    message = str(payload)[:1000]
            except Exception:
                message = response_text or resp.reason
            raise ApiError(method.upper(), url, resp.status_code, message, response_text)

    def get_json(self, path_or_url: str, params: Optional[Dict[str, Any]] = None, context: str = "") -> Any:
        data, _ = self.request("GET", path_or_url, params=params, context=context)
        return data

    def get_paginated(
        self,
        path_or_url: str,
        item_key: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        context: str = "",
    ) -> List[Any]:
        results: List[Any] = []
        next_url: Optional[str] = path_or_url
        current_params = dict(params or {})
        current_params.setdefault("per_page", 100)
        while next_url:
            data, resp = self.request("GET", next_url, params=current_params, context=context)
            current_params = None  # type: ignore[assignment]
            if isinstance(data, list):
                results.extend(data)
            elif isinstance(data, dict):
                key = item_key
                if key is None:
                    for candidate in (
                        "items",
                        "repositories",
                        "repos",
                        "secrets",
                        "variables",
                        "environments",
                        "runners",
                        "runner_groups",
                        "workflow_runs",
                        "installations",
                        "hooks",
                        "teams",
                    ):
                        if candidate in data and isinstance(data[candidate], list):
                            key = candidate
                            break
                if key and isinstance(data.get(key), list):
                    results.extend(data[key])
                else:
                    # Some endpoints are not list endpoints. Return the dict as one row to avoid data loss.
                    results.append(data)
            links = parse_link_header(resp.headers.get("Link", ""))
            next_url = links.get("next")
        return results


def add_error(
    errors: List[Dict[str, Any]],
    org: str = "",
    repo: str = "",
    endpoint_group: str = "",
    endpoint: str = "",
    error: Optional[ApiError] = None,
    note: str = "",
) -> None:
    status_code = error.status_code if error else ""
    message = error.message if error else note
    severity, classification, likely_cause, action = classify_api_issue(int(status_code or 0), endpoint_group, str(message))
    row = {
        "Organization": org,
        "Repository": repo,
        "Endpoint group": endpoint_group,
        "Endpoint": endpoint,
        "HTTP status": status_code,
        "Severity": severity,
        "Classification": classification,
        "Message": message,
        "Likely cause": likely_cause,
        "Recommended action": action,
        "Occurrences": 1,
        "URL": error.url if error else "",
    }

    # A missing permission can produce the same 404 for every repository. Keep one
    # representative row and increment Occurrences instead of creating hundreds of rows.
    if error and error.status_code == 404:
        key: Tuple[Any, ...] = (id(errors), org, endpoint_group, error.status_code, error.message)
    else:
        key = (id(errors), org, repo, endpoint_group, endpoint, status_code, message)
    with ISSUE_LOCK:
        existing = ISSUE_INDEX.get(key)
        if existing is not None:
            existing["Occurrences"] = int(existing.get("Occurrences", 1)) + 1
            return
        ISSUE_INDEX[key] = row
        errors.append(row)


def safe_get(
    client: GitHubClient,
    errors: List[Dict[str, Any]],
    org: str,
    repo: str,
    endpoint_group: str,
    endpoint: str,
    params: Optional[Dict[str, Any]] = None,
    default: Any = None,
) -> Any:
    if product_preflight_skip(client, errors, org, repo, endpoint_group, endpoint):
        return default
    if org_admin_preflight_skip(client, errors, org, repo, endpoint_group, endpoint):
        return default
    if circuit_is_open(errors, org, endpoint_group):
        return default
    try:
        return client.get_json(endpoint, params=params, context=f"{endpoint_group} {org}/{repo}")
    except ApiError as exc:
        add_error(errors, org=org, repo=repo, endpoint_group=endpoint_group, endpoint=endpoint, error=exc)
        if exc.status_code == 404 and circuit_record_404(errors, org, endpoint_group):
            add_error(
                errors,
                org=org,
                repo="",
                endpoint_group=endpoint_group,
                endpoint=endpoint,
                note=f"Stopped calling this endpoint group after {CIRCUIT_THRESHOLD} repeated 404 responses. Remaining repositories are marked unverified.",
            )
        return default


def safe_paginated(
    client: GitHubClient,
    errors: List[Dict[str, Any]],
    org: str,
    repo: str,
    endpoint_group: str,
    endpoint: str,
    item_key: Optional[str] = None,
    params: Optional[Dict[str, Any]] = None,
) -> List[Any]:
    if product_preflight_skip(client, errors, org, repo, endpoint_group, endpoint):
        return []
    if org_admin_preflight_skip(client, errors, org, repo, endpoint_group, endpoint):
        return []
    if circuit_is_open(errors, org, endpoint_group):
        return []
    try:
        return client.get_paginated(endpoint, item_key=item_key, params=params, context=f"{endpoint_group} {org}/{repo}")
    except ApiError as exc:
        add_error(errors, org=org, repo=repo, endpoint_group=endpoint_group, endpoint=endpoint, error=exc)
        if exc.status_code == 404 and circuit_record_404(errors, org, endpoint_group):
            add_error(
                errors,
                org=org,
                repo="",
                endpoint_group=endpoint_group,
                endpoint=endpoint,
                note=f"Stopped calling this endpoint group after {CIRCUIT_THRESHOLD} repeated 404 responses. Remaining repositories are marked unverified.",
            )
        return []


def split_orgs(value: str) -> List[str]:
    if not value:
        return []
    return sorted({part.strip() for part in value.split(",") if part.strip()}, key=str.lower)


def discover_organizations(client: GitHubClient, errors: List[Dict[str, Any]]) -> List[str]:
    orgs: Set[str] = set()
    user_orgs = safe_paginated(client, errors, "", "", "Organization discovery", "/user/orgs", item_key=None)
    for org in user_orgs:
        login = org.get("login") if isinstance(org, dict) else None
        if login:
            orgs.add(login)

    if orgs:
        return sorted(orgs, key=str.lower)

    # Fallback: collect org owners from repos visible to the token.
    repos = safe_paginated(
        client,
        errors,
        "",
        "",
        "Organization discovery fallback",
        "/user/repos",
        item_key=None,
        params={"type": "all", "affiliation": "owner,organization_member,collaborator"},
    )
    for repo in repos:
        owner = (repo or {}).get("owner", {}) if isinstance(repo, dict) else {}
        if owner.get("type") == "Organization" and owner.get("login"):
            orgs.add(owner["login"])
    return sorted(orgs, key=str.lower)


def discover_org_memberships(client: GitHubClient, errors: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, str]]:
    """Discover active organizations and the authenticated user's role in each."""
    roles: Dict[str, str] = {}
    memberships = safe_paginated(
        client,
        errors,
        "",
        "",
        "Organization membership discovery",
        "/user/memberships/orgs",
        item_key=None,
        params={"state": "active"},
    )
    for membership in memberships:
        if not isinstance(membership, dict):
            continue
        organization = membership.get("organization") or {}
        login = organization.get("login") if isinstance(organization, dict) else ""
        if login:
            roles[str(login)] = str(membership.get("role") or "unknown")
    if roles:
        return sorted(roles, key=str.lower), roles
    orgs = discover_organizations(client, errors)
    return orgs, {org: "unknown" for org in orgs}


def parse_scope_header(value: str) -> Set[str]:
    return {part.strip() for part in (value or "").split(",") if part.strip()}


def is_github_com_api(api_url: str) -> bool:
    parsed = urllib.parse.urlparse(api_url)
    return parsed.netloc.lower() == "api.github.com"


# Built-in variables that generally do not need manual recreation as GitHub secrets/variables.
GITHUB_BUILTINS = {
    "CI",
    "GITHUB_ACTION",
    "GITHUB_ACTION_PATH",
    "GITHUB_ACTION_REPOSITORY",
    "GITHUB_ACTIONS",
    "GITHUB_ACTOR",
    "GITHUB_ACTOR_ID",
    "GITHUB_API_URL",
    "GITHUB_BASE_REF",
    "GITHUB_ENV",
    "GITHUB_EVENT_NAME",
    "GITHUB_EVENT_PATH",
    "GITHUB_GRAPHQL_URL",
    "GITHUB_HEAD_REF",
    "GITHUB_JOB",
    "GITHUB_OUTPUT",
    "GITHUB_PATH",
    "GITHUB_REF",
    "GITHUB_REF_NAME",
    "GITHUB_REF_PROTECTED",
    "GITHUB_REF_TYPE",
    "GITHUB_REPOSITORY",
    "GITHUB_REPOSITORY_ID",
    "GITHUB_REPOSITORY_OWNER",
    "GITHUB_REPOSITORY_OWNER_ID",
    "GITHUB_RETENTION_DAYS",
    "GITHUB_RUN_ATTEMPT",
    "GITHUB_RUN_ID",
    "GITHUB_RUN_NUMBER",
    "GITHUB_SERVER_URL",
    "GITHUB_SHA",
    "GITHUB_STEP_SUMMARY",
    "GITHUB_TOKEN",
    "GITHUB_TRIGGERING_ACTOR",
    "GITHUB_WORKFLOW",
    "GITHUB_WORKFLOW_REF",
    "GITHUB_WORKFLOW_SHA",
    "GITHUB_WORKSPACE",
    "RUNNER_ARCH",
    "RUNNER_DEBUG",
    "RUNNER_ENVIRONMENT",
    "RUNNER_NAME",
    "RUNNER_OS",
    "RUNNER_TEMP",
    "RUNNER_TOOL_CACHE",
}


def is_likely_builtin(name: str, syntax_family: str) -> bool:
    name_upper = name.upper()
    if name_upper in GITHUB_BUILTINS:
        return True
    if name_upper.startswith("GITHUB_") or name_upper.startswith("RUNNER_"):
        return True
    if syntax_family in ("Azure DevOps macro", "Azure DevOps template"):
        prefixes = ("BUILD_", "BUILD.", "SYSTEM_", "SYSTEM.", "RELEASE_", "RELEASE.", "AGENT_", "AGENT.")
        return name_upper.startswith(prefixes)
    if syntax_family == "GitLab shell variable":
        return name_upper == "CI" or name_upper.startswith("CI_") or name_upper.startswith("GITLAB_")
    return False


GHA_SECRET_DOT = re.compile(r"(?<![A-Za-z0-9_])secrets\.([A-Za-z_][A-Za-z0-9_]*)")
GHA_SECRET_BRACKET = re.compile(r"secrets\[['\"]([^'\"]+)['\"]\]")
GHA_VAR_DOT = re.compile(r"(?<![A-Za-z0-9_])vars\.([A-Za-z_][A-Za-z0-9_]*)")
GHA_VAR_BRACKET = re.compile(r"vars\[['\"]([^'\"]+)['\"]\]")
AZDO_MACRO = re.compile(r"\$\(([A-Za-z_][A-Za-z0-9_.-]{0,180})\)")
AZDO_TEMPLATE_BRACKET = re.compile(r"variables\[['\"]([^'\"]+)['\"]\]")
AZDO_TEMPLATE_DOT = re.compile(r"(?<![A-Za-z0-9_])variables\.([A-Za-z_][A-Za-z0-9_.-]{0,180})")
AZDO_GROUP = re.compile(r"^\s*-?\s*group\s*:\s*['\"]?([^'\"#\r\n]+)")
GITLAB_VAR = re.compile(r"(?<!\$)\$\{?([A-Za-z_][A-Za-z0-9_]{1,120})\}?")
JENKINS_CREDENTIALS = re.compile(r"credentials\(['\"]([^'\"]+)['\"]\)|credentialsId\s*:\s*['\"]([^'\"]+)['\"]")


@dataclass
class ReferenceFinding:
    org: str
    repo: str
    default_branch: str
    file_path: str
    workflow_family: str
    github_workflow: str
    reference_kind: str
    reference_name: str
    syntax_family: str
    expression: str
    line_numbers: List[int]
    occurrence_count: int
    likely_builtin: str
    definition_match: str = ""
    defined_scopes: str = ""
    migration_action: str = ""
    line_excerpt: str = ""


def classify_ci_file(path: str) -> Tuple[str, str]:
    p = path.replace("\\", "/")
    pl = p.lower()
    name = pl.rsplit("/", 1)[-1]

    if pl.startswith(".github/workflows/") and (pl.endswith(".yml") or pl.endswith(".yaml")):
        return "GitHub Actions", "Yes"
    if name in {"azure-pipelines.yml", "azure-pipelines.yaml"} or "azure-pipelines" in pl:
        return "Azure DevOps", "No"
    if pl.startswith(".azure-pipelines/") or pl.startswith("azure-pipelines/"):
        return "Azure DevOps", "No"
    if pl.startswith(".ado/") or pl.startswith("ado/"):
        return "Azure DevOps", "No"
    if pl.startswith(".pipelines/") or pl.startswith("pipelines/") or "/pipelines/" in pl:
        return "CI pipeline", "No"
    if name == ".gitlab-ci.yml" or name == ".gitlab-ci.yaml" or pl.startswith(".gitlab/") or pl.startswith("gitlab/"):
        return "GitLab CI", "No"
    if name == "jenkinsfile" or name.startswith("jenkinsfile.") or pl.endswith("/jenkinsfile"):
        return "Jenkins", "No"
    if pl.startswith(".circleci/"):
        return "CircleCI", "No"
    if name in {".travis.yml", ".travis.yaml"}:
        return "Travis CI", "No"
    if name in {"bitbucket-pipelines.yml", "bitbucket-pipelines.yaml"}:
        return "Bitbucket Pipelines", "No"
    if name in {".drone.yml", ".drone.yaml"} or pl.startswith(".drone/"):
        return "Drone CI", "No"
    if pl.startswith(".buildkite/") or name in {"buildkite.yml", "buildkite.yaml"}:
        return "Buildkite", "No"
    if pl.startswith(".github/") and (pl.endswith(".yml") or pl.endswith(".yaml")):
        return "GitHub config", "No"
    return "Other", "No"


def is_yaml_like(path: str) -> bool:
    pl = path.lower()
    return pl.endswith((".yml", ".yaml", ".json", ".toml", ".groovy")) or pl.rsplit("/", 1)[-1] == "jenkinsfile"


def is_ci_candidate(path: str, scan_all_yaml: bool = False) -> bool:
    family, _ = classify_ci_file(path)
    if family != "Other":
        return True
    if not is_yaml_like(path):
        return False
    if scan_all_yaml:
        return True
    pl = path.lower().replace("\\", "/")
    tokens = ("workflow", "workflows", "pipeline", "pipelines", "deploy", "release", "ci", "cd", "build")
    parts = pl.split("/")
    if any(part in tokens or any(token in part for token in ("workflow", "pipeline")) for part in parts):
        return True
    return False


def scan_references_in_text(
    org: str,
    repo: str,
    default_branch: str,
    file_path: str,
    workflow_family: str,
    github_workflow: str,
    text: str,
    include_line_text: bool = False,
) -> List[ReferenceFinding]:
    findings: Dict[Tuple[str, str, str], ReferenceFinding] = {}

    def add(kind: str, name: str, syntax_family: str, expression: str, line_no: int, line_text: str) -> None:
        name = name.strip()
        if not name or len(name) > 200:
            return
        key = (kind, name, syntax_family)
        likely_builtin = "Yes" if is_likely_builtin(name, syntax_family) else "No"
        if key not in findings:
            findings[key] = ReferenceFinding(
                org=org,
                repo=repo,
                default_branch=default_branch,
                file_path=file_path,
                workflow_family=workflow_family,
                github_workflow=github_workflow,
                reference_kind=kind,
                reference_name=name,
                syntax_family=syntax_family,
                expression=expression,
                line_numbers=[],
                occurrence_count=0,
                likely_builtin=likely_builtin,
                line_excerpt=clean_cell(line_text.strip()[:500]) if include_line_text else "",
            )
        findings[key].line_numbers.append(line_no)
        findings[key].occurrence_count += 1

    for line_no, line in enumerate(text.splitlines(), start=1):
        for match in GHA_SECRET_DOT.finditer(line):
            name = match.group(1)
            add("Secret", name, "GitHub Actions secrets context", f"secrets.{name}", line_no, line)
        for match in GHA_SECRET_BRACKET.finditer(line):
            name = match.group(1)
            add("Secret", name, "GitHub Actions secrets context", f"secrets['{name}']", line_no, line)
        for match in GHA_VAR_DOT.finditer(line):
            name = match.group(1)
            add("Variable", name, "GitHub Actions vars context", f"vars.{name}", line_no, line)
        for match in GHA_VAR_BRACKET.finditer(line):
            name = match.group(1)
            add("Variable", name, "GitHub Actions vars context", f"vars['{name}']", line_no, line)

        # Azure DevOps pipeline syntaxes. These may be either normal variables or secret variables.
        if workflow_family in {"Azure DevOps", "CI pipeline", "Other", "GitHub config"}:
            for match in AZDO_MACRO.finditer(line):
                name = match.group(1)
                add("Variable or secret", name, "Azure DevOps macro", f"$({name})", line_no, line)
            for match in AZDO_TEMPLATE_BRACKET.finditer(line):
                name = match.group(1)
                add("Variable or secret", name, "Azure DevOps template", f"variables['{name}']", line_no, line)
            for match in AZDO_TEMPLATE_DOT.finditer(line):
                name = match.group(1)
                add("Variable or secret", name, "Azure DevOps template", f"variables.{name}", line_no, line)
            group_match = AZDO_GROUP.search(line)
            if group_match:
                group_name = group_match.group(1).strip()
                add("Variable group", group_name, "Azure DevOps variable group", f"group: {group_name}", line_no, line)

        # GitLab CI variable references. Avoid applying to all GitHub Actions shell snippets to reduce noise.
        if workflow_family == "GitLab CI":
            for match in GITLAB_VAR.finditer(line):
                name = match.group(1)
                add("Variable or secret", name, "GitLab shell variable", f"${name}", line_no, line)

        if workflow_family == "Jenkins":
            for match in JENKINS_CREDENTIALS.finditer(line):
                name = match.group(1) or match.group(2)
                add("External credential", name, "Jenkins credentials", f"credentials({name})", line_no, line)

    return list(findings.values())


class DefinedNameIndex:
    def __init__(self) -> None:
        self.org_actions_secrets: DefaultDict[str, Set[str]] = defaultdict(set)
        self.repo_actions_secrets: DefaultDict[Tuple[str, str], Set[str]] = defaultdict(set)
        self.env_actions_secrets: DefaultDict[Tuple[str, str, str], Set[str]] = defaultdict(set)
        self.org_actions_vars: DefaultDict[str, Set[str]] = defaultdict(set)
        self.repo_actions_vars: DefaultDict[Tuple[str, str], Set[str]] = defaultdict(set)
        self.env_actions_vars: DefaultDict[Tuple[str, str, str], Set[str]] = defaultdict(set)
        self.org_dependabot_secrets: DefaultDict[str, Set[str]] = defaultdict(set)
        self.repo_dependabot_secrets: DefaultDict[Tuple[str, str], Set[str]] = defaultdict(set)
        self.org_codespaces_secrets: DefaultDict[str, Set[str]] = defaultdict(set)
        self.repo_codespaces_secrets: DefaultDict[Tuple[str, str], Set[str]] = defaultdict(set)

    def match(self, org: str, repo: str, name: str, kind: str) -> Tuple[str, str]:
        matches: List[str] = []
        name_upper = name.upper()

        def has_name(values: Iterable[str]) -> bool:
            return name_upper in {v.upper() for v in values}

        if kind in ("Secret", "Variable or secret", "External credential"):
            if has_name(self.org_actions_secrets[org]):
                matches.append("Actions org secret")
            if has_name(self.repo_actions_secrets[(org, repo)]):
                matches.append("Actions repo secret")
            env_matches = [env for (o, r, env), vals in self.env_actions_secrets.items() if o == org and r == repo and has_name(vals)]
            if env_matches:
                matches.append("Actions environment secret: " + csv_join(env_matches, max_items=20))
            if has_name(self.org_dependabot_secrets[org]):
                matches.append("Dependabot org secret")
            if has_name(self.repo_dependabot_secrets[(org, repo)]):
                matches.append("Dependabot repo secret")
            if has_name(self.org_codespaces_secrets[org]):
                matches.append("Codespaces org secret")
            if has_name(self.repo_codespaces_secrets[(org, repo)]):
                matches.append("Codespaces repo secret")

        if kind in ("Variable", "Variable or secret"):
            if has_name(self.org_actions_vars[org]):
                matches.append("Actions org variable")
            if has_name(self.repo_actions_vars[(org, repo)]):
                matches.append("Actions repo variable")
            env_var_matches = [env for (o, r, env), vals in self.env_actions_vars.items() if o == org and r == repo and has_name(vals)]
            if env_var_matches:
                matches.append("Actions environment variable: " + csv_join(env_var_matches, max_items=20))

        if matches:
            return "Yes", csv_join(matches, max_items=30)
        if kind in ("Variable group", "External credential"):
            return "External", "External system reference; verify manually"
        return "No", "No matching GitHub secret/variable name found in fetched scopes"


def extract_repo_owner_name(repo_obj: Dict[str, Any]) -> Tuple[str, str]:
    owner = repo_obj.get("owner", {}) or {}
    return owner.get("login", ""), repo_obj.get("name", "")


def list_selected_repos(
    client: GitHubClient,
    errors: List[Dict[str, Any]],
    org: str,
    endpoint_group: str,
    selected_url: str,
    secret_or_var_name: str,
    enabled: bool,
) -> Tuple[int, str]:
    if not enabled or not selected_url:
        return 0, ""
    repos = safe_paginated(
        client,
        errors,
        org,
        "",
        endpoint_group,
        selected_url,
        item_key="repositories",
    )
    names = []
    for repo in repos:
        if not isinstance(repo, dict):
            continue
        names.append(repo.get("full_name") or repo.get("name") or str(repo.get("id", "")))
    return len(names), csv_join(names, max_items=200)


def get_tree_for_repo(
    client: GitHubClient,
    errors: List[Dict[str, Any]],
    org: str,
    repo: str,
    default_branch: str,
) -> Tuple[List[Dict[str, Any]], bool]:
    if not default_branch:
        return [], False
    endpoint = f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/git/trees/{quote_path_part(default_branch)}"
    data = safe_get(
        client,
        errors,
        org,
        repo,
        "Git tree",
        endpoint,
        params={"recursive": "1"},
        default={},
    )
    if not isinstance(data, dict):
        return [], False
    tree = data.get("tree") or []
    if not isinstance(tree, list):
        tree = []
    return tree, bool(data.get("truncated"))


def fetch_file_text(
    client: GitHubClient,
    errors: List[Dict[str, Any]],
    org: str,
    repo: str,
    path: str,
    ref: str,
) -> Optional[str]:
    endpoint = f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/contents/{quote_repo_path(path)}"
    data = safe_get(
        client,
        errors,
        org,
        repo,
        "File content",
        endpoint,
        params={"ref": ref},
        default=None,
    )
    if not isinstance(data, dict):
        return None
    if data.get("encoding") != "base64" or "content" not in data:
        return None
    try:
        raw = base64.b64decode(str(data.get("content", "")).encode("utf-8"), validate=False)
    except Exception:
        return None
    for encoding in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def summarize_ruleset_rules(ruleset: Dict[str, Any]) -> Tuple[str, int, str, int]:
    rules = ruleset.get("rules") or []
    if not isinstance(rules, list):
        rules = []
    rule_types = []
    for rule in rules:
        if isinstance(rule, dict):
            rule_types.append(rule.get("type", ""))
    bypass = ruleset.get("bypass_actors") or []
    bypass_count = len(bypass) if isinstance(bypass, list) else 0
    return csv_join([r for r in rule_types if r], max_items=100), len(rules), json_compact(ruleset.get("conditions")), bypass_count


def add_secret_row(
    secret_rows: List[Dict[str, Any]],
    name_index: DefinedNameIndex,
    org: str,
    repo: str,
    environment: str,
    secret: Dict[str, Any],
    category: str,
    scope: str,
    visibility: str = "",
    selected_repo_count: int = 0,
    selected_repo_names: str = "",
) -> None:
    name = secret.get("name", "")
    if not name:
        return
    if category == "Actions" and scope == "Organization":
        name_index.org_actions_secrets[org].add(name)
    elif category == "Actions" and scope == "Repository":
        name_index.repo_actions_secrets[(org, repo)].add(name)
    elif category == "Actions" and scope == "Environment":
        name_index.env_actions_secrets[(org, repo, environment)].add(name)
    elif category == "Dependabot" and scope == "Organization":
        name_index.org_dependabot_secrets[org].add(name)
    elif category == "Dependabot" and scope == "Repository":
        name_index.repo_dependabot_secrets[(org, repo)].add(name)
    elif category == "Codespaces" and scope == "Organization":
        name_index.org_codespaces_secrets[org].add(name)
    elif category == "Codespaces" and scope == "Repository":
        name_index.repo_codespaces_secrets[(org, repo)].add(name)

    secret_rows.append(
        {
            "Organization": org,
            "Repository": repo,
            "Environment": environment,
            "Secret category": category,
            "Scope": scope,
            "Secret name": name,
            "Visibility": visibility or secret.get("visibility", ""),
            "Selected repository count": selected_repo_count,
            "Selected repositories": selected_repo_names,
            "Created at": secret.get("created_at", ""),
            "Updated at": secret.get("updated_at", ""),
            "Value exported": "No - GitHub API does not return secret values",
            "Migration action": "Recreate secret at same scope in GHEC; update selected repo access/environment mapping if applicable",
            "Referenced file count": 0,
            "Referenced workflow families": "",
            "Referenced files": "",
        }
    )


def add_variable_row(
    variable_rows: List[Dict[str, Any]],
    name_index: DefinedNameIndex,
    org: str,
    repo: str,
    environment: str,
    variable: Dict[str, Any],
    scope: str,
    include_values: bool,
    selected_repo_count: int = 0,
    selected_repo_names: str = "",
) -> None:
    name = variable.get("name", "")
    if not name:
        return
    if scope == "Organization":
        name_index.org_actions_vars[org].add(name)
    elif scope == "Repository":
        name_index.repo_actions_vars[(org, repo)].add(name)
    elif scope == "Environment":
        name_index.env_actions_vars[(org, repo, environment)].add(name)

    variable_rows.append(
        {
            "Organization": org,
            "Repository": repo,
            "Environment": environment,
            "Variable category": "Actions",
            "Scope": scope,
            "Variable name": name,
            "Variable value": variable.get("value", "") if include_values else "[hidden; use --include-variable-values to export]",
            "Visibility": variable.get("visibility", ""),
            "Selected repository count": selected_repo_count,
            "Selected repositories": selected_repo_names,
            "Created at": variable.get("created_at", ""),
            "Updated at": variable.get("updated_at", ""),
            "Migration action": "Recreate variable at same scope in GHEC; validate selected repo access/environment mapping if applicable",
            "Referenced file count": 0,
            "Referenced workflow families": "",
            "Referenced files": "",
        }
    )


def append_reference_rows(
    reference_rows: List[Dict[str, Any]],
    findings: List[ReferenceFinding],
    name_index: DefinedNameIndex,
) -> None:
    for finding in findings:
        match, scopes = name_index.match(finding.org, finding.repo, finding.reference_name, finding.reference_kind)
        finding.definition_match = match
        finding.defined_scopes = scopes
        if finding.likely_builtin == "Yes":
            action = "Likely built-in CI/GitHub variable or token; usually no manual migration needed"
        elif finding.reference_kind in ("Variable group", "External credential"):
            action = "External CI/CD reference; identify source system value and recreate in GitHub secrets/variables if workflow remains active"
        elif match == "Yes":
            action = "Mapped to fetched GitHub secret/variable name; recreate same name/scope in GHEC and retest workflow"
        elif match == "External":
            action = "External reference; verify manually"
        else:
            action = "No matching GitHub definition found; verify whether value exists in ADO/GitLab/Jenkins or must be created in GHEC"
        finding.migration_action = action
        reference_rows.append(
            {
                "Organization": finding.org,
                "Repository": finding.repo,
                "Default branch": finding.default_branch,
                "File path": finding.file_path,
                "Workflow family": finding.workflow_family,
                "GitHub Actions workflow": finding.github_workflow,
                "Reference kind": finding.reference_kind,
                "Reference name": finding.reference_name,
                "Syntax family": finding.syntax_family,
                "Reference expression": finding.expression,
                "Line numbers": csv_join(finding.line_numbers, max_items=50),
                "Occurrence count": finding.occurrence_count,
                "Likely built-in": finding.likely_builtin,
                "Definition match": finding.definition_match,
                "Defined scopes": finding.defined_scopes,
                "Migration action": finding.migration_action,
                "Line excerpt": finding.line_excerpt,
            }
        )


def scan_repo_files(
    client: GitHubClient,
    errors: List[Dict[str, Any]],
    org: str,
    repo: str,
    default_branch: str,
    name_index: DefinedNameIndex,
    workflow_file_rows: List[Dict[str, Any]],
    reference_rows: List[Dict[str, Any]],
    max_file_size: int,
    max_ci_files_per_repo: int,
    scan_all_yaml: bool,
    include_line_text: bool,
) -> Tuple[bool, int, int, int, bool]:
    tree, truncated = get_tree_for_repo(client, errors, org, repo, default_branch)
    if not tree:
        return False, 0, 0, 0, truncated

    github_workflow_files = 0
    other_ci_files = 0
    reference_count = 0
    lfs_detected = False
    candidates: List[Dict[str, Any]] = []
    github_workflow_folder_exists = False

    for item in tree:
        if not isinstance(item, dict) or item.get("type") != "blob":
            continue
        path = item.get("path", "")
        if not path:
            continue
        if path.lower().startswith(".github/workflows/"):
            github_workflow_folder_exists = True
        if path.lower() == ".gitattributes":
            candidates.append(item)
            continue
        if is_ci_candidate(path, scan_all_yaml=scan_all_yaml):
            candidates.append(item)

    scanned_files = 0
    for item in candidates:
        path = item.get("path", "")
        if not path:
            continue
        size = int(item.get("size") or 0)
        family, github_workflow = classify_ci_file(path)
        is_gitattributes = path.lower() == ".gitattributes"
        if size > max_file_size:
            workflow_file_rows.append(
                {
                    "Organization": org,
                    "Repository": repo,
                    "Default branch": default_branch,
                    "File path": path,
                    "Workflow family": "Git attributes" if is_gitattributes else family,
                    "GitHub Actions workflow": github_workflow,
                    "File size bytes": size,
                    "Scan status": f"Skipped - larger than max file size {max_file_size}",
                    "Reference findings": 0,
                    "Secret references": 0,
                    "Variable references": 0,
                    "Variable/secret references": 0,
                    "LFS detected": "",
                }
            )
            continue
        if scanned_files >= max_ci_files_per_repo and not is_gitattributes:
            workflow_file_rows.append(
                {
                    "Organization": org,
                    "Repository": repo,
                    "Default branch": default_branch,
                    "File path": path,
                    "Workflow family": family,
                    "GitHub Actions workflow": github_workflow,
                    "File size bytes": size,
                    "Scan status": f"Skipped - max CI files per repo reached ({max_ci_files_per_repo})",
                    "Reference findings": 0,
                    "Secret references": 0,
                    "Variable references": 0,
                    "Variable/secret references": 0,
                    "LFS detected": "",
                }
            )
            continue

        text = fetch_file_text(client, errors, org, repo, path, default_branch)
        if text is None:
            workflow_file_rows.append(
                {
                    "Organization": org,
                    "Repository": repo,
                    "Default branch": default_branch,
                    "File path": path,
                    "Workflow family": "Git attributes" if is_gitattributes else family,
                    "GitHub Actions workflow": github_workflow,
                    "File size bytes": size,
                    "Scan status": "Failed to fetch/decode file content",
                    "Reference findings": 0,
                    "Secret references": 0,
                    "Variable references": 0,
                    "Variable/secret references": 0,
                    "LFS detected": "",
                }
            )
            continue

        if is_gitattributes:
            if "filter=lfs" in text.lower():
                lfs_detected = True
            workflow_file_rows.append(
                {
                    "Organization": org,
                    "Repository": repo,
                    "Default branch": default_branch,
                    "File path": path,
                    "Workflow family": "Git attributes",
                    "GitHub Actions workflow": "No",
                    "File size bytes": size,
                    "Scan status": "Scanned",
                    "Reference findings": 0,
                    "Secret references": 0,
                    "Variable references": 0,
                    "Variable/secret references": 0,
                    "LFS detected": "Yes" if lfs_detected else "No",
                }
            )
            continue

        scanned_files += 1
        if github_workflow == "Yes":
            github_workflow_files += 1
        elif family != "Other":
            other_ci_files += 1

        findings = scan_references_in_text(
            org=org,
            repo=repo,
            default_branch=default_branch,
            file_path=path,
            workflow_family=family,
            github_workflow=github_workflow,
            text=text,
            include_line_text=include_line_text,
        )
        append_reference_rows(reference_rows, findings, name_index)
        secret_refs = sum(1 for f in findings if f.reference_kind == "Secret")
        variable_refs = sum(1 for f in findings if f.reference_kind == "Variable")
        var_secret_refs = sum(1 for f in findings if f.reference_kind == "Variable or secret")
        reference_count += len(findings)
        workflow_file_rows.append(
            {
                "Organization": org,
                "Repository": repo,
                "Default branch": default_branch,
                "File path": path,
                "Workflow family": family,
                "GitHub Actions workflow": github_workflow,
                "File size bytes": size,
                "Scan status": "Scanned",
                "Reference findings": len(findings),
                "Secret references": secret_refs,
                "Variable references": variable_refs,
                "Variable/secret references": var_secret_refs,
                "LFS detected": "",
            }
        )

    return github_workflow_folder_exists, github_workflow_files, other_ci_files, reference_count, lfs_detected or truncated


def maybe_count_errors(errors: List[Dict[str, Any]], org: str, repo: str = "") -> int:
    return sum(
        int(e.get("Occurrences", 1) or 1)
        for e in errors
        if e.get("Severity") != "Info"
        and e.get("Organization") == org
        and (not repo or e.get("Repository") == repo)
    )


def apply_reference_backlinks(
    secret_rows: List[Dict[str, Any]],
    variable_rows: List[Dict[str, Any]],
    reference_rows: List[Dict[str, Any]],
) -> None:
    secret_refs: DefaultDict[Tuple[str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    variable_refs: DefaultDict[Tuple[str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for ref in reference_rows:
        org = ref.get("Organization", "")
        repo = ref.get("Repository", "")
        name = str(ref.get("Reference name", "")).upper()
        kind = ref.get("Reference kind")
        if kind == "Secret":
            secret_refs[(org, repo, name)].append(ref)
            secret_refs[(org, "", name)].append(ref)
        elif kind == "Variable":
            variable_refs[(org, repo, name)].append(ref)
            variable_refs[(org, "", name)].append(ref)
        elif kind == "Variable or secret":
            secret_refs[(org, repo, name)].append(ref)
            secret_refs[(org, "", name)].append(ref)
            variable_refs[(org, repo, name)].append(ref)
            variable_refs[(org, "", name)].append(ref)

    def summarize_refs(refs: List[Dict[str, Any]]) -> Tuple[int, str, str]:
        if not refs:
            return 0, "", ""
        files = sorted({f"{r.get('Repository','')}/{r.get('File path','')}" for r in refs})
        families = sorted({str(r.get("Workflow family", "")) for r in refs if r.get("Workflow family")})
        return len(files), csv_join(families, max_items=20), csv_join(files, max_items=100)

    for row in secret_rows:
        key = (row.get("Organization", ""), row.get("Repository", ""), str(row.get("Secret name", "")).upper())
        refs = secret_refs.get(key, [])
        if not refs and row.get("Repository"):
            refs = secret_refs.get((row.get("Organization", ""), "", str(row.get("Secret name", "")).upper()), [])
        count, families, files = summarize_refs(refs)
        row["Referenced file count"] = count
        row["Referenced workflow families"] = families
        row["Referenced files"] = files

    for row in variable_rows:
        key = (row.get("Organization", ""), row.get("Repository", ""), str(row.get("Variable name", "")).upper())
        refs = variable_refs.get(key, [])
        if not refs and row.get("Repository"):
            refs = variable_refs.get((row.get("Organization", ""), "", str(row.get("Variable name", "")).upper()), [])
        count, families, files = summarize_refs(refs)
        row["Referenced file count"] = count
        row["Referenced workflow families"] = families
        row["Referenced files"] = files


def get_repo_counts_by_org(rows: List[Dict[str, Any]], org: str, column: str) -> int:
    return sum(int(row.get(column, 0) or 0) for row in rows if row.get("Organization") == org)


def build_migration_gap_rows() -> List[Dict[str, Any]]:
    return [
        {
            "Migration gap": "GitHub Actions secrets",
            "GEI behavior": "Not migrated",
            "Script detection": "Actions org/repo/environment secrets by name and scope",
            "Manual action": "Recreate secret values in GHEC at the same scope; GitHub API cannot export secret values",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "GitHub Actions variables",
            "GEI behavior": "Not migrated",
            "Script detection": "Actions org/repo/environment variables by name and scope",
            "Manual action": "Recreate variables in GHEC; export values only if explicitly run with --include-variable-values",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Environments and environment protection rules",
            "GEI behavior": "Not migrated",
            "Script detection": "Repository environments and available protection metadata",
            "Manual action": "Recreate environments, reviewers, wait timers, branch policies, and environment secrets/variables",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Self-hosted runners, runner groups, and larger runners",
            "GEI behavior": "Not migrated / must be reconfigured",
            "Script detection": "Organization and repository self-hosted runners plus runner groups when API permits",
            "Manual action": "Register new runners in GHEC, recreate runner groups, and update workflow labels if needed",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Rulesets",
            "GEI behavior": "Not migrated; destination rulesets can also block migration unless repository migrations are bypassed",
            "Script detection": "Organization and repository rulesets when API is available",
            "Manual action": "Export/recreate rulesets in GHEC and add Repository migrations bypass on destination rulesets before migration if needed",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Workflow artifacts and workflow run history",
            "GEI behavior": "Not migrated",
            "Script detection": "Not exported; workbook identifies repositories with workflow files",
            "Manual action": "Keep GHES read-only/archive as needed for history, or separately export artifacts before cutover",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Dependabot secrets and Codespaces secrets",
            "GEI behavior": "Not migrated",
            "Script detection": "Dependabot and Codespaces secrets where the source API supports these endpoints",
            "Manual action": "Recreate in GHEC if these features will be used",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Webhooks and webhook secrets",
            "GEI behavior": "Active webhooks may migrate but must be re-enabled; webhook secrets are not migrated",
            "Script detection": "Org and repo webhooks where API permits; secret values are not returned",
            "Manual action": "Re-enable hooks in GHEC and reset webhook secrets",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "GitHub Apps and installations",
            "GEI behavior": "Not migrated",
            "Script detection": "Organization app installations when API permits",
            "Manual action": "Install apps in the destination enterprise/org and restore required repository access",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Git LFS objects",
            "GEI behavior": "Not migrated",
            "Script detection": "Best-effort detection from .gitattributes filter=lfs",
            "Manual action": "Push LFS objects separately after repository migration",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
        {
            "Migration gap": "Teams, users, and repository access",
            "GEI behavior": "Not migrated for GHES repository migrations",
            "Script detection": "Team count only; detailed access inventory is intentionally not expanded by default",
            "Manual action": "Plan organization/team structure and repository permissions separately",
            "Docs URL": DOCS_GEI_DATA_URL,
        },
    ]


def style_worksheet(ws, table_name: str = "") -> None:
    ws.freeze_panes = "A2"
    ws.sheet_view.showGridLines = False
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    thin_gray = Side(style="thin", color="D9E2F3")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=thin_gray)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.auto_filter.ref = ws.dimensions
    if table_name and ws.max_row >= 2 and ws.max_column >= 1:
        ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
        safe_name = re.sub(r"[^A-Za-z0-9_]", "_", table_name)[:240]
        if not safe_name[0].isalpha():
            safe_name = "T_" + safe_name
        table = Table(displayName=safe_name, ref=ref)
        style = TableStyleInfo(name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        table.tableStyleInfo = style
        try:
            ws.add_table(table)
        except Exception:
            pass
    for col_idx in range(1, ws.max_column + 1):
        letter = get_column_letter(col_idx)
        max_len = 0
        for cell in ws[letter]:
            try:
                max_len = max(max_len, len(str(cell.value or "")))
            except Exception:
                pass
        ws.column_dimensions[letter].width = min(max(12, max_len + 2), 55)
    ws.row_dimensions[1].height = 28


def write_sheet(wb: Workbook, title: str, headers: List[str], rows: List[Dict[str, Any]], table_name: str) -> None:
    ws = wb.create_sheet(title=title)
    ws.append(headers)
    for row in rows:
        ws.append([clean_cell(row.get(header, "")) for header in headers])
    style_worksheet(ws, table_name=table_name)


def write_workbook(
    output_path: str,
    run_info: Dict[str, Any],
    org_summary_rows: List[Dict[str, Any]],
    repo_rows: List[Dict[str, Any]],
    secret_rows: List[Dict[str, Any]],
    variable_rows: List[Dict[str, Any]],
    reference_rows: List[Dict[str, Any]],
    workflow_file_rows: List[Dict[str, Any]],
    environment_rows: List[Dict[str, Any]],
    runner_rows: List[Dict[str, Any]],
    runner_group_rows: List[Dict[str, Any]],
    ruleset_rows: List[Dict[str, Any]],
    webhook_rows: List[Dict[str, Any]],
    app_installation_rows: List[Dict[str, Any]],
    team_rows: List[Dict[str, Any]],
    errors: List[Dict[str, Any]],
) -> None:
    wb = Workbook()
    default = wb.active
    wb.remove(default)

    run_headers = ["Key", "Value"]
    run_rows = [{"Key": k, "Value": v} for k, v in run_info.items()]
    write_sheet(wb, "Run Info", run_headers, run_rows, "Run_Info")
    # Add comments with docs URLs to Run Info rows where relevant.
    ws_run = wb["Run Info"]
    for row_idx in range(2, ws_run.max_row + 1):
        key = str(ws_run.cell(row_idx, 1).value or "")
        if key == "GEI migrated/not migrated reference":
            ws_run.cell(row_idx, 2).comment = Comment(DOCS_GEI_DATA_URL, "inventory-script")

    org_headers = [
        "Organization",
        "Token user role",
        "Scan status",
        "API issue occurrences",
        "Unique API issue rows",
        "Scan duration seconds",
        "Repository count",
        "Repos with GitHub Actions workflows",
        "Repos with other CI files",
        "Repos with Git LFS detected",
        "Actions org secrets",
        "Actions repo secrets",
        "Actions environment secrets",
        "Actions org variables",
        "Actions repo variables",
        "Actions environment variables",
        "Dependabot secrets",
        "Codespaces secrets",
        "Environments",
        "Org self-hosted runners",
        "Repo self-hosted runners",
        "Runner groups",
        "Org rulesets",
        "Repo rulesets",
        "Workflow reference findings",
        "Unmatched reference findings",
        "Webhooks",
        "GitHub App installations",
        "Teams",
        "Notes",
    ]
    write_sheet(wb, "Org Summary", org_headers, org_summary_rows, "Org_Summary")

    repo_headers = [
        "Organization",
        "Repository",
        "Full name",
        "Visibility",
        "Archived",
        "Disabled",
        "Default branch",
        "Has GitHub workflow folder",
        "GitHub workflow files scanned",
        "Other CI files scanned",
        "Workflow reference findings",
        "LFS detected",
        "Actions repo secrets",
        "Actions repo variables",
        "Environment count",
        "Environment secrets",
        "Environment variables",
        "Repo runners",
        "Repo rulesets",
        "Repo webhooks",
        "API error count",
        "Scan notes",
        "HTML URL",
    ]
    write_sheet(wb, "Repo Details", repo_headers, repo_rows, "Repo_Details")

    secret_headers = [
        "Organization",
        "Repository",
        "Environment",
        "Secret category",
        "Scope",
        "Secret name",
        "Visibility",
        "Selected repository count",
        "Selected repositories",
        "Created at",
        "Updated at",
        "Value exported",
        "Migration action",
        "Referenced file count",
        "Referenced workflow families",
        "Referenced files",
    ]
    write_sheet(wb, "Secrets", secret_headers, secret_rows, "Secrets")

    variable_headers = [
        "Organization",
        "Repository",
        "Environment",
        "Variable category",
        "Scope",
        "Variable name",
        "Variable value",
        "Visibility",
        "Selected repository count",
        "Selected repositories",
        "Created at",
        "Updated at",
        "Migration action",
        "Referenced file count",
        "Referenced workflow families",
        "Referenced files",
    ]
    write_sheet(wb, "Variables", variable_headers, variable_rows, "Variables")

    reference_headers = [
        "Organization",
        "Repository",
        "Default branch",
        "File path",
        "Workflow family",
        "GitHub Actions workflow",
        "Reference kind",
        "Reference name",
        "Syntax family",
        "Reference expression",
        "Line numbers",
        "Occurrence count",
        "Likely built-in",
        "Definition match",
        "Defined scopes",
        "Migration action",
        "Line excerpt",
    ]
    write_sheet(wb, "Workflow References", reference_headers, reference_rows, "Workflow_References")

    workflow_headers = [
        "Organization",
        "Repository",
        "Default branch",
        "File path",
        "Workflow family",
        "GitHub Actions workflow",
        "File size bytes",
        "Scan status",
        "Reference findings",
        "Secret references",
        "Variable references",
        "Variable/secret references",
        "LFS detected",
    ]
    write_sheet(wb, "Workflow Files", workflow_headers, workflow_file_rows, "Workflow_Files")

    env_headers = [
        "Organization",
        "Repository",
        "Environment",
        "Created at",
        "Updated at",
        "Protection rules count",
        "Protection rules",
        "Deployment branch policy",
        "Environment secrets",
        "Environment variables",
        "HTML URL",
        "Migration action",
    ]
    write_sheet(wb, "Environments", env_headers, environment_rows, "Environments")

    runner_headers = [
        "Organization",
        "Repository",
        "Scope",
        "Runner ID",
        "Runner name",
        "OS",
        "Architecture",
        "Status",
        "Busy",
        "Ephemeral",
        "Labels",
        "Migration action",
    ]
    write_sheet(wb, "Runners", runner_headers, runner_rows, "Runners")

    runner_group_headers = [
        "Organization",
        "Runner group ID",
        "Runner group name",
        "Visibility",
        "Default",
        "Selected repository count",
        "Selected repositories",
        "Runners URL",
        "Migration action",
    ]
    write_sheet(wb, "Runner Groups", runner_group_headers, runner_group_rows, "Runner_Groups")

    ruleset_headers = [
        "Organization",
        "Repository",
        "Scope",
        "Ruleset ID",
        "Ruleset name",
        "Target",
        "Enforcement",
        "Source type",
        "Source",
        "Rule count",
        "Rule types",
        "Conditions",
        "Bypass actors count",
        "Created at",
        "Updated at",
        "Migration action",
    ]
    write_sheet(wb, "Rulesets", ruleset_headers, ruleset_rows, "Rulesets")

    webhook_headers = [
        "Organization",
        "Repository",
        "Scope",
        "Hook ID",
        "Hook name",
        "Active",
        "Events",
        "URL",
        "Content type",
        "Insecure SSL",
        "Secret exported",
        "Updated at",
        "Created at",
        "Migration action",
    ]
    write_sheet(wb, "Webhooks", webhook_headers, webhook_rows, "Webhooks")

    app_headers = [
        "Organization",
        "Installation ID",
        "App ID",
        "App slug",
        "App name",
        "Repository selection",
        "Suspended by",
        "Suspended at",
        "Permissions",
        "Events",
        "Migration action",
    ]
    write_sheet(wb, "App Installations", app_headers, app_installation_rows, "App_Installations")

    team_headers = [
        "Organization",
        "Team ID",
        "Team name",
        "Slug",
        "Privacy",
        "Permission",
        "Parent team",
        "Description",
        "Migration action",
    ]
    write_sheet(wb, "Teams", team_headers, team_rows, "Teams")

    gap_headers = ["Migration gap", "GEI behavior", "Script detection", "Manual action", "Docs URL"]
    write_sheet(wb, "Migration Gaps", gap_headers, build_migration_gap_rows(), "Migration_Gaps")

    error_headers = [
        "Organization",
        "Repository",
        "Endpoint group",
        "Endpoint",
        "HTTP status",
        "Severity",
        "Classification",
        "Message",
        "Likely cause",
        "Recommended action",
        "Occurrences",
        "URL",
    ]
    write_sheet(wb, "API Errors", error_headers, errors, "API_Errors")

    # Make the most important tabs first and visually distinct.
    for ws in wb.worksheets:
        if ws.title in {"Org Summary", "Secrets", "Variables", "Workflow References", "API Errors"}:
            ws.sheet_properties.tabColor = "1F4E78"
        elif ws.title == "Migration Gaps":
            ws.sheet_properties.tabColor = "F4B183"

    output_dir = os.path.dirname(os.path.abspath(output_path))
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    wb.save(output_path)


def prompt_text(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or default


def prompt_yes_no(label: str, default: bool = True) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    value = input(label + suffix + ": ").strip().lower()
    if not value:
        return default
    return value in {"y", "yes", "1", "true"}


def apply_scan_profile(args: argparse.Namespace) -> None:
    profile = (args.profile or "standard").lower()
    if profile == "quick":
        args.no_selected_repos = True
        args.skip_webhooks = True
        args.skip_apps = True
        args.skip_teams = True
        args.skip_dependabot_codespaces = True
        args.scan_all_yaml = False
        args.max_ci_files_per_repo = min(args.max_ci_files_per_repo, 100)
    elif profile == "deep":
        args.scan_all_yaml = True
        args.max_ci_files_per_repo = max(args.max_ci_files_per_repo, 500)
    else:
        args.profile = "standard"
        args.scan_all_yaml = False


def configure_interactive(args: argparse.Namespace) -> argparse.Namespace:
    log("\nGitHub GEI migration-gap inventory")
    log("This wizard will validate access, discover organizations, scan them in parallel, and write one Excel workbook.\n")

    default_api = args.api_url or os.getenv("GITHUB_API_URL") or "https://github.int.inceptionai.ai/api/v3"
    args.api_url = prompt_text("GHES REST API URL", default_api)
    args.output = prompt_text("Output Excel file", args.output)

    log("\nScan profile:")
    log("  1. Quick    - core secrets/variables/environments/runners/rulesets and targeted CI files")
    log("  2. Standard - recommended; also webhooks, apps, teams, Dependabot/Codespaces probes")
    log("  3. Deep     - scans all YAML/JSON/TOML/Groovy-like files; most API calls")
    choice = prompt_text("Choose profile 1/2/3", {"quick": "1", "standard": "2", "deep": "3"}.get(args.profile, "2"))
    args.profile = {"1": "quick", "2": "standard", "3": "deep"}.get(choice, choice.lower())

    default_workers = max(1, min(args.workers, 8))
    workers_text = prompt_text("Parallel organization workers", str(default_workers))
    try:
        args.workers = max(1, min(int(workers_text), 16))
    except ValueError:
        args.workers = default_workers

    if not args.orgs:
        auto = prompt_yes_no("Automatically discover all organizations visible to the token", True)
        if not auto:
            args.orgs = prompt_text("Comma-separated organizations")
    args.no_ssl_verify = not prompt_yes_no("Verify the GHES TLS certificate", not args.no_ssl_verify)

    token = args.token or os.getenv("GH_PAT") or os.getenv("GITHUB_TOKEN") or os.getenv("GH_TOKEN")
    if not token:
        args.token = getpass.getpass("GHES personal access token: ").strip()
    apply_scan_profile(args)

    log("\nSelected configuration:")
    log(f"  API URL : {args.api_url}")
    log(f"  Output  : {args.output}")
    log(f"  Profile : {args.profile}")
    log(f"  Workers : {args.workers}")
    log(f"  Orgs    : {'explicit list' if args.orgs else 'automatic discovery'}")
    log("")
    if not prompt_yes_no("Start scan", True):
        raise SystemExit("Cancelled")
    return args


def scan_inventory(args: argparse.Namespace) -> None:
    global CIRCUIT_THRESHOLD
    CIRCUIT_THRESHOLD = max(1, int(args.repeated_404_limit))
    scan_started = time.monotonic()
    with ISSUE_LOCK:
        ISSUE_INDEX.clear()
    with CIRCUIT_LOCK:
        CIRCUIT_404_COUNTS.clear()
        CIRCUIT_OPEN.clear()

    token = args.token or os.getenv("GH_PAT") or os.getenv("GITHUB_TOKEN") or os.getenv("GH_TOKEN")
    if not token:
        raise SystemExit("Missing token. Set GH_PAT or GITHUB_TOKEN, or pass --token.")

    api_url = args.api_url or os.getenv("GITHUB_API_URL") or "https://api.github.com"
    api_version = args.api_version if args.api_version is not None else os.getenv("GITHUB_API_VERSION", DEFAULT_API_VERSION)
    client = GitHubClient(
        api_url=api_url,
        token=token,
        api_version=api_version,
        verify_ssl=not args.no_ssl_verify,
        timeout=args.timeout,
        auth_scheme=args.auth_scheme,
        rate_limit_sleep_max=args.rate_limit_sleep_max,
        verbose=args.verbose,
    )

    errors: List[Dict[str, Any]] = []

    log(f"[INFO] API URL: {client.api_url}")
    log(f"[INFO] REST API version header: {api_version or '[not sent]'}")
    log(f"[INFO] Script version: {SCRIPT_VERSION}")
    log(f"[INFO] Scan profile: {args.profile}; requested workers: {args.workers}; repeated-404 limit: {CIRCUIT_THRESHOLD}")
    try:
        user, auth_response = client.request("GET", "/user", context="Authentication")
    except ApiError as exc:
        add_error(errors, endpoint_group="Authentication", endpoint="/user", error=exc)
        raise SystemExit("Authentication failed. Check the token, API URL, SSL, and PAT authorization/SSO.") from exc
    if not isinstance(user, dict) or not user.get("login"):
        raise SystemExit("Authentication failed. The /user endpoint did not return a login.")
    scope_header = auth_response.headers.get("X-OAuth-Scopes", "")
    client.token_scopes = parse_scope_header(scope_header)
    client.scope_header_present = bool(scope_header.strip())
    log(f"[INFO] Authenticated as: {user.get('login')}")
    if client.scope_header_present:
        log("[INFO] Classic PAT scopes reported by GHES: " + (", ".join(sorted(client.token_scopes)) or "[none]"))
        missing_scopes = [scope for scope in ("repo", "admin:org") if scope not in client.token_scopes]
        if missing_scopes:
            log("[ACCESS] Missing recommended classic PAT scope(s): " + ", ".join(missing_scopes))
            log("[ACCESS] GitHub may return 404 Not Found for private/admin endpoints when these scopes or owner permissions are missing.")
    else:
        log("[INFO] GHES did not report classic PAT scopes; the token may be fine-grained or the server may omit this header.")

    meta = safe_get(client, errors, "", "", "GHES metadata", "/meta", default={})
    ghes_version = ""
    if isinstance(meta, dict):
        ghes_version = str(meta.get("installed_version") or meta.get("verifiable_password_authentication") or "")
    if not is_github_com_api(client.api_url):
        client.skip_codespaces = not args.force_codespaces
        log(f"[INFO] GHES detected; installed version: {ghes_version or '[not returned by /meta]'}")
        if client.skip_codespaces and not args.skip_dependabot_codespaces:
            log("[INFO] Codespaces API calls will be skipped automatically for the GHES source.")

    org_roles: Dict[str, str] = {}
    org_value = args.orgs
    if not org_value and args.use_env_orgs:
        org_value = os.getenv("GITHUB_ORGS", "")
    elif not org_value and os.getenv("GITHUB_ORGS"):
        log("[INFO] Ignoring existing GITHUB_ORGS because automatic discovery is the default. Use --use-env-orgs to opt in.")

    orgs = split_orgs(org_value)
    if orgs:
        log(f"[INFO] Organizations from explicit configuration: {len(orgs)}")
        for org in orgs:
            membership = safe_get(
                client,
                errors,
                org,
                "",
                "Organization membership preflight",
                f"/user/memberships/orgs/{quote_path_part(org)}",
                default={},
            )
            if isinstance(membership, dict):
                org_roles[org] = str(membership.get("role") or "unknown")
            else:
                org_roles[org] = "unknown"
    else:
        log("[INFO] Discovering active organizations and owner/member roles visible to the token...")
        orgs, org_roles = discover_org_memberships(client, errors)
        log(f"[INFO] Organizations discovered: {len(orgs)}")
    if not orgs:
        raise SystemExit("No organizations found. Verify membership visibility or pass --orgs explicitly.")
    client.org_roles = org_roles
    owner_orgs = [org for org in orgs if org_roles.get(org) == "admin"]
    member_orgs = [org for org in orgs if org_roles.get(org) == "member"]
    unknown_orgs = [org for org in orgs if org_roles.get(org, "unknown") not in {"admin", "member"}]
    log("[INFO] Organizations: " + ", ".join(orgs))
    log(f"[ACCESS] Organization roles: owner={len(owner_orgs)}, member={len(member_orgs)}, unknown={len(unknown_orgs)}")
    if member_orgs:
        log("[ACCESS] Org-admin endpoints will be skipped for member-only organizations: " + ", ".join(member_orgs))
        log("[ACCESS] For complete secrets/runners/org-variable inventory, use a token owned by an owner of every organization.")

    org_summary_rows: List[Dict[str, Any]] = []
    repo_rows: List[Dict[str, Any]] = []
    secret_rows: List[Dict[str, Any]] = []
    variable_rows: List[Dict[str, Any]] = []
    reference_rows: List[Dict[str, Any]] = []
    workflow_file_rows: List[Dict[str, Any]] = []
    environment_rows: List[Dict[str, Any]] = []
    runner_rows: List[Dict[str, Any]] = []
    runner_group_rows: List[Dict[str, Any]] = []
    ruleset_rows: List[Dict[str, Any]] = []
    webhook_rows: List[Dict[str, Any]] = []
    app_installation_rows: List[Dict[str, Any]] = []
    team_rows: List[Dict[str, Any]] = []
    name_index = DefinedNameIndex()

    def scan_one_org(org: str) -> None:
        org_started = time.monotonic()
        org_role = org_roles.get(org, "unknown")
        log(f"[ORG] {org}: starting scan (role={org_role})")
        org_error_count_before = maybe_count_errors(errors, org)
        org_notes: List[str] = []

        repos = safe_paginated(
            client,
            errors,
            org,
            "",
            "Repositories",
            f"/orgs/{quote_path_part(org)}/repos",
            params={"type": "all"},
        )
        if args.max_repos_per_org and len(repos) > args.max_repos_per_org:
            org_notes.append(f"Repo scan limited to first {args.max_repos_per_org} repositories")
            repos = repos[: args.max_repos_per_org]
        repo_total_for_org = len([r for r in repos if isinstance(r, dict)])
        log(f"[ORG] {org}: {repo_total_for_org} repositories found")

        # Organization-level Actions secrets and variables.
        org_actions_secret_count = 0
        org_actions_var_count = 0
        org_dependabot_secret_count = 0
        org_codespaces_secret_count = 0

        org_secrets = safe_paginated(
            client,
            errors,
            org,
            "",
            "Actions org secrets",
            f"/orgs/{quote_path_part(org)}/actions/secrets",
            item_key="secrets",
        )
        for secret in org_secrets:
            if not isinstance(secret, dict):
                continue
            selected_count = 0
            selected_names = ""
            if secret.get("visibility") == "selected":
                selected_count, selected_names = list_selected_repos(
                    client,
                    errors,
                    org,
                    "Actions org secret selected repositories",
                    secret.get("selected_repositories_url", ""),
                    secret.get("name", ""),
                    enabled=not args.no_selected_repos,
                )
            add_secret_row(secret_rows, name_index, org, "", "", secret, "Actions", "Organization", selected_repo_count=selected_count, selected_repo_names=selected_names)
            org_actions_secret_count += 1

        org_vars = safe_paginated(
            client,
            errors,
            org,
            "",
            "Actions org variables",
            f"/orgs/{quote_path_part(org)}/actions/variables",
            item_key="variables",
        )
        for var in org_vars:
            if not isinstance(var, dict):
                continue
            selected_count = 0
            selected_names = ""
            if var.get("visibility") == "selected":
                selected_count, selected_names = list_selected_repos(
                    client,
                    errors,
                    org,
                    "Actions org variable selected repositories",
                    var.get("selected_repositories_url", ""),
                    var.get("name", ""),
                    enabled=not args.no_selected_repos,
                )
            add_variable_row(variable_rows, name_index, org, "", "", var, "Organization", include_values=args.include_variable_values, selected_repo_count=selected_count, selected_repo_names=selected_names)
            org_actions_var_count += 1

        # Organization Dependabot/Codespaces secrets. These endpoints may not exist on all GHES versions.
        if not args.skip_dependabot_codespaces:
            dep_secrets = safe_paginated(
                client,
                errors,
                org,
                "",
                "Dependabot org secrets",
                f"/orgs/{quote_path_part(org)}/dependabot/secrets",
                item_key="secrets",
            )
            for secret in dep_secrets:
                if isinstance(secret, dict):
                    selected_count = 0
                    selected_names = ""
                    if secret.get("visibility") == "selected":
                        selected_count, selected_names = list_selected_repos(
                            client,
                            errors,
                            org,
                            "Dependabot org secret selected repositories",
                            secret.get("selected_repositories_url", ""),
                            secret.get("name", ""),
                            enabled=not args.no_selected_repos,
                        )
                    add_secret_row(secret_rows, name_index, org, "", "", secret, "Dependabot", "Organization", selected_repo_count=selected_count, selected_repo_names=selected_names)
                    org_dependabot_secret_count += 1

            codespaces_secrets = safe_paginated(
                client,
                errors,
                org,
                "",
                "Codespaces org secrets",
                f"/orgs/{quote_path_part(org)}/codespaces/secrets",
                item_key="secrets",
            )
            for secret in codespaces_secrets:
                if isinstance(secret, dict):
                    selected_count = 0
                    selected_names = ""
                    if secret.get("visibility") == "selected":
                        selected_count, selected_names = list_selected_repos(
                            client,
                            errors,
                            org,
                            "Codespaces org secret selected repositories",
                            secret.get("selected_repositories_url", ""),
                            secret.get("name", ""),
                            enabled=not args.no_selected_repos,
                        )
                    add_secret_row(secret_rows, name_index, org, "", "", secret, "Codespaces", "Organization", selected_repo_count=selected_count, selected_repo_names=selected_names)
                    org_codespaces_secret_count += 1

        # Runners and runner groups.
        org_runner_count = 0
        org_runners = safe_paginated(
            client,
            errors,
            org,
            "",
            "Org self-hosted runners",
            f"/orgs/{quote_path_part(org)}/actions/runners",
            item_key="runners",
        )
        for runner in org_runners:
            if not isinstance(runner, dict):
                continue
            labels = [lbl.get("name") for lbl in runner.get("labels", []) if isinstance(lbl, dict)]
            runner_rows.append(
                {
                    "Organization": org,
                    "Repository": "",
                    "Scope": "Organization",
                    "Runner ID": runner.get("id", ""),
                    "Runner name": runner.get("name", ""),
                    "OS": runner.get("os", ""),
                    "Architecture": runner.get("architecture", ""),
                    "Status": runner.get("status", ""),
                    "Busy": runner.get("busy", ""),
                    "Ephemeral": runner.get("ephemeral", ""),
                    "Labels": csv_join(labels, max_items=100),
                    "Migration action": "Register equivalent runner in GHEC and validate workflow labels",
                }
            )
            org_runner_count += 1

        runner_groups = safe_paginated(
            client,
            errors,
            org,
            "",
            "Runner groups",
            f"/orgs/{quote_path_part(org)}/actions/runner-groups",
            item_key="runner_groups",
        )
        runner_group_count = 0
        for group in runner_groups:
            if not isinstance(group, dict):
                continue
            selected_count = 0
            selected_names = ""
            if group.get("visibility") == "selected":
                repos_for_group = safe_paginated(
                    client,
                    errors,
                    org,
                    "",
                    "Runner group selected repositories",
                    f"/orgs/{quote_path_part(org)}/actions/runner-groups/{group.get('id')}/repositories",
                    item_key="repositories",
                )
                selected_names_list = [r.get("full_name") or r.get("name") for r in repos_for_group if isinstance(r, dict)]
                selected_count = len(selected_names_list)
                selected_names = csv_join(selected_names_list, max_items=200)
            runner_group_rows.append(
                {
                    "Organization": org,
                    "Runner group ID": group.get("id", ""),
                    "Runner group name": group.get("name", ""),
                    "Visibility": group.get("visibility", ""),
                    "Default": group.get("default", ""),
                    "Selected repository count": selected_count,
                    "Selected repositories": selected_names,
                    "Runners URL": group.get("runners_url", ""),
                    "Migration action": "Recreate runner group in GHEC and assign selected repositories/runners",
                }
            )
            runner_group_count += 1

        # Organization rulesets.
        org_ruleset_count = 0
        org_rulesets = safe_paginated(
            client,
            errors,
            org,
            "",
            "Org rulesets",
            f"/orgs/{quote_path_part(org)}/rulesets",
        )
        for ruleset in org_rulesets:
            if not isinstance(ruleset, dict):
                continue
            ruleset_id = ruleset.get("id")
            details = ruleset
            if ruleset_id:
                maybe_details = safe_get(
                    client,
                    errors,
                    org,
                    "",
                    "Org ruleset details",
                    f"/orgs/{quote_path_part(org)}/rulesets/{ruleset_id}",
                    default=ruleset,
                )
                if isinstance(maybe_details, dict):
                    details = maybe_details
            rule_types, rule_count, conditions, bypass_count = summarize_ruleset_rules(details)
            ruleset_rows.append(
                {
                    "Organization": org,
                    "Repository": "",
                    "Scope": "Organization",
                    "Ruleset ID": details.get("id", ""),
                    "Ruleset name": details.get("name", ""),
                    "Target": details.get("target", ""),
                    "Enforcement": details.get("enforcement", ""),
                    "Source type": details.get("source_type", ""),
                    "Source": details.get("source", ""),
                    "Rule count": rule_count,
                    "Rule types": rule_types,
                    "Conditions": conditions,
                    "Bypass actors count": bypass_count,
                    "Created at": details.get("created_at", ""),
                    "Updated at": details.get("updated_at", ""),
                    "Migration action": "Recreate organization ruleset in GHEC; add Repository migrations bypass on destination rulesets before migration if applicable",
                }
            )
            org_ruleset_count += 1

        # Organization webhooks, app installations, and teams.
        org_webhook_count = 0
        if not args.skip_webhooks:
            org_hooks = safe_paginated(client, errors, org, "", "Org webhooks", f"/orgs/{quote_path_part(org)}/hooks", item_key="hooks")
            for hook in org_hooks:
                if not isinstance(hook, dict):
                    continue
                config = hook.get("config", {}) or {}
                webhook_rows.append(
                    {
                        "Organization": org,
                        "Repository": "",
                        "Scope": "Organization",
                        "Hook ID": hook.get("id", ""),
                        "Hook name": hook.get("name", ""),
                        "Active": hook.get("active", ""),
                        "Events": csv_join(hook.get("events", []), max_items=100),
                        "URL": config.get("url", ""),
                        "Content type": config.get("content_type", ""),
                        "Insecure SSL": config.get("insecure_ssl", ""),
                        "Secret exported": "No - webhook secret values are not returned",
                        "Updated at": hook.get("updated_at", ""),
                        "Created at": hook.get("created_at", ""),
                        "Migration action": "Re-enable/recreate hook in GHEC and reset webhook secret if used",
                    }
                )
                org_webhook_count += 1

        app_installation_count = 0
        if not args.skip_apps:
            installations = safe_paginated(client, errors, org, "", "GitHub App installations", f"/orgs/{quote_path_part(org)}/installations", item_key="installations")
            for inst in installations:
                if not isinstance(inst, dict):
                    continue
                app = inst.get("app_slug") or (inst.get("app_id") if inst.get("app_id") else "")
                app_installation_rows.append(
                    {
                        "Organization": org,
                        "Installation ID": inst.get("id", ""),
                        "App ID": inst.get("app_id", ""),
                        "App slug": inst.get("app_slug", ""),
                        "App name": (inst.get("app_slug") or app),
                        "Repository selection": inst.get("repository_selection", ""),
                        "Suspended by": json_compact(inst.get("suspended_by")),
                        "Suspended at": inst.get("suspended_at", ""),
                        "Permissions": json_compact(inst.get("permissions")),
                        "Events": csv_join(inst.get("events", []), max_items=200),
                        "Migration action": "Install/configure equivalent GitHub App in GHEC and restore repository access",
                    }
                )
                app_installation_count += 1

        team_count = 0
        if not args.skip_teams:
            teams = safe_paginated(client, errors, org, "", "Teams", f"/orgs/{quote_path_part(org)}/teams", item_key=None)
            for team in teams:
                if not isinstance(team, dict):
                    continue
                parent = team.get("parent") or {}
                team_rows.append(
                    {
                        "Organization": org,
                        "Team ID": team.get("id", ""),
                        "Team name": team.get("name", ""),
                        "Slug": team.get("slug", ""),
                        "Privacy": team.get("privacy", ""),
                        "Permission": team.get("permission", ""),
                        "Parent team": parent.get("name", "") if isinstance(parent, dict) else "",
                        "Description": team.get("description", ""),
                        "Migration action": "Plan/recreate team and repository access in GHEC; detailed membership is not expanded by default",
                    }
                )
                team_count += 1

        repo_secret_total = 0
        repo_var_total = 0
        env_count_total = 0
        env_secret_total = 0
        env_var_total = 0
        repo_runner_total = 0
        repo_ruleset_total = 0
        repos_with_github_workflows = 0
        repos_with_other_ci = 0
        workflow_reference_total = 0
        repos_with_lfs = 0
        repo_webhook_total = 0

        repo_progress_index = 0
        for repo_obj in repos:
            if not isinstance(repo_obj, dict):
                continue
            repo_progress_index += 1
            owner, repo = extract_repo_owner_name(repo_obj)
            if not repo:
                continue
            if repo_progress_index == 1 or repo_progress_index == repo_total_for_org or repo_progress_index % max(1, args.progress_every) == 0:
                stats = client.stats()
                rate_text = ""
                if stats.get("rate_remaining"):
                    rate_text = f" | rate {stats.get('rate_remaining')}/{stats.get('rate_limit') or '?'}"
                log(f"[PROGRESS] {org}: repo {repo_progress_index}/{repo_total_for_org} - {repo} | API calls {stats.get('requests')}{rate_text}")
            default_branch = repo_obj.get("default_branch") or ""
            full_name = repo_obj.get("full_name") or f"{org}/{repo}"
            repo_error_count_before = maybe_count_errors(errors, org, repo)
            scan_notes: List[str] = []
            if repo_obj.get("archived"):
                scan_notes.append("Archived")
            if repo_obj.get("disabled"):
                scan_notes.append("Disabled")
            if not default_branch:
                scan_notes.append("No default branch/empty repository")

            # Repository Actions secrets / variables.
            repo_secrets = safe_paginated(
                client,
                errors,
                org,
                repo,
                "Actions repo secrets",
                f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/actions/secrets",
                item_key="secrets",
            )
            for secret in repo_secrets:
                if isinstance(secret, dict):
                    add_secret_row(secret_rows, name_index, org, repo, "", secret, "Actions", "Repository")
            repo_secret_count = len([s for s in repo_secrets if isinstance(s, dict)])
            repo_secret_total += repo_secret_count

            repo_vars = safe_paginated(
                client,
                errors,
                org,
                repo,
                "Actions repo variables",
                f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/actions/variables",
                item_key="variables",
            )
            for var in repo_vars:
                if isinstance(var, dict):
                    add_variable_row(variable_rows, name_index, org, repo, "", var, "Repository", include_values=args.include_variable_values)
            repo_var_count = len([v for v in repo_vars if isinstance(v, dict)])
            repo_var_total += repo_var_count

            if not args.skip_dependabot_codespaces:
                repo_dep_secrets = safe_paginated(
                    client,
                    errors,
                    org,
                    repo,
                    "Dependabot repo secrets",
                    f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/dependabot/secrets",
                    item_key="secrets",
                )
                for secret in repo_dep_secrets:
                    if isinstance(secret, dict):
                        add_secret_row(secret_rows, name_index, org, repo, "", secret, "Dependabot", "Repository")
                        org_dependabot_secret_count += 1

                # This endpoint may not exist on all products/versions; errors are captured if unavailable.
                repo_codespaces_secrets = safe_paginated(
                    client,
                    errors,
                    org,
                    repo,
                    "Codespaces repo secrets",
                    f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/codespaces/secrets",
                    item_key="secrets",
                )
                for secret in repo_codespaces_secrets:
                    if isinstance(secret, dict):
                        add_secret_row(secret_rows, name_index, org, repo, "", secret, "Codespaces", "Repository")
                        org_codespaces_secret_count += 1

            # Environments and environment-scoped secrets/variables.
            envs = safe_paginated(
                client,
                errors,
                org,
                repo,
                "Environments",
                f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/environments",
                item_key="environments",
            )
            env_count = len([e for e in envs if isinstance(e, dict)])
            env_count_total += env_count
            repo_env_secret_count = 0
            repo_env_var_count = 0
            for env in envs:
                if not isinstance(env, dict):
                    continue
                env_name = env.get("name", "")
                if not env_name:
                    continue
                env_detail = safe_get(
                    client,
                    errors,
                    org,
                    repo,
                    "Environment details",
                    f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/environments/{quote_path_part(env_name)}",
                    default=env,
                )
                if not isinstance(env_detail, dict):
                    env_detail = env
                env_secrets = safe_paginated(
                    client,
                    errors,
                    org,
                    repo,
                    "Environment secrets",
                    f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/environments/{quote_path_part(env_name)}/secrets",
                    item_key="secrets",
                )
                for secret in env_secrets:
                    if isinstance(secret, dict):
                        add_secret_row(secret_rows, name_index, org, repo, env_name, secret, "Actions", "Environment")
                env_secret_count = len([s for s in env_secrets if isinstance(s, dict)])
                repo_env_secret_count += env_secret_count
                env_secret_total += env_secret_count

                env_vars = safe_paginated(
                    client,
                    errors,
                    org,
                    repo,
                    "Environment variables",
                    f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/environments/{quote_path_part(env_name)}/variables",
                    item_key="variables",
                )
                for var in env_vars:
                    if isinstance(var, dict):
                        add_variable_row(variable_rows, name_index, org, repo, env_name, var, "Environment", include_values=args.include_variable_values)
                env_var_count = len([v for v in env_vars if isinstance(v, dict)])
                repo_env_var_count += env_var_count
                env_var_total += env_var_count

                protection_rules = env_detail.get("protection_rules") or []
                if not isinstance(protection_rules, list):
                    protection_rules = []
                environment_rows.append(
                    {
                        "Organization": org,
                        "Repository": repo,
                        "Environment": env_name,
                        "Created at": env_detail.get("created_at", ""),
                        "Updated at": env_detail.get("updated_at", ""),
                        "Protection rules count": len(protection_rules),
                        "Protection rules": json_compact(protection_rules),
                        "Deployment branch policy": json_compact(env_detail.get("deployment_branch_policy")),
                        "Environment secrets": env_secret_count,
                        "Environment variables": env_var_count,
                        "HTML URL": env_detail.get("html_url", ""),
                        "Migration action": "Recreate environment and its protection rules, secrets, and variables in GHEC",
                    }
                )

            # Repository runners.
            repo_runners = safe_paginated(
                client,
                errors,
                org,
                repo,
                "Repo self-hosted runners",
                f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/actions/runners",
                item_key="runners",
            )
            for runner in repo_runners:
                if not isinstance(runner, dict):
                    continue
                labels = [lbl.get("name") for lbl in runner.get("labels", []) if isinstance(lbl, dict)]
                runner_rows.append(
                    {
                        "Organization": org,
                        "Repository": repo,
                        "Scope": "Repository",
                        "Runner ID": runner.get("id", ""),
                        "Runner name": runner.get("name", ""),
                        "OS": runner.get("os", ""),
                        "Architecture": runner.get("architecture", ""),
                        "Status": runner.get("status", ""),
                        "Busy": runner.get("busy", ""),
                        "Ephemeral": runner.get("ephemeral", ""),
                        "Labels": csv_join(labels, max_items=100),
                        "Migration action": "Register equivalent repo runner in GHEC and validate workflow labels",
                    }
                )
            repo_runner_count = len([r for r in repo_runners if isinstance(r, dict)])
            repo_runner_total += repo_runner_count

            # Repository rulesets. includes_parents=false avoids duplicating org rulesets already recorded.
            repo_rulesets = safe_paginated(
                client,
                errors,
                org,
                repo,
                "Repo rulesets",
                f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/rulesets",
                params={"includes_parents": "false"},
            )
            for ruleset in repo_rulesets:
                if not isinstance(ruleset, dict):
                    continue
                ruleset_id = ruleset.get("id")
                details = ruleset
                if ruleset_id:
                    maybe_details = safe_get(
                        client,
                        errors,
                        org,
                        repo,
                        "Repo ruleset details",
                        f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/rulesets/{ruleset_id}",
                        params={"includes_parents": "false"},
                        default=ruleset,
                    )
                    if isinstance(maybe_details, dict):
                        details = maybe_details
                rule_types, rule_count, conditions, bypass_count = summarize_ruleset_rules(details)
                ruleset_rows.append(
                    {
                        "Organization": org,
                        "Repository": repo,
                        "Scope": "Repository",
                        "Ruleset ID": details.get("id", ""),
                        "Ruleset name": details.get("name", ""),
                        "Target": details.get("target", ""),
                        "Enforcement": details.get("enforcement", ""),
                        "Source type": details.get("source_type", ""),
                        "Source": details.get("source", ""),
                        "Rule count": rule_count,
                        "Rule types": rule_types,
                        "Conditions": conditions,
                        "Bypass actors count": bypass_count,
                        "Created at": details.get("created_at", ""),
                        "Updated at": details.get("updated_at", ""),
                        "Migration action": "Recreate repository ruleset in GHEC; review destination rulesets before migration",
                    }
                )
            repo_ruleset_count = len([r for r in repo_rulesets if isinstance(r, dict)])
            repo_ruleset_total += repo_ruleset_count

            # Repository webhooks.
            repo_webhook_count = 0
            if not args.skip_webhooks:
                repo_hooks = safe_paginated(client, errors, org, repo, "Repo webhooks", f"/repos/{quote_path_part(org)}/{quote_path_part(repo)}/hooks", item_key="hooks")
                for hook in repo_hooks:
                    if not isinstance(hook, dict):
                        continue
                    config = hook.get("config", {}) or {}
                    webhook_rows.append(
                        {
                            "Organization": org,
                            "Repository": repo,
                            "Scope": "Repository",
                            "Hook ID": hook.get("id", ""),
                            "Hook name": hook.get("name", ""),
                            "Active": hook.get("active", ""),
                            "Events": csv_join(hook.get("events", []), max_items=100),
                            "URL": config.get("url", ""),
                            "Content type": config.get("content_type", ""),
                            "Insecure SSL": config.get("insecure_ssl", ""),
                            "Secret exported": "No - webhook secret values are not returned",
                            "Updated at": hook.get("updated_at", ""),
                            "Created at": hook.get("created_at", ""),
                            "Migration action": "Re-enable/recreate hook in GHEC and reset webhook secret if used",
                        }
                    )
                repo_webhook_count = len([h for h in repo_hooks if isinstance(h, dict)])
                repo_webhook_total += repo_webhook_count

            has_github_workflows = False
            gha_file_count = 0
            other_ci_file_count = 0
            repo_reference_count = 0
            lfs_detected = False
            if default_branch and not args.skip_reference_scan:
                has_github_workflows, gha_file_count, other_ci_file_count, repo_reference_count, lfs_or_tree_issue = scan_repo_files(
                    client=client,
                    errors=errors,
                    org=org,
                    repo=repo,
                    default_branch=default_branch,
                    name_index=name_index,
                    workflow_file_rows=workflow_file_rows,
                    reference_rows=reference_rows,
                    max_file_size=args.max_file_size,
                    max_ci_files_per_repo=args.max_ci_files_per_repo,
                    scan_all_yaml=args.scan_all_yaml,
                    include_line_text=args.include_line_text,
                )
                lfs_detected = bool(lfs_or_tree_issue and any(
                    row.get("Organization") == org and row.get("Repository") == repo and row.get("LFS detected") == "Yes"
                    for row in workflow_file_rows[-50:]
                ))
                if any(row.get("Organization") == org and row.get("Repository") == repo and row.get("LFS detected") == "Yes" for row in workflow_file_rows):
                    lfs_detected = True
            else:
                if args.skip_reference_scan:
                    scan_notes.append("Reference scan skipped")

            if has_github_workflows:
                repos_with_github_workflows += 1
            if other_ci_file_count > 0:
                repos_with_other_ci += 1
            workflow_reference_total += repo_reference_count
            if lfs_detected:
                repos_with_lfs += 1

            repo_error_count = maybe_count_errors(errors, org, repo) - repo_error_count_before
            repo_rows.append(
                {
                    "Organization": org,
                    "Repository": repo,
                    "Full name": full_name,
                    "Visibility": repo_obj.get("visibility", "private" if repo_obj.get("private") else "public"),
                    "Archived": repo_obj.get("archived", ""),
                    "Disabled": repo_obj.get("disabled", ""),
                    "Default branch": default_branch,
                    "Has GitHub workflow folder": "Yes" if has_github_workflows else "No",
                    "GitHub workflow files scanned": gha_file_count,
                    "Other CI files scanned": other_ci_file_count,
                    "Workflow reference findings": repo_reference_count,
                    "LFS detected": "Yes" if lfs_detected else "No",
                    "Actions repo secrets": repo_secret_count,
                    "Actions repo variables": repo_var_count,
                    "Environment count": env_count,
                    "Environment secrets": repo_env_secret_count,
                    "Environment variables": repo_env_var_count,
                    "Repo runners": repo_runner_count,
                    "Repo rulesets": repo_ruleset_count,
                    "Repo webhooks": repo_webhook_count,
                    "API error count": repo_error_count,
                    "Scan notes": csv_join(scan_notes, max_items=20),
                    "HTML URL": repo_obj.get("html_url", ""),
                }
            )

        org_error_count = maybe_count_errors(errors, org) - org_error_count_before
        unmatched_refs = sum(
            1
            for row in reference_rows
            if row.get("Organization") == org and row.get("Definition match") == "No" and row.get("Likely built-in") != "Yes"
        )
        status = "Complete" if org_error_count == 0 else "Partial"
        org_summary_rows.append(
            {
                "Organization": org,
                "Token user role": org_role,
                "Scan status": status,
                "API issue occurrences": org_error_count,
                "Unique API issue rows": sum(1 for e in errors if e.get("Organization") == org),
                "Scan duration seconds": round(time.monotonic() - org_started, 1),
                "Repository count": len([r for r in repos if isinstance(r, dict)]),
                "Repos with GitHub Actions workflows": repos_with_github_workflows,
                "Repos with other CI files": repos_with_other_ci,
                "Repos with Git LFS detected": repos_with_lfs,
                "Actions org secrets": org_actions_secret_count,
                "Actions repo secrets": repo_secret_total,
                "Actions environment secrets": env_secret_total,
                "Actions org variables": org_actions_var_count,
                "Actions repo variables": repo_var_total,
                "Actions environment variables": env_var_total,
                "Dependabot secrets": org_dependabot_secret_count,
                "Codespaces secrets": org_codespaces_secret_count,
                "Environments": env_count_total,
                "Org self-hosted runners": org_runner_count,
                "Repo self-hosted runners": repo_runner_total,
                "Runner groups": runner_group_count,
                "Org rulesets": org_ruleset_count,
                "Repo rulesets": repo_ruleset_total,
                "Workflow reference findings": workflow_reference_total,
                "Unmatched reference findings": unmatched_refs,
                "Webhooks": org_webhook_count + repo_webhook_total,
                "GitHub App installations": app_installation_count,
                "Teams": team_count,
                "Notes": csv_join(org_notes, max_items=20),
            }
        )
        elapsed = time.monotonic() - org_started
        if org_error_count:
            first_err = next((e for e in errors if e.get("Organization") == org), None)
            first_msg = first_err.get("Message") if first_err else "Open API Errors sheet"
            log(f"[ORG DONE] {org}: {repo_total_for_org} repos in {elapsed:.1f}s; {org_error_count} issue occurrence(s); first: {first_msg}")
        else:
            log(f"[ORG DONE] {org}: {repo_total_for_org} repos in {elapsed:.1f}s; no API issues")


    worker_count = max(1, min(int(args.workers), len(orgs)))
    if worker_count > 1:
        log(f"[INFO] Parallel organization workers: {worker_count}")
        with ThreadPoolExecutor(max_workers=worker_count, thread_name_prefix="org-scan") as executor:
            future_map = {executor.submit(scan_one_org, org): org for org in orgs}
            for future in as_completed(future_map):
                org = future_map[future]
                try:
                    future.result()
                except Exception as exc:
                    add_error(errors, org=org, endpoint_group="Organization worker", note=f"Unhandled worker failure: {exc}")
                    log(f"[ERROR] {org}: worker failed: {exc}")
    else:
        for org in orgs:
            scan_one_org(org)

    apply_reference_backlinks(secret_rows, variable_rows, reference_rows)

    # Parallel workers finish in nondeterministic order. Sort every sheet for a stable,
    # review-friendly workbook.
    def sort_rows(rows: List[Dict[str, Any]], *keys: str) -> None:
        rows.sort(key=lambda row: tuple(str(row.get(key, "")).casefold() for key in keys))

    sort_rows(org_summary_rows, "Organization")
    sort_rows(repo_rows, "Organization", "Repository")
    sort_rows(secret_rows, "Organization", "Repository", "Environment", "Secret category", "Secret name")
    sort_rows(variable_rows, "Organization", "Repository", "Environment", "Variable category", "Variable name")
    sort_rows(reference_rows, "Organization", "Repository", "File path", "Reference kind", "Reference name")
    sort_rows(workflow_file_rows, "Organization", "Repository", "File path")
    sort_rows(environment_rows, "Organization", "Repository", "Environment")
    sort_rows(runner_rows, "Organization", "Repository", "Scope", "Runner name")
    sort_rows(runner_group_rows, "Organization", "Runner group name")
    sort_rows(ruleset_rows, "Organization", "Repository", "Scope", "Ruleset name")
    sort_rows(webhook_rows, "Organization", "Repository", "Scope", "URL")
    sort_rows(app_installation_rows, "Organization", "App name")
    sort_rows(team_rows, "Organization", "Team name")
    severity_rank = {"Error": "0", "Warning": "1", "Info": "2"}
    errors.sort(
        key=lambda row: (
            severity_rank.get(str(row.get("Severity", "")), "9"),
            str(row.get("Organization", "")).casefold(),
            str(row.get("Repository", "")).casefold(),
            str(row.get("Endpoint group", "")).casefold(),
        )
    )

    stats = client.stats()
    scan_duration = round(time.monotonic() - scan_started, 1)
    issue_occurrences = sum(int(row.get("Occurrences") or 1) for row in errors)
    issue_classes = Counter(str(row.get("Classification") or "Unclassified") for row in errors)
    run_info = {
        "Generated at UTC": now_utc(),
        "Script version": SCRIPT_VERSION,
        "Authenticated user": user.get("login", ""),
        "API URL": client.api_url,
        "GHES installed version": ghes_version or "[not returned]",
        "API version header": api_version or "[not sent]",
        "PAT scopes reported": ", ".join(sorted(client.token_scopes)) if client.scope_header_present else "[not reported]",
        "Scan profile": args.profile,
        "Parallel organization workers": worker_count,
        "Repeated 404 circuit limit": CIRCUIT_THRESHOLD,
        "Total scan duration seconds": scan_duration,
        "REST API requests": stats.get("requests", 0),
        "Rate limit remaining": stats.get("rate_remaining", "") or "[not reported]",
        "Rate limit total": stats.get("rate_limit", "") or "[not reported]",
        "Organizations scanned": len(orgs),
        "Organization owners": len(owner_orgs),
        "Organization members": len(member_orgs),
        "Organization role unknown": len(unknown_orgs),
        "Organization list": csv_join(orgs, max_items=500),
        "Unique API issue rows": len(errors),
        "API issue occurrences": issue_occurrences,
        "Issue classifications": csv_join((f"{name}={count}" for name, count in sorted(issue_classes.items())), max_items=100),
        "Variable values exported": "Yes" if args.include_variable_values else "No",
        "Reference scan": "Skipped" if args.skip_reference_scan else "Enabled",
        "CI file max size bytes": args.max_file_size,
        "Max CI files per repo": args.max_ci_files_per_repo,
        "Scan all YAML": "Yes" if args.scan_all_yaml else "No",
        "Line excerpts exported": "Yes" if args.include_line_text else "No",
        "GEI migrated/not migrated reference": DOCS_GEI_DATA_URL,
        "Actions secrets API reference": DOCS_ACTIONS_SECRETS_URL,
        "Actions variables API reference": DOCS_ACTIONS_VARIABLES_URL,
        "Actions runners API reference": DOCS_ACTIONS_RUNNERS_URL,
        "Rulesets API reference": DOCS_RULESETS_URL,
        "Dependabot secrets API reference": DOCS_DEPENDABOT_SECRETS_URL,
        "Codespaces secrets API reference": DOCS_CODESPACES_SECRETS_URL,
    }

    write_workbook(
        output_path=args.output,
        run_info=run_info,
        org_summary_rows=org_summary_rows,
        repo_rows=repo_rows,
        secret_rows=secret_rows,
        variable_rows=variable_rows,
        reference_rows=reference_rows,
        workflow_file_rows=workflow_file_rows,
        environment_rows=environment_rows,
        runner_rows=runner_rows,
        runner_group_rows=runner_group_rows,
        ruleset_rows=ruleset_rows,
        webhook_rows=webhook_rows,
        app_installation_rows=app_installation_rows,
        team_rows=team_rows,
        errors=errors,
    )

    complete_orgs = sum(1 for row in org_summary_rows if row.get("Scan status") == "Complete")
    partial_orgs = len(org_summary_rows) - complete_orgs
    log(f"[DONE] Workbook: {os.path.abspath(args.output)}")
    log(f"[DONE] Complete organizations: {complete_orgs}; partial organizations: {partial_orgs}")
    log(f"[DONE] REST API calls: {stats.get('requests', 0)}; elapsed: {scan_duration:.1f}s")
    if stats.get("rate_remaining"):
        log(f"[DONE] API rate remaining: {stats.get('rate_remaining')}/{stats.get('rate_limit') or '?'}")
    if errors:
        severity_counts = Counter(str(row.get("Severity") or "Unknown") for row in errors)
        class_counts = Counter(str(row.get("Classification") or "Unclassified") for row in errors)
        log("[RESULT] API issue rows: " + ", ".join(f"{k}={v}" for k, v in sorted(severity_counts.items())))
        log("[RESULT] Main causes: " + "; ".join(f"{k}={v}" for k, v in class_counts.most_common(5)))
        log("[WARN] Review the API Errors sheet. Counts from skipped or unauthorized endpoints are marked unverified, not silently treated as confirmed zero.")


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create a deep GHES -> GHEC GEI migration gap inventory workbook.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--api-url", default=None, help="GitHub REST API base URL. For GHES use https://HOSTNAME/api/v3. Can also set GITHUB_API_URL.")
    parser.add_argument("--api-version", default=None, help=f"GitHub REST API version header. Can also set GITHUB_API_VERSION. Default: {DEFAULT_API_VERSION}.")
    parser.add_argument("--token", default=None, help="PAT token. Prefer GH_PAT/GITHUB_TOKEN env var to avoid shell history.")
    parser.add_argument("--auth-scheme", choices=["bearer", "token"], default="bearer", help="Authorization header scheme. Use token for older GHES if Bearer fails.")
    parser.add_argument("--orgs", default="", help="Optional comma-separated org list. If omitted, organizations are discovered automatically.")
    parser.add_argument("--use-env-orgs", action="store_true", help="Use GITHUB_ORGS when --orgs is omitted. By default a stale GITHUB_ORGS value is ignored.")
    parser.add_argument("--output", default="github_gei_migration_gap_inventory.xlsx", help="Output XLSX path.")
    parser.add_argument("--profile", choices=["quick", "standard", "deep"], default="standard", help="Scan-depth profile. Standard is recommended.")
    parser.add_argument("--workers", type=int, default=min(6, max(2, (os.cpu_count() or 4))), help="Organizations scanned concurrently. Reduce if GHES is under load.")
    parser.add_argument("--progress-every", type=int, default=5, help="Print repository progress every N repositories per organization.")
    parser.add_argument("--repeated-404-limit", type=int, default=3, help="Stop an endpoint group for an organization after this many identical 404 responses.")
    parser.add_argument("--interactive", action="store_true", help="Always show the configuration wizard.")
    parser.add_argument("--non-interactive", action="store_true", help="Never show the configuration wizard.")
    parser.add_argument("--timeout", type=int, default=30, help="HTTP timeout in seconds.")
    parser.add_argument("--no-ssl-verify", action="store_true", help="Disable SSL verification for GHES with internal/self-signed certs.")
    parser.add_argument("--rate-limit-sleep-max", type=int, default=60, help="Maximum seconds to sleep on rate limit before retry.")
    parser.add_argument("--include-variable-values", action="store_true", help="Export Actions variable values. Secrets are never exportable.")
    parser.add_argument("--include-line-text", action="store_true", help="Include line excerpts from workflow files in the workbook. Disabled by default to reduce accidental leakage.")
    parser.add_argument("--scan-all-yaml", action="store_true", help="Scan all YAML/JSON/TOML/Groovy-like files, not only likely CI/workflow files. May be slow/noisy.")
    parser.add_argument("--skip-reference-scan", action="store_true", help="Skip repository file scanning for secret/variable references.")
    parser.add_argument("--max-file-size", type=int, default=1024 * 1024, help="Maximum individual CI/config file size to fetch and scan.")
    parser.add_argument("--max-ci-files-per-repo", type=int, default=250, help="Maximum CI/config files to scan per repository.")
    parser.add_argument("--max-repos-per-org", type=int, default=0, help="Limit repo scan per org for testing. 0 means no limit.")
    parser.add_argument("--no-selected-repos", action="store_true", help="Do not fetch selected repository lists for org secrets/variables/runner groups.")
    parser.add_argument("--skip-webhooks", action="store_true", help="Skip org/repo webhooks.")
    parser.add_argument("--skip-apps", action="store_true", help="Skip organization GitHub App installations.")
    parser.add_argument("--skip-teams", action="store_true", help="Skip teams count/detail.")
    parser.add_argument("--skip-dependabot-codespaces", action="store_true", help="Skip Dependabot and Codespaces secret endpoints.")
    parser.add_argument("--force-codespaces", action="store_true", help="Call Codespaces endpoints even when the API URL appears to be GHES.")
    parser.add_argument("--verbose", action="store_true", help="Print every API request to stderr.")
    return parser.parse_args(argv)


def main() -> None:
    args = parse_args()
    try:
        if args.interactive or (sys.stdin.isatty() and not args.non_interactive):
            args = configure_interactive(args)
        else:
            apply_scan_profile(args)
        scan_inventory(args)
    except KeyboardInterrupt:
        raise SystemExit("Interrupted")


if __name__ == "__main__":
    main()
