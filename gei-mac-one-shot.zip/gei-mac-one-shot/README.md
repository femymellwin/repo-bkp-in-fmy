# One-shot GHES to GitHub.com repository migration for macOS

This package runs a complete repository migration for one GHES organization from a Mac:

1. Checks or installs `gh` and `jq`.
2. Installs or updates the official `github/gh-gei` extension.
3. Authenticates to the source GHES and destination GitHub.com APIs.
4. Inventories all source repositories before any destructive operation.
5. Deletes destination repositories according to `DELETE_SCOPE`.
6. Runs `gh gei migrate-repo` separately for every source repository.
7. Continues after repository-specific failures when configured.
8. Creates one `<repository>.err` file per failed repository and a combined `all-errors.err` file.

The script calls `gh gei migrate-repo` directly, so PowerShell is not required.

## Files

- `.env.example`: configuration and credentials template.
- `migrate-org.sh`: the only command you run.
- `.gitignore`: prevents accidental commits of credentials and logs.

## Setup

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

Required token types and scopes:

### Source GHES `GH_SOURCE_PAT`

Use a personal access token (classic) owned by a source organization owner:

- `repo`
- `admin:org`

### Destination GitHub.com `GH_PAT`

Use a personal access token (classic). For a destination organization owner performing migration and deletion:

- `repo`
- `admin:org`
- `workflow`
- `delete_repo`

Authorize the token for SAML SSO when required.

## First execution: dry run

Leave this in `.env`:

```dotenv
DRY_RUN="true"
```

Then run:

```bash
./migrate-org.sh
```

The dry run authenticates, inventories both organizations, prints deletion candidates, and prints migration candidates. It does not delete or migrate repositories.

## Production execution

Set the source and target organization names and tokens, then set:

```dotenv
DRY_RUN="false"
DELETE_DESTINATION_REPOS="true"
DELETE_SCOPE="all"
DELETE_CONFIRM="DELETE_ALL_REPOSITORIES_IN_YOUR_TARGET_ORG"
LOCK_SOURCE_REPOS="true"
```

For example, if `TARGET_ORG="inception-cloud"`:

```dotenv
DELETE_CONFIRM="DELETE_ALL_REPOSITORIES_IN_inception-cloud"
```

Run one command:

```bash
./migrate-org.sh
```

You can also pass a different environment file:

```bash
./migrate-org.sh ./production.env
```

## Output structure

```text
gei-output/
├── runs/
│   └── SOURCE-to-TARGET/
│       └── TIMESTAMP/
│           ├── run.log
│           ├── source-repositories.tsv
│           ├── destination-repositories-before-delete.tsv
│           ├── destination-repositories-after-delete.tsv
│           ├── summary.csv
│           ├── succeeded-repositories.txt
│           ├── failed-repositories.txt
│           ├── repository-logs/
│           │   └── REPOSITORY.log
│           ├── github-migration-logs/
│           │   └── REPOSITORY/
│           └── warnings/
└── errors/
    └── SOURCE-to-TARGET/
        └── TIMESTAMP/
            ├── REPOSITORY.err
            ├── cleanup.err
            └── all-errors.err
```

Each repository `.err` file contains a header, repository name, attempt count, exit code, file locations, and the complete GEI command output.

## Destructive behavior

`DELETE_SCOPE="all"` deletes every repository in the destination organization, not only repositories that also exist at the source. This permanently removes team permissions, and deleting private or internal repositories also deletes their forks. The local inventory is not a backup of code, issues, pull requests, releases, or other data.

The script therefore refuses to delete anything unless:

- source inventory succeeds and contains at least one repository;
- `DRY_RUN="false"`;
- `DELETE_DESTINATION_REPOS="true"`; and
- `DELETE_CONFIRM` exactly matches the destination organization.

Migration does not start when cleanup has errors unless `ABORT_ON_CLEANUP_ERROR="false"`.

## Migration behavior

Migration is sequential so that each repository has deterministic logs and errors. The script uses the source visibility (`public`, `private`, or `internal`) for the destination repository.

Optional controls are available in `.env` for:

- source repository locking;
- GitHub-owned migration storage;
- release skipping;
- SSL verification bypass for the internal GHES only;
- retries;
- deletion of partial failed repositories;
- continuing after individual repository failures.

## Important GEI limitations

The script can only migrate data supported by GitHub Enterprise Importer. It does not make unsupported items migratable, including Actions secrets and variables, Actions environments and run history, Git LFS objects, packages, repository discussions, teams and access permissions, rulesets, fork relationships, and several security results.
