#!/usr/bin/env bash

# One-shot macOS migration orchestrator:
#   1. Installs/checks required CLI tools.
#   2. Inventories the source organization.
#   3. Inventories and deletes destination repositories.
#   4. Migrates every source repository with GitHub Enterprise Importer.
#   5. Creates repository-specific logs and .err files.
#
# Compatible with the Bash 3.2 version included with macOS.

set -u
set -o pipefail
umask 077

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ENV_FILE="${1:-$SCRIPT_DIR/.env}"

if [ ! -f "$ENV_FILE" ]; then
  echo "ERROR: Environment file not found: $ENV_FILE" >&2
  echo "Copy .env.example to .env, edit it, then run this script again." >&2
  exit 2
fi

# shellcheck disable=SC1090
set -a
. "$ENV_FILE"
set +a

SOURCE_GHES_URL="${SOURCE_GHES_URL:-}"
SOURCE_GHES_API_URL="${SOURCE_GHES_API_URL:-}"
SOURCE_ORG="${SOURCE_ORG:-}"
TARGET_GITHUB_URL="${TARGET_GITHUB_URL:-https://github.com}"
TARGET_GITHUB_API_URL="${TARGET_GITHUB_API_URL:-https://api.github.com}"
TARGET_ORG="${TARGET_ORG:-}"
GITHUB_API_VERSION="${GITHUB_API_VERSION:-2026-03-10}"

DELETE_DESTINATION_REPOS="${DELETE_DESTINATION_REPOS:-false}"
DELETE_SCOPE="${DELETE_SCOPE:-matching-source}"
DELETE_CONFIRM="${DELETE_CONFIRM:-}"
DRY_RUN="${DRY_RUN:-true}"
ABORT_ON_CLEANUP_ERROR="${ABORT_ON_CLEANUP_ERROR:-true}"
CLEAN_PARTIAL_REPO_BEFORE_RETRY="${CLEAN_PARTIAL_REPO_BEFORE_RETRY:-true}"
DELETE_FAILED_TARGET_REPO="${DELETE_FAILED_TARGET_REPO:-true}"

USE_GITHUB_STORAGE="${USE_GITHUB_STORAGE:-true}"
LOCK_SOURCE_REPOS="${LOCK_SOURCE_REPOS:-false}"
SKIP_RELEASES="${SKIP_RELEASES:-false}"
KEEP_ARCHIVE="${KEEP_ARCHIVE:-false}"
NO_SSL_VERIFY="${NO_SSL_VERIFY:-false}"
VERBOSE="${VERBOSE:-true}"
MIGRATION_RETRIES="${MIGRATION_RETRIES:-0}"
CONTINUE_ON_REPO_ERROR="${CONTINUE_ON_REPO_ERROR:-true}"

AUTO_INSTALL_TOOLS="${AUTO_INSTALL_TOOLS:-true}"
UPDATE_GEI_EXTENSION="${UPDATE_GEI_EXTENSION:-true}"
OUTPUT_ROOT="${OUTPUT_ROOT:-./gei-output}"

RUN_ID="$(date '+%Y%m%d-%H%M%S')"
MIGRATION_KEY="${SOURCE_ORG}-to-${TARGET_ORG}"
RUN_ROOT="$OUTPUT_ROOT/runs/$MIGRATION_KEY/$RUN_ID"
ERROR_ROOT="$OUTPUT_ROOT/errors/$MIGRATION_KEY/$RUN_ID"
LOG_ROOT="$RUN_ROOT/repository-logs"
MIGRATION_LOG_ROOT="$RUN_ROOT/github-migration-logs"
WARNING_ROOT="$RUN_ROOT/warnings"
TMP_ROOT="$RUN_ROOT/tmp"
MAIN_LOG="$RUN_ROOT/run.log"
SUMMARY_CSV="$RUN_ROOT/summary.csv"
SOURCE_INVENTORY="$RUN_ROOT/source-repositories.tsv"
DESTINATION_INVENTORY="$RUN_ROOT/destination-repositories-before-delete.tsv"
DESTINATION_AFTER_CLEANUP="$RUN_ROOT/destination-repositories-after-delete.tsv"
SUCCESS_FILE="$RUN_ROOT/succeeded-repositories.txt"
FAILED_FILE="$RUN_ROOT/failed-repositories.txt"
ALL_ERRORS_FILE="$ERROR_ROOT/all-errors.err"
CLEANUP_ERROR_FILE="$ERROR_ROOT/cleanup.err"

mkdir -p "$RUN_ROOT" "$ERROR_ROOT" "$LOG_ROOT" "$MIGRATION_LOG_ROOT" "$WARNING_ROOT" "$TMP_ROOT"
: > "$MAIN_LOG"
: > "$SUCCESS_FILE"
: > "$FAILED_FILE"
: > "$ALL_ERRORS_FILE"

is_true() {
  case "${1:-}" in
    true|TRUE|True|yes|YES|Yes|1) return 0 ;;
    *) return 1 ;;
  esac
}

now() {
  date '+%Y-%m-%d %H:%M:%S'
}

log() {
  printf '[%s] %s\n' "$(now)" "$*" | tee -a "$MAIN_LOG"
}

warn() {
  printf '[%s] WARNING: %s\n' "$(now)" "$*" | tee -a "$MAIN_LOG" >&2
}

die() {
  printf '[%s] ERROR: %s\n' "$(now)" "$*" | tee -a "$MAIN_LOG" >&2
  printf '[%s] Output retained in: %s\n' "$(now)" "$RUN_ROOT" | tee -a "$MAIN_LOG" >&2
  exit 1
}

require_value() {
  variable_name="$1"
  eval "variable_value=\${$variable_name:-}"
  if [ -z "$variable_value" ]; then
    die "Required setting is empty: $variable_name"
  fi
}

valid_org_name() {
  printf '%s' "$1" | grep -Eq '^[A-Za-z0-9][A-Za-z0-9-]*$'
}

safe_file_name() {
  printf '%s' "$1" | tr -c 'A-Za-z0-9._-' '_'
}

urlencode() {
  jq -nr --arg value "$1" '$value | @uri'
}

print_phase() {
  log ""
  log "============================================================"
  log "$1"
  log "============================================================"
}

validate_configuration() {
  require_value SOURCE_GHES_URL
  require_value SOURCE_GHES_API_URL
  require_value SOURCE_ORG
  require_value GH_SOURCE_PAT
  require_value TARGET_GITHUB_URL
  require_value TARGET_GITHUB_API_URL
  require_value TARGET_ORG
  require_value GH_PAT

  if ! valid_org_name "$SOURCE_ORG"; then
    die "SOURCE_ORG must be an organization name, not a URL: $SOURCE_ORG"
  fi
  if ! valid_org_name "$TARGET_ORG"; then
    die "TARGET_ORG must be an organization name, not a URL: $TARGET_ORG"
  fi

  case "$DELETE_SCOPE" in
    all|matching-source) ;;
    *) die "DELETE_SCOPE must be 'all' or 'matching-source'." ;;
  esac

  if ! printf '%s' "$MIGRATION_RETRIES" | grep -Eq '^[0-9]+$'; then
    die "MIGRATION_RETRIES must be a non-negative integer."
  fi

  if is_true "$DELETE_DESTINATION_REPOS" && ! is_true "$DRY_RUN"; then
    if [ "$DELETE_SCOPE" = "all" ]; then
      expected="DELETE_ALL_REPOSITORIES_IN_${TARGET_ORG}"
    else
      expected="DELETE_MATCHING_REPOSITORIES_IN_${TARGET_ORG}"
    fi

    if [ "$DELETE_CONFIRM" != "$expected" ]; then
      die "Deletion confirmation mismatch. Set DELETE_CONFIRM exactly to: $expected"
    fi
  fi
}

install_or_check_tools() {
  print_phase "STEP 1 - INSTALL OR VALIDATE LOCAL TOOLS"

  missing=""
  for tool in curl jq gh; do
    if ! command -v "$tool" >/dev/null 2>&1; then
      missing="$missing $tool"
    fi
  done

  if [ -n "$missing" ]; then
    if ! is_true "$AUTO_INSTALL_TOOLS"; then
      die "Missing required tools:$missing"
    fi
    if ! command -v brew >/dev/null 2>&1; then
      die "Homebrew is required for automatic installation. Install Homebrew, or install these tools manually:$missing"
    fi

    log "Installing missing tools with Homebrew:$missing"
    for tool in $missing; do
      case "$tool" in
        curl)
          # macOS normally includes curl. Avoid replacing the system curl automatically.
          die "curl is missing. Install or repair curl manually."
          ;;
        jq|gh)
          if ! brew install "$tool" 2>&1 | tee -a "$MAIN_LOG"; then
            die "Homebrew could not install $tool."
          fi
          ;;
      esac
    done
  fi

  log "curl: $(curl --version | head -n 1)"
  log "jq: $(jq --version)"
  log "gh: $(gh --version | head -n 1)"

  if gh gei --version >/dev/null 2>&1; then
    log "GitHub Enterprise Importer extension is installed."
    if is_true "$UPDATE_GEI_EXTENSION"; then
      log "Updating github/gh-gei extension."
      if ! gh extension upgrade github/gh-gei 2>&1 | tee -a "$MAIN_LOG"; then
        die "Unable to update github/gh-gei."
      fi
    fi
  else
    log "Installing github/gh-gei extension."
    if ! gh extension install github/gh-gei 2>&1 | tee -a "$MAIN_LOG"; then
      die "Unable to install github/gh-gei."
    fi
  fi

  log "GEI: $(gh gei --version 2>&1 | head -n 1)"
}

http_request() {
  method="$1"
  url="$2"
  token="$3"
  output_file="$4"
  insecure="$5"
  api_version="$6"

  curl_args=(
    -sS
    -L
    -o "$output_file"
    -w '%{http_code}'
    -H 'Accept: application/vnd.github+json'
    -H "Authorization: Bearer $token"
    -H 'User-Agent: gei-mac-one-shot'
  )

  if [ -n "$api_version" ]; then
    curl_args+=( -H "X-GitHub-Api-Version: $api_version" )
  fi
  if is_true "$insecure"; then
    curl_args+=( -k )
  fi
  if [ "$method" != "GET" ]; then
    curl_args+=( -X "$method" )
  fi

  http_code="$(curl "${curl_args[@]}" "$url" 2>>"$MAIN_LOG")"
  curl_status=$?
  printf '%s' "$http_code"
  return "$curl_status"
}

assert_api_identity() {
  label="$1"
  api_url="$2"
  token="$3"
  insecure="$4"
  api_version="$5"

  body="$TMP_ROOT/identity-$(safe_file_name "$label").json"
  code="$(http_request GET "$api_url/user" "$token" "$body" "$insecure" "$api_version")"
  request_status=$?

  if [ "$request_status" -ne 0 ] || [ "$code" != "200" ]; then
    response="$(cat "$body" 2>/dev/null || true)"
    die "$label authentication failed. HTTP $code. Response: $response"
  fi

  login="$(jq -r '.login // empty' "$body")"
  if [ -z "$login" ]; then
    die "$label authentication response did not contain a login."
  fi
  log "$label authenticated as: $login"
}

assert_org_access() {
  label="$1"
  api_url="$2"
  org="$3"
  token="$4"
  insecure="$5"
  api_version="$6"

  encoded_org="$(urlencode "$org")"
  body="$TMP_ROOT/org-$(safe_file_name "$label")-$(safe_file_name "$org").json"
  code="$(http_request GET "$api_url/orgs/$encoded_org" "$token" "$body" "$insecure" "$api_version")"
  request_status=$?

  if [ "$request_status" -ne 0 ] || [ "$code" != "200" ]; then
    response="$(cat "$body" 2>/dev/null || true)"
    die "$label organization access failed for '$org'. HTTP $code. Response: $response"
  fi

  log "$label organization verified: $org"
}

fetch_repositories() {
  label="$1"
  api_url="$2"
  org="$3"
  token="$4"
  insecure="$5"
  api_version="$6"
  output_file="$7"

  : > "$output_file"
  page=1
  encoded_org="$(urlencode "$org")"

  while :; do
    body="$TMP_ROOT/$(safe_file_name "$label")-repos-page-$page.json"
    url="$api_url/orgs/$encoded_org/repos?type=all&per_page=100&page=$page"
    code="$(http_request GET "$url" "$token" "$body" "$insecure" "$api_version")"
    request_status=$?

    if [ "$request_status" -ne 0 ] || [ "$code" != "200" ]; then
      response="$(cat "$body" 2>/dev/null || true)"
      die "Could not list $label repositories. HTTP $code. Response: $response"
    fi

    if ! jq -e 'type == "array"' "$body" >/dev/null 2>&1; then
      die "$label repository response is not a JSON array."
    fi

    jq -r '.[] | [
      .name,
      (.visibility // (if .private then "private" else "public" end)),
      (.archived // false),
      (.fork // false),
      (.size // 0),
      (.default_branch // "")
    ] | @tsv' "$body" >> "$output_file"

    count="$(jq 'length' "$body")"
    if [ "$count" -lt 100 ]; then
      break
    fi
    page=$((page + 1))
  done

  sort -u -o "$output_file" "$output_file"
}

repo_is_in_source_inventory() {
  repository="$1"
  awk -F '\t' -v repo="$repository" '$1 == repo { found=1; exit } END { exit(found ? 0 : 1) }' "$SOURCE_INVENTORY"
}

target_repo_exists() {
  repository="$1"
  encoded_org="$(urlencode "$TARGET_ORG")"
  encoded_repo="$(urlencode "$repository")"
  body="$TMP_ROOT/target-exists-$(safe_file_name "$repository").json"
  code="$(http_request GET "$TARGET_GITHUB_API_URL/repos/$encoded_org/$encoded_repo" "$GH_PAT" "$body" false "$GITHUB_API_VERSION")"
  request_status=$?

  if [ "$request_status" -ne 0 ]; then
    return 2
  fi
  if [ "$code" = "200" ]; then
    return 0
  fi
  if [ "$code" = "404" ]; then
    return 1
  fi
  return 2
}

delete_target_repository() {
  repository="$1"
  reason="$2"
  encoded_org="$(urlencode "$TARGET_ORG")"
  encoded_repo="$(urlencode "$repository")"
  body="$TMP_ROOT/delete-$(safe_file_name "$repository").json"

  log "Deleting destination repository: $TARGET_ORG/$repository ($reason)"
  code="$(http_request DELETE "$TARGET_GITHUB_API_URL/repos/$encoded_org/$encoded_repo" "$GH_PAT" "$body" false "$GITHUB_API_VERSION")"
  request_status=$?

  if [ "$request_status" -ne 0 ] || [ "$code" != "204" ]; then
    response="$(cat "$body" 2>/dev/null || true)"
    warn "Deletion failed for $TARGET_ORG/$repository. HTTP $code. $response"
    return 1
  fi

  log "Deleted destination repository: $TARGET_ORG/$repository"
  return 0
}

append_cleanup_error() {
  repository="$1"
  details="$2"
  {
    printf '============================================================\n'
    printf 'Cleanup repository: %s/%s\n' "$TARGET_ORG" "$repository"
    printf 'Timestamp: %s\n' "$(now)"
    printf '============================================================\n'
    printf '%s\n\n' "$details"
  } >> "$CLEANUP_ERROR_FILE"
}

cleanup_destination() {
  print_phase "STEP 4 - DELETE DESTINATION REPOSITORIES"

  if ! is_true "$DELETE_DESTINATION_REPOS"; then
    log "Destination deletion is disabled."
    return 0
  fi

  destination_count="$(wc -l < "$DESTINATION_INVENTORY" | tr -d ' ')"
  if [ "$destination_count" -eq 0 ]; then
    log "Destination organization is already empty."
    return 0
  fi

  if is_true "$DRY_RUN"; then
    log "DRY RUN: no destination repositories will be deleted."
    while IFS=$(printf '\t') read -r repo visibility archived fork size default_branch; do
      if [ "$DELETE_SCOPE" = "all" ] || repo_is_in_source_inventory "$repo"; then
        log "DRY RUN deletion candidate: $TARGET_ORG/$repo"
      fi
    done < "$DESTINATION_INVENTORY"
    return 0
  fi

  : > "$CLEANUP_ERROR_FILE"
  cleanup_failures=0
  cleanup_candidates=0

  while IFS=$(printf '\t') read -r repo visibility archived fork size default_branch; do
    should_delete=false
    if [ "$DELETE_SCOPE" = "all" ]; then
      should_delete=true
    elif repo_is_in_source_inventory "$repo"; then
      should_delete=true
    fi

    if ! is_true "$should_delete"; then
      log "Keeping unrelated destination repository: $TARGET_ORG/$repo"
      continue
    fi

    cleanup_candidates=$((cleanup_candidates + 1))
    if ! delete_target_repository "$repo" "initial cleanup"; then
      cleanup_failures=$((cleanup_failures + 1))
      append_cleanup_error "$repo" "GitHub API did not return HTTP 204. Review $MAIN_LOG for the response body."
    fi
  done < "$DESTINATION_INVENTORY"

  log "Cleanup candidates: $cleanup_candidates"
  log "Cleanup failures: $cleanup_failures"

  fetch_repositories "destination-after-cleanup" "$TARGET_GITHUB_API_URL" "$TARGET_ORG" "$GH_PAT" false "$GITHUB_API_VERSION" "$DESTINATION_AFTER_CLEANUP"

  remaining_collisions=0
  if [ "$DELETE_SCOPE" = "all" ]; then
    remaining_collisions="$(wc -l < "$DESTINATION_AFTER_CLEANUP" | tr -d ' ')"
  else
    while IFS=$(printf '\t') read -r repo visibility archived fork size default_branch; do
      if repo_is_in_source_inventory "$repo"; then
        remaining_collisions=$((remaining_collisions + 1))
      fi
    done < "$DESTINATION_AFTER_CLEANUP"
  fi

  if [ "$remaining_collisions" -ne 0 ]; then
    cleanup_failures=$((cleanup_failures + remaining_collisions))
    append_cleanup_error "ORGANIZATION" "$remaining_collisions repository(s) that should have been deleted still exist after cleanup."
  fi

  if [ "$cleanup_failures" -ne 0 ]; then
    cat "$CLEANUP_ERROR_FILE" >> "$ALL_ERRORS_FILE"
    if is_true "$ABORT_ON_CLEANUP_ERROR"; then
      die "Destination cleanup failed. Migration was not started. See $CLEANUP_ERROR_FILE"
    fi
  fi
}

download_migration_log() {
  repository="$1"
  repository_log="$2"
  repo_log_dir="$MIGRATION_LOG_ROOT/$(safe_file_name "$repository")"
  warning_file="$WARNING_ROOT/$(safe_file_name "$repository").warn"
  mkdir -p "$repo_log_dir"

  log "Downloading GitHub migration log for: $TARGET_ORG/$repository"
  (
    cd "$repo_log_dir" || exit 1
    gh gei download-logs \
      --github-target-org "$TARGET_ORG" \
      --target-repo "$repository"
  ) >> "$repository_log" 2>&1
  status=$?

  if [ "$status" -ne 0 ]; then
    {
      printf 'Repository: %s/%s\n' "$TARGET_ORG" "$repository"
      printf 'Timestamp: %s\n' "$(now)"
      printf 'Warning: gh gei download-logs returned exit code %s.\n' "$status"
      printf 'The main migration result is unchanged. Review: %s\n' "$repository_log"
    } > "$warning_file"
    warn "Could not download the GitHub migration log for $repository. See $warning_file"
  else
    log "Migration log downloaded under: $repo_log_dir"
  fi
}

write_repo_error() {
  repository="$1"
  exit_code="$2"
  attempts="$3"
  repository_log="$4"
  error_file="$ERROR_ROOT/$(safe_file_name "$repository").err"

  {
    printf '============================================================\n'
    printf 'Repository: %s/%s -> %s/%s\n' "$SOURCE_ORG" "$repository" "$TARGET_ORG" "$repository"
    printf 'Timestamp: %s\n' "$(now)"
    printf 'Attempts: %s\n' "$attempts"
    printf 'Final exit code: %s\n' "$exit_code"
    printf 'Repository log: %s\n' "$repository_log"
    printf 'GitHub migration log directory: %s/%s\n' "$MIGRATION_LOG_ROOT" "$(safe_file_name "$repository")"
    printf '============================================================\n\n'
    cat "$repository_log"
    printf '\n\n'
  } > "$error_file"

  cat "$error_file" >> "$ALL_ERRORS_FILE"
  printf '%s\n' "$repository" >> "$FAILED_FILE"
}

migrate_repository() {
  repository="$1"
  visibility="$2"
  index="$3"
  total="$4"

  file_name="$(safe_file_name "$repository")"
  repository_log="$LOG_ROOT/$file_name.log"
  : > "$repository_log"

  max_attempts=$((MIGRATION_RETRIES + 1))
  attempt=1
  final_status=1

  while [ "$attempt" -le "$max_attempts" ]; do
    log "[$index/$total] Migrating $SOURCE_ORG/$repository -> $TARGET_ORG/$repository; attempt $attempt/$max_attempts"

    command_args=(
      gh gei migrate-repo
      --github-source-org "$SOURCE_ORG"
      --source-repo "$repository"
      --github-target-org "$TARGET_ORG"
      --target-repo "$repository"
      --ghes-api-url "$SOURCE_GHES_API_URL"
      --target-repo-visibility "$visibility"
    )

    if is_true "$USE_GITHUB_STORAGE"; then command_args+=( --use-github-storage ); fi
    if is_true "$LOCK_SOURCE_REPOS"; then command_args+=( --lock-source-repo ); fi
    if is_true "$SKIP_RELEASES"; then command_args+=( --skip-releases ); fi
    if is_true "$KEEP_ARCHIVE"; then command_args+=( --keep-archive ); fi
    if is_true "$NO_SSL_VERIFY"; then command_args+=( --no-ssl-verify ); fi
    if is_true "$VERBOSE"; then command_args+=( --verbose ); fi

    {
      printf '\n============================================================\n'
      printf 'Repository: %s\n' "$repository"
      printf 'Attempt: %s/%s\n' "$attempt" "$max_attempts"
      printf 'Started: %s\n' "$(now)"
      printf 'Command:'
      printf ' %q' "${command_args[@]}"
      printf '\n============================================================\n'
      "${command_args[@]}"
    } 2>&1 | tee -a "$repository_log" "$MAIN_LOG"
    final_status=${PIPESTATUS[0]}

    if [ "$final_status" -eq 0 ]; then
      log "Migration succeeded: $repository"
      download_migration_log "$repository" "$repository_log"
      printf '%s\n' "$repository" >> "$SUCCESS_FILE"
      printf '"%s","succeeded","%s","0","%s",""\n' "$repository" "$attempt" "$repository_log" >> "$SUMMARY_CSV"
      return 0
    fi

    warn "Migration failed for $repository with exit code $final_status on attempt $attempt."

    if [ "$attempt" -lt "$max_attempts" ]; then
      download_migration_log "$repository" "$repository_log"

      if is_true "$CLEAN_PARTIAL_REPO_BEFORE_RETRY"; then
        if target_repo_exists "$repository"; then
          if ! delete_target_repository "$repository" "cleanup before migration retry"; then
            warn "Could not remove partial destination repository before retry: $repository"
            break
          fi
        else
          exists_status=$?
          if [ "$exists_status" -eq 2 ]; then
            warn "Could not determine whether partial destination repository exists: $repository"
            break
          fi
        fi
      fi
    fi

    attempt=$((attempt + 1))
  done

  attempts_used="$attempt"
  if [ "$attempts_used" -gt "$max_attempts" ]; then
    attempts_used="$max_attempts"
  fi

  download_migration_log "$repository" "$repository_log"
  write_repo_error "$repository" "$final_status" "$attempts_used" "$repository_log"

  if is_true "$DELETE_FAILED_TARGET_REPO"; then
    if target_repo_exists "$repository"; then
      if ! delete_target_repository "$repository" "cleanup after final migration failure"; then
        warn "Failed destination repository remains: $TARGET_ORG/$repository"
      fi
    fi
  fi

  error_path="$ERROR_ROOT/$(safe_file_name "$repository").err"
  printf '"%s","failed","%s","%s","%s","%s"\n' "$repository" "$attempts_used" "$final_status" "$repository_log" "$error_path" >> "$SUMMARY_CSV"
  return 1
}

migrate_all_repositories() {
  print_phase "STEP 5 - MIGRATE ALL SOURCE REPOSITORIES"

  if is_true "$DRY_RUN"; then
    log "DRY RUN: migration commands will not be executed."
    while IFS=$(printf '\t') read -r repo visibility archived fork size default_branch; do
      log "DRY RUN migration candidate: $SOURCE_ORG/$repo -> $TARGET_ORG/$repo [$visibility]"
    done < "$SOURCE_INVENTORY"
    return 0
  fi

  printf '"repository","status","attempts","exit_code","log_file","error_file"\n' > "$SUMMARY_CSV"

  total="$(wc -l < "$SOURCE_INVENTORY" | tr -d ' ')"
  index=0
  succeeded=0
  failed=0

  while IFS=$(printf '\t') read -r repo visibility archived fork size default_branch; do
    index=$((index + 1))

    case "$visibility" in
      public|private|internal) ;;
      *)
        warn "Unknown visibility '$visibility' for $repo; using private."
        visibility="private"
        ;;
    esac

    if migrate_repository "$repo" "$visibility" "$index" "$total"; then
      succeeded=$((succeeded + 1))
    else
      failed=$((failed + 1))
      if ! is_true "$CONTINUE_ON_REPO_ERROR"; then
        warn "CONTINUE_ON_REPO_ERROR=false; stopping after repository failure."
        break
      fi
    fi
  done < "$SOURCE_INVENTORY"

  log "Migration results: total=$total succeeded=$succeeded failed=$failed"

  if [ "$failed" -ne 0 ]; then
    return 1
  fi
  return 0
}

final_summary() {
  print_phase "FINAL SUMMARY"
  source_count="$(wc -l < "$SOURCE_INVENTORY" | tr -d ' ')"
  destination_count="$(wc -l < "$DESTINATION_INVENTORY" | tr -d ' ')"
  succeeded_count="$(wc -l < "$SUCCESS_FILE" | tr -d ' ')"
  failed_count="$(wc -l < "$FAILED_FILE" | tr -d ' ')"

  log "Source repositories inventoried: $source_count"
  log "Destination repositories before cleanup: $destination_count"
  log "Successful migrations: $succeeded_count"
  log "Failed migrations: $failed_count"
  log "Run directory: $RUN_ROOT"
  log "Organization error directory: $ERROR_ROOT"
  log "Combined errors: $ALL_ERRORS_FILE"
  log "Summary CSV: $SUMMARY_CSV"

  if is_true "$DRY_RUN"; then
    log "DRY RUN completed. No repositories were deleted or migrated."
  elif [ "$failed_count" -ne 0 ]; then
    warn "One or more repositories failed. Review $ALL_ERRORS_FILE"
  else
    log "All repository migrations completed successfully."
  fi
}

main() {
  print_phase "GEI ONE-SHOT ORGANIZATION REPOSITORY MIGRATION"
  log "Environment file: $ENV_FILE"
  log "Source: $SOURCE_GHES_URL/$SOURCE_ORG"
  log "Destination: $TARGET_GITHUB_URL/$TARGET_ORG"
  log "Dry run: $DRY_RUN"
  log "Delete destination repositories: $DELETE_DESTINATION_REPOS"
  log "Delete scope: $DELETE_SCOPE"
  log "Lock source repositories: $LOCK_SOURCE_REPOS"
  log "Tokens are loaded but will never be printed."

  validate_configuration
  install_or_check_tools

  print_phase "STEP 2 - AUTHENTICATE AND VERIFY ORGANIZATIONS"
  assert_api_identity "source GHES" "$SOURCE_GHES_API_URL" "$GH_SOURCE_PAT" "$NO_SSL_VERIFY" ""
  assert_org_access "source GHES" "$SOURCE_GHES_API_URL" "$SOURCE_ORG" "$GH_SOURCE_PAT" "$NO_SSL_VERIFY" ""
  assert_api_identity "destination GitHub.com" "$TARGET_GITHUB_API_URL" "$GH_PAT" false "$GITHUB_API_VERSION"
  assert_org_access "destination GitHub.com" "$TARGET_GITHUB_API_URL" "$TARGET_ORG" "$GH_PAT" false "$GITHUB_API_VERSION"

  print_phase "STEP 3 - INVENTORY SOURCE AND DESTINATION"
  fetch_repositories "source" "$SOURCE_GHES_API_URL" "$SOURCE_ORG" "$GH_SOURCE_PAT" "$NO_SSL_VERIFY" "" "$SOURCE_INVENTORY"
  source_count="$(wc -l < "$SOURCE_INVENTORY" | tr -d ' ')"
  if [ "$source_count" -eq 0 ]; then
    die "Source organization contains no repositories. Destination cleanup was not attempted."
  fi
  log "Source repositories inventoried: $source_count"
  log "Source inventory: $SOURCE_INVENTORY"

  fetch_repositories "destination" "$TARGET_GITHUB_API_URL" "$TARGET_ORG" "$GH_PAT" false "$GITHUB_API_VERSION" "$DESTINATION_INVENTORY"
  destination_count="$(wc -l < "$DESTINATION_INVENTORY" | tr -d ' ')"
  log "Destination repositories inventoried: $destination_count"
  log "Destination inventory: $DESTINATION_INVENTORY"

  cleanup_destination

  migration_status=0
  migrate_all_repositories || migration_status=$?
  final_summary

  if is_true "$DRY_RUN"; then
    exit 0
  fi
  if [ "$migration_status" -ne 0 ]; then
    exit 1
  fi
  exit 0
}

main "$@"
